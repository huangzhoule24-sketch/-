#!/usr/bin/env python3
"""Deliver the current editable project with runtime art and selected public docs."""
import ast,argparse
import json
import shutil
from package_release import ROOT,BUILD,allowed_source,game_source_fingerprint,sha256,write_json,write_zip
from package_latest_editable_source import fingerprint

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['international','visual','branch'],default='international');args=parser.parse_args();profile=args.profile
    expected=game_source_fingerprint();stage=BUILD/(profile+'-source')
    if stage.exists():shutil.rmtree(stage)
    stage.mkdir();selected=set()
    for top in['assets','config','scenes','scripts','tests','web','CustomAssets','CustomAudio']:
        selected.update(p for p in(ROOT/top).rglob('*')if p.is_file()and allowed_source(p))
    selected.update(ROOT/n for n in['project.godot','export_presets.cfg','.gitignore'])
    selected.update(p for p in(ROOT/'art-source').rglob('*')if p.is_file()and allowed_source(p)and'masters'not in p.relative_to(ROOT/'art-source').parts)
    denied=('classroom','ppt','presentation','outlook','materials','slides')
    selected.update(p for p in(ROOT/'tools').rglob('*')if p.is_file()and allowed_source(p)and not any(word in p.name.lower()for word in denied))
    docs={'docs/international-release-r1.md','docs/international-art-process.md','docs/international-art-manifest.json','docs/ui-refresh-r1.md','docs/art-pipeline.md','docs/culture-guide.md','docs/cultural-redesign-guide.md','docs/english-version-guide.md','docs/mobile-portrait-r9.md','docs/device-auto-entry.md','docs/management-rules.md','docs/expansion-rules.md','docs/web-site-guide.md','docs/proposals/localization-india-nordic-greece-integrated-r2-20261105.md'}
    docs.add('docs/international-validation-r1.md')
    if profile=='visual':docs.update(['docs/visual-release-r1.md','docs/visual-validation-r1.md','docs/visual-art-provenance.json','docs/visual-art-process-r1.md'])
    if profile=='branch':docs.update(['docs/branch-release-r1.md','docs/branch-validation-r1.md','docs/branch-art-process-r1.md','docs/branch-art-provenance.json','docs/validation-artifacts/branch-r1/verification-summary.json','docs/visual-release-r1.md','docs/visual-validation-r1.md','docs/visual-art-provenance.json','docs/visual-art-process-r1.md'])
    for tool in['tools/package_release.py','tools/build_web_site.py']:
        for node in ast.walk(ast.parse((ROOT/tool).read_text())):
            if isinstance(node,ast.Constant)and isinstance(node.value,str)and node.value.startswith('docs/')and(ROOT/node.value).is_file():docs.add(node.value)
    selected.update(ROOT/n for n in docs if(ROOT/n).is_file())
    selected.update(p for p in(ROOT/'docs/proposals/localization-plan-r2').glob('*')if p.is_file()and p.suffix.lower()in['.png','.svg'])
    for top in['docs/culture-research','docs/translation-research','docs/free-sfx','docs/music-r4','docs/menu-r5']:
        selected.update(p for p in(ROOT/top).rglob('*')if p.is_file()and p.suffix.lower()in['.json','.md','.csv','.txt'])
    for path in selected:
        relative=path.relative_to(ROOT);assert relative.as_posix()not in['AGENTS.md','docs/project-memory.md']
        target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
    (stage/'README.md').write_text('''# 山海食肆物语 · 跨国食肆可编辑源码

SH-SOURCE-INTERNATIONAL-R1 · Godot 4.6.3

解压后用Godot 4.6.3导入project.godot，等待资源导入并运行主场景。包含当前完整运行美术、字体、音频、原主店和印度/北欧/希腊内容；不需要额外母图包即可运行。本轮11张新美术母图直接在assets/art/International中，图集取景由international_art.gd配置。

新内容入口：完成白泽六步引导→更多→跨国食肆。正式经营解锁，文化图鉴可提前读。默认自动交付，循环备料需主动开启并照常付款。存档与同一浏览器已部署网站的存档分别保存。

scripts/core/international_rules.gd是当地经营；scripts/ui/international_panel.gd与international_scene.gd是界面与镜头；config/international*.json由tools/build_international_content.py整理。文化资料、游戏改编与AI美术制作见docs/international-art-process.md。

命令行检查：godot --headless --path . --script tests/international_tests.gd；界面检查使用tests/international_ui_tests.gd。浏览器检查另外需要Node/Playwright/Chromium。

导出网站或Windows时安装Godot 4.6.3对应的标准导出模板，并用export_presets.cfg预设导出。旧发布工具可能引用本工程以外的历史构建缓存；在新电脑不要直接依赖这些旧缓存。源码是编辑工程，不能把它直接作为WorkBuddy的静态网站部署；使用另提供的完整网页运行包。

包内不含私人PPT、聊天记录、项目日记、登录凭据、玩家存档、Git历史或Godot导入缓存。原素材许可见assets/audio/CREDITS.md、assets/fonts及tools/licenses。新美术使用图像生成，文化资料仍可继续校勘和邀请当地读者审阅。
''',encoding='utf-8')
    if profile=='visual':
        (stage/'README.md').write_text('# 山海食肆物语 · 美术与技术完善版可编辑源码\n\nSH-SOURCE-VISUAL-R1 · Godot 4.6.3\n\n用Godot4.6.3导入project.godot即可运行；包含全部当前运行素材、新美术母图及跨国三地内容。编辑后安装同版本标准导出模板，通过Web/Windows预设导出。历史发布工具可能引用本工程之外的旧构建缓存，新电脑请使用标准模板。源码不能直接当WorkBuddy静态网站部署。\n\n检查：godot --headless --path . --script tests/visual_refinement_tests.gd；其余检查位于tests。\n\n'+(ROOT/'docs/visual-release-r1.md').read_text()+'\n\n未包含私人PPT、聊天、项目记忆、凭据、玩家存档、Git历史或导入缓存。原素材许可见assets/audio/CREDITS.md、assets/fonts及tools/licenses。\n')
    if profile=='branch':(stage/'README.md').write_text('# 山海食肆物语 · 跨国场景版可编辑源码\n\nSH-SOURCE-BRANCH-R1 · Godot 4.6.3。导入project.godot运行。包含全部当前运行素材；不含玩家存档、私人课件、项目记忆、凭据、Git历史或导入缓存。源码不能直接作为WorkBuddy静态网站部署。标准Web导出需同版本官方模板；本环境历史构建脚本可能依赖旧缓存。\n\n'+(ROOT/'docs/branch-release-r1.md').read_text()+'\n\n核心：scripts/core/international_floor.gd与international_rules.gd；界面：restaurant_scene_switcher.gd与international_scene.gd。检查：tests/branch_floor_tests.gd、branch_scene_ui_tests.gd。其余测试见tests目录。素材许可保留assets/audio/CREDITS.md与字体说明。\n')
    assert fingerprint(stage)==expected
    names=sorted(p.relative_to(stage).as_posix()for p in stage.rglob('*')if p.is_file())
    assert not any(n.startswith(('.git/','.godot/','build/'))or n in['AGENTS.md','docs/project-memory.md']or n.endswith(('.pptx','.pdf','.key','.pem'))for n in names)
    write_json(stage/'SOURCE-INFO.json',{'version':'SH-SOURCE-'+profile.upper()+'-R1','game_source':expected,'files':{n:{'bytes':(stage/n).stat().st_size,'sha256':sha256(stage/n)}for n in names}})
    artifact=write_zip(BUILD/('shanhai-'+profile+'-r1-editable-source.zip'),[(p,p.relative_to(stage).as_posix())for p in sorted(stage.rglob('*'))if p.is_file()])
    assert artifact['bytes']<100*1024*1024
    write_json(BUILD/(profile+'-r1')/'source-package.json',{'game_source':expected,'artifact':artifact,'source_files':len(names)+1});print(json.dumps(artifact,indent=2))

if __name__=='__main__':main()
