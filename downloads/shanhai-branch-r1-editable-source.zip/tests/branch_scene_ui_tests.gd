extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(v: bool,msg: String):
 checks+=1
 if not v:failures.append(msg);push_error(msg)
func settle():
 for i in range(15):await process_frame
func control(ui,id):
 for b in ui._qa_buttons:
  if is_instance_valid(b)and b.is_visible_in_tree()and not b.is_queued_for_deletion()and b.get_meta("qa_id","")==id:return b
 return null
func run():
 for rid in["india","nordic","greece"]:
  root.size=Vector2i(1280,800);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle();ui.return_to_restaurant();await settle()
  var r=ui.model.full_rules.international;r.perform("int_open",{"region":rid});var old_camera=ui.map_view.house().camera;ui.open_panel("场景切换");await settle()
  expect(control(ui,"scene:visit:"+rid)!=null,rid+" opened scene can be entered via switcher")
  control(ui,"scene:visit:"+rid).pressed.emit();await settle()
  expect(ui.panel_name.is_empty()and ui.scene_switcher.active()==rid and is_instance_valid(ui.scene_switcher.view),rid+" replaces actual primary gameplay viewport")
  var scene=ui.scene_switcher.view;expect(scene.primary and scene.size.is_equal_approx(ui.map_view.house().content_rect().size),rid+" uses full map content area")
  ui.map_view.house().zoom_at(1.4,ui.map_view.house().content_rect().get_center());expect(float(scene.camera.zoom)>1,rid+" primary zoom controls delegate to local map")
  ui.map_view.house().fit_all();expect(float(scene.camera.zoom)==1 and scene.camera.pan==Vector2.ZERO,rid+" fit restores whole local floor")
  for name in["员工","招聘","研发","装修","宣传"]:
   ui.toggle_panel(name);await settle();expect(ui.panel_name=="跨国食肆"and ui.international_ui.selected==rid,rid+" "+name+" opens current shop management");ui.close_panel();await settle()
  ui.scene_switcher.manage("店铺");await settle();expect(control(ui,"int:move:table0")!=null,rid+" empty floor offers real furniture editing")
  var original=JSON.stringify(r.region(rid).floor.fixtures);control(ui,"int:move:table0").pressed.emit();await settle()
  expect(not scene.placement_uid.is_empty()and ui.model.paused and ui.panel_name.is_empty(),rid+" placement is a paused map preview with explicit return")
  ui.scene_switcher.cancel_move();expect(JSON.stringify(r.region(rid).floor.fixtures)==original and scene.placement_uid.is_empty(),rid+" cancel preserves furnishings")
  for dims in[Vector2i(390,844),Vector2i(844,390),Vector2i(360,740)]:
   root.size=dims;ui.update_ui_layout();ui.refresh();await settle();ui.refresh();await settle()
   expect(scene.size.x>200 and scene.size.y>100 and scene.get_global_rect().end.x<=ui.size.x+2,rid+" scene fits "+str(dims))
   for id in["scene:switch","scene:fit","scene:larger","scene:outside"]:
    var b=control(ui,id);expect(b!=null and b.size.y>=44 and b.get_global_rect().end.x<=ui.size.x+2,rid+" "+id+" touch target fits "+str(dims))
   var before=scene.to_world(scene.size*.5);scene.zoom_at(1.2,scene.size*.5);expect(before.is_equal_approx(scene.to_world(scene.size*.5)),rid+" zoom keeps fingers anchored")
  ui.scene_switcher.visit("main");await settle();expect(not is_instance_valid(ui.scene_switcher.view)and ui.map_view.house().camera==old_camera,rid+" main returns with its camera")
  ui.queue_free();await settle()
 print("Branch scene UI: "+JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty()else 1)
