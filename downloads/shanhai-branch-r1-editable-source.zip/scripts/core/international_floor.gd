extends RefCounted
## Authoritative local floor, sharing the main restaurant's visibility-graph navigation.
const Navigation=preload("res://scripts/services/grid_navigation.gd")
const WORLD=Vector2(1120,640)
const BOUNDS=Rect2(60,100,1000,520)
const ENTRY=Vector2(560,610)
const CASH_POINT=Vector2(950,440)
const ROLES={"rush":"host","ferment":"chef","stock":"cashier","spice":"chef","host":"host","verify":"host","oven":"chef","route":"host","night":"chef","layout":"host","batch":"chef","promise":"host","water":"host","grain":"chef","season":"chef"}
var _ref: WeakRef
func _init(rules):_ref=weakref(rules)
func r():return _ref.get_ref()
func m():return r().m()
func now() -> int:return r().now()
func state(rid: String) -> Dictionary:return r().region(rid).floor
static func pack(p: Vector2) -> Dictionary:return {"x":p.x,"y":p.y}
static func point(value: Dictionary) -> Vector2:return Vector2(float(value.get("x",0)),float(value.get("y",0)))
static func default_fixtures(layout="balanced") -> Array:
 var result=[];var positions=[Vector2(220,215),Vector2(455,215),Vector2(220,365),Vector2(455,365)]
 if layout=="sharing":positions=[Vector2(270,215),Vector2(270,365)]
 if layout=="service":positions=[Vector2(210,215),Vector2(430,215),Vector2(210,365)]
 if layout=="storage":positions=positions.slice(0,3)
 for index in range(positions.size()):result.append({"uid":"table"+str(index),"kind":"table","x":positions[index].x,"y":positions[index].y,"shared":layout=="sharing"})
 for item in[["hot","stove",780,180],["cold","prep",940,180],["pass","pass",780,320],["cashier","cashier",950,400]]:result.append({"uid":item[0],"kind":item[1],"x":item[2],"y":item[3]})
 if layout=="storage":result.append({"uid":"storage","kind":"storage","x":455,"y":365})
 return result
static func centre(item: Dictionary) -> Vector2:return Vector2(float(item.x),float(item.y))
static func fixture_rect(item: Dictionary) -> Rect2:
 var p=centre(item)
 if item.kind=="table":return Rect2(p-Vector2(76 if item.get("shared",false)else 56,32),Vector2(152 if item.get("shared",false)else 112,64))
 if item.kind=="storage":return Rect2(p-Vector2(55,38),Vector2(110,76))
 return Rect2(p-Vector2(55,65),Vector2(110,65))
static func obstacles(items: Array) -> Array:
 var walls=[Rect2(0,470,470,170),Rect2(660,470,460,170)]
 for item in items:walls.append(fixture_rect(item))
 return walls
func fixtures(rid: String) -> Array:return state(rid).fixtures
func by_uid(rid: String,uid: String) -> Dictionary:
 for item in fixtures(rid):
  if item.uid==uid:return item
 return {}
static func seats(items: Array) -> Array:
 var result=[]
 for item in items:
  if item.kind!="table":continue
  var p=centre(item)
  if item.get("shared",false):
   for signum in[-1,1]:result.append({"table":item.uid,"point":pack(p+Vector2(signum*35,-44)),"service":pack(p+Vector2(signum*115,-50)),"direction":"down"})
   for signum in[-1,1]:result.append({"table":item.uid,"point":pack(p+Vector2(signum*35,55)),"service":pack(p+Vector2(signum*115,80)),"direction":"up"})
  else:
   for signum in[-1,1]:result.append({"table":item.uid,"point":pack(p+Vector2(signum*80,12)),"service":pack(p+Vector2(signum*80,80)),"direction":"right"if signum<0 else"left"})
 return result
func guest(rid: String,id: int) -> Dictionary:
 for g in state(rid).guests:
  if int(g.id)==id:return g
 return {}
func seat_info(rid: String,index: int) -> Dictionary:
 var list=seats(fixtures(rid));return list[index]if index>=0 and index<list.size()else{}
func operation(rid: String,uid: String) -> Vector2:
 var item=by_uid(rid,uid)
 if item.is_empty():return Vector2(620,350)
 return centre(item)+Vector2(0,-85 if item.kind=="cashier"else 48 if item.kind in["stove","prep"]else 40 if item.kind=="pass"else 54)
func route(rid: String,start: Vector2,target: Vector2) -> Dictionary:
 return Navigation.find_path(start,target,obstacles(fixtures(rid)),BOUNDS,8)
func motion(rid: String,start: Vector2,target: Vector2,speed=160.0) -> Dictionary:
 var path=route(rid,start,target)
 if path.blocked:return {}
 return {"origin":pack(start),"target":pack(target),"points":path.points.map(func(p):return pack(p)),"started":now(),"travel_minutes":float(path.length)/speed,"speed":speed}
static func position(moving: Dictionary,at: float) -> Vector2:
 if moving.is_empty():return Vector2.ZERO
 var from=point(moving.origin);var points=moving.points.map(func(p):return point(p))
 return Navigation.advance(from,points,0,maxf(0,at-float(moving.started))*float(moving.speed)).position
static func arrived(moving: Dictionary,at: float) -> bool:return moving.is_empty()or at>=float(moving.started)+float(moving.travel_minutes)
func worker_role(id: String) -> String:
 if id.begins_with("helper:"):return id.trim_prefix("helper:")
 return str(ROLES.get(str(r().definition("characters",id).get("skill","")),"host"))
func _worker(id: String) -> Dictionary:
 var role=worker_role(id);var p=Vector2(810,235)if role=="chef"else Vector2(950,315)if role=="cashier"else Vector2(1030,350)if role=="builder"else Vector2(620,390)
 if not id.begins_with("helper:"):p.x+=int(r().definition("characters",id).get("column",0))*30
 return {"id":id,"role":role,"position":pack(p),"motion":{},"job":0,"action":"Idle","look":"down"}
func ensure(rid: String):
 var data=r().region(rid)
 if not data.has("accepting"):data.accepting=true
 if not data.has("marketing_until"):data.marketing_until=0
 if not data.has("training"):data.training={}
 if not data.has("mastery"):data.mastery={}
 if not data.get("floor")is Dictionary:data.floor={"version":1,"fixtures":default_fixtures(str(data.layout)),"workers":{},"guests":[],"history":[]}
 var f=state(rid)
 for role in["chef","host","cashier","builder"]:
  var id="helper:"+role
  if not f.workers.has(id):f.workers[id]=_worker(id)
 for id in data.partners:
  if not f.workers.has(str(id)):f.workers[str(id)]=_worker(str(id))
 # Migrate old waiting/handover orders without purchasing or paying again.
 for order in data.orders:
  if not guest(rid,int(order.id)).is_empty():continue
  var used=f.guests.map(func(g):return int(g.seat));var index=0
  while index in used:index+=1
  if index>=seats(f.fixtures).size():break
  var info=seat_info(rid,index);var legacy=str(order.status)in["waiting","serving"]
  var g={"id":int(order.id),"seat":index,"table":str(info.table),"stage":str(order.status)if legacy else"arriving","motion":{},"position":info.point.duplicate(),"until":0,"paid":false,"canceled":false,"queue_slot":-1}
  if not legacy:g.position=pack(ENTRY);g.motion=motion(rid,ENTRY,point(info.point))
  f.guests.append(g)
 for job in data.jobs:
  if not job.has("phase"):
   if job.kind=="service":job.legacy_handover=true
   job.phase="working";job.worker="";job.station="";job.work_minutes=maxi(1,int(job.due)-now());job.available=now()
func available_workers(rid: String,role: String) -> Array:
 var data=r().region(rid);var f=state(rid);var chosen=[]
 for id in data.partners:
  if worker_role(str(id))==role and int(data.rest.get(id,0))<=now():chosen.append(str(id))
 if chosen.is_empty()or role=="builder":chosen.append("helper:"+role)
 return chosen.filter(func(id):return int(f.workers[id].job)==0)
func queue(rid: String,job: Dictionary,role: String,station: String,work_minutes: int,available: int=-1):
 job.phase="queued";job.worker="";job.role=role;job.station=station;job.work_minutes=work_minutes;job.available=now()if available<0 else available;job.due=now()+work_minutes
 r().region(rid).jobs.append(job)
func station_for(dish: Dictionary) -> String:return "cold"if str(dish.station)in["cold","steamer","counter","pot"]else"hot"
func prepare(rid: String,job: Dictionary,total: int):
 var delay=int(r().config.settings.supplier_delay)
 queue(rid,job,"chef",station_for(r().definition("dishes",str(job.dish_id))),maxi(1,total-delay),now()+delay)
func service(rid: String,job: Dictionary,minutes: int):queue(rid,job,"host","pass",minutes)
func add_internal(rid: String,kind: String,g: Dictionary,role: String,station: String,minutes: int):
 if r().region(rid).jobs.any(func(j):return j.kind==kind and int(j.get("order_id",-1))==int(g.id)):return
 queue(rid,{"id":r()._serial(),"kind":kind,"order_id":int(g.id),"cost":0.0,"started":now(),"due":now()+minutes},role,station,minutes)
func ready_to_serve(rid: String,id: int) -> bool:
 var g=guest(rid,id);return not g.is_empty()and g.stage=="waiting"
func _job_target(rid: String,job: Dictionary) -> Vector2:
 if job.kind in["order","clean"]:
  var g=guest(rid,int(job.order_id));var info=seat_info(rid,int(g.get("seat",-1)))
  return point(info.get("service",pack(Vector2(620,350))))
 if job.kind=="training":return Vector2(1025,350)
 if job.kind=="marketing":return Vector2(560,530)
 if job.kind in["layout","upgrade","verify"]:return Vector2(1030,350)
 return operation(rid,str(job.station))
func _active_job(data: Dictionary,station: String) -> bool:
 return not station.is_empty()and data.jobs.any(func(j):return str(j.get("station",""))==station and str(j.get("phase",""))in["walking","working","delivery"])
func _assign(rid: String):
 var data=r().region(rid);var f=state(rid)
 for job in data.jobs:
  if str(job.phase)!="queued"or int(job.available)>now():continue
  if _active_job(data,str(job.station)):continue
  var candidates=available_workers(rid,str(job.role))
  if job.kind=="training":candidates=[str(job.character)]if int(f.workers[str(job.character)].job)==0 else[]
  if candidates.is_empty():continue
  var chosen="";var best={};var length=INF
  for id in candidates:
   var w=f.workers[id];var path=motion(rid,point(w.position),_job_target(rid,job),180+int(data.training.get(id,0))*15)
   if not path.is_empty()and float(path.travel_minutes)<length:chosen=id;best=path;length=float(path.travel_minutes)
  if chosen.is_empty():continue
  job.worker=chosen;job.phase="walking";job.started=now();job.due=now()+int(ceil(float(best.travel_minutes)))+int(job.work_minutes)
  var w=f.workers[chosen];w.job=int(job.id);w.motion=best;w.action="Move"
  if job.kind=="training":data.rest[chosen]=int(job.due)
func _history(rid: String,id: int,stage: String):
 var list=state(rid).history;list.append({"id":id,"stage":stage,"minute":now()})
 while list.size()>120:list.pop_front()
func tick(rid: String) -> bool:
 var data=r().region(rid);var f=state(rid);var changed=false
 for w in f.workers.values():
  if not w.motion.is_empty():
   w.position=pack(position(w.motion,now()))
   if int(w.job)==0 and arrived(w.motion,now()):w.motion={};w.action="Idle"
 for job in data.jobs:
  if not str(job.get("phase",""))in["walking","working","delivery"]:continue
  var w=f.workers.get(str(job.worker),{})
  if w.is_empty():continue
  if job.phase=="walking"and arrived(w.motion,now()):
   w.position=w.motion.target.duplicate();job.phase="working";w.action={"prep":"Cook","service":"Serve","checkout":"Cashier","order":"Order","clean":"Clean","training":"Train","research":"Cook","marketing":"Promote","layout":"Build","upgrade":"Build","verify":"Order"}.get(str(job.kind),"Idle");w.look="down"if job.kind=="checkout"else"up";changed=true
   if job.kind=="service":
    var g=guest(rid,int(job.order_id));var info=seat_info(rid,int(g.seat));w.motion=motion(rid,point(w.position),point(info.service));job.phase="delivery";w.action="Serve";job.due=now()+int(ceil(float(w.motion.get("travel_minutes",0))))+int(job.work_minutes)
 for g in f.guests.duplicate():
  if not g.motion.is_empty():g.position=pack(position(g.motion,now()))
  if g.stage=="arriving"and arrived(g.motion,now()):
   g.motion={};g.stage="ordering";var order=r().order(rid,int(g.id));order.status="ordering";_history(rid,int(g.id),"seated");add_internal(rid,"order",g,"host","table:"+str(g.table),2);changed=true
  elif g.stage=="eating"and now()>=int(g.until):
   var slot=0;var taken=f.guests.filter(func(x):return x.stage in["queue","paying"]).map(func(x):return int(x.queue_slot))
   while slot in taken:slot+=1
   g.queue_slot=slot;g.stage="queue";g.motion=motion(rid,point(g.position),cash_point(rid)-Vector2(slot*65,0));r().order(rid,int(g.id)).status="paying";_history(rid,int(g.id),"checkout_walk");changed=true
  elif g.stage=="queue"and arrived(g.motion,now())and not data.jobs.any(func(j):return j.kind=="checkout"):
   var ahead=f.guests.any(func(other):return int(other.id)<int(g.id)and other.stage in["queue","paying"])
   if ahead:continue
   if point(g.position).distance_to(cash_point(rid))>1:g.motion=motion(rid,point(g.position),cash_point(rid));changed=true
   else:g.stage="paying";g.motion={};add_internal(rid,"checkout",g,"cashier","cashier",3);changed=true
  elif g.stage=="leaving"and arrived(g.motion,now()):
   g.stage="cleaning";g.motion={};_history(rid,int(g.id),"departed")
   if bool(g.paid):add_internal(rid,"clean",g,"host","table:"+str(g.table),3)
   else:f.guests.erase(g)
   changed=true
 _assign(rid)
 return changed
func finish(rid: String,job: Dictionary) -> bool:
 var data=r().region(rid);var f=state(rid);var w=f.workers.get(str(job.get("worker","")),{})
 if not w.is_empty():
  if not w.motion.is_empty():w.position=w.motion.target.duplicate()
  w.motion={};w.job=0;w.action="Idle"
  var home=point(_worker(str(w.id)).position)
  if point(w.position).distance_to(home)>4:w.motion=motion(rid,point(w.position),home,180+int(data.training.get(str(w.id),0))*15);w.action="Move"
 match job.kind:
  "order":
   var g=guest(rid,int(job.order_id));var order=r().order(rid,int(job.order_id))
   if not g.is_empty()and not order.is_empty():g.stage="waiting";order.status="waiting";order.due=now()+int(r().config.settings.order_window)+(20 if data.story.choice in["limited","reserve"]else 0)+(15 if r().partner(rid,"promise")else 0);_history(rid,int(g.id),"ordered")
   return true
  "service":
   var g=guest(rid,int(job.order_id));var order=r().order(rid,int(job.order_id))
   if not g.is_empty()and not order.is_empty():g.stage="eating";g.until=now()+10;order.status="eating";order.meal_cost=float(job.cost);_history(rid,int(g.id),"served")
   return true
  "checkout":
   var order=r().order(rid,int(job.order_id));var g=guest(rid,int(job.order_id))
   if not order.is_empty()and not g.is_empty()and not bool(g.paid):
    r().recognize_payment(rid,order,float(order.get("meal_cost",0)));g.paid=true;g.stage="leaving";g.motion=motion(rid,point(g.position),ENTRY);_history(rid,int(g.id),"paid")
   return true
  "clean":
   var g=guest(rid,int(job.order_id));_history(rid,int(job.order_id),"cleaned");f.guests.erase(g);return true
  "training":data.training[str(job.character)]=int(data.training.get(str(job.character),0))+1;data.rest.erase(str(job.character));return true
  "research":data.mastery[str(job.dish_id)]=int(data.mastery.get(str(job.dish_id),0))+1;return true
  "marketing":data.marketing_until=now()+120;return true
 return false
func cancel_order(rid: String,id: int):
 var g=guest(rid,id)
 if not g.is_empty():g.canceled=true;g.stage="leaving";g.motion=motion(rid,point(g.position),ENTRY);_history(rid,id,"declined")
func spawn(rid: String,order: Dictionary) -> bool:
 var f=state(rid);var used=f.guests.map(func(g):return int(g.seat));var index=0
 while index in used:index+=1
 if index>=seats(f.fixtures).size():return false
 var info=seat_info(rid,index);var moving=motion(rid,ENTRY,point(info.point))
 if moving.is_empty():return false
 f.guests.append({"id":int(order.id),"seat":index,"table":str(info.table),"stage":"arriving","motion":moving,"position":pack(ENTRY),"until":0,"paid":false,"canceled":false,"queue_slot":-1});order.status="arriving";_history(rid,int(order.id),"entered");return true
func can_remodel(rid: String) -> bool:return state(rid).guests.is_empty()and r().region(rid).jobs.is_empty()and state(rid).workers.values().all(func(w):return arrived(w.motion,now()))
func apply_layout(rid: String):state(rid).fixtures=default_fixtures(str(r().region(rid).layout))
func worker_snapshot(rid: String,at: float) -> Array:
 var data=r().region(rid);var f=state(rid);var visible=[]
 for w in f.workers.values():
  var named=not str(w.id).begins_with("helper:");var active=str(w.id)in data.partners and int(data.rest.get(str(w.id),0))<=now()
  if str(w.id)=="helper:builder"and int(w.job)==0:continue
  if not named:active=available_workers(rid,str(w.role)).has(str(w.id))or int(w.job)>0
  if not active and int(w.job)==0:continue
  var snap=w.duplicate(true);snap.position=position(w.motion,at)if not w.motion.is_empty()else point(w.position)
  if not w.motion.is_empty()and not arrived(w.motion,at):snap.action="Move"if str(w.action)!="Serve"else"Serve"
  visible.append(snap)
 return visible
func cash_point(rid: String) -> Vector2:return centre(by_uid(rid,"cashier"))+Vector2(0,40)
func can_move(rid: String,uid: String,x,y) -> bool:
 if not m()._number(x)or not m()._number(y)or by_uid(rid,uid).is_empty():return false
 var items=fixtures(rid).duplicate(true)
 for item in items:
  if item.uid==uid:item.x=float(x);item.y=float(y)
 if not safe_layout(items):return false
 for w in worker_snapshot(rid,now()):
  if not Navigation.point_is_clear(w.position,obstacles(items),8):return false
 return true
static func safe_layout(items: Array) -> bool:
 if items.size()<5 or items.size()>9:return false
 var found={};var rects=[];var table_count=0
 for item in items:
  if not item is Dictionary or not item.get("uid")is String or not str(item.get("kind",""))in["stove","prep","pass","cashier","table","storage"]:return false
  if found.has(str(item.uid))or not item.get("x")is float and not item.get("x")is int or not item.get("y")is float and not item.get("y")is int:return false
  var fixed={"hot":"stove","cold":"prep","pass":"pass","cashier":"cashier","storage":"storage"}
  if fixed.has(str(item.uid)):
   if str(item.kind)!=str(fixed[str(item.uid)]):return false
  elif not str(item.uid)in["table0","table1","table2","table3"]or item.kind!="table"or not item.get("shared")is bool:return false
  var p=centre(item)
  if not is_finite(p.x)or not is_finite(p.y)or p.x<115 or p.x>1000 or p.y<165 or p.y>425:return false
  found[str(item.uid)]=true
  var rect=fixture_rect(item)
  for old in rects:
   if rect.grow(12).intersects(old):return false
  rects.append(rect)
  if item.kind=="table":table_count+=1
 if table_count<1 or table_count>4 or not found.has_all(["hot","cold","pass","cashier"]):return false
 var walls=obstacles(items);var targets=[]
 for seat in seats(items):targets.append(point(seat.point));targets.append(point(seat.service))
 for item in items:
  if item.kind in["stove","prep","pass","cashier"]:targets.append(centre(item)+Vector2(0,-85 if item.kind=="cashier"else 48 if item.kind in["stove","prep"]else 40))
 for target in targets:
  if Navigation.find_path(ENTRY,target,walls,BOUNDS,8).blocked:return false
 return true
func _valid_point(value) -> bool:
 return value is Dictionary and m()._number(value.get("x"))and m()._number(value.get("y"))and BOUNDS.grow(2).has_point(point(value))
func _valid_motion(value) -> bool:
 if not value is Dictionary:return false
 if value.is_empty():return true
 if not _valid_point(value.get("origin"))or not _valid_point(value.get("target"))or not value.get("points")is Array or value.points.size()>64:return false
 for p in value.points:
  if not _valid_point(p):return false
 for field in["started","travel_minutes","speed"]:
  if not m()._number(value.get(field))or float(value[field])<0:return false
 return float(value.speed)>0
func validate(rid: String,data: Dictionary) -> bool:
 var f=data.floor
 if not f is Dictionary or f.get("version")!=1 or not f.get("fixtures")is Array or not safe_layout(f.fixtures):return false
 if not f.get("workers")is Dictionary or not f.get("guests")is Array or not f.get("history")is Array or f.guests.size()>8 or f.history.size()>120:return false
 if not data.get("accepting")is bool or not m()._integer(data.get("marketing_until"),0):return false
 for field in["training","mastery"]:
  if not data.get(field)is Dictionary:return false
  for id in data[field]:
   var kind="characters"if field=="training"else"dishes"
   if r().definition(kind,str(id)).get("region","")!=rid or not m()._integer(data[field][id],0)or int(data[field][id])>3:return false
 var allowed=["helper:chef","helper:host","helper:cashier","helper:builder"]+r().definition("regions",rid).characters
 var jobs={}
 for job in data.jobs:
  jobs[int(job.id)]=job
  if not str(job.get("phase",""))in["queued","walking","working","delivery"]or not job.get("worker")is String or not m()._integer(job.get("work_minutes"),1)or not m()._integer(job.get("available"),0):return false
  if not str(job.worker).is_empty()and not str(job.worker)in allowed:return false
  if job.kind=="training"and not str(job.get("character",""))in r().definition("regions",rid).characters:return false
  if job.kind=="research"and not str(job.get("dish_id",""))in r().definition("regions",rid).dishes:return false
 for id in f.workers:
  var w=f.workers[id]
  if not id in allowed or not w is Dictionary or str(w.get("id",""))!=str(id)or not _valid_point(w.get("position"))or not _valid_motion(w.get("motion"))or not m()._integer(w.get("job"),0):return false
  if not str(w.get("role",""))in["chef","host","cashier","builder"]or not str(w.get("action",""))in["Idle","Move","Cook","Serve","Cashier","Order","Clean","Train","Promote","Build"]:return false
  if int(w.job)>0 and(not jobs.has(int(w.job))or str(jobs[int(w.job)].get("worker",""))!=str(id)):return false
 var ids={};var occupied={};var order_ids={}
 for order in data.orders:
  order_ids[int(order.id)]=true
  if order.has("meal_cost")and(not m()._number(order.meal_cost)or float(order.meal_cost)<0):return false
 for g in f.guests:
  if not g is Dictionary or not m()._integer(g.get("id"),0)or ids.has(int(g.id))or not m()._integer(g.get("seat"),0)or int(g.seat)>=seats(f.fixtures).size()or occupied.has(int(g.seat)):return false
  ids[int(g.id)]=true;occupied[int(g.seat)]=true
  if not str(g.get("stage",""))in["arriving","ordering","waiting","serving","eating","queue","paying","leaving","cleaning"]or not g.get("paid")is bool or not g.get("canceled")is bool or not _valid_point(g.get("position"))or not _valid_motion(g.get("motion")):return false
  if not m()._integer(g.get("until"),0)or not m()._integer(g.get("queue_slot"),-1):return false
  if not bool(g.paid)and not bool(g.canceled)and not order_ids.has(int(g.id)):return false
 for id in order_ids:
  if not ids.has(id):return false
 return true
