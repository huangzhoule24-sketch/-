extends RefCounted
## Switch a single campaign viewport without replacing the model, music or save slot.
const Scene=preload("res://scripts/ui/international_scene.gd")
var host
var view
var switch_button: Button
var outside_button: Button
var move_bar: HBoxContainer
var move_label: Label
var confirm_button: Button
var _move_resume=false
func _init(ui):host=ui
func ui():return host.ensure_international_ui()
func active() -> String:return str(host.model.state.get("international",{}).get("active_scene","main"))
func foreign() -> bool:return active()!="main"
func setup_controls():
 var house=host.map_view.house()
 if house.controls==null:return
 if switch_button==null:
  switch_button=ui().compact(host.button("场景",func():host.open_panel("场景切换"),false,"scene:switch"));switch_button.set_meta("l10n_managed_text",true);house.controls.add_child(switch_button);house.controls.move_child(switch_button,4)
  outside_button=ui().compact(host.button("店外",func():
   if is_instance_valid(view):view.inside=not view.inside;view.fit();refresh(),false,"scene:outside"));outside_button.set_meta("l10n_managed_text",true);house.controls.add_child(outside_button);house.controls.move_child(outside_button,5)
 switch_button.visible=bool(host.model.state.get("tutorial",{}).get("finished",false))
 switch_button.text=ui().t("场景","Shops");outside_button.visible=foreign();outside_button.text=ui().t("店外"if is_instance_valid(view)and view.inside else"店内","Outside"if is_instance_valid(view)and view.inside else"Inside")
func refresh():
 if host.map_view==null:return
 setup_controls()
 var rid=active()
 if is_instance_valid(view)and(view.rid!=rid or rid=="main"):
  cancel_move();view.cancel_gesture();view.queue_free();view=null
 if rid=="main":return
 if not is_instance_valid(view):
  view=Scene.new();view.name="LocalRestaurantFloor";view.setup(ui(),rid,true,true);host.map_view.add_child(view)
  move_bar=HBoxContainer.new();move_bar.visible=false;move_bar.add_theme_constant_override("separation",5);view.add_child(move_bar)
  move_label=host.label("",14);move_label.set_meta("l10n_managed_text",true);move_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL;move_bar.add_child(move_label)
  confirm_button=ui().compact(host.button("确认",confirm_move,true,"int:move:confirm"));confirm_button.set_meta("l10n_managed_text",true);move_bar.add_child(confirm_button)
  var cancel=ui().compact(host.button("取消",cancel_move,false,"int:move:cancel"));cancel.set_meta("l10n_managed_text",true);move_bar.add_child(cancel)
 var area=host.map_view.house().content_rect();view.position=area.position;view.size=area.size;move_bar.position=Vector2(4,maxf(0,area.size.y-50));move_bar.size.x=maxf(1,area.size.x-8)
 var rules=ui().rules();var data=rules.region(rid);var def=rules.definition("regions",rid)
 if host.restaurant_name_label!=null:host.restaurant_name_label.text=ui().name_of(def.shop)
 host.guest_label.text=ui().t("在店%d位 · %d座"%[data.floor.guests.filter(func(g):return g.stage!="cleaning").size(),rules.floor.seats(data.floor.fixtures).size()],"Guests%d · Seats%d"%[data.floor.guests.filter(func(g):return g.stage!="cleaning").size(),rules.floor.seats(data.floor.fixtures).size()])
 var names=[]
 for did in data.active_menu:
  var dish=rules.definition("dishes",str(did));names.append(ui().name_of(dish.name)+" ￥"+str(dish.price))
 host.menu_label.text=ui().t("本店菜单  ","Local menu  ")+" · ".join(names)
 host.placement_label.text=ui().t("%s · 已结账%d单 · 点击人物/设备管理 · 场景可回主店"%["接待新客"if data.accepting else"停接新客",data.served],"%s · Paid orders%d · Tap staff/stations · Shops returns home"%["Accepting"if data.accepting else"No new arrivals",data.served])
 host.stock_label.text=ui().t("本店成品%d份 · 待办%d单 · 集团资金共用"%[data.stock.reduce(func(sum,l):return sum+int(l.quantity),0),data.orders.size()],"Ready%d · Orders%d · Shared cash"%[data.stock.reduce(func(sum,l):return sum+int(l.quantity),0),data.orders.size()])
 if not host.quest_title.text.begins_with(ui().t("主店待办：","Main task: ")):host.quest_title.text=ui().t("主店待办：","Main task: ")+host.quest_title.text
 if not host.todo_button.text.begins_with(ui().t("主店·","Main · ")):host.todo_button.text=ui().t("主店·","Main · ")+host.todo_button.text
func render():
 var local=ui();local.text(host.modal_body,local.t("完成白泽六步引导后，支付合作筹备费即可开店。已开店铺可直接进入；切换保留各店任务与镜头，所有店共用时间、资金和存档。","Finish Baize’s six steps and pay the opening fee. Open shops can be entered directly. Switching keeps tasks and cameras; time, cash and saves are shared."),16)
 var home=local.card(local.t("山海主店 · 有间小馆","Main restaurant"))
 local.button(home,local.t("返回主店"if foreign()else"当前正在主店","Return to main"if foreign()else"Current restaurant"),func():visit("main"),"scene:visit:main",not foreign())
 for region in local.rules().config.regions:
  var rid=str(region.id);var data=local.rules().region(rid);var body=local.card(local.name_of(region.name)+" · "+local.name_of(region.shop))
  local.picture(body,load("res://assets/art/BranchFloors/"+rid+".png"),130)
  local.text(body,local.name_of(region.summary),15)
  if data.open:
   local.button(body,local.t("进入餐厅场景"if active()!=rid else"返回当前餐厅","Enter restaurant"if active()!=rid else"Return to current restaurant"),func():visit(rid),"scene:visit:"+rid,true)
  else:
   local.text(body,local.t("合作筹备费 ￥%d · 每日 ￥%d"%[region.opening_cost,region.daily_cost],"Opening%d · Daily%d"%[region.opening_cost,region.daily_cost]),15)
   local.button(body,local.t("查看邀请与开店条件","Invitation & opening"),func():manage("店铺",rid),"scene:invite:"+rid)
func visit(rid: String):
 cancel_move();var result=host.model.full_rules.perform("int_visit",{"region":rid})
 if not result.ok:host.show_notice(str(result.reason));return
 host.close_panel(true,true);host.map_view.house().cancel_gesture();host.refresh()
func manage(tab="店铺",rid=""):
 var local=ui();local.selected=active()if rid.is_empty()else rid;local.tab=tab;local.preview="";host.open_panel("跨国食肆",false)
func route_navigation(name: String) -> bool:
 if not foreign():return false
 if name in["员工","招聘"]:manage("伙伴");return true
 if name in["装修","简单布置","宣传"]:manage("店铺");return true
 if name in["菜单","研发","采购","食材采购"]:manage("菜单");return true
 return false
func begin_move(uid: String):
 var rid=ui().selected
 if not ui().rules().floor.can_remodel(rid):host.show_notice(ui().t("先停接新客并关闭循环备料，等客人离店、清台与工作完成。","Stop arrivals and recurring prep, then finish service, cleaning and work."));return
 if active()!=rid:
  var result=host.model.full_rules.perform("int_visit",{"region":rid})
  if not result.ok:return
 host.close_panel(true,true);host.refresh();_move_resume=not host.model.paused;host.model.set_paused(true)
 view.placement_uid=uid;view.placement_point=ui().rules().floor.centre(ui().rules().floor.by_uid(rid,uid));view.placement_valid=true;view.inside=true;move_bar.visible=true;update_placement()
func update_placement():
 if not is_instance_valid(view)or not is_instance_valid(move_bar):return
 move_label.text=ui().t("点击地面选位置 · 免费","Tap floor · Free")if view.placement_valid else ui().t("位置挡路，请重选","Blocked; choose again")
 confirm_button.disabled=not view.placement_valid
func confirm_move():
 if not is_instance_valid(view):return
 var result=host.model.full_rules.perform("int_move_fixture",{"region":view.rid,"uid":view.placement_uid,"x":view.placement_point.x,"y":view.placement_point.y})
 if not result.ok:host.show_notice(str(result.reason));return
 cancel_move()
func cancel_move():
 if not is_instance_valid(view)or view.placement_uid.is_empty():return
 view.placement_uid="";move_bar.visible=false;view.cancel_gesture();view.queue_redraw()
 var resume=_move_resume;_move_resume=false
 if resume:host.model.set_paused(false)
func snapshot() -> Dictionary:
 var result={"active":active()}
 if not is_instance_valid(view):return result
 var floor=ui().rules().floor;var at=view.clock();var data=ui().rules().region(view.rid)
 result.merge({"rect":host.phone_ui.rect(view),"inside":view.inside,"zoom":view.camera.zoom,"pan_x":view.camera.pan.x,"pan_y":view.camera.pan.y,"touches":view.touches.size(),"placement":view.placement_uid,"placement_valid":view.placement_valid,"clock":at,"renders":view._render_count,"workers":floor.worker_snapshot(view.rid,at),"guests":data.floor.guests.duplicate(true),"history":data.floor.history.duplicate(true)})
 return result
