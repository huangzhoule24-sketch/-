extends RefCounted
const Art=preload("res://scripts/services/international_art.gd")
const Scene=preload("res://scripts/ui/international_scene.gd")
var host
var selected="india"
var tab="店铺"
var catalog_region="all"
var exterior=false
var preview=""
var cameras={}
var map_widget
var status_label: Label
var live_labels=[]
var actions=[]
var signature=""
var rendering=false
var pending=false
var scroll_revision=0
func _init(ui):host=ui
func rules():return host.model.full_rules.international
func english() -> bool:return host.localization!=null and host.localization.language=="en"
func t(zh: String,en: String) -> String:return en if english()else zh
func name_of(value: Dictionary) -> String:return rules().label(value,english())
func text(parent: Node,value: String,size=16,color=Color("30493f")) -> Label:
	var node=host.label(value,size,color);node.set_meta("l10n_managed_text",true);node.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;parent.add_child(node);return node
func flow(parent: Node):return host.full_panels._flow(parent)
func card(title: String,detail=""):
	var panel=host.card();host.modal_body.add_child(panel);var body=host.column(8);panel.add_child(body);text(body,title,19,host.GREEN)
	if not detail.is_empty():text(body,detail)
	return body
func button(parent: Node,title: String,callback: Callable,id: String,primary=false) -> Button:
	var node=host.button(title,callback,primary,id);node.set_meta("l10n_managed_text",true);parent.add_child(node);return node
func compact(node: Button):
	node.set_meta("compact_local_navigation",true);node.custom_minimum_size=Vector2(52,44);node.add_theme_font_size_override("font_size",14)
	for state in["normal","hover","pressed","disabled"]:
		var skin=node.get_theme_stylebox(state).duplicate();skin.set_content_margin_all(5);node.add_theme_stylebox_override(state,skin)
	return node
func action(parent: Node,title: String,kind: String,args: Dictionary,primary=false) -> Button:
	args=args.duplicate(true);args.region=selected
	var suffix=str(args.get("id",args.get("order",args.get("choice",args.get("skill",args.get("layout",""))))))
	if args.has("quantity"):suffix+=":q"+str(args.quantity)
	if kind=="int_swap":suffix+=":order"+str(args.order)
	var node=button(parent,title,func():
		var result=host.model.full_rules.perform(kind,args)
		if not result.ok:host.show_notice(str(result.get("reason_en",result.reason))if english()else str(result.reason))
		refresh_page(kind!="int_open"),"int:"+kind+":"+suffix,primary)
	actions.append({"node":weakref(node),"kind":kind,"args":args})
	var check=rules().can(kind,args);node.disabled=not bool(check.ok);node.tooltip_text=str(check.get("reason_en",check.reason))if english()else str(check.reason)
	return node
func picture(parent: Node,texture: Texture2D,height=160,width=0):
	if texture==null:return
	var image=TextureRect.new();image.texture=texture;image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED;image.custom_minimum_size=Vector2(width,height);image.size_flags_horizontal=Control.SIZE_EXPAND_FILL;image.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;parent.add_child(image)
func select_region(id: String):selected=id;preview="";refresh_page(false)
func refresh_page(keep_scroll=true):
	if host.panel_name!="跨国食肆":return
	var scroll=host.modal_body.get_parent().scroll_vertical if keep_scroll else 0
	scroll_revision+=1
	host.open_panel("跨国食肆",false);host.modal_body.get_parent().set_deferred("scroll_vertical",scroll)
	_restore_scroll(scroll,scroll_revision)
func _restore_scroll(offset: int,revision: int):
	await host.get_tree().process_frame
	await host.get_tree().process_frame
	if host.panel_name=="跨国食肆"and revision==scroll_revision:host.modal_body.get_parent().scroll_vertical=offset
func _signature() -> String:
	var data=rules().region(selected)
	var orders=data.orders.map(func(o):return [o.id,o.status,o.dish_id])
	return JSON.stringify([selected,tab,data.open,data.served,data.missed,data.level,data.layout,data.accepting,data.training,data.mastery,data.partners,data.auto_service,data.auto_recipe,data.active_menu,data.stock.map(func(l):return[l.dish_id,l.quantity]),data.jobs.map(func(j):return j.id),orders,data.story,rules().s().letters.size(),english()])
func render():
	rendering=true;pending=false;live_labels=[];actions=[];map_widget=null;status_label=null
	var regions=host.row(6);host.modal_body.add_child(regions)
	for region in rules().config.regions:
		var id=str(region.id);compact(button(regions,name_of(region.name),func():select_region(id),"int:region:"+id,selected==id))
	var def=rules().definition("regions",selected);var data=rules().region(selected)
	text(host.modal_body,name_of(def.shop),19,host.GREEN)
	var tabs=host.row(5);host.modal_body.add_child(tabs)
	for pair in [["店铺","Eatery"],["菜单","Menu"],["伙伴","Partners"],["来信","Stories & letters"],["账目","Accounts"]]:
		var next=str(pair[0]);compact(button(tabs,t(pair[0],"Letters"if next=="来信"else pair[1]),func():tab=next;preview="";refresh_page(false),"int:tab:"+next,tab==next))
	status_label=text(host.modal_body,"",16,host.GREEN)
	if data.open:
		var controls=host.row(5);host.modal_body.add_child(controls)
		compact(button(controls,t("继续"if host.model.paused else"暂停","Continue"if host.model.paused else"Pause"),func():host.toggle_pause();refresh_page(),"int:time:pause",true))
		for speed in[1,2,4]:
			var rate=int(speed);compact(button(controls,str(rate)+"×",func():host.model.set_speed(rate),"int:time:"+str(rate)))
	match tab:
		"店铺":store_panel(def,data)
		"菜单":menu_panel()
		"伙伴":partners_panel()
		"来信":story_panel(data)
		"账目":accounts_panel(data)
	signature=_signature();rendering=false;poll()
func store_panel(def: Dictionary,data: Dictionary):
	var views=host.row(5);host.modal_body.add_child(views)
	compact(button(views,t("看店内"if exterior else"看店外","Inside"if exterior else"Outside"),func():exterior=not exterior;refresh_page(),"int:scene:toggle"))
	compact(button(views,t("全景","Fit"),func():if is_instance_valid(map_widget):map_widget.fit(),"int:scene:fit"))
	for pair in [["−",.85],["+",1.15]]:
		var factor=float(pair[1]);compact(button(views,str(pair[0]),func():if is_instance_valid(map_widget):map_widget.camera.zoom=clampf(float(map_widget.camera.zoom)*factor,.65,2.8),"int:scene:"+str(pair[0])))
	map_widget=Scene.new();map_widget.setup(self,selected,not exterior);map_widget.preview=preview;host.modal_body.add_child(map_widget)
	map_widget.custom_minimum_size.y=minf(330,maxf(220,host._layout_size.y*.36))if host.portrait_layout else 360
	text(host.modal_body,t("图内拖动或双指缩放，图外滑动列表；点击全景可恢复视角。","Drag or pinch inside the view; scroll outside it. Fit restores the view."),12,host.MUTED)
	if not data.open:
		var body=card(t("收到一封合作邀请","A cooperation invitation"),name_of(def.summary))
		text(body,name_of(def.origin),14,host.MUTED)
		text(body,t("先完成白泽六步引导，即可从主店资金中安排这家食肆。当地合作独立排程，收入、费用与存档共用主店记录。","After Baize’s six opening steps, fund this eatery from the main campaign. Local work is scheduled separately; cash, accounts and saves are shared."),14,host.MUTED)
		text(body,t("合作筹备费 ￥%.0f · 每日协作与场地费用 ￥%.0f"%[def.opening_cost,def.daily_cost],"Opening fee %.0f · Daily cooperation and premises %.0f"%[def.opening_cost,def.daily_cost]))
		action(body,t("接受邀请并开店","Accept and open"),"int_open",{},true)
		text(body,t("可先浏览全部伙伴、菜品和文化简介；阅读不会替你跳过经营进度。","Browse every partner, dish and cultural entry first; reading does not skip progression."),14,host.MUTED)
		return
	button(host.modal_body,t("进入此店场景","Enter this restaurant"),func():host.scene_switcher.visit(selected),"int:enter:"+selected,true)
	action(host.modal_body,t("停接新客"if data.accepting else"恢复接待新客","Stop arrivals"if data.accepting else"Resume arrivals"),"int_business",{"enabled":not data.accepting})
	text(host.modal_body,t("基础后厨、前厅与收银班组包含在合作及日常费用中；两位当班伙伴参与真实岗位工作。顾客会入座点单、用餐、走到收银台付款，离店后再清台。","The opening and daily fees include kitchen, service and cashier crews. Up to two partners join real roles. Guests order, dine, pay at the cashier and leave before tables are cleaned."),14,host.MUTED)
	action(host.modal_body,t("食街宣传 · ￥20 · 完成后持续120分钟","Market promotion ·20 ·120min after completion"),"int_marketing",{})
	text(host.modal_body,t("点击继续后与主店共用时钟。当地团队默认自动核对交付已备好的适配餐点，也可暂停后手动换单或出餐。","Continue shares the main clock. The local team automatically checks and hands over compatible prepared meals; pause to swap or serve manually."),14,host.MUTED)
	action(host.modal_body,t("自动核对交付：开启"if data.auto_service else"自动核对交付：关闭","Automatic checked service: ON"if data.auto_service else"Automatic checked service: OFF"),"int_auto",{"id":"service"})
	orders_panel(data)
	jobs_panel(data)
	var improvements=card(t("设备、桌席与伙伴合作","Equipment, layout and partner work"))
	action(improvements,t("停炉维护 / 工作台改进 · ￥%d"%(80+int(data.level)*40),"Equipment improvement · %d"%(80+int(data.level)*40)),"int_upgrade",{})
	var options=flow(improvements)
	for pair in [["balanced","日常小桌","Everyday tables"],["service","取餐与分流","Handover space"],["storage","储备与安静席","Storage & quiet seats"],["sharing","共享桌席","Shared tables"]]:
		var layout=str(pair[0]);button(options,t(pair[1],pair[2]),func():preview=layout;refresh_page(),"int:preview:"+layout,preview==layout)
	if not preview.is_empty():
		text(improvements,t("正在预览，尚未扣款；实际确认后占用12分钟。","Preview only; no payment yet. Confirmation takes12 game minutes."),14)
		action(improvements,t("确认本方案 · ￥45","Confirm layout ·45"),"int_layout",{"layout":preview})
		button(improvements,t("取消预览","Cancel preview"),func():preview="";refresh_page(),"int:preview:cancel")
	var fixtures=card(t("移动桌椅与设备","Move furniture and stations"),t("先停接新客并关闭循环备料，等客人离店、清台和当前工作结束。选择物件后点击地面预览，确认才生效；取消可返回。","Stop arrivals and recurring prep, then finish service, cleaning and work. Choose an item and tap the floor; only confirmation applies it. Cancel returns safely."))
	var moves=flow(fixtures)
	for item in rules().floor.fixtures(selected):
		var uid=str(item.uid);var labels={"table":["餐桌","Table"],"stove":["炉灶","Stove"],"prep":["备餐台","Prep"],"pass":["出餐台","Pass"],"cashier":["收银台","Cashier"],"storage":["储物柜","Storage"]};var pair=labels[item.kind]
		var move=button(moves,t(pair[0],pair[1])+" "+uid,func():host.scene_switcher.begin_move(uid),"int:move:"+uid);move.disabled=not rules().floor.can_remodel(selected)
	if selected=="india":action(improvements,t("迦楼罗：预约下一批加急 · ￥35","Garuda: reserve one rush batch ·35"),"int_skill",{"skill":"rush"})
	if selected=="nordic":action(improvements,t("拉塔托斯克：核实供货消息 · ￥8","Ratatoskr: verify supply report ·8"),"int_skill",{"skill":"verify"})
func orders_panel(data: Dictionary):
	var body=card(t("当前订单 · 用餐后到收银台结账","Current orders · payment at the cashier"))
	if data.orders.is_empty():text(body,t("下一位客人正在路上。可先准备一批已学会的菜。","The next guest is on the way. Prepare a learned dish first."));return
	for entry in data.orders:
		var oid=int(entry.id);var dish=rules().definition("dishes",entry.dish_id)
		var request={"standard":t("按已列用料","Declared recipe"),"no_milk":t("明确要求无乳","Explicitly no dairy"),"mild":t("明确要求低辣","Explicitly mild")}[str(entry.request)]
		var line=text(body,"",16);live_labels.append({"node":weakref(line),"kind":"order","id":oid})
		text(body,t("需要：","Request: ")+request,14,host.MUTED)
		var row=flow(body)
		action(row,t("核对并出餐","Confirm and serve"),"int_serve",{"order":oid},true)
		action(row,t("说明后婉拒（未收款）","Explain and decline (unpaid)"),"int_decline",{"order":oid})
		var alternatives=flow(body)
		for did in rules().definition("regions",selected).dishes:
			if did==entry.dish_id:continue
			var other=rules().definition("dishes",did)
			if rules().unlocked(selected,other):action(alternatives,t("协商换成：","Offer: ")+name_of(other.name),"int_swap",{"order":oid,"id":did})
func jobs_panel(data: Dictionary):
	var body=card(t("备料与正在进行的工作","Preparation and work in progress"))
	if data.jobs.is_empty():text(body,t("当前没有进行中的工作。","No work in progress."))
	for job in data.jobs:
		var line=text(body,"",15);live_labels.append({"node":weakref(line),"kind":"job","id":int(job.id)})
func menu_panel():
	text(host.modal_body,t("采购费转为在制/成品价值，售出时再结转耗用。游戏时间压缩不等于现实烹饪时长；菜牌只承诺本店已列配方。","Purchases become work-in-progress/prepared stock, then cost of sales at checkout. Compressed game time is not real cooking time. The menu commits to the declared house recipe."),14,host.MUTED)
	for did in rules().definition("regions",selected).dishes:
		var dish=rules().definition("dishes",did);var body=card(name_of(dish.name),name_of(dish.origin))
		picture(body,Art.dish(did),100)
		text(body,name_of(dish.ingredients),16)
		text(body,t("本店明确含有：","Declared ingredients/tags: ")+tag_names(dish.contains),14,host.MUTED)
		text(body,t("可接需求：","Supported requests: ")+tag_names(dish.suits),14,host.MUTED)
		text(body,t("售价 ￥%.2f · 已备好%d份 · 学习条件：本店交付%d单"%[dish.price,rules().ready(selected,did),dish.unlock_orders],"Price %.2f · Ready%d · Learn after%d local orders"%[dish.price,rules().ready(selected,did),dish.unlock_orders]))
		body.add_child(host.culture_button("dishes",did))
		action(body,t("暂时下架"if did in rules().region(selected).active_menu else"加入在售菜单","Remove from sale"if did in rules().region(selected).active_menu else"List on menu"),"int_menu",{"id":did})
		var options=flow(body)
		for quantity in[1,3]:
			var q=int(quantity);var quote=rules().prep_quote(selected,dish,q)
			action(options,t("采购并备料×%d · ￥%.2f · %d分钟"%[q,quote.cost,quote.minutes],"Buy & prepare%d · %.2f · %dmin"%[q,quote.cost,quote.minutes]),"int_prepare",{"id":did,"quantity":q},true)
		text(body,t("配方改良 %d/3：每级缩短1分钟备餐，不改变已承诺用料。"%int(rules().region(selected).mastery.get(did,0)),"Recipe refinement %d/3: -1 prep minute per level; declared ingredients stay the same."%int(rules().region(selected).mastery.get(did,0))),14)
		action(body,t("改良这道配方 · ￥25 · 20分钟","Refine recipe ·25 ·20min"),"int_research",{"id":did})
		action(body,t("停止本菜循环备料"if rules().region(selected).auto_recipe==did else"设为循环备料（现金保底200）","Stop recurring preparation"if rules().region(selected).auto_recipe==did else"Repeat this recipe (cash floor200)"),"int_auto",{"id":did})
	jobs_panel(rules().region(selected))
	text(host.modal_body,t("循环备料须主动开启；每批照常采购扣款，并保留主店现金至少200。自动交付也会检查订单实际用料需求，不能把含乳餐点交给明确要求无乳的客人。","Recurring preparation is opt-in, pays for each batch and keeps shared cash at least200. Automatic handover still checks the actual recipe against the order’s declared needs."),14,host.MUTED)
func partners_panel():
	text(host.modal_body,t("同时安排两位当地伙伴，工作与合作能力有明确限制。可随时阅读全部小传；更多伙伴随真实订单进展结缘。","Assign two local partners at a time, with explicit work limits. All cultural stories are readable; more collaborations follow actual local orders."),14,host.MUTED)
	for cid in rules().definition("regions",selected).characters:
		var entry=rules().definition("characters",cid);var body=card(name_of(entry.name)+" · "+name_of(entry.role))
		picture(body,Art.character(cid),200)
		text(body,name_of(entry.skill_name)+"："+name_of(entry.skill_description))
		text(body,t("结缘条件：本店已交付%d/%d单"%[rules().region(selected).served,entry.unlock_orders],"Cooperation: %d/%d local orders"%[rules().region(selected).served,entry.unlock_orders]),14,host.MUTED)
		body.add_child(host.culture_button("employees",cid))
		text(body,t("岗位进修 %d/3；每级提升实际行走效率。培训期间由基础班组补岗。"%int(rules().region(selected).training.get(cid,0)),"Role training %d/3; each level improves actual walking speed. The base crew covers the role during training."%int(rules().region(selected).training.get(cid,0))),14)
		action(body,t("安排岗位培训 · ￥30 · 30分钟","Train partner ·30 ·30min"),"int_train",{"id":cid})
		action(body,t("结束本次当班合作"if cid in rules().region(selected).partners else"安排当班合作","Release partner slot"if cid in rules().region(selected).partners else"Assign partner"),"int_partner",{"id":cid})
func story_panel(data: Dictionary):
	var titles={"india":t("一张早餐单，三种安排","One breakfast order, three arrangements"),"nordic":t("船晚一天，店还要开","The ship is late; the eatery still opens"),"greece":t("一张长桌，不止一种吃法","One long table, more than one way to dine")}
	var opening={"india":t("当地伙伴约你参加食街早餐日。发酵、蒸位与煎板都有限，客人会提出各自的要求。你们决定先怎样安排？","The partners invite you to the market breakfast day. Fermentation and cooking stations are limited; guests have individual requests. How will you organise reception?"),"nordic":t("港口传来船期变动。拉塔托斯克提醒你区分传闻与核实消息，斯卡蒂正在查看天气。今天怎样继续接待？","A ship schedule changes. Ratatoskr separates reports from verified news; Skadi checks the weather. How will today’s service continue?"),"greece":t("一批客人准备相聚，也有人希望独立用餐。赫斯提亚要先排炉，阿拉克涅等你确定桌席。怎样开这场晚餐？","Some guests plan to share; others prefer individual meals. Hestia needs oven rounds and Arachne needs the seating plan. How will dinner be served?")}
	var body=card(titles[selected],opening[selected])
	var choices={"india":[["limited","限制预约：接单容量1，等待窗口延长20分钟","Limited bookings: one order, +20min window"],["extra","增加准备班次：费用35，每日额外费用10","Extra preparation shift:35 now, +10 daily"],["alternative","优先已确认的植物性餐点","Prioritise confirmed plant-based dishes"]],"nordic":[["stocks","缩短菜单：优先库存已有的餐点","Short menu: prioritise ready stock"],["rush","支付35，预约下一批加急采购","Pay35 for the next rush preparation"],["reserve","分时预约：接单较慢，等待窗口延长20分钟","Timed bookings: fewer arrivals, +20min window"]],"greece":[["shared","共享晚餐：每单两份，交接增加2分钟","Shared meal: two portions, +2min handover"],["separate","独立分餐：每单一份","Individual meals: one portion per order"],["mixed","混合安排：交替接单，部分两份","Mixed service: some orders need two portions"]]}
	for choice in choices[selected]:action(body,t(choice[1],choice[2]),"int_story",{"choice":str(choice[0])})
	text(body,t("确定后需实际完成3笔当地订单才收到回信；未交付、取消与超时会写入本次反馈。","Fulfil3 actual local orders after choosing to receive a reply. Missed, declined and late orders appear in the feedback."),14,host.MUTED)
	for letter in rules().s().letters:
		if str(letter.region)!=selected:continue
		var reply=card(t("来信：这一次，我们这样开门","A letter: how we opened this time"))
		var chosen=str(letter.choice)
		for item in choices[selected]:
			if item[0]==chosen:chosen=t(item[1],item[2]);break
		text(reply,t("你选择了「%s」。"%chosen,"Your plan: %s."%chosen))
		text(reply,name_of(rules().letter_body(letter)))
func accounts_panel(data: Dictionary):
	var body=card(t("当地食肆经营记录","Local eatery accounts"))
	text(body,t("营业额 ￥%.2f · 累计已付/已记费用与采购 ￥%.2f · 待付 ￥%.2f"%[data.revenue,data.costs,data.arrears],"Sales %.2f · Recorded costs and purchases %.2f · Arrears %.2f"%[data.revenue,data.costs,data.arrears]))
	text(body,t("采购不是当场利润损失：备料和成品仍是存货；结账时才结转耗用。筹备、改装、装盘与每日合作费用分别记入总账，结清已记欠费不会重复记费用。","A purchase is not an immediate profit loss: preparation and ready meals remain inventory until checkout. Setup, improvements, service and daily cooperation are recorded separately; paying an already-recorded arrear does not book it twice."),14,host.MUTED)
	action(body,t("结清本店待付费用","Settle local arrears"),"int_arrears",{})
	for row in data.log.slice(-20):text(body,"%d · %s · %+.2f"%[int(row.minute),str(row.get("text_en","Local transaction"))if english()else str(row.text),float(row.amount)],14)
	button(body,t("查看全店账单与资金流水","Open shared bills and cash flow"),func():host.open_panel("账单"),"full:open:账单")
func tag_names(tags: Array) -> String:
	var labels={"milk":["乳","milk"],"egg":["蛋","egg"],"gluten":["含麸质谷物","gluten cereals"],"fish":["鱼","fish"],"chicken":["鸡肉","chicken"],"beef":["牛肉","beef"],"pork":["猪肉","pork"],"lamb":["羊肉","lamb"],"honey":["蜂蜜","honey"],"vegan":["植物性配方","plant-based"],"vegetarian":["素食配方（详见用料）","vegetarian; see recipe"],"mild":["已确认低辣调整","confirmed mild version"]}
	var result=[]
	for id in tags:
		var pair=labels.get(str(id),[str(id),str(id)]);result.append(t(pair[0],pair[1]))
	return " · ".join(result)if not result.is_empty()else t("基础配方未列此类项；请查看完整用料","None of these tags listed; see the full ingredients")
func catalog(kind: String):
	var regions=flow(host.modal_body)
	for pair in [["all","全部","All"],["india","印度","India"],["nordic","北欧","Nordic"],["greece","希腊","Greece"]]:
		var rid=str(pair[0]);button(regions,t(pair[1],pair[2]),func():catalog_region=rid;host.open_panel("图鉴",false),"int:catalog:"+rid,catalog_region==rid)
	for entry in rules().config[kind]:
		if catalog_region!="all"and str(entry.region)!=catalog_region:continue
		var body=card(name_of(entry.name)+" · "+name_of(rules().definition("regions",entry.region).name))
		picture(body,Art.character(entry.id)if kind=="characters"else Art.dish(entry.id),180 if kind=="characters"else 100)
		text(body,name_of(entry.skill_description)if kind=="characters"else name_of(entry.ingredients))
		body.add_child(host.culture_button("employees"if kind=="characters"else"dishes",entry.id))
	button(host.modal_body,t("前往跨国食肆","Visit international eateries"),func():host.open_panel("跨国食肆"),"full:open:跨国食肆",true)
func poll():
	if rendering or host.panel_name!="跨国食肆":return
	var data=rules().region(selected);var fresh=_signature()
	var scrolling=host._touch_scrolling!=null and host._touch_scrolling.dragging
	if fresh!=signature and not pending and not scrolling and not(is_instance_valid(map_widget)and(map_widget.dragging or not map_widget.touches.is_empty())):
		pending=true;host.call_deferred("_refresh_international")
	if is_instance_valid(status_label):
		status_label.text=t("%s · 交付%d · 待办%d · ￥%.2f"%["暂停"if host.model.paused else"营业中",data.served,data.orders.size(),host.model.state.cash],"%s · Served%d · Orders%d · %.2f"%["Paused"if host.model.paused else"Open",data.served,data.orders.size(),host.model.state.cash])
		if selected=="nordic":
			var next=str(rules().snapshot().regions[selected].next_weather)
			var names={"clear":["正常到货","Normal supply"],"wind":["风路延误","Wind delay"],"rain":["雨天延误","Rain delay"],"unverified":["待核实","Unverified"]}
			var current=names[rules().weather(selected)];var forecast=names[next]
			status_label.text+=t(" · 天气："," · Weather: ")+t(current[0],current[1])+t(" · 后续消息："," · Next report: ")+t(forecast[0],forecast[1])
	for entry in live_labels:
		var node=entry.node.get_ref()
		if not is_instance_valid(node):continue
		if entry.kind=="order":
			var item=rules().order(selected,int(entry.id))
			if not item.is_empty():
				var stages={"arriving":["入店就座","Arriving"],"ordering":["点单中","Ordering"],"waiting":["候餐","Waiting"],"serving":["送餐中","Serving"],"eating":["用餐中","Dining"],"paying":["前往收银/结账","Checkout"]};var label=stages.get(str(item.status),[str(item.status),str(item.status)])
				node.text=name_of(rules().definition("dishes",item.dish_id).name)+" ×"+str(item.quantity)+" · "+t(label[0],label[1])+(t(" · 剩余%d分钟"%maxi(0,int(item.due)-rules().now())," · %dmin"%maxi(0,int(item.due)-rules().now()))if item.status=="waiting"else"")
		else:
			for job in data.jobs:
				if int(job.id)!=int(entry.id):continue
				var title=name_of(rules().definition("dishes",str(job.get("dish_id",""))).get("name",{}))if job.kind in["prep","service"]else t({"upgrade":"炉具维护","layout":"桌席调整","verify":"核实供货消息","order":"前厅点单","checkout":"收银结账","clean":"离店清台","training":"岗位培训","research":"配方改良","marketing":"食街宣传"}.get(str(job.kind),"工作中"),{"upgrade":"Equipment maintenance","layout":"Layout adjustment","verify":"Supply verification","order":"Taking order","checkout":"Checkout","clean":"Cleaning","training":"Training","research":"Recipe refinement","marketing":"Promotion"}.get(str(job.kind),"Work"))
				var phases={"queued":["等待供货/岗位","Waiting supply/crew"],"walking":["前往岗位","Walking"],"working":["工作中","Working"],"delivery":["实际送餐","Delivering"]};var phase=phases.get(str(job.get("phase","working")),["工作中","Working"])
				node.text=title+" · "+t(phase[0],phase[1])+(""if str(job.get("phase",""))=="queued"else t(" · 预计%d分钟"%maxi(0,int(job.due)-rules().now())," · ~%dmin"%maxi(0,int(job.due)-rules().now())))
	for entry in actions:
		var node=entry.node.get_ref()
		if not is_instance_valid(node):continue
		var check=rules().can(entry.kind,entry.args);node.disabled=not check.ok;node.tooltip_text=str(check.get("reason_en",check.reason))if english()else str(check.reason)
