extends RefCounted

## Full-game controls share the existing compact, scrollable main window.
## This class only renders and submits actions; rules remain in the model.
const GREEN = Color("427b6c")
const MUTED = Color("869088")
const WARNING = Color("a26c40")
const Rarity = preload("res://scripts/ui/rarity_display.gd")
const ATTRIBUTES = {"cooking": "厨艺", "speed": "速度", "charm": "魅力", "endurance": "耐力", "eloquence": "口才", "creativity": "创意", "calculation": "算力"}
const PERIODS = {"breakfast": "早市", "rest": "休息时段", "lunch": "午市", "tea": "下午茶", "dinner": "晚市", "night_market": "夜市"}
const MORE_SECTIONS = [
	["日常经营", ["主线故事", "经营升级", "库存供应", "采购设置", "菜单定价", "宣传营销", "招聘", "员工培养", "账单"]],
	["拓展经营", ["会员外卖", "连锁经营", "山海探索", "三界集团"]],
	["山海档案", ["事件", "事件图鉴", "羁绊图鉴", "相生相克", "员工支线", "世界排行榜", "顾客反馈", "待办汇总", "封锁对抗", "营业日志", "说明"]]
]
const STAGE_DEFAULTS = [
	{"name": "路边小馆", "revenue": 0, "reputation": 20, "staff": 3, "tables": 4, "rent": 60, "features": "招聘、训练、宣传和简单布置"},
	{"name": "街角饭店", "revenue": 4000, "reputation": 100, "staff": 5, "tables": 8, "rent": 120, "features": "正式研发、手动定价、员工技能和装修"},
	{"name": "区域名店", "revenue": 20000, "reputation": 500, "staff": 8, "tables": 12, "rent": 260, "features": "会员、外卖、营销活动和羁绊组合"},
	{"name": "城市连锁", "revenue": 100000, "reputation": 2000, "staff": 12, "tables": 12, "rent": 600, "features": "三家分店、中央厨房、供应链和山海探索"},
	{"name": "三界餐饮集团", "revenue": 500000, "reputation": 10000, "staff": 20, "tables": 12, "rent": 1500, "features": "跨三界分店、神兽觉醒、厨神大赛和本地榜单"}
]

var host
var model
var catalog_tab: String = "员工"
var stages: Array = STAGE_DEFAULTS.duplicate(true)
var _confirm_upgrade: bool = false
var _snapshot_cache: Dictionary = {}
var _researcher_id: String = ""
var more_query=""
var more_search: LineEdit

func _init(ui) -> void:
	host = ui
	model = ui.model

func render(name: String) -> bool:
	if str(model.state.get("mode", "normal")) != "full": return false
	_refresh_stages()
	_snapshot_cache = _snapshot()
	match name:
		"更多": more_panel()
		"员工": employee_panel()
		"招聘": employee_panel(true)
		"员工培养": training_panel()
		"研发", "配方研发": research_panel()
		"菜单", "菜单定价": menu_panel()
		"库存供应": stock_panel()
		"任务", "经营升级": growth_panel()
		"宣传", "宣传营销": marketing_panel()
		"会员外卖": membership_panel()
		"会员计划": membership_panel("member")
		"外卖服务": membership_panel("delivery")
		"连锁经营": expansion_panel()
		"分店管理": expansion_panel("branches")
		"中央厨房": expansion_panel("central")
		"供应链": expansion_panel("supply")
		"山海探索": exploration_panel()
		"三界集团": group_panel()
		"厨神大赛": group_panel("contest")
		"神兽觉醒": group_panel("awaken")
		"世界排行榜": group_panel("ranking")
		"事件图鉴": event_catalog_panel()
		"羁绊图鉴": bond_catalog_panel()
		"封锁对抗": blockade_panel()
		"图鉴": catalog_panel()
		_: return false
	return true

func _refresh_stages() -> void:
	stages = STAGE_DEFAULTS.duplicate(true)
	var names: Array = model.full_rules.config.get("stage_names", []) if "full_rules" in model and model.full_rules != null else []
	for index in range(stages.size()):
		if index < names.size(): stages[index]["name"] = str(names[index])
		for pair in [["revenue", "revenue"], ["reputation", "reputation"], ["staff", "employee_limit"], ["tables", "tables"], ["rent", "rent"]]:
			var key = "stage.%d.%s" % [index, str(pair[1])]
			stages[index][str(pair[0])] = model.balance.get(key, stages[index][str(pair[0])])
		if "full_rules" in model and model.full_rules != null:
			var table_limits: Array = model.full_rules.config.get("stage", {}).get("table_limits", [])
			if index < table_limits.size(): stages[index]["tables"] = int(table_limits[index])

func _snapshot() -> Dictionary:
	if "full_rules" in model and model.full_rules != null and model.full_rules.has_method("snapshot"):
		var result = model.full_rules.snapshot()
		if result is Dictionary: return result
	return {}

func _section(id: String) -> Dictionary:
	var value = _snapshot_cache.get(id, _snapshot_cache)
	return value if value is Dictionary else {}

func _can(action: String, args: Dictionary = {}) -> Dictionary:
	if "full_rules" in model and model.full_rules != null and model.full_rules.has_method("can_perform"):
		var result = model.full_rules.can_perform(action, args)
		if result is Dictionary:
			if not bool(result.get("ok", true)) and str(result.get("reason", "")).is_empty():
				result = result.duplicate()
				result["reason"] = str(result.get("message", "当前条件不足"))
			return result
		if result is bool: return {"ok": result, "reason": "当前条件不足" if not result else ""}
	return {"ok": true, "reason": ""}

func _perform(action: String, args: Dictionary = {}, destination: String = "", resume: bool = false) -> void:
	if not "full_rules" in model or model.full_rules == null:
		host.show_notice("完整经营规则尚未初始化")
		return
	var before_price = float(model._dish(str(args.get("dish_id",args.get("id","")))).get("price",0))
	var result = model.full_rules.perform(action, args)
	var okay = bool(result.get("ok", false)) if result is Dictionary else bool(result)
	if "audio" in host and host.audio != null:
		if not okay: host.audio.play_cue("ui.error")
		elif action == "claim": host.audio.play_cue("event.quest")
	if result is Dictionary:
		var message = str(result.get("message", result.get("reason", "")))
		if not message.is_empty(): host.show_notice(message)
	if okay:
		if action == "upgrade": _confirm_upgrade = false
		if "action_notifications" in host and host.action_notifications != null: host.action_notifications.complete_action(action,args)
		if "tutorial_overlay" in host and host.tutorial_overlay != null and (action != "set_price" or not is_equal_approx(before_price,float(args.get("price",before_price)))): host.tutorial_overlay.observe(action,args)
		if model.has_signal("autosave_requested"): model.autosave_requested.emit()
	if okay and resume:
		host.close_panel()
	elif not destination.is_empty():
		host.open_panel(destination)
	else:
		host.open_panel(str(host.panel_name))

func _action(parent: Node, text: String, action: String, args: Dictionary = {}, destination: String = "", primary: bool = false, resume: bool = false, forced_reason: String = "") -> Button:
	var check = _can(action, args)
	var reason = forced_reason if not forced_reason.is_empty() else str(check.get("reason", "")) if not bool(check.get("ok", true)) else ""
	var control: Button = host.button(text, func(): _perform(action, args, destination, resume), primary, _action_id(action, args))
	control.set_meta("full_action", action)
	control.set_meta("full_args", args.duplicate(true))
	control.disabled = not reason.is_empty() or not bool(check.get("ok", true))
	control.tooltip_text = reason
	parent.add_child(control)
	if not reason.is_empty():
		var hint: Label = host.label(reason, 12, WARNING)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		parent.add_child(hint)
	return control

func _action_id(action: String, args: Dictionary) -> String:
	var parts: Array[String] = ["full", action]
	for key in ["id", "employee_id", "dish_id", "kind", "role", "attribute", "method", "quantity", "enabled", "period", "strategy", "location"]:
		if key == "employee_id" and action in ["research", "tutorial_research"]: continue
		if args.has(key): parts.append(str(args[key]))
	return ":".join(parts)

func _body(title: String, detail: String = "") -> VBoxContainer:
	var panel: PanelContainer = host.card()
	host.modal_body.add_child(panel)
	var result: VBoxContainer = host.column(8)
	panel.add_child(result)
	var heading: Label = host.label(title, 19)
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	result.add_child(heading)
	if not detail.is_empty():
		var description: Label = host.label(detail, 14, MUTED)
		description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		result.add_child(description)
	return result

func _flow(parent: Node) -> HFlowContainer:
	var result = HFlowContainer.new()
	result.add_theme_constant_override("h_separation", 8)
	result.add_theme_constant_override("v_separation", 8)
	parent.add_child(result)
	return result

func _shortcut(parent: Node, text: String, destination: String, primary: bool = false) -> void:
	parent.add_child(host.button(text, func(): host.open_panel(destination), primary, "full:open:" + destination))

func _text(parent: Node, text: String, color: Color = MUTED, size: int = 16) -> Label:
	var result: Label = host.label(text, size, color)
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(result)
	return result

func _identity(body: VBoxContainer, employee: Dictionary) -> void:
	if body.get_parent() is PanelContainer: Rarity.apply_border(body.get_parent(), str(employee.get("rarity", "N")))
	var identity = host.row(12)
	body.add_child(identity)
	body.move_child(identity, 1)
	var portrait = preload("res://scripts/ui/portrait_frame.gd").add_to(host,identity,employee,false)
	portrait.full_body = host.panel_name == "员工详情"
	var badge=Rarity.create_badge(str(employee.get("rarity", "N")), false, host.assets);badge.size_flags_vertical=Control.SIZE_SHRINK_CENTER;identity.add_child(badge)
	var culture=host.culture_button("employees", str(employee.id));culture.size_flags_vertical=Control.SIZE_SHRINK_CENTER;identity.add_child(culture)

func _portrait_texture(id: String) -> Texture2D:
	if not "assets" in host or host.assets == null: return null
	# Use the same Idle paths as restaurant animation, including numbered frames.
	# The short ID remains a fallback for earlier custom-asset packs.
	for texture in host.assets.get_frames(id, "idle"):
		if not host.assets.is_placeholder(texture): return texture
	var legacy_id = "Characters/" + id
	return host.assets.get_texture(legacy_id) if host.assets.has_image(legacy_id) else null

func _role_name(role: String) -> String:
	return "培训/研发" if role.to_lower() == "tutor" else str(host.role_name(role.to_lower()))

func _recruit_check(kind: String) -> Dictionary:
	var check = _can("recruit", {"kind": kind})
	if not bool(check.get("ok", true)):
		if str(check.get("reason", "")).is_empty(): check["reason"] = "当前无法招聘，请检查资源与契约"
		return check
	if kind == "contract":
		return {"ok": not model.state.get("contracts", []).is_empty(), "reason": "完成成长目标可获得指定伙伴契约" if model.state.get("contracts", []).is_empty() else ""}
	return check

func _stage_reason(required: int) -> String:
	return "需要阶段 %d · %s" % [required, str(stages[required].name)] if int(model.state.stage) < required else ""

func more_panel() -> void:
	host.paragraph("按分类选择管理内容，也可以搜索功能名称。", MUTED)
	var search_row=host.row(8);host.modal_body.add_child(search_row)
	more_search=LineEdit.new();more_search.placeholder_text="搜索功能…";more_search.text=more_query;more_search.custom_minimum_size=Vector2(100,44);more_search.size_flags_horizontal=Control.SIZE_EXPAND_FILL;more_search.set_meta("qa_id","more:search");search_row.add_child(more_search)
	for state in ["normal","focus"]:
		var skin=host.style(Color("faf9f3"),0,host.GREEN if state=="focus"else host.BORDER);skin.content_margin_left=10;skin.content_margin_right=10;skin.content_margin_top=8;skin.content_margin_bottom=8;more_search.add_theme_stylebox_override(state,skin)
	more_search.add_theme_font_size_override("font_size",16);more_search.add_theme_color_override("font_color",host.INK);more_search.add_theme_color_override("font_placeholder_color",MUTED);more_search.add_theme_color_override("caret_color",host.INK)
	var clear=host.button("清空",func():more_search.text="";more_search.text_changed.emit(""),false,"more:clear");search_row.add_child(clear)
	var count_label=host.label("",14,MUTED);count_label.set_meta("l10n_managed_text",true);host.modal_body.add_child(count_label)
	var no_results=host.label("当前阶段没有匹配的功能，试试其他关键词。",16,MUTED);no_results.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;host.modal_body.add_child(no_results)
	var groups: Dictionary = {}
	var sections: Dictionary={}
	for entry in host.Policy.more_entries(int(model.state.stage)):
		var group = str(entry.group)
		if not groups.has(group):
			var body=_body(group);sections[group]=body.get_parent();groups[group]=_flow(body)
		_shortcut(groups[group],str(entry.label),str(entry.panel))
	var filter=func(text: String):
		more_query=text
		var matched=0;var total=0
		for group in groups:
			var visible_count=0
			for button in groups[group].get_children():
				total+=1
				var source=str(button.get_meta("l10n_source",button.text));var translated=host.localization.translate(source)if host.localization!=null else source
				button.visible=text.strip_edges().is_empty()or source.to_lower().contains(text.strip_edges().to_lower())or translated.to_lower().contains(text.strip_edges().to_lower())
				if button.visible:matched+=1;visible_count+=1
			sections[group].visible=visible_count>0
		clear.disabled=text.is_empty()
		no_results.visible=matched==0
		count_label.text=("%d / %d functions"if host.localization!=null and host.localization.language=="en"else"显示%d / %d项功能")%[matched,total]
	more_search.text_changed.connect(filter);filter.call(more_query)

func debt_time_panel() -> void:
	var finance = _body("债务与营业时间", "待还本金 ￥%.2f。还本与利息分开记录；不要花光采购与发薪资金。" % float(model.state.debt))
	var actions = _flow(finance)
	for amount in [100, 500]:
		var value = int(amount)
		var repay: Button = host.button("还款 ￥%d" % value, func(): model.repay_debt(value);host.open_panel("更多"), false, "repay:%d" % value)
		repay.disabled = float(model.state.cash) < minf(value, float(model.state.debt)) or float(model.state.debt) <= 0
		actions.add_child(repay)
	var repay_all: Button = host.button("还清余款", func(): model.repay_debt(int(ceil(float(model.state.debt))));host.open_panel("更多"), false, "repay:all")
	repay_all.disabled = float(model.state.debt) <= 0 or float(model.state.cash) < float(model.state.debt)
	repay_all.tooltip_text = "没有待还本金" if float(model.state.debt) <= 0 else "需要足额钞票偿清本金" if repay_all.disabled else "偿清全部本金，利息欠款可在账本中清偿"
	actions.add_child(repay_all)
	var time_actions = _flow(finance)
	time_actions.add_child(host.button("下一营业时段", func(): model.advance_to_next_period();host.open_panel("更多"), false, "next:period"))
	time_actions.add_child(host.button("结算至次日清晨", func(): model.skip_to_next_morning();host.open_panel("系统"), false, "next:day"))
	var world = _section("world")
	if float(world.get("unpaid_fines", 0)) > 0:
		_action(finance, "补缴罚款 · 尚欠￥%.2f" % float(world.unpaid_fines), "pay_fines", {}, "更多")
	if not host.find_employee("zhu_long").is_empty():
		var daylight = _body("烛龙 · 昼夜神通", "每日一次：选择今日采用的营业时段客流系数。不会推进时钟，也不会在休息时间生成顾客。")
		var periods = _flow(daylight)
		for key in PERIODS:
			if key == "rest": continue
			_action(periods, str(PERIODS[key]), "zhulong_shift", {"period": str(key)}, "更多", false, false, "今日已使用昼夜神通" if bool(world.get("zhulong_used_today", false)) else "")

func employee_panel(recruitment: bool = false) -> void:
	var stage = clampi(int(model.state.stage), 0, 4)
	var working = 0
	for employee in model.employees:
		if not bool(employee.get("resting", false)): working += 1
	host.paragraph("当班 %d/%d · 已拥有 %d 位。招募获得重复伙伴时转化为碎片；候补仍计发工资。" % [working, int(stages[stage].staff), model.employees.size()], MUTED)
	if recruitment:
		var hires = _flow(host.modal_body)
		var contract: Button = host.button("故事契约 ×%d" % model.state.get("contracts", []).size(), func():
			if "tutorial_overlay" in host and host.tutorial_overlay != null: host.tutorial_overlay.observe("recruit_attempt")
			host.recruit_employee("contract"), true, "hire:contract")
		var contract_check = _recruit_check("contract")
		contract.disabled = not bool(contract_check.ok)
		contract.tooltip_text = str(contract_check.get("reason", "")) if contract.disabled else "使用成长目标奖励的指定伙伴契约"
		hires.add_child(contract)
		for kind in ["normal", "advanced"]:
			var hire_kind = str(kind)
			var offer: Dictionary = _can("recruit", {"kind":hire_kind})
			var text: String = host.recruitment_text(hire_kind, offer)
			var hire: Button = host.button(text, func():
				if "tutorial_overlay" in host and host.tutorial_overlay != null: host.tutorial_overlay.observe("recruit_attempt")
				host.recruit_employee(hire_kind), kind == "normal", "hire:" + hire_kind)
			var hire_check = _recruit_check(hire_kind)
			hire.disabled = not bool(hire_check.ok)
			hire.tooltip_text = str(hire_check.get("reason", "")) if hire.disabled else "重复角色转化为培养碎片"
			hires.add_child(hire)
		host.paragraph("普通招聘每10次保底SR+、每50次SSR；高级招聘每10次SR+、每30次SSR。稀有度决定成长方式，各岗位都有用武之地。", MUTED)
		return
	host.paragraph("点击员工卡查看排班，或直接点击培训、解雇。",MUTED)
	for employee in model.employees:
		var id = str(employee.id)
		var body = _body("%s · %s · %s" % [str(employee.name), str(employee.rarity), _role_name(str(employee.role))], str(employee.get("skill_description", "")))
		body.get_child(0).add_theme_color_override("font_color", rarity_color(str(employee.rarity)))
		_identity(body, employee)
		var branch_id: String = str(employee.get("branch_id", ""))
		var branch_name: String = str(_section("expansion").get("branches", {}).get(branch_id, {}).get("definition", {}).get("name", "分店"))
		var location: String = "派驻 · " + branch_name if not branch_id.is_empty() else "休息中" if employee.get("resting", false) else "主店当班"
		_text(body, "体力 %d  心情 %d  忠诚 %d  ·  %s" % [int(employee.stamina), int(employee.mood), int(employee.loyalty), "离职交接中" if bool(employee.get("pending_resignation", false)) else location])
		host.revision_ui.staff_controls(body,employee)
		var actions = _flow(body)
		var rest = bool(employee.get("resting", false))
		if not branch_id.is_empty():
			_text(body, "分店按排班营业，体力耗尽时自动休整。可在连锁经营中调回主店。")
			_shortcut(actions, "查看派驻与调回", "连锁经营")
		else:
			actions.add_child(host.button("返回工作" if rest else "安排休息", func(): model.set_employee_rest(id, not rest);host.open_panel("员工"), false, ("work:" if rest else "rest:") + id))

func stock_panel() -> void:
	var management = _section("management")
	var stock: Array = management.get("stock", [])
	host.paragraph("采购记入库存，制作时按配方领料。每日按最近三日平均消耗的1.2倍补货；资金不足时保留已买到的库存。", MUTED)
	var auto = bool(management.get("auto_procure", true))
	_action(host.modal_body, "每日自动采购：%s（点击%s）" % ["开启" if auto else "关闭", "关闭" if auto else "开启"], "set_auto_procure", {"enabled": not auto}, "库存供应", true)
	for entry in stock:
		var id = str(entry.id)
		var body = _body("%s · 库存 %.2f份" % [str(entry.name), float(entry.get("quantity", 0))], "单价 ￥%.2f · 新鲜度 %d%% · %s" % [float(entry.get("price", 0)), int(entry.get("freshness", 100)), str(entry.get("source", ""))])
		var actions = _flow(body)
		for amount in [5, 20]:
			var quantity = int(amount)
			_action(actions, "采购 %d份" % quantity, "purchase", {"id": id, "quantity": quantity}, "库存供应", false, false, str(entry.get("reason", "需要先解锁相应供应商")) if not bool(entry.get("purchasable", true)) else "")
	var supplier = _body("山海供应商", "解锁后可采购丹木果、山猪肉、丹粟米及山海草药。稀有食材通过阶段3探索获取。")
	_action(supplier, "解锁山海供应商", "unlock_supplier", {"id": "shanhai"}, "库存供应")
	if stock.is_empty(): host.paragraph("当前没有可用库存目录，请重载数值配置后重新打开。", WARNING)

func growth_panel() -> void:
	var task: Dictionary=model.full_rules.revision.current_task()
	if not task.is_empty():
		var task_body=_body("当前阶段任务 · "+str(task.title),str(task.description)+"\n进度 %.0f/%.0f" % [float(task.progress),float(task.target)])
		_shortcut(task_body,"前往完成",str(task.destination),true)
	var current = clampi(int(model.state.stage), 0, 4)
	host.paragraph("当前：阶段 %d · %s。累计营业额 ￥%.2f，声望 %d。升级同时要求营业额与声望，达到后由你手动确认。" % [current, str(stages[current].name), float(model.state.total_revenue), int(model.state.reputation)], GREEN)
	var milestones: Array = _snapshot_cache.get("milestones", model.quest_status())
	for milestone in milestones:
		if bool(milestone.get("claimed", false)): continue
		var goal = _body(str(milestone.get("title", "成长目标")), "进度 %d/%d · %s" % [int(milestone.get("progress", 0)), int(milestone.get("target", 1)), str(milestone.get("reward_summary", ""))])
		_action(goal, "领取成长奖励", "claim", {"id": str(milestone.id)}, "经营升级", true, false, "目标尚未完成" if not bool(milestone.get("complete", false)) else "")
	for index in range(maxi(0,current),mini(stages.size(),current+2)):
		var stage: Dictionary = stages[index]
		var body = _body("阶段 %d · %s%s" % [index, str(stage.name), "（当前）" if current == index else "（已达成）" if current > index else ""], str(stage.features))
		_text(body, "累计营业额 ￥%d · 声望 %d · 员工上限 %d · 日租金 ￥%d" % [int(stage.revenue), int(stage.reputation), int(stage.staff), int(stage.rent)])
		_text(body, "规模：%d张餐桌上限" % int(stage.tables) if index < 3 else "规模：三处分店" if index == 3 else "规模：跨人间、妖界与天庭")
		if index == current + 1:
			var ready = float(model.state.total_revenue) >= float(stage.revenue) and int(model.state.reputation) >= int(stage.reputation)
			if _confirm_upgrade and ready:
				_text(body, "确认升级？新阶段的日租金将调整为 ￥%d，新增功能会立即开放。" % int(stage.rent), WARNING)
				_action(body, "确认升级为" + str(stage.name), "upgrade", {}, "经营升级", true)
			else:
				var confirm: Button = host.button("升级为" + str(stage.name), func(): _confirm_upgrade = true;host.open_panel("经营升级"), true, "upgrade:prepare")
				confirm.disabled = not ready
				confirm.tooltip_text = "营业额和声望尚未同时达到要求" if not ready else "查看升级确认"
				body.add_child(confirm)
				if not ready: _text(body, "还需营业额 ￥%.0f、声望 %d" % [maxf(0, float(stage.revenue) - float(model.state.total_revenue)), maxi(0, int(stage.reputation) - int(model.state.reputation))], WARNING)
	if current == 4: host.paragraph("经营已进入三界集团阶段，去【三界集团】参加厨神大赛。", GREEN)

func training_panel() -> void:
	var management = _section("management")
	var employees: Array = management.get("employees", model.employees)
	host.paragraph("训练期间暂停工作。训练费用与稀有度、当前目标属性有关；白泽导师可缩短耗时。副职培训后可切换岗位，工资随岗位与加薪调整。", MUTED)
	host.paragraph("技能书 %d 本。技能培养需阶段1；同一角色的碎片由重复招聘与探索获取。" % int(management.get("skill_books", 0)), GREEN)
	for employee in employees:
		if not host.revision_ui.employee_id.is_empty() and str(employee.id)!=host.revision_ui.employee_id: continue
		var id = str(employee.id)
		var attributes: Dictionary = employee.get("attributes", {})
		var summary: Array[String] = []
		for key in ATTRIBUTES: summary.append("%s %d" % [str(ATTRIBUTES[key]), int(attributes.get(key, 0))])
		var body = _body("%s · %s · 等级%d/%d · 技能 Lv.%d" % [str(employee.name), str(employee.get("rarity", "N")), int(employee.get("level",1)),model.full_rules.revision.level_cap(employee), int(employee.get("skill_level", 1))], "  ".join(summary))
		_identity(body, employee)
		if bool(employee.get("pending_resignation", false)): _text(body, "离职交接中：完成当前项目后离开，不能再安排新项目。", WARNING)
		_text(body, "主职 %s · 副职 %s · 每日额外工资 ￥%d · 碎片 %d" % [_role_name(str(employee.get("primary_role", employee.role))), _role_name(str(employee.get("secondary_role", "未培训"))), int(employee.get("wage_extra", 0)), int(employee.get("fragments", 0))])
		var busy = int(employee.get("busy_until", employee.get("management_until", 0))) - int(model.state.total_minutes)
		if busy > 0: _text(body, "当前项目剩余 %d 游戏分钟，关闭面板后继续推进。" % busy, WARNING)
		var train_row = host.row(8)
		body.add_child(train_row)
		var attribute = OptionButton.new()
		var attribute_keys: Array = ATTRIBUTES.keys()
		for key in attribute_keys: attribute.add_item(str(ATTRIBUTES[key]))
		attribute.custom_minimum_size = Vector2(140, 42)
		train_row.add_child(attribute)
		var train_button: Button = host.button("训练所选属性", func(): _perform("train_attribute", {"id": id, "attribute": str(attribute_keys[attribute.selected])}, "员工培养", true), true, "full:train_attribute:" + id)
		train_button.disabled = busy > 0
		train_row.add_child(train_button)
		var training_note = _text(body, "", WARNING, 12)
		var update_training = func():
			var check = _can("train_attribute", {"id": id, "attribute": str(attribute_keys[attribute.selected])})
			train_button.disabled = not bool(check.get("ok", true))
			train_button.tooltip_text = str(check.get("reason", ""))
			training_note.text = str(check.get("reason", "")) if train_button.disabled else "训练费用 ￥%.0f；关闭面板后开始推进。" % float(employee.get("training_costs", {}).get(str(attribute_keys[attribute.selected]), check.get("cost", 0)))
		attribute.item_selected.connect(func(_selected): update_training.call())
		update_training.call()
		var career = _flow(body)
		var career_roles: Array = management.get("roles", ["chef", "waiter", "salesman"]).duplicate()
		# An original Tutor must be able to return to that position after learning a secondary job.
		var primary_role = str(employee.get("primary_role", employee.role))
		if not primary_role in career_roles: career_roles.append(primary_role)
		for role in career_roles:
			var next_role = str(role)
			if primary_role == "all" and next_role != str(employee.role):
				_action(career, "切换为" + _role_name(next_role), "switch_role", {"id": id, "role": next_role}, "员工培养")
			elif next_role != primary_role and str(employee.get("secondary_role", "")).is_empty():
				_action(career, "培训副职·" + host.role_name(next_role), "train_secondary", {"id": id, "role": next_role}, "员工培养", false, true)
			elif next_role in [str(employee.get("primary_role", employee.role)), str(employee.get("secondary_role", ""))] and next_role != str(employee.role):
				_action(career, "切换为" + host.role_name(next_role), "switch_role", {"id": id, "role": next_role}, "员工培养")
		var support = _flow(body)
		if int(model.state.stage) >= 1:
			_action(support, "碎片升级技能 · %d碎片" % int(employee.get("skill_cost", 0)), "upgrade_skill", {"id": id, "method": "fragments"}, "员工培养", false, false, _stage_reason(1))
			_action(support, "技能书升级", "upgrade_skill", {"id": id, "method": "book"}, "员工培养", false, false, _stage_reason(1))
		_action(support, "加薪 ￥10/日", "raise_wage", {"id": id}, "员工培养")
		_action(support, "沟通与关怀", "comfort", {"id": id}, "员工培养")
		_shortcut(body,"返回员工排班与详情","员工详情")
	var projects: Array = management.get("projects", [])
	if not projects.is_empty():
		var body = _body("进行中的培养与研发")
		for project in projects: _text(body, "%s · %s · 剩余 %d 分钟" % [str(project.get("employee_id", project.get("id", ""))), str(project.get("type", "项目")), maxi(0, int(project.get("due", 0)) - int(model.state.total_minutes))])

func research_panel() -> void:
	var management = _section("management")
	var researchers: Array = management.get("researchers", [])
	var available_ids: Array = []
	for employee in researchers: available_ids.append(str(employee.id))
	if not _researcher_id in available_ids: _researcher_id = str(available_ids[0]) if not available_ids.is_empty() else ""
	if researchers.is_empty():
		host.paragraph("暂无可主持研发的在岗厨师或导师；请先结束其他项目、调回分店员工或调整排班。", WARNING)
	else:
		var choose = _body("主持研发", "选择实际主持伙伴；研发期间会暂停其主店工作。白泽当班参与时研发必定成功。")
		var selector = OptionButton.new()
		for employee in researchers:
			selector.add_item("%s · %s · 创意%d%s" % [str(employee.name), _role_name(str(employee.role)), int(employee.get("attributes", {}).get("creativity", 0)), " · 必成功" if bool(employee.get("guaranteed", false)) else ""])
		selector.selected = available_ids.find(_researcher_id)
		selector.set_meta("qa_id", "research:researcher")
		selector.item_selected.connect(func(index): _researcher_id = str(available_ids[index]);host.open_panel("研发"))
		choose.add_child(selector)
	if int(model.state.stage) == 0:
		host.paragraph("阶段0的三道基础菜已解锁；正式研发在阶段1开放。先经营、还债并提升声望，再从经营升级确认成长。",GREEN)
		_shortcut(_flow(host.modal_body),"查看升级条件","经营升级")
	else:
		host.paragraph("正式研发由具备条件的厨师主持，会消耗钞票、食材与时间。缺少关联伙伴或食材时，按钮会说明原因。失败也能积累经验。", MUTED)
	for entry in management.get("research", []):
		var id = str(entry.id)
		var body = _body("%s · 参考售价 ￥%.2f" % [str(entry.name), float(entry.get("base_price", entry.get("price", 0)))], "关联伙伴：" + _employee_name(str(entry.get("required_employee", ""))))
		body.add_child(host.culture_button("dishes", id))
		var explanation: Dictionary=model.full_rules.culture_experience.definition("menus",id)
		if not explanation.is_empty():
			var language="en" if host.localization!=null and host.localization.language=="en" else "zh"
			_text(body,str(explanation.ingredients.get(language,explanation.ingredients.zh)))
			_text(body,str(explanation.flavour.get(language,explanation.flavour.zh)),MUTED)
			body.add_child(host.button("用料与菜名说明",func():host.open_menu_explanation(id),false,"culture:explain:"+id))
		var recipe: Array[String] = []
		for ingredient in entry.get("recipe", []): recipe.append("%s %.2f份（库存 %.2f）" % [str(ingredient.get("name", ingredient.id)), float(ingredient.get("quantity", 0)), float(ingredient.get("owned", 0))])
		if not recipe.is_empty(): _text(body, "配方：" + " / ".join(recipe))
		var unlocked = bool(entry.get("unlocked", false))
		if unlocked:
			_text(body, "配方已解锁。可以在菜单中上架、调价。", GREEN)
		elif bool(entry.get("active", false)):
			_text(body, "正在研发。关闭面板并继续营业，项目会自动推进。", GREEN)
		else:
			_action(body, "开始研发", "research", {"id": id, "employee_id": _researcher_id}, "研发", true, true, _stage_reason(1))
			if not str(entry.get("reason", "")).is_empty(): _text(body, str(entry.reason), WARNING)

func menu_panel() -> void:
	host.paragraph("至少保留一道已研发的菜品。阶段1可将售价调整为基础售价的50%—200%；每提价10%，价格敏感带来的客流约减少5%。库存不足时该菜售罄，顾客仍会到店并选择其他有货菜品。", MUTED)
	var entries: Array = _section("management").get("research", [])
	for entry in entries:
		if not bool(entry.get("unlocked", false)): continue
		var id = str(entry.id)
		var enabled = bool(entry.get("in_menu", id in model.state.menu_enabled))
		var base_price = float(entry.get("base_price", entry.get("price", 1)))
		var sold_out = not bool(entry.get("can_make",false))
		var body = _body("%s · %s" % [str(entry.name), "售罄" if sold_out else "已上架" if enabled else "未上架"], "售价 ￥%.2f · 基础售价 ￥%.2f · 配方成本 ￥%.2f" % [float(entry.get("price", base_price)), base_price, float(entry.get("cost", 0))])
		body.add_child(host.culture_button("dishes", id))
		if sold_out:
			body.modulate = Color("b3b6af")
			_text(body,"售罄：当前食材不足，顾客不会点这道菜。补货后自动恢复可售。",WARNING)
		var explanation: Dictionary=model.full_rules.culture_experience.definition("menus",id)
		if not explanation.is_empty():
			var language="en" if host.localization!=null and host.localization.language=="en" else "zh"
			_text(body,str(explanation.ingredients.get(language,explanation.ingredients.zh)))
			_text(body,str(explanation.flavour.get(language,explanation.flavour.zh)),MUTED)
			body.add_child(host.button("用料与菜名说明",func():host.open_menu_explanation(id),false,"culture:explain:"+id))
		var menu_toggle: Button = _action(body, "下架" if enabled else "售罄 · 暂不可上架" if sold_out else "上架", "set_menu", {"id": id, "enabled": not enabled}, "菜单", enabled)
		if sold_out and not enabled:
			menu_toggle.disabled = true
			menu_toggle.tooltip_text = "请先补齐配方食材"
		var prices = host.row(8)
		body.add_child(prices)
		var price = SpinBox.new()
		price.min_value = snappedf(base_price * 0.5, 0.01)
		price.max_value = snappedf(base_price * 2.0, 0.01)
		price.step = 0.1
		price.value = float(entry.get("price", base_price))
		price.prefix = "￥"
		price.custom_minimum_size = Vector2(170, 42)
		price.editable = int(model.state.stage) >= 1
		prices.add_child(price)
		var confirm: Button = host.button("确认售价", func(): _perform("set_price", {"id": id, "price": price.value}, "菜单"), false, "full:set_price:" + id)
		confirm.disabled = int(model.state.stage) < 1
		confirm.tooltip_text = _stage_reason(1)
		prices.add_child(confirm)
		var reset: Button = _action(prices, "恢复原价", "set_price", {"id": id, "price": base_price}, "菜单")
		reset.set_meta("qa_id", "full:reset_price:" + id)

func marketing_panel() -> void:
	host.paragraph("销售员的魅力与口才会加强宣传效果。先安排足够员工与库存，再吸引更多顾客。活动时间在关闭面板后继续推进。", MUTED)
	var entries = [
		{"id": "flyer", "name": "发传单", "prefix": "promotion", "stage": 0},
		{"id": "social", "name": "朋友圈广告", "prefix": "promotion.social", "stage": 0},
		{"id": "blogger", "name": "本地美食博主", "prefix": "promotion.blogger", "stage": 0},
		{"id": "influencer", "name": "异兽网红合作", "prefix": "promotion.mythic", "stage": int(model.balance.get("promotion.mythic_stage", 2))}
	]
	for entry in entries:
		if int(model.state.stage) < int(entry.stage): continue
		var prefix = str(entry.prefix)
		var cost_key = "promotion.cost" if str(entry.id) == "flyer" else prefix + ("_gems" if str(entry.id) == "influencer" else "_cost")
		var bonus_key = "promotion.bonus" if str(entry.id) == "flyer" else prefix + "_bonus"
		var duration_key = "promotion.duration" if str(entry.id) == "flyer" else prefix + "_duration"
		var cost = "%d灵石" % int(model.balance.get(cost_key, 0)) if str(entry.id) == "influencer" else "￥%.0f" % float(model.balance.get(cost_key, 0))
		var effect = "客流 +%.0f%% · %d游戏分钟" % [float(model.balance.get(bonus_key, 0)) * 100, int(model.balance.get(duration_key, 0))]
		if str(entry.id) == "blogger": effect += "；平均品质至少%.0f" % float(model.balance.get("promotion.blogger_quality_threshold", 75))
		if str(entry.id) == "influencer": effect += "；有概率触发合作事件"
		var body = _body(str(entry.name) + " · " + cost, effect)
		_action(body, "开展" + str(entry.name), "marketing", {"kind": str(entry.id)}, "宣传营销", true, true, _stage_reason(int(entry.stage)))
	if int(model.state.stage) >= 2:
		for definition in _section("expansion").get("config",{}).get("campaigns",[]):
			var campaign = _body(str(definition.name), "￥%.0f + %d灵石 · 持续%d分钟" % [float(definition.cash), int(definition.gems), int(definition.minutes)])
			_action(campaign, "开展营销活动", "campaign", {"id": str(definition.id)}, "宣传营销", true, true, _stage_reason(int(definition.stage)))

func membership_panel(scope: String = "all") -> void:
	var expansion = _section("expansion")
	var config: Dictionary = expansion.get("config", {})
	host.paragraph("阶段2开放会员与外卖。外卖也消耗库存和厨房产能，送达后按扣除平台佣金的金额入账。", MUTED)
	if int(model.state.stage) < 2: host.paragraph(_stage_reason(2), WARNING)
	if scope in ["all","member"]:
		var members: Dictionary = expansion.get("membership", {})
		var member_config: Dictionary = config.get("membership", {})
		var body = _body("会员计划", "会员 %d 人 · 积分 %d · %s" % [int(members.get("members", 0)), int(members.get("points", 0)), "优惠券待使用" if bool(members.get("voucher", false)) else "暂无优惠券"])
		_action(body, "开通会员计划 · ￥%.0f" % float(member_config.get("setup_cost", 0)), "membership_enable", {}, host.panel_name, true, false, _stage_reason(2))
		_action(body, "兑换会员优惠券 · %d积分" % int(member_config.get("redeem_points", 50)), "member_redeem", {}, host.panel_name, false, false, _stage_reason(2))
	if scope in ["all","delivery"]:
		var delivery_body = _body("外卖服务", "已完成 %d 单 · 外卖入账 ￥%.2f" % [int(expansion.get("delivery_completed", 0)), float(expansion.get("delivery_revenue", 0))])
		_action(delivery_body, "暂停外卖接单" if bool(expansion.get("delivery_enabled", false)) else "开启外卖接单", "delivery_toggle", {"enabled": not bool(expansion.get("delivery_enabled", false))}, host.panel_name, true, false, _stage_reason(2))
		var offer: Dictionary = expansion.get("delivery_offer", {})
		if not offer.is_empty():
			_text(delivery_body, "新外卖：%s · ￥%.2f · 剩余%d分钟" % [_dish_name(str(offer.get("dish_id", ""))), float(offer.get("price", 0)), maxi(0, int(offer.get("expires", 0)) - int(model.state.total_minutes))], GREEN)
			_action(delivery_body, "接下这一单", "delivery_accept", {"offer_id": str(offer.id)}, host.panel_name, true, true)
		else:
			_text(delivery_body, "开启后在营业时间等待新订单。")
		for order in expansion.get("delivery_orders", []): _text(delivery_body, "在途 #%s · %s · 剩余%d分钟" % [str(order.get("id", "")), _dish_name(str(order.get("dish_id", ""))), maxi(0, int(order.get("due", 0)) - int(model.state.total_minutes))])

func expansion_panel(scope: String = "all") -> void:
	var expansion = _section("expansion")
	var config: Dictionary = expansion.get("config", {})
	host.paragraph("阶段3开始管理连锁。分店需要厨师与前厅员工，还要从中央厨房补给成品；实际顾客购买后才有收入。", MUTED)
	if int(model.state.stage) < 3: host.paragraph(_stage_reason(3), WARNING)
	var branches: Dictionary = expansion.get("branches", {})
	var available: Array = expansion.get("available_employees", model.employees)
	if scope in ["all","branches","supply"]:
		for id in branches:
			var branch_id = str(id)
			var branch: Dictionary = branches[id]
			var definition: Dictionary = branch.get("definition", {})
			var body = _body(str(definition.get("name", id)) + " · " + str(definition.get("realm", "人间")), "累计营业额 ￥%.2f · 已接待%d位 · 日租金￥%.0f" % [float(branch.get("revenue", 0)), int(branch.get("served", 0)), float(definition.get("rent", 0))])
			_text(body,"在店库存：" + _stock_summary(branch.get("stock",{})))
			if scope in ["all","branches"]:
				if not bool(branch.get("open", false)):
					_action(body, "开设分店 · ￥%.0f" % float(definition.get("cost", 0)), "branch_open", {"id": branch_id}, host.panel_name, true, false, _stage_reason(int(definition.get("stage", 3))))
				else:
					for employee in model.employees:
						if str(employee.get("branch_id", "")) == branch_id:
							_action(body, "调回主店：%s（%s）" % [str(employee.name), _role_name(str(employee.role))], "branch_return", {"employee_id": str(employee.id)}, host.panel_name)
					var candidates: Array = []
					for employee in available:
						if str(employee.get("branch_id", "")).is_empty(): candidates.append(employee)
					_employee_action(body, "派驻所选员工", "branch_assign", {"id": branch_id}, candidates, host.panel_name, false)
			if scope in ["all","supply"] and bool(branch.get("open",false)):
				var central_stock: Dictionary = expansion.get("central", {}).get("stock", {})
				for dish_id in central_stock:
					if int(central_stock[dish_id]) <= 0: continue
					_action(body, "调拨%s ×%d" % [_dish_name(str(dish_id)), mini(5, int(central_stock[dish_id]))], "supply_send", {"id": branch_id, "dish_id": str(dish_id), "quantity": mini(5, int(central_stock[dish_id]))}, host.panel_name, false, true)
	if scope in ["all","central","supply"]:
		var central: Dictionary = expansion.get("central", {})
		var kitchen_config: Dictionary = config.get("central", {})
		var kitchen = _body("中央厨房与供应链", "批量烹饪→成品入库→付运费调拨→分店售出。库存与在途货物会随存档保存。")
		if scope in ["all","central"]:
			_action(kitchen, "建设中央厨房 · ￥%.0f" % float(kitchen_config.get("unlock_cost", 0)), "central_unlock", {}, host.panel_name, true, false, _stage_reason(3))
		_text(kitchen, "中央成品：" + _stock_summary(central.get("stock", {})))
		if bool(central.get("enabled", false)) and scope in ["all","central"]:
			for dish_id in model.state.unlocked_dishes:
				_action(kitchen, "批量制作%s ×5" % _dish_name(str(dish_id)), "central_cook", {"dish_id": str(dish_id), "quantity": 5}, host.panel_name, false, true)
		for job in central.get("jobs", []): _text(kitchen, "制作中：%s ×%d · 剩余%d分钟" % [_dish_name(str(job.dish_id)), int(job.quantity), maxi(0, int(job.due) - int(model.state.total_minutes))])
		for shipment in central.get("shipments", []): _text(kitchen, "调拨在途：%s ×%d → %s · 剩余%d分钟" % [_dish_name(str(shipment.dish_id)), int(shipment.quantity), str(shipment.branch_id), maxi(0, int(shipment.due) - int(model.state.total_minutes))])
	if scope in ["all","branches"]:
		_shortcut(_flow(host.modal_body),"前往供应链","供应链")
		_shortcut(_flow(host.modal_body),"前往山海探索","山海探索")

func exploration_panel() -> void:
	var expansion = _section("expansion")
	var exploration: Dictionary = expansion.get("config", {}).get("exploration", {})
	host.paragraph("派伙伴探索山海界，完成后自动带回食材与碎片。派出的伙伴暂时离岗，先为主店安排替补。", MUTED)
	var body = _body("山海界探索", "消耗 ￥%.0f + %d灵石 · 耗时%d游戏分钟" % [float(exploration.get("cash", 0)), int(exploration.get("gems", 0)), int(exploration.get("minutes", 0))])
	var locations: Array = model.full_rules.sidequests.snapshot().get("exploration_locations",[]) if "sidequests" in model.full_rules and model.full_rules.sidequests != null else []
	if locations.is_empty(): locations = [{"id":"dahuang","name":"大荒山野"}]
	for location in locations:
		_employee_action(body,"派遣探索 · " + str(location.get("name",location.id)),"explore",{"location":str(location.id)},expansion.get("available_employees",model.employees),"山海探索",true,_stage_reason(3))
	for expedition in expansion.get("explorations", []):
		var progress = _body("探索队伍 · " + _employee_name(str(expedition.employee_id)))
		_text(progress, "剩余 %d 游戏分钟" % maxi(0, int(expedition.due) - int(model.state.total_minutes)))
	var history: Array = expansion.get("exploration_history", [])
	if not history.is_empty():
		var archive = _body("最近探索成果")
		for result in history.slice(maxi(0, history.size() - 5)):
			var reward: Dictionary = result.get("reward", {})
			_text(archive, "食材 %s · 灵石%d · %s碎片%d" % [str(reward.get("items", {})), int(reward.get("gems", 0)), _employee_name(str(result.get("fragment_id", ""))), int(reward.get("fragments", 0))])

func group_panel(scope: String = "all") -> void:
	var expansion = _section("expansion")
	var config: Dictionary = expansion.get("config", {})
	host.paragraph("阶段4开放神兽觉醒与厨神大赛。榜单明确区分本地玩家与模拟对手，不连接在线服务器。", MUTED)
	if int(model.state.stage) < 4: host.paragraph(_stage_reason(4), WARNING)
	if scope in ["all","awaken"]:
		var awakening: Dictionary = config.get("awakening", {})
		var body = _body("神兽觉醒", "消耗 ￥%.0f + %d灵石 + %d同名碎片。全属性永久提升，并切换觉醒美术状态。" % [float(awakening.get("cash", 0)), int(awakening.get("gems", 0)), int(awakening.get("fragments", 0))])
		for employee in model.employees:
			_action(body, "%s · %s" % [str(employee.name), "已觉醒" if bool(employee.get("awakened", false)) else "举行觉醒"], "awaken", {"employee_id": str(employee.id)}, host.panel_name, false, false, "伙伴已经觉醒" if bool(employee.get("awakened", false)) else _stage_reason(4))
	if scope in ["all","contest"]:
		var competition: Dictionary = expansion.get("competition", {})
		var contest_config: Dictionary = config.get("competition", {})
		var contest = _body("厨神大赛", "报名 ￥%.0f + %d灵石 · 耗时%d分钟 · 冠军门槛%.0f分" % [float(contest_config.get("cash", 0)), int(contest_config.get("gems", 0)), int(contest_config.get("minutes", 0)), float(contest_config.get("win_score", 0))])
		var chefs: Array = []
		for employee in expansion.get("available_employees", model.employees):
			if str(employee.role) in ["chef", "all"]: chefs.append(employee)
		var dish_select = OptionButton.new()
		var dishes: Array = model.state.unlocked_dishes
		for id in dishes: dish_select.add_item(_dish_name(str(id)))
		contest.add_child(dish_select)
		var employee_select = OptionButton.new()
		for chef in chefs: employee_select.add_item(str(chef.name))
		contest.add_child(employee_select)
		var compete: Button = host.button("以所选厨师与菜品参赛", func():
			if chefs.is_empty() or dishes.is_empty(): return
			_perform("compete", {"employee_id": str(chefs[employee_select.selected].id), "dish_id": str(dishes[dish_select.selected])}, host.panel_name, true), true, "full:compete")
		contest.add_child(compete)
		var update_contest = func():
			var reason = "需要有厨师与已研发菜品" if chefs.is_empty() or dishes.is_empty() else str(_can("compete", {"employee_id": str(chefs[employee_select.selected].id), "dish_id": str(dishes[dish_select.selected])}).get("reason", ""))
			compete.disabled = not reason.is_empty()
			compete.tooltip_text = reason
		dish_select.item_selected.connect(func(_index): update_contest.call())
		employee_select.item_selected.connect(func(_index): update_contest.call())
		update_contest.call()
		var active: Dictionary = competition.get("active", {})
		if not active.is_empty(): _text(contest, "比赛中 · 剩余%d分钟" % maxi(0, int(active.due) - int(model.state.total_minutes)), GREEN)
		_text(contest, "参赛%d次 · 夺冠%d次 · 最高分%.1f" % [int(competition.get("attempts", 0)), int(competition.get("wins", 0)), float(competition.get("best_score", 0))])
		var result: Dictionary = competition.get("last_result", {})
		if not result.is_empty(): _text(contest, "上届：%.1f分 · %s" % [float(result.get("score", 0)), "夺得冠军" if bool(result.get("won", false)) else "继续磨练厨艺"], GREEN)
	if scope in ["all","ranking"]:
		var board = _body(str(expansion.get("leaderboard_label", "本地单机世界榜 · 模拟对手")))
		board.add_child(host.button("阅读榜单与赛季规则",func(): host.tutorial_overlay.observe("ranking_view");host.show_notice("已阅读本地世界榜规则：12家NPC企业，30天赛季。"),false,"ranking:view"))
		var league: Dictionary = expansion.get("league", {})
		var season_days: int = int(expansion.get("league_season_days", 30))
		if not league.is_empty():
			var season_day: int = clampi(int(model.state.total_minutes / 1440) - int(league.get("start_day", 0)) + 1, 1, season_days)
			_text(board, "第%d赛季 · 第%d/%d天 · 每日结算后更新" % [int(league.get("season", 1)), season_day, season_days], GREEN)
		_text(board, str(expansion.get("leaderboard_rules", "单机模拟榜，经营数据在每日结算时更新。")))
		var leaderboard: Array = expansion.get("leaderboard", [])
		for index in range(leaderboard.size()):
			var entry: Dictionary = leaderboard[index]
			_text(board, "%d. %s · %.1f分" % [index + 1, str(entry.get("name", "有间小馆")), float(entry.get("score", 0))], GREEN if bool(entry.get("player", false)) else MUTED)
			if not bool(entry.get("player", false)):
				_text(board, "今日营收￥%.2f · 今日利润￥%.2f · 声望%d · 分店%d" % [float(entry.get("daily_revenue", 0)), float(entry.get("daily_profit", 0)), int(entry.get("reputation", 0)), int(entry.get("branches", 0))], MUTED, 12)
		var seasons: Array = league.get("history", [])
		if not seasons.is_empty():
			var history = _body("近期赛季记录")
			for season in seasons.slice(maxi(0, seasons.size() - 3)):
				_text(history, "第%d赛季 · 第%d—%d天 · 本店第%d名" % [int(season.get("season", 1)), int(season.get("start_day", 0)) + 1, int(season.get("end_day", 0)) + 1, int(season.get("player_rank", 0))])

func _employee_action(parent: Node, text: String, action: String, args: Dictionary, employees: Array, destination: String, resume: bool, forced_reason: String = "") -> void:
	var selected = OptionButton.new()
	var first_available = -1
	for index in range(employees.size()):
		var employee: Dictionary = employees[index]
		var values = args.duplicate()
		values["employee_id"] = str(employee.id)
		var available = bool(_can(action, values).get("ok", true))
		selected.add_item("%s · %s%s" % [str(employee.name), _role_name(str(employee.role)), "" if available else "（当前不可派遣）"])
		if available and first_available < 0: first_available = index
	if first_available >= 0: selected.select(first_available)
	parent.add_child(selected)
	var action_button: Button = host.button(text, func():
		if employees.is_empty(): return
		var values = args.duplicate()
		values["employee_id"] = str(employees[selected.selected].id)
		_perform(action, values, destination, resume), true, "full:" + action + ":" + str(args.get("id", "")))
	parent.add_child(action_button)
	var reason_label = _text(parent, "", WARNING, 12)
	var update = func():
		var reason = forced_reason
		if reason.is_empty() and employees.is_empty(): reason = "没有可选的员工"
		if reason.is_empty():
			var values = args.duplicate()
			values["employee_id"] = str(employees[selected.selected].id)
			var check = _can(action, values)
			if not bool(check.get("ok", true)): reason = str(check.get("reason", "当前条件不足"))
		action_button.disabled = not reason.is_empty()
		action_button.tooltip_text = reason
		reason_label.text = reason
	selected.item_selected.connect(func(_index): update.call())
	update.call()

func _dish_name(id: String) -> String:
	for dish in model.dishes:
		if str(dish.id) == id: return str(dish.name)
	return id

func _stock_summary(stock: Dictionary) -> String:
	var values: Array[String] = []
	for id in stock:
		if int(stock[id]) > 0: values.append("%s ×%d" % [_dish_name(str(id)), int(stock[id])])
	return "、".join(values) if not values.is_empty() else "暂无成品"

func festival_selection() -> void:
	var data: Dictionary = model.full_rules.world.snapshot().get("festival", {})
	var chefs: Array = data.get("chefs", [])
	var dishes: Array = data.get("dishes", [])
	var body = _body("美食节参赛准备", "选择主店在岗厨师和已研发菜品。报名消耗入场费及一份真实配方食材，品质、创意与招牌搭配决定成绩。")
	if chefs.is_empty() or dishes.is_empty():
		_text(body, "需要可参赛的厨师与已研发菜品。", WARNING)
		return
	var chef = OptionButton.new()
	var dish = OptionButton.new()
	var chef_ids: Array = []
	var dish_ids: Array = []
	for entry in chefs:
		chef_ids.append(str(entry.id))
		chef.add_item("%s · 厨艺%d · 创意%d" % [str(entry.name), int(entry.cooking), int(entry.creativity)])
	for entry in dishes:
		dish_ids.append(str(entry.id))
		dish.add_item(str(entry.name) + (" · 食材不足" if not bool(entry.get("can_make", true)) else ""))
	chef.selected = maxi(0, chef_ids.find(str(data.get("employee_id", ""))))
	dish.selected = maxi(0, dish_ids.find(str(data.get("dish_id", ""))))
	chef.set_meta("qa_id", "festival:chef")
	dish.set_meta("qa_id", "festival:dish")
	body.add_child(chef)
	body.add_child(dish)
	var prepare: Button = host.button("确认参赛搭配", func(): _perform("festival_prepare", {"employee_id":str(chef_ids[chef.selected]), "dish_id":str(dish_ids[dish.selected])}, "事件"), true, "full:festival_prepare")
	body.add_child(prepare)
	var reason: Label = _text(body, "", WARNING, 12)
	var update_selection = func():
		var check: Dictionary = _can("festival_prepare", {"employee_id":str(chef_ids[chef.selected]), "dish_id":str(dish_ids[dish.selected])})
		prepare.disabled = not bool(check.get("ok", false))
		prepare.tooltip_text = str(check.get("reason", ""))
		reason.text = prepare.tooltip_text if prepare.disabled else ""
	chef.item_selected.connect(func(_index): update_selection.call())
	dish.item_selected.connect(func(_index): update_selection.call())
	update_selection.call()
	if not str(data.get("employee_id", "")).is_empty(): _text(body, "已准备：%s + %s" % [_employee_name(str(data.employee_id)), _dish_name(str(data.dish_id))], GREEN)
	var previous: Dictionary = data.get("last_result", {})
	if not previous.is_empty(): _text(body, "最近比赛：%.1f / 对手%.1f · %s" % [float(previous.get("score", 0)), float(previous.get("opponent_score", 0)), "获胜" if bool(previous.get("won", false)) else "继续磨练"])

func blockade_panel() -> void:
	var data: Dictionary = _section("world").get("blockade", {})
	if bool(data.get("resolved", false)):
		host.paragraph("供应、服务与社区支持已形成合力，昆仑商业封锁已经突破。", GREEN)
		return
	if data.is_empty() or not bool(data.get("active", false)):
		host.paragraph("商业封锁尚未开始。阶段推进后，昆仑商会将考验小馆的供应、服务与邻里关系。", MUTED)
		return
	var body = _body("昆仑商会封锁对抗", "应对商会捣乱后，稳住供应、完成优质服务并争取社区支持，三项达成才会真正突破封锁。")
	_text(body, "已应对%d次 · 优质服务%d/%d单 · 品质要求≥%.0f" % [int(data.get("responses", 0)), int(data.get("service_orders", 0)), int(data.get("service_target", 0)), float(data.get("service_quality", 0))])
	if bool(data.get("resolved", false)):
		_text(body, "封锁已突破。", GREEN)
		return
	var labels = {"supply":"建立替代供应", "service":"展示真实服务成绩", "community":"争取社区支持"}
	var flags = {"supply":"supply_secured", "service":"service_secured", "community":"community_support"}
	for strategy in labels:
		var done: bool = bool(data.get(flags[strategy], false))
		var cost: float = float(data.get("costs", {}).get(strategy, 0))
		_action(body, str(labels[strategy]) + (" · 已完成" if done else " · ￥%.0f" % cost), "kunlun_counter", {"strategy":str(strategy)}, "封锁对抗", false, false, "已经达成" if done else "")

func catalog_panel() -> void:
	host.paragraph("点击「文化简介」阅读身份、特色与本作故事。文化资料对全部伙伴和菜品开放，无需先招募或研发。", MUTED)
	var tabs = _flow(host.modal_body)
	for name in ["员工", "菜品", "特殊顾客", "事件", "羁绊", "道具", "装修"]:
		var destination = str(name)
		tabs.add_child(host.button(destination, func(): catalog_tab = destination;host.open_panel("图鉴"), catalog_tab == destination, "catalog:" + destination))
	match catalog_tab:
		"特殊顾客": host.revision_ui.guest_catalog()
		"事件": event_catalog_panel()
		"羁绊": bond_catalog_panel()
		"道具": item_catalog_panel()
		"装修": decoration_catalog_panel()
		"菜品":
			var culture_dishes: Array = model.dishes.duplicate()
			var hidden: Dictionary = model.full_rules.management.config.get("hidden_recipe", {})
			if not hidden.is_empty() and not culture_dishes.any(func(dish): return str(dish.id) == str(hidden.get("id", ""))): culture_dishes.append(hidden)
			for dish in culture_dishes:
				var body = _body(str(dish.name) + " · " + str(dish.get("category", "菜品")), str(dish.get("description", "")))
				body.add_child(host.culture_button("dishes", str(dish.id)))
				_text(body, "参考售价 ￥%.2f · 配方成本 ￥%.2f · %s" % [float(dish.price), float(dish.cost), "已解锁" if str(dish.id) in model.state.unlocked_dishes else "尚未研发"])
				var partner = model._employee_config(str(dish.get("required_employee","")))
				if not partner.is_empty(): _text(body, "招牌伙伴：" + str(partner.name))
				_text(body, "用料：" + str(dish.get("ingredients_description", "普通食材")))
		_:
			for employee in model.catalog:
				var body = _body("%s · %s · %s" % [str(employee.name), str(employee.rarity), _role_name(str(employee.role))], str(employee.get("skill_description", "")))
				body.get_child(0).add_theme_color_override("font_color", rarity_color(str(employee.rarity)))
				_identity(body, employee)
				_text(body, "已结缘" if not host.find_employee(str(employee.id)).is_empty() else "尚未招募", GREEN if not host.find_employee(str(employee.id)).is_empty() else MUTED)

func item_catalog_panel() -> void:
	var management = _section("management")
	var books = _body("技能书 · 持有%d本" % int(management.get("skill_books", 0)), "阶段1起可代替碎片升级员工技能。通过成长目标、剧情奖励、月度经营和山海探索获取。")
	_shortcut(_flow(books), "前往员工培养", "员工培养")
	for employee in model.catalog:
		var count: int = int(model.state.get("fragments", {}).get(str(employee.id), 0))
		var body = _body(str(employee.name) + "碎片 · 持有%d个" % count, "重复招聘该伙伴或山海探索获取；用于技能升级和阶段4觉醒。")
		body.add_child(Rarity.create_badge(str(employee.rarity), true, host.assets))
	var contracts: Array = model.state.get("contracts", [])
	var contract_body = _body("故事契约 · 持有%d份" % contracts.size(), "完成成长与收集目标获取；在招聘页使用，指定伙伴直接加入，重复伙伴转成培养碎片。")
	for id in contracts: _text(contract_body, "● " + _employee_name(str(id)), rarity_color(str(model._employee_config(str(id)).get("rarity", "N"))))
	_shortcut(_flow(contract_body), "前往招聘", "招聘")
	var supplies = _body("食材目录", "普通食材与山海供应商材料可采购；稀有食材通过阶段3山海探索获取。制作时按配方领料。")
	for entry in management.get("stock", []):
		_text(supplies, "%s · 库存%.2f份 · %s" % [str(entry.name), float(entry.get("quantity", 0)), str(entry.get("source", "库存供应"))])
	_shortcut(_flow(supplies), "前往库存供应", "库存供应")

func decoration_catalog_panel() -> void:
	for decoration in model.decorations:
		var owned = 0
		for placement in model.state.get("layout", []):
			if str(placement.id) == str(decoration.id): owned += 1
		var cost: float = float(model.balance.get(str(decoration.cost_key), 0))
		var body = _body("%s %s · ￥%.0f" % [str(decoration.get("icon", "饰")), str(decoration.name), cost], host.decoration_effect_summary(decoration))
		_text(body, "已摆放%d件 · %s" % [owned, "装修面板购买并在地图摆放" if int(model.state.stage) >= int(decoration.get("min_stage", 0)) else "阶段%d解锁" % int(decoration.min_stage)])
	_shortcut(_flow(host.modal_body), "前往装修", "装修")

func event_catalog_panel() -> void:
	var entries: Array = model.events
	host.paragraph("事件档案 · %d则。事件会依据阶段、当班伙伴和经营状态触发；效果以选项说明和实际结算为准。" % entries.size(), MUTED)
	var world = _section("world")
	var seen: Array = world.get("seen_events", [])
	for entry in world.get("history", []):
		var event_id = str(entry.get("event_id", entry.get("id", "")))
		if not event_id in seen: seen.append(event_id)
	for event in entries:
		var body = _body(str(event.get("title", event.get("name", "事件"))) + (" · 已遇见" if str(event.id) in seen else ""), str(event.get("description", "")))
		for option in event.get("options", []): _text(body, "• " + str(option.get("label", "")))
		var trigger: Dictionary = event.get("trigger", {})
		var conditions: Array[String] = []
		if trigger.has("employee_id"):
			var employee: Dictionary = model._employee_config(str(trigger.employee_id))
			_text(body, "● " + _employee_name(str(trigger.employee_id)), rarity_color(str(employee.get("rarity", "N"))))
		if trigger.has("min_stage"): conditions.append("阶段至少 " + str(trigger.min_stage))
		if not conditions.is_empty(): _text(body, "触发线索：" + "，".join(conditions), WARNING)

func bond_catalog_panel() -> void:
	var active: Array = model.active_bonds()
	var active_ids: Array = []
	for bond in active: active_ids.append(str(bond.id))
	host.paragraph("神兽羁绊 · %d组。相关伙伴需要同时在岗，训练、研发、休息与探索时不提供羁绊；阶段2开放组合加成。" % model.bonds.size(), MUTED)
	for bond in model.bonds:
		var body = _body(str(bond.name) + (" · 已激活" if str(bond.id) in active_ids else " · 未激活"))
		var highest = 0
		var ranks: Array = ["N", "R", "SR", "SSR"]
		for id in bond.get("employee_ids", []): highest = maxi(highest, ranks.find(str(model._employee_config(str(id)).get("rarity", "N"))))
		var members = _flow(body)
		for id in bond.get("employee_ids", []):
			var employee: Dictionary = model._employee_config(str(id))
			var rank: String = str(employee.get("rarity", "N"))
			var member: Label = host.label("● %s %s" % [_employee_name(str(id)), rank], 14, rarity_color(rank) if ranks.find(rank) == highest else MUTED)
			members.add_child(member)
		_text(body, str(bond.get("description", "")), GREEN if str(bond.id) in active_ids else MUTED)
		var missing: Array[String] = []
		for id in bond.get("employee_ids", []):
			if host.find_employee(str(id)).is_empty(): missing.append(_employee_name(str(id)))
		if not missing.is_empty(): _text(body, "尚未拥有：" + "、".join(missing), WARNING)
		elif not str(bond.id) in active_ids: _shortcut(_flow(body), "前往安排伙伴", "员工")

func _employee_name(id: String) -> String:
	if id.is_empty(): return "任意合适厨师"
	for entry in model.catalog:
		if str(entry.id) == id: return str(entry.name)
	return id

static func rarity_color(rarity: String) -> Color:
	return Rarity.color_for(rarity)
