extends SceneTree
const Harness=preload("res://tests/culture_ui_tests.gd").Harness
const Helpers=preload("res://tests/culture_ui_tests.gd")
const Language=preload("res://scripts/services/localization.gd")
var checks=0
var failures=0
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func find(node: Node,id: String) -> Node:
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var found=find(child,id)
		if found!=null:return found
	return null
func text_of(node: Node) -> String:
	var text=str(node.text) if node is Label or node is Button else ""
	for child in node.get_children():
		if not child.is_queued_for_deletion():text+="\n"+text_of(child)
	return text
func _init():call_deferred("run")
func run():
	var ui=Harness.new();root.add_child(ui)
	await process_frame
	ui.localization=Language.new("user://culture-language-test-%d.cfg"%OS.get_process_id())
	ui.localization.language="en"
	for sample in ["誉14","峰2h 誉3h","毕方 培训60分","烛龙 研发15分","羬羊 施工90分","⚠ 2位员工状态偏低 · 早餐营业","债1.5万","主持人：本届大荒美食节，有间小馆在与连锁品牌的角逐中获胜！白泽：胜负的背后，是日复一日的菜品与服务。"]:
		expect(ui.localization.chinese.search(ui.localization.translate(sample))==null,"Live status is localized with its current parameters: "+sample)
	ui.model.state.stage=1
	ui.open_panel("菜单");await process_frame
	var explain=find(ui,"culture:explain:noodles")
	expect(explain!=null,"The actual pricing/menu page exposes ingredient notes at the point of ordering")
	if explain!=null:explain.pressed.emit();await process_frame
	expect(ui.panel_name=="菜牌说明" and ui.cultural_ui.selected_dish=="noodles","The real menu explanation opens the matching dish")
	for panel in ["山海驿路","角色特征","菜牌说明","山海来信"]:
		ui.open_panel(panel);await process_frame
		expect(ui.panel_name==panel,"Production cultural panel opens: "+panel)
		expect(find(ui,"culture:tab:Letters")!=null,"Every cultural branch offers navigation and return context")
	ui.open_panel("角色特征")
	for entry in ui.model.full_rules.culture_experience.config.cast:
		var control=find(ui,"culture:companion:"+str(entry.id))
		expect(control!=null,"All thirty character choices exist: "+str(entry.id))
		if control!=null:control.pressed.emit();await process_frame
		expect(text_of(ui.modal_body).contains(str(entry.decision.en)),"Character has meaningful English action context: "+str(entry.id))
	ui.open_panel("菜牌说明")
	for menu in ui.model.full_rules.culture_experience.config.menus:
		var control=find(ui,"culture:menu:"+str(menu.id))
		expect(control!=null,"All twenty-five menus exist: "+str(menu.id))
		if control!=null:control.pressed.emit();await process_frame
		expect(text_of(ui.modal_body).contains(str(menu.ingredients.en)),"Food has clear ingredients before its reading: "+str(menu.id))
	ui.model.state.served=1;ui.model.full_rules.culture_experience.tick();ui.open_panel("山海驿路")
	var money=ui.model.state.cash;var rng=ui.model._rng.state
	var start=find(ui,"culture:choose:menu:accept")
	expect(start!=null,"Real encounter can be entered from the road")
	if start!=null:start.pressed.emit();await process_frame
	expect(ui.model.state.cash==money+20,"UI submits a real deposit rather than a display-only value")
	var verify=find(ui,"culture:choose:menu:verify")
	if verify!=null:verify.pressed.emit();await process_frame
	var refund=find(ui,"culture:choose:menu:refund")
	if refund!=null:refund.pressed.emit();await process_frame
	expect(ui.model.state.cash==money,"The native refund control reverses the prepayment")
	expect(text_of(ui.modal_body).contains("refunded"),"An unfulfilled/refunded booking is not labelled as completed service")
	expect(ui.model._rng.state==rng,"An explanatory conversation draws no service randomness")
	var before=ui.model.state.duplicate(true)
	ui.localization.set_language("zh");ui.localization.apply_tree(ui)
	expect(ui.model.state==before,"Interface language changes cannot mutate campaign state")
	var again=Language.new(ui.localization.path)
	expect(again.language=="zh","Global language preference persists independently of saves")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(ui.localization.path))
	ui.queue_free();await process_frame
	print("Cultural interface: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
