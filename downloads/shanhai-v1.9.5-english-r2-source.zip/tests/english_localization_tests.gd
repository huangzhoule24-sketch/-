extends SceneTree
const Language=preload("res://scripts/services/localization.gd")
const Harness=preload("res://tests/culture_ui_tests.gd").Harness
var checks=0
var failures=0
var report={"missing":[],"states":[],"checks":0,"failures":0}
var locale
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func sample(source: String) -> String:
	var token=RegEx.new();token.compile("(?<!%)%(?!%)[+\\-0-9.]*[dsfi]")
	var matches=token.search_all(source)
	if matches.is_empty():return source
	var rendered=source
	# Some configuration prose contains a literal % alongside placeholders;
	# it is not itself passed to printf by the game. Substitute the candidates
	# by span; real formatted messages are asserted separately below.
	for i in range(matches.size()-1,-1,-1):
		var item=matches[i];var kind=item.get_string().right(1)
		var value="ARG" if kind=="s" else "17.25" if kind=="f" else "23"
		rendered=rendered.left(item.get_start())+value+rendered.substr(item.get_end())
	return rendered.replace("%%","%")
func find(node: Node,id: String) -> Node:
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var found=find(child,id)
		if found!=null:return found
	return null
func event_fixture():
	var m=preload("res://scripts/core/game_model.gd").new(1926)
	m.full_rules.start_full();m.state.cash=10000.0;m.state.gems=100;m.state.reputation=1000;m.state.stage=4;m.state.total_minutes=10*1440+720
	m.employees.clear()
	for definition in m.catalog:
		var employee=m._create_employee(definition);employee.resting=false;m.employees.append(employee)
	m.state.world.clear();m.full_rules.world.ensure_state()
	return m
func event_context(m,event):
	var trigger=event.trigger
	var context={"spy_detected":true,"employee_id":str(trigger.get("employee_id","")),"amount":50.0,"kind":"influencer","promotion_kind":"influencer"}
	if str(trigger.get("category",""))!="":
		for dish in m.dishes:
			if str(dish.category)==str(trigger.category):context.dish_id=str(dish.id);break
		context.category=str(trigger.category)
	if trigger.has("periods"):m.state.total_minutes=10*1440+22*60
	if bool(trigger.get("stamina_zero",false)):m._employee(str(trigger.employee_id)).stamina=0
	if trigger.has("mood_below"):m.employees[0].mood=20;context.employee_id=str(m.employees[0].id)
	if trigger.has("min_overdue"):m.state.overdue_count=3
	if trigger.has("minimum_streak"):context.streak=int(trigger.minimum_streak)
	if trigger.has("minimum_usage"):context.usage=int(trigger.minimum_usage)
	if trigger.has("minimum_parallel"):m.customers.assign([{"stage":"cooking","worker":str(trigger.employee_id)},{"stage":"cooking","worker":str(trigger.employee_id)}])
	return context
func audit_event_messages():
	var base=event_fixture();var observed=[];var choices=0;var resolved=0
	for event in base.events:
		for option in event.options:
			var m=event_fixture();m.events=[event.duplicate(true)]
			m.notice.connect(func(value):observed.append(str(value)))
			m.full_rules.world._enqueue(str(event.id),event_context(m,event))
			if not bool(event.get("auto",false)):m.full_rules.world.choose(str(option.id))
			var history=m.full_rules.world.snapshot().history
			if not history.is_empty():resolved+=1
			for record in history:
				observed.append(str(record.title));observed.append(str(record.label))
				for detail in record.details:observed.append(str(detail))
				for change in record.changes:observed.append(str(change.label)+" %+.2f"%float(change.delta))
			choices+=1
	for source in observed:
		var translated=locale.translate(source)
		if locale.chinese.search(translated)!=null:report.missing.append({"source":source,"translated":translated,"paths":["real_event_effects"]})
	report["event_choices"]=choices;report["event_resolved"]=resolved;report["event_messages"]=observed.size()
	expect(choices>=50 and choices==resolved and not observed.is_empty(),"Event language fixtures actually resolve every configured option")
	expect(report.missing.is_empty(),"All actual event feedback, deltas and notices translate completely")
func audit_event_windows():
	var ui=Harness.new();root.add_child(ui);await process_frame;ui.localization=locale
	ui.model.state.stage=4;ui.model.state.cash=10000.0;ui.model.state.gems=100;ui.model.state.reputation=1000
	ui.model.employees.clear()
	for definition in ui.model.catalog:ui.model.employees.append(ui.model._create_employee(definition))
	ui.model.full_rules.ensure_state_defaults()
	var count=0
	for event in ui.model.events.duplicate(true):
		if bool(event.get("auto",false)):continue
		ui.model.state.world.queue.clear()
		ui.model.full_rules.world._enqueue(str(event.id),event_context(ui.model,event))
		ui.open_panel("事件");await process_frame;locale.apply_tree(ui)
		var texts=[];ui._qa_interface_texts(ui,texts)
		for source in texts:
			if source!="中文" and locale.chinese.search(str(source))!=null:
				report.missing.append({"source":source,"paths":["event_window:"+str(event.id)]})
		expect(ui.panel_name=="事件" and str(ui.model.pending_event().get("id",""))==str(event.id),"Actual event window renders: "+str(event.id))
		count+=1
	report["event_windows"]=count
	expect(count==22,"All 22 interactive/notice events open through the production UI; 16 automatic events are audited through their actual notifications")
	ui.queue_free();await process_frame
func run():
	var reading_preferences="user://culture_preferences.cfg"
	var had_preferences=FileAccess.file_exists(reading_preferences)
	var old_preferences=FileAccess.get_file_as_bytes(reading_preferences) if had_preferences else PackedByteArray()
	locale=Language.new("user://english-r2-test-%d.cfg"%OS.get_process_id());locale.language="en"
	var input=JSON.parse_string(FileAccess.get_file_as_string("res://build/english-r2/coverage-input.json"))
	expect(input is Dictionary,"Coverage candidates were generated from current scripts and configuration")
	for entry in input.get("candidates",[]):
		var source=sample(str(entry.source));var translated=locale.translate(source)
		if locale.chinese.search(translated)!=null:report.missing.append({"source":entry.source,"sample":source,"translated":translated,"paths":entry.paths})
		checks+=1
	audit_event_messages()
	await audit_event_windows()
	var file=FileAccess.open("res://build/english-r2/catalogue-missing.json",FileAccess.WRITE);file.store_string(JSON.stringify(report.missing,"\t"));file.close()
	expect(report.missing.is_empty(),"All extracted display-copy candidates translate without residual Chinese; see catalogue-missing.json")
	for pair in [["体力 100","Stamina 100"],["1年1月1日  06:00 · 早餐营业","Y1/1/1 06:00 · Breakfast Service"],["羬羊 · 厨艺13 · 创意21","Qianyang · Cooking 13 · Creativity 21"],["钞票100 · 灵石2","Cash 100 · Spirit Gems 2"]]:
		expect(locale.translate(pair[0])==pair[1],"Specific templates preserve fields and avoid overlapping wrappers: "+pair[0])
	for prefix in ["菜品收入：酸梅汤","装修预订：朴素双人桌","解雇补偿及遣散费：灌灌","员工培训：羬羊"]:
		var message="%s +￥%.2f"%[prefix,6.25]
		expect(locale.chinese.search(locale.translate(message))==null,"Combined cash messages translate complete names and amounts: "+message)
	expect(locale.translate("这是一句钞票未知整句")=="这是一句钞票未知整句","Unknown prose is recorded, never damaged by word replacement")
	var box=VBoxContainer.new();root.add_child(box)
	var option=OptionButton.new();option.add_item("厨师",11);option.add_item("服务员",22);option.select(1);box.add_child(option)
	locale.apply_tree(box);expect(option.get_item_text(0)=="Cook" and option.get_selected_id()==22,"Options translate without changing selection IDs")
	option.clear();option.add_item("培训",33);option.add_item("装修",44);option.select(1)
	locale.apply_tree(box);expect(option.get_item_text(0)=="Training" and option.get_selected_id()==44,"Rebuilt options replace earlier source metadata")
	locale.language="zh";locale.apply_tree(box);expect(option.get_item_text(0)=="培训" and option.get_item_text(1)=="装修","Chinese restores after a rebuilt dropdown")
	var edit=LineEdit.new();edit.placeholder_text="选择图片";edit.text="CustomAssets/我的图片.png";box.add_child(edit)
	var dialog=ConfirmationDialog.new();dialog.title="装修尚未完成";dialog.dialog_text="请选择一位当班空闲员工";root.add_child(dialog)
	locale.language="en";locale.apply_tree(box);locale.apply_tree(dialog)
	expect(edit.placeholder_text=="Choose Image" and edit.text=="CustomAssets/我的图片.png","Only placeholders translate; player input and asset paths remain unchanged")
	expect(dialog.title=="Furnishing Unfinished" and dialog.dialog_text=="Choose an Idle On-Duty Staff Member","Window titles and dialog bodies translate")
	locale.language="zh";locale.apply_tree(dialog);expect(dialog.title=="装修尚未完成" and dialog.dialog_text=="请选择一位当班空闲员工","Native dialog source text restores in Chinese")
	box.queue_free();dialog.queue_free();await process_frame
	var ui=Harness.new();root.add_child(ui);await process_frame;ui.localization=locale;ui.setup_audio()
	var before=JSON.stringify(ui.model.state);var rng=ui.model._rng.state
	for code in ["en","zh","en","zh"]:ui.set_interface_language(code)
	expect(JSON.stringify(ui.model.state)==before and ui.model._rng.state==rng,"Language switching changes neither campaign state nor simulation RNG")
	ui.localization.language="en"
	var csv=ui.model.full_rules.finance.export_csv(-1,locale.translate)
	expect(csv.begins_with("Transaction ID,Game Day,Game Minute"),"English CSV headers follow the interface language")
	ui.model.change_cash(6.25,"tips","顾客小费")
	var cash_before=ui.model.state.cash
	csv=ui.model.full_rules.finance.export_csv(-1,locale.translate)
	expect(csv.contains("Guest Tips") and csv.contains("6.25") and ui.model.state.cash==cash_before,"English transaction descriptions preserve amounts and do not post another entry")
	ui._notice_last.clear();ui.toast_timer=0;ui.show_notice("招募成功：毕方（SR）")
	locale.apply_tree(ui)
	expect(ui.toast_label.get_parsed_text().contains("Bifang") and locale.chinese.search(ui.toast_label.get_parsed_text())==null,"Rarity colours do not interrupt full-sentence translation")
	ui.set_interface_language("zh")
	expect(ui.toast_label.get_parsed_text().contains("毕方"),"An already visible coloured notice restores its original Chinese")
	ui.set_interface_language("en")
	var culture=preload("res://scripts/services/culture_catalog.gd").new();var quotes=0;var published=0
	for kind in ["employees","dishes","guests"]:
		for id in culture.entry_ids(kind):
			var entry=culture.get_entry(kind,id)
			expect(not str(entry.en.summary).is_empty() and entry.en.sections.size()==entry.sections.size(),"Complete English reading: "+id)
			for quote in entry.get("quotes",[]):
				quotes+=1;var info=quote.get("translation_info",{})
				expect(not info.is_empty() and not str(info.get("credit","")).is_empty(),"Every English quotation has an explicit credit: "+id)
				if info.get("kind","")=="published_excerpt":
					published+=1;expect(culture.data.translation_editions.has(info.edition_id),"Published excerpt resolves to a verifiable edition: "+id)
	expect(quotes==54 and published==4,"54 excerpts retain attribution; four use published translations")
	ui.open_culture("employees","xiao");ui.culture_panel.language="en";ui.open_panel("文化简介",false);await process_frame
	expect(find(ui,"culture:translation-source:0")!=null and find(ui,"culture:translation-source:1")!=null,"Both owl poems expose actual translation-source controls")
	find(ui,"culture:translation-source:0").pressed.emit();find(ui,"culture:translation-source:1").pressed.emit()
	expect(ui.opened_urls.size()==2 and ui.opened_urls[0]==str(culture.data.translation_editions.waley1937.url),"Translation-source controls resolve to the researched fixed witness URL")
	ui.queue_free();await process_frame
	if had_preferences:
		var restored=FileAccess.open(reading_preferences,FileAccess.WRITE);restored.store_buffer(old_preferences);restored.close()
	else:DirAccess.remove_absolute(reading_preferences)
	report.checks=checks;report.failures=failures
	FileAccess.open("res://build/english-r2/localization-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("English localization tests: ",checks," checks, ",failures," failures, ",report.missing.size()," untranslated candidates")
	quit(0 if failures==0 else 1)
