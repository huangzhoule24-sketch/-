extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func expect(ok: bool,description: String):
	checks+=1
	if not ok:failures+=1;push_error(description)
func game(ids: Array):
	var model=Model.new(20261031);model.start_full();model.employees.clear()
	for id in ids:model.employees.append(model._create_employee(model._employee_config(id)))
	model.full_rules.ensure_state_defaults();model.state.tutorial.finished=true
	for step in preload("res://scripts/core/tutorial_progress.gd").config().get("steps",[]):model.state.tutorial.completed_steps.append(step.id)
	model.state.stage=4;model.state.cash=10000.0;model.state.total_minutes=720;model.balance["customer.base_flow"]=0
	for ingredient in model.full_rules.management.ingredients:model.full_rules.management.add_item(str(ingredient.id),100,float(ingredient.price)*100)
	model.full_rules.revision18.before_tick()
	return model
func queue(model,dish: String,count: int,parallel: bool=false):
	for i in range(count):
		model._spawn_customer(dish,false)
		var c=model.customers.back();c.stage="queued";c.arrival_due=0;c.order_decided=true;c.recommendation_done=true
		if parallel:c.group_id=100;c.group_size=count;c.group_parallel=true
func _init():call_deferred("run")
func run():
	var model=game(["jiu_ying","xiao"]);var culture=model.full_rules.culture_experience;var rules=model.full_rules.dollhouse
	expect(not culture.can("culture_batch_mode",{"mode":"same_table"}).ok,"Two installed stoves cannot select three-stove coordination")
	model.state.layout.append({"id":"stove","x":13,"y":0,"w":1,"h":1})
	expect(culture.perform("culture_batch_mode",{"mode":"same_table"}).ok,"Three actual stoves enable coordinated service")
	queue(model,"noodles",3,true);model._assign_tasks()
	var jobs=model.customers.filter(func(c):return c.worker=="jiu_ying")
	expect(jobs.size()==3,"Jiuying coordinates three actual cook tasks")
	var devices=[];var due=[]
	for job in jobs:
		devices.append(str(job.device_uid));due.append(int(job.due_minute))
		expect(job.ingredients_reserved,"Each parallel dish consumes an ingredient reservation")
	expect(devices.size()==3 and devices[0]!=devices[1] and devices[1]!=devices[2] and devices[0]!=devices[2],"No virtual stove or shared reservation")
	expect(due.size()==3 and due[0]==due[1] and due[1]==due[2],"The table’s real scheduled dishes finish together")
	var path="user://culture-advanced-%d.json"%OS.get_process_id()
	expect(model.save_game(path),"Parallel coordinated jobs save")
	var copy=Model.new(4);expect(copy.load_game(path),"Parallel coordinated jobs reload through full validation")
	model=game(["di_jiang","xian_yang"]);culture=model.full_rules.culture_experience
	queue(model,"noodles",1);var customer=model.customers[0];customer.stage="serving";customer.ingredients_reserved=true;customer.quality=80;customer.price=8
	model._assign_tasks();var cue=culture.handover("di_jiang")
	expect(not cue.is_empty() and cue.customer_id==customer.id,"Dijiang’s visible handover refers to a real serving order")
	expect(customer.task_motion.teleport and customer.task_motion.travel_minutes==0 and customer.task_motion.work_minutes>0,"Serving skips travel but retains real handover work")
	expect(culture.handover("xian_yang").is_empty(),"Other staff do not acquire the exceptional movement cue")
	customer.stage="cleaning";expect(culture.handover("di_jiang").is_empty(),"The handover cue ends when actual serving ends")
	model=game(["zhu_long","di_jiang"]);culture=model.full_rules.culture_experience
	model.state.unlocked_dishes.append("zhulong_ramen");model.state.menu_enabled=["zhulong_ramen"]
	var minute=model.state.total_minutes
	expect(culture.perform("culture_night_meal").ok,"Night booking invokes the original daily traffic skill")
	expect(model.state.total_minutes==minute and int(model.state.world.zhulong_day)==culture.day(),"Night lighting does not change the real clock; daily use is recorded")
	expect(not culture.perform("culture_night_meal").ok,"The same daily night skill cannot run twice")
	queue(model,"zhulong_ramen",3)
	model.set_paused(false)
	for i in range(100):
		model.advance_real(1)
		if bool(culture.s().night.get("completed",false)):break
	expect(bool(culture.s().night.get("completed",false)) and culture.s().night.progress==3,"Three genuine Zhulong noodle payments fulfil the night booking")
	expect(model.save_game(path),"Completed night booking saves")
	copy=Model.new(5);expect(copy.load_game(path),"Night daily use and follow-up reload")
	model.state.total_minutes=int(culture.s().night.get("reply_due",minute+1441));culture.tick()
	expect(culture.s().letters.any(func(x):return str(x.id).begins_with("night:complete:")),"The actual meal later receives a traveller’s reply")
	model=game(["zhu_long","xiao"]);culture=model.full_rules.culture_experience;model.state.unlocked_dishes.append("zhulong_ramen");model.state.menu_enabled=["zhulong_ramen"]
	culture.perform("culture_night_meal");model.state.total_minutes=int(culture.s().night.until)+1;culture.tick()
	expect(not culture.s().night.active and not culture.s().night.completed,"An unfulfilled deadline cannot become a successful meal")
	expect(culture.s().letters.any(func(x):return str(x.id).begins_with("night:unfinished:")),"An unfinished meal has its own feedback")
	model=game(["xian_yang","xiao"]);culture=model.full_rules.culture_experience
	culture.s().branch_themes["test"]="qianlai"
	var candidates=[model._dish("noodles"),model._dish("fried_rice")]
	expect(culture.branch_menu("test",candidates).size()==1 and culture.branch_menu("test",candidates)[0].id=="noodles","A branch theme selects from actual available dishes")
	expect(culture.branch_menu("test",[model._dish("fried_rice")]).size()==1,"A theme does not conjure unavailable stock")
	culture.s().branch_themes.clear()
	var visitor={"id":1,"dish_id":"noodles","visitor_id":"old_gourmand","visit_serial":8}
	for i in range(2):model.state.served+=1;culture.on_paid(visitor,8)
	expect(culture.s().guest_memories.old_gourmand.visits==1 and culture.s().guest_memories.old_gourmand.orders==2,"Multiple dishes in one visit count as one remembered visit")
	visitor.visit_serial=9;model.state.served+=1;culture.on_paid(visitor,8);culture.returning_guest(visitor)
	expect(culture.s().guest_memories.old_gourmand.visits==2 and visitor.get("culture_returning",false),"A later real visit recalls its previous dish")
	culture.on_story_claim("champion");var letters=culture.s().letters.size();culture.on_story_claim("champion")
	expect(culture.s().letters.size()==letters and culture.s().letters.any(func(x):return x.id=="epilogue"),"The optional epilogue records actual history once without gating the ending")
	# A guest lost before fulfilment must be refunded even when cash has been spent.
	model=game(["xian_yang","xiao"]);culture=model.full_rules.culture_experience;model.state.served=1;culture.tick()
	culture.perform("culture_choose",{"id":"menu","choice":"accept"});culture.perform("culture_choose",{"id":"menu","choice":"verify"});culture.perform("culture_choose",{"id":"menu","choice":"switch"});culture.tick()
	expect(culture.s().booking.status=="arrived","Failure fixture has an actual arrived reservation")
	customer=model._customer(int(culture.s().booking.customer_id));model._release_customer(customer);model.customers.erase(customer);model.state.cash=0.0;culture.tick()
	expect(culture.s().booking.status=="refunded" and culture.s().booking.remaining==0,"An unfulfilled disappeared reservation clears its liability")
	expect(model.paused and model.state.finance.rescue.pending,"A cash-short refund enters the existing rescue flow")
	expect(model.save_game(path),"The refund and rescue state remain saveable")
	copy=Model.new(6);expect(copy.load_game(path),"The cash-short refund does not corrupt a save")
	var saved=model.state.duplicate(true)
	for field in ["letters","transactions","applied","evidence"]:
		var broken=saved.duplicate(true);broken.culture_experience[field]=[1]
		expect(not culture.validate(broken),"Malformed cultural metadata rejected: "+field)
	# Complete a real expedition, including the synchronous autosave signal emitted
	# by its letter. A save at that boundary must not retain the paid reward job.
	model=game(["ying_zhao","xian_yang","xiao"]);culture=model.full_rules.culture_experience
	model.state.gems=10
	expect(model.full_rules.perform("explore",{"employee_id":"ying_zhao","location":"old_restaurant"}).ok,"Dispatch Yingzhao through the real paid expedition action")
	var expedition: Dictionary=model.state.expansion.explorations[0].duplicate(true)
	var before_stock={}
	for id in expedition.reward.items:before_stock[id]=float(model.full_rules.management.item(str(id)).quantity)
	var expedition_model=model
	var sync_saves=[]
	model.autosave_requested.connect(func():
		expect(expedition_model.state.expansion.explorations.is_empty(),"The letter requests autosave only after the rewarded expedition job is removed")
		sync_saves.append(expedition_model.save_game(path)))
	model.state.total_minutes=int(expedition.due)
	model.full_rules.expansion._tick_exploration()
	expect(sync_saves==[true],"The synchronous letter boundary produces one valid save")
	expect(culture.s().letters.any(func(x):return str(x.id).begins_with("garden:")),"An actually completed Yingzhao expedition delivers a garden letter")
	for id in expedition.reward.items:expect(is_equal_approx(float(model.full_rules.management.item(str(id)).quantity),float(before_stock[id])+float(expedition.reward.items[id])),"The letter reports actual received stock: "+str(id))
	copy=Model.new(7);expect(copy.load_game(path),"The synchronous expedition save reloads")
	var inventory_value=copy.full_rules.management.inventory_value();var saved_gems=copy.state.gems
	copy.full_rules.expansion._tick_exploration()
	expect(is_equal_approx(inventory_value,copy.full_rules.management.inventory_value()) and copy.state.gems==saved_gems,"Reload cannot replay expedition rewards")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	print("Advanced culture: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
