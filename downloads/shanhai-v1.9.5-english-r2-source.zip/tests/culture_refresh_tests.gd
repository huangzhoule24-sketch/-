extends SceneTree
## Real reading controls; guest records below are explicit UI fixtures.
const Catalog = preload("res://scripts/services/culture_catalog.gd")
const LorePanel = preload("res://scripts/ui/culture_panel.gd")
const Harness = preload("res://tests/culture_ui_tests.gd").Harness
var checks = 0
var failures = 0
func _init(): call_deferred("run")
func expect(value: bool,message: String):
	checks += 1
	if not value: failures += 1; push_error(message)
func text(node: Node) -> String:
	var result = str(node.text) if node is Label or node is RichTextLabel else ""
	for child in node.get_children():
		if not child.is_queued_for_deletion(): result += "\n"+text(child)
	return result
func find(node: Node,id: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.get_meta("qa_id","")) == id: return node
	for child in node.get_children():
		var value = find(child,id)
		if value != null: return value
	return null
func settle():
	for i in range(3): await process_frame
func run():
	var catalog = Catalog.new()
	expect(catalog.errors.is_empty(),"Player edition validates")
	expect(catalog.entry_ids("employees").size()==30 and catalog.entry_ids("dishes").size()==25 and catalog.entry_ids("guests").size()==6,"All named staff, recipes and special visitors have readings")
	for kind in Catalog.KINDS:
		for id in catalog.entry_ids(kind):
			var e = catalog.get_entry(kind,id)
			var chinese = str(e.summary)
			var english = str(e.en.summary)
			for section in e.sections: chinese += str(section.text)
			for section in e.en.sections: english += " "+str(section.text)
			expect(chinese.length()>=200 and english.split(" ",false).size()>=90,"Substantive Chinese and English reading: "+id)
			var editorial = false
			for term in ["本作将","游戏改编","开发者","数值","不是历史考据结论"]: editorial = editorial or term in chinese
			expect(not editorial,"Player copy avoids implementation commentary: "+id)
			for q in e.get("quotes",[]): expect(str(q.translation).length()>0 and e.source_ids.has(q.source_id),"Excerpt is attributed and explained: "+id)
	var broken = catalog.data.duplicate(true)
	broken.employees.xian_yang.en.sections.clear()
	expect(not Catalog.validate(broken).is_empty(),"Missing translated sections cannot publish")
	broken = catalog.data.duplicate(true); broken.employees.xian_yang.quotes[0].translation = ""
	expect(not Catalog.validate(broken).is_empty(),"An excerpt without an English explanation cannot publish")
	broken = catalog.data.duplicate(true); broken.employees.xian_yang.quotes[0].paraphrase = ""
	expect(not Catalog.validate(broken).is_empty(),"An excerpt without a Chinese explanation cannot publish")
	broken = catalog.data.duplicate(true); broken.employees.xian_yang.quotes[0].context = ""
	expect(not Catalog.validate(broken).is_empty(),"A contextual passage without its introduction cannot publish")
	broken = catalog.data.duplicate(true); broken.employees.xian_yang.quotes[0].source_label = ""
	expect(not Catalog.validate(broken).is_empty(),"A contextual passage must identify its actual chapter or commentary")
	var ui = Harness.new(); root.add_child(ui); await settle()
	var preferences = "user://culture-refresh-%d.cfg" % OS.get_process_id()
	ui.culture_panel = LorePanel.new(ui,preferences)
	ui.open_panel("图鉴")
	ui.open_culture("guests","old_gourmand")
	expect(ui.panel_name=="图鉴" and ui.model.state.special_visitors.records.is_empty(),"Unmet visitors cannot be revealed through the reading API")
	for definition in ui.model.full_rules.visitors.definitions(): ui.model.state.special_visitors.records[str(definition.id)]={"met":1,"best":"UI fixture"}
	var cash = ui.model.state.cash; var minute = ui.model.state.total_minutes; var rng = ui.model._rng.state
	var recipes = ui.model.state.unlocked_dishes.duplicate(true); var employees = ui.model.employees.duplicate(true)
	for kind in Catalog.KINDS:
		ui.full_panels.catalog_tab = "特殊顾客" if kind=="guests" else "员工" if kind=="employees" else "菜品"
		ui.open_panel("图鉴"); await settle()
		for id in catalog.entry_ids(kind):
			var e = catalog.get_entry(kind,id)
			ui.open_culture(kind,id); await settle()
			if ui.culture_panel.language != "zh": find(ui.modal_body,"culture:language:zh").pressed.emit(); await settle()
			var rendered = text(ui.modal_body)
			var complete = rendered.contains(e.summary)
			for section in e.sections: complete = complete and rendered.contains(section.text)
			for quote in e.get("quotes",[]): complete = complete and rendered.contains(quote.paraphrase)
			for quote in e.get("quotes",[]):
				if quote.has("context"): complete = complete and rendered.contains(quote.context) and rendered.contains(quote.source_label)
			expect(complete,"All Chinese paragraphs are rendered, not truncated: "+id)
			find(ui.modal_body,"culture:language:en").pressed.emit(); await settle()
			rendered = text(ui.modal_body); complete = rendered.contains(e.en.summary)
			for section in e.en.sections: complete = complete and rendered.contains(section.text)
			for q in e.get("quotes",[]): complete = complete and rendered.contains(q.text) and rendered.contains(q.translation)
			for quote in e.get("quotes",[]):
				if quote.has("source_label_en"): complete = complete and rendered.contains(quote.source_label_en)
			expect(complete and ui.culture_panel.snapshot().language=="en","Actual English control renders full story and excerpts: "+id)
			expect(not "https://" in rendered and not "职责：" in rendered and not "神通：" in rendered,"The reading page contains stories rather than stats or raw research links: "+id)
			expect(ui.culture_panel.image_available and ui.culture_panel.snapshot().resource_id==ui.assets.culture_resource_id(kind,id),"Existing art and replaceable lore slot survive: "+id)
			find(ui.modal_window,"culture:back").pressed.emit(); await settle()
			expect(ui.panel_name=="图鉴","Reading returns to its actual parent: "+id)
	expect(cash==ui.model.state.cash and minute==ui.model.state.total_minutes and rng==ui.model._rng.state and recipes==ui.model.state.unlocked_dishes and employees==ui.model.employees,"Reading all 61 cards in both languages leaves economy, staff, unlocks and RNG intact")
	var reopened = LorePanel.new(ui,preferences)
	expect(reopened.language=="en","Reading language persists independently of campaign saves")
	ui.culture_panel = reopened; root.size = Vector2i(844,390); ui.queue_ui_layout(); await settle()
	ui.open_culture("employees","bai_ze"); await settle()
	ui.modal_body.get_parent().scroll_vertical=100000; await settle()
	var back: Button = find(ui.modal_window,"culture:back")
	expect(back.is_visible_in_tree() and back.size.y>=44 and ui.modal_window.get_global_rect().encloses(back.get_global_rect()),"Mobile return stays visible at the bottom of a long English story")
	expect(ui.modal_body.size.x<=ui.modal_window.size.x and ui.modal_body.get_parent().horizontal_scroll_mode!=ScrollContainer.SCROLL_MODE_AUTO,"Mobile reading wraps without horizontal scrolling")
	ui.queue_free(); await settle()
	var report={"checks":checks,"failures":failures,"staff":30,"dishes":25,"visitors":6,"languages":2}
	FileAccess.open("res://build/culture-refresh/tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Culture refresh: ",JSON.stringify(report)); quit(1 if failures else 0)
