extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func expect(ok: bool,description: String) -> void:
	checks+=1
	if not ok: failures+=1;push_error(description)
func near(a: float,b: float) -> bool: return absf(a-b)<0.01
func fresh():
	var model=Model.new(10132026)
	model.start_full()
	model.state.tutorial.finished=true
	for step in preload("res://scripts/core/tutorial_progress.gd").config().get("steps",[]): model.state.tutorial.completed_steps.append(step.id)
	model.state.cash=5000.0
	model.full_rules.management.add_item("generic",100,300)
	return model
func actor(model,id: String):
	if model._employee(id).is_empty(): model.employees.append(model._create_employee(model._employee_config(id)))
	model.full_rules.ensure_state_defaults()
	return model._employee(id)
func choose(model,id: String,choice: String) -> Dictionary:
	return model.full_rules.perform("culture_choose",{"id":id,"choice":choice})
func _init(): call_deferred("run")
func run():
	var model=fresh();var c=model.full_rules.culture_experience
	expect(c.config.cast.size()==30 and c.config.menus.size()==25 and c.config.guests.size()==6,"All existing entities have production content")
	model.state.served=1;c.tick()
	expect(c.event("menu").status=="offered","A real prior service makes the menu encounter eligible")
	var money=float(model.state.cash);var sales=float(model.state.ledger.sales)
	expect(choose(model,"menu","accept").ok,"Accept the reservation")
	expect(near(model.state.cash,money+20) and near(model.state.ledger.sales,sales),"A deposit changes cash and liability, not revenue")
	expect(not choose(model,"menu","accept").ok and near(model.state.cash,money+20),"Repeated choice cannot duplicate the deposit")
	expect(choose(model,"menu","verify").ok,"Clarify the need before offering a change")
	expect(choose(model,"menu","refund").ok,"Refund an unfulfilled booking")
	expect(near(model.state.cash,money) and near(model.state.ledger.sales,sales),"Refund reverses prepayment, not fictitious income")
	var saved_path="user://cultural-test-%d.json"%OS.get_process_id()
	expect(model.save_game(saved_path),"Save the persistent encounter")
	var loaded=Model.new(2)
	var loaded_ok=loaded.load_game(saved_path)
	expect(loaded_ok,"New encounter state passes real save validation")
	if loaded.state.has("culture_experience"):
		expect(loaded.full_rules.culture_experience.event("menu").status=="followup","Follow-up survives reload")
		var old_cash=float(loaded.state.cash);loaded.full_rules.culture_experience.tick()
		expect(near(loaded.state.cash,old_cash),"Reload and tick never replay a transaction")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(saved_path))
	# A second campaign follows the real order path, rather than a scene-completion command.
	model=fresh();c=model.full_rules.culture_experience;model.state.served=1;c.tick()
	choose(model,"menu","accept");choose(model,"menu","verify")
	expect(choose(model,"menu","switch").ok,"Agree the alternative only with stock available")
	model.state.total_minutes=720
	model.full_rules.revision18.before_tick()
	c.tick()
	var booking_id=int(c.s().booking.get("customer_id",-1))
	expect(booking_id>0 and not model._customer(booking_id).is_empty(),"Reservation spawns a real customer with a real seat")
	if booking_id>0:
		expect(model._customer(booking_id).get("culture_booking_id","")=="lin","The reserved guest is identified without a fictitious special-guest unlock")
	model.set_paused(false)
	for i in range(150):
		model.advance_real(1.0)
		if c.event("menu").status=="followup":break
	expect(c.event("menu").status=="followup" and c.s().booking.status=="served","Actual preparation/service/payment, not a button, completes the visit")
	expect(float(c.s().booking.remaining)==0 and float(model.state.ledger.sales)>0,"The paid order applies its prepayment once and records real revenue")
	for tx in c.s().transactions:
		expect(near(float(tx.cash)+float(tx.inventory)+float(tx.get("receivables",0))-float(tx.liabilities),float(tx.profit)),"Event transaction reconciles: "+str(tx.id))
	var when=int(c.event("menu").due);model.state.total_minutes=when;c.tick()
	expect(c.event("menu").status=="resolved" and c.s().letters.size()>0,"A later clock tick produces the follow-up letter")
	var letters=c.s().letters.size();c.tick();expect(letters==c.s().letters.size(),"Follow-up letters are idempotent")
	# Procurement and donation act on valued stock, with no artificial starting balance.
	for buy in [true,false]:
		for share in [true,false]:
			model=fresh();c=model.full_rules.culture_experience;actor(model,"dang_kang")
			model.state.total_minutes=5*1440+600;c.tick()
			expect(c.event("harvest").status=="offered","Harvest uses the live configured five-day period")
			var cash_before=float(model.state.cash);var inventory_before=model.full_rules.management.inventory_value();var expenses_before=float(model.state.ledger.expenses)
			choose(model,"harvest","buy" if buy else "hold")
			var next="gift" if share else "reserve"
			if not buy:next="contact" if share else "revisit"
			expect(choose(model,"harvest",next).ok,"Every harvest branch has a valid ending")
			expect(near(model.state.cash,cash_before-(80 if buy else 0)),"Only actual purchase spends cash")
			expect(near(model.full_rules.management.inventory_value(),inventory_before+(80 if buy else 0)-(12 if buy and share else 0)),"Purchase and donation change real valued stock")
			expect(near(model.state.ledger.expenses,expenses_before+(12 if buy and share else 0)),"Only a real gift becomes an expense")
			var current=model.state.cash
			expect(not choose(model,"harvest",next).ok and near(model.state.cash,current),"Resolved choice cannot run twice")
	# Both Bifang plans use the installed stoves and actual wing orders.
	for strategy in ["small","training"]:
		model=fresh();c=model.full_rules.culture_experience
		model.state.stage=1
		var cook=actor(model,"bi_fang")
		for other in model.employees:
			if str(other.role)=="chef" and str(other.id)!="bi_fang":other.resting=true
		for ingredient in model.full_rules.management.ingredients:model.full_rules.management.add_item(str(ingredient.id),100,float(ingredient.price)*100)
		model.state.unlocked_dishes.append("bifang_wings");model.state.menu_enabled=["bifang_wings"]
		model.balance["events.bifang_fire_probability"]=0.0
		c.tick();expect(c.event("bifang").status=="offered","Bifang invitation needs a real recruit, recipe and stove")
		var before=float(model.state.cash)
		expect(choose(model,"bifang",strategy).ok,"Start Bifang plan: "+strategy)
		expect(near(model.state.cash,before-(30 if strategy=="training" else 0)),"Training fee is charged once")
		if strategy=="training":
			expect(model.save_game(saved_path),"Save during actual team training")
			var copy=Model.new(8)
			expect(copy.load_game(saved_path),"Cultural training project survives full validation and reload")
		model.set_paused(false)
		for i in range(1000):
			model.advance_real(1)
			if c.event("bifang").status in ["followup","resolved"]:break
		expect(c.event("bifang").status in ["followup","resolved"],"Real wing service completes "+strategy)
		expect(int(c.event("bifang").progress)==(3 if strategy=="small" else 5),"Only the agreed number of paid banquet orders count")
		DirAccess.remove_absolute(ProjectSettings.globalize_path(saved_path))
	model=fresh();c=model.full_rules.culture_experience
	expect(not c.can("culture_batch_mode",{"mode":"same_table"}).ok,"One-stove or absent-Jiuying service cannot claim coordinated capacity")
	var rng=model._rng.state;var cash_before=model.state.cash
	c.snapshot();c.definition("cast","di_jiang");c.definition("menus","dijiang_dumplings")
	expect(rng==model._rng.state and cash_before==model.state.cash,"Reading snapshots and identity cards leave simulation untouched")
	var old=model.state.duplicate(true);old.erase("culture_experience")
	expect(c.validate(old),"Older saves can omit the optional namespace")
	var broken=model.state.duplicate(true);broken.culture_experience.booking={"remaining":-1,"status":"held"}
	expect(not c.validate(broken),"Malformed liabilities cannot be loaded")
	print("Cultural experience: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
