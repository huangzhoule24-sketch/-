"""Validate design coverage, source fidelity and every standalone story/ledger branch."""
from pathlib import Path
import copy, hashlib, json, re
import jsonschema

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def read(name):return json.loads((HERE/name).read_text())
plan=read('execution-plan.json'); sample=read('samples/content-samples.json'); baseline=read('baseline.json')
editorial=json.loads((ROOT/'docs/culture-research/player-edition.json').read_text())
checks=[]
def check(ok,label):
    if not ok:raise AssertionError(label)
    checks.append(label)
jsonschema.Draft202012Validator(read('execution-plan.schema.json')).validate(plan)
check(True,'JSON schema valid')
for kind in ['employees','dishes','guests']:
    key='characters' if kind=='employees' else kind
    actual={e['id'] for e in plan[key]}
    check(len(actual)==len(plan[key]),key+' unique IDs')
    check(actual==set(editorial[kind]),key+' exact existing ID coverage')
    check(all(e['status']=='proposed' for e in plan[key]),key+' proposal status preserved')
sources={e['id']:e for e in editorial['sources']}
check(read('reference-index.json')['sources']==editorial['sources'],'all 54 source records supplied unchanged in bundle')
for c in plan['characters']+plan['dishes']+plan['regions']:
    check(all(sid in sources for sid in c['source_ids']),c['id']+' source references exist')
tasks={t['id']:t for t in plan['tasks']}
check(len(tasks)==len(plan['tasks']),'task IDs unique')
resolved=set()
while len(resolved)<len(tasks):
    ready={tid for tid,t in tasks.items() if set(t['depends_on'])<=resolved}
    check(bool(ready-resolved),'task dependency graph has next level')
    resolved|=ready
for p in sample['profiles']:
    check(p['quotes']==editorial['employees'][p['id']]['quotes'],p['id']+' classical quotations unchanged')
    check(all(len(p['paragraphs'][lang])==2 for lang in ['zh-CN','en']),p['id']+' bilingual prose complete')
for s in sample['sources']:
    check(s==sources[s['id']],s['id']+' source metadata unchanged')
used=set()
for p in sample['profiles']:
    used.update(p['source_ids']);used.update(q['source_id'] for q in p['quotes'])
for e in sample['events']:used.update(e['source_ids'])
check(used=={s['id'] for s in sample['sources']},'all sample sources supplied')

branches=[]
for event in sample['events']:
    nodes={n['id']:n for n in event['nodes']}; visited=set()
    check(len(nodes)==len(event['nodes']),event['id']+' node IDs unique')
    def walk(nid,balance,path,ancestors):
        check(nid in nodes,event['id']+'/'+nid+' target exists')
        check(nid not in ancestors,event['id']+'/'+nid+' no unbounded loop')
        visited.add(nid);n=nodes[nid]
        check(all(n[k].get(lang) for k in ['title','text'] for lang in ['zh-CN','en']),event['id']+'/'+nid+' bilingual')
        check(bool(n['terminal'])==(not bool(n['options'])),event['id']+'/'+nid+' terminal/dead-end consistency')
        if n['terminal']:
            branches.append({'event_id':event['id'],'terminal':nid,'choices':path,'balance':balance})
            return
        optionids=[o['id'] for o in n['options']]
        check(len(optionids)==len(set(optionids)),event['id']+'/'+nid+' choice IDs unique')
        for option in n['options']:
            nextbalance=copy.deepcopy(balance)
            for tx in option['transactions']:
                check(tx['cash']+tx['inventory']-tx['liabilities']==tx['profit'],tx['id']+' balanced transaction')
                for key in nextbalance:nextbalance[key]+=tx[key]
                check(all(nextbalance[k]>=0 for k in ['cash','inventory','liabilities']),tx['id']+' resources sufficient')
            opening=event['initial']['cash']+event['initial']['inventory']-event['initial']['liabilities']
            check(nextbalance['cash']+nextbalance['inventory']-nextbalance['liabilities']==opening+nextbalance['profit'],option['id']+' cumulative ledger reconciles')
            walk(option['next'],nextbalance,path+[option['id']],ancestors|{nid})
    walk(event['start'],copy.deepcopy(event['initial']),[],set())
    check(visited==set(nodes),event['id']+' all nodes reachable')
check(len(branches)==8,'all eight terminal branches validated')
for rel,digest in baseline['file_hashes'].items():
    check(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel+' production baseline unchanged')
inline=(HERE/'samples/sample-data.js').read_text()
check(json.loads(inline.removeprefix('window.SHANHAI_SAMPLE = ').removesuffix(';\n'))==sample,'offline JS data equals JSON')
for rel in ['samples/index.html','samples/sample-app.js','samples/sample-data.js','修改意见策划案_AI可读版.md','execution-plan.schema.json']:
    check((HERE/rel).is_file(),rel+' exists')
for rel in re.findall(r'<script src="([^"]+)"', (HERE/'samples/index.html').read_text()):
    check((HERE/'samples'/rel).is_file(),'offline script '+rel+' exists')
report={'scope':'Planning data, source copying, event graphs and sample accounting only; not production game or human communication testing',
 'passed':True,'checks':len(checks),'terminal_paths':branches,'coverage':{'characters':30,'dishes':25,'guests':6,'profiles':6,'events':3,'tasks':len(tasks)},
 'production_baseline_unchanged':True}
(HERE/'validation/data-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'terminal_paths':len(branches),'passed':True}))
