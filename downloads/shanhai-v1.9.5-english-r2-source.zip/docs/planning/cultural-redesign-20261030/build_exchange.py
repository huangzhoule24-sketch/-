"""Build planning exchange data and standalone samples; never writes game configuration."""
from pathlib import Path
import hashlib, json, subprocess, copy, html

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def read(rel): return json.loads((ROOT / rel).read_text())
def dump(rel, value):
    (HERE / rel).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def bi(zh, en): return {'zh-CN': zh, 'en': en}

editorial = read('docs/culture-research/player-edition.json')
staff = read('config/employees.json')
dishes = read('config/dishes.json')

# Original proposal material. Original references are copied separately without rewriting them.
rows = [
('xian_yang','羊形与马尾；钱来松石','松影色围裙、可辨马尾，盛汤时尾梢先停','让赶路者喝到恰好的热汤，讨厌只被看作一道菜名','汤品品质已有；新做冠名与食材说明、冷夜旅人回访','采购预算内选汤品与份量，先问需要再讲名字','一碗汤的介绍与钱来来信','P0'),
('xiao','夜鸟圆眼；诗歌中的警觉与护巢语境','圆眼与脸盘，夜间先观察再走','喜欢夜班的安静，不愿被一声不祥概括','夜市速度已有；增加夜班工作偏好与照明反馈','调整夜班与休息，保留安静通道','夜席里熟悉的那双眼','P1'),
('er_shu','兔首麋身、以尾飞、犬声','长耳与尾翼；悬浮不蹬脚','想快快送稳每只盘子，却会被突然的大声打断','传菜加速与受惊已有；说明声音关系并可调整岗位','安排与灌灌的位置和班次，避免单纯罚胆小','盘子落稳之后的感谢','P1'),
('guan_guan','青丘鸟；呵呼之声、佩之不惑','鸟羽领与张口呼声，户外招徕','热情又嗓门大，想学会让人听懂而非只听见','宣传与顾客情绪影响已有；增加安静/户外方案','与耳鼠错区配合，选择简短清楚的菜牌','旅人复述了正确的名字','P1'),
('e_shou','《神异经》人面兔形、言语颠倒','兔耳、人面与翻转菜牌动作','爱漂亮话，也在意别人是否真的信它','虚假宣传事件已有；扩为核查、改牌、培训与回访','用清楚说明换取长期信任，留存旧牌与处理记录','名字之外，碗里是什么','P0'),
('tao_tie','恶名、鼎上兽面、郭璞关联狍鸮三层来源','羊角与腋侧眼纹、兽面围兜；大口但不吞人','贪尝每一种味道，需学会给别人留下一份','速度快耗材多已有；增加试味份量与余量提醒','自助少量补盘或预制大盘，比较浪费与断供','最后一勺留给谁','P1'),
('ran_yi_yu','鱼身蛇首六足、白色山林与安眠愿望','鱼鳞长身与六足饰纹；低位移动','偏爱慢慢说话，想让急客也坐定片刻','汤品收益已有；增加清淡夜汤的风味说明','汤品备货与夜客等候，不承诺现实助眠疗效','从英鞮水路寄来的信','P1'),
('dang_kang','猪形有牙、自名之声、丰收征兆','獠牙与谷穗，搬粮袋时重心稳','听到丰收就高兴，又担心粮袋只换来账上虚荣','5天折扣实际配置已有；新增库存/现金/分享分支','采购或留钱，再选择备料或赠出已买食材','听见丰年之后','P0'),
('tian_gou','山兽白首狸形；天象与吞月的后续脉络','白首、兽耳与看向月亮的动作','愿意守住门口，却不喜欢客人只拿吞月打趣','防逃单已有；新增天象误认的夜席对话','客人问月食时用不同文本说明，不套日本天狗造型','月亮还在，夜宵也在','P1'),
('gu_diao','有角雕形、婴儿声、危险水泽','禽翼与角、发声时先抬头','声音会惊人，也想学会提醒客人','特殊客权重与吓退已有；新增提前告知和声音区','安排招徕时段，解释突兀声音，保留异质魅力','门外那声啼鸣','P1'),
('xuan_gui','龟形鸟首虺尾、判木之声、水路','鸟喙轮廓、龟甲与贴地蛇尾','做事缓而稳，珍惜一次清楚的回应','耐力和免争抢已有；新做稳岗搭配与木声回忆','让稳岗承担长汤项目，不把慢等同没用','木响沿水而来','P1'),
('qing_fu','《搜神记》母子相寻、还钱故事','虫翼、成对铜钱纹；轻飞不蹬脚','把钱的来去也听成牵挂，想知道熟客会不会回来','拾取加成已有；扩到回款解释与熟客约定','辨认收款与利润，追踪承诺而非无限生钱','一枚钱的归路','P1'),
('jiu_wei_hu','青丘九尾与危险；涂山白狐的另一传统','九尾扇形分层与狐耳，尾不遮邻桌','喜欢被注目，也会试探别人的判断','小费已有；增加介绍层次与不靠迷惑成交的服务','先询问口味，再选一句故事或直接点单','灯下认出第九条尾巴','P0'),
('bi_fang','青身赤纹白喙、一足、火兆','不对称单足支撑、青赤披翼、白喙形发饰','骄傲而戒慎，要证明自己能守住火候','烧烤与火灾已有；扩为备烤/协作夜宴方案','规模与培训时间二选，真实炉灶与队列反馈','一足立在火边','P0'),
('pi_xiu','《史记》威猛兽名；后续聚财传统','强健兽角与守柜姿态；具体体型属本作选择','爱积攒也怕漏钱，需学习有理由地花钱','收银加成与招聘费用已有；加培训预算讨论','说明留钱和投资员工的取舍，不做必定守财模板','钱柜外的一笔好支出','P1'),
('ying_zhao','槐江园圃、人面马身虎纹鸟翼、巡四海','虎纹与鸟翼；巡园与来信动作','爱护园圃，也想知道别处的树怎样生长','客流与心情已有；增加探索来信与可用时蔬线索','从已有探索选季节食材，听旅人带来的种植经验','园圃也有远方','P1'),
('lu_wu','昆仑下都、虎身九尾、园囿时节职守','虎爪与紧束九尾；整齐摆盘','重视时序，遇上随性伙伴会绷紧脸','烤制提速已有；增加宴席协作的节拍安排','预先分锅与开席时间，与毕方商量规模','开席以前的九条尾巴','P1'),
('jing_wei','女娃溺海、白喙赤足、衔木石','红足与白喙发饰；小石和反复往返','执着却会疲惫，不把坚持当被无限加班的理由','清台与心情代价已有；增加轮休和带石来信','完成一段任务后轮换，承认失败也能继续','海风带不走的名字','P1'),
('qiong_qi','牛猬毛与翼虎两形；四凶恶名','优先翼虎主形，猬毛用肩背辅锚','好斗好胜，也在意输赢是否公平','辣菜收益与冲突已有；新增辣度说明与冲突预防','确认个体辣度需求，安排安静/热闹桌，不按国籍分','把锋芒留给辣香','P1'),
('tao_wu','顽固恶名与虎足猪牙长尾的后续形象','猪牙、虎爪和长尾；抱臂而非翻桌','认定的方子不愿改，却愿意接受说得通的试味','宣传与拒令已有；增加解释理由/小份试验方案','协商改菜单，一次试验与证据比强令更有效','认准的味道也能再尝','P1'),
('hun_dun','《庄子》待客与七窍；另一异兽叙述','浑圆身体与感官留白；不与帝江复制轮廓','爱招待又抗拒被别人改成标准样子','研发成败/耗时已有；新增尊重不同与试味记录','选择保留原味或合作试验，创新有可见记录','一只未被凿开的云吞','P1'),
('xie_zhi','独角辨曲直，形似牛/羊的不同文本','单角、青色毛与侧耳听诉动作','重承诺，宁愿问慢一点也不先下结论','客诉已有；扩为证据-双方-补救-复访过程','核对菜单与订单，不能按角色神力凭空断罪','请先从第一道菜说起','P0'),
('qing_geng','青身白喙白目白尾、自鸣、御疫愿望','清楚的青白分区与白尾','喜欢清整的桌面，对客人的不安很敏感','投诉与心情已有；新增清洁/说明反馈','看见清台与洗手/备餐流程，不宣传现实防病神效','清亮的一声问候','P1'),
('tian_lu','天鹿步摇、宫廷铸物与福禄','鹿角或吉兽主形须注明本作选择；珠枝纹','喜欢盛装迎客，也怕被当只会招财的摆件','拾取概率已有；新做迎宾器物和装饰介绍','把器物故事作为自选读，不强迫点单仪式','随步轻摇的一点光','P1'),
('feng_huang','丹穴五彩与五德纹、歌舞、太平之愿','五彩分区与可读羽纹，不只红色火焰','追求端正优美，却不愿所有目光都等它燃尽','复活士气与支线已有；重构叙事重心与群体宴席','分担岗位，以稳定合作完成席面而非靠耗尽体力刷复活','五色落在一张桌上','P1'),
('bai_ze','白泽图、能言万物、黄帝问知的后出文献','卷册与可辨神兽角纹，柔和而非普通秘书','爱命名和追问，也会把解释留给亲历者','导师研发已有；增加渐进引导与可查问答','先让玩家尝试，求助时才给线索，不长篇授课','给陌生之物一个名字','P0'),
('ying_long','蓄水、战事、不能返天与旱雨的多篇叙述','有翼龙尾与雨水轨迹，翼只局部起伏','能带来雨，也记得不能归去的远行','水产品质与雨客流已有；新做雨季备料与避雨来客','雨天菜单和库存取舍，不把战争当单一治愈童话','雨停以前的一席','P1'),
('zhu_long','赤色人面蛇身、视昼瞑夜、呼吸季候','赤蛇尾、双眼开合与安静呼吸','掌过天地的明暗，如今在意一盏桌灯是否太亮','借时段系数已有；新做可读技能与预约夜席','看清客流与休息承诺再使用每日一次技能','把夜色留给这一席','P0'),
('di_jiang','黄囊丹赤、六足四翼、无面目、识歌舞','无脸面、四翼与六肢成组；不可只用面具代替','用节奏交朋友，不希望别人替它补一张笑脸','传菜特殊移动已有；新做可视交接与动作回应','安排服务交接方式，保留仅传菜阶段特例','没有眉眼，也能接住一拍','P0'),
('jiu_ying','《淮南子》灾世九婴；高诱注水火怪；多首流传','多首/蛇颈轮廓与冷暖双侧，优先显示主辅首','想同时照看所有锅，却不愿被当无穷人手','真实三炉并发已有；新做同席同步与轮休','看真实炉数、体力、上菜窗口，不能凭画面造炉','几口锅，一席饭','P0'),
]
characters=[]
for row in rows:
    eid,anchor,visual,wish,existing,decision,story,priority=row
    base=next(x for x in staff if x['id']==eid); e=editorial['employees'][eid]
    characters.append({'id':eid,'name':base['name'],'role':base['role'],'status':'proposed','source_ids':e['source_ids'],
        'source_anchor':anchor,'proposed_visual':visual,'desire_and_tension':wish,'existing_and_delta':existing,
        'decision':decision,'story_seed':story,'priority':priority,'preserve_current_portrait_until_review':True})

dish_rows=[
('noodles','清汤面、葱香与面条','先说明鲜与清淡不等于没味道','首单看得懂原料和价格'),
('fried_rice','米饭、鸡蛋与家常配料','一粒饭的火候与家常记忆','快出餐与少量备料'),
('plum_juice','乌梅风味饮品，酸甜可描述','解腻和待客，不宣称治病','给客人实际甜酸选择'),
('qianyang_soup','普通肉类汤，冠名伙伴不是原料','钱来松石、西域大羊见闻','冷夜汤份量与温度'),
('bifang_wings','烤翅用料与丹木果','火鸟意象进入受控火候','分批备烤/协作夜宴'),
('fox_milk','实际乳饮用料与薲草','九尾名称的美丽与多种流传','含乳先明示，问需要不靠魅惑'),
('yinglong_hotpot','山海水产，需核实具体种类','应龙旱雨叙事与围锅而坐','雨天库存与共享份量'),
('taotie_buffet','多种实料的自助组合','贪食意象与节制留余','小份补盘与真实耗用'),
('phoenix_soup','稀有食材羹汤','羹与凤凰五德，不只重生','群体宴席与细腻口感说明'),
('zhuyu_salad','含虚构神异祝余草的轻食','古书饥饱愿望与当下轻食','份量说明，不标现实保健功效'),
('luwu_platter','山猪肉为主的烤制拼盘','陆吾职守与时序','同桌各份按约上齐'),
('yingzhao_salad','迷榖芽等山海蔬食','园圃守护和巡四海','探索时蔬线索与陌生味道'),
('jingwei_bibimbap','丹粟米等石锅拌饭','精卫记忆与韩国饮食经验相遇','旅人试味与石锅热度提示'),
('dangkang_rice','普通谷物炒饭','丰收征兆、粮食与分享','采购转存货、耗用记成本'),
('tiangou_tempura','普通海鲜炸制，具体成分待核','中国天狗脉络与日本菜式分层','脆衣口感与真实用料说明'),
('ranyiyu_soup','普通水产为主的汤','冉遗鱼冠名、白山水路和安眠愿望','不把异兽当原料或许诺助眠'),
('qiongqi_hotpot','真实麻辣用料','麻与辣分开解释，穷奇保留锋芒','询问个体辣度与共享锅边界'),
('taowu_barbecue','山猪肉秘制烤制','固执与食谱记忆','小份试味协商，不强迫改变'),
('hundun_wonton','有面皮的云吞','混沌与云吞的音义趣味；庄子待客','研发记录和不强加标准样子'),
('xiezhi_set','组合套餐，明列各部分用料','公正落实到说明和承诺','价格、份量、换单与证据'),
('zhulong_ramen','含丹木果的拉面','烛龙昼夜意象与夜席','说明风味与温度，不只是火焰图标'),
('dijiang_dumplings','普通肉馅与实际面皮','无面目专名≠无面粉','核查小麦信息、确认再换单'),
('jiuying_platter','稀有食材组成的拼盘','水火同体与多首流传','真实多炉、同席窗口、独立订单'),
('baize_hidden_banquet','隐藏宴席，按现有实际配方显示','知识变成彼此听得懂的菜牌','先前经历回顾，不靠读书刷解锁'),
('phoenix_true_soup','丹木果、山海鱼与稀有食材','原有支线成果与凤凰更完整来历','保留隐藏解锁，复访承认合作'),
]
dish_matrix=[]
for eid,actual,culture,touch in dish_rows:
    e=editorial['dishes'][eid]
    dish_matrix.append({'id':eid,'name':e['name'],'status':'proposed','source_ids':e['source_ids'],
        'menu_information':actual,'cultural_direction':culture,'gameplay_touchpoint':touch,
        'allergen_status':'requires_recipe_audit','preserve_existing_recipe':True})

guest_rows=[
('old_gourmand','不只求分数，也想再尝到记得的火候','记住上次菜单与火候选择','说出一次具体变化，而非固定好评'),
('baize_friend','带一份书页线索，关心古书如何被理解','记住玩家问过哪一种名物','交来一条新的可选阅读，不赠神通收益'),
('lost_cub','先得到不吓人的说明与合适份量','记住曾获得的帮助和约定','带同伴再来，需求仍先询问'),
('picky_blogger','核对菜单与体验，不是专门找茬','保存原菜单、订单与处理记录','如实补充改进经过，不自动删差评'),
('grateful_monster','回应确有发生的善意','保存是赠粮、留座还是清楚解释','具体回信或食谱交流，非反复刷钱'),
('kunlun_spy','观察小馆方法，也有自己的职业顾虑','记住一次竞争与待客决定','可提出合作或疑问，不只永远敌对'),
]
guest_matrix=[{'id':eid,'name':editorial['guests'][eid]['name'],'status':'proposed',
 'request':request,'memory':memory,'return_feedback':feedback,'encounter_gate':'preserve_existing'}
 for eid,request,memory,feedback in guest_rows]

regions=[
 {'id':'qianlai','name':'钱来山','predecessors':[],'theme':'松石与热汤','source_ids':['a_sh_west','origin_erya_sheep'],'employee_ids':['xian_yang'],'dish_ids':['qianyang_soup','noodles'],'actual_action':'完成3份已付款汤类订单；阅读非必需'},
 {'id':'qingqiu','name':'青丘','predecessors':['qianlai'],'theme':'尾影与呼声','source_ids':['a_sh_south'],'employee_ids':['jiu_wei_hu','guan_guan'],'dish_ids':['fox_milk','plum_juice'],'actual_action':'核对并发布1份原料清楚的菜牌，再完成1次来客回访'},
 {'id':'zhange','name':'章莪','predecessors':['qingqiu'],'theme':'瑶碧与炉火','source_ids':['a_sh_west'],'employee_ids':['bi_fang'],'dish_ids':['bifang_wings'],'actual_action':'已有毕方当班时按选择方案完成真实宴席；可延期'},
 {'id':'danxue','name':'丹穴','predecessors':['zhange'],'theme':'五彩与共席','source_ids':['b_shj_south','b_song_omens'],'employee_ids':['feng_huang'],'dish_ids':['phoenix_soup','phoenix_true_soup'],'actual_action':'符合现有阶段/员工/菜条件后完成群体宴席；不赠稀有卡'},
]

taskrows=[
('BASE-01','P0','核对基线、数值与事件冲突',[],['记录30/25/6实体及调用证据；当康周期读实配','列出新旧技能唯一结算点和冲突组'],'all','planning'),
('SRC-01','P0','角色来源层级与六人身份表',['BASE-01'],['六人各有正文/古注/流传/原创字段','羬羊全景、九婴不引相柳、凤凰不等同西方phoenix'],'all','content'),
('LOC-01','P0','全局语言框架与首单英语',['BASE-01'],['英文完成首单、排班、备货、账表和错误出口','切换语言不改变经营RNG和资金；参数占位相同'],'all','localization'),
('EVT-01','P0','事件数据校验与可重入状态机',['BASE-01'],['三事件触发、选择、延期、回访均可持久化','重复点击/刷新/读档不重复业务'],'all','engineering'),
('FIN-01','P0','事件原子入账与对账适配',['EVT-01'],['每个事务校验现金库存负债与利润','采购、赠粮、预收退款不重复入账'],'accounting','engineering'),
('MENU-01','P0','菜牌原料、风味与未知成分',['LOC-01','SRC-01'],['25菜保留配方与冠名分栏；未知过敏信息显式提示','无面饺子不显示成无小麦；没有疗效承诺'],'law','content'),
('EVENT-A','P0','毕方宴席：分批与培训两路线',['EVT-01','FIN-01','SRC-01'],['实际毕方/灶台/食材/已付款订单参与；未具备可延期','复用火灾冲突组；两路线有不同次日回访'],'hr','gameplay'),
('EVENT-B','P0','菜牌误读：需求、核查、换单或退款',['EVT-01','FIN-01','MENU-01'],['先问清需求与实料再选；无承诺未知过敏安全','预收款不记两次销售；双方记录与回访存在'],'law','gameplay'),
('ART-01','P0','六位角色锚点与动作审校',['SRC-01'],['六位立绘/像素/徽记身份一致；至少轮廓+行为两锚点','四方向≤1px起伏；真实服务点；无新增座位穿模'],'all','art'),
('ONB-01','P0','条件驱动前20分钟引导',['LOC-01','EVENT-A','EVENT-B'],['不依赖抽到稀有员工；访客情节不赠技能','可暂停延后，自愿读典籍，首次账表可看懂'],'all','gameplay'),
('EVENT-C','P0','当康采购、留钱、赠粮与留存',['EVT-01','FIN-01'],['四条组合路线均结束，未买不能赠库存','现金240/存货60起点按交易对得上，负库存拒绝'],'accounting','gameplay'),
('PLAY-01','P0','第一轮真人观察与迭代',['ONB-01','ART-01','EVENT-C'],['记录人数/语言/熟悉度/求助/回忆原话','将误解与后续修改关联，不以自动测试代替真人'],'all','evaluation'),
('ROUTE-01','P1','四站驿路与现探索适配',['PLAY-01'],['路线标为策划选编，不伪称原典地理顺序','实际任务驱动，旧档阶段与原结局不被锁住'],'all','gameplay'),
('CAST-01','P1','30员工全量特征、愿望和行为覆盖',['SRC-01','ART-01','PLAY-01'],['30个稳定ID均有形貌/行为/关系或选择','阅读原180段员工文学正文和典籍身世保留'],'hr','content'),
('DISH-01','P1','25菜全量菜单与跨文化交流',['MENU-01','ROUTE-01'],['25菜均有点餐说明和触点，隐藏条件保留','拌饭/天妇罗不伪称原著中国古菜；事实另核'],'all','content'),
('GUEST-01','P1','6来客记忆与双向回访',['EVENT-B','EVENT-C'],['6原来客解锁规则保留，记忆来自实际选择','新旅人不按国籍固定口味或知识'],'law','gameplay'),
('LOC-02','P1','后期核心系统与结果全量英语',['LOC-01','CAST-01','DISH-01','GUEST-01'],['阶段0–4、更多分支、动态错误与存档提示均可用英语','所有页返回和长英文布局检查，罕字无缺字'],'all','localization'),
('SKILL-J','P1','九婴真实多炉同席协调',['BASE-01','EVENT-A','PLAY-01'],['单炉拒绝特殊模式；三炉对应三个真实任务','预约/取消/体力/库存正确，无第四个虚构炉'],'hr','gameplay'),
('SKILL-D','P1','帝江交接动作与非语言回应',['ART-01','EVENT-B'],['仅传菜使用原特殊移动，其他任务仍守规则','面目留白可读，交接不挡旁人，不考玩家节拍'],'all','gameplay'),
('SKILL-Z','P1','烛龙可读神通与预约夜席',['ROUTE-01','FIN-01','PLAY-01'],['每日次数不重置、不绕过打烊；客流系数仅算一次','光色与实际时钟区别清楚；排班/菜单有履约结果'],'hr','gameplay'),
('GARDEN-01','P1','英招与当康的探索来信',['ROUTE-01','EVENT-C'],['复用探索与实际食材，无虚假采集收获','时令说明与真实日期一致，未实现易腐不扣损耗'],'accounting','gameplay'),
('REG-01','P1','旧档、经济、视觉与完整流程回归',['LOC-02','SKILL-J','SKILL-D','SKILL-Z','GARDEN-01'],['新旧档阶段0–4可推进，事件不刷收益','真实订单/资金/服务点/声音静音和导入路径回归'],'all','qa'),
('COURSE-01','P2','第二轮试玩、原创性与课程材料',['REG-01'],['六张来源到玩法映射、三专业审校、AI人工改稿证据','按实测人数报告理解/兴趣/问题，未测项保留'],'all','evaluation'),
]
tasks=[{'id':tid,'priority':p,'title':title,'status':'proposed','depends_on':deps,'acceptance':accept,
        'discipline_review':review,'workstream':stream,'evidence_required':['changed_files','automated_or_manual_checks','actual_scope_and_limits']}
       for tid,p,title,deps,accept,review,stream in taskrows]

files=['config/employees.json','config/dishes.json','config/sidequests.json','config/culture.json',
 'config/global_balance.json','docs/culture-research/player-edition.json','scripts/core/effect_resolver.gd',
 'scripts/core/dollhouse_rules.gd','scripts/core/world_events.gd','scripts/ui/culture_panel.gd']
baseline={'id':'v1.9.5-culture-origins','reviewed_on':'2026-10-30','development_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'published_game_fingerprint':'cd9afc7c850b64c8971f5402f558c4332bd52614ae4128888969e7e1cd7d721b',
 'status':'existing_verified','counts':{'employees':30,'standard_dishes':23,'hidden_dishes':2,'special_guests':6,'culture_entries':61,'quotes':54},
 'file_hashes':{f:sha(ROOT/f) for f in files},'verification_scope':'实体、来源数据、配置及既有验证记录；没有本轮重跑整款游戏或自然通关',
 'external_research_this_delivery':False,'research_note':'使用项目此前核实的54条来源关系与古籍资料；本轮无新增联网史料考证。新增比较/饮食历史细节须另核。'}
dump('baseline.json',baseline)
dump('reference-index.json',{'schema_version':1,'status':'existing_verified','origin':'docs/culture-research/player-edition.json',
 'note':'沿用项目此前核实的54条来源关系；本轮未新增联网史料核验。用于解析本案全部source_ids，不等于54本古籍。',
 'sources':editorial['sources']})
plan={'schema_version':1,'document_id':'SH-CULTURE-R1','date':'2026-10-30','status':'proposed',
 'current_authorization':{'design_documents':True,'standalone_samples':True,'production_game_changes':False},
 'baseline':'baseline.json','human_document':'修改意见策划案_AI可读版.md',
 'sample_data':'samples/content-samples.json','source_index':'reference-index.json','states':['existing_verified','proposed','sample_only','implemented_unverified','verified'],
 'goals':['通过异兽特征形成经营理由','陌生玩家无需预习可开始','双向饮食与神话交流','HR/会计/法学进入同一决策链'],
 'preserve':['stable_entity_ids','stage_0_4','old_save_progress','literary_culture_reading','54_contextual_quotes','readable_font','four_direction_walk','crowd_and_seat_fixes','asset_audio_import_paths','standalone_music_not_imported'],
 'priority_character_ids':['xian_yang','bi_fang','di_jiang','jiu_ying','jiu_wei_hu','zhu_long'],
 'regions':regions,'characters':characters,'dishes':dish_matrix,'guests':guest_matrix,'tasks':tasks,
 'global_acceptance':{'all_entity_ids_preserved':True,'old_save_no_reset':True,'reading_not_required_for_progress':True,
  'transaction_idempotency':True,'no_duplicate_skill_application':True,'full_core_english_target':True,
  'human_evaluation_required_for_communication_claims':True,'animation_body_bob_source_pixels_max':1,'foot_lift_source_pixels_max':2}}
dump('execution-plan.json',plan)

# Six prose samples: creative writing attached to precise, unchanged classical excerpts.
prose={
 'xian_yang':('钱来山的风，先吹进一碗汤',
 '锅盖轻轻一响，羬羊把火收小。客人先看见围裙后那条长长的马尾，才闻到汤里的热气。“路远么？”它问。它不急着把故乡说完，只把碗沿转到不烫手的一边。',
 '钱来山上有松，山下有洗石。古人记下山羊似的身体、马一般的尾巴，也记下脂膏润护皴裂肌肤的愿望。郭璞读到这里，又想起西域大月氏的大羊。一个名字里，于是同时住进山林、日常生活与遥远的见闻。它愿意让过路人从一碗热汤，记住那座山。',
 'A wind from Qianlai, caught in a bowl',
 'The lid clicks. Qianyang lowers the flame. A traveller notices the long horse-like tail behind the apron before the broth reaches their nose. “A long road?” Qianyang asks, turning the bowl so its rim is easier to hold.',
 'Qianlai is a mountain of pines and washing stones. The old account gives its sheep-like creature a horse’s tail, and records hopes of using its fat to soothe cracked skin. Guo Pu’s commentary thinks, too, of great sheep in the far-off Yuezhi lands. A name gathers landscape, daily needs and distant observations. Here is a companion willing to let a warm bowl carry a little of home.'),
 'bi_fang':('一足立在火边',
 '毕方只用一只脚站在炉前，另一道本该属于脚的影子，留给了青赤相间的披翼。火苗向上一窜，它没有退。白喙般的发饰低下来，恰好映住一线将熟的金黄。',
 '古书里的毕方出于章莪山，青身赤纹，白喙独足，叫声像在喊自己的名字。它一出现，城邑便可能有异火。如今它站在食肆里，最不爱听的话却是“反正你就是火”。它想学会的，是把猛烈的一瞬收住，让客人尝到炙香，而不是只记住一场惊吓。',
 'One foot beside the fire',
 'Bifang stands on one foot at the grill. Blue-green and red wings fill the space where another silhouette might have fallen. A flame leaps. Bifang stays still, watching the edge of the food turn gold.',
 'On Mount Zhang’e, the old text describes a crane-like bird with one leg, a white beak and red markings on a blue-green body. Its appearance foretells uncanny fire. Here at the inn, Bifang dislikes hearing, “Well, you are fire.” What it wants is to hold back that fierce instant: to leave the guests with the scent of the grill, rather than a fright.'),
 'di_jiang':('没有眉眼，也能接住一拍',
 '帝江停在桌边，四翼微张，托盘却稳得没有一声轻响。它没有可供猜测的眉眼。客人犹豫时，它便把手收回半寸，等对方点头，再递过去——像一支舞里刚好留给旁人的一拍。',
 '天山的旧记写它如黄囊、赤如丹火，六足四翼，浑敦而无面目，末了却说“是识歌舞”。认识它不一定要先找一张脸。我们也可以从停顿、朝向和一次接稳的盘子，慢慢读出它的邀请。那一拍就这样，从古书的歌舞，轻轻续到了餐桌旁。',
 'A beat with room for someone else',
 'Dijiang pauses beside the table, four wings slightly open, its tray perfectly still. There are no eyes or eyebrows to read. When a guest hesitates, it draws its hand back a little, waits for a nod, then offers the plate—a beat in a dance left open for a partner.',
 'The Tianshan account gives it six feet, four wings and a rounded body without a distinct face, then adds that it understands song and dance. Perhaps a face need not be our first way of knowing it. A pause, a turn and a plate received safely can also make an invitation. The old text gives us dance; this inn continues that beat beside a table.'),
 'jiu_ying':('几口锅，一席饭',
 '几口锅几乎同时响起来。九婴的一颗头偏向汤灶，另一颗还盯着刚离火的盘子。“我都看得见，”它说，过了一会儿又补一句，“不等于我不累。”',
 '《淮南子》把九婴写在十日焦禾、羿为民除害的灾世，高诱注称它为水火之怪。后来流传的多首轮廓，给这股力量添上许多朝向。在小馆里，这些朝向成了忙碌与牵挂：既想每一口锅都好，也得承认，一席饭要靠几个人共同端稳。',
 'Several stoves, one shared meal',
 'Several pots begin to sing at once. One of Jiuying’s heads turns towards the broth while another watches a plate just lifted from the heat. “I can see them all,” it says. After a pause: “That does not mean I never tire.”',
 'Huainanzi places Jiuying in a time when ten suns scorch the crops and Yi is sent against the creatures afflicting people. Gao You’s commentary calls it a creature of water and fire. Later many-headed imagery gives that force several directions. At the inn, those directions become attention and concern: every pot matters, yet one meal still needs more than one person to bring it safely to the table.'),
 'jiu_wei_hu':('灯下认出第九条尾巴',
 '客人已经数到第八条尾巴，九尾狐偏偏往灯外一转。“还有一条，”它笑道，却先把菜牌推近，“不过，你想喝热的，还是凉的？”它很懂得让人回头，也知道回头之后，最好还有值得留下的东西。',
 '青丘的狐有九尾，声音近婴儿，也有凶险的一面；涂山的白狐又走进婚娶与王者之兆的故事。同一个名字在东亚走过很长的路，每到一处，面貌与性情未必相同。它不急着替所有狐狸说话，只愿让这一桌人先认识眼前的它。',
 'The ninth tail, just beyond the lamplight',
 'A guest has counted eight tails when the fox turns one just beyond the lamp. “One more,” it smiles, then draws the menu closer. “But first—something warm, or something cool?” It knows how to make people look back. It also knows there should be a reason to stay once they do.',
 'The fox of Qingqiu has nine tails, an infant-like voice and a dangerous side. The white fox at Tushan enters a different story of marriage and kingship. Fox traditions have travelled widely across East Asia without remaining identical. This fox does not speak for all of them. It would rather the people at this table came to know the companion before them.'),
 'zhu_long':('把夜色留给这一席',
 '烛龙睁眼时，窗外的晚色仿佛亮了一层。它却先伸手，替最近的客人挡住太直的灯光。“这样呢？”它问。曾经容得下天地明暗的目光，此刻只量着一张桌的距离。',
 '古书记烛阴、烛龙，目光一开一合，便有昼夜；一呼一吹，又像季候流转。赤色人面蛇身把天地的尺度拉得很长。在食肆里，它愿意先同伙伴约好一席夜饭：灯何时亮，汤何时热，忙碌的人又何时可以休息。',
 'A little night, kept for this table',
 'When Zhulong opens its eyes, the dusk beyond the window seems a shade brighter. Yet its first gesture is to shield a nearby guest from the lamp. “Better?” it asks. A gaze once measured in daylight and darkness now attends to the distance across one table.',
 'The old accounts of Zhuyin and Zhulong bind opening and closing eyes to day and night, breath to the turning seasons. A red, human-faced serpent stretches imagination to the scale of a world. Here, it begins by agreeing on a night meal with its companions: when the lamps will shine, when the soup will be ready, and when the people who serve it may rest.'),
}
profiles=[]
art_briefs={
 'xian_yang':{'portrait':'成年温和的人形面容，羊角与羊耳贴近发际，衣料取松石的灰绿；长马尾从腰后明确垂出，不能画成蓬松羊尾。角耳是羊形转译，衣装与人形是本作设计。',
  'pixel':'保留头部羊形与细长马尾两种轮廓；尾尖与围裙不同色，不用巨大姓名牌补辨识。',
  'idle_work':'待机轻理围裙；盛汤先停尾、稳碗后舀汤；锅盖和汤锅来自实际设备，小人只带汤勺。',
  'recognition_check':'遮住名字，观察者应能指出羊特征与马尾，而非只看见普通羊角厨师。'},
 'bi_fang':{'portrait':'清俊修长的人形上身，青底赤纹披翼、白喙形额饰；下肢明确单足支撑，用衣摆留出不对称负形，不悄悄补成两足。',
  'pixel':'一足、青赤两区与白色头部点是主锚点；独足移动用小幅移足与翼部平衡，不套双脚交替，不用高跳破坏≤1px躯干约束。',
  'idle_work':'独足稳定停驻，披翼只在失衡前小幅收展；烤制时收腕和等火动作清楚，火焰属于真炉。',
  'recognition_check':'静态看得出独足，动作看得出守火；不与普通红发火系角色混同。'},
 'di_jiang':{'portrait':'保持人的衣装与优美姿态，面部留白无眼鼻口而非只戴一张可摘面具；四翼明确成两对，六肢以主臂/下肢和两侧辅肢组织。',
  'pixel':'圆润丹赤体块、无面浅色区和两对翼在小图优先；六肢可通过组形表达，不增巨型身体挡邻桌。',
  'idle_work':'待机六肢分组轻点，躯干不大跳；递盘前停半拍，对方接稳再收臂；场景模型交接位置不偏离。',
  'recognition_check':'不用笑脸也能读懂邀请；与混沌的浑圆轮廓有翼数、肢组和色块区别。'},
 'jiu_ying':{'portrait':'主面容保持美型人形，另八个较小蛇颈/兽首沿肩背分层成组，形成九首而非九张相同人脸；水火用冷暖纹与动作区分。多首造型记流传与本作层。',
  'pixel':'主首与四组辅首构成齿状肩背轮廓，重要头部在现帧内分层；小尺度宁可简化五官，也不只画九颗装饰珠。',
  'idle_work':'各组头平缓转向实际炉灶，不同时乱抖；同一身体只能处于真实任务位置，多炉调度用可见转向和独立设施反馈表达。',
  'recognition_check':'能看出多首与冷暖的两股力量；不会从像素里误认成普通厨师加一串项链。'},
 'jiu_wei_hu':{'portrait':'人形面容可俊美或妩媚，狐耳与九尾是身份主锚点；不把魅力限定为一种性别表演。尾巴以三组三尾组织，纹理与衣装不抢脸。',
  'pixel':'九尾组成独特扇形外轮廓，正常占用仍服从人物遮挡范围；近景可数九条，远景至少一眼认出多尾狐。',
  'idle_work':'转身时尾组依次跟随，服务时先收尾避开椅背，不能穿过邻座身体；有趣但不靠持续大幅摆动抢镜。',
  'recognition_check':'立绘和小人的耳色、尾尖、服饰主色一致；不用单纯放大小费图标表达其魅力。'},
 'zhu_long':{'portrait':'美型人面与赤色蛇形下身相连，长身收在画面内，眼睛的开合与呼吸为主；不直接改成普通有角西方翼龙。',
  'pixel':'赤鳞长尾贴地盘转，头部眼光以稳定明暗表示；不快速闪烁，也不占用不真实的地面面积。',
  'idle_work':'缓慢呼吸≤1px，爬行/滑移而非双脚走；看向客人时灯光渐变，做菜仍抵达真实设备点。',
  'recognition_check':'无名字也能看到赤蛇、人面与目光主题；灯光反馈不冒充模拟时钟已倒流。'},
}
for eid in plan['priority_character_ids']:
    title,p1,p2,te,e1,e2=prose[eid]; old=editorial['employees'][eid]; c=next(x for x in characters if x['id']==eid)
    profiles.append({'id':eid,'name':old['name'],'name_en':old['en']['name'],'status':'sample_only',
      'title':bi(title,te),'paragraphs':{'zh-CN':[p1,p2],'en':[e1,e2]},'source_anchor':c['source_anchor'],
      'visual_brief':c['proposed_visual'],'tension':c['desire_and_tension'],'gameplay_direction':c['existing_and_delta'],
      'source_ids':old['source_ids'],'quotes':copy.deepcopy(old['quotes']),'art_design_brief':art_briefs[eid],
      'source_layers':{'primary_or_commentary':'见每条source_label及来源记录；引用不改写',
       'original_in_this_sample':'人形服装、食肆关系、对白、工作姿态与经营方案',
       'later_tradition':'九婴多首、狐叙事流传等不作为所有原典共有特征'}})

def tx(tid, zh, en, cash=0, inventory=0, liabilities=0, profit=0):
    return {'id':tid,'label':bi(zh,en),'cash':cash,'inventory':inventory,'liabilities':liabilities,'profit':profit}
def option(oid,zh,en,next_node,transactions=None):
    return {'id':oid,'label':bi(zh,en),'next':next_node,'transactions':transactions or []}
def node(nid,title,text,options=None,terminal=False,reading_ids=None):
    return {'id':nid,'title':title,'text':text,'options':options or [],'terminal':terminal,'reading_ids':reading_ids or []}

events=[]
events.append({'id':'sample_bifang_banquet','status':'sample_only','title':bi('一足立在火边','One foot beside the fire'),
 'production_trigger':{'hook':'pre_service_banquet','required_employee_id':'bi_fang','requires_active_employee':True,'conflict_group':'bifang_fire','requires_real_orders':True},
 'source_ids':['a_sh_west'],'initial':{'cash':240,'inventory':60,'liabilities':0,'profit':0},'start':'invitation',
 'nodes':[
 node('invitation',bi('灯下的一席','A meal beneath the lamps'),bi('毕方盯着炉口：“别把这一席写成看火的奇观。我想让他们记住味道。”陆吾翻开排班：“那就先约好几桌、几轮。”你选择怎样筹备？','Bifang watches the grill. “Please do not advertise a spectacle of fire. I want them to remember the food.” Luwu checks the roster. “Then let us agree how many tables, and how many rounds.” How will you prepare?'),[
  option('small','分两轮备烤，先办小席（不新增现金支出，规模较小）','Prepare two rounds for a smaller meal (no extra cash cost; fewer tables)','small_result'),
  option('training','先做协作培训，下一次开席（培训支出30）','Train together first; hold the meal next time (training costs 30)','training_result',[tx('training_fee','协作培训费用','Team training expense',cash=-30,profit=-30)])]),
 node('small_result',bi('慢一点，刚好','A little slower, just right'),bi('你把席面分为两轮。毕方不必追赶所有炉口，陆吾也能让每一轮按约端上桌。客人端起盘子时，毕方终于把目光从火上移开，向桌边点了一下头。','You divide the meal into two rounds. Bifang need not chase every flame, and Luwu can keep each round together. When the guests receive their plates, Bifang finally looks away from the heat and gives the table a small nod.'),[
  option('read_letter','查看次日回信','Read the next-day letter','small_letter')]),
 node('training_result',bi('练的是彼此','Learning one another'),bi('培训花了30，今晚先把炉边留给伙伴。毕方练习收火，陆吾练习听它说“这一轮先别催”。等到下一次开席，他们已经知道，哪一声呼唤是在请对方再等一等。','Training costs 30. Tonight, the space by the grill belongs to the team. Bifang practises easing the flame; Luwu practises hearing “not this round, not yet.” By the next meal, they know which call asks a companion to wait a little longer.'),[
  option('read_letter','查看下一次宴席后的回信','Read the letter after the next meal','training_letter')]),
 node('small_letter',bi('回信：那只稳稳站着的鸟','Letter: the bird that stood so still'),bi('“我本来只听过它与火的传闻。昨晚记住的，却是那只独足的鸟，等到食物刚刚好的样子。若下次还有一席，我愿意早点预约。”','“I had only heard the stories of fire. What stayed with me last night was the one-legged bird waiting until the food was just right. If there is another meal, I would like to book early.”'),terminal=True,reading_ids=['bi_fang']),
 node('training_letter',bi('回信：留给伙伴的一次停顿','Letter: a pause for a companion'),bi('“我看见厨师收了火，另一位等了一下才接盘。原来一席饭好吃，也因为大家知道何时等待彼此。”毕方把信折好，没有把培训称作自己的失误。','“I saw one cook ease the fire and another wait a moment before taking the plate. A meal can be good because the people making it know when to wait for each other.” Bifang folds the letter without calling the training a failure.'),terminal=True,reading_ids=['bi_fang'])]})

events.append({'id':'sample_menu_encounter','status':'sample_only','title':bi('名字之外，碗里是什么','Beyond the name, what is in the bowl?'),
 'production_trigger':{'hook':'guest_menu_question','required_employee_id':'','conflict_group':'menu_information','requires_verified_recipe_metadata':True},
 'source_ids':['b_shj_west','b_tpy_lawbeast_890','a_shenyi_eshou'],
 'initial':{'cash':240,'inventory':60,'liabilities':20,'profit':0},'start':'ask',
 'recipe_scope':{'sample_only':True,'dumplings':'示例面皮确认含小麦','plum_drink':'示例明确用水、乌梅、糖；售价6，成本2；交叉接触未核实，不作过敏安全承诺','guest':'饮食计划避小麦，客人明确不是严重过敏；不得外推所有顾客'},
 'nodes':[
 node('ask',bi('旅人 Lin 的问题','Lin has a question'),bi('Lin 已为一份订单预付20：“Faceless Dumplings 是说没有面粉吗？我需要避开小麦。”讹兽正想讲帝江的故事，獬豸抬手：“先听清她要问什么。”','Lin has prepaid 20 for an order. “Does Faceless Dumplings mean there is no flour? I need to avoid wheat.” Eshou is ready with a story about Dijiang, but Xiezhi pauses. “Let us understand the question first.”'),[
 option('ask_need','先确认饮食需求，再查面皮与用料','Ask about the need, then check the wrapper and ingredients','verify')]),
 node('verify',bi('先把需要听清','Understand the need first'),bi('Lin：“我是按自己的饮食计划避开小麦，不是严重过敏。请告诉我确切用料。”示例配方单确认：饺子面皮含小麦；酸梅饮用水、乌梅与糖，售价6、成本2。交叉接触未核实，不能承诺过敏安全。','Lin says, “I am avoiding wheat as part of my own eating plan, not because of a severe allergy. Please tell me the exact ingredients.” This sample recipe sheet lists wheat in the dumpling wrapper. The plum drink contains water, smoked plum and sugar; price 6, cost 2. Cross-contact has not been checked: no allergy-safe promise can be made.'),[
 option('explain','清楚说明，并让 Lin 选择下一步','Explain clearly and let Lin choose what happens next','choose')]),
 node('choose',bi('名字讲来处，原料说清楚','A name tells a story; ingredients need clarity'),bi('你说明“无面”来自帝江无面目的形貌，不是无面粉。Lin 愿意自己判断这份明确的饮品配方，也接受不能确认其他替代菜。两种处理都可保留她的选择权。','You explain that “faceless” refers to Dijiang’s appearance, not to flour. Lin can decide about the clearly listed drink and understands that other alternatives cannot be confirmed. Either response respects that decision.'),[
 option('switch','经 Lin 确认改为酸梅饮：转收入6，退余款14，耗料成本2','With Lin’s agreement, switch to the plum drink: revenue 6, refund 14, ingredients 2','switch_result',[
 tx('refund_balance','退还未使用预收款14','Refund unused prepayment of 14',cash=-14,liabilities=-14),
 tx('recognize_sale','预收款6转为本次收入','Recognize 6 of prepayment as revenue',liabilities=-6,profit=6),
 tx('consume_drink','本次饮品耗料成本2','Ingredients used for the drink: 2',inventory=-2,profit=-2)]),
 option('cancel','不勉强换单：取消未履行订单，退还预收款20','Do not press for a substitute: cancel the unfulfilled order and refund the 20 prepayment','cancel_result',[
 tx('refund_all','退还预收款20，不冲减尚未确认的收入','Refund 20 of prepayment; no revenue had yet been recognized',cash=-20,liabilities=-20)])]),
 node('switch_result',bi('一页菜牌，两个问题','One menu, two different questions'),bi('Lin 端起自己选定的饮品。讹兽在故事旁加上实料栏，没把原来的故事划掉。獬豸保存了这次用料核对与换单记录。','Lin accepts the drink she chose. Eshou adds an ingredient panel beside the story rather than crossing the story out. Xiezhi keeps the ingredient check and the agreed order change.'),[
 option('letter','查看回访','Read the follow-up','switch_letter')]),
 node('cancel_result',bi('没有一碗饭，也能认真待客','Hospitality can include an honest no'),bi('你退还未履行订单的预收款20，没有把它当成已赚到的钱。Lin 感谢清楚的说明。小馆把未确认的配方列入复核，而不是马上贴上“人人都能吃”。','You refund the 20 prepayment for an order not fulfilled; it was never money earned. Lin appreciates the clear answer. The inn marks uncertain recipes for review rather than declaring them suitable for everyone.'),[
 option('letter','查看回访','Read the follow-up','cancel_letter')]),
 node('switch_letter',bi('回信里也有一个名字','A name in the reply'),bi('“我回去查了那位没有眉眼、却识歌舞的神。你们先说明用料，我才有心情听懂它的名字。下次我想带一份家里的食谱来，一起看看能做什么。”','“I looked up the god without a distinct face who understands song and dance. Because you explained the ingredients first, I had room to hear its name. Next time I would like to bring a recipe from home and see what we might make together.”'),terminal=True,reading_ids=['di_jiang']),
 node('cancel_letter',bi('给下次留一个确切的约定','A clear promise for next time'),bi('Lin 寄来自己常做的一份谷物食谱：“不用急着说一定可以。先把材料核对好；若合适，我们再约。”小馆把来信夹在待试菜单里，尚未核实就不提前上架。','Lin sends a grain recipe she often makes. “You do not need to promise it will work. Check the ingredients first; if it suits, we can arrange another visit.” The inn keeps it with the recipes to review, without listing an unverified dish for sale.'),terminal=True,reading_ids=['di_jiang'])]})

events.append({'id':'sample_dangkang_harvest','status':'sample_only','title':bi('听见丰年之后','After the harvest call'),
 'production_trigger':{'hook':'dangkang_existing_discount','required_employee_id':'dang_kang','conflict_group':'dangkang_discount','use_current_period_config':True},
 'source_ids':['a_sh_east'],'initial':{'cash':240,'inventory':60,'liabilities':0,'profit':0},'start':'market',
 'nodes':[
 node('market',bi('门前的谷袋','Grain sacks at the door'),bi('当康喊着自己的名字，粮商把折扣谷物搬到门前。买入这一批需80。你手头现金240，库存账面60；明天仍有日常开支。丰收并不替你决定怎么买。','Dangkang calls its own name as a trader brings discounted grain to the door. This batch costs 80. You hold cash of 240 and inventory worth 60, with ordinary bills still ahead. A harvest does not decide your budget for you.'),[
 option('buy','买入80：现金转为同额存货，暂不算费用','Buy for 80: move cash into inventory; no expense yet','after_buy',[tx('purchase','买粮入库80','Purchase grain into inventory: 80',cash=-80,inventory=80)]),
 option('hold','暂留现金，不采购这批折扣粮','Keep the cash; pass on this batch','after_hold')]),
 node('after_buy',bi('谷袋到了以后','Once the sacks arrive'),bi('现金变成160，库存变成140，事件利润仍为0。街坊问能否为共同的晚饭匀出一点食材。你可以赠出成本12的一份，也可以留作明日备料。','Cash is now 160, inventory 140, and event profit remains 0. A neighbour asks whether a little grain can help a shared supper. You may give ingredients costing 12 or keep them for tomorrow’s service.'),[
 option('gift','赠出账面成本12的食材：库存与利润各减少12','Give ingredients costing 12: inventory and profit each fall by 12','gift_result',[tx('gift_cost','食材赠出按账面成本12计本次支出','Gift ingredients at their carrying cost of 12',inventory=-12,profit=-12)]),
 option('reserve','留作明日备料，不新增支出','Reserve them for tomorrow; no further expense','reserve_result')]),
 node('after_hold',bi('没有买粮，也能回应','A response without a purchase'),bi('你把明日现金需求写给当康看。它有些遗憾，但没有把谨慎说成吝啬。街坊问起晚饭，你们可以分享一条余粮联络消息，或约好以后再问。','You show Dangkang tomorrow’s cash needs. It is disappointed, but does not call caution stinginess. When a neighbour asks about supper, you can share a contact for surplus grain or arrange to check again another day.'),[
 option('share_contact','分享已核实的余粮联络方式（不扣钱、不赠库存）','Share a checked contact for surplus grain (no cash or stock used)','contact_result'),
 option('revisit','约定下次再看余量，不作无法履行的承诺','Offer to check next time; make no promise you cannot keep','revisit_result')]),
 node('gift_result',bi('回信：一袋粮的一小部分','Reply: a little from one sack'),bi('库存128，现金160，事件利润-12。街坊来信说晚饭多坐了两个人，并附了一种家乡谷物粥的做法。当康把那张食谱放到米袋上，没有把回信折算成额外收入。','Inventory is 128, cash 160, event profit -12. The neighbour writes that two more people joined supper, adding a recipe for a grain porridge from home. Dangkang lays it on a sack without turning the letter into extra revenue.'),terminal=True),
 node('reserve_result',bi('回信：明早有饭','Reply: food for the morning'),bi('库存140，现金160，事件利润0。次日，当康先把需用的米量清点好。小馆没有收到赠粮回信，却守住了明日的备料。下一次丰年仍有新的选择。','Inventory is 140, cash 160, event profit 0. Next day Dangkang checks the rice needed for service. There is no gift letter, but tomorrow’s ingredients are ready. The next harvest will bring another choice.'),terminal=True),
 node('contact_result',bi('回信：也谢谢那条消息','Reply: thank you for the lead'),bi('现金240，库存60，没有虚构赠粮支出。街坊找到了合适的余粮：“那条消息帮了忙。下次若你们需要人手，也告诉我们。”这是来信承诺，正式游戏须后续事件才会发生，不能立刻凭空加员工。','Cash stays 240 and inventory 60; no imaginary donation is expensed. The neighbour found suitable surplus grain. “That lead helped. If you need a hand another day, let us know.” This is a promise in a letter, not an employee granted out of nowhere.'),terminal=True),
 node('revisit_result',bi('回信：下一次再商量','Reply: we will ask next time'),bi('现金240，库存60，事件利润0。当康仍期待丰收，却也记住了预算上的留白。街坊约好改日再问，食肆不因这次保留现金而被贴上冷漠的标签。','Cash is 240, inventory 60 and event profit 0. Dangkang still hopes for a harvest, while remembering the room needed in a budget. The neighbour will ask another day; keeping cash has not labelled the inn unkind.'),terminal=True)]})

source_ids=set()
for e in profiles:
    source_ids.update(e['source_ids']);source_ids.update(q['source_id'] for q in e['quotes'])
for e in events:source_ids.update(e['source_ids'])
sources=[copy.deepcopy(e) for e in editorial['sources'] if e['id'] in source_ids]
sample={'schema_version':1,'status':'sample_only','languages':['zh-CN','en'],
 'notice':bi('独立策划交互样例：不是正式游戏；不连接存档；点击下一幕不代表真实经营已经完成。','Standalone design prototype: not the production game; no game saves are connected. Advancing a scene does not complete a real service.'),
 'profiles':profiles,'events':events,'sources':sources,'regions':regions,
 'accounting_scope':bi('事件切片账表：仅含本事件变动，不代替完整营业账单。金额为示例游戏单位；期初净资产=现金+存货-负债，期末还需计入本事件利润。','Event-only accounts, not a full daily report. Amounts are sample game units. Opening net assets equal cash plus inventory minus liabilities; event profit explains the change.'),
 'provenance':{'classical_quotes':'copied_unchanged_from_current_editorial','new_scene_prose':'original_planning_samples_2026_10_30','new_external_research':False,'all_new_mechanics':'not_integrated_into_game'}}
dump('samples/content-samples.json',sample)
# Inline data: file:// works offline; no fetch, external dependencies, tracking or game access.
(HERE/'samples/sample-data.js').write_text('window.SHANHAI_SAMPLE = '+json.dumps(sample,ensure_ascii=False)+';\n')

schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'SH-CULTURE-R1 planning exchange',
 'type':'object','required':['schema_version','document_id','status','current_authorization','characters','dishes','guests','tasks','regions'],
 'properties':{'schema_version':{'const':1},'document_id':{'const':'SH-CULTURE-R1'},'status':{'const':'proposed'},
  'current_authorization':{'type':'object','required':['production_game_changes'],'properties':{'production_game_changes':{'const':False}}},
  'characters':{'type':'array','minItems':30,'maxItems':30,'items':{'$ref':'#/$defs/entity'}},
  'dishes':{'type':'array','minItems':25,'maxItems':25,'items':{'$ref':'#/$defs/entity'}},
  'guests':{'type':'array','minItems':6,'maxItems':6,'items':{'$ref':'#/$defs/entity'}},
  'regions':{'type':'array','minItems':4,'maxItems':4},
  'tasks':{'type':'array','minItems':1,'items':{'type':'object','required':['id','priority','title','status','depends_on','acceptance','discipline_review'],
   'properties':{'id':{'type':'string','minLength':1},'status':{'const':'proposed'},'priority':{'enum':['P0','P1','P2']},'depends_on':{'type':'array','items':{'type':'string'}},'acceptance':{'type':'array','minItems':2,'items':{'type':'string'}}}}}},
 '$defs':{'entity':{'type':'object','required':['id','name','status'],'properties':{'id':{'type':'string','minLength':1},'name':{'type':'string','minLength':1},'status':{'const':'proposed'}}}}}
dump('execution-plan.schema.json',schema)

doc=HERE/'修改意见策划案_AI可读版.md'
text=doc.read_text().split('## 22. 全员修改覆盖矩阵')[0]
text+='## 22. 全员修改覆盖矩阵\n\n所有列为待实施设计，当前已有部分在“既有与新增”中说明；具体原文见本项目文化读本。\n\n| ID/角色 | 文化/视觉锚点 | 愿望与矛盾 | 既有与新增 | 玩家行动 |\n| --- | --- | --- | --- | --- |\n'
for c in characters:text+=f"| {c['id']} / {c['name']} | {c['source_anchor']}；{c['proposed_visual']} | {c['desire_and_tension']} | {c['existing_and_delta']} | {c['decision']} |\n"
text+='\n## 23. 全菜品修改覆盖矩阵\n\n不改原 ID、基础配方或隐藏条件。过敏信息均需实际配方复核；“待核”不可自动填成安全。\n\n| ID/菜品 | 点餐说明方向 | 文化方向 | 经营/交流触点 |\n| --- | --- | --- | --- |\n'
for d in dish_matrix:text+=f"| {d['id']} / {d['name']} | {d['menu_information']} | {d['cultural_direction']} | {d['gameplay_touchpoint']} |\n"
text+='\n## 24. 特殊来客修改覆盖矩阵\n\n保留现有六位及遇见后阅读门槛。\n\n| ID/来客 | 具体需求 | 记忆依据 | 回访变化 |\n| --- | --- | --- | --- |\n'
for g in guest_matrix:text+=f"| {g['id']} / {g['name']} | {g['request']} | {g['memory']} | {g['return_feedback']} |\n"
text+='\n## 25. 任务验收总表\n\n所有任务当前为 proposed，网页样例完成不改变此状态。机器依赖图以 execution-plan.json 为准。\n\n| 任务 | 优先级 | 依赖 | 交付与验收 |\n| --- | --- | --- | --- |\n'
for t in tasks:text+=f"| {t['id']} | {t['priority']} | {', '.join(t['depends_on']) or '无'} | {t['title']}；{'；'.join(t['acceptance'])} |\n"
text+='\n## 26. 本次交付边界\n\n已完成的是本修改案、全量实体矩阵、机器任务表与六人/三事件的独立双语交互样例。没有改动正式游戏，没有进行新版本自然通关，没有真人跨文化试玩，没有新增史料联网核验。示例的美术说明属于后续修稿方向，不代表新立绘或动作已经画好。来源采用项目已有核实资料；新的饮食史与比较研究仍按后续任务验证。\n'
text+='\n## 27. 六位优先角色的美术与动作样例说明\n\n以下为待绘制的开发简报，不是已生成新美术。沿用水墨美型人形与像素小人一致的原则；先画识别草图再做完整资产，不因拟人化删除关键妖异形貌。\n'
for profile in profiles:
    text+='\n### '+profile['name']+' / '+profile['id']+'\n\n'
    for key,label in [('portrait','立绘'),('pixel','像素轮廓'),('idle_work','待机与工作'),('recognition_check','辨识验收')]:
        text+='- '+label+'：'+profile['art_design_brief'][key]+'\n'
doc.write_text(text)
(HERE/'修改意见策划案_AI可读版.txt').write_bytes(('\ufeff'+text).encode())
# A legible offline reading copy; no external markdown runtime.
(HERE/'策划案阅读.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>山海食肆物语 · 修改案 R1</title><style>body{max-width:1100px;margin:30px auto;padding:20px;background:#f7f3e8;color:#24362d;font:17px/1.9 system-ui,sans-serif}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}a{color:#235e52}</style><p><a href="samples/index.html">打开独立交互样例</a> · <a href="修改意见策划案_AI可读版.txt">文本版</a></p><pre>'+html.escape(text)+'</pre></html>')
print(json.dumps({'characters':len(characters),'dishes':len(dish_matrix),'guests':len(guest_matrix),'tasks':len(tasks),'profiles':len(profiles),'events':len(events),'sample_sources':len(sources),'plan_characters':len(text)},ensure_ascii=False))
