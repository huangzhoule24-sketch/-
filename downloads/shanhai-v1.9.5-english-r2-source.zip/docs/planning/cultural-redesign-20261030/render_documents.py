"""Render this proposal's limited Markdown syntax as offline HTML and editable DOCX."""
from pathlib import Path
import html, re

HERE=Path(__file__).resolve().parent
text=(HERE/'修改意见策划案_AI可读版.md').read_text()
def blocks():
    lines=text.splitlines(); i=0
    while i<len(lines):
        line=lines[i]
        if not line.strip():i+=1;continue
        if line.startswith('| '):
            rows=[]
            while i<len(lines) and lines[i].startswith('| '):
                row=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?',c) for c in row):rows.append(row)
                i+=1
            yield ('table',rows);continue
        m=re.match(r'^(#{1,4}) (.*)',line)
        if m:yield('heading',(len(m[1]),m[2]));i+=1;continue
        if line.startswith('- '):yield('bullet',line[2:]);i+=1;continue
        if re.match(r'^\d+\. ',line):yield('number',re.sub(r'^\d+\. ','',line));i+=1;continue
        if line.startswith('> '):yield('quote',line[2:]);i+=1;continue
        yield('paragraph',line);i+=1
def inline(s):
    s=html.escape(s)
    s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s)
    return s
body=[];toc=[];n=0
for kind,value in blocks():
    if kind=='heading':
        depth,title=value;n+=1
        body.append(f'<h{depth} id="s{n}">{inline(title)}</h{depth}>')
        if depth==2:toc.append(f'<a href="#s{n}">{html.escape(title)}</a>')
    elif kind=='table':
        body.append('<div class="table"><table><thead><tr>'+''.join('<th>'+inline(v)+'</th>' for v in value[0])+'</tr></thead><tbody>')
        body.extend('<tr>'+''.join('<td>'+inline(v)+'</td>' for v in row)+'</tr>' for row in value[1:])
        body.append('</tbody></table></div>')
    elif kind=='quote':body.append('<blockquote>'+inline(value)+'</blockquote>')
    elif kind in ['bullet','number']:body.append('<p class="item">'+('• ' if kind=='bullet' else '▸ ')+inline(value)+'</p>')
    else:body.append('<p>'+inline(value)+'</p>')
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>山海食肆物语 · 完整修改案 R1</title>
<style>html{scroll-behavior:smooth}body{margin:0;background:#f5f1e5;color:#243e35;font:17px/1.9 system-ui,sans-serif}header{background:#243e35;color:#fff4d5;padding:24px max(24px,calc((100vw - 1180px)/2));position:sticky;top:0;z-index:2}header a{color:#fff4d5;margin-right:20px}main{max-width:1180px;margin:30px auto;padding:0 24px 50px}h1,h2,h3{font-family:Georgia,"Noto Serif CJK SC",serif;line-height:1.5}h2{margin-top:52px;padding-top:18px;border-top:3px solid #b68a44;scroll-margin-top:100px}h3{scroll-margin-top:100px}p{max-width:970px}a{color:#2b6650}code{background:#e6e1d0;padding:2px 4px;overflow-wrap:anywhere;font-size:.9em}.table{overflow-x:auto;border:1px solid #d2c7a8;background:#fffdf7}table{width:100%;border-collapse:collapse;font-size:14px;min-width:800px}td,th{padding:12px;border:1px solid #ded5bf;vertical-align:top;min-width:90px}th{background:#e3dfcf}blockquote{border-left:4px solid #b68a44;margin:20px 0;padding:12px 20px;background:#fffdf7}.item{padding-left:18px}details{padding:18px;background:#e8e4d4}details a{display:block}summary{cursor:pointer}@media print{header,details{display:none}body{background:white;font-size:11pt}h2{break-after:avoid}.table{overflow:visible}table{min-width:0;font-size:8pt}td,th{min-width:0;padding:5px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}</style>
<header><a href="samples/index.html">打开交互样例</a><a href="修改意见策划案_AI可读版.txt">TXT</a><a href="山海食肆物语_修改意见策划案_R1.docx">可编辑 Word</a></header><main><details><summary>展开完整目录</summary>'''+''.join(toc)+'</details>'+''.join(body)+'</main></html>'
(HERE/'策划案阅读.html').write_text(page)

from docx import Document
from docx.shared import Inches, Pt, Cm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc=Document();section=doc.sections[0]
section.page_height=Cm(29.7);section.page_width=Cm(21)
section.top_margin=Cm(2);section.bottom_margin=Cm(2);section.left_margin=Cm(1.7);section.right_margin=Cm(1.7)
for name in ['Normal','Title','Heading 1','Heading 2','Heading 3','List Bullet','List Number']:
    style=doc.styles[name];style.font.name='Calibri';style._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'等线')
doc.styles['Normal'].font.size=Pt(10.5)
doc.styles['Normal'].paragraph_format.space_after=Pt(7)
def plain(s):return s.replace('**','').replace('`','')
for kind,value in blocks():
    if kind=='heading':
        depth,title=value
        doc.add_heading(plain(title),level=depth-1 if depth>1 else 0)
    elif kind=='table':
        table=doc.add_table(rows=0, cols=len(value[0]));table.style='Table Grid'
        for ridx,row in enumerate(value):
            cells=table.add_row().cells
            for cell,content in zip(cells,row):
                cell.text=plain(content)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(3)
                    for r in p.runs:r.font.size=Pt(8.5);r.bold=ridx==0
            if ridx==0:
                repeat=OxmlElement('w:tblHeader');table.rows[0]._tr.get_or_add_trPr().append(repeat)
        doc.add_paragraph()
    else:
        p=doc.add_paragraph(plain(value),style='List Bullet' if kind=='bullet' else 'List Number' if kind=='number' else 'Normal')
        if kind=='quote':p.paragraph_format.left_indent=Cm(.7)
doc.save(HERE/'山海食肆物语_修改意见策划案_R1.docx')
print('Rendered offline HTML and editable DOCX')
