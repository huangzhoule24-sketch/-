'use strict';
(() => {
  const D = window.SHANHAI_SAMPLE;
  let lang = 'zh-CN';
  try { lang = localStorage.getItem('shanhai-design-r1-language') === 'en' ? 'en' : 'zh-CN'; } catch (_) {}
  let tab = 'events', eventId = D.events[0].id, profileId = D.profiles[0].id;
  const states = new Map();
  const el = id => document.getElementById(id);
  const tr = value => typeof value === 'string' ? value : (value[lang] || value['zh-CN']);
  const T = (zh, en) => lang === 'en' ? en : zh;
  const escape = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const p = s => `<p>${escape(s)}</p>`;
  const button = (label, data = '') => `<button type="button" ${data}>${escape(label)}</button>`;
  const currentEvent = () => D.events.find(e => e.id === eventId);
  function stateFor(event) {
    if (!states.has(event.id)) states.set(event.id, {node:event.start, balance:{...event.initial}, journal:[], applied:[], history:[]});
    return states.get(event.id);
  }
  function choose(choiceId) {
    const event = currentEvent(), state = stateFor(event);
    const node = event.nodes.find(n => n.id === state.node);
    const choice = node.options.find(c => c.id === choiceId);
    if (!choice) return; // A stale click cannot select a choice at a different node.
    const next = {...state.balance}, journal = [...state.journal], applied = [...state.applied];
    for (const tx of choice.transactions) {
      const key = `${event.id}/${node.id}/${choice.id}/${tx.id}`;
      if (applied.includes(key)) continue;
      for (const k of ['cash','inventory','liabilities','profit']) next[k] += tx[k];
      if (next.cash < 0 || next.inventory < 0 || next.liabilities < 0) throw new Error('Invalid sample transaction');
      if (tx.cash + tx.inventory - tx.liabilities !== tx.profit) throw new Error('Unbalanced sample transaction');
      journal.push(tx); applied.push(key);
    }
    const equity = event.initial.cash + event.initial.inventory - event.initial.liabilities;
    if (next.cash + next.inventory - next.liabilities !== equity + next.profit) throw new Error('Unbalanced sample state');
    Object.assign(state,{node:choice.next,balance:next,journal,applied,history:[...state.history,choice.id]});
    render();
    el('scene-title')?.focus({preventScroll:true});
  }
  function ledger(event, state) {
    const b=state.balance, equity=event.initial.cash+event.initial.inventory-event.initial.liabilities;
    const fields=[['cash',T('现金','Cash')],['inventory',T('存货账面','Inventory')],['liabilities',T('负债 / 预收款','Liabilities / prepayment')],['profit',T('本事件利润','Event profit')]];
    return `<section class="ledger" aria-label="${T('事件账表','Event accounts')}"><h3>${T('这次选择，账上发生了什么','What changed in the accounts?')}</h3><div class="metrics">${fields.map(([k,title])=>`<div class="metric"><span>${title}</span><strong data-balance="${k}">${b[k]}</strong></div>`).join('')}</div><p class="note">${escape(tr(D.accounting_scope))}</p><details><summary>${T('展开交易与核对','Show transactions and reconciliation')}</summary><p>${T('期初净资产','Opening net assets')}: ${equity} · ${T('当前净资产','Current net assets')}: ${b.cash+b.inventory-b.liabilities} = ${equity} + ${b.profit}</p><div class="table-scroll"><table><thead><tr><th>${T('事项','Transaction')}</th>${fields.map(([,title])=>`<th>${title}</th>`).join('')}</tr></thead><tbody>${state.journal.length?state.journal.map(tx=>`<tr><td>${escape(tr(tx.label))}</td>${fields.map(([k])=>`<td>${tx[k]>0?'+':''}${tx[k]}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="5">${T('尚无本事件交易；期初余额不属于新收入。','No event transactions yet. Opening balances are not new income.')}</td></tr>`}</tbody></table></div></details></section>`;
  }
  function renderEvents() {
    const event=currentEvent(), state=stateFor(event), node=event.nodes.find(n=>n.id===state.node);
    return `<div class="grid"><aside class="sidebar" aria-label="${T('事件选择','Choose an event')}">${D.events.map((e,i)=>button(`${String(i+1).padStart(2,'0')} · ${tr(e.title)}`,`data-event="${e.id}" aria-pressed="${e.id===eventId}"`)).join('')}<p class="note">${T('可随时切换事件；重置只影响当前样例，不涉及游戏。','Switch events freely. Reset affects only this prototype, never the game.')}</p></aside><article class="card" data-node="${node.id}"><div class="eyebrow">${escape(tr(event.title))}</div><h2 id="scene-title" tabindex="-1">${escape(tr(node.title))}</h2><div class="story">${escape(tr(node.text))}</div>${node.terminal?`<p class="badge">${T('这一条分支已结束 · 可重置查看另一种选择','Branch complete · reset to try another choice')}</p>`:''}<div class="choices">${node.options.map(c=>button(tr(c.label),`data-choice="${c.id}"`)).join('')}</div><div class="toolbar">${(node.reading_ids||[]).map(id=>button(T('看看它从哪里来','Read its old-book origins'),`data-read="${id}"`)).join('')}${button(T('重置当前事件','Reset this event'),'data-reset="true"')}</div>${ledger(event,state)}<div class="end-mark">${T('山海相遇 · 行动 → 结果 → 回信 → 自愿阅读','AN ENCOUNTER · CHOICE → CONSEQUENCE → LETTER → OPTIONAL READING')}</div></article></div>`;
  }
  function renderProfiles() {
    const profile=D.profiles.find(x=>x.id===profileId);
    return `<div class="grid"><aside class="sidebar profile-nav">${D.profiles.map(e=>button(lang==='en'?e.name_en:e.name,`data-profile="${e.id}" aria-pressed="${e.id===profileId}"`)).join('')}</aside><article class="card"><div class="eyebrow">${escape(lang==='en'?profile.name_en:profile.name)} · ${T('新写作样例，未替换正式小传','New writing sample; existing reading remains unchanged')}</div><h2>${escape(tr(profile.title))}</h2><div class="story">${profile.paragraphs[lang].map(p).join('')}</div><div class="toolbar">${button(T('典籍里的原貌','A closer reading of the old texts'),`data-read="${profile.id}"`)}</div><p class="note">${T('本页没有新绘人物图。轮廓与动作修改方向见完整策划案和 JSON；文字样例不代表动作已经制作。','No new character art is shown here. Silhouette and motion directions are in the plan and JSON; prose does not mean animations have been made.')}</p><div class="pixel-land" aria-hidden="true"></div></article></div>`;
  }
  const regionEn={qianlai:['Qianlai','Pines, stones and a warm bowl','Qianyang · a mountain sheep with a horse-like tail','A first menu that explains both name and ingredients'],qingqiu:['Qingqiu','Tail shadows and calling birds','The nine-tailed fox · Guanguan','A clear menu and a visitor who remembers'],zhange:['Zhang’e','Blue-green stone and a watchful flame','Bifang · the one-legged firebird','A banquet with a real plan, not a fire spectacle'],danxue:['Danxue','Five colours and a shared table','Fenghuang · feathers carrying the five virtues','A meal achieved by cooperation, not merely rebirth']};
  function renderRegions() {
    return `<p class="notice">${T('四站为策划选编顺序，不是古书原有路线。这里只展示主题关联，尚未接入探索、订单或解锁。','This four-stop itinerary is a design selection, not a route prescribed by the old book. These cards show themes only; exploration, orders and unlocks are not connected.')}</p><div class="region-grid" style="margin-top:24px">${D.regions.map((r,i)=>`<article class="card"><div class="region-no">0${i+1}</div><h2>${escape(lang==='en'?regionEn[r.id][0]:r.name)}</h2><h3>${escape(lang==='en'?regionEn[r.id][1]:r.theme)}</h3><p>${escape(lang==='en'?regionEn[r.id][2]:r.employee_ids.map(id=>D.profiles.find(p=>p.id===id)?.name||({'guan_guan':'灌灌','feng_huang':'凤凰'}[id]||id)).join(' · '))}</p><p>${escape(lang==='en'?regionEn[r.id][3]:r.actual_action)}</p><div class="pixel-land" aria-hidden="true"></div></article>`).join('')}</div>`;
  }
  function openReading(id) {
    const profile=D.profiles.find(x=>x.id===id);if(!profile)return;
    el('reading-title').textContent=lang==='en'?profile.name_en:profile.name;
    el('close-reading').textContent=T('返回样例','Back to sample');
    el('reading-body').innerHTML=profile.quotes.map(q=>`<section class="source"><h3>${escape(lang==='en'?(q.source_label_en||q.source_label):q.source_label)}</h3>${lang==='zh-CN'?p(q.context||''):''}<blockquote>${escape(q.text)}</blockquote>${p(lang==='en'?q.translation:q.paraphrase)}</section>`).join('')+`<details><summary>${T('资料记录（可选）','Source records (optional)')}</summary>${profile.source_ids.map(sid=>D.sources.find(s=>s.id===sid)).filter(Boolean).map(s=>`<p><a href="${escape(s.url)}" target="_blank" rel="noopener noreferrer">${escape(lang==='en'?(s.work_en||s.title):s.title)}</a></p>`).join('')}</details>`;
    el('reading').showModal();
  }
  function render() {
    document.documentElement.lang=lang;
    document.title=T('山海食肆物语 · 山海相遇策划样例','Shanhai · Cultural Encounter Design Study');
    el('heading').textContent=T('把山海，请到同一张桌边','An inn between mountains and seas');
    el('subtitle').textContent=T('文化体验改造 R1 · 六位伙伴 / 三段相遇 / 四站驿路','Cultural design R1 · six companions / three encounters / four stops');
    el('lang').textContent=lang==='en'?'中文':'English';
    el('notice').textContent=tr(D.notice);
    el('tabs').innerHTML=[['events',T('相遇与选择','Encounters & choices')],['profiles',T('六位伙伴','Six companions')],['regions',T('山川与菜单','Places & menus')]].map(([id,title])=>button(title,`data-tab="${id}" aria-pressed="${tab===id}"`)).join('');
    el('view').innerHTML=tab==='events'?renderEvents():tab==='profiles'?renderProfiles():renderRegions();
    el('footer').textContent=T('独立离线原型 · 无外部依赖 · 不读写游戏存档 · 2026-10-30','Standalone offline prototype · no external dependencies · no game-save access · 2026-10-30');
  }
  el('lang').addEventListener('click',()=>{lang=lang==='en'?'zh-CN':'en';try{localStorage.setItem('shanhai-design-r1-language',lang);}catch(_){}render();});
  el('close-reading').addEventListener('click',()=>el('reading').close());
  document.addEventListener('click',e=>{
    const b=e.target.closest('button');if(!b)return;
    if(b.dataset.tab){tab=b.dataset.tab;render();}
    else if(b.dataset.event){eventId=b.dataset.event;render();}
    else if(b.dataset.profile){profileId=b.dataset.profile;render();}
    else if(b.dataset.choice)choose(b.dataset.choice);
    else if(b.dataset.reset){states.delete(eventId);render();}
    else if(b.dataset.read)openReading(b.dataset.read);
  });
  // Read-only inspection for prototype QA. Does not expose or modify the game.
  window.SHANHAI_DESIGN_QA=()=>JSON.parse(JSON.stringify({lang,tab,eventId,profileId,states:Object.fromEntries(states)}));
  render();
})();
