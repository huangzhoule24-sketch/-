# 《山海食肆物语》完整修改意见策划案 R1

2026-10-30。针对“怎样吸引不熟悉中国文化的玩家、怎样发挥山海特色、怎样让题材进入经营”的反馈编写。

核心主张：把**山川物产、异兽特征、经营选择与旅人回访**连接起来，让玩家在行动中认识文化。

## 阅读

1. 双击 `策划案阅读.html`，阅读完整策划；或用 Word 打开 `山海食肆物语_修改意见策划案_R1.docx`。
2. 双击 `samples/index.html`，查看独立交互样例。无需安装 Godot 或联网；若系统限制本地网页，可在本文件夹执行 `python3 -m http.server 8013`，访问 `http://127.0.0.1:8013/samples/index.html`。
3. 把 `修改意见策划案_AI可读版.md` 和 `execution-plan.json` 一起交给后续开发 AI；TXT 为带 UTF-8 BOM 的同内容备份。

完整方案包含：定位与玩家、现状差距、独创性检查、阶段 0–4 成长、前 20 分钟引导、30 员工、25 菜品、6 特殊来客的全量矩阵、四站驿路、神通改造、跨文化传播、三专业联动、UI/英语/美术/音频、存档契约、23 项依赖任务与验收、真人试玩与课程证据。

## 已制作的样例

- 六位伙伴的新写作样例：羬羊、毕方、帝江、九婴、九尾狐、烛龙；中英文，配现有完整原文与释意。
- 三个可点击事件、共八条结局分支：毕方宴席；帝江饺子菜牌误读；当康丰收采购与分享。
- 事件账表：可查看现金、存货、负债/预收款和利润，含培训、采购、赠粮、预付款转收入及退款。
- 四站主题卡：钱来山、青丘、章莪、丹穴，为策划选编顺序。

样例不包含新绘美术，不模拟真实行走、烹饪或排班，不连接游戏存档。文案中的下一幕用于审阅分支，不代表正式游戏任务已完成。原有游戏未改动。

## AI 与开发者文件

- `execution-plan.json`：全量实体、建议状态、任务依赖与验收。
- `execution-plan.schema.json`：机器数据结构约束。
- `baseline.json`：实际基线数量、代码提交与相关文件哈希。
- `reference-index.json`：54 条完整既有来源记录，供解析全部策划实体的 source_ids。
- `samples/content-samples.json`：双语角色、事件节点、交易与来源。
- `samples/sample-data.js`：与 JSON 内容一致的离线内嵌数据；网页不依赖 fetch。
- `build_exchange.py`：更新机器数据及生成正文覆盖矩阵；不编辑游戏文件。
- `render_documents.py`：生成易读 HTML 和可编辑 Word。
- `validate_bundle.py`、`validate_browser.cjs` 与 `validation/`：结构/账务和实际浏览器检查。

改机器数据时同步生成文件。当前重建命令（在游戏项目根目录运行）：

```sh
python3 docs/planning/cultural-redesign-20261030/build_exchange.py
python3 docs/planning/cultural-redesign-20261030/render_documents.py
python3 docs/planning/cultural-redesign-20261030/validate_bundle.py
```

Python 验证/渲染分别需要 `jsonschema`、`python-docx`，仅用于重建；阅读和使用网页无需安装。浏览器验证需要 Playwright、Chromium 及本地 HTTP 服务，端口见脚本。

## 状态与资料

新增生产机制全部标为 `proposed`，可运行网页仅标为 `sample_only`。本轮没有把课程目标记为已经在正式游戏达成。

典籍沿用项目此前核实的资料，十二条样例来源记录随 JSON 保存，原文逐字段保留。本轮未新增联网史料研究；角色对话和情境是此次原创，现代饮食史细节与新比较论断要在正式采用前另核。

实际检查结果与范围见 `validation/验证说明.md`。自动检查不等于真人喜欢、理解或跨文化传播已得到证明。
