/* Real browser interaction with the independent design sample, not the game. */
const {chromium}=require('playwright');
const fs=require('fs');const path=require('path');
(async()=>{
 const root=__dirname, data=JSON.parse(fs.readFileSync(path.join(root,'samples/content-samples.json')));
 const report=JSON.parse(fs.readFileSync(path.join(root,'validation/data-validation.json')));
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1360,height:1000}});
 const errors=[];let clicks=0;const checks=[];
 page.on('pageerror',e=>errors.push(String(e)));
 const assert=(v,label)=>{if(!v)throw new Error(label);checks.push(label);};
 const click=async selector=>{await page.locator(selector).click();clicks++;};
 await page.goto('http://127.0.0.1:8013/samples/index.html');
 const requestUrls=[];page.on('request',r=>requestUrls.push(r.url()));
 for(const lang of ['zh-CN','en']){
  const actual=await page.evaluate(()=>window.SHANHAI_DESIGN_QA().lang);
  if(actual!==lang)await click('#lang');
  await click('[data-tab="events"]');
  for(const branch of report.terminal_paths){
   await click(`[data-event="${branch.event_id}"]`);await click('[data-reset]');
   for(const choice of branch.choices)await click(`[data-choice="${choice}"]`);
   const state=await page.evaluate(()=>{const q=window.SHANHAI_DESIGN_QA();return q.states[q.eventId];});
   assert(state.node===branch.terminal,lang+'/'+branch.terminal+' reached by clicks');
   assert(JSON.stringify(state.balance)===JSON.stringify(branch.balance),lang+'/'+branch.terminal+' accounts correct');
   assert(await page.locator('[data-choice]').count()===0,lang+'/'+branch.terminal+' stops');
   // Opening the accounts is a real operation; source reading must not alter state.
   await page.locator('summary').first().click();clicks++;
   const r=page.locator('[data-read]');
   if(await r.count()){
    const before=JSON.stringify(state);await r.first().click();clicks++;
    assert(await page.locator('#reading').isVisible(),lang+'/'+branch.terminal+' optional reading opens');
    await click('#close-reading');
    const after=await page.evaluate(()=>{const q=window.SHANHAI_DESIGN_QA();return q.states[q.eventId];});
    assert(JSON.stringify(after)===before,lang+'/'+branch.terminal+' reading has no account effect');
   }
  }
  await click('[data-tab="profiles"]');
  for(const profile of data.profiles){
   await click(`[data-profile="${profile.id}"]`);
   assert((await page.locator('.story').innerText()).includes(profile.paragraphs[lang][0]),lang+'/'+profile.id+' prose appears');
   await click(`[data-read="${profile.id}"]`);
   assert(await page.locator('#reading-body blockquote').count()===profile.quotes.length,lang+'/'+profile.id+' all quotations');
   await click('#close-reading');
  }
  await click('[data-tab="regions"]');
  assert(await page.locator('.region-grid article').count()===4,lang+' four region cards');
 }
 await page.reload();
 assert(await page.evaluate(()=>window.SHANHAI_DESIGN_QA().lang)==='en','language preference survives reload');
 // Return to Chinese for representative captures.
 await click('#lang');await click('[data-tab="events"]');
 await click('[data-event="sample_bifang_banquet"]');
 await page.screenshot({path:path.join(root,'validation/01-encounter-desktop.png'),fullPage:true});
 await click('[data-choice="small"]');await click('[data-choice="read_letter"]');
 await page.screenshot({path:path.join(root,'validation/02-bifang-letter.png'),fullPage:true});
 await click('[data-tab="profiles"]');await click('[data-profile="xian_yang"]');
 await click('[data-read="xian_yang"]');
 await page.screenshot({path:path.join(root,'validation/03-qianyang-reading.png')});await click('#close-reading');
 for(const viewport of [{width:844,height:390},{width:390,height:844}]){
  await page.setViewportSize(viewport);await click('[data-tab="events"]');
  await click('[data-event="sample_menu_encounter"]');await click('[data-reset]');
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),viewport.width+' no page horizontal overflow');
  await click('[data-choice="ask_need"]');await click('[data-choice="explain"]');
  await click('[data-choice="switch"]');await click('[data-choice="letter"]');
  await click('[data-read="di_jiang"]');
  await page.locator('#reading').evaluate(d=>{d.scrollTop=d.scrollHeight;});
  const r=await page.locator('#close-reading').boundingBox();
  assert(r&&r.y>=0&&r.y+r.height<=viewport.height,viewport.width+' reading back stays visible');
  await click('#close-reading');
  const b=await page.evaluate(()=>{const q=window.SHANHAI_DESIGN_QA();return q.states[q.eventId].balance;});
  assert(b.cash===226&&b.inventory===58&&b.liabilities===0&&b.profit===4,viewport.width+' narrow ledger correct');
  await page.screenshot({path:path.join(root,`validation/04-narrow-${viewport.width}.png`),fullPage:true});
 }
 assert(errors.length===0,'no browser script errors');
 assert(requestUrls.every(u=>u.startsWith('http://127.0.0.1:8013/')),'no external requests during sample use');
 fs.writeFileSync(path.join(root,'validation/browser-validation.json'),JSON.stringify({passed:true,clicks,checks:checks.length,errors,terminal_paths_by_language:16,note:'Actual Chromium clicks on standalone prototype over localhost HTTP. file:// is blocked by this environment policy and was not tested. Does not verify Godot integration or human understanding.',details:checks},null,2)+'\n');
 await browser.close();console.log(JSON.stringify({passed:true,clicks,checks:checks.length,errors}));
})().catch(e=>{console.error(e);process.exit(1);});
