"""Package only the reviewable planning folder; never exports game or Git history."""
from pathlib import Path
import hashlib, json, zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OUT=ROOT/'build/culture-redesign-r1-20261030'
OUT.mkdir(parents=True,exist_ok=True)
files={}
for p in sorted(HERE.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    rel=p.relative_to(HERE).as_posix()
    if rel.startswith('.') or any(x.startswith('.') for x in Path(rel).parts):continue
    files[rel]=p.read_bytes()
assert 'samples/index.html' in files and 'execution-plan.json' in files
manifest={name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in files.items()}
files['FILE-MANIFEST.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
files['SHA256SUMS.txt']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in files.items()).encode()
zip_path=OUT/'shanhai-culture-redesign-r1-complete.zip'
prefix='Shanhai-Culture-Redesign-R1-20261030/'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in files.items():z.writestr(prefix+name,raw)
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    for name,raw in files.items():assert z.read(prefix+name)==raw
for src,dest in [('修改意见策划案_AI可读版.md','shanhai-culture-redesign-r1.md'),('山海食肆物语_修改意见策划案_R1.docx','shanhai-culture-redesign-r1.docx')]:
    (OUT/dest).write_bytes((HERE/src).read_bytes())
artifacts={}
for p in OUT.iterdir():
    if p.suffix in ['.zip','.md','.docx']:
        raw=p.read_bytes();artifacts[p.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'artifact-manifest.json').write_text(json.dumps({'document_id':'SH-CULTURE-R1','bundle_files':len(files),'artifacts':artifacts},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'bundle_files':len(files),'artifacts':artifacts},ensure_ascii=False))
