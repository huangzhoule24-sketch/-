# 山海食肆物语 · 文化体验改造 SH-CULTURE-R1

本版以用户确认的 v1.9.5 源码为基础，将完整修改案落实到经营流程。原阶段0–4、30员工、25菜、6特殊来客、原文学读本和54段典籍摘录保留。四站驿路是游戏选编线索，不是《山海经》原有的一条旅行路线，也不影响原主线通关。

## 怎么体验

欢迎页选择中文或English，开始完整经营，完成原有首单教学。文化内容不要求先读书，也不要求抽到稀有卡。

1. **更多 → 山海驿路**：查看钱来、青丘、章莪、丹穴四站，以及当前可处理的相遇。没到条件可以稍后回来。三笔热汤付款后有一封毕方访客来信，不赠送卡牌或技能。
2. **菜牌说明**：25道菜分开介绍名字、用料、风味和仍需核实的复合成分。菜单本身也有用料文字与“用料与菜名说明”按钮。无面饺子有面皮，“无面”指帝江形貌；羬羊等是冠名伙伴，并不把员工当原料。
3. **角色特征**：30位伙伴各有特色、愿望和一项经营选择。可进一步阅读原有完整中英小传与典籍。重点重绘羬羊、毕方、帝江、九婴、九尾狐、烛龙，立绘仍为水墨，场景小人为像素。
4. **山海来信**：读实际履约后次日寄来的信，查看事件账目、核查记录和六类熟客记忆。来客提问与带来的家乡做法进入交流，不按国籍替人决定口味。

## 三次相遇

- **毕方炉边宴**：阶段1、毕方当班、烤翅研发且有炉灶时出现。小席共3份，首轮2份完成付款后再做余下1份；另一方案花30、用60游戏分钟培训毕方，之后完成5份真实付款。培训期间暂停其正常工作，培训后仅本次宴席烤翅工时×0.95。原火灾机制继续存在，没有额外重复抽取或阅读免灾。
- **名字之外，碗里是什么**：首单和基础教学后，Lin带来一份菜牌并提出饮食需要。记录20预收，听清避小麦的个人计划，再核对用料、确认换为酸梅汤或退款。换单需真实库存、座位、营业与自动服务，不能点击“完成”跳过。配料未知项照常保留。
- **听见丰年之后**：当康当班且到实际配置的第5天周期时出现。用80采购实际普通库存或留现金；买后可按账面成本12赠粮或留用，没买则分享联络线索或约定再问。不会把未发生的采购、礼物或回信变成收益。

**账目**：采购是现金转库存，赠粮是库存转费用；预收款履约前为负债，退款冲回负债。真正销售与成本仍由原结账系统各记一次。事件小账表额外列现金、存货、应收、负债、利润，用来解释业务，不另加一份销售收入。

## 后期经营

九婴的“同席协调”需要实际当班及3个已安装炉灶，三个任务分别占用设备并消耗原料、体力；可选逐份出餐。帝江只在原传菜特例中跨越路径，仍保留交接工时，托盘旁两段不闪烁的色标显示交接进度，其他工作照常行路。烛龙预约夜席复用原每日一次的时段客流神通，不推动时钟、不绕过打烊；240分钟内3份由烛龙烹调并付款的拉面才算履约。可减少光效。

开设分店后可选择已完成驿路的主题菜单；只从现有成品库存里选菜，主题缺货时回用常规有货菜单。英招实际探索返回才有带入库明细和归来日的信。领取原厨神冠军剧情后，可收到按本局真实订单、来客和驿路数量写成的散席回顾；没有新增结局门槛。

## 开发与资源替换

Godot 4.6.3；直接打开project.godot。存档仍为schema5，新增culture_experience.version1命名空间，不清空原进度。语言偏好独立保存，不参与随机数或经营存档。

- 内容源：tools/build_cultural_experience.py → config/cultural_experience.json；原文学源docs/culture-research/player-edition.json保持独立。
- 场景短句：config/experience.json中的personal_thoughts与personal_thoughts_en覆盖30位伙伴，保留既有低频率/避让逻辑。
- 全局英语：tools/localization_en.py、localization_events.py及相关配置中的_en字段 → tools/build_localization.py → config/localization.json。不联网实时翻译，原典原字不会被全局语言替换。
- 新美术母图：art-source/masters/cultural_r1_*及art-source/cultural-r1-inputs.json；完整重建入口bash tools/rebuild_all_art.sh，依次执行原全量和新六人选择性构建。仅运行旧build_art_pack会覆盖新稿，请用统一入口。
- 外置美术：程序旁CustomAssets/Portraits、Sprites、UI、Map、Items、FX，旧目录继续兼容；网页用系统中的资源导入。内置assets/art与统一AssetCatalog接口保留。详见美术接入说明。
- 动作：四方向基础图经有界像素绑定烘焙为原14400帧格，飞行/爬行/步行不同；不是14400张逐帧手绘。身体上下≤1源像素、脚抬起≤2源像素，设备不随手持物生成。
- 音频仍为既有42文件和28类音效/2类环境声，外置CustomAudio与四总线保留；独立配乐未导入。

源码分为**Source.zip与art-masters.zip**，两包解压到同一个目录即为完整可编辑工程；游戏运行只需对应Windows或Web包。分包是为了公开下载站单文件100MiB限制，母图没有丢弃。

## 验证范围

自动规则、存读档、原生界面、英语页面遍历和浏览器实际点击的结果见docs/cultural-redesign-validation.md。技术检查不能证明外国玩家已经理解或更喜爱中华文化。真人两轮试玩、三位专业同学的最终审校仍需真实参与者；docs/course-r1提供中英任务、记录表、专业审校和AI改稿证据模板，不含虚构受试者或虚构效果数字。Windows只作导出与文件完整性验证，未宣称Windows实机试玩。

## English quick start

Choose English on the welcome screen. Serve a first guest through the opening guide, then open More → The Shanhai Road. Companions, Menu Notes and Letters are available before rare recruitment. A prepayment is held until a real visit; a failed visit is refunded. Replies follow the actual game clock, and overnight advancement may pause for events or daily accounts. Back preserves the previous page; another Back returns to More. Save in Settings & Saves.

Unpack the source ZIP and art-masters ZIP into the same directory for the complete editable project. Runtime art is already in the source core. Human cultural evaluation, Windows-native testing and physical-phone testing remain pending.
