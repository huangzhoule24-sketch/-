# 当前源码版本与资源交付 · 2026-10-31

用户上传 `shanhai-v1.9.5-culture-origins-source.zip`，要求以此作为当前最新版本并返回对应游戏资源。随后用户提供 SHA256 与 [source-20261031 Release 直接下载链接](https://github.com/huangzhoule24-sketch/-/releases/download/source-20261031/shanhai-v1.9.5-culture-origins-source.zip)。已实际下载并验证，现以该链接指定的源码作为当前基线。10 月 30 日文化体验改造提案仍是待实施方案。

## 链接源码已验证：当前有效结论

下载 99,694,644 字节，SHA256 与用户提供的 `e244cef74629a343dc0bb1bfc1f4390ddbc6299a46167ea310a5a2e89d0fdbf9` 一致；ZIP CRC、重复路径、绝对路径/越级路径与符号链接检查通过。归档 1,462 项，与项目保存的原始 ZIP **逐字节相同**。814 个游戏文件逐文件对比零差异，游戏指纹亦一致。

用户此前表示修改过文件，但本次给定链接中的实际文件与原归档完全相同，未发现额外修改。本次按最后明确指定并成功取得的文件采用基线，不再等待导入，也不声称合并了新的代码改动。当前游戏文件已经与该源码一致，保留后续项目记忆与独立策划文档，无需用旧文档覆盖新记录。

因此下列匹配运行包与资源包即为此源码对应交付，无需重编译或重制资产。下载证据为 `release-source-verification.json`，本轮重新回读三个公开下载的结果为 `release-confirmed-downloads.json`，均位于 `docs/validation-artifacts/source-baseline-20261031/`。

## 先前附件读取限制（历史，现已通过链接解决）

此前 `download_file` 返回附件超过工具 32 MiB 传输上限，因而未根据同名推断内容相同，向用户索取直接链接。该限制现已通过用户提供的 Release 链接解决；采用依据是本次实际下载及哈希、字节对比结果，不是文件名猜测。

同名原始源码归档 99,694,644 字节，SHA256：

```
e244cef74629a343dc0bb1bfc1f4390ddbc6299a46167ea310a5a2e89d0fdbf9
```

其 814 个游戏文件与当前工程逐文件一致；从归档独立计算的游戏指纹为：

```
cd9afc7c850b64c8971f5402f558c4332bd52614ae4128888969e7e1cd7d721b
```

Windows 51 项、网页 59 项导出回执文件均逐一核对，指向该源代码指纹。沿用匹配的现有导出包，无需重新编译或改变游戏版本号。若以后提供与此包不同的变更，再据实际内容更新。

## 当前指定源码对应交付

- [Windows 可玩包](https://github.com/huangzhoule24-sketch/-/raw/83b42ab5a8a928174157aa683176a859bc458792/downloads/shanhai-v1.9.5-culture-origins-windows.zip)：65,304,053 字节，SHA256 `88e54e70f667e2310efe2a308e048840db0c00afbeabbdf253937c9c9dffa179`。
- [网页运行包](https://github.com/huangzhoule24-sketch/-/raw/3ddf71113e7fd6ad1850e8249d9e0126f240d073/downloads/shanhai-v1.9.5-culture-origins-web.zip)：38,767,124 字节，SHA256 `e4b1e266253826422f58d003f2f65ae0409212ae16d3aaf7a37ed87d92b6dffd`。
- [可编辑资源包](https://github.com/huangzhoule24-sketch/-/raw/3ddf71113e7fd6ad1850e8249d9e0126f240d073/downloads/shanhai-v1.9.5-culture-origins-resources.zip)：80,358,197 字节，SHA256 `de94fa81b213daa1d474fd75125bf264b25ac74e7692a80c521282dcd45464f8`。

资源包直接从上述已保存源码归档提取，共 780 项，保留所有选中原资源字节与许可：274 张内置 PNG、22 张美术母图、42 个音效/环境声，另含字体、图集映射、当前经营与文化配置、CustomAssets/CustomAudio 接口和维护文档。音乐槽保持原状；独立试听音乐不加入。

资源包构建工具为 `tools/package_baseline_resources.py`，输入归档 SHA 固定；它不修改源代码或原运行包。公开资源/Web 下载分支为 `source-baseline-v1.9.5-20261031`，独立根提交 `3ddf71113e7fd6ad1850e8249d9e0126f240d073`，仅含两份 ZIP、说明与校验，不公开开发历史。Windows 沿用之前不可变的匹配发布地址。

Windows 包全部解压，运行 `shanhai-v1.9.5-culture-origins.exe`，保留同级 PCK、CustomAssets、CustomAudio 和 licenses。网页包全部解压，运行 `python serve.py`，再访问 `http://127.0.0.1:8000/`。独立资源包供编辑，不是单独可玩的程序。

## 本轮验证范围

三个下载均实际无登录 HTTP 200、长度/SHA256/ZIP CRC 校验通过；资源包清单逐文件核对、Windows/Web 回执逐文件核对。既有 30 员工、25 菜、6 特殊来客和全部文学文化内容保留。

从网页运行 ZIP 新解压的目录启动服务，Chromium 实际 77 次点击/滚动、9 项检查、0 脚本错误，覆盖真实开局首单、中英文化页、羬羊典籍/古注、耳鼠罕见字、菜品阅读、刷新后继续、英文偏好与 844×390 返回。未声称本轮做了 Windows/手机实机、全程自然通关或真人传播效果测量。

结构化证据：`docs/validation-artifacts/source-baseline-20261031/`。本轮未修改正式游戏脚本、经营配置或美术资源。
