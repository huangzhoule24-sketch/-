/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8019').replace(/\/$/, '');
const out = process.argv[2] || 'build/culture-r1-browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      if(!id.startsWith('event:')&&!id.startsWith('daily:')&&id!=='panel:close'){
        if(s.panel==='事件'){
          const choice=s.buttons.find(x=>x.qa_id.startsWith('event:')&&x.qa_id!=='event:open'&&!x.disabled);
          if(choice){await click(choice.qa_id);continue;}
        }
        if(s.panel==='事件结果'){await click('panel:close');continue;}
        if(s.panel==='今日收支结算'){await click('daily:ack',true);continue;}
        if(id.startsWith('full:open:')&&s.panel!=='更多'){await click('nav:更多');continue;}
      }
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function sceneReady() {
    for(let attempt=0;attempt<10;attempt++){
      const s=await state();if(!s.panel)return;
      const event=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id.endsWith(':1'))||s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
      if(event)await click(event.qa_id);
      else if(s.buttons.some(b=>b.qa_id==='panel:close'&&!b.disabled))await click('panel:close');
      else throw Error('Unresolved natural interruption during pickup verification: '+s.panel);
    }
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  async function eventually(predicate,timeout=120000){
    const until=Date.now()+timeout;
    while(Date.now()<until){
      const s=await state();if(predicate(s))return;
      fs.writeFileSync(path.join(out,'live-state.json'),JSON.stringify({panel:s.panel,paused:s.paused,minute:s.state.total_minutes,booking:s.state.culture_experience.booking}));
      if(s.panel==='事件'){
        const b=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id!=='event:open');
        if(b)await click(b.qa_id);
      }else if(s.panel==='事件结果')await click('panel:close');
      await page.waitForTimeout(250);
    }
    throw Error('Real service did not reach its expected outcome');
  }
  try{
    receipt=await(await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('locale:en');
    if((await state()).interface_language!=='en')throw Error('Global English did not activate');
    await shot('01-english-welcome');await click('start:full');
    await page.setViewportSize({width:844,height:390});await sync();await shot('01b-mobile-guide');
    const mobileGuide=await state(),ack=mobileGuide.buttons.find(b=>b.qa_id==='tutorial:ack'&&!b.disabled);
    checks.push({label:'English opening guide keeps its confirmation visible at 844×390',ok:!!ack&&ack.rect.x>=0&&ack.rect.y>=0&&ack.rect.x+ack.rect.w<=845&&ack.rect.y+ack.rect.h<=391});
    await page.setViewportSize({width:1440,height:900});await sync();await click('tutorial:ack');
    await click('nav:员工');await shot('02-english-staff');await click('panel:close');await click('tutorial:ack');
    await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');
    if((await state()).panel)await click('panel:close');
    await eventually(s=>s.state.served>=1);
    if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');
    await click('tutorial:ack');await click('tutorial:destination');await shot('03-first-accounts');await click('tutorial:ack');await click('panel:close');
    checks.push({label:'English tutorial completes through an actual paid first order and real bill preview',ok:(await state()).state.tutorial.finished});
    await click('nav:更多');await click('full:open:菜牌说明',true);await shot('04-menu-ingredients');
    if((await state()).panel!=='菜牌说明')throw Error('Menu explanation not connected');
    await shot('05-menu-notes');await click('culture:tab:Companions');await click('culture:companion:di_jiang');await shot('06-dijiang');
    await click('culture:companion:reading');await shot('07-origins-english');await wheel(20000);await shot('07b-original-quotes');await click('culture:back');
    if((await state()).panel!=='角色特征')throw Error('Cultural reading lost its new parent');
    await click('culture:tab:The Shanhai Road',true);await shot('08-lin-question');
    const cash=(await state()).state.cash;
    await click('culture:choose:menu:accept');
    if((await state()).state.cash!==cash+20)throw Error('Deposit was not real');
    await click('culture:choose:menu:verify');await shot('09-menu-evidence');await click('culture:choose:menu:switch');
    await click('panel:close');
    if((await state()).paused)await click('time:pause');
    await eventually(s=>['served','refunded'].includes(s.state.culture_experience.booking.status),150000);
    const bookingOutcome=(await state()).state.culture_experience.booking.status;
    checks.push({label:'Lin’s real order reaches a recorded outcome, with fulfilment or an actual refund',outcome:bookingOutcome,ok:true});
    await shot('10-lin-paid');
    await click('nav:更多');await click('full:open:账单',true);await click('bill:settle');await shot('11-first-settlement');
    if((await state()).panel==='今日收支结算')await click('daily:ack',true);
    else if((await state()).panel)await click('panel:close');
    await click('nav:更多');await click('full:open:账单',true);
    await click('next:day',true);
    if((await state()).panel==='今日收支结算')await click('daily:ack',true);
    else if((await state()).panel)await click('panel:close');
    // A midnight settlement and the following 06:00 boundary can both stop
    // the clock. Let the remaining actual day elapse rather than assuming a reply.
    if((await state()).panel)await click('panel:close');
    if((await state()).paused)await click('time:pause');
    await eventually(s=>s.state.culture_experience.events.menu.status==='resolved',120000);
    await click('nav:更多');await click('full:open:山海来信',true);await shot('12-letters-english');
    if(!(await state()).state.culture_experience.letters.some(l=>l.id==='event:menu'))throw Error('Delayed letter missing after real clock advancement');
    checks.push({label:'Actual settlement and continued service deliver the delayed Lin reply without scene skip commands',ok:true});
    await page.setViewportSize({width:844,height:390});await sync();await shot('13-mobile-letters');
    await click('culture:tab:Menu Notes',true);await shot('14-mobile-menu');await click('culture:menu:dijiang_dumplings',true);await shot('15-mobile-dumplings');
    await click('panel:back');
    checks.push({label:'A nested menu page returns to its previous Letters context on 844×390 landscape',ok:(await state()).panel==='山海来信'});
    await click('panel:back');
    checks.push({label:'The cultural root retains its More return on 844×390 landscape',ok:(await state()).panel==='更多'});
    await click('nav:更多');await click('full:open:系统',true);await click('system:save');await page.waitForTimeout(2000);const saved=(await state()).state.culture_experience.booking.status;
    await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    if((await state()).interface_language!=='en'||(await state()).state.culture_experience.booking.status!==saved)throw Error('Browser save/reload lost language or booking');
    await click('locale:zh');await shot('16-chinese-return');
    checks.push({label:'Global language and completed cultural state persist through real browser reload',ok:true});
    fs.writeFileSync(path.join(out,'final-state.json'),JSON.stringify(await state(),null,2));
  }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify(await state(),null,2));}
  for(const failed of checks.filter(c=>!c.ok))errors.push('Failed check: '+failed.label);
  const report={game_source:receipt?.game_source,actions,checks,errors};
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({actions:actions.length,checks,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
