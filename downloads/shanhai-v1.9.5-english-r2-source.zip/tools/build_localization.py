#!/usr/bin/env python3
"""Offline interface localization catalogue. English is curated in this repository."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent.parent
pairs='''
山海食肆物语|Shanhai Inn
大荒市 · 有间小馆 / 三界食肆|Dahuang · a small inn on the Shanhai road
山海驿路|The Shanhai Road
山海来信|Letters to the Inn
菜牌说明|What Is in the Dish?
角色特征|Meet the Companions
经营目标|Business Goals
经营升级|Grow the Restaurant
欢迎|Welcome
员工|Staff
招聘|Recruit
装修|Furnish
简单布置|Move Furniture
研发|Research
配方研发|Recipe Research
菜单|Menu
菜单定价|Menu & Prices
宣传|Promotion
营销|Marketing
宣传营销|Promotion & Marketing
更多|More
系统|Settings & Saves
系统与存档|Settings & Saves
声音设置|Sound Settings
开发者选项|Developer Options
美术资源|Art Resources
数值面板|Balance Settings
图鉴|Encyclopedia
文化简介|Cultural Reading
员工培养|Training & Shifts
培养、技能与排班|Training, Skills & Shifts
训练与排班|Training & Shifts
员工管理|Staff Management
库存与采购|Stock & Purchasing
库存供应|Stock & Suppliers
账单|Bills
日结账单|Daily Accounts
资金流水|Cash Transactions
贷款|Loans
破产救援|Emergency Rescue
采购设置|Purchasing Settings
顾客反馈|Guest Feedback
员工支线|Companion Stories
相生相克|Working Together
世界排行榜|Local League
会员外卖|Membership & Delivery
会员计划|Membership
外卖订单|Delivery Orders
分店|Branches
分店管理|Branch Management
中央厨房|Central Kitchen
山海探索|Shanhai Expeditions
探索|Explore
神兽觉醒|Awakening
觉醒|Awaken
厨神大赛|Cooking Contest
排行榜|League
任务|Goals
待办汇总|Current Tasks
公告|Notices
事件|Event
事件结果|Event Result
今日收支结算|Daily Accounts
现金流预警|Cash Warning
经营失败|Campaign End
营业日志|Service Log
重新开始|New Campaign
开张庆典|Opening Celebration
特殊顾客|Special Guests
菜品|Dishes
返回|Back
返回 / Back|Back / 返回
返回更多|Back to More
返回图鉴|Back to Encyclopedia
返回员工|Back to Staff
关闭|Close
确认|Confirm
取消|Cancel
撤销|Undo
前往处理|Go to Task
暂不处理|Later
忽略提示|Dismiss
保存|Save
读取|Load
手动保存|Save Now
读取存档|Load Save
继续经营|Continue Service
开始经营|Begin Service
开始完整经营|Start Campaign
继续完整经营|Continue Campaign
开始|Start
继续|Continue
中文|中文
钞票|Cash
灵石|Spirit Gems
声望|Reputation
营业额|Revenue
累计营业额|Total Revenue
客流|Arrivals
顾客|Guests
当班|On Duty
休息|Rest
培训|Training
训练|Train
研发中|Researching
装修中|Building
建造中|Building
培训中|Training
候补|Reserve
主职|Primary Role
副职|Secondary Role
厨师|Cook
服务员|Server
销售员|Promoter / Cashier
全能|Versatile
培训/研发|Tutor / Researcher
厨艺|Cooking
速度|Speed
魅力|Charm
耐力|Endurance
创意|Creativity
口才|Eloquence
算力|Calculation
体力|Stamina
心情|Mood
忠诚|Loyalty
好感|Affinity
工资|Wages
加薪|Raise Wages
关怀|Care
解雇|Dismiss
排班|Set Shifts
培训员工|Train Staff
主副职业|Primary / Secondary Role
普通|Common
稀有|Rare
超稀有|Super Rare
传说|Legendary
碎片|Fragments
技能书|Skill Books
神通|Mythic Skill
等级|Level
已拥有|Owned
未拥有|Not Recruited
已解锁|Unlocked
未解锁|Locked
已领取|Claimed
可领取|Claim
已完成|Complete
未完成|Incomplete
尚未遇见|Not Yet Met
已遇见|Encountered
已读|Read
未读|Unread
用料|Ingredients
招牌伙伴|Signature Companion
风味|Flavour
价格|Price
售价|Menu Price
成本|Cost
库存|Stock
缺货|Out of Stock
补货|Restock
采购|Purchase
购买|Buy
普通通用食材|Ordinary Ingredients
普通食材|Ordinary Ingredients
食材|Ingredients
山海食材|Shanhai Ingredients
稀有食材|Rare Ingredients
品质|Quality
鲜度|Freshness
新鲜度|Freshness
利润|Profit
现金流|Cash Flow
存货|Inventory
负债|Liabilities
净资产|Net Assets
预收款|Prepayment
租金|Rent
房租|Rent
水电|Utilities
利息|Interest
本金|Principal
债务|Debt
收入|Income
支出|Expense
还款|Repay
还清余款|Repay All Principal
预计|Expected
余额|Balance
退款|Refund
经营准备|Before Service
经营记录|Records
伙伴与故事|Companions & Stories
长期经营|Long-Term Business
收藏与系统|Collection & Settings
记录与文化|Records & Culture
早市|Breakfast
午市|Lunch
午餐|Lunch
午后|Afternoon
下午茶|Afternoon Tea
晚市|Dinner
晚餐|Dinner
夜市|Night Market
打烊|Closed
休市|Break
清晨|Morning
春|Spring
夏|Summer
秋|Autumn
冬|Winter
晴|Clear
晴天|Clear
雨|Rain
雨天|Rainy
雪|Snow
雪天|Snowy
主食|Staple
饮品|Drink
汤品|Soup
烧烤|Grill
套餐|Set Meal
轻食|Light Meal
火锅|Hot Pot
点心|Small Dish
甜品|Sweet
家常主食|Homestyle Staples
烤制风味|Grilled Flavours
甜饮|Sweet Drinks
清爽口味|Fresh & Light
辛辣口味|Spicy
水产风味|Aquatic Flavours
随意用餐|Any Meal
少量轻食|Small Meal
偏好蔬食|Prefers Vegetables
丰盛饱腹|Hearty Meal
青年|Young Adult
成年|Adult
长者|Older Adult
女性|Woman
男性|Man
未说明|Unspecified
人类|Human
妖怪|Mythic Guest
神兽后裔|Mythic Descendant
特殊|Special
传菜|Serving
点单|Taking Orders
结账|Checkout
收银|Cashier
清台|Clearing Tables
用餐|Eating
烹饪|Cooking
待机|Idle
行走|Walking
飞行|Flying
爬行|Crawling
移动|Moving
离席|Leaving
灶台|Stove
收银台|Till
传菜口|Serving Pass
餐桌|Dining Table
座椅|Chair
休息区|Rest Area
庭院|Courtyard
街道|Street
店内|Dining Room
暂无|None Yet
无|None
是|Yes
否|No
启用|Enable
停用|Disable
已启用|Enabled
已停用|Disabled
开启|On
关闭自动弹出|Disable Automatic Popup
导入|Import
导出|Export
试听|Preview
停止试听|Stop Preview
重载|Reload
音量|Volume
静音|Mute
总音量|Master Volume
背景音乐|Music
音效|Sound Effects
环境声|Ambience
作者与许可|Credits & Licences
没有可用存档或存档内容损坏，当前进度已保留|No usable save was found, or its contents are invalid. Your current progress is unchanged.
存档失败：无法写入文件|Could not write the save file.
存档失败：无法替换存档文件|Could not replace the save file.
已保存|Saved
存档已保存|Game saved
已读取存档|Save loaded
条件尚未满足|Requirements are not met yet.
当前条件不足|Requirements are not met yet.
请先进入完整经营模式|Start a campaign first.
请先选择破产救援方式|Choose how to handle the emergency first.
请选择空闲员工|Choose an available employee.
需要空闲员工|Requires an available employee.
员工不存在|This employee is not available.
员工正在执行任务，或已调往分店|This employee is busy or assigned to a branch.
培训、研发或装修中不可重新排班|Finish training, research or construction before changing shifts.
需要主店在岗且空闲于其他任务的厨师或培训导师主持研发|Research needs an available on-duty cook or tutor at the main inn.
所需食材不足|Not enough ingredients.
普通通用食材不足|Not enough ordinary ingredients.
普通食材不足|Not enough ordinary ingredients.
普通通用食材|Ordinary Ingredients
招聘资源不足|Not enough resources to recruit.
没有可使用的员工契约|No staff contract is available.
菜谱不存在|This recipe does not exist.
该菜品已经解锁|This dish is already unlocked.
该菜品正在研发中|This dish is already being researched.
该隐藏菜须完成对应神兽支线后领取|Complete the companion story to receive this hidden recipe.
街角饭店阶段解锁神通升级|Skill upgrades unlock at the Corner Restaurant stage.
街角饭店阶段解锁菜品定价|Menu pricing unlocks at the Corner Restaurant stage.
餐厅升级至街角饭店后解锁常规研发|Regular research unlocks at the Corner Restaurant stage.
请先完成白泽当前教学；阶段功能可稍后继续。|Finish Baize’s current step first. Later-stage guidance can wait.
白泽：先完成当前教学，阶段新功能可选择稍后引导。|Baize: finish the current step first. You may postpone guidance for later features.
有一封新的山海来信，可在山海驿路中阅读。|A new letter has arrived. Read it on the Shanhai Road.
✓ 已完成，点击继续|✓ Complete — click to continue
前往|Go
暂停|Pause
继续营业|Resume Service
下一营业时段|Next Service Period
结算至次日清晨|Settle Accounts to Next Morning
结算至次日，查看实际账单|Settle to Next Day and View Actual Bill
查看当日账单|View Today’s Bill
查看账单|View Bill
保存并退出|Save & Exit
再次确认|Confirm Again
清理后厨|Clean the Kitchen
餐厅升级|Restaurant Upgrade
有间小馆|Little Inn
街角饭店|Corner Restaurant
区域名店|Regional Favourite
城市连锁|City Chain
三界餐饮集团|Three-Realm Restaurant Group
确认重新开始完整经营|Start a New Campaign
重新开局（保留永久收藏）|Restart (Keep Permanent Collections)
白泽：欢迎来到大荒市。你接手了负债1200元的有间小馆，要让这间小馆成长为三界餐饮集团。|Baize: welcome to Dahuang. You have inherited a little inn with a debt of 1,200. Begin with one well-served meal, then find your road through the mountains and seas.
完整经营：30位员工、23道常规菜品与隐藏配方、34个山海事件与状态事件、11组羁绊及10组相生相克。阶段升级后开放会员外卖、分店供应链、探索觉醒与厨神大赛。|Run the full campaign with 30 companions, 23 standard dishes and hidden recipes. Growth opens delivery, branches, supply chains, expeditions, awakening and cooking contests. Companions and returning travellers shape the inn along the way.
标准节奏：1×每秒3游戏分钟，新局默认2×，支持暂停与1–4倍速。顶部待办直达当前目标，右侧箭头查看全部；低频工具收在更多。管理面板通常暂停；阶段教学期间继续经营，装修会话始终暂停。|At 1×, each second advances 3 game minutes. A new campaign starts at 2×; pause or choose 1–4× at any time. The task bar opens your current goal. More holds occasional tools. Management usually pauses service; later guidance may let it continue. Furnishing always pauses the clock.
已接入水墨员工立绘与像素场景、人物、界面和物品；开发者可继续替换图片。玩法进度会自动保存。|Ink portraits and pixel scenes, actors, interfaces and objects are included. Progress saves automatically; replacement art can still be imported.
重新开始会重置当前这一局。请先保存需要保留的进度。|Starting again resets this campaign. Save any progress you wish to keep first.
经营工具随阶段逐步开放。未满足条件的操作会说明原因；阶段引导期间顾客与员工正常工作。|Business tools open as the inn grows. Unavailable actions explain their requirements. During later-stage guidance, guests and staff may continue working.
这里显示当前阶段的经营任务；教学引导独立展示，山海志和文化彩蛋不进入待办。|These are the current stage’s business tasks. Guidance appears separately; optional reading and discoveries do not block this list.
当前没有待办，可以安心经营。|There are no pending tasks. Carry on with service.
每笔资金变化记录时间、用途、金额与变化后余额。每页40笔，最新记录优先。|Every cash movement records its time, purpose, amount and resulting balance. The latest 40 transactions appear first.
此日期暂无资金流水。|No cash transactions for this date.
返回救援选择|Back to Rescue Options
返回账单|Back to Bill
今日账单 · 结算前预览|Today’s Bill · Preview Before Settlement
这是目前真实累计经营记录；预计费用尚未扣款。|Actual records so far. Expected charges have not been paid yet.
当前处于新手保护期：免房租水电、最低还款减半且不触发债务逾期。|Opening protection: no rent or utility charges, half minimum principal repayment and no original-debt overdue trigger.
已记营业额|Revenue Recorded
其中小费|Including Tips
已采购支出|Cash Spent on Stock
已耗用食材成本|Ingredients Used at Cost
预计员工工资|Expected Wages
预计房租|Expected Rent
预计水电|Expected Utilities
预计债务利息|Expected Debt Interest
预计最低还款|Expected Minimum Principal Payment
预计贷款利息|Expected Loan Interest
目前现金|Current Cash
近7日实际现金支出构成|Actual Cash Outflows · Last 7 Days
查看日期|Choose Date
全部日期 / 最近记录|All Dates / Recent Records
导出所选流水CSV|Export Selected Transactions as CSV
更新的40笔|40 Newer Transactions
更早的40笔|40 Older Transactions
白泽：贷款提供周转资金，也带来每日1%的利息。只能保留一笔未结清贷款，30天到期，逾期另有声望与罚款后果。|Baize: a loan provides working cash, with 1% daily interest. Only one regular loan may remain open; it is due in 30 days. Overdue balances have reputation and penalty consequences.
白泽：从有间小馆启程，先稳住现金、接待食客，再开创三界食肆。|Baize: begin at this little inn. Keep cash ready, welcome your guests, then find a road to a larger restaurant.
现金与利润不同；采购先变存货，耗用才进成本。|Cash differs from profit: purchases become inventory, then ingredients used become costs.
'''
strings={}
for line in pairs.strip().splitlines():
 if '|'in line:
  a,b=line.split('|',1);strings[a]=b
# Canonical short names travel consistently across every interface.
culture=json.loads((ROOT/'config/culture.json').read_text())
for kind in ['employees','dishes','guests']:
 for e in culture[kind].values():
  full=e.get('en',{}).get('name','');short=full.split(',')[0]
  if full:strings[e['name']]=short
# Known introductory guidance is translated as a whole rather than by replacement fragments.
tutorial=json.loads((ROOT/'config/tutorial.json').read_text())
patterns=[
(r'^第(\d+)日\s+(\d\d:\d\d)$','Day {1} {2}'),
(r'^第(\d+)日$','Day {1}'),
(r'^阶段(\d+)$','Stage {1}'),
(r'^当班 (\d+)/(\d+) · 已拥有 (\d+) 位。休息、训练和研发期间无法接单；候补仍领取工资。$','On duty {1}/{2} · {3} owned. Resting, training and research staff cannot take orders. Reserve staff still receive wages.'),
(r'^故事契约 ×(\d+)$','Story contracts ×{1}'),
(r'^第(\d+)日 · 日结账单$','Day {1} · Daily Accounts'),
(r'^期初现金￥([\d.]+) → 期末现金￥([\d.]+)$','Opening cash {1} → closing cash {2}'),
(r'^待还本金 ￥([\d.]+)。还本与利息分开记录；不要花光采购与发薪资金。$','Principal outstanding: {1}. Principal and interest are separate; keep cash for ingredients and wages.'),
(r'^(.+)：￥([\d.]+)$','{1}: {2}'),
(r'^第(\d+)日 (\d\d:\d\d) · (.+)$','Day {1} {2} · {3}'),
(r'^申请贷款 ￥(\d+) · 所需声望(\d+)$','Borrow {1} · reputation required: {2}'),
(r'^偿还贷款 ￥(\d+)$','Repay loan: {1}'),
(r'^(.+)尚未解锁。需要阶段(\d+)：累计营业额￥([\d.]+)（当前￥([\d.]+)），声望(\d+)（当前(\d+)）。请先在经营升级页达成并确认升级。$','{1} unlocks at stage {2}: total revenue {3} (now {4}), reputation {5} (now {6}). Meet and confirm the requirements in Grow the Restaurant.'),
(r'^需要拥有(.+)$','Recruit {1} first.'),
(r'^(.+)训练成功：(.+)\+1$','{1} completed training: {2} +1'),
(r'^(.+)训练未成功，积累经验$','{1} gained experience from this unsuccessful training.'),
(r'^菜品收入：(.+)$','Dish revenue: {1}'),
(r'^目标奖励：(.+)$','Goal reward: {1}'),
(r'^(.+)好感 ([+−-]?[\d.]+)：(.+)$','{1} affinity {2}: {3}')]
from localization_en import EXTRA, SKILLS, EXTRA_PATTERNS
for line in EXTRA.strip().splitlines():
 if '|'in line:
  a,b=line.split('|',1);strings[a]=b
for e in json.loads((ROOT/'config/employees.json').read_text()):
 if e['id'] in SKILLS:strings[e['skill_description']]=SKILLS[e['id']]
patterns=EXTRA_PATTERNS+patterns
from localization_events import EVENTS
for event in json.loads((ROOT/'config/events.json').read_text()):
 if event['id'] not in EVENTS:continue
 title,description,options=EVENTS[event['id']]
 strings[event['title']]=title;strings[event.get('description','')]=description
 for old,new in zip(event.get('options',[]),options):strings[old['label']]=new
# Paired editorial fields are authored in their owning configuration, never translated live.
def paired_value(source,target):
 if isinstance(source,str) and isinstance(target,str):strings[source]=target
 elif isinstance(source,list) and isinstance(target,list) and len(source)==len(target):
  for a,b in zip(source,target):paired_value(a,b)
 elif isinstance(source,dict) and isinstance(target,dict):
  for key in source.keys() & target.keys():paired_value(source[key],target[key])
def paired(value):
 if isinstance(value,dict):
  if isinstance(value.get('zh'),str) and isinstance(value.get('en'),str):strings[value['zh']]=value['en']
  for key,target in value.items():
   if key.endswith('_en') and key[:-3] in value:paired_value(value[key[:-3]],target)
   paired(target)
 elif isinstance(value,list):
  for item in value:paired(item)
for path in (ROOT/'config').glob('*.json'):
 if path.name not in ['culture.json','localization.json']:paired(json.loads(path.read_text()))
from localization_complete import PAIRS, PATTERNS
for line in PAIRS.strip().splitlines():
 if '|' in line:
  source,target=line.split('|',1);strings[source]=target
patterns=PATTERNS+patterns
# Inline bilingual copy belongs to the same catalogue as factory-created labels.
quoted=r'"(?:[^"\\]|\\.)*"'
for path in (ROOT/'scripts').rglob('*.gd'):
 for match in re.finditer(r'\b(?:t|pair)\(('+quoted+r'),\s*('+quoted+r')\)',path.read_text()):
  try:
   source,target=map(json.loads,match.groups())
   strings.setdefault(source,target)
  except json.JSONDecodeError:pass
# Keep complete structural labels usable when a composed line inserts its own separator.
for source,target in list(strings.items()):
 for old,new in [('：',':'),(' ·',' ·')]:
  if source.endswith(old) and target.endswith(new):strings.setdefault(source[:-len(old)],target[:-len(new)])
# A translated display template is also usable after printf interpolation.
auto_patterns=[]
for source,target in strings.items():
 token=re.compile(r'(?<!%)%(?!%)[+\-0-9.]*[dsfi]')
 old=list(token.finditer(source));new=list(token.finditer(target))
 if [m[0][-1] for m in old]!=[m[0][-1] for m in new]:raise ValueError('Mismatched translation placeholders: '+source)
 if old and len(old)==len(new):
  regex='^';pos=0
  for m in old:
   capture='(.*?)' if m[0][-1]=='s' else r'([+−-]?\d+(?:\.\d+)?)'
   regex+=re.escape(source[pos:m.start()].replace('%%','%'))+capture;pos=m.end()
  regex+=re.escape(source[pos:].replace('%%','%'))+'$'
  rendered='';pos=0
  for i,m in enumerate(new):rendered+=target[pos:m.start()].replace('%%','%')+'{'+str(i+1)+'}';pos=m.end()
  rendered+=target[pos:].replace('%%','%');auto_patterns.append((regex,rendered))
 # Preserve numeric fields in observed compact labels without hardcoding a day or balance.
 old=list(re.finditer(r'-?\d+(?:\.\d+)?',source));new=list(re.finditer(r'-?\d+(?:\.\d+)?',target))
 if old and len(old)==len(new) and [float(x[0])for x in old]==[float(x[0])for x in new]:
  regex='^';pos=0
  for m in old:regex+=re.escape(source[pos:m.start()])+r'(-?\d+(?:\.\d+)?)';pos=m.end()
  regex+=re.escape(source[pos:])+'$';rendered='';pos=0
  for i,m in enumerate(new):rendered+=target[pos:m.start()]+'{'+str(i+1)+'}';pos=m.end()
  rendered+=target[pos:];auto_patterns.append((regex,rendered))
# Specific sentences must precede generic wrappers such as '%s · %s'.
# Numeric captures are nonempty and cannot consume another field.
patterns=auto_patterns+patterns
patterns=[(r,e) for r,e in patterns if r!=r'^(.+)分$']
patterns.append((r'^([+−-]?[\d.]+)分$', '{1} points'))
def literal_weight(regex):
 from re import _parser, _constants
 def count(tokens):
  total=0
  for op,arg in tokens:
   if op==_constants.LITERAL:total+=1
   elif op==_constants.SUBPATTERN:total+=count(arg[-1])
   elif op==_constants.BRANCH:total+=min(map(count,arg[1]))
   elif op in [_constants.MAX_REPEAT,_constants.MIN_REPEAT]:total+=arg[0]*count(arg[2])
  return total
 return count(_parser.parse(regex,0))
patterns.sort(key=lambda item:literal_weight(item[0]),reverse=True)
terms=dict(strings)
# Word-sized fallbacks are only for compact labels; complete sentences use exact entries/patterns.
extra={'灵':'Gems','誉':'Rep','财':'Cash','班':'Duty','训':'Train','建':'Build','休':'Rest','疲':'Tired','洁':'Clean','饰':'Decor','餐':'Meal','人':'Guests'}
terms.update(extra)
output={'version':2,'strings':strings,'patterns':[{'regex':r,'en':e}for r,e in patterns],'terms':terms,'terms_order':sorted([k for k in terms if len(k)>1],key=len,reverse=True),'notes':['Offline interface catalogue; no live translation requests. Original classical passages are deliberately excluded.']}
(ROOT/'config/localization.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print('Compiled',len(strings),'exact entries and',len(patterns),'parameterized patterns')
