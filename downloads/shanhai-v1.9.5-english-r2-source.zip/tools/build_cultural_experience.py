#!/usr/bin/env python3
"""Compile reviewed cultural gameplay content without replacing literary readings or economics."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
P=ROOT/'docs/planning/cultural-redesign-20261030'
plan=json.loads((P/'execution-plan.json').read_text()); prose=json.loads((P/'samples/content-samples.json').read_text()); culture=json.loads((ROOT/'config/culture.json').read_text())
def bi(z,e):return {'zh':z,'en':e}
def text(e,kind='employees'):
 c=culture[kind][e['id']];return c.get('en',{}).get('summary','')
en_decisions=[
'Plan a warming soup service; explain the real ingredients separately from the cook’s name.',
'Choose a night shift and a quiet, well-lit route; leave time for rest.',
'Keep a quiet serving route apart from loud promotion; watch the tail-powered flight.',
'Choose clear outdoor calls, with quiet service space for companions.',
'Check the menu, keep the earlier wording and follow up after correcting an unclear promise.',
'Choose smaller refills or larger batches; compare food used with guests actually served.',
'Prepare a mild evening broth and explain the flavour without promising real-world sleep benefits.',
'Buy discounted grain or keep cash; reserve the stock or share some of what was really bought.',
'Ask which Tiangou story the visitor knows; distinguish the mountain animal from later moon tales.',
'Introduce the surprising voice before a guest is startled; choose where to greet arrivals.',
'Give a steady cook a long broth project; speed is not the only useful contribution.',
'Follow a promise and explain cash received separately from profit earned.',
'Ask a guest’s preference first; offer a short story when they want to hear one.',
'Choose a smaller grill service or time for teamwork; count real stoves and paid dishes.',
'Weigh the cash reserve against investing in companions and training.',
'Bring usable produce and letters back from a real expedition; ask about gardens elsewhere.',
'Agree on the serving order and meal size with Bifang before opening.',
'Rotate a tired worker after a completed task; persistence need not mean endless overtime.',
'Ask each guest about heat and numbing spice; never infer preference from nationality.',
'Try a small recipe change with an explanation, rather than issuing another unexplained command.',
'Record a cooking experiment while leaving room for a different way of tasting.',
'Hear both accounts, inspect the menu and order, then agree a remedy and follow-up.',
'Keep preparation and tables clear; describe a traditional hope without making a medical claim.',
'Invite a guest to notice an ornament without making its story compulsory for ordering.',
'Complete a shared meal through coordinated work, rather than deliberately exhausting the team.',
'Offer a useful hint after the player tries; let names and knowledge grow from an encounter.',
'Prepare for rainy-day demand with actual stock and a place for travellers to shelter.',
'Check staffing, menu and rest before using the once-a-day borrowed traffic period.',
'Offer a visible handover cue; keep the serving-only movement exception distinct from other work.',
'Coordinate a shared table using separate installed stoves; allow for stamina and waiting.'
]
food_en={
'noodles':'Wheat noodles, clear broth and spring onion. Broth components and shared preparation need checking.',
'fried_rice':'Rice, egg and homestyle additions. Check the additions and shared preparation.',
'plum_juice':'An ume-plum drink with seasoning. Sweetness and the full preparation can be discussed.',
'qianyang_soup':'Ordinary meat in a warming broth. Qianyang is the companion’s name, not an ingredient.',
'bifang_wings':'Grilled wing ingredients and fictional Danmu fruit. Check the meat and marinade.',
'fox_milk':'A dairy drink with fictional Pincao. Contains dairy; other components need checking.',
'yinglong_hotpot':'Shanhai aquatic ingredients in a shared pot. Check the actual species and broth.',
'taotie_buffet':'A selection of real dishes, replenished from actual stock. Each item has its own ingredients.',
'phoenix_soup':'A fine broth made with rare ingredients. Fenghuang names the theme, not the meat.',
'zhuyu_salad':'A light meal featuring the fictional herb Zhuyu. Its story is not a health promise.',
'luwu_platter':'A grilled wild-pork platter; check the marinade and sides.',
'yingzhao_salad':'Mountain vegetables including fictional Migu shoots; check the dressing.',
'jingwei_bibimbap':'A hot stone-pot rice dish using fictional Dansu grain. Ask about additions before mixing.',
'dangkang_rice':'Fried rice made from ordinary grain. Explain harvest, portion size and food used.',
'tiangou_tempura':'Fried aquatic ingredients with a crisp coating. Check the coating and species.',
'ranyiyu_soup':'A broth made from ordinary aquatic ingredients; the mythical cook is not an ingredient.',
'qiongqi_hotpot':'A spicy pot. Numbing spice and chilli heat can be explained separately.',
'taowu_barbecue':'Marinated wild pork, grilled. A small tasting portion can help discuss a change.',
'hundun_wonton':'Filled wrappers. The name invites a word-and-story connection, not a flour-free claim.',
'xiezhi_set':'A set meal. List its parts, ingredients, price and what can actually be changed.',
'zhulong_ramen':'Noodles with fictional Danmu fruit. Describe flavour, heat and the night-meal theme.',
'dijiang_dumplings':'Filled dumplings with wrappers. “Faceless” refers to Dijiang; it does not mean flourless.',
'jiuying_platter':'A shared selection using rare ingredients. Several orders still need separate seats and stoves.',
'baize_hidden_banquet':'A hidden shared meal; display its real recipe once it has been discovered.',
'phoenix_true_soup':'Danmu fruit, Shanhai fish and rare ingredients; available through the existing Fenghuang story.'}
en_wishes=['Wants a traveller to remember a bowl of warmth, not mistake the cook for an ingredient.', 'Enjoys the quiet of a night shift and resists being reduced to an omen of misfortune.', 'Wants every plate delivered steadily, but sudden loud voices can break that concentration.', 'Wants to be understood as clearly as heard, without losing a warm, noisy welcome.', 'Loves a beautiful turn of phrase and cares whether anyone believes it afterwards.', 'Wants to taste everything, and must learn to leave something for the next person.', 'Prefers a slower conversation and hopes a hurried guest might sit awhile.', 'Celebrates a full granary, yet worries when abundance becomes only a number in the books.', 'Likes guarding the doorway and wishes guests knew more than the story of swallowing the moon.', 'Has a startling voice and wants a chance to announce it before a guest is afraid.', 'Works steadily and values a clear response; slowness need not mean a lack of purpose.', 'Wonders whether a returning coin is also a small sign of someone’s attachment.', 'Enjoys attention and tests a judgement, but wants a reason for guests to stay beyond the first glance.', 'Proud and watchful, wants guests to remember controlled heat rather than a fire to fear.', 'Likes to save and fears a leaking till, yet must consider when spending on companions is worthwhile.', 'Tends a garden with care and asks what trees grow in a traveller’s home.', 'Cares about timing, and finds a carefree colleague difficult without an agreed plan.', 'Keeps going even while tired; persistence is not permission for endless work.', 'Competitive and quick to flare, still wants the terms of a contest to be fair.', 'Clings to a trusted recipe, but can listen when a small tasting makes the argument clear.', 'Loves hosting and experiments, yet resists being reshaped into somebody else’s standard.', 'Values a promise and would rather ask slowly than judge before hearing both sides.', 'Likes a clean table and notices the unease a visitor has not quite put into words.', 'Enjoys dressing for a welcome and dislikes being treated only as an ornament for wealth.', 'Seeks grace and good order, without wanting every guest to wait for a spectacle of burning.', 'Loves names and questions, and can leave room for someone else to discover the answer.', 'Can bring rain and remembers the journey from which returning home was impossible.', 'Once attended to a world’s light and darkness; now asks whether one table’s lamp is too bright.', 'Invites friendship through rhythm and does not need another person to supply a smile.', 'Wants to watch every pot and also be heard when the many heads say they are tired.']
en_anchors=[
'Sheep form and a horse’s tail; the pines and stones of Qianlai.',
'A night bird’s round eyes; watchfulness and shelter in the old poems.',
'Rabbit head, deer-like body, tail-powered flight and a dog-like call.',
'A bird of Qingqiu, with a calling voice and an association with being free of confusion.',
'A human-faced rabbit in the Shenyijing, with words that turn meanings upside down.',
'Three strands: a notorious appetite, vessel beast-masks and Guo Pu’s connection to Paoxiao.',
'Fish body, serpent head and six feet; waterways and an old hope for untroubled sleep.',
'Boar form, tusks and a self-naming call; a sign of a plentiful harvest.',
'A white-headed, cat-like mountain creature; celestial and moon-swallowing traditions add other strands.',
'A horned eagle-like creature with an infant-like cry, linked to dangerous waters.',
'Turtle form, bird head, serpent tail and the sound of splitting wood.',
'A mother and young finding one another in the Soushenji; later stories of returning coins.',
'Qingqiu’s nine tails and danger; Tushan’s white fox belongs to another tradition.',
'Blue-green body, red markings, white beak, one leg and a fire omen.',
'A fierce beast-name in the Shiji, followed by traditions of gathering wealth.',
'The gardens of Huaijiang Mountain: human face, horse body, tiger markings, bird wings and journeys abroad.',
'Kunlun’s lower capital: tiger body, nine tails and stewardship of gardens and seasons.',
'Yandi’s daughter Nüwa drowned at sea; the white beak, red feet and repeated carrying of wood and stones.',
'Two forms, ox with hedgehog bristles and winged tiger, alongside a notorious name.',
'A stubborn reputation and a later tiger-footed, boar-tusked, long-tailed form.',
'The Zhuangzi’s hospitality and seven openings; other books describe another strange creature.',
'A horned creature associated with distinguishing right and wrong, in several later accounts.',
'A blue-green bird with white beak, eyes and tail, and a self-naming call; an old hope of protection from illness.',
'Tianlu on a swaying hair ornament and cast court objects; associations with blessing and prosperity.',
'Danxue’s five-coloured Fenghuang, five virtue patterns, song and dance, and the hope of peace.',
'Later texts of a speaking creature, Baize diagrams and the Yellow Emperor’s questions about beings.',
'A winged dragon, water, battles and drought/rain; a journey from which it cannot return to heaven.',
'Red human-faced serpent body; light and darkness, and breath linked with winter and summer.',
'A yellow-pouch form, cinnabar red, with six limbs, four wings and no distinct face; it understands song and dance.',
'Jiuying in Yi’s Huainanzi story; Gao You describes water and fire, while later imagery supplies many heads.'
]
en_visuals=[
'Pine-coloured apron and a visible horse tail; the tail settles before the soup is served.',
'Round eyes and a facial disc; pauses to look before moving at night.',
'Long ears and a tail-wing; hovering rather than stepping through the air.',
'A feathered collar and an open calling pose, used for outdoor greetings.',
'Rabbit ears and a human face; a turning menu board accompanies the words.',
'Horns, eye motifs near the sides and a beast-mask apron; a great mouth without eating people.',
'A scaled silhouette and six-limb details, moving close to the ground.',
'Tusks and grain ears; a steady stance while carrying a sack.',
'A pale head, animal ears and a glance towards the moon.',
'Bird wings and a horn; raises the head before its startling call.',
'A beak-like profile, turtle shell and low serpent tail.',
'Insect wings and paired coin patterns; light flight without stepping feet.',
'Fox ears and layered nine-tail fan, kept clear of neighbouring tables.',
'One supporting leg, blue-green and red wing-cloak and a white beak-shaped ornament.',
'Strong beast horns and a guarding pose by the till; this body design is the inn’s choice.',
'Tiger stripes and bird wings; garden rounds and a letter carried home.',
'Tiger claws and nine gathered tails; careful timing and ordered plates.',
'Red feet, a white beak ornament and the small stone of a repeated journey.',
'A winged-tiger silhouette with bristled shoulder details recalling the other form.',
'Boar tusks, tiger paws and a long tail; a folded-arm stance.',
'A rounded form with sensory space left open, distinct from Dijiang’s outline.',
'A clear single horn and a listening posture before a decision.',
'White eyes, white beak and a white tail, with gentle gestures around the tables.',
'An auspicious beast silhouette and ornaments, rather than an imported unicorn template.',
'Layered five-colour feathers; composed service rather than a constant burning display.',
'A pale, knowing companion with a book or archive motif, offered as a guide.',
'Dragon wings, rain-associated details and a sheltered place by the inn.',
'A long red serpent lower body with a human face; low movement and restrained lamplight.',
'Facial features left blank, four wings, and six limbs adapted as four arms and two legs.',
'Water-blue and fire-red head motifs, with a readable central figure tending several pots.'
]
cast=[]
for i,c in enumerate(plan['characters']):
 e={'id':c['id'],'name':c['name'],'anchor':bi(c['source_anchor'],en_anchors[i]),'wish':bi(c['desire_and_tension'],en_wishes[i]),
 'decision':bi(c['decision'],en_decisions[i]),'source_ids':c['source_ids'],'source_layers':{'text_and_commentary':[{'source_id':q['source_id'],'label':q.get('source_label',''),'label_en':q.get('source_label_en','')}for q in culture['employees'][c['id']].get('quotes',[])],'game_interpretation':c['proposed_visual'],'interpretation_kind':'original_game_design'},'portrait':'Portraits/'+c['id']+'.png','status':'production_content'}
 cast.append(e)
 # Keep source layers explicit for reviewers; the player can still enter through the story.
 quotes=culture['employees'][c['id']].get('quotes',[])
 primary=c['source_ids'][0] if c['source_ids'] else ''
 e['source_layers']={
  'primary_text':[q for q in e['source_layers']['text_and_commentary'] if '注' not in q['label'] and (q['source_id']==primary or (primary.startswith('b_shj_') and q['source_id'].startswith('b_shj_')))],
  'ancient_commentary':[q for q in e['source_layers']['text_and_commentary'] if '注' in q['label']],
  'later_tradition':[q for q in e['source_layers']['text_and_commentary'] if '注' not in q['label'] and not (q['source_id']==primary or (primary.startswith('b_shj_') and q['source_id'].startswith('b_shj_')))],
  'game_interpretation':bi(c['proposed_visual'],en_visuals[i]),
  'interpretation_kind':'original_game_design',
 }
menus=[]
for c in plan['dishes']:
 known=[]
 if c['id'] in ['noodles','hundun_wonton','dijiang_dumplings','zhulong_ramen']:known.append('wheat')
 if c['id']=='fried_rice':known.append('egg')
 if c['id']=='fox_milk':known.append('milk')
 menus.append({'id':c['id'],'name':c['name'],'ingredients':bi(c['menu_information'],food_en[c['id']]),'flavour':bi(culture['dishes'][c['id']]['summary'],text(c,'dishes')),
 'encounter':bi(c['gameplay_touchpoint'],food_en[c['id']]),'source_ids':c['source_ids'],'known_components':known,
 'unknown_components':bi('复合用料与共用备餐接触尚未逐项核实；需要时请先问清。','Composite ingredients and cross-contact have not been fully checked. Ask before relying on a dietary claim.')})
regions=[
{'id':'qianlai','title':bi('钱来山 · 松石与热汤','Qianlai · pines, stones and a warm bowl'),'employee':'xian_yang','source_ids':['a_sh_west','origin_erya_sheep'],'target':3,'metric':'warm_paid','requires':[],'action':bi('完成3份已付款的清汤面或汤品。阅读不是条件。','Complete 3 paid clear-noodle or soup orders. Reading is optional.'),'letter':bi('钱来山的松影被写进回信：“那碗汤的名字，我记住了。下次想听听那条马尾的来处。”','A letter carries the shadow of Qianlai’s pines: “I remember the name of that bowl. Next time I would like to hear where the horse-like tail comes from.”')},
{'id':'qingqiu','title':bi('青丘 · 尾影与呼声','Qingqiu · tail shadows and calling birds'),'employee':'jiu_wei_hu','source_ids':['a_sh_south'],'target':1,'metric':'menu_followup','requires':['qianlai'],'action':bi('核对菜牌，并完成Lin的来访处理与次日回访。','Review the menu and complete Lin’s encounter and next-day follow-up.'),'letter':bi('青丘来的信没有催你多讲几个故事，只问：“上次那位旅人，后来尝到自己想吃的东西了吗？”','A letter from Qingqiu does not ask for more stories. It asks, “Did that traveller find something they wanted to taste?”')},
{'id':'zhange','title':bi('章莪 · 瑶碧与炉火','Zhang’e · stone and watchful flame'),'employee':'bi_fang','source_ids':['a_sh_west'],'target':1,'metric':'bifang_followup','requires':['qingqiu'],'action':bi('让毕方按所选方案完成真实宴席，并收到回信。需要毕方与已研发烤翅，可稍后再办。','Complete Bifang’s planned meal and receive the reply. Requires Bifang and the researched wing recipe; it can wait.'),'letter':bi('火光在信纸边缘染出一点红：“那一足的鸟守住了火，也替大家守住了开席的约定。”','A red edge seems to warm the letter: “The one-legged bird watched the fire, and kept the team’s promise about the meal.”')},
{'id':'danxue','title':bi('丹穴 · 五色与共席','Danxue · five colours, one table'),'employee':'feng_huang','source_ids':['b_shj_south','b_song_omens'],'target':3,'metric':'phoenix_paid','requires':['zhange'],'action':bi('以已解锁凤凰羹完成3笔真实付款订单，保留伙伴正常轮休。','Complete 3 paid orders of an unlocked Fenghuang broth while allowing ordinary team rest.'),'letter':bi('丹穴来的回信像一片展开的羽：“一席饭里，有掌火的、接盘的，也有愿意等一等的人。”','A reply opens like a feather: “A meal has someone tending heat, someone receiving a plate, and someone willing to wait.”')}
]
letters={
'bifang_small':bi('“我只听过它与火的传闻。昨晚记住的，却是那只独足的鸟，等食物刚刚好的样子。下次我愿意早点预约。”','“I had only heard the stories of fire. What stayed with me was the one-legged bird waiting until the food was just right. Next time I would like to book early.”'),
'bifang_training':bi('“厨师收了火，伙伴等了一下才接盘。一席饭好吃，也因为大家知道何时等彼此。”毕方把信折好，放在炉旁。','“One cook eased the fire; a companion waited before taking the plate. A meal can be good because people know when to wait for one another.” Bifang folds the letter beside the grill.'),
'menu_served':bi('Lin来信：“你们先说清用料，我才有心情听懂那位无面神的名字。下次想带一份家里的食谱来，一起看看能做什么。”','Lin writes: “Because you explained the ingredients first, I had room to hear the faceless god’s name. Next time I would like to bring a recipe from home and see what we might make together.”'),
'menu_refund':bi('Lin寄来一张食谱：“不用急着说一定可以。先把材料核对好，若合适我们再约。”你把信夹在待试菜牌里。','Lin sends a recipe: “You do not need to promise it will work. Check the ingredients first; if it suits, we can arrange another visit.” You keep it with the menus to review.'),
'harvest_gift':bi('街坊来信说晚饭多坐了两个人，附了一份家乡谷物粥做法。当康把信放在米袋上，又读了一遍那份粥的做法。','The neighbour writes that two more people joined supper, adding a grain-porridge recipe from home. Dangkang lays the letter on the sack and reads the porridge recipe once more.'),
'harvest_reserve':bi('当康清点好第二天的备料：“丰年也要一袋一袋安排。”下一席的米已经备妥。','Dangkang checks tomorrow’s ingredients. “Even in a harvest year, each sack needs a plan.” The next meal is ready to begin.'),
'harvest_contact':bi('“那条余粮消息帮上了忙。”街坊约好下一次相见的时辰，当康用谷穗在信边轻轻划了一道。','“That lead on surplus grain helped.” The neighbour suggests a time to meet again. Dangkang makes a small mark at the edge of the letter with an ear of grain.'),
'harvest_revisit':bi('“下次再看余量。”当康记下这个约定，也记住了账上需要留白的地方。','“We can check what remains next time.” Dangkang remembers the agreement, and the room a budget needs.'),
'night_meal':bi('旅人回信：“记得那条赤色长尾，也记得它先问灯是否太亮。夜饭散了，忙碌的人终于能坐下来。”','A traveller writes: “I remember the long red tail, and the first question: was the lamp too bright? When the meal ended, the people serving could finally sit down.”'),
'garden':bi('英招从真实行程带回一封信：“这里的树也在等雨。愿你们尝到它们这一季的味道。”','Yingzhao returns from the journey with a letter: “The trees here wait for rain too. I hope you taste what this season has given them.”')}
config={'version':1,'cast':cast,'menus':menus,'regions':regions,'guests':plan['guests'],'letters':letters,
 'settings':{'bifang_training_cost':30,'bifang_trained_cook_multiplier':0.95,'bifang_training_minutes':60,'bifang_small_orders':3,'bifang_training_orders':5,'deposit':20,'harvest_budget':80,'harvest_gift_cost':12,'night_orders':3,'night_duration':240,'followup_minutes':1440,'history_limit':256},
 'notes':['Actual orders, inventory and payments drive progress. No prototype scene advancement or initial balances are imported.','Source IDs refer to the existing culture catalogue. No claim of new historical research.']}
(ROOT/'config/cultural_experience.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
print('Compiled 30 companions, 25 menus, 6 guest memories, four routes and bilingual letters')
