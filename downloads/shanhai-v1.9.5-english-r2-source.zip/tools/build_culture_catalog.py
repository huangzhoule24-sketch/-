#!/usr/bin/env python3
"""Build player-facing bilingual readings from the reviewed editorial source.

Historical research parts are retained for provenance. They no longer overwrite
later employees or the new player prose. No network is used by this builder.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
EDITORIAL = ROOT / 'docs/culture-research/player-edition.json'


def build():
    result = json.loads(EDITORIAL.read_text(encoding='utf-8'))
    employees = json.loads((ROOT/'config/employees.json').read_text(encoding='utf-8'))
    dishes = json.loads((ROOT/'config/dishes.json').read_text(encoding='utf-8'))
    hidden = json.loads((ROOT/'config/management.json').read_text(encoding='utf-8'))['hidden_recipe']
    additional = json.loads((ROOT/'config/sidequests.json').read_text(encoding='utf-8'))['hidden_recipes']
    guests = json.loads((ROOT/'config/revision171.json').read_text(encoding='utf-8'))['guests']
    expected = {'employees':employees,'dishes':dishes+[hidden]+additional,'guests':guests}
    sources = {s['id']:s for s in result['sources']}
    if len(sources) != len(result['sources']): raise ValueError('Duplicate source ID')
    for kind,records in expected.items():
        if set(result[kind]) != {r['id'] for r in records}: raise ValueError('Reading IDs do not match: '+kind)
        result[kind] = {r['id']:result[kind][r['id']] for r in records}
        for record in records:
            entry=result[kind][record['id']]
            if entry['name'] != record['name']: raise ValueError('Name mismatch: '+record['id'])
            if len(entry['sections']) != len(entry['en']['sections']) or len(entry['sections']) < 3: raise ValueError('Incomplete reading: '+record['id'])
            if not all(i in sources for i in entry['source_ids']): raise ValueError('Unregistered source: '+record['id'])
            for quote in entry.get('quotes',[]):
                if quote['source_id'] not in entry['source_ids'] or not quote.get('translation'): raise ValueError('Untraceable excerpt: '+record['id'])
                if int(entry.get('reading_version',1)) >= 3 and not quote.get('paraphrase'): raise ValueError('Missing Chinese excerpt explanation: '+record['id'])
                if int(entry.get('reading_version',1)) >= 4 and not all(quote.get(field) for field in ['context','source_label','source_label_en']): raise ValueError('Missing passage context: '+record['id'])
    (ROOT/'config/culture.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    notes=['# 山海食肆文化读本 · Chinese & English','', '修订：'+result['revised_on']+'。30位员工、25道菜品、6位来客。中文与英文分别润写，原文节选配中文白话与英文释意。','', '欢迎页或系统页可切换中文/English；来客小传仍须遇见后阅读。英文典籍节选标明译者或本项目译述，原文与美术替换通道保留。','']
    for kind,heading in [('employees','山海伙伴'),('dishes','一桌山海'),('guests','来客小传')]:
        notes += ['## '+heading,'']
        for entry_id,e in result[kind].items():
            notes += ['### '+e['name']+' · '+e['pinyin'],'',e['summary'],'']
            for s in e['sections']: notes += ['**'+s['title']+'**','',s['text'],'']
            for q in e.get('quotes',[]):
                source=sources[q['source_id']]
                if q.get('context'): notes += [q['context'],'']
                notes += ['> '+q['text'],'> ——'+q.get('source_label','《'+source['work']+'》'),'> '+q['translation'],'']
                if q.get('source_label_en'): notes += ['> — '+q['source_label_en'],'']
                if q.get('translation_info'): notes += ['> English: '+q['translation_info']['credit'],'']
                if q.get('paraphrase'): notes += [q['paraphrase'],'']
            notes += ['**'+e['en']['name']+'**','',e['en']['summary'],'']
            for s in e['en']['sections']:notes += ['**'+s['title']+'**','',s['text'],'']
    (ROOT/'docs/culture-entries.md').write_text('\n'.join(notes),encoding='utf-8')
    print(json.dumps({'employees':len(result['employees']),'dishes':len(result['dishes']),'guests':len(result['guests']),'source_records':len(sources),'excerpts':sum(len(e.get('quotes',[])) for k in expected for e in result[k].values())},ensure_ascii=False))


if __name__=='__main__': build()
