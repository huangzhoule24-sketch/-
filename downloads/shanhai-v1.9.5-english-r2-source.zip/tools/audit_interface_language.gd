extends SceneTree
const Harness=preload("res://tests/culture_ui_tests.gd").Harness
func _init():call_deferred("run")
func audit_text(value,localization):
	if value is Dictionary:
		for key in value:
			if key=="notes" or str(key).ends_with("_en"):continue
			audit_text(value[key],localization)
	elif value is Array:
		for item in value:audit_text(item,localization)
	elif value is String:
		if not value.begins_with("nav:") and not value.begins_with("panel:") and not value.begins_with("finance:"):localization.translate(value)
func dismiss_dialogs(ui):
	for key in ["_requirement_dialog","_action_dialog","_decoration_dialog"]:
		var window=ui.get(key)
		if is_instance_valid(window):window.hide();window.queue_free()
	await process_frame
func run():
	var ui=Harness.new();root.add_child(ui);await process_frame
	ui.story_panel=ui.StoryPanel.new(ui)
	ui.revision_ui=ui.Revision171Panels.new(ui)
	ui.setup_audio()
	ui.localization=preload("res://scripts/services/localization.gd").new("user://locale-audit-only.cfg")
	ui.localization.language="en"
	ui.model.state.stage=4;ui.model.state.cash=100000.0;ui.model.state.reputation=20000
	var panels=["欢迎","员工","图鉴","菜单","装修","山海驿路","角色特征","菜牌说明","山海来信","系统","声音设置","经营状态","日结账单","分店管理","中央厨房","山海探索","神兽觉醒","厨神大赛","会员计划","会员外卖","菜单定价","资金流水","贷款","采购设置","顾客反馈","员工支线","相生相克","世界排行榜","宣传营销","库存供应","员工培养","招聘"]
	for entry in ui.Policy.more_entries(4):
		if not str(entry.panel) in panels:panels.append(str(entry.panel))
	var opened=[]
	for scenario in ["late_initial", "late_all_content", "late_no_cash", "opening"]:
		if scenario=="late_all_content":
			ui.model.employees.clear()
			for e in ui.model.catalog:ui.model.employees.append(ui.model._create_employee(e))
			ui.model.state.unlocked_dishes=ui.model.dishes.map(func(d):return str(d.id))
			ui.model.state.menu_enabled=ui.model.state.unlocked_dishes.duplicate()
			ui.model.full_rules.ensure_state_defaults()
		if scenario=="late_no_cash":ui.model.state.cash=0.0
		if scenario=="opening":ui.model.start_full()
		ui.tutorial_overlay.poll(0);ui.revision_ui.poll(0)
		for name in panels:
			if ui.decoration_active():
				ui.decoration_session.finish(false);ui.close_panel(false)
			await dismiss_dialogs(ui);ui.open_panel(name);await process_frame
			ui.localization.apply_tree(ui)
			opened.append({"scenario":scenario,"requested":name,"actual":ui.panel_name,"children":ui.modal_body.get_child_count()})
	# Use real day settlement to cover the compulsory report and populated accounts.
	ui.model.state.tutorial.finished=true
	ui.model.state.tutorial.completed_steps=ui.Guide.config().steps.map(func(step):return str(step.id))
	ui.model.state.tutorial.active_id=""
	ui.model.state.tutorial.ready_to_ack=[]
	ui.model.skip_to_next_morning()
	ui.open_panel("今日收支结算");await process_frame;ui.localization.apply_tree(ui)
	opened.append({"scenario":"real_settlement","requested":"今日收支结算","actual":ui.panel_name,"children":ui.modal_body.get_child_count()})
	assert(ui.model.full_rules.perform("daily_ack").ok,"The actual daily report can be acknowledged")
	ui.revision_ui.report_open=false
	var encounter=ui.model.full_rules.culture_experience
	if encounter.event("menu").status=="offered":
		for choice in ["accept","verify","refund"]:assert(encounter.perform("culture_choose",{"id":"menu","choice":choice}).ok)
	for name in ["账单","资金流水","顾客反馈"]:
		await dismiss_dialogs(ui);ui.open_panel(name);await process_frame;ui.localization.apply_tree(ui)
		assert(ui.panel_name==name,"Ledger audit must open the requested page")
		opened.append({"scenario":"real_settlement","requested":name,"actual":ui.panel_name,"children":ui.modal_body.get_child_count()})
	# Additional fixtures cover every staff detail, all 61 readings, populated
	# letters, developer import menus and active production. Fixtures are audit
	# inputs, not evidence of natural campaign completion.
	ui.model.state.stage=4;ui.model.state.cash=1000000.0;ui.model.state.gems=1000
	ui.model.employees.clear()
	for e in ui.model.catalog:ui.model.employees.append(ui.model._create_employee(e))
	ui.model.state.unlocked_dishes=ui.model.dishes.map(func(d):return str(d.id))
	ui.model.state.menu_enabled=ui.model.state.unlocked_dishes.duplicate()
	ui.model.full_rules.ensure_state_defaults()
	ui.model.state.developer_mode=true
	ui.model.full_rules.management.purchase("generic",200)
	for guest in ui.model.full_rules.visitors.definitions():
		ui.model.state.special_visitors.records[str(guest.id)]={"met":2,"best":"正在用餐","best_score":75.0,"last":"尚未完成接待"}
		encounter.s().guest_memories[str(guest.id)]={"visits":2,"last_dish":"noodles","last_day":1,"promises":[],"orders":2,"last_visit_serial":1}
	for key in encounter.config.letters:
		encounter._add_letter("audit:"+str(key),encounter.pair("山海来信","Letters"),encounter.config.letters[key],"event")
	for employee in ui.model.employees:
		ui.revision_ui.employee_id=str(employee.id)
		for name in ["员工详情","员工培养"]:
			await dismiss_dialogs(ui);ui.open_panel(name);await process_frame;ui.localization.apply_tree(ui)
			opened.append({"scenario":"staff:"+str(employee.id),"requested":name,"actual":ui.panel_name})
	for name in ["山海来信","来客往事","特殊顾客图鉴","主线故事","开发者选项","美术资源","数值面板","说明","封锁对抗","供应链","三界集团"]:
		await dismiss_dialogs(ui);ui.open_panel(name);await process_frame;ui.localization.apply_tree(ui)
		opened.append({"scenario":"populated_and_developer","requested":name,"actual":ui.panel_name})
	for kind in ["employees","dishes","guests"]:
		for id in preload("res://scripts/services/culture_catalog.gd").new().entry_ids(kind):
			ui.open_culture(kind,id);ui.culture_panel.language="en";ui.open_panel("文化简介",false)
			await process_frame;ui.localization.apply_tree(ui)
			opened.append({"scenario":"reading:"+kind+":"+id,"requested":"文化简介","actual":ui.panel_name})
	ui.close_panel(false)
	ui.model.full_rules.expansion.perform("central_unlock")
	ui.model.full_rules.expansion.perform("branch_open",{"id":"human_east"})
	var batch=ui.model.full_rules.expansion.perform("central_cook",{"dish_id":"noodles","quantity":5,"employee_id":"xian_yang"})
	assert(batch.ok,"Production fixture starts a real central-kitchen batch")
	ui.model.full_rules.expansion.perform("explore",{"employee_id":"ying_zhao"})
	for name in ["员工","经营状态","中央厨房","分店管理","山海探索"]:
		await dismiss_dialogs(ui);ui.open_panel(name);await process_frame;ui.refresh();ui.localization.apply_tree(ui)
		opened.append({"scenario":"active_production","requested":name,"actual":ui.panel_name})
	for employee in ["xiao","bai_ze"]:
		await dismiss_dialogs(ui);ui.revision_ui.confirm_dismiss(employee);ui.localization.apply_tree(ui)
		if is_instance_valid(ui._action_dialog):ui._action_dialog.queue_free()
		if is_instance_valid(ui._requirement_dialog):ui._requirement_dialog.queue_free()
		await process_frame
	for config in [ui.Guide.config(),ui.model.full_rules.story.config,ui.model.full_rules.sidequests.config]:audit_text(config,ui.localization)
	var out=FileAccess.open("res://build/english-r2/untranslated-ui.json",FileAccess.WRITE)
	out.store_string(JSON.stringify(ui.localization.untranslated,"\t"));out.close()
	FileAccess.open("res://build/english-r2/language-panels.json",FileAccess.WRITE).store_string(JSON.stringify(opened,"\t"))
	print("Panel states audited: ",opened.size(),"; incomplete translations: ",ui.localization.untranslated.size())
	var missing=ui.localization.untranslated.size()
	ui.queue_free();await process_frame;quit(0 if missing==0 else 1)
