"""Curated English extensions. Stable UI keys stay Chinese internally; only presentation changes."""
EXTRA='''
点击查看剩余工期、债务与全部人员状态。|View remaining work, debt and all staff statuses.
● 点单 → 制作 → 上菜 → 结账  /  更多中管理菜单|● Order → cook → serve → pay / Manage the menu in More
下架|Remove from Menu
上架|Add to Menu
已上架|On Menu
今日经营|Today’s Service
前往操作|Go to Action
单口灶台|Single Stove
基础传菜口|Basic Serving Pass
基础收银台|Basic Till
取消预览|Cancel Preview
后厨设备升级|Kitchen Equipment Upgrade
员工休息角|Staff Rest Corner
增加两个座位。|Adds two seats.
安排休息|Rest
完成1次山海探索|Complete 1 Shanhai expedition
完成并保留本次调整，或放弃后退出。也可以继续布置。|Finish and keep these changes, discard them and leave, or continue arranging.
完成经营目标后领取一次奖励|Claim a one-time reward after completing the business goal.
完成装修|Finish Furnishing
宣传立牌|Promotion Board
宽敞四人桌|Spacious Four-Seat Table
尚未招募|Not Recruited
展开全部待办|Show All Tasks
已结缘|Encountered
布置期间暂停经营。选中后点击地图绿格，底部完成后保留；可撤销或取消预览。红格表示占用、影响通路或条件不足。|Arranging furniture pauses service. Select an item, then a green map cell. Finish below to keep changes, or undo/cancel. Red cells are occupied, obstruct a route or fail another requirement.
当前没有特殊顾客|No special guest is here.
当班伙伴|Companions on Duty
必须为当班且空闲的员工；闭店0:00–6:00暂停装修，其他时段按游戏分钟推进。完工前不增加座位或经营效果。|Choose an available on-duty worker. Construction pauses during closing from 00:00 to 06:00; otherwise it follows game minutes. Seats and effects become available only when finished.
恢复原价|Restore Base Price
指派装修负责人|Assign a Construction Worker
按住鼠标左键拖动画面|Hold the left mouse button to drag the view.
排班 / 详情|Shifts / Details
旋转手机后继续经营|Rotate Your Phone to Continue
横屏可同时查看餐厅与操作按钮|Landscape view shows the restaurant and its controls together.
早餐营业|Breakfast Service
午餐营业|Lunch Service
下午茶营业|Afternoon Service
晚餐营业|Dinner Service
夜市营业|Night-Market Service
主店当班|On Duty at Main Inn
休息中|Resting
派遣中|Away on Assignment
分店派驻|Assigned to Branch
时间|Time
更多：经营工具、图鉴、账单与设置|More: business tools, encyclopedia, accounts and settings
有间小馆，第一单|A Little Inn, One First Order
朴素双人桌|Simple Two-Seat Table
查看目标与提示|View Goals & Hints
标准经营 · 1×每秒3分钟|Campaign · 1× advances 3 game minutes per second
清洁|Clean
灵巧收银台|Efficient Till
点击「文化简介」阅读身份、特色与本作故事。文化资料对全部伙伴和菜品开放，无需先招募或研发。|Open Cultural Reading for identities, distinctive details and stories of the inn. Companions and dishes can be read about before recruitment or research.
点击员工卡查看排班，或直接点击培训、解雇。|Open a staff card for shifts, or use Train and Dismiss.
点击查看所需资金、员工和摆放条件|View required cash, worker and placement conditions.
物品|Items
道具|Items
知道了|Understood
稍后引导|Guide Me Later
羁绊|Bonds
至少保留一道已研发的菜品。阶段1可将售价调整为基础售价的50%—200%；每提价10%，价格敏感带来的客流约减少5%。库存不足时该菜售罄，顾客仍会到店并选择其他有货菜品。|Keep at least one researched dish on the menu. From stage 1, prices may range from 50% to 200% of base price; each 10% markup reduces price-sensitive demand by about 5%. A dish without stock sells out; guests may still arrive and choose available alternatives.
请横屏游玩|Please Use Landscape View
请选择装修负责人|Choose a Construction Worker
青龙壁画|Azure Dragon Mural
九尾狐灯笼|Nine-Tailed Fox Lantern
预览并摆放|Preview & Place
厨房布局|Kitchen Layout
宣|Promo
峰|Rush
惠|Offer
桌|Table
歇|Rest
灯|Lamp
灶|Stove
炉|Stove
菜|Dish
银|Till
龙|Dragon
明白收入与利润的区别|I Understand Revenue and Profit
白泽：欢迎来到有间小馆。小馆负债1200元，先学会接待食客，再还债扩张。前三天免房租水电，最低还款减半；现金不是利润，记得留下采购和工资。|Baize: welcome to the little inn. Its debt is 1,200. Learn to welcome guests before repaying and expanding. The first three days have no rent or utilities, and half the minimum repayment. Cash is not profit: keep enough for ingredients and wages.
先打开【员工】，认识羬羊厨师与当康服务员。查看岗位后关闭员工面板，回到餐厅。|Open Staff to meet Qianyang the cook and Dangkang the server. Check their jobs, then close the panel to return to the inn.
点击底部【宣传】，花20元发一次传单。宣传吸引食客，但不会代替库存和服务。|Open Promotion below and spend 20 on leaflets. Promotion brings guests; it does not replace ingredients or service.
回到餐厅观察第一单：入座、点单、制作、上菜、结账由员工自动完成。若还在暂停，点击继续；顾客在营业时段到店。|Return to the inn and observe the first order: staff handle seating, ordering, cooking, serving and checkout. Resume if paused; guests arrive during business hours.
第一单到账了！绿色飘字是进账，声望反映口碑。售价收入还要覆盖食材、工资和还款，不等于净利润。|The first payment is in! Green floating amounts show cash received; reputation reflects guest opinion. Revenue still needs to cover ingredients, wages and repayments. It is not net profit.
点击底部【待办】直达账单，查看当前日的真实记录与结算前预览。自动采购先于费用；点击待办旁的展开箭头可查看全部事项。|Open the task below to see today’s actual accounts and the preview before settlement. Automatic purchasing happens before charges. The arrow beside the task opens the full list.
'''
SKILLS={
'xian_yang':'Broth Cook: soup quality +5%.','xiao':'Night Shift: task speed +15% during the night market.',
'er_shu':'Agile: serving speed +10%, but sudden loud calls may startle this companion.',
'guan_guan':'Calling Bird: promotion +5%, with a small guest-mood cost.','e_shou':'Silver Tongue: promotion +20%, but a 10% misleading-advertising risk.',
 'tao_tie':'Big Appetite: cooking speed +15%, ingredient use +10%.','ran_yi_yu':'Strange Fish: a 10% chance of extra income from a paid soup order.',
 'dang_kang':'Harvest: an ingredient-discount event every 5 days when eligible.','tian_gou':'Watchful: may prevent a guest leaving without payment when working the till.',
 'gu_diao':'Uncanny Call: may attract a special guest, but can frighten ordinary guests.','xuan_gui':'Steady: stamina use -10%; own cooking avoids random kitchen-scramble delays.',
 'qing_fu':'Returning Coins: cash pickups +20% while on duty at the main inn; use the strongest bonus of the same kind.',
 'jiu_wei_hu':'Charm: tip chance +30% after serving.','bi_fang':'Fire Cook: grill quality +30%, with a small fire risk.',
 'pi_xiu':'Keeper of Wealth: checkout income +15%, recruitment cost +5%.','ying_zhao':'Wanderer: arrivals +10% and improved guest mood.',
 'lu_wu':'Fire Timing: grilled dishes take 20% less cooking time.','jing_wei':'Persistence: table clearing +30%, with slightly faster mood loss.',
 'qiong_qi':'Hot Temper: spicy-dish order value +20%, with a possible dispute.','tao_wu':'Stubborn: promotion +15%, but a 10% chance of refusing an instruction.',
 'hun_dun':'Experimenter: research success +20%, research time +20%.','xie_zhi':'Fair Hearing: complaint-handling success +30% and improved guest trust.',
 'qing_geng':'Reassuring: complaint risk -20%; guest mood and satisfaction recover slowly by 2 each game hour on duty.',
 'tian_lu':'Auspicious Arrival: paid main-inn orders have a further 5 percentage-point chance to drop a pickup.',
 'feng_huang':'Renewal: once per day, recover after stamina runs out and lift the team’s mood by 10%.',
 'bai_ze':'Knowing: dedicated tutor/researcher; training speed +50%. Research with Baize succeeds and may reveal a hidden recipe.',
 'ying_long':'Rain-Bringer: aquatic-dish quality +40%, rainy-day arrivals +20%.',
 'zhu_long':'Day and Night: borrow another business period’s arrival factor once per game day.',
 'di_jiang':'Faceless Dancer: serving ignores path obstacles and improves guest satisfaction.',
 'jiu_ying':'Many Heads: cooks 3 dishes at separate installed stoves, using 30% more stamina.'}
EXTRA_PATTERNS=[
(r'^(\d+) / (\d+) 座 · 舒适度 ([\d.]+)$','{1} / {2} seats · comfort {3}'),
(r'^([\d.]+)万$','{1} × 10,000'),
(r'^(\d+)年(\d+)月(\d+)日$','Y{1}/{2}/{3}'),
(r'^(.+) · 早餐营业$','{1} · Breakfast service'),
(r'^Lv\.(\d+) / (\d+) · (.+)$','Lv.{1} / {2} · {3}'),
(r'^(.+) / 阶段 (\d+)$','{1} / stage {2}'),
(r'^(.+) · 点击查看立绘$','{1} · open portrait'),
(r'^今日菜单\s+(.+)$','Today’s menu: {1}'),
(r'^体力 ([\d.]+)  心情 ([\d.]+)  忠诚 ([\d.]+)  ·  (.+)$','Stamina {1} · mood {2} · loyalty {3} · {4}'),
(r'^债￥([\d.]+)$','Debt {1}'),
(r'^全部本金负债￥([\d.]+)，点击账单查看利息及到期日$','Principal liabilities {1}. Open accounts for interest and due dates.'),
(r'^可操作设备：(.+)$','Usable facilities: {1}'),
(r'^售价 ￥([\d.]+) · 基础售价 ￥([\d.]+) · 配方成本 ￥([\d.]+)$','Price {1} · base price {2} · recipe cost {3}'),
(r'^(.+) · 座位 \+(\d+) · 工期(\d+)分钟$','{1} · seats +{2} · build time {3} minutes'),
(r'^奖励 钞票(\d+) · 灵石(\d+)$','Reward: cash {1} · spirit gems {2}'),
(r'^(.+) (\d+)/(\d+)$','{1} {2}/{3}'),
(r'^(.+)；点击直达，右侧箭头展开全部待办。$','{1}. Click to open; the arrow shows all tasks.'),
(r'^当班 (\d+)/(\d+) · 已拥有 (\d+) 位。招募获得重复伙伴时转化为碎片；候补仍计发工资。$','On duty {1}/{2} · {3} owned. Duplicate recruits become fragments; reserve staff still receive wages.'),
(r'^新增(\d+)个休息操作位，到达后体力恢复\+([\d.]+)%。 · 工期(\d+)分钟$','Adds {1} rest station; stamina recovery +{2}% after arrival. Build time: {3} minutes.'),
(r'^新增(\d+)个传菜口，上菜工作速度\+([\d.]+)%（同类取最佳）。 · 工期(\d+)分钟$','Adds {1} serving pass; serving work speed +{2}% (strongest of the same kind). Build time: {3} minutes.'),
(r'^新增(\d+)个宣传操作位，销售员可在宣传活动期间到此工作。 · 工期(\d+)分钟$','Adds {1} promotion station for a promoter during campaigns. Build time: {2} minutes.'),
(r'^新增(\d+)个灶台，增加(\d+)路并行烹饪产能；仍须有空闲厨师。 · 工期(\d+)分钟$','Adds {1} stove and {2} cooking slot; an available cook is still needed. Build time: {3} minutes.'),
(r'^(.+) · 顾客(\d+) / 等待(\d+) · 食材([\d.]+) / 新鲜(\d+)% · 预计工资￥([\d.]+)$','{1} · guests {2} / waiting {3} · ingredients {4} / freshness {5}% · expected wages {6}'),
(r'^烹饪速度\+([\d.]+)%。 · 烹饪速度 \+([\d.]+)% · 工期(\d+)分钟$','Cooking speed +{1}% · effective bonus +{2}% · build time {3} minutes'),
(r'^移动(\d+)·(.+)$','Move {1} · {2}'),
(r'^等(\d+)$','Waiting {1}'),
(r'^累计接待 (\d+) 位  ·  流失 (\d+) 位$','Total served {1} · lost {2}'),
(r'^结账速度\+([\d.]+)%，逃单风险减半。 · 结账速度 \+([\d.]+)% · 逃单风险降低 \+([\d.]+)% · 工期(\d+)分钟$','Checkout speed +{1}%; escape risk halved. Effective checkout +{2}%, escape reduction +{3}%. Build time {4} minutes.'),
(r'^舒适度\+([\d.]+)，客单价\+([\d.]+)%。 · 舒适度 \+([\d.]+) · 客单价 \+([\d.]+)% · 工期(\d+)分钟$','Comfort +{1}, order price +{2}%. Effective comfort +{3}, order price +{4}%. Build time {5} minutes.'),
(r'^舒适度\+([\d.]+)，客流量\+([\d.]+)%。 · 舒适度 \+([\d.]+) · 客流量 \+([\d.]+)% · 工期(\d+)分钟$','Comfort +{1}, arrivals +{2}%. Effective comfort +{3}, arrivals +{4}%. Build time {5} minutes.'),
(r'^花费 ￥([\d.]+) 发传单，持续 (\d+) 游戏分钟$','Leaflets cost {1} and last {2} game minutes.'),
(r'^来客×(\d+)$','Guests ×{1}'),
(r'^采购 (\d+) 份普通食材，花费 ￥([\d.]+)$','Buy {1} ordinary ingredient units for {2}.'),
(r'^阶段(\d+)开放，增加四个座位。 · 座位 \+(\d+) · 工期(\d+)分钟$','Unlocks at stage {1}; adds {2} seats. Build time {3} minutes.'),
(r'^食材 ([\d.]+) 份  /  新鲜度 (\d+)%$','Ingredients {1} units / freshness {2}%'),
(r'^(.+) · 已上架$','{1} · on menu'),
(r'^培训中 · 剩(\d+)分$','Training · {1} minutes left'),
(r'^研发中 · 剩(\d+)分$','Researching · {1} minutes left'),
(r'^上回那份(.+)的火候，我还记得。$','I remember how you cooked {1} last time.'),
(r'^上次的(.+)让我又翻了一页旧书。$','Last time, {1} sent me back to another page of an old book.'),
(r'^我记得这里，也记得上回的(.+)。$','I remember this place, and the {1} I had before.'),
(r'^今天想看看，上回(.+)的说明有没有更清楚。$','I want to see whether the explanation of {1} is clearer this time.'),
(r'^谢谢上次的(.+)，这次我也带来一句家乡的做法。$','Thank you for the {1} last time. I brought a way of making it from home.'),
(r'^我还想再看看，你们怎样把(.+)端给不同的人。$','I would like another look at how you serve {1} to different people.'),
]
EXTRA+='''
基础收银|Basic Checkout
阶段1开放，增加四个座位。|Unlocks at stage 1 and adds four seats.
洁|Clean
誉|Rep
财|Cash
'''
EXTRA_PATTERNS += [
(r'^(\d+)年(\d+)月(\d+)日\s+(\d\d:\d\d)$','Y{1}/{2}/{3} {4}'),
(r'^建(\d+)$','Build {1}'),(r'^训(\d+)$','Train {1}'),
(r'^(.+) · (N|R|SR|SSR)$','{1} · {2}'),
(r'^(.+) · 当班 · 体力 ([\d.]+)$','{1} · on duty · stamina {2}'),
]
EXTRA+='''
主线故事|Main Story
声音设置与音频导入|Sound Settings & Import
三界联合宣传|Three-Realm Promotion
三界食肆，正式启程|The Three-Realm Inn Sets Out
中央厨房与供应链|Central Kitchen & Supply Chain
中央成品：暂无成品|Central stock: no prepared dishes
丹木果|Danmu Fruit
丹粟米|Dansu Grain
主持研发|Lead Research
九种声音的值班簿|A Roster of Nine Voices
九首一心|Many Heads, One Purpose
公正丰年|A Fair Harvest
任意合适厨师|Any Suitable Cook
关联伙伴|Associated Companions
凤凰与九尾狐|Fenghuang and the Nine-Tailed Fox
凶兽之势|The Fierce Beasts’ Presence
凶名与和解|A Fierce Name, a Chance to Reconcile
前往供应链|Open Supply Chain
前往完成|Go Complete This
剧情条件尚未达成|Story requirements are not met yet.
勤勉之翼|Wings of Diligence
十二神兽相聚|Twelve Companions Gather
十二神兽，相聚一席|Twelve Companions, One Shared Meal
等待前篇|Complete the Earlier Chapter First
进行中|In Progress
未激活|Inactive
已激活|Active
日常采购|Everyday Purchasing
山海供应商|Shanhai Supplier
山海界探索|Shanhai Expeditions
单机世界公司榜 · NPC经营模拟赛季|Local Business League · Simulated NPC Season
双火之工|Two Keepers of the Fire
发传单|Leaflets
可选黄点提示|Optional Amber Hints
同名员工碎片不足|Not enough fragments of this companion.
员工碎片不足|Not enough staff fragments.
固定数量|Fixed Quantity
在山海探索页选择员工与地点，派遣并等待归来。|Choose a companion and destination in Shanhai Expeditions, send them, then wait for their return.
在店库存：暂无成品|Inn stock: no prepared dishes
城市美食推广|City Food Campaign
培养：员工可训练属性、学习副职、升级神通、安排时段或休息。训练、研发及派遣期间不会在主店接单。候补也领取工资。|Staff can train attributes, learn a second role, improve a skill, set shifts or rest. Training, research and expeditions make them unavailable for main-inn orders. Reserve staff still earn wages.
大荒东街店|East Street Branch
大荒北城店|North City Branch
大荒西市店|West Market Branch
天庭云上店|Cloud-Court Branch
妖界山海店|Mythic-Realm Branch
人间|Human Realm
天庭|Celestial Court
妖界|Mythic Realm
大荒市的新口碑|A New Reputation in Dahuang
大荒市美食节|Dahuang Food Festival
好感、个人剧情与《白泽图》独立记录。文化简介始终可读；剧情解锁需要真实结识与经营任务。|Affinity, personal stories and the Baize Atlas have separate records. Cultural reading is always available; stories need actual encounters and business tasks.
安排清洁后厨|Schedule Kitchen Cleaning
实时经营状态|Live Business Status
客流、采购、体力和投诉效果即时生效；同类收益采用最佳来源。|Arrivals, purchasing, stamina and complaint effects apply to real operations. Only the strongest benefit of the same kind applies.
宣传资源不足|Not enough promotion resources.
寻回白泽图|Recover the Baize Atlas
导入音频|Import Audio
封锁对抗|Respond to the Blockade
小小的岸|A Little Shore
尚未同时当班|Not on Duty Together Yet
尚未拥有|Not Yet Recruited
尚未日结：以上固定费用为当前配置预估，未提前扣款；实际账单在日结后生成。|The day has not settled. Fixed charges above are current estimates, not advance deductions. Actual bills appear after settlement.
山海全员图鉴|The Complete Shanhai Collection
山海全席|A Shanhai Banquet
山海文化交流周|Shanhai Cultural Exchange Week
山海水产|Shanhai Aquatic Ingredients
山猪肉|Wild Pork
差评原因分布|Reasons for Negative Reviews
已内置操作、经营动作和事件音效，以及食肆与夜间环境声。背景音乐可另行导入。|Interface, work and event sounds are included, alongside inn and night ambience. Music can be imported separately.
已就绪|Ready
待导入|Awaiting Import
任务奖励|Goal Reward
伙伴加入|Companion Joins
地面脚步|Footsteps
夜间庭院|Night Courtyard
拾取物品|Collect Pickup
按钮点击|Button Click
挑战失败|Challenge Unsuccessful
振翅轻响|Wing Flutter
操作完成|Action Complete
擦桌清洁|Wipe Table
收银动作|Work the Till
条件不足|Requirements Not Met
每日结算|Daily Settlement
爬行摩擦|Crawling Movement
特殊顾客到访|Special Guest Arrives
研发完成|Research Complete
端盘上菜|Serve a Plate
经营升级|Restaurant Growth
装修施工|Construction Work
订单成交|Order Paid
记录点单|Record an Order
返回页面|Return to Page
锅灶烹饪|Cook at Stove
门前招徕|Welcome at the Door
随机事件提示|Event Notice
顾客不满|Guest Dissatisfied
顾客入座|Guest Takes a Seat
顾客满意|Guest Satisfied
顾客进食|Guest Eats
食肆环境|Inn Ambience
库存供应：按菜品对应采购原料。新鲜度随日结下降，自动备货可开关；没有原料的菜品暂停销售。餐厅没有离线收益。|Purchase the ingredients needed by each dish. Freshness falls at day settlement; automatic stocking can be switched on or off. A dish without ingredients cannot be sold. The inn has no offline earnings.
应龙与九婴|Yinglong and Jiuying
建立三界餐饮集团|Build the Three-Realm Restaurant Group
开发者选项更新后续计算，已取得的奖励和经营进度保留。|Developer settings affect future calculations. Existing rewards and progress remain.
开发者：重载数值配置|Developer: Reload Balance Settings
开启后在营业时间等待新订单。|After enabling, wait for new orders during business hours.
开启外卖接单|Accept Delivery Orders
开展发传单|Distribute Leaflets
开展异兽网红合作|Start a Mythic Food-Creator Collaboration
开展朋友圈广告|Run Social Advertising
开展本地美食博主|Invite a Local Food Blogger
开展营销活动|Run a Marketing Activity
开市日|Market-Opening Day
开设分店|Open Branch
开通会员计划|Start the Membership Plan
异兽网红合作|Mythic Food-Creator Collaboration
当前策略|Current Strategy
当前阶段任务|Current Stage Task
夜市与休息|Night Market & Rest
日常营业|Everyday Service
标题·山海有间|Title · An Inn in Shanhai
我在寻找散落的《白泽图》残页。每次真正结识一位异兽，便能整理一页档案；公开的文化简介始终可以自由阅读。|I am looking for scattered pages of the Baize Atlas. Each creature you actually meet gives us a page to put in order. Public cultural readings remain freely available.
批量烹饪→成品入库→付运费调拨→分店售出。库存与在途货物会随存档保存。|Batch cook → store prepared dishes → pay to ship them → sell at a branch. Stored and in-transit goods persist in the save.
技能书不足|Not enough skill books.
技能书升级|Upgrade with a Skill Book
报名资源不足|Not enough entry resources.
指派一位空闲员工|Assign an Available Companion
探索资源不足|Not enough expedition resources.
支持OGG、MP3、WAV，单文件最多64MB。导入后会替换所选声音。网页版保存在当前浏览器，保存后请稍候再刷新。|Supports OGG, MP3 and WAV, up to 64 MB per file. Import replaces the selected sound. Web imports stay in this browser; allow time to save before refreshing.
《白泽图》残页|A Page of the Baize Atlas
整理羬羊的档案页|Organize Qianyang’s Atlas Page
整理鸮的档案页|Organize Xiao’s Atlas Page
新月开市，整理菜单、检查库存，邀请街坊来有间小馆坐坐。|A new month opens the market. Arrange the menu, check stock and invite neighbours to the inn.
新的一局|A New Campaign
无面亦相识|Knowing a Faceless Companion
无面无相|Beyond a Face
无面者与记录者|The Faceless One and the Keeper of Records
日常关怀（免费）|Everyday Care (Free)
旧食肆的灶铭|An Inscription on the Old Stove
昆仑山道的旧路牌|An Old Sign on the Kunlun Road
昆仑集团的账外故事|A Story Beyond Kunlun’s Accounts
昼夜九味|Nine Flavours, Day and Night
普通招聘每10次保底SR+、每50次SSR；高级招聘每10次SR+、每30次SSR。稀有度决定成长方式，各岗位都有用武之地。|Ordinary recruitment guarantees SR+ every 10 draws and SSR every 50. Advanced recruitment guarantees SR+ every 10 and SSR every 30. Rarity shapes growth; every role has useful work.
普通海鲜 / 水产|Ordinary Seafood / Aquatic Ingredients
普通肉类|Ordinary Meat
普通谷物|Ordinary Grain
普通面皮|Ordinary Wrappers
普通食材（通用）|Ordinary General Ingredients
暂无数据|No Records Yet
暴食招财|Appetite and Wealth
有间小馆 · 主线故事|The Little Inn · Main Story
朋友圈广告|Social Advertising
本地美食博主|Local Food Blogger
本月尚未结算，月末后可查看报告。|This month has not settled. Its report will be available at month end.
梼杌与白泽|Taowu and Baize
正式研发由具备条件的厨师主持，会消耗钞票、食材与时间。缺少关联伙伴或食材时，按钮会说明原因。失败也能积累经验。|Research is led by an eligible cook and uses cash, ingredients and time. If a companion or ingredient is missing, the action explains why. Unsuccessful attempts build experience too.
每日自动采购：开启（点击关闭）|Daily Automatic Purchasing: On (Click to Disable)
每日自动采购：关闭（点击开启）|Daily Automatic Purchasing: Off (Click to Enable)
每月日1、5、10为本游戏自设节日；邻里活动需要真实支出，没有自动现金奖励。|The inn marks days 1, 5 and 10 of each game month as festivals. Neighbourhood activities cost real resources and do not grant automatic cash.
水族双鲜|Two Aquatic Flavours
沟通与关怀|Conversation & Care
没有待清偿欠款或现金不足|There are no arrears to settle, or not enough cash.
派伙伴探索山海界，完成后自动带回食材与碎片。派出的伙伴暂时离岗，先为主店安排替补。|Send companions into Shanhai; on return they bring real ingredients and fragments. They are away from their posts, so arrange cover at the main inn first.
派遣探索|Send an Expedition
三界裂隙|Three-Realm Rift
古食肆遗址|Old Inn Ruins
昆仑旧道|Old Kunlun Road
混沌与白泽|Hundun and Baize
源文件曾重命名并转为OGG；本作进一步裁剪、调整音量、淡化端点、处理循环并转换格式。|The source files had been renamed and converted to OGG. This project further trimmed them, adjusted levels, faded edges, prepared loops and converted formats.
火焰魅惑|Fire and Charm
'''
EXTRA_PATTERNS += [
(r'^(.+) · (N|R|SR|SSR) · (.+)$','{1} · {2} · {3}'),
(r'^(.+) · 参考售价 ￥([\d.]+)$','{1} · indicative price {2}'),
(r'^(.+) · 库存 ([\d.]+)份$','{1} · stock {2} units'),
(r'^关联伙伴：(.+)$','Associated companions: {1}'),
(r'^好感([\d.]+) · 招募对应神兽后开启支线$','Affinity {1} · recruit the companion to open this story'),
(r'^(.+) · (等待前篇|进行中|已完成)\s+\(([\d.]+) / ([\d.]+)\)$','{1} · {2} ({3} / {4})'),
(r'^今日营收￥([\d.]+) · 今日利润￥([\d.]+) · 声望([\d.]+) · 分店(\d+)$','Today’s revenue {1} · profit {2} · reputation {3} · branches {4}'),
(r'^主职 (.+) · 副职 (.*?) · 每日额外工资 ￥([\d.]+) · 碎片 (\d+)$','Primary {1} · secondary {2} · extra daily wages {3} · fragments {4}'),
(r'^(.+) · 人间$','{1} · Human Realm'),
(r'^(.+) · 妖界$','{1} · Mythic Realm'),
(r'^(.+) · 天庭$','{1} · Celestial Court'),
(r'^单价 ￥([\d.]+) · 新鲜度 ([\d.]+)% · (.+)$','Unit price {1} · freshness {2}% · {3}'),
(r'^(.+) · 使用(\d+) / 共(\d+)个$','{1} · in use {2} / installed {3}'),
(r'^已就绪 (\d+) / (\d+)$','Ready {1} / {2}'),
(r'^已完成 (\d+) 单 · 外卖入账 ￥([\d.]+)$','Completed {1} orders · delivery income {2}'),
(r'^技能书 (\d+) 本。技能培养需阶段1；同一角色的碎片由重复招聘与探索获取。$','Skill books {1}. Skill development needs stage 1; companion fragments come from duplicate recruitment and expeditions.'),
(r'^活动支出￥([\d.]+) · 声望\+(\d+) · 员工心情\+(\d+)；每日限一次。$','Activity cost {1} · reputation +{2} · staff mood +{3}; once per day.'),
(r'^原债利息 ￥([\d.]+)$','Original-debt interest {1}'),
(r'^常规贷款利息 ￥([\d.]+)$','Regular-loan interest {1}'),
(r'^最低还本 ￥([\d.]+)$','Minimum principal payment {1}'),
(r'^建设中央厨房 · ￥([\d.]+)$','Build the central kitchen · {1}'),
(r'^开设分店 · ￥([\d.]+)$','Open branch · {1}'),
(r'^开通会员计划 · ￥([\d.]+)$','Start membership · {1}'),
(r'^异兽网红合作 · (\d+)灵石$','Mythic creator collaboration · {1} spirit gems'),
(r'^已收集(\d+)/(\d+) · 白泽仍是引导NPC，不占员工位$','Collected {1}/{2}. Guide Baize is still an NPC and uses no staff slot.'),
(r'^已结识(\d+) / (\d+)种神兽 · 主线收集目标为(\d+)种，全(\d+)种另有成就。$','Met {1}/{2} kinds of companions. The main story needs {3}; all {4} have a separate achievement.'),
(r'^事件档案 · (\d+)则。事件会依据阶段、当班伙伴和经营状态触发；效果以选项说明和实际结算为准。$','Event archive · {1} entries. Events depend on stage, on-duty companions and business state; their choices and actual settlement determine effects.'),
(r'^后厨使用 (\d+)/(\d+) 次 · 清洁用品￥([\d.]+) / (\d+)游戏分钟$','Kitchen uses {1}/{2} · cleaning supplies {3} / {4} game minutes'),
(r'^加薪 ￥([\d.]+)/日$','Raise wages by {1} per day'),
(r'^● (.+)\s+([\d.]+)$','● {1} {2}'),
(r'^进度 ([\d.]+)/([\d.]+)$','Progress {1}/{2}'),
(r'^当前：阶段 (\d+) · (.+)。累计营业额 ￥([\d.]+)，声望 (\d+)。升级同时要求营业额与声望，达到后由你手动确认。$','Current stage {1} · {2}. Total revenue {3}, reputation {4}. Meet both requirements, then confirm growth yourself.'),
]
EXTRA+='''
神兽羁绊 · 11组。相关伙伴需要同时在岗，训练、研发、休息与探索时不提供羁绊；阶段2开放组合加成。|Companion bonds: 11 groups. Both companions must be on duty; training, research, rest and expeditions suspend a bond. Combined benefits open at stage 2.
从负债小馆到三界集团。剧情依据真实经营、事件选择与比赛结果推进；阶段升级沿用营业额与声望门槛。|From a little inn in debt to a three-realm business, the story advances through actual service, event choices and contest results. Stage growth still needs revenue and reputation.
声望达到500且营业时可申请邀请。选择当班厨师和已解锁菜品，支付300元并耗用真实食材；品质×0.8＋创意＋拿手菜加分与连锁品牌70分比较，获胜推进主线。|During open service with reputation 500, request an invitation. Choose an on-duty cook and unlocked dish, pay 300 and use real ingredients. Quality ×0.8 + creativity + specialty bonus competes against the chain’s score of 70. Winning advances the story.
开店：跟随白泽完成六步必修教学：认识负债、查看并关闭员工面板、花20元发传单、观察第一单、认识收入与利润、查看真实账单预览。阶段0没有免费研发。|Opening: follow Baize through six steps—understand debt, open and close Staff, spend 20 on leaflets, observe the first order, distinguish revenue from profit, then inspect the actual bill preview. Stage 0 has no free research.
成长：累计营业额与声望同时达标后，在更多→经营目标中确认。阶段2开放会员外卖，3开放三分店、中央厨房与探索，4开放跨界、觉醒及厨神大赛。|Growth: meet both total-revenue and reputation requirements, then confirm in More → Business Goals. Stage 2 opens membership and delivery; stage 3 adds three branches, central cooking and expeditions; stage 4 adds other realms, awakening and contests.
累计营业额与声望同时达标后，在更多→经营目标中确认。阶段2开放会员外卖，3开放三分店、中央厨房与探索，4开放跨界、觉醒及厨神大赛。|Meet both total-revenue and reputation requirements, then confirm in More → Business Goals. Stage 2 opens membership and delivery; stage 3 adds three branches, central cooking and expeditions; stage 4 adds other realms, awakening and contests.
更多→账单与资金流水页底部可快进到下一营业时段或次日，期间依旧逐分钟处理订单、费用与员工状态。开局教学不可跳过；每次升级逐项教学，阶段教学可稍后继续，可从系统与存档重新学习。|At the bottom of More → Bills and Cash Transactions, advance to the next service period or morning. Orders, costs and staff states still update minute by minute. Opening guidance is required; later-stage lessons can wait and can be reviewed in Settings & Saves.
申请只取得原事件的邀请；报名仍收取原定费用，活动冷却、排队、菜品品质与胜率照常生效。|Requesting an invitation does not enter the event. Entry fees, cooldowns, queues, food quality and chances still apply.
相生与相克只在两位伙伴同时当班时生效；不同来源按独立规则计算。调整真实排班可以改变组合。|Support and friction apply only while both companions are on duty. Sources follow their own combination rules. Changing actual shifts changes the pairing.
离线单机竞争：NPC公司每日结算营业额、成本、利润与口碑，盈利积累现金后扩店；市场周期影响每日表现。每30游戏日一赛季，保存最近12季成绩。赛季分＝本季营业额×0.01＋本季新增声望＋现有分店×500＋本季大赛夺冠奖励2000（只计一次）。赛季结束时营业额、新增声望与夺冠加分归零，分店保留；NPC无夺冠加分。旧存档从载入当日起建立首个赛季，不补造过去成绩。|Offline local competition: simulated companies settle revenue, costs, profit and reputation each day, then expand when profits build cash. Market cycles affect performance. A season lasts 30 game days; the latest 12 results are kept. Score = season revenue ×0.01 + new reputation + existing branches ×500 + a one-time 2,000 contest-win bonus. Revenue, new reputation and the win bonus reset next season; branches remain. NPCs receive no contest bonus. An old save starts its first season when loaded; earlier results are not invented.
系统→开发者选项→美术资源。桌面版可在程序旁CustomAssets放置图片；详细路径见随包美术接入说明。|Settings → Developer Options → Art Resources. On desktop, place images in CustomAssets beside the program. The included art guide lists the exact paths.
美术：系统→开发者选项→美术资源。桌面版可在程序旁CustomAssets放置图片；详细路径见随包美术接入说明。|Art: Settings → Developer Options → Art Resources. On desktop, place images in CustomAssets beside the program; see the included art guide for paths.
累计收集全部30种神兽员工。这是独立的全收集成就，主线的十二神兽目标保持为十二种。|Collect all 30 companion types for a separate achievement. The main story still asks for twelve.
累计结识十二种不同的神兽员工，领取时解锁原创隐藏配方白泽万象宴。重复招聘不会增加种类，离职也不会抹去曾经相聚的记录。|Meet twelve different companion types, then claim the hidden Baize banquet recipe. Duplicate recruits do not add types; a departure does not erase an earlier encounter.
累计营业额与声望达到阶段4的原始门槛后，手动升级为三界餐饮集团。剧情领取不会额外限制阶段升级。|Meet the original stage-4 revenue and reputation thresholds, then confirm growth into the Three-Realm Restaurant Group. Claiming a story milestone adds no extra growth restriction.
自动：按前3日平均消耗×1.2补货。固定：按你设置的数量采购。暂停：不自动花钱。全部在日结前执行，记入当日账单，现金不足时不透支。|Automatic: replenish at 1.2× average use over the previous 3 days. Fixed: buy your chosen quantities. Paused: spend nothing automatically. Purchases happen before day settlement and appear on that day’s accounts; insufficient cash never causes an automatic overdraft.
训练期间暂停工作。训练费用与稀有度、当前目标属性有关；白泽导师可缩短耗时。副职培训后可切换岗位，工资随岗位与加薪调整。|Training pauses the employee’s ordinary work. Cost depends on rarity and the target attribute; Baize can shorten the time. Learning a second role allows a role switch. Wages follow the active role and any raises.
采购记入库存，制作时按配方领料。每日按最近三日平均消耗的1.2倍补货；资金不足时保留已买到的库存。|Purchases enter inventory; cooking uses the actual recipe. Daily replenishment is 1.2× average use over the previous three days. If cash runs short, stock already bought remains.
销售员的魅力与口才会加强宣传效果。先安排足够员工与库存，再吸引更多顾客。活动时间在关闭面板后继续推进。|A promoter’s charm and eloquence improve campaigns. Prepare enough staff and stock before drawing more guests. Campaign time continues after closing this panel.
阶段2后应对昆仑集团捣乱，并在封锁客流压力下建立独立供货、完成12单品质至少80的真实订单、争取社区合作。三个条件完成才正式突破封锁。|From stage 2, face Kunlun’s interference. Under the blockade’s reduced arrivals, establish independent supply, complete 12 real orders of quality at least 80, and gain neighbourhood cooperation. All three are needed to lift it.
阶段2开放会员与外卖。外卖也消耗库存和厨房产能，送达后按扣除平台佣金的金额入账。|Membership and delivery open at stage 2. Delivery uses real stock and kitchen capacity; payment is recorded after arrival, net of the platform commission.
阶段3开始管理连锁。分店需要厨师与前厅员工，还要从中央厨房补给成品；实际顾客购买后才有收入。|Branch management begins at stage 3. Branches need cooks and front-of-house staff, plus prepared dishes shipped from the central kitchen. Only actual sales earn revenue.
阶段4开放神兽觉醒与厨神大赛。榜单明确区分本地玩家与模拟对手，不连接在线服务器。|Stage 4 opens awakening and cooking contests. Rankings distinguish the local player from simulated opponents; there is no online server.
音效鸣谢：Kenney Vleugels（kenney.nl）、SFX Kit by Wyzowl，CC0 1.0。|Sound credits: Kenney Vleugels (kenney.nl) and SFX Kit by Wyzowl, CC0 1.0.
顾客到店不受库存控制；缺货会影响能点的菜、心情与口碑。以下来自实际订单，打开面板不会抹除统计。|Arrivals are not controlled by stock. Shortages affect what can be ordered, mood and reputation. These figures come from real orders; opening this panel does not erase them.
白泽：有间小馆开张啦！先接待顾客，留意食材和员工体力。|Baize: the little inn is open! Welcome the guests and watch ingredients and staff stamina.
开市日。可自费举办邻里活动，非自动发放奖金。|Market-opening day. You may fund a neighbourhood activity; no bonus is paid automatically.
'''
EXTRA_PATTERNS += [
(r'^(\d+)年(\d+)月(\d+)日\s+(\d\d:\d\d)\s+(.+)$','Y{1}/{2}/{3} {4} · {5}'),
(r'^原债本金￥([\d.]+) · 工资/房租欠款￥([\d.]+) · 紧急贷款本金￥([\d.]+)$','Original principal {1} · wage/rent arrears {2} · emergency principal {3}'),
(r'^月度真实营业额达到￥([\d.]+)，可领取(\d+)本技能书。旧存档从接入本系统之日起累计，不追补历史月份。$','Reach actual monthly revenue {1} to claim {2} skill book(s). Older saves count from the day this system begins; previous months are not backfilled.'),
(r'^消耗 ￥([\d.]+) \+ (\d+)灵石 \+ (\d+)同名碎片。全属性永久提升，并切换觉醒美术状态。$','Cost {1} cash + {2} spirit gems + {3} matching fragments. Permanently improves all attributes and switches to the awakened appearance.'),
(r'^累计营业额 ￥([\d.]+) · 声望 (\d+) · 员工上限 (\d+) · 日租金 ￥([\d.]+)$','Total revenue {1} · reputation {2} · staff limit {3} · daily rent {4}'),
]

# Later campaign pages, real requirements and dynamic accounts.
EXTRA+='''
奖励|Rewards
薲草|Pincao
规模|Scale
说明|Description
赠茶|Offer Tea
进度|Progress
配方|Recipe
休息角|Rest Corner
供应链|Supply Chain
其他|Other
山海鱼|Shanhai Fish
待清偿|Outstanding Charges
祝余草|Zhuyu
跨人间|Across the Human Realm
迷榖芽|Migu Shoots
举行觉醒|Perform Awakening
会员系统|Membership
保存进度|Save Progress
厨神之巅|At the Summit of Cooking
同时当班|Together on Duty
员工技能|Companion Skills
外卖服务|Delivery Service
普通海鲜|Ordinary Seafood
独立成就|Independent Achievements
真伪难辨|Truth and Embellishment
简单装修|Simple Furnishing
经营日历|Business Calendar
经营状态|Business Status
自动补货|Automatic Restocking
菜品定价|Dish Pricing
营销活动|Marketing Campaigns
角下有尺|A Measure Beneath the Horn
触发线索|How to Begin
试听所选|Preview Selected Sound
读取进度|Load Progress
长夜将明|The Long Night Nears Dawn
隐藏配方|Hidden Recipe
雨落有时|Rain in Its Season
音频素材|Audio Files
高级招聘|Premium Recruitment
魅惑之外|Beyond Enchantment
麻辣食材|Chilli and Numbing Spices
龙凤呈祥|Dragon and Phoenix
备齐丹木果|Gather Danmu Fruit
妖界与天庭|The Creature Realm and Heaven
导入与试听|Import & Preview
暂无优惠券|No Coupons
灶边的灰烬|Ash Beside the Stove
白泽与帝江|Baize and Dijiang
穷奇与獬豸|Qiongqi and Xiezhi
等待超时|Waiting Timeout
粮仓有余粮|Grain to Spare
羁绊与相生|Bonds & Cooperation
蛊雕与英招|Gudiao and Yingzhao
跨三界分店|Branches Across Three Realms
返回供应链|Back to Supply Chain
阅读并继续|Read & Continue
陆吾与天狗|Luwu and Tiangou
饕餮与九婴|Taotie and Jiuying
今日节日提醒|Today’s Calendar Note
今日顾客反馈|Today’s Guest Feedback
保住有间小馆|Keep the Little Inn Going
月食下的天狗|Tiangou Beneath an Eclipsed Moon
灰烬里的归程|A Journey Home Through Ash
白泽图的新页|A New Page in Baize’s Album
目标尚未完成|The Goal Is Not Complete
石与鱼的约定|A Promise of Stone and Fish
碎片升级技能|Upgrade Skill with Fragments
精卫与冉遗鱼|Jingwei and Ranyiyu
菜品品质差|Poor Dish Quality
营销预算不足|Insufficient Marketing Budget
训练所选属性|Train Selected Attribute
请先开通会员|Activate Membership First
走出商业封锁|Through the Blockade
返回外卖服务|Back to Delivery Service
返回经营状态|Back to Business Status
还清初始债务|Repay the Initial Debt
重放开局教学|Replay the Opening Guide
领取剧情奖励|Claim Story Reward
领取成长奖励|Claim Growth Reward
保存固定采购量|Save Fixed Purchase Quantity
债务与营业时间|Debt & Opening Hours
兑换会员优惠券|Redeem a Member Coupon
每日结算后更新|Updated After Daily Settlement
申请美食节邀请|Request a Food-Festival Invitation
第一道山海招牌|The First Shanhai Signature Dish
解锁山海供应商|Unlock the Shanhai Supplier
先解锁山海供应商|Unlock the Shanhai Supplier First
尚无缺货口碑标记|No Shortage-Related Reputation Mark
稀有食材（通用）|Rare Ingredients (General)
自费举办邻里活动|Fund a Neighbourhood Gathering
裂隙另一侧的街灯|Streetlights Beyond the Rift
重新加载音频目录|Reload Audio Catalogue
出餐速度+10%。|Serving speed +10%.
用现有现金清偿欠款|Pay Outstanding Charges with Available Cash
纠纷风险+15%。|Dispute risk +15%.
经营状态与后厨维护|Business Status & Kitchen Maintenance
解锁后可采购丹木果|Danmu fruit becomes purchasable after unlocking.
跨人间、妖界与天庭|Across the human realm, the creature realm and heaven
返回员工排班与详情|Back to Staff Shifts & Details
重看序章与白泽引导|Revisit the Prologue & Baize’s Guide
阅读榜单与赛季规则|Read League & Season Rules
三界餐饮集团（当前）|Three-Realm Restaurant Group (Current)
以所选厨师与菜品参赛|Enter with Selected Cook & Dish
厨师（当前不可派遣）|Cook (Currently Unavailable for Assignment)
服务员（当前不可派遣）|Server (Currently Unavailable for Assignment)
所有菜品品质+10%。|All dish quality +10%.
请先领取前一个主线目标|Claim the Previous Main-Story Goal First
重复角色转化为培养碎片|Duplicate Recruits Become Training Fragments
实际完成3次獬豸断案事件|Complete 3 actual Xiezhi complaint hearings
所有菜品客单价+15%。|All dish order values +15%.
水产食材新鲜度衰减减半。|Aquatic ingredients lose freshness at half the usual rate.
由精卫实际完成12次清台|Have Jingwei actually clear 12 tables
辣味/烤肉客单价+25%|Spicy/grilled order value +25%
收集其余25位异兽的档案残页|Collect archive fragments for the other 25 creatures
稀有食材各1份并用于重生仪式|One of each rare ingredient, used in the renewal ritual
配方已解锁。可以在菜单中上架|Recipe unlocked. Add it to the menu.
客流+10%，食材耗用+5%。|Arrivals +10%, ingredient use +5%.
研发成功率 -15 个百分点。|Research success -15 percentage points.
稀有食材只能通过探索或事件获得|Rare ingredients come only from expeditions or events.
继续完成支线，解锁世界观记录。|Continue companion stories to reveal more of the world.
参赛员工与评分沿用真实比赛系统。|The usual contest rules determine entrants and scores.
在穷奇争执事件中实际选择3次调停|Choose mediation in 3 actual Qiongqi disputes
宣传+30%，虚假宣传风险翻倍。|Promotion +30%; misleading-advertising risk doubled.
晚餐客流+30%，团体食客增加。|Dinner arrivals +30%, with more guest groups.
满意度+20%，食材成本-5%。|Satisfaction +20%, ingredient cost -5%.
研发时隐藏菜发现概率 +10%。|Hidden-recipe discovery chance during research +10%.
水产品质+35%，雨天另加10%。|Aquatic dish quality +35%, with a further 10% in rain.
偿清全部本金，利息欠款可在账本中清偿|Repay all principal; outstanding interest can be paid in the accounts.
烧烤品质+20%、出餐速度+10%。|Grill quality +20%, serving speed +10%.
由九尾狐实际送达12份菜，并完成结账|Have Jiuweihu serve 12 actual dishes that are then paid for
连续完成3次九婴「多线操作」协调事件|Complete 3 consecutive Jiuying coordination encounters
由帝江实际送达12份菜，并完成结账|Have Dijiang serve 12 actual dishes that are then paid for
水产品质 +15%；雨天客流 +10%。|Aquatic dish quality +15%; rainy-day arrivals +10%.
配方已解锁。可以在菜单中上架、调价。|Recipe unlocked. Add it to the menu and adjust its price.
食材消耗 +15%；后厨混乱概率 +10%。|Ingredient use +15%; kitchen-scramble risk +10%.
女性顾客客单价 +20%；小费概率 +10%。|Female guest order value +20%; tip chance +10%.
由应龙实际烹饪并送达12份水产菜，并完成结账|Have Yinglong cook 12 actual aquatic dishes that are served and paid for
纠纷概率 +20%；獬豸客诉处理效率 -20%。|Dispute chance +20%; Xiezhi complaint-handling efficiency -20%.
蛊雕吓跑普通顾客概率翻倍；英招自身客流增益失效。|Gudiao is twice as likely to frighten ordinary guests; Yingzhao’s own arrival bonus is inactive.
夜间盗抢/逃单概率 -30%；收银安全 +20%。|Night theft/non-payment chance -30%; till security +20%.
烛龙实际烹饪并在晚餐/夜市送达12份菜，并完成结账|Have Zhulong cook 12 actual dishes served at dinner/night market and then paid for
先让我做你的引路人吧。我暂不受雇，也不占用员工位置。|Let me guide you first. I am not employed yet and do not occupy a staff slot.
经营已进入三界集团阶段，去【三界集团】参加厨神大赛。|The business has reached the Three-Realm Group stage. Open Three-Realm Group to enter the cooking contest.
还没有日结记录。可在【更多→账单】中结算至次日清晨。|There is no daily settlement yet. Open More → Bills to settle through to the next morning.
备齐丹木果、山海鱼、稀有食材各1份并用于重生仪式|Gather one unit each of Danmu fruit, Shanhai fish and rare ingredients for the renewal ritual.
今日节日提醒：开市日。可自费举办邻里活动，非自动发放奖金。|Calendar note: Market Opening Day. You may fund a neighbourhood gathering; no automatic cash prize is awarded.
全收集不是主线十二神兽的替代条件。离职保留曾经结缘的记录。|The full-collection achievement is separate from meeting twelve companions in the main story. Departures preserve past encounters.
接单/传菜/清台的服务员速度+20%，清台效率另+30%。|Server speed for orders, serving and clearing +20%; clearing efficiency gains another 30%.
白泽训练/研发加成 -30%；梼杌拒绝指令概率再 +10%。|Baize’s training/research bonus -30%; Taowu’s instruction-refusal chance gains another 10%.
音量设置自动保存，重新开局也会保留。尚未导入的声音会静默跳过。|Volume settings save automatically and survive a new campaign. Empty sound slots are skipped silently.
进度不会在关闭期间推进。每日结算后自动存档，也可以随时手动保存。|Progress pauses while the game is closed. Daily settlement saves automatically; you can also save manually.
在阶段4的厨神大赛中获胜；报名、食材、参赛员工与评分沿用真实比赛系统。|Win the stage-4 cooking contest, using its usual entry, ingredients, staff and scoring rules.
商业封锁尚未开始。阶段推进后，昆仑商会将考验小馆的供应、服务与邻里关系。|The commercial blockade has not begun. Later, Kunlun’s traders will test the inn’s supply, service and neighbourhood relationships.
还清初始债务。已有经营目标的钞票奖励保持原样，这里领取剧情进展与技能书。|Repay the initial debt. Existing business-goal cash rewards remain; this story goal grants progress and skill books.
选择实际主持伙伴；研发期间会暂停其主店工作。白泽当班参与时研发必定成功。|Choose the actual research leader, who will pause main-inn work during the project. Research led by on-duty Baize always succeeds.
解锁后可采购丹木果、山猪肉、丹粟米及山海草药。稀有食材通过阶段3探索获取。|Unlock this supplier to buy Danmu fruit, wild pork, Dansu grain and Shanhai herbs. Rare ingredients come from stage-3 expeditions.
'''
EXTRA_PATTERNS += [
(r'^返回(.+)$','Back to {1}'),(r'^重放阶段(\d+)(.*)$','Replay stage {1}{2}'),
(r'^(.+) · 举行觉醒$','{1} · Perform awakening'),
(r'^(.+)（当前不可派遣）$','{1} (unavailable for assignment)'),
(r'^等级(\d+)/(\d+) · 技能 Lv\.(\d+)$','Level {1}/{2} · skill Lv.{3}'),
(r'^技能 Lv\.(\d+)$','Skill Lv.{1}'),(r'^技能书(\d+)本$','{1} skill books'),
(r'^([\d.]+)积分$','{1} points'),(r'^积分 ([\d.]+)$','Points {1}'),
(r'^第(\d+)天$','Day {1}'),(r'^第(\d+)赛季$','Season {1}'),
(r'^第(\d+)/(\d+)天$','Day {1}/{2}'),(r'^阶段 ([\d.]+)$','Stage {1}'),
(r'^阶段至少 ([\d.]+)$','Stage at least {1}'),(r'^进度 ([\d.]+)/([\d.]+)$','Progress {1}/{2}'),
(r'^(.+)：([\d.]+)/([\d.]+)$','{1}: {2}/{3}'),
(r'^([^。]+) · (等待前篇|进行中)  \((\d+) / (\d+)\)$','{1} · {2} ({3} / {4})'),
(r'^([\d.]+)分$','{1} points'),(r'^([\d.]+)游戏分钟$','{1} game minutes'),
(r'^耗时([\d.]+)(游戏)?分钟$','Takes {1} game minutes'),(r'^持续([\d.]+)分钟$','Lasts {1} minutes'),
(r'^会员 (\d+) 人$','Members: {1}'),(r'^到店(\d+)$','Arrivals {1}'),
(r'^好评(\d+)$','Positive reviews {1}'),(r'^差评(\d+)$','Negative reviews {1}'),
(r'^等待超时(\d+)$','Waiting timeouts {1}'),(r'^完成(\d+)单$','Completed orders {1}'),
(r'^缺货(\d+)单$','Orders without stock {1}'),(r'^参赛(\d+)次$','Contests entered {1}'),
(r'^夺冠(\d+)次$','Contests won {1}'),(r'^最高分([\d.]+)$','Best score {1}'),
(r'^已接待(\d+)位$','Guests served {1}'),(r'^日租金￥([\d.]+)$','Daily rent {1}'),
(r'^欠息￥([\d.]+)$','Interest owed {1}'),(r'^欠租￥([\d.]+)$','Rent owed {1}'),
(r'^欠薪￥([\d.]+)$','Wages owed {1}'),(r'^(.+)  ([\d.]+)$','{1}: {2}'),
(r'^满意度 ([\d.]+)%$','Satisfaction {1}%'),(r'^次日客流系数 ([\d.]+)$','Next-day arrival factor {1}'),
(r'^(.+) ([\d.]+)份（库存 ([\d.]+)）$','{1}: {2} units (stock {3})'),
(r'^采购 ([\d.]+)份$','Buy {1} units'),(r'^(.+) · 库存 ([\d.]+)份$','{1} · stock {2} units'),
(r'^(.+) · 使用(\d+) / 共(\d+)个$','{1} · {2} in use / {3} total'),
(r'^训练费用 ￥([\d.]+)；关闭面板后开始推进。$','Training cost {1}; progress begins after closing this panel.'),
(r'^冠军门槛([\d.]+)分$','Winning threshold {1} points'),
(r'^报名 ￥([\d.]+) \+ ([\d.]+)灵石$','Entry: {1} + {2} spirit gems'),
(r'^消耗 ￥([\d.]+) \+ ([\d.]+)灵石$','Costs {1} + {2} spirit gems'),
(r'^￥([\d.]+) \+ ([\d.]+)灵石$','{1} + {2} spirit gems'),
(r'^(.+) · ([\d.]+)灵石$','{1} · {2} spirit gems'),
(r'^(.+) · ([\d.]+)积分$','{1} · {2} points'),(r'^(.+) · (\d+)碎片$','{1} · {2} fragments'),
(r'^(\d+)\. (.+)（玩家）$','{1}. {2} (Player)'),
(r'^(\d+)\. (.+)（单机NPC）$','{1}. {2} (Offline NPC)'),
]
EXTRA+='''
昆仑集团|Kunlun Group
天阙仙宴|Heavenly Banquet
瑶池百味|Jade Pool Flavours
云梦酒楼|Yunmeng Restaurant
赤水食坊|Redwater Kitchen
大荒商旅|Dahuang Caravan
扶桑料理社|Fusang Kitchen
青丘茶舍|Qingqiu Tea House
北冥渔家|Northern Sea Fishers
长留山居|Changliu Mountain Inn
丹水小馆|Danshui Inn
灵丘夜市|Lingqiu Night Market
等待前篇|Awaiting Previous Chapter
在山海探索页选择员工与地点，派遣并等待归来。|Choose a companion and destination in Shanhai Expeditions, dispatch them and wait for their return.
'''
EXTRA+='''
交接|Handover
'''
EXTRA+='''
水产|Aquatic Ingredients
游戏|Game
厨神大赛和本地榜单|Cooking Contest & Local League
跨三界分店、神兽觉醒、厨神大赛和本地榜单|Branches across three realms, awakening, the cooking contest and the local league
研发成功率+30%，传菜忽略障碍。|Research success +30%; serving ignores obstacles.
'''
EXTRA_PATTERNS += [
(r'^([\d.]+)游戏分钟；平均品质至少([\d.]+)$','{1} game minutes; average quality at least {2}'),
(r'^([\d.]+)游戏分钟；有概率触发合作事件$','{1} game minutes; a cooperation encounter may occur'),
]
EXTRA+='''
售罄|Sold Out
必成功|Guaranteed Success
主线进展|Story Progress
当前生效|Currently Active
招募3人|Recruit 3 Companions
昼夜神通|Day & Night Skill
每日一次|Once Per Day
相克警示|Conflict Warning
路边小馆|Roadside Inn
钞票不足|Not Enough Cash
食材不足|Not Enough Ingredients
切换为厨师|Switch to Cook
可操作设备|Usable Facilities
现金流告急|Cash Running Low
切换为服务员|Switch to Server
切换为销售员|Switch to Promoter / Cashier
建设资金不足|Not Enough Cash for Construction
开店资金不足|Not Enough Cash to Open a Branch
当前售罄菜单|Currently Sold-Out Dishes
活动经费不足|Not Enough Cash for This Gathering
白泽不可解雇|Baize Cannot Be Dismissed
獬豸翻开值班簿|Xiezhi Opens the Duty Book
调整库存与采购|Adjust Stock & Purchasing
切换为培训/研发|Switch to Training / Research
这锅羊汤，可别急火。|Give this broth time; do not rush the flame.
需要足额钞票偿清本金|Keep Enough Cash to Repay the Principal
Cash Flow告急|Cash Running Low
我是鸮，认真做好这一班。|I am Xiao. I will give this shift my care.
请先完成白泽当前教学或救援选择|Finish Baize’s Current Guide Step or Rescue Decision First
山海全员图鉴，可到「主线故事」领取。|The full-companion achievement is ready in Main Story.
事情要一件一件查，人也要一次一次认识。|Examine each matter in turn; get to know people one encounter at a time.
我留在夜灶，想看看那些等待天亮的面孔。|I stay by the night stove, wondering about the faces waiting for dawn.
九个脑袋，九种调味，谁都觉得自己说得对！|Nine heads, nine seasonings, and each thinks it knows best!
今天我先把这一餐送好，剩下的故事慢慢说。|Today I will serve this meal well. The rest of the story can wait.
先别争，灶台旁要留出彼此能够听见的距离。|Before arguing, leave enough space by the stove to hear each other.
既然每个人都先认定我会惹事，我何必解释？|If everyone has already decided I cause trouble, why should I explain?
主动贷款在阶段1解锁，破产救援时可提前申请|Ordinary Loans Unlock at Stage 1; Emergency Rescue Can Be Offered Earlier
掌雨的名字太大，切好这一尾鱼却要先稳住刀。|Bringing rain is a grand name. Cutting this fish well begins with a steady knife.
有人把祥瑞写进我的尾巴，也有人只记得诱惑。|Some write good fortune into my tails; others remember only temptation.
帝江没有画出脸，只在纸上留下六足四翼的轮廓。|Dijiang draws no face, only the outline of six limbs and four wings.
我愿意坐在柜台旁，先替双方留住证据和解释的机会。|I will sit by the counter and keep the evidence, and each side’s chance to explain.
他们说我每次燃尽都会归来，可跌落人间时，我也会害怕。|They say I return whenever the flames burn out. Yet falling into this world can frighten me too.
古书中的形象与今天的你，都不该被随意并成别人的故事。|Neither your old-book image nor who you are today should be casually folded into someone else’s story.
当前食材不足，顾客不会点这道菜。补货后自动恢复可售。|Guests cannot order this dish without its ingredients. Restocking makes it available again automatically.
我来到大荒市，想知道天候之外，一顿饭能否也给人安定。|I came to Dahuang wondering whether a meal, as well as the weather, could offer someone steadiness.
衔木石很久了，我也想知道，停下来吃一口热饭是什么滋味。|After carrying wood and stones so long, I wonder how it feels to stop for a warm meal.
传说中的角能辨曲直，人间的争议却不能只凭一个名字下结论。|The legendary horn distinguishes right from wrong. A human dispute still needs more than a name to settle it.
食肆给她留了一处窗边的位置，也留了一份由她自己选择的工作。|The inn leaves her a place by the window, and work she can choose for herself.
睁眼是昼，闭眼是夜——传说如此说，人间却还有许多不肯睡去的人。|Eyes open for day, closed for night, the story says. Yet this world has many who will not sleep.
选择今日采用的营业时段客流系数。不会推进时钟，也不会在休息时间生成顾客。|Choose the business-period arrival factor to use today. This does not advance the clock or bring guests during closed periods.
食肆中的重生故事是游戏改编；典籍里的凤凰祥瑞与后世涅槃意象，请分别在文化简介中了解。|The inn’s renewal story is its own creation. Cultural Reading explores the old Fenghuang’s auspicious associations and later images of rebirth separately.
'''
EXTRA_PATTERNS += [
(r'^切换为(.+)$','Switch to {1}'),(r'^整理(.+)的档案页$','Arrange {1}’s archive page'),
(r'^现金不足，需要 ￥([\d.]+)$','Not enough cash; requires {1}'),
(r'^现金不足，礼物需要￥([\d.]+)$','Not enough cash; this gift costs {1}'),
(r'^(.+) · 创意([\d.]+) · 必成功$','{1} · creativity {2} · guaranteed success'),
(r'^(.+)售罄$','{1} sold out'),
]
EXTRA+='''
完成成长目标可获得指定伙伴契约|Complete Growth Goals to Earn a Specified Companion Contract
需要完整经营模式|Requires Campaign Mode
没有可用的安全存档，当前进度已保留|No Valid Safe Save Is Available; Current Progress Has Been Kept
已达到三界集团阶段|The Three-Realm Group Stage Has Been Reached
累计营业额与声望尚未同时达标|Total Revenue and Reputation Must Both Meet Their Targets
未知宣传类型|Unknown Promotion Type
阶段2解锁异兽网红|Creature Influencers Unlock at Stage 2
当班菜品品质需要达到75|On-Duty Dish Quality Must Reach 75
目标未完成或奖励已领取|Goal Incomplete or Reward Already Claimed
未知目标|Unknown Goal
v1.5在阶段1解锁正常研发，初始引导无需试制|Ordinary Recipe Research Unlocks at Stage 1; Opening Guidance Does Not Require a Trial
未知招聘方式|Unknown Recruitment Method
没有可补缴罚款或现金不足|No Fine Is Payable, or Cash Is Insufficient
需要烛龙当班且处于营业时段|Requires Zhulong on Duty During an Open Business Period
已确认日结收支|Daily Accounts Confirmed
请选择是否自动弹出日报|Choose Whether Daily Reports Open Automatically
日结展示设置已保存|Daily Report Preference Saved
梼杌暂时拒绝这次指令，没有扣除资源|Taowu Refused This Instruction; No Resources Were Deducted
请选择有效食材与正数数量|Choose a Valid Ingredient and a Positive Quantity
请选择不超过现有库存的正数数量|Choose a Positive Quantity Within Available Stock
未知供应商|Unknown Supplier
已解锁该供应商|This Supplier Is Already Unlocked
街角饭店阶段解锁山海供应商|The Shanhai Supplier Unlocks at the Corner Restaurant Stage
已达到该阶次等级上限，需觉醒突破后继续培训|This Tier’s Level Cap Has Been Reached; Awaken Before Further Training
未知属性|Unknown Attribute
属性已达到训练上限|This Attribute Has Reached Its Training Cap
未知职业|Unknown Role
员工已经掌握该职业|This Companion Already Knows This Role
先完成该副职业培训|Complete This Secondary-Role Training First
神通已达到最高等级|The Skill Has Reached Its Maximum Level
加薪已达到每日上限|The Daily Wage-Increase Limit Has Been Reached
排班时段格式无效|Invalid Shift-Time Format
未知排班时段|Unknown Shift Period
免费试制只能进行一次羬羊汤研发|The Free Qianyang Soup Trial Is Available Once
需要拥有|Recruit First
菜品尚未解锁|This Dish Is Not Unlocked
定价需在默认价格的50%至200%之间|Price Must Be Between 50% and 200% of the Default
采购策略须为自动补货、固定数量或暂停采购|Choose Automatic Restocking, a Fixed Quantity or Paused Purchasing
请选择可采购食材与0至100000的整数数量|Choose a Purchasable Ingredient and an Integer Quantity from 0 to 100000
请先解锁山海供应商|Unlock the Shanhai Supplier First
未知管理操作：|Unknown Management Action:
现金不足，需要 ￥%s|Not enough cash; requires %s
山海食材供应商|Shanhai Ingredient Supplier
没有待处理事件|No Event Is Waiting
未知选项|Unknown Option
资源不足|Not Enough Resources
请为美食节选择一位当班厨师|Choose an On-Duty Cook for the Food Festival
请选择已解锁且食材充足的参赛菜品|Choose a Researched Contest Dish with Enough Ingredients
当前没有需要突破的商业封锁|There Is No Active Blockade to Overcome
请在营业时组织应对|Organize the Response During Open Service
未知封锁应对策略|Unknown Blockade Response
这一项应对已经完成|This Response Has Already Been Completed
请先处理昆仑集团捣乱事件，明确经营立场|Resolve the Kunlun Interference Event First and Set the Inn’s Response
需要在封锁期间完成%d单品质至少%.0f的真实营业订单|Complete %d actual orders of at least %.0f quality during the blockade
社区合作需要声望达到%.0f|Community cooperation requires reputation %.0f
封锁应对经费不足|Not Enough Cash for the Blockade Response
未知事件操作|Unknown Event Action
没有可支付的罚款或现金不足|No Fine Is Payable, or Cash Is Insufficient
烛龙需在营业时当班|Zhulong Must Be on Duty During Open Service
今日已使用昼夜神通|The Day & Night Skill Has Already Been Used Today
只能切换为营业时段系数|Choose an Open Business Period’s Arrival Factor
未知装修项目|Unknown Furnishing Project
这是开局设施，扩建请选对应设备项目|This Is a Starting Facility; Choose the Corresponding Upgrade to Expand
员工不存在或已经离场|The Companion Does Not Exist or Has Left
白泽是主线关键角色，不可解雇|Baize Is Part of the Main Story and Cannot Be Dismissed
请先完成订单、培训、研发、派遣或装修，并将分店员工调回|Finish Orders, Training, Research, Expeditions or Building First; Recall Staff from Branches
至少保留1名厨师和1名服务员，请先招聘接替人员|Keep at Least 1 Cook and 1 Server; Recruit Replacements First
最小编制不足，必须保留1名厨师和1名服务员|Keep at Least 1 Cook and 1 Server
补偿及遣散费共￥%.2f，现金不足|Compensation and severance total %.2f; cash is insufficient
濒临破产请使用独立的一次性紧急救援，常规贷款不可替代救援|Use the One-Time Emergency Rescue When Insolvent; an Ordinary Loan Cannot Replace It
负债阶段无法申请常规贷款，请先还清逾期债务；濒临破产时将提供一次紧急救援|Ordinary Loans Are Unavailable While Overdue Debt Remains. Repay It First; Insolvency Offers One Emergency Rescue
同一时间仅能保有一笔未结清贷款|Only One Ordinary Loan May Be Outstanding at a Time
该额度需要声望%d|This loan tier requires reputation %d
请选择1000、2000或5000元贷款档位|Choose a Loan of 1000, 2000 or 5000
还款金额必须大于0|Repayment Must Be Greater Than 0
没有待偿还贷款|No Loan Is Outstanding
现金不足，无法偿还所选金额|Not Enough Cash for the Selected Repayment
救援选择已打开|The Rescue Decision Is Already Open
仅在破产救援中使用|Available Only During Emergency Rescue
没有待确认催收通知|No Collection Notice Needs Confirmation
未知财务操作|Unknown Finance Action
贷款￥%.2f已到账，日息1%%，第%d日到期|Loan %.2f received; daily interest 1%%, due on day %d
贷款已偿还￥%.2f|Loan repayment: %.2f
请选择紧急贷款、重开本局或读取存档|Choose Emergency Loan, Restart Campaign or Load Save
催收通知已确认，贷款仍需实际归还|Collection Notice Confirmed; the Loan Still Needs Repayment
荐菜机制已移除|Dish Recommendation Has Been Removed
替代菜也已售罄，食客离店|The Alternative Dish Is Also Sold Out; the Guest Leaves
未知顾客服务操作|Unknown Guest-Service Action
该拾取物已消失或已拾取|This Pickup Has Disappeared or Was Already Collected
后厨清洁正在进行|Kitchen Cleaning Is Already Underway
清洁后厨需要￥%.0f|Kitchen cleaning costs %.0f
请选择一位空闲员工；正在收尾、培训、装修或派驻中的员工不可清洁|Choose an Available Companion; Staff Finishing Work, Training, Building or Assigned Elsewhere Cannot Clean
未知操作|Unknown Action
请先招募这位员工；引导白泽可通过档案残页建立好感|Recruit This Companion First; Guide Baize Gains Affinity Through Archive Fragments
好感已满|Affinity Is Full
今天已赠礼|A Gift Has Already Been Given Today
今天已经交谈|You Have Already Talked Today
请选择茶点或书册|Choose Tea & Snacks or a Book
现金不足，礼物需要￥%.0f|Not enough cash; this gift costs %.0f
白泽支线保留原有25页，旋龟与青耕不新增必需残页|Baize’s Story Keeps Its Original 25 Pages; Xuangui and Qinggeng Add No Required Fragments
这页档案已整理|This Archive Page Is Already Arranged
真正结识并招募这位异兽后，才能整理档案页|Meet and Recruit This Creature Before Arranging Its Archive Page
山海志尚未发现|This Shanhai Record Has Not Been Discovered
未知神兽支线|Unknown Companion Story
这条支线已完成，可随时重读|This Story Is Complete and Can Be Reread Anytime
招募对应神兽后开启支线|Recruit the Corresponding Companion to Begin This Story
来处已经读过，请查看后续心结与专属任务|The Origin Has Been Read; Continue to the Dilemma and Companion Task
请先阅读来处|Read the Origin First
需要好感≥%.0f并经历专属事件；白泽以收集残页推进|Requires affinity ≥%.0f and the companion event; Baize progresses through archive fragments
请选择一项对话回应|Choose a Dialogue Response
请先完成心结对话|Complete the Dilemma Dialogue First
归处需要好感≥%.0f|The homecoming requires affinity ≥%.0f
未知支线操作|Unknown Companion-Story Action
好感已更新；心情与忠诚保持独立|Affinity Updated; Mood and Loyalty Remain Separate
白泽图档案残页已保存|Baize’s Archive Fragment Saved
山海志阅读进度已保存；不发放数值奖励|Reading Progress Saved; No Stat Reward Is Granted
支线完成：|Story Complete:
剧情进度已保存，可随时返回经营|Story Progress Saved; Return to Service Anytime
已收养幼崽，获得|Cub Adopted; Received
线索碎片×1|Clue Fragment ×1
没有待收养的幼崽，或该奖励已经领取|No Cub Is Waiting for Adoption, or the Reward Was Already Claimed
需要阶段 %d|Requires stage %d
会员系统已开放|Membership Is Already Unlocked
上一张优惠券尚未使用|The Previous Coupon Has Not Been Used
积分不足|Not Enough Points
暂无可接外卖单|No Delivery Order Is Available
外卖单已更新|The Delivery Order Has Changed
外卖配送已满|Delivery Capacity Is Full
需要空闲厨师|Requires an Available Cook
菜品食材不足|Not Enough Ingredients for This Dish
运费不足|Not Enough Cash for Shipping
未知营销活动|Unknown Marketing Campaign
阶段尚未开放该活动|This Campaign Is Not Unlocked at This Stage
该营销活动仍在进行|This Marketing Campaign Is Still Active
未知分店|Unknown Branch
该世界尚未开放|This Realm Is Not Unlocked
分店已营业|The Branch Is Already Open
分店尚未开业|The Branch Is Not Open
员工正在工作、培训、研究或已调往分店|The Companion Is Working, Training, Researching or Assigned to a Branch
该员工未派驻分店|This Companion Is Not Assigned to a Branch
中央厨房已开放|The Central Kitchen Is Already Unlocked
请先建设中央厨房|Build the Central Kitchen First
批量数量超出范围|Batch Quantity Is Outside the Allowed Range
菜品未研发|This Dish Has Not Been Researched
需要空闲厨师主持|Requires an Available Cook to Lead
中央厨房库存与在制品超过容量|Central-Kitchen Stock and Work in Progress Exceed Capacity
批量原料不足|Not Enough Ingredients for This Batch
中央厨房成品不足|Not Enough Prepared Stock in the Central Kitchen
调拨运费不足|Not Enough Cash for Transfer Shipping
未知探索地点|Unknown Expedition Destination
探索队已满|All Expedition Slots Are in Use
觉醒需要空闲员工|Awakening Requires an Available Companion
觉醒资源不足|Not Enough Awakening Resources
比赛正在进行|A Contest Is in Progress
下一场比赛尚未开始|The Next Contest Is Not Yet Open
参赛菜品未研发|The Contest Dish Has Not Been Researched
请选择空闲厨师|Choose an Available Cook
参赛食材不足|Not Enough Contest Ingredients
未知后期操作：|Unknown Expansion Action:
可以执行|Available
食材刚刚发生变化|Ingredient Availability Has Just Changed
批量原料刚刚发生变化|Batch Ingredient Availability Has Just Changed
参赛原料刚刚发生变化|Contest Ingredient Availability Has Just Changed
当前没有预警|There Is No Current Warning
当前没有待选择的救援|No Rescue Decision Is Pending
紧急贷款仅在濒临破产的救援画面提供|Emergency Loans Are Offered Only in the Insolvency Rescue Screen
本局紧急救援已使用，无法再次申请|This Campaign’s Emergency Rescue Has Already Been Used
请先确认救援代价：5000元，日息2%，20日到期，逾期声望−50/罚款400元；再次破产强制结束|Confirm Rescue Terms First: 5000, Daily Interest 2%, Due in 20 Days; Overdue Reputation −50 and Fine 400. Another Insolvency Ends the Campaign
请输入正数还款金额|Enter a Positive Repayment Amount
没有待还的紧急贷款|No Emergency Loan Is Outstanding
现金不足|Not Enough Cash
未知救援操作|Unknown Rescue Action
未知剧情目标|Unknown Story Goal
剧情奖励已领取|Story Reward Already Claimed
美食节配置不可用|Food-Festival Configuration Is Unavailable
美食节邀请今日已发生或已在队列中|A Food-Festival Invitation Has Already Occurred Today or Is Queued
需要声望达到500、正在营业，且没有同类邀请排队或冷却|Requires Reputation 500, Open Service and No Similar Invitation Queued or Cooling Down
请先处理队列中的事件|Resolve Queued Events First
今日没有节日活动|There Is No Calendar Gathering Today
今日邻里活动已经举办|Today’s Neighbourhood Gathering Has Already Been Held
请在营业时举办活动|Hold the Gathering During Open Service
月度奖励已领取或营业额未达标|Monthly Reward Already Claimed or Revenue Target Unmet
没有对应的月度报告|No Matching Monthly Report
未知剧情操作|Unknown Story Action
已领取：|Claimed:
已申请美食节邀请；请到事件面板决定是否报名|Food-Festival Invitation Requested; Decide Whether to Enter in the Event Panel
邻里活动已完成，支出已记入费用|Neighbourhood Gathering Completed; Its Cost Was Recorded as an Expense
已领取月度经营技能书%d本|Claimed %d monthly business skill books
请选择有效槽位及OGG、MP3或WAV文件。|Choose a Valid Slot and an OGG, MP3 or WAV File.
单个音频不能超过64MB。|Each Audio File Must Be No Larger Than 64 MB.
音频无法解码，请重新导出文件。|The Audio Cannot Be Decoded; Export the File Again.
音频槽位路径无效。|Invalid Audio Slot Path.
音频目录无法写入。|The Audio Directory Is Not Writable.
音频文件无法写入。|The Audio File Cannot Be Written.
保存音频失败。|Failed to Save Audio.
仅可导入约定美术目录中的 PNG/JPG 图片，文件名不能含路径跳转。|Import PNG/JPG Images into the Supported Art Directories; Filenames Cannot Traverse Paths.
图片无法解码、格式不符或超过 32 MiB / 8192 像素边长限制。|Image Cannot Be Decoded, Has an Unsupported Format or Exceeds 32 MiB / 8192 Pixels Per Side.
资源路径不能经过符号链接。|Asset Paths Cannot Pass Through Symbolic Links.
无法创建资源目录（错误 %d）。|Cannot create asset directory (error %d).
无法写入资源图片（错误 %d）。|Cannot write asset image (error %d).
资源图片未完整写入（错误 %d）。|Asset image was not fully written (error %d).
'''
EXTRA+='''
用料与菜名说明|Ingredients & Dish Name
请先补齐配方食材|Restock the Recipe Ingredients First
请先完成白泽当前教学；阶段功能可稍后继续。|Finish Baize’s Current Guide Step First; Stage Features Can Wait
请先完成装修，或确认放弃本次调整。|Finish Furnishing or Confirm Discarding These Changes First
山海|Shanhai
交接|Handover
'''
EXTRA+='''
✓ 已完成，点击继续|✓ Complete — Continue
必修|Required
功能教学|Feature Guide
待办|Task
招募第3名员工|Recruit a Third Companion
炒菜|Cooking
用餐区|Dining Area
后厨|Kitchen
庭院 · 店门|Courtyard · Entrance
点单|Taking Order
清台|Clearing
上菜|Serving
待命|Ready
行走|Moving
等餐|Waiting for Food
离店|Leaving
食客|Guest
今日招牌|Today’s Special
施工|Building
'''
EXTRA_PATTERNS += [
(r'^白泽引导\s+(\d+) / (\d+) · 必修$','Baize’s guide {1} / {2} · required'),
(r'^白泽 · 阶段(\d+) / (.+)$','Baize · stage {1} / {2}'),
(r'^前往 · (.+)$','Go to · {1}'),(r'^待办[:：]\s*(.+)$','Task: {1}'),
(r'^(.+)·(炒菜|清台|上菜|待命|行走|点单|宣传|施工|收银|休息|交接)$','{1} · {2}'),
]

EXTRA+='''
灵石|Gems
操作提示|Action Notice
'''
EXTRA+='''
请先完成白泽当前教学；阶段功能可选择稍后引导。|Finish Baize’s Current Guide Step First; Later Feature Guidance Can Wait.
先备好下一桌的食材。|Get the next table’s ingredients ready.
今日也要认真待客。|Give today’s guests our care.
借过，热菜来了。|Coming through with a hot dish.
沿着通道走，不挡同伴。|Keep to the aisle and leave room for companions.
掌握火候，慢工出好味。|Watch the heat and give the flavour time.
这一锅，要让食客满意。|Let this pot be worth the guest’s wait.
您的菜好了，请慢用。|Your meal is ready. Enjoy.
收拾干净，迎接下一桌。|A clean table for the next guest.
账目清楚，分毫有据。|Clear accounts, every coin explained.
山海风味，欢迎来尝。|Come taste the flavours of Shanhai.
歇一歇，再精神上岗。|Rest a little, then return refreshed.
多练一次，就多懂一点。|One more practice, one more thing understood.
试试新的食材搭配。|Try a different pairing of ingredients.
有些累了，想轮班休息。|A little tired. Time for someone else’s turn.
想和掌柜聊聊。|I would like a word with the innkeeper.
这里不通，请调整布置。|The route is blocked. Please rearrange the room.
缺少食材，先补货吧。|Ingredients are missing; restock first.
这道招牌正合您的口味。|This signature dish may suit your taste.
我来介绍今天的山海佳肴。|Let me introduce today’s Shanhai dishes.
量好尺寸，把设备装稳。|Measure carefully and install it steadily.
认真做好眼前的一件事。|Give this one task my attention.
先看看今天的招牌。|Let us see today’s specials.
这家小馆闻着真香。|Something smells good in this little inn.
找个位置歇歇脚。|A seat to rest my feet.
不知道这里有什么拿手菜？|What does this kitchen do best?
走了好远，终于能坐下了。|A long walk, and at last a seat.
这屋里的灯光真暖。|Such a warm light in here.
听见锅铲声了，应该快好了。|I can hear the cooking. Perhaps it is nearly ready.
先喝口水，不着急。|Some water first. There is time.
后厨今天挺忙呢。|The kitchen is busy today.
邻桌那盘看着不错。|That dish at the next table looks good.
现做的饭，值得等一小会儿。|A freshly cooked meal is worth a little wait.
这道菜的名字真有意思。|What an interesting name for a dish.
能帮我看看这份还要多久吗？|Could you check how much longer my meal will take?
肚子有点饿了……|Getting a little hungry…
希望我的菜很快就到了。|I hope my dish arrives soon.
再等一会儿，可别忘了我。|I can wait a little. Do not forget me.
要不要先问问店员？|Perhaps I should ask a server.
闻到香味就更想吃了。|The smell makes me even hungrier.
这口火候正好。|Just the right heat for this bite.
热乎乎的，真舒服。|Lovely and warm.
下次带朋友一起来。|I will bring a friend next time.
原来这就是招牌的味道。|So this is the taste of the special.
慢慢吃，把这一餐好好过完。|Take my time and enjoy this meal.
吃完再聊聊这道菜的故事。|After eating, I would like to hear the dish’s story.
这一碗，有点家的味道。|Something in this bowl reminds me of home.
不同的味道放在一起也很合适。|Different flavours can sit well together.
'''
EXTRA_PATTERNS += [(r'^灶台 (\d+)/(\d+) · 收银 (\d+)/(\d+)$','Stoves {1}/{2} · tills {3}/{4}'),
(r'^(.+) · 体力(\d+) 心情(\d+)$','{1} · stamina {2} · mood {3}')]
EXTRA+='''
Lin本次用餐未能完成，已退回预收款。请查看排班、等候队列与山海来信。|Lin’s visit could not be completed and the prepayment was refunded. Check staff shifts, the queue and Letters to the Inn.
'''
EXTRA+='''
吸|Magnet
状|State
可升级|Ready to Grow
'''
EXTRA_PATTERNS += [
(r'^([峰惠誉洁财吸状])(\d+)(h?)$','{1} {2}{3}'),
(r'^([峰惠誉洁财吸状]\d+h?) (.+)$','{1} {2}'),
(r'^!(\d+) (.+)$','!{1} {2}'),
(r'^(.+) (研发|培训|施工)(\d+)分$','{1} · {2} {3}m'),
(r'^⚠ (\d+)位员工状态偏低 · (.+)$','⚠ {1} staff need attention · {2}'),
(r'^清洁剩(\d+)分 · (.+)$','Cleaning: {1}m remaining · {2}'),
(r'^债([\d.]+)万$','Debt {1}×10k'),
]
EXTRA+='''
⚠ %d位员工状态偏低|⚠ %d staff need attention
展开收入明细|Show Income Details
收起收入明细|Hide Income Details
'''
EXTRA+='''
来处|Origins
心结|A Question to Face
归处|Finding a Place
凤凰：我不愿让每次重生只成为招徕客人的奇观。你能陪我找回愿意点燃自己的理由吗？|Fenghuang: I do not want each return to become a spectacle for attracting guests. Will you help me find a reason to kindle that flame for myself?
先以真实的三种食材筹备一席饭，再决定如何叙述重生。|Prepare a meal with the three actual ingredients first, then decide how to tell the story of renewal.
先听你说完|Let Me Hear You Out
不急着给传说下定义，先听此刻站在面前的伙伴怎样解释自己。|Before defining a legend, listen to how the companion before you describes themselves.
一起把难题做完|Work Through It Together
用分工与实践回应心结，把食肆当作能够重新出发的地方。|Answer the difficulty through shared work, making the inn a place to begin again.
凤凰没有让火焰吞没小馆，而把它收束在一盏羹汤里。|Fenghuang does not let the flames swallow the inn, but gathers their warmth into a bowl of broth.
凤凰：归来不必独自承担。此后这道「凤凰涅槃羹·真」，就记得我们一同做成的这一餐。|Fenghuang: I need not carry the return alone. Let this True Renewal Broth remember the meal we made together.
知音之约：你留下的是倾听的位置，而不是对神话的单一答案。|A promise of understanding: you leave a place for listening, rather than one final answer to a myth.
同业之约：你们约定以日常分工与共同承担，继续经营这间食肆。|A promise of shared work: you agree to keep the inn going through everyday cooperation and responsibility.
白泽：残页不是给异兽贴上永远不变的标签。不同典籍、后世传说和此地生活，需要分层记录。|Baize: these fragments are not permanent labels for strange beings. The old books, later tales and life here each need their place in the record.
十五页已见轮廓。请继续结识伙伴，补全其余档案。|Fifteen pages reveal an outline. Keep meeting companions to fill the remaining records.
最后一页合拢，白泽把秘书的案卷放到食肆桌上。|The last page closes. Baize sets the secretary’s files on the inn’s table.
白泽：引路的责任没有结束。但现在，我愿意作为一名培训与研发伙伴，正式加入你们。|Baize: guiding you is not over. But now I would like to join you properly, as a companion in training and research.
白泽现已进入招聘与契约池；完成支线不直接免费发放员工。|Baize is now available through recruitment and contracts; completing this story does not grant a free employee.
应龙：人们向我求雨，也埋怨雨来得不合时宜。|Yinglong: people ask me for rain, then complain when it arrives at the wrong moment.
凤凰说火候须懂得收放，或许行雨也是一样。先让这十二份水产不误客人的一餐。|Fenghuang says heat needs restraint as well as strength. Perhaps rain does too. First bring these twelve aquatic dishes to their guests in time.
十二份鲜味送到桌边，应龙把窗外的云推向远处。|Twelve fresh dishes reach the tables. Yinglong sends the clouds beyond the window further away.
应龙：山海之间的分寸，也可以从一口灶台学起。|Yinglong: a sense of measure between mountains and seas can begin at one stove.
烛龙：能拨动昼夜，不等于懂得他人的时间。|Zhulong: moving day and night is not the same as understanding another person’s time.
为迟归的食客留十二份热饭吧。灯火不必驱散所有黑暗，照亮一张桌子也足够。|Keep twelve warm meals for late travellers. A lamp need not scatter every darkness; lighting one table is enough.
最后一碗面端出，长夜依旧缓缓流动。|The last bowl of noodles is served. The long night still flows at its own pace.
烛龙：此后我守的不是世界的钟，而是这一间还愿意等人的食肆。|Zhulong: from now on I will watch over this inn, still willing to wait for someone, rather than the clock of the world.
帝江在案上写：没有面目，是否就不能被认出？|Dijiang writes on the desk: without a face, can I still be recognized?
不如记住彼此工作的习惯，记住哪一份餐点是由你送来。|Remember each other’s ways of working, and which meal you brought to the table.
十二张餐桌旁的客人，开始向那道熟悉的身影招手。|Guests at twelve tables begin to wave to the familiar figure.
帝江写下自己的名字，把纸留在食肆的值班簿里。|Dijiang writes its own name and leaves the paper in the inn’s duty book.
九首轮流讲述各自想做的菜，却总在最后一味调料前争执。|The nine heads take turns describing dishes they want to make, but always argue over the last seasoning.
通过连续三次真实的多线协调，让抢话变成分工；其他事件不会中断，协调失败才会重计。|Complete three actual coordination encounters in succession to turn interruption into cooperation. Other events do not break the sequence; a failed coordination does.
九首终于为同一桌客人报出一致的出菜顺序。|At last, the nine heads agree on a serving order for the same table.
九婴：我们仍有九种意见，但可以先听完，再一同上菜。|Jiuying: we still have nine opinions. We can hear them through, then serve together.
九婴烹饪并行容量由3提升至4，实际工作队列同步生效。|Jiuying’s parallel cooking capacity rises from 3 to 4 in the actual work queue; real stoves are still required.
九尾狐：若顾客只因魅惑停留，我是不是永远不知道他们真正喜欢什么？|Jiuweihu: if guests stay only because they are enchanted, will I ever know what they really like?
让他们记住十二次细致的服务，哪怕没有一个华丽的说法。|Let them remember twelve attentive services, even without a single splendid turn of phrase.
熟客说起她记得的口味和递上的温水，而不是数尾巴。|A returning guest speaks of a remembered flavour and the warm water offered, rather than counting tails.
九尾狐笑着收起传说的标签，继续询问下一桌的需要。|Jiuweihu smiles, sets the legend’s label aside and asks what the next table needs.
精卫：不放弃不该意味着永远不能歇息。|Jingwei: not giving up should not mean never being allowed to rest.
我愿意把一张张桌面擦净，却也想在收工时去看一眼岸边。|I will wipe each table clean, and I would also like to see the shore when work is done.
第十二次清台之后，精卫准时把抹布挂好。|After clearing the twelfth table, Jingwei hangs the cloth up on time.
她带着一包晚饭去看海。店里的灯，仍等她回来。|She takes a packed supper to see the sea. The inn’s lamp still waits for her return.
穷奇：我并非没有怒气，只是不知怎样让人听见。|Qiongqi: I do have anger. I do not know how to make someone hear it.
下一次争执，不靠恐吓压过去。把经过讲清，把不同意见听完。|In the next dispute, explain what happened and hear the other view through, rather than ending it with threats.
第三次调停结束，穷奇第一次主动把争执经过写下。|After the third mediation, Qiongqi volunteers for the first time to write down what happened.
他并没有失去锋芒，只是学会先问：究竟发生了什么？|His sharpness remains. He has learned to ask first: what actually happened?
獬豸：穷奇的凶名不是今天的证据，我的神兽之名也不是天然正确。|Xiezhi: Qiongqi’s fierce reputation is not today’s evidence, and my own mythic name does not make me right.
把三件真实的客诉处理完整，才算立下这间小馆共同认可的规矩。|Handle three actual complaints fully to establish a process the inn can agree on together.
第三份处理记录合上，双方各自确认了自己的陈述。|The third record closes. Both sides confirm their own accounts.
獬豸：规矩不是角的威力，而是每个人都能看见、也能理解的过程。|Xiezhi: a rule lives in a process everyone can see and understand, rather than the force of a horn.
你没有把所有异象都当作敌意。天狗在安抚中谈起漫长守夜的孤独。这段往事属于大荒市原创剧情，天狗的典籍形象请参看文化简介。|You did not read every strange sign as hostility. Reassured, Tiangou speaks of the loneliness of long nights on watch. This is a Dahuang story; Cultural Reading explores the creature’s older textual forms.
天狗吞月事件选择「安抚」|Choose Reassure in Tiangou’s Moon Event
昆仑集团曾替跨界商旅搭建粮道。后来，方便同行的契约渐渐变成排斥小店的门槛。你从真实的供应、服务与邻里合作中拼出这段原创商业史。|Kunlun once built grain routes for travellers between realms. Agreements that eased their journeys slowly became barriers to small inns. Actual supply, service and neighbourhood cooperation reveal this fictional commercial history.
实际解决昆仑商业封锁|Actually Resolve the Kunlun Blockade
白泽提议给每张脸编号，帝江却写下：也请记下我们怎样相待。白泽划掉了编号栏，为每页档案添上「未定之说」。|Baize suggests numbering each face. Dijiang writes: please also record how we treat each other. Baize crosses out the number column and adds room for an open question to each page.
白泽与帝江同时当班|Baize and Dijiang on Duty Together
精卫问冉遗鱼海中是否真的有尽头。冉遗鱼没有作答，只带来一条潮汐线。她把那条线收在值班簿里，约好轮休时一同看潮。|Jingwei asks Ranyiyu whether the sea has an end. Ranyiyu brings a line marking the tide instead of an answer. She keeps it in the duty book; they agree to watch the tide together when resting.
精卫与冉遗鱼同时当班|Jingwei and Ranyiyu on Duty Together
探索队在旧灶背后读到一句残铭：「饥者先食，来者先问。」这不是从现实古籍摘录的铭文，而是大荒市食肆传承的原创线索。|Behind an old stove, the expedition finds a fragment: feed the hungry first; ask the visitor first. This inscription is a clue to Dahuang’s inn tradition, created for this story.
探索「古食肆遗址」|Explore the Old Inn Ruins
山道旁旧路牌上的店号来自不同世界。早先的通行约定容纳许多小馆，后来却被一道道收费门替代。探索队拓印了它，带回给邻里共同辨认。|The old sign beside the mountain road names inns from different worlds. Earlier agreements made room for many small kitchens; toll gates later took their place. The expedition brings back a rubbing for the neighbours to read together.
探索「昆仑旧道」|Explore the Old Kunlun Road
山海裂隙另一侧，也有人在等一顿晚饭。所谓三界食肆，并非占据所有街巷，而是在陌生处仍愿意认真问一句：你想吃些什么？|Beyond the Shanhai rift, someone is waiting for supper too. An inn across three realms begins by asking, even in an unfamiliar place: what would you like to eat?
探索「三界裂隙」|Explore the Three-Realm Rift
凤凰留下的灰烬装在一只小瓷瓶里。它不展示神迹，只记得那次大家共同筹备的晚餐。|Fenghuang’s ash rests in a small porcelain bottle, remembering the supper everyone prepared together.
完成凤凰支线|Complete Fenghuang’s Story
白泽图补齐了缺页，却没有封笔。新页写着：这里收录的是曾经相遇的伙伴，而非他们最后的定义。|The missing pages of Baize’s album are filled, but the book stays open. A new page records companions met along the way, leaving their final definitions unwritten.
完成白泽支线|Complete Baize’s Story
值班簿上有九种笔迹，最终都签在同一条出菜记录之后。意见不同，也可以完成同一件事。|Nine hands finally sign beneath the same serving record in the duty book. Different opinions can still complete one task.
完成九婴支线|Complete Jiuying’s Story
凤|Fenghuang
凤凰专属支线所解锁的原创隐藏菜；品质基础85。|An original hidden dish unlocked through Fenghuang’s story; base quality 85.
丹木果、山海鱼与稀有食材|Danmu fruit, Shanhai fish and rare ingredients
闭店休息|Closed / Rest Period
以后不再自动弹出（仍可在系统→账单查看）|Do not open automatically again (still available in Settings → Bills)
在员工面板排班|Set Shifts in Staff
已平衡|Balanced
原始债务日息|Daily Interest on Initial Debt
每日最低还本|Daily Minimum Principal Repayment
员工工资|Staff Wages
连续3单好评带来口碑发酵：客流+15%，好评机会提升，持续1游戏日。|Three consecutive positive orders build word of mouth: arrivals +15%, improved positive-review chance, lasting 1 game day.
结账掉落概率+10个百分点，现金拾取金额加成10%，持续4游戏小时。同类金额加成取最佳来源。|Checkout pickup chance +10 percentage points; cash pickup value +10% for 4 game hours. The strongest bonus of the same kind applies.
耗用计入成本；贷款本金与装修资产支出不直接计入利润。拾取不计入菜品营业额。|Ingredients used become cost of sales. Loan principal and furnishing assets do not directly change profit. Pickups are separate from dish revenue.
采购形成存货、耗用计入成本；贷款本金与装修资产支出不直接计入利润。拾取不计入菜品营业额。|Purchases become inventory; ingredients used become cost of sales. Loan principal and furnishing assets do not directly change profit. Pickups are separate from dish revenue.
采购形成存货|Purchases Become Inventory
现金核对|Cash Reconciliation
经营收入|Operating Revenue
领取奖励|Claim Reward
食材采购成本-20%，持续3游戏小时。|Ingredient purchase cost -20% for 3 game hours.
'''
EXTRA_PATTERNS += [
(r'^候补/休息 (\d+) 位$','Reserve / resting: {1}'),
(r'^(净利润|净现金流|收入合计|支出合计)￥([+−-]?[\d.]+)$','{1}: {2}'),
(r'^剩(\d+)分钟$','{1} minutes left'),
(r'^(.+) 剩(\d+)分钟$','{1} · {2} minutes left'),
(r'^状态已开始；客流 ([+−-]?[\d.]+)%，持续至第(\d+)天 (\d\d:\d\d)$','Active: arrivals {1}%, until day {2}, {3}'),
(r'^点击手动拾取，剩([\d.]+)真实秒$','Click to collect; {1} real seconds left'),
]
EXTRA+='''
净利润|Net Profit
净现金流|Net Cash Flow
收入合计|Total Cash In
支出合计|Total Cash Out
'''
EXTRA+='''
主持人|Host
本届大荒美食节，有间小馆在与连锁品牌的角逐中获胜！白泽：胜负的背后，是日复一日的菜品与服务。|At this Dahuang Food Festival, the little inn has won against the chain brands! Baize: behind the result are the dishes and service we practise every day.
从中央厨房向已开设分店实际发送一次成品调拨。库存和运费都会记录。|Send one actual prepared-food shipment from the central kitchen to an open branch. Stock and shipping costs are recorded.
从几张旧桌椅到横跨三界的集团，小馆的名字仍在。现在，让最好的伙伴与菜品接受厨神大赛的检验。|From a few old tables to a group spanning three realms, the little inn keeps its name. Now let your best companions and dishes meet the cooking contest’s test.
十二位各具所长的伙伴，让山海风味有了新的可能。这份万象宴配方，是我们共同经营的纪念。|Twelve companions with different gifts bring new possibilities to Shanhai’s flavours. This Many-Forms Banquet recipe remembers the inn we run together.
在员工培养中使用技能书或同名碎片，升级一次员工技能。资源不足可稍后继续，待办会保留。|Use skill books or matching fragments in Training to upgrade a companion’s skill once. If resources are short, return later; the task stays available.
在菜单定价中调整一道菜的售价并确认。提价会影响价格敏感顾客，恢复原价也可作练习。|Change and confirm one price in Menu & Prices. A higher price affects price-sensitive guests; restoring the base price also counts as practice.
山海伙伴全员相聚。稀有度只是一种招聘分布，每位伙伴都有自己的岗位与成长。|All the Shanhai companions are together. Rarity describes recruitment chances; each companion has work and growth of their own.
建设中央厨房，实际开始一次批量制作。成品制作完成后才可调拨。|Build the central kitchen and begin one actual batch. Prepared dishes can be shipped only after production finishes.
开启外卖接单，等待订单后实际接下一单。外卖同样消耗食材与厨房产能。|Enable delivery orders, wait for an offer and accept one. Delivery also uses ingredients and kitchen capacity.
开展一次阶段2营销活动，观察花费与效果。资金不足时可稍后引导。|Run a stage-2 marketing campaign and observe its cost and effect. Postpone this guide if cash is short.
开设一家分店，并为它安排厨师与前厅。分店实际接待与库存共同决定收入。|Open a branch and assign kitchen and front-of-house staff. Actual guests and available stock determine branch revenue.
开通会员计划，让真实食客消费积累会员与积分。|Activate membership; actual guests’ purchases build membership and points.
我们回应了昆仑集团的竞争行动。独立经营的底气，来自透明的决定、稳定的供货和愿意留下的食客。|We have answered Kunlun’s competitive actions. The confidence to stay independent comes from clear decisions, steady supply and guests who choose to remain.
打开世界排行榜查看本地榜及赛季规则。本游戏的对手为单机NPC，不是联网玩家。|Open the league to read local standings and season rules. Opponents are offline NPCs, not online players.
打开装修，选择一件家具并在餐厅绿格实际摆放。只有购买成功才完成教学。|Open Furnish, choose a piece and place it on a green restaurant cell. The guide completes only after a successful purchase.
月中相聚，在小馆办一场邻里夜宴。这里是游戏自设节日，并非具体传统节日的考据还原。|Gather neighbours at the inn for a midmonth night meal. This is the inn’s own calendar celebration, rather than a reconstruction of a particular traditional festival.
月末向食客与伙伴致谢，也为本月的真实经营数据作一次复盘。|Thank guests and companions at month’s end, and look back over the month’s actual business records.
月末谢客|Month-End Thanks
有间小馆登上了厨神之巅。故事在这里留下一个句号，经营仍可继续。每位伙伴、每道菜和每间分店，都还有新的可能。|The little inn reaches the summit of the cooking contest. The story pauses here; service can continue. Every companion, dish and branch still has possibilities ahead.
望月夜宴|Moonwatch Night Meal
查看羁绊组合，将已拥有的组合伙伴安排为同班工作，使至少一组羁绊或相生实际生效。暂未拥有组合可稍后继续。|Check bonds and schedule an owned pair together so that at least one bond or synergy actually activates. Return later if you do not yet own a pair.
正式研发已开放|Recipe Research Is Now Available
选择厨师和配方，完成一次研发。研发会消耗真实资金与食材，期间主持人暂时离岗。|Choose a cook and recipe, then complete one research project. It uses actual cash and ingredients; its leader temporarily leaves ordinary work.
派出一位可用伙伴开始探索，等待其归来获得真实成果。主店要留够人手。|Send an available companion on an expedition and wait for the actual return. Keep enough staff at the main inn.
账上的债务终于归零。小馆是大家一起保住的，接下来去更大的舞台吧。|The debt finally reaches zero. We kept this inn going together. Now we can step onto a larger stage.
选择一位资源足够的伙伴举行觉醒。觉醒会消耗同名碎片与资金，永久提升属性。|Choose an eligible companion with enough resources for awakening. It spends matching fragments and cash for permanent attribute growth.
选择厨师与已研发菜品，实际报名一次厨神大赛。比赛期间厨师会离岗。|Choose a cook and researched dish to enter the actual cooking contest. The cook leaves ordinary work during the contest.
'''
EXTRA_PATTERNS += [(r'^(.+)  ([+−-]?[\d.]+)$','{1}: {2}')]
EXTRA+='''
原始债务利息|Initial-Debt Interest
原始债务还本|Initial-Debt Principal
食材采购|Stock Purchases
顾客预收款|Guest Prepayment
预收款退回|Prepayment Refund
Lin的下一次用餐预收款（尚非收入）|Lin’s next-visit prepayment (not revenue yet)
退还Lin的未履行订单预收款|Refund Lin’s unfulfilled-order prepayment
Lin换单后退还预收余款|Refund the prepayment balance after Lin’s changed order
毕方与伙伴的炉边协作培训|Bifang’s grill teamwork training
毕方炉边培训|Bifang’s grill training
当康来信采购|Purchase following Dangkang’s letter
当康赠粮|Dangkang’s shared grain
'''
EXTRA_PATTERNS += [(r'^(.+)售罄。食客心情(-?\d+)，缺货差评，声望(-?\d+)，食客离店$','{1} sold out. Guest mood {2}, a shortage-related negative review, reputation {3}; the guest leaves.')]
