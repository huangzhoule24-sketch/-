#!/usr/bin/env python3
"""Verify the recorded English release checks and preserve reviewable evidence."""
from pathlib import Path
import json,re,shutil,subprocess
from package_release import game_source_fingerprint
ROOT=Path(__file__).resolve().parent.parent
BUILD=ROOT/'build/english-r2'
OUT=ROOT/'docs/validation-artifacts/english-r2'

def main():
 source=game_source_fingerprint()
 assert source==json.loads((BUILD/'tested-source.json').read_text()),'Runtime changed after regression checks began'
 log=(BUILD/'full-checks-final.log').read_text()
 groups=re.findall(r'^PASS ([^:]+):',log,re.M)
 assert len(groups)==53 and not re.search(r'^FAIL|SCRIPT ERROR:|^ERROR:',log,re.M),'Full regression has not passed'
 native=json.loads((BUILD/'localization-tests.json').read_text())
 assert native['failures']==0 and native['missing']==[] and native['event_choices']==native['event_resolved']==55 and native['event_windows']==22
 missing=json.loads((BUILD/'untranslated-ui.json').read_text());assert missing=={}
 states=json.loads((BUILD/'language-panels.json').read_text());assert len(states)==313
 assert 'incomplete translations: 0' in (BUILD/'ui-audit-final.log').read_text()
 assert not re.search(r'^ERROR:|SCRIPT ERROR:',(BUILD/'ui-audit-final.log').read_text(),re.M)
 browser=json.loads((BUILD/'browser/report.json').read_text())
 assert browser['game_source']==source and not browser['errors'] and len(browser['checks'])>=8 and all(c['ok']for c in browser['checks'])
 assert len(browser['actions'])>=80 and len(browser['english_snapshots'])>=80 and all(not s['bad']for s in browser['english_snapshots'])
 for platform in ['web','windows']:
  receipt=json.loads((ROOT/'build'/('full-web'if platform=='web'else'full-windows')/'export-receipt.json').read_text())
  assert receipt['game_source']==source
 catalogue=json.loads((ROOT/'config/localization.json').read_text());culture=json.loads((ROOT/'config/culture.json').read_text())
 prior=json.loads(subprocess.check_output(['git','show','59f4bc2:docs/culture-research/player-edition.json'],cwd=ROOT))
 for kind in ['employees','dishes','guests']:
  for id,entry in culture[kind].items():
   old=prior[kind][id]
   for key in ['name','summary','sections','en']:assert entry[key]==old[key],(kind,id,key)
   assert [(q['text'],q['paraphrase'])for q in entry.get('quotes',[])]==[(q['text'],q['paraphrase'])for q in old.get('quotes',[])]
 preservation=json.loads((BUILD/'assets-config-preservation.json').read_text());assert preservation['all_existing_art_audio_and_balance_files_unchanged']
 research=json.loads((ROOT/'docs/translation-research/english-r2-sources.json').read_text());assert research['published_matches_verified'] and research['waley_total_excerpt_words']<=90
 summary={'version':'SH-EN-R2','validated_on':'2026-11-01','game_source':source,'native_groups':groups,'native_group_count':len(groups),'english_checks':native['checks'],'display_candidates':len(json.loads((BUILD/'coverage-input.json').read_text())['candidates']),'event_choices':native['event_choices'],'event_messages':native['event_messages'],'event_windows':native['event_windows'],'untranslated_candidates':0,'ui_states':len(states),'untranslated_ui':0,'browser_actions':len(browser['actions']),'browser_checks':len(browser['checks']),'english_browser_snapshots':len(browser['english_snapshots']),'browser_errors':browser['errors'],'classical_excerpts':54,'published_excerpts':4,'project_renderings':50,'chinese_and_literary_preserved':True,'art_audio_balance_preserved':True,'limits':['Fixtures are not natural campaign completion.','Browser checks include a real Lin booking outcome and real elapsed time, not a forced successful meal.','No Windows or phone hardware playtest, human language review or cultural-effectiveness study is claimed.']}
 OUT.mkdir(parents=True,exist_ok=True)
 (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 for name in ['full-checks-final.log','localization-tests.json','language-panels.json','untranslated-ui.json','ui-audit-final.log','assets-config-preservation.json']:
  shutil.copy2(BUILD/name,OUT/(name[:-4]+'.txt'if name.endswith('.log')else name))
 shutil.copy2(BUILD/'browser/report.json',OUT/'browser-report.json')
 for name in ['01-english-welcome.png','01b-mobile-guide.png','03b-waley-owl-poems.png','03-first-accounts.png','12-letters-english.png','13-mobile-letters.png','16-chinese-return.png']:
  shutil.copy2(BUILD/'browser'/name,OUT/name)
 (ROOT/'docs/english-version-validation.md').write_text(f'''# SH-EN-R2 英文版验证

验证日期：2026-11-01。基于当前 SH-CULTURE-R1 完整经营版本；不是新 Demo。运行源码指纹 `{source['sha256']}`，{source['files']} 项；Web 与 Windows 导出回执一致。

53 组原生回归全部通过，其中英译专项 {native['checks']} 项。直接提取 {summary['display_candidates']} 条脚本与配置文案候选，另实际解析 38 类事件的 55 个选项、{native['event_messages']} 条反馈与通知，并打开 22 个交互/通知事件的真实弹窗；全部未译检查通过。内部跳转 ID、资源路径和原本应保留的中文读本/古文与界面文案分开核对，未使用任意词语替换掩盖缺译。

313 个实际页面状态覆盖全体员工详情/培训、全部 61 篇读本、有记录账单、来信、特殊顾客、开发者导入、在途生产与后期工具，0 覆盖未译文本。包括下拉菜单重建后的语言往返、弹窗标题、输入框提示、导入大小提示、现金飘字、带稀有度颜色的通知和多行体力提示。检查数据中的后期状态是测试夹具，不表示自然通关。

Chromium 实际浏览器 {summary['browser_actions']} 次鼠标/滚轮操作、{summary['browser_checks']} 项结果检查，{summary['english_browser_snapshots']} 次英文文本快照均无残留中文界面文案，0 浏览器错误。流程含英文六步开局、真实首单与账单、经图鉴进入未招募员工的韦利诗文、Lin 真实预约结果与经过实际时间的回信、844×390 横屏返回、保存刷新和中英切换。中文姓名、诗文原文和中文语言按钮有意保留，不计作漏译。

译本：两段《诗经》采用 Arthur Waley，连续混沌寓言两段采用 Herbert A. Giles。原在线文本与游戏译文已比对，韦利共 83 词；其余 50 段明确标为项目译述。引用资料和固定链接在 `translation-research/english-r2-sources.json`。61 篇中英文文学叙事与 54 段中文原文、白话逐字段保留；全部已有美术、音频、经营数值配置逐字节未改。独立音乐未导入。

语言偏好独立于经营存档，往返切换不改变经济数据和模拟随机数。英文 CSV 的标题、用途文字与数额经过专项检查；原公式防护保留。完整测试在临时存档目录运行，避免玩家原有语言偏好干扰测试或被测试覆盖。

这不替代英文母语者审校、Windows/手机硬件试玩或课程中的真人传播评估。部分扩展测试夹具在进程退出时有 ObjectDB 引用回收警告，原始记录保留；未将此类进程退出记录称为正式游戏运行时内存测试。

原始汇总、页面清单、浏览器记录和截图在 `validation-artifacts/english-r2/`。公开 ZIP 下载回读证据在发布后另行追加，不覆盖已校验归档。
''',encoding='utf-8')
 print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
