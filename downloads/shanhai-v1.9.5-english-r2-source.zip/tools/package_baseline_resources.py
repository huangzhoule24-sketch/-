#!/usr/bin/env python3
"""Package unchanged editable resources directly from an archived source ZIP."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile

ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'build/山海食肆物语-v1.9.5-culture-origins-Source.zip'
EXPECTED='e244cef74629a343dc0bb1bfc1f4390ddbc6299a46167ea310a5a2e89d0fdbf9'
OUT=ROOT/'build/source-baseline-20261031'
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert sha(SOURCE.read_bytes())==EXPECTED
OUT.mkdir(parents=True,exist_ok=True)
selected={}
docs={
 'docs/art-pipeline.md','docs/art-complete-guide.md','docs/animation-rules.md',
 'docs/山海食肆物语-美术资源清单.md','docs/art-resource-list-v1.9.3.csv',
 'docs/audio-pipeline.md','docs/audio-resource-list.csv','docs/free-sfx/guide.md',
 'docs/free-sfx/selection.json','docs/free-sfx/sources.json','docs/culture-guide.md',
 'docs/culture-entries.md','docs/culture-origins.md',
 'tools/licenses/Godot-LICENSE.txt','tools/licenses/Godot-COPYRIGHT.txt','tools/licenses/NOTICE.txt',
}
with zipfile.ZipFile(SOURCE)as z:
    assert z.testzip()is None
    for info in z.infolist():
        name=info.filename;p=PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts
        if info.is_dir():continue
        if name.startswith(('assets/','art-source/','CustomAssets/','CustomAudio/','config/')) or name in docs:
            selected[name]=z.read(name)
asset_manifest={name:{'bytes':len(raw),'sha256':sha(raw)}for name,raw in selected.items()}
counts={
 'builtin_art_png':sum(n.startswith('assets/art/')and n.endswith('.png')for n in selected),
 'source_master_images':sum(n.startswith('art-source/masters/')and n.endswith('.png')for n in selected),
 'audio_files':sum(n.startswith('assets/audio/')and n.endswith(('.ogg','.mp3','.wav'))for n in selected),
}
assert counts=={'builtin_art_png':274,'source_master_images':22,'audio_files':42},counts
culture=json.loads(selected['config/culture.json'])
assert [len(culture[k])for k in ['employees','dishes','guests']]==[30,25,6]
selected['资源包使用说明.txt']='''山海食肆物语 v1.9.5 · 典籍身世版 · 可编辑资源包
整理日期：2026-10-31

本包所有现有资源逐字节取自对应源代码归档，未重新生成或改绘。

assets/art：274张内置PNG，含员工水墨立绘、像素人物图集、顾客、家具、菜品、UI和场景；动画映射见animation_catalog.json。
art-source/masters：22张选定的美术生成母图与相关输入记录。
assets/fonts：当前清晰字体、像素字体、稀有字补字字体及许可。
assets/audio：42个音效/环境声文件，原作者鸣谢与许可须保留。
config：对应版本的经营与文化数据；文化小传30员工、25菜、6来客。
CustomAssets与CustomAudio：后续资源替换目录与说明。
docs：接入、动画、资源清单、完整文化读本与音效来源等说明。

这是编辑资源包；直接游玩请下载Windows游戏包或网页包。PNG动画使用图集，不是每帧一个独立文件；保持现有帧尺寸与锚点。替换方式见docs/art-pipeline.md。
配乐槽按原版留空，此前独立试听的长笛音乐未加入。
音效有CC0与CC BY 4.0授权；转交或发布时保留assets/audio/CREDITS.md及licenses目录。字体与引擎许可亦保留。
本包不包含10月30日修改提案的未实施机制或独立交互样例。
'''.encode('utf-8-sig')
selected['RESOURCE-MANIFEST.json']=(json.dumps({'source_archive_sha256':EXPECTED,'counts':counts,'files':asset_manifest},ensure_ascii=False,indent=2)+'\n').encode()
selected['SHA256SUMS.txt']=''.join(sha(v)+'  '+n+'\n'for n,v in selected.items()).encode()
target=OUT/'shanhai-v1.9.5-culture-origins-resources.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,raw in selected.items():z.writestr(name,raw)
with zipfile.ZipFile(target)as z:
    assert z.testzip()is None
    for name,expected in asset_manifest.items():
        raw=z.read(name);assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
result={'file':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'source_archive_sha256':EXPECTED,'counts':counts,'files':len(selected),'zip_crc_valid':True,'original_assets_unchanged':True}
(OUT/'resource-package.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
