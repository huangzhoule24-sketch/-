#!/usr/bin/env python3
"""Assemble checked release evidence; never turn an incomplete browser run into a pass."""
from pathlib import Path
import json,re,shutil,hashlib,subprocess
from package_release import game_source_fingerprint
ROOT=Path(__file__).resolve().parent.parent
BUILD=ROOT/'build';OUT=ROOT/'docs/validation-artifacts/culture-r1/final'
def read(path):return json.loads((ROOT/path).read_text())
def dump(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
source=game_source_fingerprint()
checks=read('build/culture-r1-release-checks.json')
assert checks['exit_code']==0 and checks['unchanged_through_checks'] and checks['game_source']==source
suite=(BUILD/'culture-r1-release-checks.log').read_text()
assert len(re.findall(r'^PASS ',suite,re.M))==52 and not re.search(r'^FAIL |SCRIPT ERROR:',suite,re.M)
browser_dir=BUILD/'culture-r1-browser-accepted'
browser=json.loads((browser_dir/'report.json').read_text())
assert browser['game_source']==source and not browser['errors'] and len(browser['checks'])>=6 and all(x['ok']for x in browser['checks'])
assert read('build/culture-r1-untranslated-ui.json')=={}
assert 'SCRIPT ERROR:'not in (BUILD/'culture-r1-language-final.log').read_text()
for platform in ['web','windows']:assert read('build/full-'+platform+'/export-receipt.json')['game_source']==source
OUT.mkdir(parents=True,exist_ok=True)
for p in (BUILD/'check-results').glob('*.log'):shutil.copy2(p,OUT/(p.stem+'.txt'))
for name in ['culture-r1-release-checks.json','culture-r1-release-checks.log','culture-r1-language-final.log','culture-r1-language-panels.json','culture-r1-untranslated-ui.json']:
 p=BUILD/name;shutil.copy2(p,OUT/(p.stem+'.txt'if p.suffix=='.log'else name))
shutil.copy2(browser_dir/'report.json',OUT/'browser-report.json')
for name in ['01-english-welcome','01b-mobile-guide','06-dijiang','07-origins-english','09-menu-evidence','12-letters-english','13-mobile-letters','15-mobile-dumplings','16-chinese-return']:
 shutil.copy2(browser_dir/(name+'.png'),OUT/(name+'.png'))
original=subprocess.check_output(['git','show','c4c3602:config/culture.json'],cwd=ROOT)
assert original==(ROOT/'config/culture.json').read_bytes()
culture=read('config/culture.json');content=read('config/cultural_experience.json');loc=read('config/localization.json')
quotes=sum(len(entry.get('quotes',[]))for kind in ['employees','dishes','guests']for entry in culture[kind].values())
assert [len(content[k])for k in ['cast','menus','guests']]==[30,25,6] and quotes==54
preserved={}
for name in ['global_balance','employees','dishes','ingredients','management','full_game']:
 path='config/'+name+'.json';raw=(ROOT/path).read_bytes();assert raw==subprocess.check_output(['git','show','c4c3602:'+path],cwd=ROOT);preserved[path]=hashlib.sha256(raw).hexdigest()
proof={'version':'SH-CULTURE-R1','game_source':source,'native_groups':52,'browser_actions':len(browser['actions']),'browser_checks':len(browser['checks']),'browser_errors':browser['errors'],'lin_browser_outcome':next(x.get('outcome')for x in browser['checks']if 'outcome'in x),'interface_panel_states':len(read('build/culture-r1-language-panels.json')),'untranslated_in_audit':0,'localization_exact':len(loc['strings']),'localization_patterns':len(loc['patterns']),'original_culture_sha256':hashlib.sha256(original).hexdigest(),'classical_quote_records':quotes,'preserved_mechanical_configs':preserved,'windows_native_playtest':False,'physical_mobile_playtest':False,'human_cultural_evaluation':False}
dump(OUT/'release-validation.json',proof)
progress=read('docs/cultural-redesign-progress.json')
for task in progress['tasks']:
 if task['id']not in ['PLAY-01','COURSE-01']:task['status']='verified';task.pop('note',None)
 else:task['status']='proposed'if task['id']=='PLAY-01'else'implemented_unverified';task['note']='材料已准备；真人试玩及三专业同学审校/效果评估待实际参与者完成。'
progress.update({'checkpoint_state':'technical_release_verified','last_user_request':'继续','release_ready':True,'implementation_complete':True,'human_evaluation_complete':False,'game_source':source,'validation':'docs/validation-artifacts/culture-r1/final/release-validation.json','resume_next':['完成归档和公开下载校验；真人两轮试玩/三专业同学审校按材料进行，不伪造结果。']})
dump(ROOT/'docs/cultural-redesign-progress.json',progress)
(ROOT/'docs/cultural-redesign-progress.md').write_text('''# SH-CULTURE-R1 技术实施完成

已从35c4553保存点继续，完成技术实现、复验与同源Web/Windows导出。21项技术任务完成；PLAY-01真人试玩与COURSE-01中的真人/同学审校未发生，材料已准备，不能作为传播效果已验证。

三事件、四站驿路、30伙伴/25菜/6来客、六人新图、三种神通的经营反馈、探索来信、分店主题、按实际经历写出的终局回顾已接入。菜单和研发页均有用料/菜名说明，保留原61篇中英读本与54段原文。

最终检查52组通过，源码在检查期间未变化。新规则63项、UI135项、后期46项通过。英语覆盖176个页面状态、真实日结及有记录的账单/流水/反馈，并检查教学/主线/支线配置文本；覆盖审查未发现未译字段。当前词库1552项/357模板，不把0残留等同于真人翻译质量审校。

浏览器真实操作涵盖英文首单、菜单、角色与典籍返回、Lin实际预约结算或退款、强制日结/事件确认、经过真实时钟的回信、小屏固定返回、存档刷新和语言偏好。完整数字与图见docs/cultural-redesign-validation.md和validation-artifacts/culture-r1/final。旧incomplete报告保留为迭代记录，不计作通过。

已修复英文实时刷新回中文、教学卡确认被滚动区藏住/小屏宽度残留、多角色连续发言被冒号拆坏、实际菜单位于研发页之外缺说明、预约退款仍标为履约完成、财务新预收/退款类别显示内部代码等问题。探索来信在库存/历史/移除任务之后才请求保存，真实存读验证不重放奖品。

当前代码与资源是正式文化体验改造版，原阶段0–4与旧档保留；不是用独立样例代替正式游戏。源码主包与全部美术母图分两ZIP，同目录解压恢复完整工程。独立配乐未导入；Windows仅验证导出与文件完整性，未做Windows/手机实机验收。公开下载证据在发布后追加。
''')
(ROOT/'docs/cultural-redesign-validation.md').write_text(f'''# SH-CULTURE-R1 验证与范围

技术实现与检查已完成。游戏源码指纹：`{source['sha256']}`（{source['files']}文件），Web与Windows导出相同，检查前后不变。

- 完整原生回归52组通过。新文化规则63项、界面135项、后期46项；美术11739项、座位层438项、旧档82项等原有检查继续通过。逐组日志与指纹回执见validation-artifacts/culture-r1/final。
- 浏览器{proof['browser_actions']}次真实鼠标/键盘/滚动操作，{proof['browser_checks']}项结果检查，0脚本/浏览器错误。英文首单、账表、菜牌、帝江小传及典籍、原父页返回、实际Lin预约的结算/退款、日结与事件弹窗、满一天回访、844×390返回、保存刷新及中英偏好已检查。本次Lin结果为`{proof['lin_browser_outcome']}`；另一履约/退款路线由真实模型服务回归覆盖，早期浏览器亦记录过正常履约。
- 英语审查176页面状态及教学/主线/支线数据；含实际日结与有记录的账单、流水、反馈，核对实际打开的财务页面，覆盖审查0未译字段。{len(loc['strings'])}精确词条/{len(loc['patterns'])}参数模板；不声称所有未来随机组合和英语文学质量已由外国玩家审校。
- 原文化配置与c4c3602逐字节相同，61篇中英阅读、54段原文保留；原员工、菜品、原料、全局经济/管理配置逐字节保留。新宴席培训费用/时间/5%工时变化独立列在文化体验配置中，不覆盖原基数。
- 六位优先伙伴的立绘/四方向像素已目视联系图复核；继续使用有界绑定烘焙，14400帧格不是逐帧手绘。身体上下≤1源像素、抬脚≤2，原设备预约、真实服务点、座位层和清晰字体保留。

早期失败日志以incomplete或旧文件名保留，只用于追踪实际修复；最终证据使用final子目录。所有浏览器QA只读快照并物理操作界面，不写浏览器经营状态。跨日按钮会受事件与日结暂停打断，回信按实际时间到期，测试没有注入时间或手工补信。

未做真人文化传播效果测量、Windows本机或手机实机试玩。课程材料docs/course-r1供组员填写真实审校/两轮观察；不含虚构受试者。独立配乐未导入。
''')
# Refresh the six editorial cards after the final bilingual anchor pass.
p=ROOT/'docs/course-r1/six-source-to-play-cards.json';cards=json.loads(p.read_text())
for card in cards:card['source_layers']=next(e['source_layers']for e in content['cast']if e['id']==card['id'])
dump(p,cards)
print(json.dumps(proof,ensure_ascii=False))
