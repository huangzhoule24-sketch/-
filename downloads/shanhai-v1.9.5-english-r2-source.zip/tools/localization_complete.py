"""Reviewed full-sentence English additions; never replace words inside prose."""

PAIRS = r'''
休息时段|Closed for Rest
日常经营|Everyday Service
拓展经营|Growing the Business
连锁经营|Chain Management
三界集团|Three-Realm Group
山海档案|Shanhai Archives
事件图鉴|Event Archive
羁绊图鉴|Companion Bonds
招聘、训练、宣传和简单布置|Recruitment, training, promotion and basic furnishing
正式研发、手动定价、员工技能和装修|Recipe research, menu pricing, staff skills and furnishing
会员、外卖、营销活动和羁绊组合|Membership, delivery, marketing and companion bonds
三家分店、中央厨房、供应链和山海探索|Three branches, a central kitchen, supply chains and Shanhai expeditions
完整经营规则尚未初始化|Campaign rules have not finished loading.
员工详情|Staff Details
当前无法招聘，请检查资源与契约|Recruitment is unavailable. Check your funds and contracts.
需要阶段 %d · %s|Requires stage %d · %s
待还本金 ￥%.2f。还本与利息分开记录；不要花光采购与发薪资金。|Principal outstanding: ¥%.2f. Principal and interest are recorded separately. Keep cash for ingredients and wages.
还款 ￥%d|Repay ¥%d
没有待还本金|No principal outstanding
补缴罚款 · 尚欠￥%.2f|Pay Fine · ¥%.2f outstanding
烛龙 · 昼夜神通|Zhulong · Master of Day and Night
每日一次：选择今日采用的营业时段客流系数。不会推进时钟，也不会在休息时间生成顾客。|Once a day, choose an arrival-rate modifier for today's service periods. This does not advance the clock or bring guests during closing hours.
当班 %d/%d · 已拥有 %d 位。招募获得重复伙伴时转化为碎片；候补仍计发工资。|On duty %d/%d · %d recruited. Duplicate recruits become fragments. Reserve staff still receive wages.
故事契约 ×%d|Story contracts ×%d
使用成长目标奖励的指定伙伴契约|Use a companion contract earned from a growth goal
派驻 ·|Assigned to Branch ·
体力 %d  心情 %d  忠诚 %d  ·  %s|Stamina %d  Mood %d  Loyalty %d  ·  %s
离职交接中|Finishing Before Departure
分店按排班营业，体力耗尽时自动休整。可在连锁经营中调回主店。|Branch staff follow their shifts and rest when exhausted. Recall them through Chain Management.
查看派驻与调回|Manage Branch Assignments
返回工作|Return to Work
每日自动采购：%s（点击%s）|Daily auto-purchasing: %s (click to %s)
%s · 库存 %.2f份|%s · %.2f portions in stock
单价 ￥%.2f · 新鲜度 %d%% · %s|Unit price ¥%.2f · Freshness %d%% · %s
采购 %d份|Buy %d Portions
需要先解锁相应供应商|Unlock the relevant supplier first.
当前没有可用库存目录，请重载数值配置后重新打开。|No stock catalogue is available. Reload the balance configuration, then reopen this page.
当前阶段任务 ·|Current Stage Goal ·
进度 %.0f/%.0f|Progress %.0f/%.0f
当前：阶段 %d · %s。累计营业额 ￥%.2f，声望 %d。升级同时要求营业额与声望，达到后由你手动确认。|Stage %d · %s. Total revenue ¥%.2f; reputation %d. Meet both requirements, then confirm the upgrade.
成长目标|Growth Goals
进度 %d/%d · %s|Progress %d/%d · %s
阶段 %d · %s%s|Stage %d · %s%s
（当前）|(Current)
（已达成）|(Reached)
累计营业额 ￥%d · 声望 %d · 员工上限 %d · 日租金 ￥%d|Total revenue ¥%d · Reputation %d · Staff limit %d · Daily rent ¥%d
规模：%d张餐桌上限|Capacity: up to %d tables
规模：三处分店|Scale: three branches
规模：跨人间、妖界与天庭|Scale: the human realm, spirit realm and celestial court
确认升级？新阶段的日租金将调整为 ￥%d，新增功能会立即开放。|Confirm this upgrade? Daily rent will become ¥%d, and the new features will open immediately.
确认升级为|Confirm Upgrade to
升级为|Upgrade to
营业额和声望尚未同时达到要求|Both revenue and reputation requirements must be met.
查看升级确认|Review Upgrade
还需营业额 ￥%.0f、声望 %d|Still needed: ¥%.0f revenue and %d reputation
技能书 %d 本。技能培养需阶段1；同一角色的碎片由重复招聘与探索获取。|%d skill books. Skill training opens at stage 1. Obtain a companion's fragments through duplicate recruitment and expeditions.
%s · %s · 等级%d/%d · 技能 Lv.%d|%s · %s · Level %d/%d · Skill Lv.%d
离职交接中：完成当前项目后离开，不能再安排新项目。|Leaving after the current project. No new projects can be assigned.
主职 %s · 副职 %s · 每日额外工资 ￥%d · 碎片 %d|Primary: %s · Secondary: %s · Extra daily wages ¥%d · Fragments %d
未培训|Not Trained
当前项目剩余 %d 游戏分钟，关闭面板后继续推进。|%d game minutes remain on this project. Close the panel to let it continue.
训练费用 ￥%.0f；关闭面板后开始推进。|Training costs ¥%.0f. Close the panel to begin.
切换为|Switch to
培训副职·|Train Secondary Role ·
碎片升级技能 · %d碎片|Upgrade Skill · %d Fragments
加薪 ￥10/日|Raise Wages by ¥10/Day
进行中的培养与研发|Active Training & Research
%s · %s · 剩余 %d 分钟|%s · %s · %d minutes remaining
项目|Project
暂无可主持研发的在岗厨师或导师；请先结束其他项目、调回分店员工或调整排班。|No on-duty cook or tutor is available for research. Finish another project, recall branch staff or change the shifts.
%s · %s · 创意%d%s|%s · %s · Creativity %d%s
· 必成功|· Guaranteed Success
阶段0的三道基础菜已解锁；正式研发在阶段1开放。先经营、还债并提升声望，再从经营升级确认成长。|The three opening recipes are already available. Research opens at stage 1. Serve guests, repay debt and earn reputation, then confirm your growth in Grow the Restaurant.
查看升级条件|View Upgrade Requirements
%s · 参考售价 ￥%.2f|%s · Suggested price ¥%.2f
关联伙伴：|Associated companion:
%s %.2f份（库存 %.2f）|%s: %.2f portions (%.2f in stock)
配方：|Recipe:
正在研发。关闭面板并继续营业，项目会自动推进。|Research is underway. Close the panel and resume service to let it continue.
开始研发|Start Research
未上架|Off the Menu
售价 ￥%.2f · 基础售价 ￥%.2f · 配方成本 ￥%.2f|Menu price ¥%.2f · Base price ¥%.2f · Recipe cost ¥%.2f
售罄：当前食材不足，顾客不会点这道菜。补货后自动恢复可售。|Sold out: not enough ingredients. Guests cannot order this dish until you restock.
售罄 · 暂不可上架|Sold Out · Cannot Add to Menu
确认售价|Confirm Price
%d灵石|%d Spirit Gems
客流 +%.0f%% · %d游戏分钟|Arrivals +%.0f%% · %d game minutes
；平均品质至少%.0f|; average quality must be at least %.0f
；有概率触发合作事件|; may trigger a partnership event
开展|Launch
￥%.0f + %d灵石 · 持续%d分钟|¥%.0f + %d Spirit Gems · Lasts %d minutes
会员 %d 人 · 积分 %d · %s|%d members · %d points · %s
优惠券待使用|Coupon Available
开通会员计划 · ￥%.0f|Launch Membership · ¥%.0f
兑换会员优惠券 · %d积分|Redeem Member Coupon · %d Points
已完成 %d 单 · 外卖入账 ￥%.2f|%d deliveries completed · Delivery receipts ¥%.2f
暂停外卖接单|Pause Delivery Orders
新外卖：%s · ￥%.2f · 剩余%d分钟|New delivery: %s · ¥%.2f · %d minutes left
接下这一单|Accept Order
在途 #%s · %s · 剩余%d分钟|In transit #%s · %s · %d minutes left
累计营业额 ￥%.2f · 已接待%d位 · 日租金￥%.0f|Total revenue ¥%.2f · %d guests served · Daily rent ¥%.0f
在店库存：|Branch stock:
开设分店 · ￥%.0f|Open Branch · ¥%.0f
调回主店：%s（%s）|Recall to Main Inn: %s (%s)
派驻所选员工|Assign Selected Staff
调拨%s ×%d|Transfer %s ×%d
建设中央厨房 · ￥%.0f|Build Central Kitchen · ¥%.0f
中央成品：|Central kitchen stock:
批量制作%s ×5|Batch Cook %s ×5
制作中：%s ×%d · 剩余%d分钟|Cooking: %s ×%d · %d minutes left
调拨在途：%s ×%d → %s · 剩余%d分钟|Transfer underway: %s ×%d → %s · %d minutes left
前往山海探索|Go to Shanhai Expeditions
消耗 ￥%.0f + %d灵石 · 耗时%d游戏分钟|Costs ¥%.0f + %d Spirit Gems · Takes %d game minutes
大荒山野|The Dahuang Wilds
派遣探索 ·|Send Expedition ·
探索队伍 ·|Expedition Team ·
剩余 %d 游戏分钟|%d game minutes remaining
最近探索成果|Recent Expedition Finds
食材 %s · 灵石%d · %s碎片%d|Ingredients: %s · Spirit Gems %d · %s fragments %d
消耗 ￥%.0f + %d灵石 + %d同名碎片。全属性永久提升，并切换觉醒美术状态。|Costs ¥%.0f + %d Spirit Gems + %d fragments of this companion. Permanently increases all attributes and unlocks their awakened appearance.
已觉醒|Awakened
伙伴已经觉醒|This companion is already awakened.
报名 ￥%.0f + %d灵石 · 耗时%d分钟 · 冠军门槛%.0f分|Entry ¥%.0f + %d Spirit Gems · Takes %d minutes · Winning score %.0f
需要有厨师与已研发菜品|You need a cook and a researched dish.
比赛中 · 剩余%d分钟|Competing · %d minutes left
参赛%d次 · 夺冠%d次 · 最高分%.1f|%d entries · %d wins · Best score %.1f
上届：%.1f分 · %s|Last contest: %.1f points · %s
夺得冠军|Champion
继续磨练厨艺|Keep Practising
本地单机世界榜 · 模拟对手|Local League · Simulated Rivals
已阅读本地世界榜规则：12家NPC企业，30天赛季。|League rules read: 12 NPC businesses, with a 30-day season.
第%d赛季 · 第%d/%d天 · 每日结算后更新|Season %d · Day %d/%d · Updated after daily settlement
单机模拟榜，经营数据在每日结算时更新。|An offline simulated league. Business results update after each daily settlement.
%d. %s · %.1f分|%d. %s · %.1f points
今日营收￥%.2f · 今日利润￥%.2f · 声望%d · 分店%d|Today's revenue ¥%.2f · Today's profit ¥%.2f · Reputation %d · Branches %d
近期赛季记录|Recent Seasons
第%d赛季 · 第%d—%d天 · 本店第%d名|Season %d · Days %d–%d · Our rank: %d
（当前不可派遣）|(Unavailable for Assignment)
没有可选的员工|No Staff Available
暂无成品|No Prepared Dishes
美食节参赛准备|Food Festival Preparation
选择主店在岗厨师和已研发菜品。报名消耗入场费及一份真实配方食材，品质、创意与招牌搭配决定成绩。|Choose an on-duty cook at the main inn and a researched dish. Entry uses the fee and one recipe's ingredients. Quality, creativity and signature pairings determine the result.
需要可参赛的厨师与已研发菜品。|You need an available cook and a researched dish.
%s · 厨艺%d · 创意%d|%s · Cooking %d · Creativity %d
· 食材不足|· Not Enough Ingredients
确认参赛搭配|Confirm Contest Pairing
已准备：%s + %s|Prepared: %s + %s
最近比赛：%.1f / 对手%.1f · %s|Last contest: %.1f / rival %.1f · %s
获胜|Won
继续磨练|Keep Practising
供应、服务与社区支持已形成合力，昆仑商业封锁已经突破。|Reliable supplies, good service and community support have broken the Kunlun trade blockade.
昆仑商会封锁对抗|Breaking the Kunlun Blockade
应对商会捣乱后，稳住供应、完成优质服务并争取社区支持，三项达成才会真正突破封锁。|After facing the guild's interference, secure supplies, serve quality meals and win community support. All three are needed to break the blockade.
已应对%d次 · 优质服务%d/%d单 · 品质要求≥%.0f|%d incidents handled · Quality meals %d/%d · Quality required ≥%.0f
封锁已突破。|The blockade has been broken.
建立替代供应|Find Alternative Supplies
展示真实服务成绩|Present Service Results
争取社区支持|Win Community Support
· 已完成|· Complete
已经达成|Already Achieved
参考售价 ￥%.2f · 配方成本 ￥%.2f · %s|Suggested price ¥%.2f · Recipe cost ¥%.2f · %s
尚未研发|Not Researched
招牌伙伴：|Signature companion:
用料：|Ingredients:
技能书 · 持有%d本|Skill Books · %d Owned
阶段1起可代替碎片升级员工技能。通过成长目标、剧情奖励、月度经营和山海探索获取。|From stage 1, skill books can replace fragments for skill upgrades. Earn them through growth goals, stories, monthly results and expeditions.
前往员工培养|Go to Staff Training
碎片 · 持有%d个|Fragments · %d Owned
重复招聘该伙伴或山海探索获取；用于技能升级和阶段4觉醒。|Earned from duplicate recruitment and expeditions. Used for skill upgrades and awakening at stage 4.
故事契约 · 持有%d份|Story Contracts · %d Owned
完成成长与收集目标获取；在招聘页使用，指定伙伴直接加入，重复伙伴转成培养碎片。|Earn contracts from growth and collection goals. Use one in Recruitment to invite its named companion; duplicates become training fragments.
前往招聘|Go to Recruitment
食材目录|Ingredient Catalogue
普通食材与山海供应商材料可采购；稀有食材通过阶段3山海探索获取。制作时按配方领料。|Buy ordinary ingredients and Shanhai supplier goods. Rare ingredients come from expeditions at stage 3. Each dish uses the quantities in its recipe.
%s · 库存%.2f份 · %s|%s · %.2f portions in stock · %s
前往库存供应|Go to Stock & Suppliers
饰|Decor
已摆放%d件 · %s|%d placed · %s
装修面板购买并在地图摆放|Buy in Furnish, then place on the map
阶段%d解锁|Unlocks at Stage %d
前往装修|Go to Furnish
事件档案 · %d则。事件会依据阶段、当班伙伴和经营状态触发；效果以选项说明和实际结算为准。|Event Archive · %d entries. Events depend on your stage, on-duty companions and business conditions. Choices show their effects; results are recorded when resolved.
· 已遇见|· Encountered
阶段至少|Minimum stage
触发线索：|How to encounter:
神兽羁绊 · %d组。相关伙伴需要同时在岗，训练、研发、休息与探索时不提供羁绊；阶段2开放组合加成。|Companion Bonds · %d combinations. Both companions must be on duty; training, research, rest and expeditions suspend their bond effects. Bonuses open at stage 2.
· 已激活|· Active
· 未激活|· Inactive
尚未拥有：|Not yet recruited:
前往安排伙伴|Manage Companions
开局教学需要完成当前操作；完成后点击确认进入下一步。|Complete the current opening task, then confirm to continue.
白泽 · 阶段%d / %s|Baize · Stage %d / %s
白泽引导  %d / %d · 必修|Baize's Guide  %d / %d · Required
前往 ·|Go ·
来客往事|Travellers' Stories
现场来客|Guests at the Inn
特殊顾客图鉴|Special Guest Album
财务账本|Financial Ledger
音频服务尚未初始化。|The audio service has not finished loading.
音频素材：导入与试听|Audio Assets: Import & Preview
已就绪 ·|Ready ·
待导入 ·|Awaiting Import ·
已就绪 %d / %d|Ready %d / %d
此声音尚未导入，或文件无法读取。|This sound has not been imported, or its file cannot be read.
外置目录：|External folder:
内置目录：|Built-in folder:
事件映射：config/audio.json；文件清单与规格：docs/audio-pipeline.md|Event mapping: config/audio.json; asset list and specifications: docs/audio-pipeline.md
音频文件|Audio Files
选择音频|Choose Audio
单个音频不能超过64MB|Each audio file must be 64 MB or smaller.
图片不能超过32MB|Each image must be 32 MB or smaller.
文件无法读取或超过64MB。|The file cannot be read or exceeds 64 MB.
已导入：|Imported:
导入失败：|Import failed:
未知错误|Unknown Error
营业收入|Service Revenue
小费|Tips
债务利息|Original Debt Interest
债务还本|Original Debt Principal Repaid
贷款利息|Loan Interest
贷款本金|Loan Principal Received
贷款还本|Loan Principal Repaid
事件收支|Event Receipts & Payments
研发与培养|Research & Training
经营费用|Operating Expenses
菜品研发|Recipe Research
员工培训|Staff Training
员工关怀|Staff Care
员工招聘|Recruitment
供应商解锁|Supplier Access
装修购置|Furnishing Purchases
长期经营项目|Long-Term Business Projects
经营欠款清偿|Overdue Operating Bills Paid
事件支出|Event Payments
第%d日|Day %d
● 可选 ·|● Optional ·
财务服务正在初始化。|The financial service is loading.
第%d日 · 日结账单|Day %d · Daily Accounts
期初现金￥%.2f → 期末现金￥%.2f|Opening cash ¥%.2f → Closing cash ¥%.2f
第%d日 %02d:%02d · %s|Day %d %02d:%02d · %s
资金变动|Cash Movement
%s￥%.2f · 余额 ￥%.2f|%s¥%.2f · Balance ¥%.2f
现有贷款|Current Loan
剩余本金 ￥%.2f · 第%d日到期|Principal remaining ¥%.2f · Due on day %d
利息欠款￥%.2f · 罚款欠款￥%.2f|Interest outstanding ¥%.2f · Fines outstanding ¥%.2f
偿还贷款 ￥%d|Repay Loan ¥%d
申请贷款 ￥%d · 所需声望%d|Borrow ¥%d · Reputation required: %d
一次性紧急救援贷款|One-Time Emergency Rescue Loan
日息2%，第%d日到期。本金￥%.2f，欠息￥%.2f，罚款￥%.2f。|Daily interest 2%%; due on day %d. Principal ¥%.2f, interest owed ¥%.2f, fines ¥%.2f.
偿还紧急贷款 ￥%.0f|Repay Emergency Loan ¥%.0f
白泽：小馆暂时陷入周转危机。经营已暂停，存档没有删除。你可以申请紧急贷款（每日1%利息）、保留永久收集重开，或读取最近存档。请先选择一条出路。|Baize: the inn has run short of working cash. Service is paused and your save is safe. Choose an emergency loan (1% daily interest), restart while keeping permanent collections, or load your latest save.
连续欠付工资或房租，需要处理资金风险。|Repeated unpaid wages or rent have created a cash crisis.
A · 紧急贷款 ￥%d（每日1%%利息）|A · Emergency Loan ¥%d (1%% Daily Interest)
已有未结清贷款，不能借新还旧；可选择读取存档或重开。|An existing loan is still outstanding. You cannot borrow to repay it; load a save or restart instead.
B · 重开本局（保留图鉴与成就）|B · Restart (Keep Album & Achievements)
C · 读取最近存档|C · Load Latest Save
当前策略：|Current strategy:
暂停采购|Pause Purchasing
缺货%d单 · 好评%d · 差评%d · 满意度 %.1f%%|%d orders lost to shortages · %d positive / %d negative reviews · Satisfaction %.1f%%
到店%d · 完成%d单 · 等待超时%d|%d arrivals · %d meals completed · %d guests left waiting
次日客流系数 %.2f · %s|Tomorrow's arrival multiplier %.2f · %s
口碑受损，及时补货改善服务|Reputation is suffering. Restock and improve service.
· 售罄|· Sold Out
已请求下载资金流水CSV。|Your transaction CSV download has been requested.
无法写入CSV，请检查用户目录权限。|Cannot write the CSV. Check access to the user data folder.
资金流水已导出：|Transactions exported to:
已收集%d/%d · %s|Collected %d/%d · %s
白泽已可招募|Baize Can Now Be Recruited
白泽仍是引导NPC，不占员工位|Baize is still your guide and does not use a staff slot.
关闭 ×|Close ×
确认，继续经营|Confirm & Resume Service
前往员工|Go to Staff
前往员工排班|Go to Staff Shifts
口碑发酵|Word of Mouth
招财日|Prosperity Day
食材大降价|Ingredient Sale
普通招聘|Standard Recruitment
今日菜单|Today's Menu
预计工资|Expected Wages
主店当班|On Duty at Main Inn
普通|Common
稀有 ★|Rare ★
超稀有 ★ ★|Super Rare ★ ★
传说 ★ ★ ★|Legendary ★ ★ ★
返回事件图鉴|Back to Event Archive
返回羁绊图鉴|Back to Companion Bonds
'''

PATTERNS = [
    (r'^(.+)\s+￥([\d.]+)\s*$', '{1} ¥{2}'),
    (r'^(.+) (N|R|SR|SSR)$', '{1} {2}'),
    (r'^培训副职·(.+)$', 'Train Secondary Role · {1}'),
    (r'^(.+)\s*([★](?: [★])*)$', '{1} {2}'),
    (r'^([+-]?[\d.]+)灵石$', '{1} Spirit Gems'),
    (r'^钞票\s*(￥?[\d.]+)$', 'Cash {1}'),
    (r'^灵石\s*(\d+)$', 'Spirit Gems {1}'),
    (r'^声望\s*([+-]?\d+)$', 'Reputation {1}'),
    (r'^好感([+-]?[\d.]+)$', 'Affinity {1}'),
    (r'^创意([\d.]+)$', 'Creativity {1}'),
    (r'^体力(\d+)/心情(\d+)$', 'Stamina {1} / Mood {2}'),
    (r'^客流 ([+-]?[\d.]+)%$', 'Arrivals {1}%'),
    (r'^(.+)分钟$', '{1} minutes'),
    (r'^剩([\d.]+)分钟$', '{1} minutes left'),
    (r'^(.+) · 剩([\d.]+)分钟$', '{1} · {2} minutes left'),
    (r'^解雇 ￥([\d.]+)$', 'Dismiss · ¥{1}'),
    (r'^累计营业额 ￥([\d.]+)$', 'Total Revenue ¥{1}'),
    (r'^余额 ￥([\d.]+)$', 'Balance ¥{1}'),
    (r'^([+−-])￥([\d.]+) · 余额 ￥([\d.]+)$', '{1}¥{2} · Balance ¥{3}'),
    (r'^今日菜单\s+(.+)$', "Today's Menu: {1}"),
    (r'^(.+)  \((\d+) / (\d+)\)$', '{1} ({2} / {3})'),
    (r'^(\d+)年(\d+)月(\d+)日  (\d\d:\d\d) · (.+)$', 'Y{1}/{2}/{3} {4} · {5}'),
    (r'^厨艺 (\d+)  速度 (\d+)  魅力 (\d+)  耐力 (\d+)  口才 (\d+)  创意 (\d+)  算力 (\d+)$', 'Cooking {1}  Speed {2}  Charm {3}  Endurance {4}  Eloquence {5}  Creativity {6}  Calculation {7}'),
    (r'^重放阶段(\d+) · (.+)$', 'Replay Stage {1} · {2}'),
]

PAIRS += r'''
· 好感%d|· Affinity %d
赠茶 · ￥20|Offer Tea · ¥20
好感%d · %s|Affinity %d · %s
保存结局并领取奖励|Save Ending & Claim Reward
已保存结局：|Saved ending:
山海志 · 老饕的口味笔记|Shanhai Notes · The Gourmet's Tasting Book
老饕说，真正的山海盛宴藏在伙伴的故事里。整理白泽图残页、完成凤凰支线，并留意高品质研发与稀有食材，也许能发现菜单外的菜肴。|The old gourmet says a true Shanhai feast lies hidden in your companions' stories. Gather Baize's scattered pages, follow Fenghuang's story, and watch for exceptional recipes and rare ingredients. There may be dishes beyond the menu.
山海志 · 故人一盏茶|Shanhai Notes · Tea with an Old Friend
故人捧起茶杯，说起白泽曾在山路上为迷途旅人辨认方向。白泽把沿途异兽的习性记入图册，也记下人们互相照应的小事。故人笑道，今天这些见闻又在小馆的餐桌边续上了。|Holding a cup of tea, the old friend remembers how Baize guided lost travellers along mountain paths. His book recorded the creatures he met and the small ways people cared for one another. The friend smiles: those stories are finding new chapters around the inn's tables.
新 ·|New ·
标记已阅读|Mark as Read
组合|Combination
相克警示：|Conflict warning:
服务|Serving
疲劳|Tired
低落|Low Spirits
通路受阻|Path Blocked
食客：|Guest:
训|Train
建|Build
疲|Tired
休|Rest
班|Duty
立绘待补充|Portrait Pending
· 点击查看立绘|· Click to View Portrait
灶台 %d/%d · 收银 %d/%d|Stoves %d/%d · Checkouts %d/%d
施工中|Under Construction
基础|Basic
可放|Valid
不可放|Blocked
有 间 小 馆|L I T T L E  I N N
客人正在路上…|Guests are on their way…
稍歇片刻，准备下一场营业|A short rest before the next service
出餐台|Serving Counter
山海壁画|Shanhai Mural
暖灯|Warm Lamp
扩建灶台|Extra Stove
放|Place
点击放置|Click to Place
这里不能放置|Cannot Place Here
制作|Cooking
餐|Meal
人类食客|Human Guest
山海异兽|Shanhai Creature
神秘来客|Mysterious Traveller
%s · %s|%s · %s
预计消费 ￥%d · 当前品质 %d|Expected bill ¥%d · Current quality %d
等待点单|Waiting to Order
立绘 ·|Portrait ·
引导立绘 ·|Guide Portrait ·
小人 · %s · %s · %s|Actor · %s · %s · %s
菜品图标 ·|Dish Icon ·
俯视设施 ·|Overhead Facility ·
木地板|Wooden Floor
店墙|Inn Wall
店招|Inn Sign
绿植|Plant
员工面板|Staff Panel
照片框|Picture Frame
状态警示|Status Warning
顾客 · %s · %s · %s|Guest · %s · %s · %s
特殊来客立绘 ·|Special Guest Portrait ·
特殊来客 · %s · %s · %s|Special Guest · %s · %s · %s
顶栏资源图标 ·|Top-Bar Resource Icon ·
状态图标 ·|Status Icon ·
道具 ·|Item ·
可招聘新伙伴|New Recruitment Available
货币充足；完成招聘或选择暂不招募。|You have enough currency. Recruit a companion or choose Later.
契约可招募|Contract Recruitment Available
使用已有员工契约。|Use a staff contract you already own.
需要照顾|Needs Care
安排休息或沟通；状态恢复后提醒才消失。|Arrange rest or a conversation. This reminder clears when their condition improves.
可训练|Training Available
训练会消耗资金并暂停工作，可手动忽略。|Training costs cash and takes staff away from service. You may dismiss this reminder.
可研发|Research Available
菜品研发中|Recipe Research Underway
等待研发完成；打开面板不会清除此提醒。|Wait for research to finish. Opening the panel does not clear this reminder.
员工训练中|Staff Training Underway
训练完成后处理本次提醒，也可暂时忽略。|Return when training is complete, or dismiss this reminder for now.
可购置|Available to Buy
可排班激活|Available through Shifts
让组合伙伴同班工作。|Put the companions on the same shift.
经营升级条件已达成|Restaurant Upgrade Available
完成升级后逐项学习新功能。|Confirm the upgrade, then explore each new feature.
奖励可领取：|Reward available:
事件待决定：|Decision needed:
欠款需要处理|Overdue Bills Need Attention
补缴欠薪、欠租和利息；打开账单不会清除提醒。|Pay overdue wages, rent and interest. Opening the bill does not clear this reminder.
经营危机：选择救援出路|Business Crisis: Choose a Rescue
现金周转风险|Cash Flow Risk
新员工已收集|New Companion Collected
新菜品已收集|New Dish Collected
阶段经营目标已完成|Stage Business Goal Complete
钞票￥%.2f|Cash ¥%.2f
灵石%d|Spirit Gems %d
技能书%d本|Skill Books %d
隐藏配方：白泽万象宴|Hidden Recipe: Baize's Myriad Wonders Banquet
剧情对白与纪念|Story Dialogues & Keepsakes
收起序章|Hide Prologue
已结识%d / 30种神兽 · 主线收集目标为12种，全30种另有成就。|Met %d / 30 companions · The main story requires 12; meeting all 30 earns another achievement.
主线已完成，仍可继续经营、培养员工与收集图鉴。|The main story is complete. You can keep running the inn, training staff and filling your album.
往局成就记录：|Achievements from earlier campaigns:
。本局的资源与剧情条件独立计算。|. Resources and story requirements are counted separately for this campaign.
经营日历 · 第%d天|Business Calendar · Day %d
今日正常经营。下一次节日会在日界时提醒。|An ordinary service day. You will be notified of the next festival when its day begins.
活动支出￥%.2f · 声望+%d · 员工心情+%d；每日限一次。|Event cost ¥%.2f · Reputation +%d · Staff mood +%d; once per day.
今日活动已完成|Today's Activity Complete
最近一周：营业额￥%.2f · 接待%d位。|Last week: revenue ¥%.2f · %d guests served.
月度真实营业额达到￥%.2f，可领取%d本技能书。旧存档从接入本系统之日起累计，不追补历史月份。|Earn ¥%.2f in actual monthly revenue to claim %d skill books. Older saves count from the introduction of this system; earlier months are not backfilled.
第%d月：营业额￥%.2f · 接待%d位%s|Month %d: revenue ¥%.2f · %d guests served%s
· 已领取|· Claimed
领取第%d月经营技能书|Claim Month %d Skill Books
条件达成，等待前篇|Requirements Met; Complete the Previous Chapter
奖励：|Reward:
收起对白|Hide Dialogue
重看这一段对白|Read Dialogue Again
物品栏 ▴|Inventory ▴
物品栏 ▾|Inventory ▾
状态|Status
钞票 ￥%.2f|Cash ¥%.2f
%.2f万|%.2f ×10,000
灵石 %d|Spirit Gems %d
声望 %d|Reputation %d
债%.1f万|Debt %.1f ×10,000
债￥%.0f|Debt ¥%.0f
全部本金负债￥%.2f，点击账单查看利息及到期日|Total principal owed ¥%.2f. Open Bills for interest and due dates.
· 顾客%d / 等待%d · 食材%.1f / 新鲜%d%% · 预计工资￥%.0f|· Guests %d / Waiting %d · Ingredients %.1f / Freshness %d%% · Expected wages ¥%.0f
⚠ %d位员工状态偏低 ·|⚠ %d staff need care ·
现金流告急 ·|Cash Warning ·
可升级 ·|Upgrade Available ·
研发%d分|Research %d min
培训%d分|Training %d min
施工%d分|Building %d min
清洁剩%d分 ·|Cleaning: %d min left ·
等%d|Waiting %d
剩%d分钟|%d min left
训0|Train 0
建0|Build 0
灵石 ×%d|Spirit Gems ×%d
技能书 ×%d|Skill Books ×%d
招聘券 ×%d|Recruitment Tickets ×%d
碎片 ×%d|Fragments ×%d
契约|Contract
查看或使用：|View or use:
。资源已经记入余额，不可重复领取。|. These resources are already in your balance and cannot be claimed again.
散财童子自动吸附中 · 剩%d游戏分钟，收益仍记入拾取收入。|Wealth Child auto-collection active · %d game minutes left. Receipts are still recorded as pickup income.
%s · 使用%d / 共%d个|%s · %d in use / %d total
后厨使用 %d/%d 次 · 清洁用品￥%.0f / %d游戏分钟|Kitchen use %d/%d · Cleaning supplies ¥%.0f / %d game minutes
正在清洁：|Cleaning:
全收集成就：已保留旧版26员工成就；新版图鉴目标为30位。|The earlier 26-companion achievement is retained. The current album goal is 30.
全收集成就：已保留旧版28员工成就；新版图鉴目标为30位。|The earlier 28-companion achievement is retained. The current album goal is 30.
经营收入  ￥%.2f|Service Receipts  ¥%.2f
菜品￥%.2f · 小费￥%.2f · 手动拾取￥%.2f|Meals ¥%.2f · Tips ¥%.2f · Manual pickups ¥%.2f
收入合计￥%.2f · 支出合计￥%.2f · 净现金流￥%.2f|Total cash in ¥%.2f · Total cash out ¥%.2f · Net cash flow ¥%.2f
净利润￥%.2f · 现金核对：%s|Net profit ¥%.2f · Cash reconciliation: %s
需检查|Needs Review
事件待处理|Event Pending
培训×0|Training ×0
装修×0|Building ×0
来客×0|Guests ×0
旋转手机后继续经营|Rotate Your Phone to Continue
横屏可同时查看餐厅与操作按钮|Landscape view fits the restaurant and controls together
采购 %d 份普通食材，花费 ￥%d|Buy %d portions of ordinary ingredients for ¥%d
花费 ￥%d 发传单，持续 %d 游戏分钟|Spend ¥%d on flyers for %d game minutes
查看目标|View Goals
· 宣传中|· Promotion Active
%d / %d 座 · 舒适度 %d|%d / %d seats · Comfort %d
累计接待 %d 位  ·  流失 %d 位|%d guests served  ·  %d lost
食材 %.1f 份  /  新鲜度 %d%%|Ingredients %.1f portions  /  Freshness %d%%
待还本金 ￥%.2f|Principal Outstanding ¥%.2f
训练中|Training
%s · %s · 体力 %d|%s · %s · Stamina %d
候补/休息 %d 位 · 在员工面板排班|%d reserve/resting · Set shifts in Staff
%s / 阶段 %d|%s / Stage %d
绿格可放置 · 点击确认 · 右键/Esc取消|Green tiles are valid · Click to place · Right-click/Esc to cancel
食材不足：|Ingredient shortage:
查看经营目标|View Business Goals
待办：|Tasks:
；点击直达，右侧箭头展开全部待办。|; click to open, or use the arrow to view all tasks.
完成布置|Finish Furnishing
开张篇 · 1秒=%d分钟|Opening Chapter · 1 second = %d game minutes
奖励|Reward
完成开张篇|Finish Opening Chapter
三界食肆，继续经营|A Three-Realm Inn · Keep Serving
还清债务，提升口碑|Repay Debt and Build Your Reputation
下阶段：累计营业额%.0f，声望%d；在更多→经营目标中确认。|Next stage: total revenue %.0f and reputation %d. Confirm in More → Business Goals.
招牌菜与神兽组合，让小馆更热闹|Signature dishes and companion pairings bring the inn to life
查看成长目标|View Growth Goals
本局已经结束，请重新开局或返回主菜单。|This campaign has ended. Start again or return to the main menu.
请先完成当前页面的确认操作。|Confirm the current page before continuing.
请先处理经营救援。|Choose a business rescue first.
请先完成白泽当前教学，阶段功能可选择稍后引导。|Finish Baize's current task first. Guidance for later-stage features can wait.
%s尚未解锁。需要阶段%d：累计营业额￥%.0f（当前￥%.0f），声望%d（当前%d）。请先在经营升级页达成并确认升级。|%s requires stage %d: total revenue ¥%.0f (now ¥%.0f), reputation %d (now %d). Meet and confirm these requirements in Grow the Restaurant.
招聘结果|Recruitment Result
亲自接待这位来客后，可以阅读来客小传。|Welcome this traveller to the inn to unlock their story.
'''

PAIRS += r'''
此条文化资料暂不可用。|This cultural reading is currently unavailable.
来源链接格式无效。|The source link is invalid.
未能打开浏览器，可复制资料中的网址。|The browser could not be opened. Copy the address from the reading instead.
当班 %d/%d · 已拥有 %d 位。休息、训练和研发期间无法接单；候补仍领取工资。|On duty %d/%d · %d recruited. Resting, training and research staff cannot take orders. Reserve staff still receive wages.
普通：每10次SR+、50次SSR；高级：每10次SR+、30次SSR。重复员工转为5碎片。|Standard: SR+ every 10 draws, SSR every 50. Premium: SR+ every 10, SSR every 30. Duplicate recruits become 5 fragments.
组合排班：毕方掌厨 · 九尾狐传菜|Pairing: Bifang cooks · Nine-Tailed Fox serves
已激活羁绊：|Active bonds:
训练厨艺 +1|Train Cooking +1
训练速度 +1|Train Speed +1
神通已实现：|Available mythic skill:
图鉴资料：|Album notes:
训练中（剩余 %d 分钟）|Training (%d minutes left)
当班中|On Duty
体力 %d  /  心情 %d  /  忠诚 %d|Stamina %d  /  Mood %d  /  Loyalty %d
厨艺 %d  /  速度 %d  ·  %s|Cooking %d  /  Speed %d  ·  %s
23道菜 · 28位神兽。本章实现7位员工神通、2组羁绊，其余为后续内容资料。|23 dishes · 28 companions. This legacy chapter includes 7 staff skills and 2 bonds; other entries preview later content.
可在研发面板查看条件|View Requirements in Research
后续内容|Later Content
成本 ￥ %d   /   %s|Cost ¥%d   /   %s
· 神通可生效|· Mythic Skill Available
· 神通待开放|· Mythic Skill Locked
浏览器会在后台将存档和导入图片写入站点存储，保存后请稍候再刷新或关闭页面。|The browser writes saves and imported images to site storage in the background. Wait briefly after saving before refreshing or closing the page.
进度已保存；浏览器后台写入中，请稍候再关闭页面。|Progress saved. Browser storage is syncing; wait briefly before closing the page.
进度已保存，包括未完成订单。|Progress saved, including unfinished orders.
进度已恢复，点击继续即可营业。|Progress restored. Click Continue to resume service.
读取旧版基础框架进度|Load Legacy Framework Save
上次日结|Last Daily Settlement
房租水电|Rent & Utilities
导入开张篇 Demo 存档|Import Opening Demo Save
重新开始将重置当前未保存的进度。已有存档仍可读取。|Restarting resets unsaved progress. Existing saves can still be loaded.
确认重新开始|Confirm Restart
新的小馆开张了。|A new little inn has opened.
采购 %d 份食材 · ￥ %.0f|Buy %d Portions of Ingredients · ¥%.0f
还清剩余债务|Repay Remaining Debt
快进到下一营业时段|Advance to Next Service Period
快进到次日 06:00|Advance to Tomorrow at 06:00
快进会逐分钟处理订单、员工状态与财务，正常扣除每日费用。|Fast-forward processes orders, staff condition and accounts minute by minute. Daily expenses still apply.
标准节奏按原始升级条件经营，不发放开张篇任务奖励。|Standard pacing uses the original growth requirements without opening-chapter task rewards.
已完成的目标需要领取奖励，才会开放下一个目标。|Claim the completed goal's reward to open the next goal.
等待达成|In Progress
完成前置目标后开放|Complete the Previous Goal First
街角饭店：累计营业额 ￥%.0f/%.0f · 声望 %d/%d · 债务 ￥%.0f|Corner Restaurant: revenue ¥%.0f/%.0f · Reputation %d/%d · Debt ¥%.0f
升级为街角饭店|Upgrade to Corner Restaurant
%s灵石|%s Spirit Gems
新伙伴|New Companion
熟悉的伙伴再次应聘，已转为 %d 个碎片。可在【员工培养】中升级技能。|A familiar companion applied again, granting %d fragments. Use them to upgrade skills in Staff Training.
新伙伴已经加入小馆。|Your new companion has joined the inn.
当前排班已满，先安排一位员工休息，再让它上班。|The shift is full. Let another staff member rest before assigning this companion.
它会自动参与当班工作。|They will join the current shift automatically.
安排伙伴工作|Assign Companion
回到小馆|Return to the Inn
毕方掌厨，九尾狐传菜。火焰魅惑使客单价提升15%。|Bifang cooks while Nine-Tailed Fox serves. Their Flame and Charm bond raises spending per guest by 15%.
研发消耗 ￥%d 与 %d 份食材，耗时 %d 游戏分钟。主持厨师暂时停止做菜；关闭面板后时间继续。|Research uses ¥%d and %d portions of ingredients, taking %d game minutes. The lead cook pauses service; close the panel to let time continue.
配方尚未研发|Recipe Not Researched
配方已解锁，可在菜单中上架|Recipe Unlocked · Add It to the Menu
研发中 · 剩余 %d 分钟|Researching · %d minutes left
上架菜品决定顾客点单。菜单至少保留一道菜；招牌菜更贵，也需要更长制作时间。|Guests order from enabled dishes. Keep at least one dish on the menu. Signature dishes cost more and take longer to cook.
当前可调整已有家具；升级到阶段1后可购买正式装修。|Move existing furniture now. New furnishing purchases open at stage 1.
工期%d分钟|Construction: %d minutes
座位|Seats
舒适度|Comfort
客流量|Arrivals
客单价|Spending per Guest
烹饪速度|Cooking Speed
结账速度|Checkout Speed
逃单风险降低|Reduced Walkout Risk
正式装修在阶段1开放；现在可移动已有家具。|New furnishing opens at stage 1. You can move existing furniture now.
请选择1名装修负责人|Choose One Construction Lead
点击绿色格子预览购买；完成装修后保留，撤销可收回本次操作。|Click a green tile to preview the purchase. Finish furnishing to keep it, or Undo to reverse this step.
移动到绿色格子，点击确认。右键或Esc取消。|Move to a green tile and click to confirm. Right-click or Esc cancels.
位置不可施工，请检查设备占位、操作站位和通路。|Construction is blocked here. Check equipment space, working positions and paths.
此处无法放置：请避开使用中的餐桌、家具、员工和通路。|Cannot place here. Leave room for occupied tables, furniture, staff and paths.
%s · ￥%.0f · 工期%d游戏分钟|%s · ¥%.0f · Construction: %d game minutes
确认负责人后预订，完成布置后开工。|Choose the lead to reserve it; construction starts when furnishing is finished.
请选择一位当班空闲员工|Choose an Idle On-Duty Staff Member
确认负责人|Confirm Lead
返回预览|Back to Preview
请选择1名装修负责人；本次尚未扣费。|Choose one construction lead. No payment has been taken.
仅空闲家具可移动，点击绿色格子确认。|Only unused furniture can be moved. Click a green tile to confirm.
还没有可以撤销的步骤。|There are no steps to undo.
装修已开工，完工后生效；0:00–6:00暂停施工。|Construction has begun and takes effect when finished. Work pauses from 00:00 to 06:00.
装修尚未完成|Furnishing Unfinished
完成并退出|Finish & Exit
继续布置|Continue Furnishing
放弃本次调整|Discard These Changes
暂时没有待处理事件。事件会在营业中出现，部分需要对应神兽当班。|No events are pending. Events appear during service; some require a particular companion on duty.
查看商业封锁与对抗进度|View Trade Blockade Progress
确认后生效：|Applied on confirmation:
可以先关闭面板，稍后通过顶部待办处理。|You can close this panel and return through the task bar later.
白泽：三界食肆的香气，终于传到了厨神大赛！|Baize: the scent of our inn has finally reached the grand cooking contest!
厨神大赛最高 %.1f 分 · 已获胜 %d 次|Best Contest Score %.1f · %d Wins
从有间小馆到三界餐饮集团，累计营业额￥%.2f，收集%d位员工、研发%d道菜。|From a little inn to the Three-Realm Restaurant Group: ¥%.2f in revenue, %d companions and %d researched dishes.
可以继续经营、收集神兽和挑战大赛；排行榜中的其他食肆为本地模拟对手。|Keep serving, meeting companions and entering contests. Other inns in the league are locally simulated rivals.
继续经营三界食肆|Continue Running the Inn
重放阶段%d · %s|Replay Stage %d · %s
关闭开发者模式|Disable Developer Mode
开启开发者模式|Enable Developer Mode
美术资源：导入与重载|Art Assets: Import & Reload
音频资源：导入与试听|Audio Assets: Import & Preview
重新显示新手教程|Show Opening Tutorial Again
开发者模式会按文件变化刷新图片。数值面板改动作用于本次存档，重载配置可恢复默认。|Developer mode refreshes images when files change. Balance edits apply to this save; reload the configuration to restore defaults.
请先在开发者选项中开启开发者模式。|Enable Developer Mode in Developer Options first.
更改影响后续计算；已发生的收入、支出与订单不追溯重算。|Changes affect future calculations. Earlier receipts, payments and orders are not recalculated.
输入参数名过滤，例如 hire 或 stage|Filter by parameter name, e.g. hire or stage
应用数值|Apply Values
已应用|Applied
数值不符合规则，当前参数已保留|Invalid values. Current parameters were kept.
重载配置并清除本局覆盖|Reload Configuration & Clear Campaign Overrides
当前配置开局测算：两名N级厨师/服务员日工资￥%.2f；保护期免租金水电，含利息和减半还本的现金支出￥%.2f/天；保护期后现金支出￥%.2f/天。还本不计利润费用。|Opening estimate: daily wages for an N-tier cook and server ¥%.2f. With rent and utilities waived, protected-period cash outflow including interest and half principal repayment is ¥%.2f/day; afterward, ¥%.2f/day. Principal repayment is not an expense in profit.
按日营业额400–500元、食材约30%%估算：保护期日现金结余￥%.2f至￥%.2f；保护期后￥%.2f至￥%.2f。此为调参诊断，实际经营受客流、缺货与效率影响。|Assuming daily revenue of ¥400–500 and ingredients at about 30%%: protected-period daily cash surplus ¥%.2f–¥%.2f; afterward ¥%.2f–¥%.2f. This is a balance diagnostic. Actual results depend on arrivals, shortages and efficiency.
售价与成本检查：|Price and cost check:
所有当前菜品售价均高于配方成本。|All current menu prices exceed their recipe costs.
以下菜品售价不高于成本：|These dishes are priced at or below cost:
替换美术|Replace Art
自定义目录：|Custom folder:
六类资源：Portraits立绘、Sprites四方向动作、UI界面、Map箱庭、Items菜品道具、FX图标。旧四类目录仍兼容，接入说明随构建附带。|Six asset groups: Portraits, four-direction Sprites, UI, Map, Items and FX. Legacy folders remain compatible. Integration instructions are included with the build.
目标相对路径，例如 Sprites/xian_yang/idle_down_0.png|Target relative path, e.g. Sprites/xian_yang/idle_down_0.png
选择资源类别与角色/动作/方向后导入；立绘、场景和文化专图相互独立。也可手填约定路径。|Choose an asset group, character, action and direction to import. Portraits, scene art and reading illustrations are independent. You may also enter a documented path.
手动填写目标路径|Enter Target Path Manually
来客 ·|Guest ·
· 简介|· Reading
· 场景|· Scene
钞票拾取图标|Cash Pickup Icon
灵石拾取图标|Spirit Gem Pickup Icon
箱庭 ·|Dollhouse ·
选择PNG/JPG图片并导入|Choose & Import PNG/JPG
立即重新扫描素材目录|Rescan Asset Folders Now
美术资源已重载|Art assets reloaded
自定义图片优先，缺图时使用内置素材或占位图。桌面版可直接把图片放入程序旁CustomAssets；网页版使用此处选择文件，文件保存于浏览器本地存储。|Custom art takes priority, with built-in art or placeholders as fallbacks. On desktop, put files in CustomAssets beside the program. On the web, choose files here; they are kept in browser storage.
加载提示：|Loading notes:
PNG/JPG 图片|PNG/JPG Images
选择图片|Choose Image
图片已导入：|Image imported:
图片格式或路径无效|Invalid Image Format or Path
完整经营模式开放财务账本。|The financial ledger is available in the full campaign.
资产 ￥%.2f · 负债 ￥%.2f · 净资产 ￥%.2f|Assets ¥%.2f · Liabilities ¥%.2f · Net assets ¥%.2f
现金 ￥%.2f · 原料存货 ￥%.2f · 在制/成品 ￥%.2f · 应收款 ￥%.2f|Cash ¥%.2f · Raw inventory ¥%.2f · Work in progress / prepared stock ¥%.2f · Receivables ¥%.2f
累计收入 ￥%.2f · 已结转成本 ￥%.2f · 费用 ￥%.2f · 简化利润 ￥%.2f|Total income ¥%.2f · Cost recognised ¥%.2f · Expenses ¥%.2f · Simplified profit ¥%.2f
教学简化：采购先计存货，实际耗用再结转成本；还本减少现金和负债，利息计费用。资本投入暂不折旧，事件奖励单列；退款、赠送与测试调参可能需要人工复核。|Simplified teaching accounts: purchases enter inventory and become costs when used. Principal repayments reduce cash and liabilities; interest is an expense. Capital purchases are not depreciated here, and event rewards are separate. Refunds, gifts and balance tests may need manual review.
待清偿：欠息￥%.2f · 欠薪￥%.2f · 欠租￥%.2f|Outstanding: interest ¥%.2f · Wages ¥%.2f · Rent ¥%.2f
已清偿￥%.2f，余欠￥%.2f|Paid ¥%.2f; ¥%.2f remains
当前无法清偿|Cannot Pay Now
依次清偿欠息、欠薪和欠租；不重复计入费用。|Pays interest, wages and rent arrears in that order. Expenses are not counted twice.
第%d日已结算：打开更多→账单查看每笔收支与现金核对。|Day %d settled. Open More → Bills for itemised receipts, payments and cash reconciliation.
操作条件不足|Requirements Not Met
恢复全天排班|Restore All-Day Shifts
特殊顾客到访：点击定位|Special Guest Visiting · Click to Locate
· 声望达标|· Reputation Requirement Met
现金流告急|Cash Warning
请选择一位在职员工。|Choose a currently employed companion.
等级%d/%d · 体力%d · 心情%d · 忠诚%d · 日工资￥%.2f|Level %d/%d · Stamina %d · Mood %d · Loyalty %d · Daily wages ¥%.2f
恢复当班|Return to Duty
培训、研发或装修期间不可重新排班|Shifts cannot be changed during training, research or construction.
主职业：|Primary role:
· 副职业：|· Secondary role:
尚未培训|Not Trained
设为主职业：|Set Primary Role:
主副职业共同决定可操作设备；培训新职业请点培训。|Primary and secondary roles determine usable equipment. Click Training to learn another role.
在下列营业时段安排此员工：|Assign this companion to these service periods:
保存排班|Save Shifts
相生相克与岗位冲突请查看排班关系。|Check shift relationships for bonds and role conflicts.
查看相生相克|View Working Relationships
确认解雇|Confirm Dismissal
等级%d×50 + 训练属性点%d×10 + 忠诚%.0f×5 + 遣散费100|Level %d ×50 + trained attribute points %d ×10 + loyalty %.0f ×5 + severance 100
合计支付￥%.2f。员工离场，图鉴和支线记录保留。|Total payment ¥%.2f. The companion leaves; album and story records remain.
以上为本游戏规则。|These are the rules used in this game.
%s · %s · %d/%d分钟%s|%s · %s · %d/%d minutes%s
（待确认开工）|(Awaiting Construction Confirmation)
原债利息|Original Debt Interest
最低还本|Minimum Principal Repayment
常规贷款利息|Regular Loan Interest
原债本金￥%.2f · 工资/房租欠款￥%.2f · 紧急贷款本金￥%.2f|Original principal ¥%.2f · Wages/rent owed ¥%.2f · Emergency loan principal ¥%.2f
第%d日 · 今日收支结算|Day %d · Daily Settlement
白泽：现金连续下降，已不足预计固定支出￥%.2f。|Baize: cash has kept falling and is now below the expected fixed costs of ¥%.2f.
请优先备齐基础食材、安排厨师和服务员，暂缓装修与高成本培养。紧急救援本局仅一次，5000元、日息2%、20日到期；再次破产将结束经营。|Prioritise basic ingredients, cooks and servers; postpone furnishing and expensive training. Emergency rescue is available once per campaign: ¥5,000 at 2% daily interest, due in 20 days. Another bankruptcy ends the campaign.
知道了，调整经营|Understood · Adjust the Business
最后一次自救：紧急贷款5000元，日息2%，20游戏日到期；逾期声望−50并罚款400元。本局仅可使用1次，救援失败或再次破产将强制结束。常规贷款禁贷不影响此次救援。|Last chance: an emergency loan of ¥5,000 at 2% daily interest, due in 20 game days. Overdue payment costs 50 reputation and a ¥400 fine. Available once per campaign; failed rescue or another bankruptcy ends play. Regular borrowing restrictions do not block this rescue.
接受紧急救援（先确认代价）|Accept Rescue (Review the Cost First)
紧急救援代价确认|Confirm Rescue Terms
此救援贷款利率2%/天，20日到期，逾期声望−50、罚款400元。|This rescue loan charges 2% daily interest, due in 20 days. Late payment costs 50 reputation and a ¥400 fine.
本局仅此一次；若再次破产，将直接结束游戏。|This is your only rescue this campaign. Another bankruptcy ends the game.
放弃救援，结束经营|Decline Rescue & End Campaign
经营失败 ·|Campaign End ·
累计营业额￥%.2f · 最高声望%d · 已收集员工%d位 · 经营%d天|Total revenue ¥%.2f · Peak reputation %d · %d companions collected · %d days in business
重开保留永久图鉴、成就、特殊顾客见闻、山海志与白泽支线，重置本局资金、研发和雇佣。|Restarting keeps permanent albums, achievements, special guest memories, Shanhai notes and Baize's story. Campaign funds, research and employment reset.
重新开局|Restart Campaign
返回主菜单|Return to Main Menu
已执行：|Applied:
确认结果|Confirm Result
已遇见%d/6 · %s|Met %d/6 · %s
山海来客全收集成就已解锁（无数值奖励）|All Shanhai Guests achievement unlocked (no numerical reward)
亲自接待后揭示身份与反馈|Welcome Them to Reveal Their Identity & Feedback
回看全部接待与互动记录|Review All Visits & Interactions
· 新|· New
尚未遇见的特殊顾客|Special Guest Not Yet Met
剪影 · 图片待补充|Silhouette · Artwork Pending
来客小传 / Story|Traveller's Story
图像待补充|Artwork Pending
出现条件：|Visit requirements:
到店行为：|Behaviour at the inn:
遇见%d次 · 最佳结果：%s|Met %d times · Best result: %s
前局接待 ·|Earlier Campaign ·
第%d天 ·|Day %d ·
收养幼崽 · 领取神兽线索碎片×1|Adopt the Young Creature · Claim 1 Creature Clue Fragment
当前没有特殊顾客到访。|No special guests are visiting now.
位置：第%d号座位 · 正在%s|Location: seat %d · %s
定位这位顾客|Locate Guest
查看特殊顾客图鉴|View Special Guest Album
这位顾客已经离店，可以在图鉴回看结果。|This guest has left. Review the result in the album.
▼ 特殊顾客|▼ Special Guest
接待记录|Visit Records
保留最近120次特殊接待结果与40次实际互动；图鉴永久保留遇见次数和最佳结果。|Keeps the latest 120 special visits and 40 actual interactions. The album permanently retains visit counts and best results.
店员与顾客的互动|Staff & Guest Interactions
顾客%d · %s / %s|Guest %d · %s / %s
典籍里的原貌|A Closer Reading of the Old Texts
请先选择要移动的家具|Select the furniture to move first.
此处已被其他家具占用，请另选空位|Other furniture occupies this space. Choose an empty spot.
超出店内可用范围，请放在店内区域|Outside the usable area. Place it inside the inn.
有客人正在使用这件家具，请等其离座后再移动|A guest is using this furniture. Wait until they leave the seat.
落点过近或挡住通路，请拉开桌椅间距，并留出员工和顾客的走道|Too close or blocking a path. Space out tables and chairs, leaving walkways for staff and guests.
该设施正在施工中，施工完成后才能移动|This facility is under construction. Move it after work finishes.
该设备正在使用中（有员工/顾客正在操作），请稍后再试|Staff or guests are using this equipment. Try again later.
灵|Gem
点击手动拾取，剩%.1f真实秒|Click to Collect · %.1f Real Seconds Left
相克|Conflict
整理|Compile
的档案页|'s Archive Page
'''
PATTERNS += [
    (r'^整理(.+)的档案页$', "Compile {1}'s Archive Page"),
    (r'^确认解雇 (.+)$', 'Confirm Dismissal: {1}'),
    (r'^(.+) · (.+) · 体力(\d+) 心情(\d+)$', '{1} · {2} · Stamina {3} Mood {4}'),
    (r'^训(\d+)$', 'Train {1}'), (r'^建(\d+)$', 'Build {1}'),
]

PAIRS += r'''
散财童子告辞了，掉落物恢复手动拾取。|The Wealth Child has left. Pickups must be collected manually again.
本订单其余收款/应收|Remaining Receipts / Receivable for This Order
本订单实际耗用成本|Actual Ingredient Cost for This Order
上次的%s，我还记得。|I still remember last time's %s.
第%d日归来，已入库：%s。|Returned on day %d; stored: %s.
退还未履行预收款|Refund of Unfulfilled Prepayment
预约退款后现金不足|Insufficient Cash after Booking Refund
预收款结转与退回余款（营业收入由原订单记录）|Prepayment Applied and Remainder Refunded (Revenue Recorded by the Original Order)
请先开设分店，并完成对应驿路主题（或选择常规菜单）。|Open a branch and complete the matching road theme first, or choose the regular menu.
请选择有效出餐方案。|Choose a valid service plan.
同席协调需要九婴当班和3个已安装炉灶。|Coordinated table service requires Jiuying on duty and 3 installed stoves.
已有夜席正在进行。|A night meal is already underway.
先研发并上架烛龙拉面。|Research Zhulong noodles and add them to the menu first.
需要烛龙当班、正在营业且今日未使用神通。|Zhulong must be on duty during service, with today's skill unused.
已开始烹饪的订单需完成服务；未开始的预约可退款。|Orders already cooking must be served. Unstarted bookings can be refunded.
来信不存在。|This letter does not exist.
当前事件不能延期。|This event cannot be postponed now.
这一选择已处理或尚未开放。|This choice has already been resolved or is not open yet.
请选择当前可用的处理方式。|Choose an available response.
需要毕方当班、已研发烤翅和可用炉灶。|You need Bifang on duty, researched wings and an available stove.
烤翅所需食材不足，请先补货。|Not enough ingredients for the wings. Restock first.
培训资金不足。|Not enough cash for training.
请等毕方完成当前任务再开始协作培训。|Wait for Bifang's current task to finish before starting team training.
可赠出的普通食材账面价值不足。|Not enough ordinary ingredients available to give at the required book value.
需先备好已解锁酸梅汤的真实用料。|Unlock the sour plum drink and stock its required ingredients first.
请保留足额现金退回预收款。|Keep enough cash to refund the prepayment.
炉边协作培训|Kitchen Team Training
收到预约预收款，未确认收入|Booking Prepayment Received; Revenue Not Yet Recognised
旧菜牌与预收凭据已留存：无面饺子有面皮，预收20尚未履约。|Old menu and prepayment receipt retained: Faceless Dumplings have wrappers; the 20 prepayment is still unfulfilled.
已确认Lin为个人饮食计划避小麦，非严重过敏；复合用料与交叉接触仍列未知项。|Lin avoids wheat by personal choice, not for a severe allergy. Composite ingredients and cross-contact remain unverified.
买粮入库，现金转存货|Grain Purchased: Cash Converted to Inventory
按账面成本赠出食材|Ingredients Given at Book Cost
约定已记下。|Your agreement has been recorded.
客诉已登记：%s，%s；资源惩罚只按原订单结算一次。|Complaint registered: %s, %s. Resource penalties are applied only once through the original order.
等待当班服务人员|Waiting for On-Duty Service Staff
处理|Handling
有员工上班后继续|Continues When Staff Return to Duty
预计%d分钟|Estimated %d Minutes
%s完成客诉处理，用时%d分钟；处理结果已写入事件日志。|%s resolved the complaint in %d minutes. The result is recorded in the event log.
饕餮与九婴争食抢料，%s的这道%s备菜额外延迟%.0f分钟。|Taotie and Jiuying squabble over ingredients, delaying %s's preparation of %s by %.0f minutes.
数值配置读取失败，继续使用当前配置|Could not read the balance configuration. Current values are retained.
已重新载入数值配置|Balance configuration reloaded
休息中（11:00 恢复营业）|Resting (Service Resumes at 11:00)
经营已暂停，请处理救援|Service is paused. Resolve the rescue first.
已完成日结，来到下一次清晨|Daily accounts settled. It is the next morning.
食客逃单，收银台与天狗可以降低风险|A guest left without paying. A checkout counter and Tiangou reduce this risk.
菜品收入：|Dish revenue:
顾客小费|Guest Tips
顾客结账 +￥%s|Guest Payment +¥%s
同一位食客又点了一份%s|A guest ordered another serving of %s.
超时订单食材报损|Ingredients Written Off for a Timed-Out Order
顾客等待超时离店，声望下降|A guest left after waiting too long. Reputation decreased.
体力耗尽，已自动休息|Out of stamina; resting automatically
感到疲惫，工作效率下降|Feeling tired; work efficiency reduced
培训、研发或装修期间不能重新排班，请等待项目完成|Wait for training, research or construction to finish before changing shifts.
体力耗尽，先休息再上班|Out of stamina. Rest before returning to duty.
当前阶段最多安排 %d 位员工当班，先让其他员工休息|This stage allows %d on-duty staff. Let someone else rest first.
梼杌暂时拒绝了排班指令|Taowu has refused the shift assignment for now.
训练需要 ￥%d，现金不足|Training requires ¥%d. Not enough cash.
开始训练，期间暂停工作|Training started; service duties are paused.
训练成功，|Training succeeded,
训练未成功，积累了训练经验|Training did not succeed, but experience was gained.
食材采购需要 ￥%d，现金不足|Ingredients cost ¥%d. Not enough cash.
采购 %d 份食材，支出 ￥%d|Bought %d portions of ingredients for ¥%d.
现金不足，暂时无法发传单|Not enough cash to distribute flyers.
已发传单，接下来两小时客流增加|Flyers distributed. More guests will arrive over the next two hours.
现金不足或已经还清债务|Not enough cash, or the debt has already been repaid.
手动偿还原始债务本金|Manual Repayment of Original Principal
偿还本金|Principal Repaid
归还本金 ￥%d，剩余债务 ￥%d|Repaid ¥%d principal; ¥%d debt remains.
清偿经营欠款|Payment of Operating Arrears
清偿欠息、欠薪与欠租；不重复计费用|Pay interest, wages and rent arrears without counting expenses twice.
已清偿经营欠款 ￥%.2f|Paid ¥%.2f in operating arrears.
第%d天日结：收入￥%.2f，净利润￥%.2f，现金￥%.2f|Day %d settled: income ¥%.2f, net profit ¥%.2f, cash ¥%.2f.
债务连续逾期，白泽提醒：优先采购、恢复经营并归还欠款。|Debt is repeatedly overdue. Baize advises: prioritise supplies, restore service and repay what is owed.
每日利息、工资与房租水电|Daily Interest, Wages, Rent & Utilities
自动偿还本金|Automatic Principal Repayment
第 %d 天日结：营业额 ￥%s，工资 ￥%s，房租水电 ￥%s|Day %d settled: revenue ¥%s, wages ¥%s, rent and utilities ¥%s.
%s因长期低心情离职，请及时排班与沟通。|%s left after a long period of low morale. Review shifts and keep in touch with staff.
现金变动|Cash Movement
已重开本局；图鉴收藏、山海志与成就记录保留。|Campaign restarted. Album collections, Shanhai notes and achievements are retained.
已重开本局并保留永久收集|Campaign restarted with permanent collections retained.
已读取最近的安全存档，当前暂停，可重新安排经营|Latest safe save loaded. Service is paused so you can reorganise.
宣传已启动，持续 %d 分钟|Promotion launched for %d minutes.
白泽：本周经营总结已更新。|Baize: this week's business summary is ready.
月度全量存档已备份。|Monthly full-save backup created.
升级为%s！新经营系统已解锁。|Upgraded to %s! New business features are available.
目标奖励：|Goal reward:
目标奖励|Goal Reward
请在装修页校验条件、指派当班空闲员工，再确认开工。|Check the requirements in Furnish, assign idle on-duty staff, then confirm construction.
研发耗用食材|Ingredients Used in Research
食材报损|Ingredient Write-Off
解锁山海食材供应商|Shanhai Supplier Unlocked
开始研发 %s，主持员工在此期间暂停工作|Research on %s has started. The lead staff member pauses other duties.
因长期情绪低落离职，可通过招募再次邀请|Left after prolonged low morale. You may invite them back through recruitment.
完成副职业培训，可切换岗位|Secondary-role training complete. You can now change roles.
训练成功：|Training succeeded:
训练未成功，积累经验|Training did not succeed; experience gained.
研发成功！|Research succeeded!
研发未成功，保留经验；下一次成功率提高|Research did not succeed. Experience is retained, raising the next attempt's success chance.
日结前食材备货|Ingredient Restocking Before Settlement
提出离职，将在当前项目结束后完成交接|Resignation submitted. Departure follows completion of the current project.
新事件：|New event:
资源不足，尚未执行这个选项|Not enough resources. This choice has not been applied.
已处理|Resolved
本次没有资源或属性变化；你保留了现有经营安排。|No resources or attributes changed. Your existing business arrangements remain in place.
债务本金|Debt Principal
待收营业款|Service Receipts Pending
待付罚款|Fine Outstanding
回头客|Returning Guests
特殊食客|Special Guests
已解锁菜品|Unlocked Dishes
食材耗用|Ingredient Use
宣传效果|Promotion Effect
清台速度|Table-Clearing Speed
传菜速度|Serving Speed
厨房效率|Kitchen Efficiency
体力消耗|Stamina Use
采购价格|Purchase Price
顾客等待保护|Guest Patience Protection
传菜穿行|Serving Through Crowds
为原价%.0f%%|%.0f%% of Original Price
%s %s，持续至第%d天 %02d:%02d|%s %s, until day %d at %02d:%02d
状态「%s」：%s；持续至第%d天|Status "%s": %s; until day %d
供应商采购|Supplier Purchase
供应商8折囤货|Supplier Stock Purchase at 20% Off
供应商正常采购|Supplier Stock Purchase at Regular Price
实际入库普通食材 %.0f 份，采购支出 %.2f 元；采购形成存货，耗用时计入成本。|%.0f portions of ordinary ingredients added to stock for ¥%.2f. Purchases enter inventory and become costs when used.
天气变化：|Weather change:
暴雪|Snowstorm
酷暑|Heatwave
雨天：客流-10%，水产类需求+50%|Rain: arrivals −10%, seafood demand +50%
暴雪：客流-25%，汤品需求+50%|Snowstorm: arrivals −25%, soup demand +50%
酷暑：客流-15%，饮品需求+50%|Heatwave: arrivals −15%, drink demand +50%
恢复晴天|Clear Weather Returns
，持续%d分钟。|, lasting %d minutes.
应收|Receivable
待收|Pending Receipt
营业款|Service Receipts
罚款|Fine
罚款未付余额已记入事件账目，请在经营恢复后处理|The unpaid fine is recorded in the event accounts. Pay it when service resumes.
本次宣传效果归零；已支付宣传费不重复扣除。|This promotion's effect is cancelled. Its fee is not charged again.
山海志彩蛋已解锁：|Shanhai discovery unlocked:
客人因过度热情发生纠纷，声望-5；已进入客诉处理。|Overenthusiastic service caused a dispute. Reputation −5; a complaint is now being handled.
延迟事件后果|Delayed Event Outcome
%d分钟后判定后续影响，概率%.0f%%。|A follow-up outcome will be checked in %d minutes, with a %.0f%% chance.
事件奖励|Event Reward
网红根据实际菜品给出了好评|The food blogger praised the actual dish served.
网红根据实际菜品给出差评，声望-10。|The food blogger criticised the dish served. Reputation −10.
待收营业款到账|Pending Service Receipts Collected
待收款本金到账|Receivable Principal Collected
聚宝袋增益|Treasure Pouch Bonus
全天营业款转应收|Daily Service Receipts Transferred to Receivables
貔貅暂存当日营业款；已支用部分不重复收付|Pixiu holds today's receipts. Amounts already spent are not received or paid again.
貔貅暂存全天营业款：已转待收￥%.2f，触发前已支用￥%.2f；后续营业款日末统一到账并按全天营业额增加%.0f%%|Pixiu holds the day's receipts: ¥%.2f transferred to receivables, ¥%.2f already spent before activation. Later receipts arrive at day-end with a %.0f%% bonus on daily revenue.
貔貅暂存后续营业款|Later Service Receipts Held by Pixiu
全天营业应收款到账|Daily Service Receivables Collected
貔貅当日待收款本金到账|Pixiu's Daily Receivable Principal Collected
貔貅全天营业额增益；不重复计销售收入|Pixiu's Daily Revenue Bonus; Sales Not Counted Twice
貔貅日末到账：本金￥%.2f＋全天营业额增益￥%.2f；已支用￥%.2f不重复返还|Pixiu's day-end payment: ¥%.2f principal + ¥%.2f daily revenue bonus. ¥%.2f already spent is not returned again.
待收本金%.2f元与全天营业额5%%增益%.2f元已入账；已支用%.2f元不重复返还。|Receivable principal ¥%.2f and the 5%% daily revenue bonus of ¥%.2f have arrived. ¥%.2f already spent is not returned twice.
次日营业款到账|Next-Day Service Receipts Collected
貔貅次日入账|Pixiu's Next-Day Payment
参赛准备就绪|Contest Preparation Ready
美食节参赛食材|Food Festival Entry Ingredients
美食节奖金|Food Festival Prize
美食节：%s凭%s获得%.1f分，超过连锁品牌%.1f分，夺得冠军！|Food festival: %s's %s scored %.1f, beating the chain's %.1f to win!
美食节：%s获得%.1f分，连锁品牌%.1f分。提升厨艺、创意或选择拿手菜后可再次参赛。|Food festival: %s scored %.1f; the chain scored %.1f. Improve cooking and creativity, or choose a signature dish, then try again.
商业封锁应对：|Blockade response:
稳定供货、真实服务与社区支持已形成合力，昆仑商业封锁正式解除！|Reliable supplies, good service and community support have lifted the Kunlun trade blockade!
已完成封锁应对：|Completed blockade response:
建立独立供货|Establish Independent Supplies
兑现服务承诺|Fulfil Service Promises
建立社区合作|Build Community Partnerships
本次卫生检查通过概率%.0f%%（%s）。|Chance of passing this hygiene inspection: %.0f%% (%s).
已认真准备|Carefully Prepared
未增加准备|No Extra Preparation
卫生检查通过：声望+10|Hygiene inspection passed: reputation +10
卫生检查未通过：罚款200、声望-10，整改后继续经营|Hygiene inspection failed: ¥200 fine, reputation −10. Make improvements and resume service.
特殊食客受骗损失|Loss to a Fraudulent Guest
来客是骗子：已记录实际损失，今后要核对来客信息。|The visitor was a fraud. The actual loss is recorded; verify guest information next time.
大主顾预付赠礼|Gift from a Major Patron
迎来大主顾，留下%.0f元赠礼；消费仍按实际订单结算。|A major patron left a gift of ¥%.0f. Meals are still charged through actual orders.
神兽食客赠礼|Gift from a Mythic Guest
迎来神兽食客，留下赠礼与好评。|A mythic guest left a gift and a favourable review.
当前座位已满，特殊来客已加入候座；赠礼或损失照实记账，有座位后入店消费。|All seats are occupied. The special guest has joined the queue. Gifts and losses are recorded as they occur; dining starts when a seat is free.
蛊雕迎来的候座特殊食客已经入店；接下来按实际菜单与订单结算。|The special guest brought by Gudiao has been seated. Their meal follows the actual menu and order charges.
普通人类|Human
受惊离店订单食材报损|Ingredients Written Off after a Frightened Guest Left
1位普通顾客受惊提前离店，未形成销售收入。|One ordinary guest left early in fright. No sale was recorded.
当时没有可受惊的普通顾客；接下来1小时普通迎客受到影响。|No ordinary guest was present to frighten. Ordinary arrivals will be affected for the next hour.
混沌的试验发现了隐藏菜品配方|Hundun's Experiment Revealed a Hidden Recipe
'''

PAIRS += r'''
排班%s：%s。%s|Shift %s: %s. %s
试验发现可用的稀有食材|The experiment uncovered useful rare ingredients.
裂缝探索获得 %s 碎片|Rift expedition found %s fragments.
后续影响已结算|Follow-Up Resolved
延迟影响已结算：现金与属性变化已记入账本。|Delayed outcome resolved. Cash and attribute changes are recorded in the ledger.
美食节厨师与菜品已准备；报名时仍需支付费用并耗用食材|Festival cook and dish selected. Entry still requires the fee and ingredients.
补缴罚款|Pay Outstanding Fine
已支付罚款 ￥%.2f|Paid fine of ¥%.2f.
今日客流采用%s时段系数|Today's arrivals use the %s service-period modifier.
体力恢复至|Stamina Restored to
自动收取已有及新掉落物，持续%d游戏分钟|Automatically collects existing and new pickups for %d game minutes
确认后在地面刷新灵石×1，须在15真实秒内手动拾取|On confirmation, 1 Spirit Gem appears on the ground. Collect it manually within 15 real seconds.
，持续%d游戏分钟|, lasting %d game minutes
确认后托管今日营业款，日末返还待收本金及全天5%增益|On confirmation, today's receipts are held until day-end, when outstanding principal and a 5% daily revenue bonus are paid.
采购价调整为%.0f%%，持续%d游戏分钟|Purchase prices become %.0f%% of normal for %d game minutes
清洁后厨 · 剩%d分|Kitchen Cleaning · %d min left
收尾服务中 · 完成全部订单后休息|Finishing Service · Resting after All Orders
装修中 · %d/%d分钟%s|Building · %d/%d minutes%s
（闭店暂停）|(Paused While Closed)
剩%d分|%d min left
该装修需阶段%d解锁|This furnishing requires stage %d.
钞票不足，还差￥%.2f|Not enough cash; ¥%.2f more needed.
灵石不足，还差%d颗|Not enough Spirit Gems; %d more needed.
请先处理经营救援|Resolve the business rescue first.
当前无当班空闲员工，请先排班并等待订单或项目结束|No idle on-duty staff are available. Set shifts and wait for an order or project to finish.
该员工未当班、正忙碌或已负责另一项目|This staff member is off duty, busy or leading another project.
位置不可施工，请检查占位、通路、在途路线和餐桌上限|Construction is blocked here. Check occupied space, paths, active routes and the table limit.
装修预订：|Furnishing reservation:
装修资产：|Furnishing asset:
装修完工，效果已生效|Construction complete. Its effects are now active.
解雇补偿及遣散费：|Dismissal compensation and severance:
解雇补偿及遣散费|Dismissal Compensation & Severance
水电费|Utilities
昆仑钱庄贷款日息|Kunlun Bank Daily Loan Interest
贷款到期催收罚款|Overdue Loan Collection Fine
昆仑钱庄贷款到期催收罚款|Kunlun Bank Overdue Loan Fine
昆仑钱庄催收：贷款到期未还清，声望-%d、罚款￥%.2f；请到贷款账本处理。|Kunlun Bank collection: your loan is overdue. Reputation −%d and a ¥%.2f fine. Resolve it in Loans.
日结：债务利息、工资、房租、水电与贷款利息|Daily Settlement: Debt Interest, Wages, Rent, Utilities & Loan Interest
每日最低还本；本金不是费用|Daily Minimum Principal Repayment; Principal Is Not an Expense
日结后现金为负，食肆需要财务救援|Cash is negative after settlement. The inn needs financial rescue.
连续%d日未能补足欠薪或欠租，需要选择救援方案|Wages or rent have been overdue for %d days. Choose a rescue plan.
白泽：经营已触及破产条件。本局仅可救援一次：5000元、日息2%、20日到期；拒绝救援或再次破产将结束经营。|Baize: the inn has reached bankruptcy. One rescue is available this campaign: ¥5,000 at 2% daily interest, due in 20 days. Declining rescue or another bankruptcy ends the campaign.
昆仑钱庄贷款到账；本金不是营业收入|Kunlun Bank Loan Received; Principal Is Not Revenue
昆仑钱庄借入本金|Kunlun Bank Principal Borrowed
偿还贷款本金|Loan Principal Repaid
清偿贷款欠息/罚款；不重复计费用|Loan Interest/Fines Paid; Expenses Not Counted Twice
偿还昆仑钱庄贷款本金|Kunlun Bank Loan Principal Repaid
主动申请破产结算|Voluntary Bankruptcy Settlement
流水号,游戏日,游戏分钟,项目,说明,金额,变动前余额,变动后余额|Transaction ID,Game Day,Game Minute,Category,Description,Amount,Opening Balance,Closing Balance
食材不足：%s售罄。食客心情%d|Ingredient shortage: %s sold out. Guest mood %d
当前菜品|This Dish
，缺货差评，声望%d|; negative shortage review, reputation %d
，改点|; instead orders
，食客离店|; the guest leaves
早餐即将休息，不再接待新客；已入店顾客继续服务。|Breakfast is closing. No new arrivals; guests already inside will still be served.
今日即将打烊，不再接待新客；店员完成订单后休息。|Closing soon. No new arrivals; staff rest after finishing current orders.
已结束。|has ended.
后厨清洁完成，卫生隐患已解除，设备使用计数已清零。|Kitchen cleaning complete. Hygiene risks are cleared and equipment use counts reset.
自动吸附|Auto-Collection
手动拾取|Manual Pickup
钞票（非菜品营业额）|Cash (Outside Dish Revenue)
元|yuan
清洁后厨|Clean the Kitchen
后厨清洁用品与维护|Kitchen Cleaning Supplies & Maintenance
开始清洁后厨，15游戏分钟后完成。|Kitchen cleaning started; finishes in 15 game minutes.
员工赠礼|Gift for Staff
收到书册|Received a Book
一同分享茶点|Shared Tea and Snacks
认真听完彼此今日的感受|Listened to Each Other's Day
白泽图残页：整理了%s的档案（%d/%d）。文化简介仍可自由阅读。|Baize's scattered pages: compiled %s's record (%d/%d). Cultural readings remain freely available.
共同完成专属支线|Completed a Companion Story Together
神兽支线完成：%s。%s|Companion story complete: %s. %s
神兽支线：%s，已保存%s。|Companion story: %s; saved %s.
心结回应|A Response from the Heart
专属隐藏菜已进入实际菜单：|A companion's hidden dish is now on the menu:
凤凰专属支线食材耗用|Ingredients Used for Fenghuang's Story
发现山海志：%s（剧情收藏，无数值奖励）。|Shanhai note discovered: %s (story keepsake; no numerical reward).
共同经历专属事件|Shared a Companion Event
相克同班产生分歧（每人每日最多一次）|Disagreement between Conflicting Companions (Once per Person per Day)
连续十天未排班（无自然衰减）|Not Scheduled for Ten Days (No Passive Decay)
尚未发现。线索：|Not discovered yet. Clue:
白泽：先完成第一笔生意，再领取开店奖励与毕方契约。|Baize: complete your first sale, then claim the opening reward and Bifang's contract.
还没有员工契约，先领取开店任务奖励|No staff contract yet. Claim the opening task reward first.
白泽仍是引导NPC，完成《白泽图》残页支线后才能招募|Baize is still your guide. Complete the scattered-pages story to recruit him.
招聘资源不足，先经营或领取任务奖励|Not enough recruitment resources. Continue service or claim task rewards.
当前稀有度没有可招募员工，未扣费|No recruits are available at this rarity. Nothing was charged.
员工契约招募：|Staff contract recruitment:
重复招募 %s，获得 %d 碎片|Duplicate recruit %s: received %d fragments.
招募成功：%s（%s）|Recruited: %s (%s)
菜单至少保留一道菜品|Keep at least one dish on the menu.
餐厅升级后才可研发特色菜品|Upgrade the restaurant before researching signature dishes.
研发需要先招募|Research requires recruiting
需要一位在岗的厨师主持研发|An on-duty cook must lead the research.
研发需要 ￥%d 与 %d 份食材|Research requires ¥%d and %d portions of ingredients.
开始研发 %s，%d 分钟后揭晓|Researching %s; results in %d minutes.
研发成功！%s 已加入菜单|Research succeeded! %s is on the menu.
研发未成功，积累经验，下次成功率提高|Research did not succeed. Experience raises the next attempt's chance.
这个位置无法摆放，检查范围、占位与餐桌上限|Cannot place here. Check boundaries, occupied space and the table limit.
现金不足，暂时无法购买装修|Not enough cash to buy furnishing.
装修购买：|Furnishing purchase:
已摆放|Placed
食材 %d|Ingredients %d
经营目标奖励：|Business goal reward:
任务完成：|Task complete:
有间小馆开业成功！债务还清，欢迎继续自由经营。|The little inn is a success! Its debt is repaid. Keep serving at your own pace.
升级需要累计营业额 ￥%d 与声望 %d|Upgrading requires total revenue of ¥%d and reputation of %d.
先还清债务，再为街角饭店举办开业典礼|Repay the debt before celebrating the Corner Restaurant's opening.
餐厅升级为街角饭店！解锁 8 张餐桌与 5 个排班位。|Upgraded to Corner Restaurant! Up to 8 tables and 5 on-duty staff.
这个选项需要更多资源，请选择另一种处理方式|This choice needs more resources. Choose another response.
事件选择：|Event choice:
尚未完成接待|Visit Not Yet Complete
正在用餐|Dining
欢迎光临，今日菜品请慢慢看。|Welcome. Take your time with today's menu.
菜已上齐，请慢用。|Everything is here. Enjoy your meal.
谢谢光临，期待您再次到来。|Thank you for coming. We hope to see you again.
谢谢招待。|Thank you for the meal.
好评：声望+30，隐藏菜线索已记入山海志。|Positive review: reputation +30. A hidden-dish clue is recorded in Shanhai Notes.
差评：声望−20，请改善菜品品质与接待。|Negative review: reputation −20. Improve food quality and hospitality.
故人谈起白泽走访山海的往事：白泽好感+10，往事已记入山海志。|The old friend recalls Baize's travels: Baize affinity +10. The memory is recorded in Shanhai Notes.
未能完成茶饮接待，故人暂且告辞。|Tea service was not completed. The old friend has left for now.
故人来访|An Old Friend Visits
幼崽吃完后恋恋不舍，可在特殊顾客图鉴中选择收养，获得神兽线索碎片×1。|The young creature lingers after its meal. Adopt it in the Special Guest Album to receive 1 creature clue fragment.
未能完成接待，幼崽暂时离去。|Service was not completed. The young creature has left for now.
3道菜全获好评：声望+50、客流+10%持续1天。|All 3 dishes received praise: reputation +50, arrivals +10% for 1 day.
有菜品或接待未达要求：声望−15。|Food or service fell short: reputation −15.
报恩的妖怪留下500元厚礼。|The grateful spirit left a generous gift of ¥500.
特殊食客赠予食材|Ingredients Gifted by a Special Guest
报恩的妖怪赠予|Gift from a Grateful Spirit
未完成接待，妖怪约定改日再来。|Service was not completed. The spirit promises to return another day.
已识破密探，昆仑反击事件提供证据选项，执行后声望+20。|The spy was identified. The Kunlun response event now offers an evidence option, granting reputation +20 when used.
密探未被识破，次日昆仑捣乱事件概率提升。|The spy escaped detection. Kunlun interference is more likely tomorrow.
特殊顾客谢礼|Special Guest's Thank-You Gift
个人口味：|Personal tastes:
用餐需求：|Dining needs:
（不限制其他选择）|(Other Choices Remain Available)
菜单中的自由选择|Free Choice from the Menu
长期经营项目支出|Long-Term Business Project Payment
分店或外卖营业款|Branch or Delivery Receipts
分店小费|Branch Tips
分店或外卖销售|Branch or Delivery Sales
外卖平台服务费|Delivery Platform Fee
会员计划开放：每三笔堂食发展一名会员，真实结账积累积分|Membership launched: every three dine-in payments bring one member. Actual payments earn points.
积分已兑换下笔堂食九折券，结账时自动核销|Points exchanged for 10% off the next dine-in bill. Applied automatically at checkout.
外卖接单已开启|Delivery orders enabled
外卖接单已暂停；在途订单继续配送|Delivery orders paused; orders in transit continue.
外卖已接单：已扣食材和运费，送达后扣平台费再到账|Delivery accepted: ingredients and shipping paid. Proceeds arrive on delivery after the platform fee.
已启动|Started
已开业；请派驻厨师与前厅员工并调拨成品|Branch open. Assign a cook and front-of-house staff, then transfer prepared dishes.
已派驻分店，不再参与主店任务；工资照常结算|Assigned to a branch; no longer takes main-inn tasks. Wages still apply.
已返回主店|Returned to Main Inn
；当班容量已满，先安排休息，腾出岗位后可恢复当班|; the shift is full, so they are resting until a duty slot becomes available.
中央厨房建设完成|Central Kitchen Built
中央厨房已投料，成品将在批次完成后入库|Ingredients committed at the central kitchen. Prepared dishes enter stock when the batch finishes.
成品已从中央仓出库，在途调拨不会提前产生销售收入|Prepared dishes dispatched from central storage. Transfers in transit do not create sales revenue.
探索队出发：员工暂离岗位，返回后自动结算并记录|Expedition departed. Staff leave service temporarily; findings are recorded automatically on return.
已觉醒：全属性提升，外观资源使用 awakened 状态|Awakened: all attributes increased; art uses the awakened state.
厨神大赛开始：按当前厨艺、创意、参赛菜品与觉醒状态评分|Cooking contest begun. Scoring uses current cooking, creativity, selected dish and awakening.
外卖耗用食材|Ingredients Used for Delivery
外卖送达，扣除平台费用后到账 ￥%.2f|Delivery completed. Received ¥%.2f after the platform fee.
成品耗用|Prepared Stock Used
山海探索队返回，食材、灵石与员工碎片已入库|Expedition returned. Ingredients, Spirit Gems and staff fragments added to stock.
厨神大赛奖金|Cooking Contest Prize
厨神大赛奖励|Cooking Contest Reward
厨神大赛参赛食材|Cooking Contest Entry Ingredients
厨神大赛 %.1f 分：%s|Cooking contest: %.1f points · %s
夺冠！|Champion!
积累经验后可再次挑战|Gain Experience and Try Again
（单机NPC）|(Offline NPC)
有间小馆（玩家）|Little Inn (Player)
单机世界榜第%d赛季结束：本店第%d名，历史成绩已保存|Local league season %d ended. Our inn placed %d; results saved.
本地单机模拟榜|Local Offline Simulated League
白泽：现金连续下降且不足预计固定支出，请先补货、安排人手并控制采购。紧急救援本局仅一次，日息2%。|Baize: cash keeps falling and cannot cover expected fixed costs. Restock, schedule staff and control purchases. One emergency rescue is available this campaign, at 2% daily interest.
本局已使用紧急救援，再次破产，经营结束。|Emergency rescue was already used. Another bankruptcy ends the campaign.
已放弃一次性紧急救援。|One-time emergency rescue declined.
一次性紧急救援贷款本金（非营业收入）|One-Time Rescue Loan Principal (Not Revenue)
紧急救援借款|Emergency Rescue Borrowing
救援后仍不能补足欠款，经营结束。|The rescue cannot cover the arrears. The campaign has ended.
5000元救援到账并清偿经营欠款。紧急贷款日息2%，20日内偿还；本局不再提供第二次救援。|¥5,000 rescue received and operating arrears paid. The emergency loan charges 2% daily interest and is due within 20 days. No further rescue is available this campaign.
偿还紧急贷款|Emergency Loan Repaid
偿还紧急贷款本金|Emergency Loan Principal Repaid
紧急救援贷款日息2%|Emergency Rescue Loan: 2% Daily Interest
紧急贷款逾期罚款400元|Overdue Emergency Loan Fine: ¥400
紧急救援贷款逾期罚款|Overdue Emergency Rescue Loan Fine
紧急救援贷款已逾期：声望−50，罚款400元；欠息和罚款均不计复利。|Emergency loan overdue: reputation −50, ¥400 fine. Interest arrears and fines do not compound.
主线进展：%s，可到「主线故事」领取。|Story progress: %s. Claim it in Main Story.
本周经营回顾：营业额￥%.2f，接待%d位；到主线故事查看。|This week's review: revenue ¥%.2f, %d guests served. Read it in Main Story.
本月经营回顾：营业额￥%.2f；达标后可领取%d本技能书。|This month's review: revenue ¥%.2f. Meet the goal to claim %d skill books.
今日节日提醒：%s。可自费举办邻里活动，非自动发放奖金。|Today's festival: %s. You may fund a neighbourhood activity; no bonus is paid automatically.
主线奖励：|Story reward:
节日邻里活动|Festival Neighbourhood Activity
邻里活动结束：经费￥%.2f，声望+%d，伙伴心情+%d。|Neighbourhood activity complete: cost ¥%.2f, reputation +%d, companion mood +%d.
文化资料文件不存在|Cultural Reading File Not Found
文化资料不是JSON对象|Cultural Reading Must Be a JSON Object
未知文化资料版本|Unknown Cultural Reading Version
缺少来源清单|Source List Missing
来源不是对象|Source Must Be an Object
空或重复的来源ID：|Empty or duplicate source ID:
来源字段缺失：%s/%s|Source field missing: %s/%s
来源地址无效：|Invalid source address:
来源类型无效：|Invalid source type:
缺少简介类别：|Reading category missing:
缺少简介：%s/%s|Reading missing: %s/%s
简介不是对象：|Reading must be an object:
简介字段缺失：%s/%s|Reading field missing: %s/%s
简介应区分至少三个阅读层次：|Reading must contain at least three sections:
简介没有来源：|Reading has no sources:
简介引用未登记来源：%s/%s|Reading cites an unregistered source: %s/%s
空简介段落：|Empty reading section:
段落引用不是数组：|Section references must be an array:
段落引用未列入简介来源：%s/%s|Section reference missing from reading sources: %s/%s
原文摘录不是数组：|Classical excerpts must be an array:
原文摘录引用无效：|Invalid classical excerpt reference:
原文节选缺少中文释意：|Classical excerpt missing Chinese explanation:
原文节选缺少上下文或篇目：|Classical excerpt missing context or chapter:
英文简介缺失：|English reading missing:
中英文阅读段落不完整：|Chinese and English sections are incomplete:
空英文段落：|Empty English section:
原文节选缺少英文释意：|Classical excerpt missing English translation:
无法读取音频：|Cannot read audio:
无法读取资源清单：|Cannot read asset manifest:
资源清单应包含 aliases 对象：|Asset manifest must contain an aliases object:
忽略不合法的资源别名：|Invalid asset alias ignored:
图片不可用，已回退：|Image unavailable; fallback used:
'''

PAIRS += r'''
有间小馆·开张篇|Little Inn · Opening Chapter
以约20分钟体验单店经营、招募、研发、装修和还债。Demo对时间与升级条件作单独调整。|A roughly 20-minute introduction to service, recruitment, research, furnishing and debt repayment. This legacy demo has its own pacing and upgrade requirements.
接待第一位食客，白泽会带来毕方的故事契约。|Serve your first guest. Baize will bring Bifang's story contract.
粮仓要有余粮|Something in the Storeroom
手动采购一次食材，保证厨房不断供。|Buy ingredients manually once to keep the kitchen supplied.
火羽来相助|A Fire-Feathered Friend
在员工面板使用故事契约招募毕方。|Use a story contract in Staff to recruit Bifang.
一碗招牌汤|A Signature Bowl of Soup
让羬羊研发羊肉汤，第一次研发必定成功。|Have Qianyang research the mutton soup. The first attempt is guaranteed to succeed.
小馆添新色|A New Look for the Inn
购买并放置一件桌椅、装饰或后厨设备。|Buy and place a table, decoration or kitchen facility.
食客口耳相传|Word Spreads
累计完成十次顾客结账，建立小馆的第一批口碑。|Complete ten guest payments to build the inn's first reputation.
账本终于轻了|A Lighter Ledger
还清1200元初始债务，完成有间小馆的第一个目标。|Repay the initial ¥1,200 debt to complete the little inn's first goal.
街角饭店，开张|The Corner Restaurant Opens
累计营业额达到1500元、声望80并清偿债务后，手动升级。|Reach ¥1,500 total revenue and 80 reputation, repay the debt, then confirm the upgrade.
白泽研究所发现的原创隐藏配方；品质与好评提升。|An original hidden recipe discovered at Baize's institute; improves quality and positive reviews.
祝余草与普通食材|Zhuyu and Ordinary Ingredients
隐居的美食评论家|A Food Critic Living in Seclusion
阶段≥1，当前菜品品质均值≥75|Stage ≥1; average current dish quality ≥75
点最贵菜品，只评价一次|Orders the most expensive dish and reviews it once
白泽旧识的仙家|An Immortal Who Knew Baize Long Ago
白泽在店（含引导期）|Baize is at the inn, including his time as guide
点一杯茶饮，讲述白泽往事|Orders a drink and recalls Baize's travels
走失的神兽幼崽|A Lost Young Mythic Creature
阶段≥0|Stage ≥0
点基础菜，吃完后等待收养|Orders a basic dish, then waits to be adopted
严格的美食博主|An Exacting Food Blogger
声望≥300|Reputation ≥300
连点3道菜，逐一打分|Orders 3 dishes and scores each one
曾受玩家帮助的妖怪|A Spirit You Once Helped
曾在员工情绪低落事件中安抚员工|You comforted staff during a low-morale event
消费后留下厚礼|Leaves a generous gift after dining
假扮食客的敌对集团卧底|A Rival Group's Spy Disguised as a Guest
阶段≥2|Stage ≥2
暗中记录，由獬豸或高忠诚员工识破|Takes secret notes; Xiezhi or highly loyal staff can identify the spy
在招聘页支付费用招募第3位员工；重复员工转为碎片，请继续招聘。|Pay for recruitment to hire your third staff member. Duplicates become fragments; keep recruiting until a new companion joins.
完成第一笔营收|Make Your First Sale
备好面条等基础食材，让厨师和服务员当班，等待顾客完成结账。|Stock basic ingredients, put a cook and server on duty, and wait for a guest to pay.
研发1道新菜|Research 1 New Dish
在研发页选择已满足厨师与食材条件的菜品，指派厨师研发并等待成功。|In Research, choose a dish whose cook and ingredient requirements are met. Assign a cook and wait for success.
指派员工完成1次装修|Assign Staff to Finish 1 Construction
在装修页选负责人和位置，完成布局确认后等待施工结束。|Choose a lead and location in Furnish. Confirm the layout, then wait for construction to finish.
在会员计划页支付开通费用，启用会员经营。|Pay the setup fee in Membership to launch the scheme.
接待1单外卖|Complete 1 Delivery
在外卖服务页开启接单，备齐食材并等待真实订单交付。|Enable delivery orders, stock ingredients and wait for an actual order to arrive.
开设1家分店|Open 1 Branch
在分店管理页购买1家分店并安排员工。|Buy a branch in Branch Management and assign staff.
建设中央厨房|Build the Central Kitchen
在中央厨房页支付建设费用，启用中央厨房。|Pay the construction fee in Central Kitchen to open it.
完成1次神兽觉醒|Awaken 1 Companion
准备足够同名碎片与灵石，在神兽觉醒页为员工完成觉醒。|Gather enough fragments of the companion and Spirit Gems, then awaken them in Awakening.
赢得1次厨神大赛|Win 1 Cooking Contest
在厨神大赛页选择合适厨师和菜品，实际参赛并赢得冠军。|Choose a suitable cook and dish in Cooking Contest, enter and win.
相生|Harmony
青年客群对烤翅的轻微概率倾向|A Small Youth-Demographic Preference for Wings
女性客群对仙奶的轻微概率倾向|A Small Female-Demographic Preference for Milk Drinks
欢迎页|Welcome Screen
夜市、休息、闭店|Night Market, Rest and Closing
打开山海探索页面|Opening Shanhai Expeditions
打开厨神大赛页面|Opening Cooking Contest
随营业时段切换；经营暂停时暂停|Changes with service periods; pauses with service
通用按钮确认|Ordinary Button Confirmation
条件提示框|Requirement Dialog
员工真实到站后点单|Taking an Order after Reaching the Guest
真实烹饪动作，工作中定期轻触发|Cooking Action, Played Softly at Intervals
真实传菜动作|Serving Action
真实收银动作|Checkout Action
真实清洁动作|Cleaning Action
到工地后的真实施工动作|Construction Action at the Worksite
真实宣传动作|Promotion Action
地面员工行走|Ground Staff Walking
飞行员工移动|Flying Staff Movement
爬行员工移动|Crawling Staff Movement
顾客实际走到座位|Guest Arrives at Their Seat
就餐状态中定期轻触发|Played Softly at Intervals While Dining
特殊顾客到访，仅一次|Special Guest Arrival, Once per Visit
实际完成收银，非单纯现金上涨|A Completed Checkout, Rather than Any Cash Increase
新增每日账单|New Daily Bill
实际升级阶段|Restaurant Stage Upgrade
研发成果新增|New Research Result
在职人数增加|Staff Count Increases
成功领取任务奖励|Task Reward Claimed
新随机事件弹出|New Random Event
新厨神大赛/美食节结果：获胜|New Contest/Festival Result: Win
新厨神大赛/美食节结果：未获胜|New Contest/Festival Result: No Win
成功手动拾取现金或灵石|Cash or Spirit Gem Collected Manually
本日新增好评；与成交反馈合并限频|New Positive Review; Rate-Limited with Sale Feedback
本日新增差评；与其他反馈合并限频|New Negative Review; Rate-Limited with Other Feedback
放任偷吃|Snacking Unchecked
3天内偷吃事件触发概率提高；每天仍至多一次。|Snacking is more likely for 3 days, still at most once per day.
口碑风险|Reputation Risk
3天后有50%概率曝光并损失30声望。|After 3 days, a 50% chance of exposure and a loss of 30 reputation.
虚假宣传曝光|False Advertising Exposed
火灾风险|Fire Risk
次日毕方烧烤火灾概率翻倍。|Bifang's grill-fire risk doubles tomorrow.
天狗往事|Tiangou's Past
天狗并非只会吞月：原典中的它也被描述为可以御凶的白首兽。食肆选择倾听，让恐慌化作理解。|Tiangou's story reaches beyond swallowing the moon: the old text also describes a white-headed creature that wards off harm. At the inn, listening turns fear into understanding.
法律风险|Legal Risk
放任冲突伤害顾客；3小时后可能被调查并处罚。|Leaving the conflict unchecked harms guests. An investigation and penalty may follow after 3 hours.
顾客冲突后续调查|Follow-Up Investigation of a Guest Dispute
昆仑敌意|Kunlun Hostility
3天内昆仑集团再次捣乱概率提高。|Kunlun interference is more likely for 3 days.
山海伙伴|Shanhai Companions
员工支线与山海志|Companion Stories & Shanhai Notes
记录与设置|Records & Settings
账单与资金流水|Bills & Cash Transactions
帮助与教学|Help & Tutorials
山海相遇|Shanhai Encounters
基础，稳定收入|A Basic Dish with Steady Revenue
面条、清汤与葱花|Noodles, Clear Broth and Scallions
基础，出餐快|A Basic Dish, Quick to Serve
米饭、鸡蛋与家常配料|Rice, Eggs and Everyday Seasonings
解腻，提升顾客满意度|Refreshing after a Rich Meal; Improves Guest Satisfaction
乌梅与调味用料|Smoked Plums and Seasonings
冬季销量翻倍，顾客温暖度提升|Winter Sales Double; Warms Guests
高客单价，年轻顾客喜爱|Higher Spending per Guest; Popular with Younger Guests
烤翅用料、丹木果|Chicken Wings and Danmu Fruit
女性顾客偏爱，小费增加|Favoured More Often by Female Guests; Increases Tips
乳饮用料、薲草|Milk-Drink Ingredients and Pincao
高客单价，雨天销量翻倍|Higher Spending per Guest; Sales Double in Rain
翻台率提升，但食材消耗大|Faster Table Turnover, with High Ingredient Use
大量食材|A Generous Supply of Ingredients
声望+大量，好评率高|A Large Reputation Gain and Strong Reviews
吸引减肥顾客|Attracts Guests Seeking a Lighter Meal
烤制时间缩短，适合午市快节奏|Shorter Grilling Time, Suited to the Lunch Rush
健康顾客增多，降低客诉|Attracts Health-Conscious Guests and Reduces Complaints
上菜速度快，顾客等待耐心+20%|Quick Service; Guest Patience +20%
食材成本降低10%，客单价稳定|Ingredient Cost −10%; Steady Spending per Guest
炸物|Fried Food
夜市时段销量+30%|Night-Market Sales +30%
有20%概率顾客再点一份|20% Chance of a Repeat Order
普通水产|Ordinary Seafood
客单价高，但可能引发顾客冲突|High Spending per Guest, with a Risk of Disputes
口碑极佳，宣传时效果翻倍|Excellent Reviews; Double the Promotion Effect
小吃|Snacks
研发成功后有隐藏效果（随机）|A Random Hidden Effect after Successful Research
顾客纠纷降低，增加回头客|Fewer Guest Disputes; More Returning Guests
每日首次购买顾客必给好评|The First Buyer Each Day Always Gives a Positive Review
传菜速度极快，无等待时间|Very Fast Serving, without a Serving Delay
同时出三份，满足团体顾客|Three Portions at Once for Group Dining
舒适度+5，客流量+3%。|Comfort +5; arrivals +3%.
舒适度+10，客单价+5%。|Comfort +10; spending per guest +5%.
烹饪速度+15%。|Cooking speed +15%.
结账速度+20%，逃单风险减半。|Checkout speed +20%; unpaid walkout risk halved.
新增1个灶台，增加1路并行烹饪产能；仍须有空闲厨师。|Adds 1 stove and 1 parallel cooking slot. An available cook is still needed.
新增1个传菜口，上菜工作速度+15%（同类取最佳）。|Adds 1 serving counter; serving speed +15% (best bonus of this type applies).
新增1个宣传操作位，销售员可在宣传活动期间到此工作。|Adds 1 promotion station where promoters work during campaigns.
新增1个休息操作位，到达后体力恢复+10%。|Adds 1 rest station; stamina recovery +10% after arrival.
开局设施，可移动；扩建请选对应装修项目。|A movable starting facility. Choose the matching furnishing project to expand.
横截面场景|Cross-Section Scene
设备|Equipment
立绘|Portrait
引导立绘|Guide Portrait
菜品图标|Dish Icon
俯视设施|Overhead Facility
特殊来客立绘|Special Guest Portrait
状态图标|Status Icon
顶栏资源图标|Top-Bar Resource Icon
小人|Actor
道具|Item
顾客|Guests
点击查看立绘|Click to View Portrait
知道了，去拾取|Understood · Collect It
知道了，去拾取灵石|Understood · Collect the Spirit Gem
增加两个座位。|Adds Two Seats.
状态已开始；客流|Status Active; Arrivals
奖励 钞票%d|Reward: Cash %d
第|No.
名员工|Staff
人|Guests
羊|Ram
鼠|Mouse
鸟|Bird
兔|Hare
兽|Beast
鱼|Fish
猪|Boar
犬|Hound
雕|Eagle
龟|Turtle
蚨|Insect
狐|Fox
火|Fire
貔|Pixiu
马|Horse
虎|Tiger
奇|Qiongqi
杌|Taowu
云|Cloud
豸|Xiezhi
青|Qinggeng
禄|Tianlu
泽|Baize
烛|Zhulong
羽|Wing
九|Nine
面|Noodles
饭|Rice
梅|Plum
汤|Soup
翅|Wings
奶|Milk
锅|Hotpot
宴|Feast
羹|Thick Soup
叶|Leaf
肉|Meat
穗|Grain
炸|Fried
辣|Spicy
炙|Grilled
饺|Dumpling
'''
PATTERNS += [
    (r'^将累计营业额提升至(\d+)元$', 'Reach ¥{1} in Total Revenue'),
    (r'^将声望提升至(\d+)$', 'Reach {1} Reputation'),
    (r'^备货、排班并完成真实订单，使累计营业额提升至(\d+)元；随后前往经营升级确认下阶段。$', 'Stock ingredients, set shifts and complete paid orders to reach ¥{1} in total revenue. Then confirm the next stage in Grow the Restaurant.'),
    (r'^备货、排班并完成真实订单，使声望提升至(\d+)；随后前往经营升级确认下阶段。$', 'Stock ingredients, set shifts and complete paid orders to reach {1} reputation. Then confirm the next stage in Grow the Restaurant.'),
    (r'^(.+)（单机NPC）$', '{1} (Offline NPC)'),
    (r'^(.+)分$', '{1} points'),
    (r'^横截面场景_(stage_\d+)$', 'Cross-Section Scene · {1}'),
    (r'^设备 (.+)$', 'Equipment · {1}'),
    (r'^(.+)\s+剩(\d+)分钟$', '{1} · {2} minutes left'),
    (r'^顾客(\d+)$', 'Guests {1}'), (r'^等待(\d+)$', 'Waiting {1}'),
    (r'^食材([\d.]+)$', 'Ingredients {1}'), (r'^新鲜(\d+)%$', 'Freshness {1}%'),
    (r'^预计工资￥([\d.]+)$', 'Expected Wages ¥{1}'),
    (r'^(座位|舒适度|客流量|客单价|烹饪速度|结账速度|逃单风险降低) ([+−-]?[\d.]+%?)$', '{1} {2}'),
    (r'^(.+)售罄。食客心情([+−-]?\d+)，食客离店$', '{1} sold out. Guest mood {2}; the guest leaves.'),
]

PAIRS += r'''
*.ogg,*.mp3,*.wav ; 音频文件|*.ogg,*.mp3,*.wav ; Audio Files
*.png,*.jpg,*.jpeg ; PNG/JPG 图片|*.png,*.jpg,*.jpeg ; PNG/JPG Images
原有出餐方案|Existing Service Plan
各份完成即出餐|Serve Each Dish When Ready
九婴 · 同席协调|Jiuying · Coordinated Table Service
减弱场景光效|Reduce Scene Lighting
恢复场景光效|Restore Scene Lighting
名字之外，碗里是什么|Beyond the Name, What Is in the Bowl?
一足立在火边|One Foot beside the Fire
听见丰年之后|After the Harvest Call
先完成开局引导与一笔真实服务，再听旅人的提问。|Finish the opening guidance and a paid meal, then hear the traveller's question.
阶段1后，让已招募的毕方当班、研发烤翅并装好炉灶，就能筹备这一席。|From stage 1, put Bifang on duty, research the wings and install a stove to prepare this meal.
当康当班的丰收折扣日会有来信，周期沿用当前采购规则。|A letter arrives on Dangkang's on-duty harvest-discount day, following the current purchasing cycle.
当康的叫声把折扣粮商引到门前。可以用80买粮入库，也可以保留周转现金。丰收不会替你决定预算。|Dangkang's call brings a grain trader to the door. Buy stock for 80 or keep the working cash. A harvest does not decide your budget.
粮已入库。街坊问能否匀一点给共同的晚饭：赠出账面成本12的食材，或留作明日备料。买粮和赠粮是两笔不同的业务。|The grain is stored. A neighbour asks about a shared supper: give ingredients costing 12, or reserve them for tomorrow. Buying and giving are separate transactions.
当康看过明日预算，没有把谨慎叫成吝啬。你可以分享一条已核实的余粮消息，或约定下次再问。|Dangkang reads tomorrow's budget without calling caution stinginess. Share a checked lead on surplus grain, or agree to ask another day.
分两轮办小席 · 完成3份烤翅付款|A Smaller Meal in Two Rounds · 3 Paid Wing Orders
协作培训30，耗时60分钟 · 再完成5份|Team Training: 30 and 60 Minutes · Then 5 Paid Orders
记录预约与预收20，先听清需求|Record the Booking and 20 Prepayment; Listen First
询问需求，核对旧菜牌、面皮与用料|Ask, Then Check the Old Menu, Wrappers and Ingredients
经Lin确认改为酸梅汤，等待真实到店服务|With Lin's Agreement, Serve a Plum Drink on the Actual Visit
取消未履行预约，退回预收款|Cancel the Unfulfilled Booking & Refund Its Prepayment
用80采购普通食材，先记存货|Purchase 80 of Ordinary Ingredients into Inventory
暂留现金，不买这批粮|Keep the Cash; Pass on This Batch
赠出成本12的真实食材|Share Actual Ingredients Costing 12
留作明日备料|Keep the Stock for Tomorrow
分享余粮联络消息|Share the Surplus-Grain Contact
约好下次再问|Agree to Check Another Day
有人记住了那一足守火的影子。|Someone remembers the one-footed shadow watching the fire.
Lin说，下次想带家里的食谱来。|Lin hopes to bring a recipe from home next time.
Lin留下的食谱仍夹在待试菜牌里，等下一次合适的相约。|Lin's recipe still waits among the menus to try, for another suitable meeting.
街坊送来的粥方，旁边还画着一束谷穗。|An ear of grain is sketched beside the neighbour's porridge recipe.
门灯没有熄，故事便还有下一席。|With the doorway lamp still lit, there is room for another meal.
奖杯旁边，仍放着明日的采购单。小馆已经接待%d笔付款订单，留下%d位特殊来客的往来记录，也收到%d处驿路的回声。|Tomorrow's shopping list lies beside the trophy. The inn has settled %d orders, kept memories of %d special visitors and heard back from %d stops along the road.
不只求分数，也想再尝到记得的火候|Looks beyond scores for the remembered touch of the cook
记住上次菜单与火候选择|Remembers the previous menu and cooking choices
说出一次具体变化，而非固定好评|Comments on a particular change, rather than giving automatic praise
带一份书页线索，关心古书如何被理解|Brings a clue to a scattered page and cares how old books are understood
记住玩家问过哪一种名物|Remembers which creature or object the player asked about
交来一条新的可选阅读，不赠神通收益|Offers another optional reading, without a skill reward
先得到不吓人的说明与合适份量|Needs a reassuring explanation and a suitable portion first
记住曾获得的帮助和约定|Remembers earlier help and promises
带同伴再来，需求仍先询问|Returns with a companion; ask about their needs again
核对菜单与体验，不是专门找茬|Checks the menu against the experience, rather than seeking fault for its own sake
保存原菜单、订单与处理记录|Keeps the original menu, order and response record
如实补充改进经过，不自动删差评|Reports actual improvements; negative reviews are not deleted automatically
回应确有发生的善意|Responds to kindness that actually occurred
保存是赠粮、留座还是清楚解释|Remembers whether help meant grain, a saved seat or a clear explanation
具体回信或食谱交流，非反复刷钱|Returns a personal letter or recipe exchange, rather than repeated cash rewards
观察小馆方法，也有自己的职业顾虑|Observes the inn's methods, while carrying professional concerns of their own
记住一次竞争与待客决定|Remembers a decision about competition and hospitality
可提出合作或疑问，不只永远敌对|May offer cooperation or ask questions, rather than remaining an unchanging enemy
原案规定贷款额度随声望解锁，未给出阈值；实现采用0/200/1000声望，作为可调默认值。|Loan limits unlock with reputation. Adjustable implementation defaults use thresholds of 0/200/1000 because the design did not specify them.
贷款逾期罚款与声望处罚在每笔贷款到期时执行一次；后续仍按剩余本金计单利，不对罚款或欠息计复利。|Each loan's overdue fine and reputation penalty apply once at maturity. Later interest is simple interest on remaining principal; fines and interest arrears do not compound.
现金流水与权责发生制利润分开：采购增加库存、本金偿还减少负债，均不重复计入利润费用。|Cash flows and accrual profit are separate. Purchases increase inventory and principal repayments reduce liabilities; neither is counted again as a profit expense.
工资、房租不足连续两日日结才强制救援；每日欠款仍保留并须实际清偿。|Unpaid wages or rent trigger mandatory rescue after two consecutive settlements. Daily arrears remain and must be paid.
原案未给周/月/节日的具体算法；本文件的日历、自费小活动、技能书奖励与对白是可配置补全。|The calendar, self-funded activities, skill-book rewards and dialogue are configurable implementations of weekly, monthly and festival systems not detailed in the design.
美食节、昆仑事件和厨神大赛的结果来自已有系统；主线不复制抽奖、不绕过活动费用或事件冷却。|Festival, Kunlun and cooking-contest results come from their existing systems. The main story does not repeat draws or bypass entry costs and cooldowns.
所有剧情奖励必须显式领取，旧存档可补建story字段；已领取与日历日期均持久化。|Story rewards require explicit claiming. Older saves can gain missing story fields; claims and calendar dates are persistent.
美食节评分与商业封锁的对抗数值是原文未指定的补全规则，均通过event_balance配置；既有已领取主线进度保留。|Festival scoring and trade-blockade values are implementation rules configured in event_balance. Previously claimed story progress remains valid.
菜谱配方数量按显式成本除以原料单价归一，优先遵守23道默认成本表，保留真实食材种类。|Recipe quantities are normalised from stated cost and unit prices, preserving ingredient types and prioritising the default cost table for the 23 standard dishes.
顾客先独立生成个人口味和用餐需求，再按菜单匹配；年龄与性别仅对原文指定菜品作轻微概率修正，不限制购买。|Guests receive independent tastes and dining needs before menu matching. Age and gender make only small adjustments for specified dishes and never restrict orders.
每天采购按前三日已发生的分类消耗均值乘安全系数，稀有食材不参与自动或直接采购。|Daily purchases use the previous three days' mean category consumption times a safety factor. Rare ingredients are excluded from automatic and direct purchasing.
隐菜单为原创新增，不属于23道标准图鉴数量。|Hidden dishes are original additions outside the 23 standard dish entries.
v1.5仅给凤凰/白泽/九婴示例；其余7条和具体任务数、对话、结局、礼物与好感节奏为可调游戏原创默认值，不伪称原典。|Version 1.5 supplied Fenghuang, Baize and Jiuying examples. The other seven stories, task counts, dialogue, endings, gifts and affinity pacing are adjustable original game content.
完成任务不强制经营暂停；对白可随时关闭，进度持久保存。|Completing a task does not force service to pause. Dialogue may be closed at any time, and progress is persistent.
山海志解锁无经济或属性收益；文化简介始终公开可读，不受招募与档案页限制。|Shanhai Notes grant no cash or attribute benefits. Cultural readings remain available regardless of recruitment or archive-page collection.
九婴连续3次指其自身多线事件的连续成功，不由其他普通事件打断。|Jiuying's three consecutive successes refer to its own multitasking event; ordinary events do not interrupt the sequence.
v1.3未细化的系统数量、时间和成本采用可调整实现默认值。世界榜为离线单机NPC公司经营赛季，不连接网络或提交玩家成绩。|System counts, durations and costs not specified in v1.3 use adjustable defaults. The league simulates offline NPC businesses; it does not connect or submit scores online.
10组均按v1.5第8.3章；关系为游戏改编，文化原典请阅读文化简介。|All 10 pairs follow v1.5 section 8.3. Relationships are game adaptations; see Cultural Reading for the old texts.
仅两人同时在主店当班生效；同类型正向来源取最大、负向来源取最小，两者相加；不同效果保留。|Both companions must be on duty at the main inn. For each effect type, the strongest positive and strongest negative source combine; distinct effects remain separate.
水兽同班的游戏改编；并非原典已记载的固定组合。|A game pairing of water creatures, rather than a fixed partnership recorded in the old texts.
祥瑞与灵狐意象的游戏改编。|A game adaptation pairing auspicious and spirit-fox imagery.
通晓与无面的对照为游戏原创关系。|The contrast between knowing and facelessness is an original game relationship.
镇守意象的游戏改编。|A game adaptation of guardian imagery.
填海与异鱼意象的游戏改编。|A game adaptation connecting the sea-filling bird and an extraordinary fish.
凶兽与公正意象冲突的游戏改编。|A game conflict between ferocious-creature and justice imagery.
凶顽与通晓的理念冲突为游戏原创关系。|The clash between stubbornness and understanding is an original game relationship.
争食抢料情节为游戏原创。|The ingredient-squabbling episode is original game content.
蒙昧与洞察的意象对照为游戏原创。|The contrast between unknowing and insight is original game content.
惊客与巡游气场冲突为游戏原创。|The clash between startling guests and a welcoming procession is original game content.
年龄、性别、口味和用餐需求分别独立抽取；人口特征不决定个人口味，也不限制可售菜单。|Age, gender, taste and dining needs are sampled independently. Demographics neither determine personal taste nor restrict the available menu.
保留原策划的青年烤翅与女性仙奶倾向，只作较小的权重修正；个人口味和需求的匹配权重更高。|The design's youth/wings and female/milk-drink tendencies are small weight adjustments. Personal taste and dining needs carry more weight.
轻食与蔬食需求是顾客自主的饮食选择，不声称虚构菜品有现实减脂或医疗功效。|Light-meal and plant-based preferences are guests' own choices. Fictional dishes make no real-world weight-loss or medical claims.
年龄分布、口味比例与权重是原文未指定的可调实现值，不是现实人群统计。|Age distributions, taste proportions and weights are adjustable implementation values, not real population statistics.
点单由服务员完成，已启用且有库存的菜单菜品均可按顾客独立偏好被选择，不要求销售员。|Servers take orders. Any enabled, stocked dish can be selected according to independent guest preferences; no promoter is required.
售价不再接受魅力、口才或荐菜的单客溢价；品质、全局、顾客类型、取整与8倍封顶保留。|Charm, eloquence and recommendations no longer add per-guest price premiums. Quality, global and guest-type modifiers, rounding and the 8× cap remain.
'''
PATTERNS += [
    (r'^研发(\d+)分$', 'Research {1} min'),
    (r'^培训(\d+)分$', 'Training {1} min'),
    (r'^施工(\d+)分$', 'Building {1} min'),
    (r'^清洁剩(\d+)分 · $', 'Cleaning: {1} min left · '),
    (r'^培训/研发×(\d+) · 装修×(\d+) · 状态预警×(\d+)(.*?) \| 食材([\d.]+) / 新鲜(\d+)% · 预计工资￥([\d.]+)$', 'Training/research ×{1} · Building ×{2} · Warnings ×{3}{4} | Ingredients {5} / Freshness {6}% · Expected wages ¥{7}'),
    (r'^现金流告急 \| (.*)$', 'Cash Warning | {1}'),
    (r'^(.+) · (.+) · 体力(\d+) 心情(\d+)\n(.+)$', '{1} · {2} · Stamina {3} Mood {4}\n{5}'),
]

PAIRS += "\n返回 / Back|Back\n"
PATTERNS += [(r'^清洁剩(\d+)分$', 'Cleaning: {1} min left')]
PAIRS += r'''
场景|Scene
简介|Reading
来客|Guest
箱庭|Dollhouse
'''
PAIRS += "\n副职业|Secondary role\n"
PATTERNS += [(r'^(.+) ([+−-])￥([\d.]+)$', '{1} {2}¥{3}')]
PATTERNS += [
    (r'^(.+)体力耗尽，已自动休息$', '{1} is out of stamina and is resting automatically.'),
    (r'^(.+)感到疲惫，工作效率下降$', '{1} is tired; work efficiency is reduced.'),
    (r'^(.+)开始训练，期间暂停工作$', '{1} has started training and is taking a break from service.'),
    (r'^(.+)训练成功，(.+)\+1$', '{1} completed training: {2} +1.'),
    (r'^(.+)训练成功：(.+)\+1$', '{1} completed training: {2} +1.'),
    (r'^(.+)训练未成功，积累了训练经验$', '{1} gained experience from this unsuccessful training attempt.'),
    (r'^(.+)训练未成功，积累经验$', '{1} gained experience from this unsuccessful training attempt.'),
    (r'^(.+)因长期情绪低落离职，可通过招募再次邀请$', '{1} left after prolonged low morale. Recruitment can bring them back.'),
    (r'^(.+)完成副职业培训，可切换岗位$', '{1} completed secondary-role training and can now change roles.'),
    (r'^(.+)提出离职，将在当前项目结束后完成交接$', '{1} has resigned and will leave after finishing the current project.'),
    (r'^(.+)开始清洁后厨，15游戏分钟后完成。$', '{1} started cleaning the kitchen; finishes in 15 game minutes.'),
    (r'^(.+)装修完工，效果已生效$', '{1} construction is complete. Its effects are now active.'),
    (r'^(.+)已结束。$', '{1} has ended.'),
    (r'^研发需要先招募(.+)$', 'Recruit {1} before beginning this research.'),
    (r'^研发成功！(.+)$', 'Research succeeded! {1} is now available.'),
    (r'^已收养幼崽，获得(.+)线索碎片×1$', 'Young creature adopted. Received 1 {1} clue fragment.'),
    (r'^(.+)处理$', '{1} is handling it'),
    (r'^(.+)碎片$', '{1} Fragments'),
    (r'^(.+) ([+−-][\d.]+%?)$', '{1} {2}'),
    (r'^任务完成：(.+)  (.+)$', 'Task complete: {1} · {2}'),
]
PATTERNS += [
    (r'^状态「(.+)」$', 'Status "{1}"'),
    (r'^持续至第(\d+)天$', 'Until day {1}'),
    (r'^持续(\d+)分钟。$', 'lasting {1} minutes.'),
]
PAIRS += r'''
放任冲突伤害顾客|Leaving the conflict unchecked harms guests
3小时后可能被调查并处罚。|An investigation and penalty may follow after 3 hours.
'''
PATTERNS += [(r'^(体力|心情|忠诚|厨艺|速度|魅力|耐力|口才|创意|算力)\s+([\d.]+)$', '{1} {2}')]
PAIRS += r'''
天气变为%s，持续%d游戏分钟|Weather becomes %s for %d game minutes
%s %+.0f%%，持续%d游戏分钟|%s %+.0f%% for %d game minutes
'''
