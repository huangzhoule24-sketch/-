#!/usr/bin/env bash
set -euo pipefail
shanhai_root="$(realpath "$(dirname "${BASH_SOURCE[0]}")/..")"
cd "$shanhai_root"
export XDG_DATA_HOME="${XDG_DATA_HOME:-/workspace/.tools/godot/data}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-/workspace/.tools/godot/config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/workspace/.tools/godot/cache}"
godot --headless --path . --script res://tools/build_art_pack.gd
godot --headless --path . --script res://tools/build_cultural_art.gd
godot --headless --editor --path . --import
