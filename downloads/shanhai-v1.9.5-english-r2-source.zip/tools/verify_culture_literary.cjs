/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8004').replace(/\/$/, '');
const out = process.argv[2] || 'build/v195-browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function sceneReady() {
    for(let attempt=0;attempt<10;attempt++){
      const s=await state();if(!s.panel)return;
      const event=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id.endsWith(':1'))||s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
      if(event)await click(event.qa_id);
      else if(s.buttons.some(b=>b.qa_id==='panel:close'&&!b.disabled))await click('panel:close');
      else throw Error('Unresolved natural interruption during pickup verification: '+s.panel);
    }
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  const samples=[];
  async function read(cue,language){
    await click(cue,true);
    await check('Culture page opens',()=>window.shanhaiQAState.panel==='文化简介');
    if((await state()).culture_entry.language!==language)await click('culture:language:'+language,true);
    const s=await state();
    if(s.culture_entry.reading_version!==3||s.culture_entry.paraphrase_count!==s.culture_entry.quote_count||s.culture_entry.language!==language||s.culture_entry.section_titles.length!==3)throw Error('Incomplete reading snapshot');
    samples.push({id:s.culture_entry.id,language:s.culture_entry.language,sections:s.culture_entry.section_titles,quotes:s.culture_entry.quote_count});
    return s;
  }
  try {
    receipt=await(await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:full');await click('tutorial:ack');
    await click('nav:员工');await click('panel:close');await click('tutorial:ack');
    await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');
    if((await state()).panel)await click('panel:close');
    await page.waitForFunction(()=>window.shanhaiQAState?.state.served>=1,undefined,{timeout:60000});
    if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');
    await click('tutorial:ack');await click('tutorial:destination');await click('tutorial:ack');await click('panel:close');
    await click('nav:员工');
    await read('culture:employees:xian_yang','zh');await shot('staff-chinese');
    await wheel(20000);await shot('staff-chinese-end');
    await click('culture:language:en',true);await shot('staff-english');
    if(!(await state()).buttons.some(b=>b.qa_id==='culture:back'))throw Error('Fixed return missing');
    await wheel(20000);await shot('staff-english-end');
    checks.push({label:'Original Chinese, rewritten English and attributed short excerpt are reachable by scrolling',ok:true});
    await click('culture:back');if((await state()).panel!=='员工')throw Error('Employee return lost its parent');
    await click('nav:更多');await click('full:open:图鉴',true);await click('catalog:菜品');
    await read('culture:dishes:jingwei_bibimbap','zh');await shot('dish-chinese');
    await wheel(20000);await shot('dish-chinese-end');
    await click('culture:language:en',true);await shot('dish-english');
    await click('culture:back');await read('culture:dishes:phoenix_soup','zh');await shot('phoenix-chinese');await wheel(20000);await shot('phoenix-chinese-end');await click('culture:language:en',true);await shot('phoenix-english');const before=await state();await click('culture:back');
    if((await state()).panel!=='图鉴'||(await state()).culture_navigation.catalog_tab!=='菜品')throw Error('Dish return lost catalog tab');
    checks.push({label:'Cross-cultural recipe remains readable before research; return restores dish catalog',ok:true});
    await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:continue');await sceneReady();
    await click('nav:员工');await read('culture:employees:xian_yang','en');
    checks.push({label:'English reading preference survives a real browser reload',ok:true});
    await page.setViewportSize({width:844,height:390});await sync();await wheel(-20000);await shot('mobile-english');
    await wheel(20000);await shot('mobile-english-end');
    if(!(await state()).buttons.some(b=>b.qa_id==='culture:back'))throw Error('Mobile fixed return is clipped');
    await click('culture:back');if((await state()).panel!=='员工')throw Error('Mobile return lost context');
    checks.push({label:'844x390 long-form English reading keeps its fixed return control',ok:true});
    fs.writeFileSync(path.join(out,'final-state.json'),JSON.stringify(await state(),null,2));
  } catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});}
  const report={game_source:receipt?.game_source,actions,checks,samples,errors};
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({actions:actions.length,checks:checks.length,samples,errors},null,2));
  await browser.close();if(errors.length)process.exitCode=1;
})();
