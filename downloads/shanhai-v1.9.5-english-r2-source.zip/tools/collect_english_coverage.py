#!/usr/bin/env python3
"""Extract display-copy candidates, retaining provenance for native Godot auditing.

Internal routing IDs are not display text. Chinese literary readings and original
classical passages are audited separately because they are deliberately retained.
"""
from pathlib import Path
import ast,json,re
ROOT=Path(__file__).resolve().parent.parent
CJK=re.compile('[\u3400-\u9fff]')
LITERALS=re.compile(r'''\#[^\n]*|"""[\s\S]*?"""|\'\'\'[\s\S]*?\'\'\'|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*' ''',re.VERBOSE)

def collect():
 records={};excluded=[]
 def add(text,path):
  if not CJK.search(text):return
  if text.startswith(('nav:','panel:','finance:','res://','user://','https://')):
   excluded.append({'source':text,'path':path,'reason':'Internal routing identifier, resource path or URL'});return
  if text=='中文':return # The language selector must stay recognisable in both languages.
  records.setdefault(text,[]).append(path)
 for path in sorted((ROOT/'scripts').rglob('*.gd')):
  source=path.read_text()
  for m in LITERALS.finditer(source):
   if m[0].startswith('#'):continue
   try:text=ast.literal_eval(m[0])
   except (SyntaxError,ValueError):continue
   if isinstance(text,str):add(text,f'{path.relative_to(ROOT)}:{source.count(chr(10),0,m.start())+1}')
 def walk(value,path):
  if isinstance(value,str):add(value,path)
  elif isinstance(value,list):
   for i,child in enumerate(value):walk(child,f'{path}/{i}')
  elif isinstance(value,dict):
   for key,child in value.items():walk(child,f'{path}/{key}')
 for path in sorted((ROOT/'config').glob('*.json')):
  if path.name in ['culture.json','localization.json']:continue
  walk(json.loads(path.read_text()),str(path.relative_to(ROOT)))
 walk(json.loads((ROOT/'assets/art/manifest.json').read_text()),'assets/art/manifest.json')
 out=ROOT/'build/english-r2';out.mkdir(parents=True,exist_ok=True)
 payload={'candidates':[{'source':s,'paths':paths}for s,paths in records.items()],'excluded':excluded,'notes':['Original Chinese cultural readings and quotations remain visible by design.','Internal routes and paths are excluded; their display labels are included separately.']}
 (out/'coverage-input.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 print(f'Collected {len(records)} unique text candidates; {len(excluded)} routing/path references excluded with provenance.')
 return payload
if __name__=='__main__':collect()
