extends "res://tools/build_art_pack.gd"
## Selective rebuild. Existing furniture, other staff, customers and import slots remain intact.
func component(image: Image,cutoff: float=.8) -> Image:
	image.convert(Image.FORMAT_RGBA8)
	var w=image.get_width();var h=image.get_height();var visited=PackedByteArray();visited.resize(w*h)
	var best=PackedInt32Array()
	for y in h:
		for x in w:
			var first=y*w+x
			if visited[first] or image.get_pixel(x,y).a<cutoff:continue
			var queue=PackedInt32Array([first]);visited[first]=1;var cursor=0
			while cursor<queue.size():
				var n=queue[cursor];cursor+=1
				for next in [n-1,n+1,n-w,n+w]:
					if next<0 or next>=w*h or visited[next] or absi(next%w-n%w)>1:continue
					if image.get_pixel(next%w,next/w).a<cutoff:continue
					visited[next]=1;queue.append(next)
			if queue.size()>best.size():best=queue
	var clean=Image.create(w,h,false,Image.FORMAT_RGBA8);clean.fill(Color.TRANSPARENT)
	for n in best:clean.set_pixel(n%w,n/w,image.get_pixel(n%w,n/w))
	var rect=clean.get_used_rect()
	return clean.get_region(rect) if rect.has_area() else image
func character_foreground(image: Image) -> Image:
	image=component(image,.8)
	threshold(image,.8)
	return image
func portrait(path: String,index: int) -> Image:
	var source=Image.load_from_file(path)
	var x=roundi(index*source.get_width()/3.0);var right=roundi((index+1)*source.get_width()/3.0)
	# Small gutters protect the horse-tail edge; the largest alpha component excludes neighbours.
	var rect=Rect2i(maxi(0,x-32),0,mini(source.get_width(),right+32)-maxi(0,x-32),source.get_height())
	var image=component(source.get_region(rect),.08)
	var scale=minf(492.0/image.get_width(),492.0/image.get_height())
	image.resize(maxi(1,roundi(image.get_width()*scale)),maxi(1,roundi(image.get_height()*scale)),Image.INTERPOLATE_CUBIC)
	var out=Image.create(512,512,false,Image.FORMAT_RGBA8);out.fill(Color.TRANSPARENT)
	out.blit_rect(image,Rect2i(Vector2i.ZERO,image.get_size()),Vector2i((512-image.get_width())/2,508-image.get_height()))
	return out
func run():
	var changes=JSON.parse_string(FileAccess.get_file_as_string("res://art-source/cultural-r1-inputs.json"))
	catalog=JSON.parse_string(FileAccess.get_file_as_string(ROOT+"art_catalog.json"))
	atlas_index=JSON.parse_string(FileAccess.get_file_as_string(ROOT+"animation_catalog.json"))
	for i in changes.employees.size():
		var id=str(changes.employees[i]);var group=i/3;var row=i%3
		save(portrait(str(changes.portraits[group]),row),"Portraits/"+id+".png")
		var raw: Dictionary={}
		for direction in range(4):
			if changes.get("overrides",{}).has(id):
				var source: Dictionary=changes.overrides[id]
				raw[DIRS[direction]]=cell(str(source.path),int(source.columns),int(source.rows),int(source.source_columns[direction]),int(source.row))
			else:raw[DIRS[direction]]=cell(str(changes.pixels[group]),4,3,direction,row)
		var bases=prepare_bases(raw)
		var gait="fly" if id in FLY else "crawl" if id in CRAWL else "walk"
		bake(id,bases,ACTIONS,gait)
		for awakened in catalog.awakened:
			if str(awakened.base)!=id:continue
			var glow_bases={}
			for direction in DIRS:
				var base: Image=bases[direction];var glow=base.duplicate()
				for y in range(1,79):
					for x in range(1,63):
						if base.get_pixel(x,y).a>.5:continue
						if base.get_pixel(x-1,y).a>.5 or base.get_pixel(x+1,y).a>.5 or base.get_pixel(x,y-1).a>.5 or base.get_pixel(x,y+1).a>.5:glow.set_pixel(x,y,Color("c9a74f"))
				glow_bases[direction]=glow
			bake(str(awakened.id),glow_bases,ACTIONS,gait)
		save(bases.down,"Characters/"+id+"_idle.png")
		save(bases.down.get_region(Rect2i(8,3,48,42)),"Characters/"+id+"_lore.png")
		for employee in catalog.employees:
			if str(employee.id)==id:employee["cultural_revision"]="R1";employee["source"]="art-source/cultural-r1-inputs.json"
		print("Cultural artwork rebuilt: ",id)
	FileAccess.open(ROOT+"animation_catalog.json",FileAccess.WRITE).store_string(JSON.stringify(atlas_index,"\t"))
	FileAccess.open(ROOT+"art_catalog.json",FileAccess.WRITE).store_string(JSON.stringify(catalog,"\t"))
	quit()
