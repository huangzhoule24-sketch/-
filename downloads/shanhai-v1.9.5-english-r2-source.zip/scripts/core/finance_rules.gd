extends RefCounted
## v1.5: transparent cash flows, deterministic day-close charges and loan/rescue rules.
## Sales and cost recognition remain in the existing accrual ledger. Recording a cash
## flow never books a second sale, expense, inventory cost or financing principal.

const ACTIONS = ["loan_apply", "loan_repay", "bankruptcy_settle", "bankruptcy_restart", "bankruptcy_load", "loan_collection_ack"]
var _model_ref: WeakRef
var _rules_ref: WeakRef
var config: Dictionary = {}
var _closing_day: int = 0

func _init(host: Variant, rules: Variant = null) -> void:
	_model_ref = weakref(host)
	if rules != null: _rules_ref = weakref(rules)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/finance.json"))
	config = parsed if parsed is Dictionary else {}

func _m(): return _model_ref.get_ref()
func _rules(): return _rules_ref.get_ref() if _rules_ref != null else _m().get("full_rules")
func _s() -> Dictionary: return _m().state.get("finance", {})
func _money(value: float) -> float: return _m()._money(value)
func _now() -> int: return int(_m().state.total_minutes)
func _day_minutes() -> int:
	return maxi(1,int(_m()._b("day.minutes"))) if _m()!=null and _m().has_method("_b") else 1440
func current_day() -> int: return _closing_day if _closing_day > 0 else _now() / _day_minutes() + 1
func _v(group: String, key: String, fallback: Variant = 0) -> Variant:
	var value: Variant = config.get(group, {}).get(key, fallback)
	if value is int or value is float:
		var candidate: Variant = _m().balance.get("finance.%s.%s" % [group,key], value)
		if _numeric(candidate): return candidate
	return value
func _tier_value(tier: Dictionary, key: String) -> float:
	return float(_m().balance.get("finance.loan.tiers.%s.%s" % [str(tier.id),key], tier[key]))
func _ledger_totals(saved: Dictionary = {}) -> Dictionary:
	var source: Dictionary = saved if not saved.is_empty() else _m().state
	var ledger: Dictionary = source.get("ledger", {})
	var result: Dictionary = {}
	for key in ["sales", "cost_of_sales", "expenses", "procurement", "financing", "capital", "other_income"]: result[key] = float(ledger.get(key, 0))
	return result

func default_state() -> Dictionary:
	return default_state_for(_m().state)

func default_state_for(saved: Dictionary) -> Dictionary:
	return {"version":1, "flows":[], "bills":[], "sequence":0,
		"opening_cash":float(saved.get("cash",0)), "opening_ledger":_ledger_totals(saved),
		"last_settled_day":int(saved.get("total_minutes",0)) / _day_minutes(), "last_bill_day":0, "unpaid_days":0,
		"daily_tips":0.0, "daily_sales_recorded":0.0,
		"loan":{"principal":0.0, "original":0.0, "opened_day":0, "due_day":0, "interest_arrears":0.0, "fine_arrears":0.0, "penalty_applied":false, "collection_pending":false},
		"rescue":{"pending":false, "ever_triggered":false, "day":0, "reason":"", "resume_paused":false},
		"summary_pending":false}

func ensure_state() -> void:
	if not _m().state.get("finance") is Dictionary: _m().state.finance = {}
	var defaults: Dictionary = default_state()
	for key in defaults:
		if not _s().has(key): _s()[key] = defaults[key].duplicate(true) if defaults[key] is Dictionary or defaults[key] is Array else defaults[key]

func balance_defaults() -> Dictionary:
	var result: Dictionary = {}
	for section in ["protection", "loan", "bankruptcy", "history"]:
		for key in config.get(section, {}):
			var value: Variant = config[section][key]
			if _numeric(value): result["finance.%s.%s" % [section,key]] = value
	for tier in config.get("loan", {}).get("tiers", []):
		for key in ["amount", "reputation"]: result["finance.loan.tiers.%s.%s" % [str(tier.id),key]] = tier[key]
	return result

func validate_balance(candidate: Dictionary) -> bool:
	var values: Dictionary=balance_defaults()
	for key in candidate:
		if not str(key).begins_with("finance."): continue
		if not values.has(key) or not _numeric(candidate[key]): return false
		values[key]=candidate[key]
	for key in values:
		if not _numeric(values[key]) or float(values[key])<0 or float(values[key])>1.0e12: return false
	for key in ["finance.protection.days","finance.loan.term_days","finance.loan.active_limit","finance.loan.overdue_reputation_penalty","finance.bankruptcy.unpaid_days","finance.history.flow_limit","finance.history.bill_limit","finance.history.recent_days"]:
		if not _integer(values[key],0 if key in ["finance.protection.days","finance.loan.overdue_reputation_penalty"] else 1): return false
	if int(values["finance.loan.active_limit"])!=1: return false
	for key in ["finance.protection.minimum_repayment_multiplier","finance.loan.daily_interest_rate"]:
		if float(values[key])>1: return false
	var previous_amount: float=-1
	var previous_reputation: float=-1
	for tier in config.get("loan",{}).get("tiers",[]):
		var amount: Variant=values["finance.loan.tiers.%s.amount"%str(tier.id)]
		var reputation: Variant=values["finance.loan.tiers.%s.reputation"%str(tier.id)]
		if not _integer(amount,1) or float(amount)<=previous_amount or not _integer(reputation) or float(reputation)<previous_reputation: return false
		previous_amount=float(amount)
		previous_reputation=float(reputation)
	return true

func record_cash_flow(delta: float, category: String, description: String, balance_before: float, balance_after: float) -> void:
	ensure_state()
	delta = _money(delta)
	if is_zero_approx(delta): return
	_s().sequence = int(_s().sequence) + 1
	_s().flows.append({"id":int(_s().sequence), "minute":_now(), "day":current_day(), "type":category,
		"description":description, "amount":delta, "balance_before":_money(balance_before), "balance":_money(balance_after)})
	while _s().flows.size() > int(_v("history","flow_limit",30000)): _s().flows.pop_front()

func cash_change(delta: float, category: String, description: String) -> float:
	var before: float = float(_m().state.cash)
	_m().state.cash = _money(before + delta)
	var actual: float = _money(float(_m().state.cash) - before)
	record_cash_flow(actual, category, description, before, float(_m().state.cash))
	return actual

func record_sale(gross: float, tip: float = 0.0) -> void:
	ensure_state()
	_s().daily_sales_recorded = _money(float(_s().daily_sales_recorded) + maxf(0,gross))
	_s().daily_tips = _money(float(_s().daily_tips) + clampf(tip,0,maxf(0,gross)))

func _record(kind: String, amount: float, description: String) -> void:
	var rules: Variant = _rules()
	if rules != null and amount != 0: rules.record(kind, amount, description)

func _pay(amount: float, category: String, description: String) -> float:
	var paid: float = _money(minf(maxf(0,float(_m().state.cash)),maxf(0,amount)))
	cash_change(-paid,category,description)
	return paid

func begin_day_close() -> void:
	ensure_state()
	_closing_day = maxi(1,_now() / _day_minutes())

func settle_daily_charges() -> Dictionary:
	ensure_state()
	if _closing_day <= 0: begin_day_close()
	var day: int = _closing_day
	if int(_s().last_settled_day) >= day: return {"day":day,"duplicate":true}
	_s().last_settled_day = day
	var m: Variant = _m()
	var protected: bool = day <= int(_v("protection","days",3))
	var interest_due: float = _money(float(m.state.debt) * m._b("economy.interest_rate"))
	var report: Dictionary = {"day":day,"protected":protected,"revenue":float(m.state.daily_revenue), "interest_due":interest_due,
		"interest":_pay(interest_due,"debt_interest","原始债务日息"),"repayment":0.0,"minimum_due":0.0,
		"wages":0.0,"wages_due":0.0,"rent":0.0,"rent_due":0.0,"utilities":0.0,"utilities_due":0.0,
		"rent_utilities":0.0,"loan_interest":0.0,"loan_interest_due":0.0,"loan_fine":0.0,"overdue":false,
		"procurement":0.0,"procured_units":0,"duplicate":false}
	m.state.interest_arrears = _money(float(m.state.interest_arrears) + interest_due - float(report.interest))
	var minimum: float = minf(float(m.state.debt),m._b("economy.minimum_repayment") * (float(_v("protection","minimum_repayment_multiplier",0.5)) if protected else 1.0))
	report.minimum_due = minimum
	if minimum<=0 or float(m.state.cash) >= minimum:
		report.repayment = _pay(minimum,"debt_principal","每日最低还本")
		m.state.debt = _money(float(m.state.debt) - float(report.repayment))
		m.state.overdue_count = 0
	elif not protected:
		report.overdue = true
		m.state.overdue_count = int(m.state.overdue_count) + 1
		m.state.reputation = maxi(0,int(m.state.reputation)-int(m._b("economy.overdue_reputation_penalty")))
	for employee in m.employees:
		var wage: float = m.employee_wage(employee)
		var paid: float = _pay(wage,"wages","员工工资："+str(employee.name))
		report.wages_due = float(report.wages_due)+wage
		report.wages = float(report.wages)+paid
		if paid < wage: employee.loyalty = maxf(0,float(employee.loyalty)-m._b("economy.wage_loyalty_penalty"))
		var mood_multiplier: float = m.full_rules.effects.daily_mood_cost(employee)
		employee.mood = maxf(0,float(employee.mood)-m._b("employee.daily_mood_decay")*mood_multiplier)
	var rent_due: float = 0.0 if protected else (m._b("economy.rent") if int(m.state.stage)==0 else float(m.balance.get("stage.%d.rent"%int(m.state.stage),m._b("economy.rent"))))
	var utilities_due: float = 0.0 if protected else m._b("economy.utilities")
	report.rent_due = rent_due
	report.utilities_due = utilities_due
	report.rent = _pay(rent_due,"rent","房租")
	report.utilities = _pay(utilities_due,"utilities","水电费")
	report.rent_utilities = float(report.rent)+float(report.utilities)
	if float(report.rent_utilities)<rent_due+utilities_due:
		m.state.reputation = maxi(0,int(m.state.reputation)-int(m._b("economy.rent_reputation_penalty")))
		# v1.5 explicitly resolves the older conflicting arrears definition:
		# only inability to pay the minimum principal increments debt overdue_count.
	m.state.wage_arrears = _money(float(m.state.wage_arrears)+float(report.wages_due)-float(report.wages))
	m.state.rent_arrears = _money(float(m.state.rent_arrears)+rent_due+utilities_due-float(report.rent_utilities))
	var loan: Dictionary = _s().loan
	if float(loan.principal)>0:
		report.loan_interest_due = _money(float(loan.principal)*float(_v("loan","daily_interest_rate",0.01)))
		report.loan_interest = _pay(float(report.loan_interest_due),"loan_interest","昆仑钱庄贷款日息")
		loan.interest_arrears = _money(float(loan.interest_arrears)+float(report.loan_interest_due)-float(report.loan_interest))
		if day>=int(loan.due_day) and not bool(loan.penalty_applied):
			loan.penalty_applied = true
			loan.collection_pending = true
			m.state.reputation = maxi(0,int(m.state.reputation)-int(_v("loan","overdue_reputation_penalty",30)))
			var fine_due: float = float(_v("loan","overdue_fine",200))
			report.loan_fine = _pay(fine_due,"loan_fine","贷款到期催收罚款")
			loan.fine_arrears = _money(float(loan.fine_arrears)+fine_due-float(report.loan_fine))
			_record("expenses",fine_due,"昆仑钱庄贷款到期催收罚款")
			m._notify("昆仑钱庄催收：贷款到期未还清，声望-%d、罚款￥%.2f；请到贷款账本处理。"%[int(_v("loan","overdue_reputation_penalty",30)),fine_due])
	if m.state.has("rescue171"): m.full_rules.rescue.charge_day(report)
	_record("expenses",interest_due+float(report.wages_due)+rent_due+utilities_due+float(report.loan_interest_due),"日结：债务利息、工资、房租、水电与贷款利息")
	_record("financing",-float(report.repayment),"每日最低还本；本金不是费用")
	return report

func finish_day(report: Dictionary) -> Dictionary:
	ensure_state()
	if bool(report.get("duplicate",false)): _closing_day=0; return report
	var day: int = int(report.day)
	if int(_s().last_bill_day)>=day: _closing_day=0; return report
	_s().last_bill_day=day
	var m: Variant = _m()
	var ledger: Dictionary = _ledger_totals()
	var opening: Dictionary = _s().opening_ledger
	var delta: Dictionary = {}
	for key in ledger: delta[key]=_money(float(ledger[key])-float(opening.get(key,0)))
	var flows: Array = flows_by_day(day)
	report["cash_flows"] = flows.duplicate(true)
	var cash_delta: float = 0.0
	var loan_principal: float = 0.0
	var event_cash: float = 0.0
	for flow in flows:
		cash_delta+=float(flow.amount)
		if str(flow.type)=="loan_principal": loan_principal+=float(flow.amount)
		if str(flow.type).begins_with("event"): event_cash+=float(flow.amount)
	var tips: float = minf(float(report.revenue),float(_s().daily_tips))
	var units: int=0
	for purchase in m.state.get("management",{}).get("last_day",{}).get("auto_purchases",[]): units+=int(purchase.get("quantity",0))
	report.procured_units=units
	report.merge({"tips":tips,"dish_revenue":_money(float(report.revenue)-tips),"cost_of_sales":float(delta.cost_of_sales),
		"procurement":maxf(0,float(delta.procurement)),"projects":maxf(0,float(delta.capital)),"operating_expenses":float(delta.expenses),
		"other_income":float(delta.other_income),"loan_principal_flow":_money(loan_principal),"event_cash":_money(event_cash),
		"net_profit":_money(float(report.revenue)+float(delta.other_income)-float(delta.cost_of_sales)-float(delta.expenses)),
		"net_cashflow":_money(cash_delta),"opening_cash":float(_s().opening_cash),"closing_cash":float(m.state.cash),
		"flow_count":flows.size(),"cash_reconciled":absf(float(m.state.cash)-float(_s().opening_cash)-cash_delta)<0.011,
		"minute":_now(),"pickup_income":flows.filter(func(flow):return str(flow.type)=="pickup_cash").reduce(func(total,flow):return total+float(flow.amount),0.0)},true)
	report["operating_income"]=float(report.revenue)+float(report.get("pickup_income",0))
	var payables: float = float(m.state.get("wage_arrears",0))+float(m.state.get("rent_arrears",0))
	var unpaid: bool = payables>0.005 and float(m.state.cash)+0.005<payables
	_s().unpaid_days=int(_s().unpaid_days)+1 if unpaid else 0
	report.unpaid_days=int(_s().unpaid_days)
	if float(m.state.cash)<0:
		_trigger_rescue("日结后现金为负，食肆需要财务救援",day)
	elif int(_s().unpaid_days)>=int(_v("bankruptcy","unpaid_days",2)):
		_trigger_rescue("连续%d日未能补足欠薪或欠租，需要选择救援方案"%int(_s().unpaid_days),day)
	report.bankruptcy=bool(_s().rescue.pending)
	_s().bills.append(report.duplicate(true))
	while _s().bills.size()>int(_v("history","bill_limit",120)): _s().bills.pop_front()
	_s().summary_pending=true
	if m.state.get("revision171",{}).get("daily_auto",false):
		m.state.revision171.daily_pending=true
		m.paused=true
	m.state.last_report=report.duplicate(true)
	m.state.get_or_add("day_reports",[]).append(report.duplicate(true))
	var limit: int = int(_rules().config.economy.daily_report_limit) if _rules()!=null else int(_v("history","bill_limit",120))
	while m.state.day_reports.size()>limit: m.state.day_reports.pop_front()
	_s().opening_cash=float(m.state.cash)
	_s().opening_ledger=ledger
	_s().daily_tips=0.0
	_s().daily_sales_recorded=0.0
	_closing_day=0
	return report

func _trigger_rescue(reason: String, day: int) -> void:
	if not bool(_s().rescue.pending): _s().rescue.resume_paused=bool(_m().paused)
	_s().rescue.merge({"pending":true,"ever_triggered":true,"day":day,"reason":reason},true)
	_m().paused=true
	if _m().state.has("rescue171"): _m().full_rules.rescue.assess_rescue()
	_m()._notify("白泽：经营已触及破产条件。本局仅可救援一次：5000元、日息2%、20日到期；拒绝救援或再次破产将结束经营。")

func _result(ok: bool, reason: String = "", extra: Dictionary = {}) -> Dictionary:
	var result: Dictionary={"ok":ok,"reason":reason,"message":reason}
	result.merge(extra,true)
	return result

func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	ensure_state()
	var loan: Dictionary=_s().loan
	match action:
		"loan_apply":
			if bool(_s().rescue.pending): return _result(false,"濒临破产请使用独立的一次性紧急救援，常规贷款不可替代救援")
			if _m().state.has("rescue171") and _m().full_rules.rescue.regular_banned(): return _result(false,"负债阶段无法申请常规贷款，请先还清逾期债务；濒临破产时将提供一次紧急救援")
			if int(_m().state.stage)<1: return _result(false,"主动贷款在阶段1解锁，破产救援时可提前申请")
			if float(loan.principal)+float(loan.interest_arrears)+float(loan.fine_arrears)>0.005: return _result(false,"同一时间仅能保有一笔未结清贷款")
			var amount: float=float(args.get("amount",1000)) if _numeric(args.get("amount",1000)) else -1
			for tier in config.get("loan",{}).get("tiers",[]):
				if is_equal_approx(amount,_tier_value(tier,"amount")):
					if float(_m().state.reputation)<_tier_value(tier,"reputation"): return _result(false,"该额度需要声望%d"%int(_tier_value(tier,"reputation")))
					return _result(true,"",{"amount":amount})
			return _result(false,"请选择1000、2000或5000元贷款档位")
		"loan_repay":
			var amount: float=float(args.get("amount",0)) if _numeric(args.get("amount",0)) else -1
			if amount<=0: return _result(false,"还款金额必须大于0")
			var owed: float=float(loan.principal)+float(loan.interest_arrears)+float(loan.fine_arrears)
			if owed<=0: return _result(false,"没有待偿还贷款")
			if float(_m().state.cash)<minf(owed,amount): return _result(false,"现金不足，无法偿还所选金额")
			return _result(true,"",{"amount":minf(owed,amount)})
		"bankruptcy_settle": return _result(not bool(_s().rescue.pending),"救援选择已打开" if bool(_s().rescue.pending) else "")
		"bankruptcy_restart", "bankruptcy_load": return _result(bool(_s().rescue.pending),"仅在破产救援中使用" if not bool(_s().rescue.pending) else "")
		"loan_collection_ack": return _result(bool(loan.collection_pending),"没有待确认催收通知" if not bool(loan.collection_pending) else "")
	return _result(false,"未知财务操作")

func perform(action: String, args: Dictionary = {}) -> Dictionary:
	var check: Dictionary=can_perform(action,args)
	if not check.ok: return check
	var loan: Dictionary=_s().loan
	match action:
		"loan_apply":
			var amount: float=float(check.amount)
			var day: int=current_day()
			loan.merge({"principal":amount,"original":amount,"opened_day":day,"due_day":day+int(_v("loan","term_days",30)),"interest_arrears":0.0,"fine_arrears":0.0,"penalty_applied":false,"collection_pending":false},true)
			cash_change(amount,"loan_principal","昆仑钱庄贷款到账；本金不是营业收入")
			_record("financing",amount,"昆仑钱庄借入本金")
			if bool(_s().rescue.pending):
				_s().rescue.pending=false
				_m().paused=bool(_s().rescue.resume_paused)
			return _result(true,"贷款￥%.2f已到账，日息1%%，第%d日到期"%[amount,int(loan.due_day)],{"loan":loan.duplicate(true)})
		"loan_repay":
			var remaining: float=float(check.amount)
			var total: float=remaining
			for field in ["fine_arrears","interest_arrears","principal"]:
				var paid: float=minf(remaining,float(loan[field]))
				loan[field]=_money(float(loan[field])-paid)
				remaining=_money(remaining-paid)
				_pay(paid,"loan_principal" if field=="principal" else "liability_settlement","偿还贷款本金" if field=="principal" else "清偿贷款欠息/罚款；不重复计费用")
				if field=="principal": _record("financing",-paid,"偿还昆仑钱庄贷款本金")
			if float(loan.principal)+float(loan.interest_arrears)+float(loan.fine_arrears)<=0.005: loan.collection_pending=false
			return _result(true,"贷款已偿还￥%.2f"%total,{"paid":total})
		"bankruptcy_settle":
			_trigger_rescue("主动申请破产结算",current_day())
			return _result(true,"请选择紧急贷款、重开本局或读取存档")
		"bankruptcy_restart": return _result(true,"",{"request_restart":true})
		"bankruptcy_load": return _result(true,"",{"request_load":true})
		"loan_collection_ack": loan.collection_pending=false; return _result(true,"催收通知已确认，贷款仍需实际归还")
	return _result(false,"未知财务操作")

func flows_by_day(day: int = -1) -> Array:
	var result: Array=[]
	for flow in _s().get("flows",[]):
		if day<0 or int(flow.day)==day: result.append(flow.duplicate(true))
	return result

func recent_expense_composition(days: int = -1) -> Array:
	ensure_state()
	if days<0: days=int(_v("history","recent_days",7))
	var from_day: int=maxi(1,current_day()-maxi(1,days)+1)
	var categories: Dictionary={}
	for flow in _s().flows:
		if int(flow.day)<from_day or float(flow.amount)>=0: continue
		var category: String=str(flow.type)
		categories[category]=_money(float(categories.get(category,0))-float(flow.amount))
	var result: Array=[]
	for category in categories: result.append({"type":category,"amount":float(categories[category])})
	result.sort_custom(func(a,b): return float(a.amount)>float(b.amount))
	return result

func _csv_cell(value: Variant) -> String:
	var content: String=str(value)
	# Spreadsheet export must not turn a player's custom label into a formula.
	if content.begins_with("=") or content.begins_with("+") or content.begins_with("@") or content.begins_with("-"): content="'"+content
	return "\""+content.replace("\"","\"\"")+"\""

func export_csv(day: int = -1, translator: Callable = Callable()) -> String:
	var lines: PackedStringArray=["流水号,游戏日,游戏分钟,项目,说明,金额,变动前余额,变动后余额"]
	if translator.is_valid():lines[0]=str(translator.call(lines[0]))
	for flow in flows_by_day(day):
		var cells: PackedStringArray=[]
		var description=str(translator.call(str(flow.description))) if translator.is_valid() else str(flow.description)
		for value in [flow.id,flow.day,flow.minute,flow.type,description,"%.2f"%float(flow.amount),"%.2f"%float(flow.balance_before),"%.2f"%float(flow.balance)]: cells.append(_csv_cell(value))
		lines.append(",".join(cells))
	return "\n".join(lines)+"\n"

func preview_bill() -> Dictionary:
	ensure_state()
	var m: Variant = _m()
	var protected: bool = current_day()<=int(_v("protection","days",3))
	var wages: float=0.0
	for employee in m.employees: wages+=m.employee_wage(employee)
	var rent: float=0.0 if protected else (m._b("economy.rent") if int(m.state.stage)==0 else float(m.balance.get("stage.%d.rent"%int(m.state.stage),m._b("economy.rent"))))
	var utilities: float=0.0 if protected else m._b("economy.utilities")
	var delta: Dictionary={}
	var ledger: Dictionary=_ledger_totals()
	for key in ledger: delta[key]=_money(float(ledger[key])-float(_s().opening_ledger.get(key,0)))
	return {"preview":true,"day":current_day(),"protected":protected,"revenue":float(m.state.daily_revenue),
		"tips":float(_s().daily_tips),"procurement":maxf(0,float(delta.procurement)),"cost_of_sales":float(delta.cost_of_sales),
		"wages_due":wages,"rent_due":rent,"utilities_due":utilities,
		"interest_due":_money(float(m.state.debt)*m._b("economy.interest_rate")),
		"minimum_due":minf(float(m.state.debt),m._b("economy.minimum_repayment")*(float(_v("protection","minimum_repayment_multiplier",0.5)) if protected else 1.0)),
		"loan_interest_due":_money(float(_s().loan.principal)*float(_v("loan","daily_interest_rate",0.01))),
		"opening_cash":float(_s().opening_cash),"current_cash":float(m.state.cash),
		"note":"尚未日结：以上固定费用为当前配置预估，未提前扣款；实际账单在日结后生成。"}

func snapshot(day: int = -1) -> Dictionary:
	ensure_state()
	var tiers: Array=[]
	for tier in config.get("loan",{}).get("tiers",[]):
		var amount: float=_tier_value(tier,"amount")
		tiers.append({"id":str(tier.id),"amount":amount,"reputation":_tier_value(tier,"reputation"),"check":can_perform("loan_apply",{"amount":amount})})
	return {"bills":_s().bills.duplicate(true),"flows":flows_by_day(day),"expense_composition":recent_expense_composition(),
		"loan":_s().loan.duplicate(true),"loan_tiers":tiers,"rescue":_s().rescue.duplicate(true),"summary_pending":bool(_s().summary_pending),
		"protected":current_day()<=int(_v("protection","days",3)),"protection_days":int(_v("protection","days",3)),
		"current_day":current_day(),"loan_rate":float(_v("loan","daily_interest_rate",0.01)),"loan_term_days":int(_v("loan","term_days",30)),
		"unpaid_days":int(_s().unpaid_days),"preview":preview_bill()}

static func _numeric(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
static func _integer(value: Variant, minimum: int = 0) -> bool:
	return _numeric(value) and float(value)>=minimum and float(value)==floorf(float(value)) and float(value)<=2147483647

func validate_state(saved: Dictionary, now: int = -1) -> bool:
	if now<0: now=_now()
	if not _integer(saved.get("version"),1) or int(saved.version)!=1: return false
	for key in ["sequence","last_settled_day","last_bill_day","unpaid_days"]:
		if not _integer(saved.get(key)): return false
	for key in ["opening_cash","daily_tips","daily_sales_recorded"]:
		if not _numeric(saved.get(key)): return false
	if float(saved.daily_tips)<0 or float(saved.daily_sales_recorded)<float(saved.daily_tips): return false
	if not saved.get("summary_pending") is bool or not saved.get("opening_ledger") is Dictionary: return false
	for key in ["sales","cost_of_sales","expenses","procurement","financing","capital","other_income"]:
		if not _numeric(saved.opening_ledger.get(key)): return false
	if not saved.get("flows") is Array or saved.flows.size()>int(_v("history","flow_limit",30000)): return false
	var previous_id: int=0
	for flow in saved.flows:
		if not flow is Dictionary: return false
		if not _integer(flow.get("id"),1) or int(flow.id)<=previous_id or int(flow.id)>int(saved.sequence): return false
		if not _integer(flow.get("minute")) or int(flow.minute)>now or not _integer(flow.get("day"),1): return false
		if not flow.get("type") is String or str(flow.type).is_empty() or not flow.get("description") is String: return false
		for key in ["amount","balance_before","balance"]:
			if not _numeric(flow.get(key)): return false
		if is_zero_approx(float(flow.amount)) or absf(float(flow.balance_before)+float(flow.amount)-float(flow.balance))>0.011: return false
		previous_id=int(flow.id)
	if not saved.get("bills") is Array or saved.bills.size()>int(_v("history","bill_limit",120)): return false
	var previous_day: int=0
	for bill in saved.bills:
		if not bill is Dictionary or not _integer(bill.get("day"),1) or int(bill.day)<=previous_day or int(bill.day)>int(saved.last_bill_day): return false
		if not _integer(bill.get("minute")) or int(bill.minute)>now: return false
		for key in ["revenue","interest","repayment","wages","wages_due","rent","rent_due","utilities","utilities_due","loan_interest","loan_interest_due","loan_fine","procurement","cost_of_sales","tips","dish_revenue","operating_expenses","other_income","net_profit","net_cashflow","opening_cash","closing_cash"]:
			if not _numeric(bill.get(key)): return false
		for key in ["protected","overdue","bankruptcy","cash_reconciled"]:
			if not bill.get(key) is bool: return false
		for key in ["revenue","interest","repayment","wages","wages_due","rent","rent_due","utilities","utilities_due","loan_interest","loan_interest_due","loan_fine","procurement","cost_of_sales","tips","dish_revenue","operating_expenses","other_income"]:
			if float(bill[key])<0: return false
		if float(bill.tips)>float(bill.revenue) or absf(float(bill.dish_revenue)+float(bill.tips)-float(bill.revenue))>0.011: return false
		if absf(float(bill.revenue)+float(bill.other_income)-float(bill.cost_of_sales)-float(bill.operating_expenses)-float(bill.net_profit))>0.011: return false
		if bill.cash_reconciled and absf(float(bill.closing_cash)-float(bill.opening_cash)-float(bill.net_cashflow))>0.011: return false
		if bill.has("cash_flows"):
			if not bill.cash_flows is Array:return false
			var net=0.0
			var previous_flow=0
			for flow in bill.cash_flows:
				if not flow is Dictionary or not _integer(flow.get("id"),1) or int(flow.id)<=previous_flow or int(flow.id)>int(saved.sequence):return false
				if not flow.get("description") is String or not _numeric(flow.get("amount")) or not _numeric(flow.get("balance_before")) or not _numeric(flow.get("balance")):return false
				if not _integer(flow.get("day"),1) or int(flow.day)!=int(bill.day):return false
				if absf(float(flow.balance_before)+float(flow.amount)-float(flow.balance))>0.011:return false
				net+=float(flow.amount);previous_flow=int(flow.id)
			if absf(net-float(bill.net_cashflow))>0.011:return false
		previous_day=int(bill.day)
	if int(saved.last_bill_day)>int(saved.last_settled_day) or int(saved.last_settled_day)>now / _day_minutes(): return false
	if not saved.get("loan") is Dictionary: return false
	var loan: Dictionary=saved.loan
	for key in ["principal","original","interest_arrears","fine_arrears"]:
		if not _numeric(loan.get(key)) or float(loan[key])<0: return false
	if float(loan.principal)>float(loan.original): return false
	for key in ["opened_day","due_day"]:
		if not _integer(loan.get(key)): return false
	if int(loan.due_day)<int(loan.opened_day): return false
	if float(loan.original)>0 and int(loan.opened_day)<1: return false
	if float(loan.original)>0 and int(loan.due_day)-int(loan.opened_day)!=int(_v("loan","term_days",30)): return false
	for key in ["penalty_applied","collection_pending"]:
		if not loan.get(key) is bool: return false
	if bool(loan.collection_pending) and not bool(loan.penalty_applied): return false
	if not saved.get("rescue") is Dictionary: return false
	var rescue: Dictionary=saved.rescue
	for key in ["pending","ever_triggered","resume_paused"]:
		if not rescue.get(key) is bool: return false
	if not _integer(rescue.get("day")) or int(rescue.day)>now / _day_minutes()+1 or not rescue.get("reason") is String: return false
	if bool(rescue.pending) and (not bool(rescue.ever_triggered) or str(rescue.reason).is_empty()): return false
	return true
