extends RefCounted
## Candidate-only upgrades. Never writes a save or changes the running model.
## Legacy campaigns keep their original mode unless the player requests import.

const DemoRules = preload("res://scripts/core/demo_rules.gd")
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const CURRENT_VERSION := 5
const FULL_SCHEMA_VERSION := 4
const V15_KEYS := ["finance", "customer_service", "synergies", "sidequests", "migration_v15"]
const LEGACY_EVENT_IDS := ["supplier_discount", "hygiene", "taotie_steals", "bifang_fire"]
const CLAIM_MAP := {"first_order": "opening", "stock": "stock", "research": "research", "regulars": "regulars", "debt_free": "debt"}
const FULL_KEYS := ["campaign_claimed", "stage_rewards", "tutorial_researched", "ledger", "promotion_bonus", "wage_arrears", "rent_arrears", "day_reports", "weekly_count", "monthly_count", "last_promotion_kind", "developer_mode", "management", "world", "expansion", "effect_resolution"]


static func migrate(payload: Variant, model: Variant, convert_legacy: bool = false) -> Variant:
	if not payload is Dictionary or not _integer(payload.get("version"), 1): return null
	var version := int(payload.version)
	if version > CURRENT_VERSION: return null
	if not payload.get("state") is Dictionary: return null
	var candidate: Dictionary = preload("res://scripts/services/employee_identity.gd").migrate(payload)
	# This namespace starts with canonical employee IDs. Its event IDs (e.g. bifang)
	# and transaction identifiers are business identities, not legacy employee IDs.
	if payload.state.get("culture_experience") is Dictionary:
		candidate.state.culture_experience = payload.state.culture_experience.duplicate(true)
	if candidate.state.get("balance_overrides") is Dictionary:
		for key in candidate.state.balance_overrides.keys():
			if str(key).begins_with("recommend.") or str(key).begins_with("coeff.recommend_"):candidate.state.balance_overrides.erase(key)
	for customer in candidate.get("customers",[]):
		if customer is Dictionary and customer.get("stage")=="recommending" and _integer(customer.get("due_minute"),-1) and int(customer.due_minute)<0:
			customer.stage="ordering";customer.order_decided=true;customer.recommendation_done=true;customer.recommendation_premium=0.0;customer.remaining_minutes=0
	var mode := str(candidate.state.get("mode", "normal"))
	# Current full saves and ordinary current reads remain entirely unchanged.
	# An explicit import may still convert a chapter previously saved in the current schema.
	if version == CURRENT_VERSION and not (convert_legacy and mode in ["demo", "normal"]):
		if mode=="full" and not candidate.state.has("revision18") and candidate.state.get("story") is Dictionary:
			var story: Dictionary=candidate.state.story
			story.v18_legacy_collection=story.get("completed",[]).has("all_beasts") and story.get("collected_ids",[]).size()>=26
		if mode=="full" and not candidate.state.has("revision19") and candidate.state.get("story") is Dictionary:
			candidate.state.story.v19_legacy_collection="all_beasts" in candidate.state.story.get("completed",[]) and candidate.state.story.get("collected_ids",[]).size()>=28
		return candidate
	var sandbox: Variant = model.get_script().new(1)
	if mode != "full":
		# Validate before adding full-system defaults or archiving event data.
		# Versions 1–3 used the original four-event, two-option schema. A v4
		# chapter uses the current strict event schema, without old-data repairs.
		sandbox._rules = DemoRules.new(sandbox)
		if version < FULL_SCHEMA_VERSION:
			sandbox.events = []
			for id in LEGACY_EVENT_IDS:
				sandbox.events.append({"id": id, "options": [{}, {}]})
		if not sandbox._valid_save(candidate): return null
		if version == 1:
			for key in DemoRules.CHAPTER_KEYS: candidate.state.erase(key)
			for employee in candidate.employees: employee.research_until = 0
			# Foundation v1 never persisted chapter state. Only that absent schema
			# is rebuilt; cash, stock, employees, orders and RNG remain unchanged.
			for key in DemoRules.CHAPTER_KEYS:
				candidate.state[key] = _copy(sandbox.state[key])
			candidate.state.event_last_minute = candidate.state.total_minutes
		else:
			for employee in candidate.employees:
				if not employee.has("research_until"): employee.research_until = 0
		_fill_attribute_defaults(candidate.employees, sandbox)
		if convert_legacy:
			# Old chapters had no full-system payload. Unexpected, preexisting
			# fields must not be replaced by clean defaults during conversion.
			for key in FULL_KEYS + V15_KEYS:
				if candidate.state.has(key): return null
			# Use only empty full-system defaults, never the fresh game's starting
			# money, ingredients, roster, random seed or reward balances.
			sandbox._rules = sandbox.full_rules
			sandbox.start_full()
			for key in FULL_KEYS:
				if not candidate.state.has(key): candidate.state[key] = _copy(sandbox.state[key])
			candidate.state.mode = "full"
			candidate.state.management.items = _empty_inventory(sandbox)
			var generic: Dictionary = candidate.state.management.items.generic
			generic.quantity = candidate.state.ingredients
			generic.freshness = candidate.state.freshness
			generic.value = float(candidate.state.ingredients) * float(sandbox.full_rules.management._ingredient("generic").price)
			generic.consumption_today = candidate.state.daily_consumption
			generic.history = candidate.state.consumption_history.duplicate(true)
			candidate.state.management.skill_books = 0
			candidate.state.management.tutorial_trial_available = not "qianyang_soup" in candidate.state.unlocked_dishes and candidate.state.research_projects.is_empty()
			candidate.state.tutorial_researched = "qianyang_soup" in candidate.state.unlocked_dishes
			candidate.state.expansion.membership.observed_served = candidate.state.served
			candidate.state.expansion.delivery_next_offer = candidate.state.total_minutes
			candidate.state.expansion.last_day = int(float(candidate.state.total_minutes) / 1440.0)
			candidate.state.expansion.erase("league")
			for branch in candidate.state.expansion.branches.values(): branch.next_order = candidate.state.total_minutes
			candidate.state.world.last_random_minute = candidate.state.total_minutes
			candidate.state.campaign_claimed = []
			for id in candidate.state.quests_claimed:
				if CLAIM_MAP.has(id) and not CLAIM_MAP[id] in candidate.state.campaign_claimed:
					candidate.state.campaign_claimed.append(CLAIM_MAP[id])
			# A legacy stage reward was already paid when the stage was reached.
			candidate.state.stage_rewards = []
			for stage in range(1, int(candidate.state.stage) + 1): candidate.state.stage_rewards.append(stage)
			candidate.state.legacy_import = {"source_version": version, "source_mode": mode, "event_queue": candidate.state.event_queue.duplicate(true), "event_history": candidate.state.event_history.duplicate(true), "quests_claimed": candidate.state.quests_claimed.duplicate(true), "completed": candidate.state.completed}
			candidate.state.event_queue = []
			candidate.state.event_history = []
			candidate.state.completed = false
			for employee in candidate.employees: _fill_employee_fields(employee, sandbox)
			_migrate_baize(candidate.employees, sandbox)
	elif version < FULL_SCHEMA_VERSION:
		# Only pre-v4 full saves lack v1.3 fields. A v4 payload missing one
		# is malformed and must not be repaired while adding v1.5 defaults.
		if not candidate.state.has("effect_resolution"):
			candidate.state.effect_resolution = {"first_reviews": {}, "extra_income_total": 0.0, "prevented_escapes": 0}
		if candidate.state.get("world") is Dictionary and not candidate.state.world.has("seen_events"):
			candidate.state.world.seen_events = []
			if candidate.state.world.get("history") is Array:
				for entry in candidate.state.world.history:
					if entry is Dictionary and entry.get("id") is String and not entry.id in candidate.state.world.seen_events:
						candidate.state.world.seen_events.append(entry.id)
		if candidate.get("employees") is Array:
			_fill_attribute_defaults(candidate.employees, sandbox)
			_migrate_baize(candidate.employees, sandbox)
	if str(candidate.state.get("mode", "normal")) == "full":
		_migrate_v15(candidate, version, sandbox)
	candidate.version = CURRENT_VERSION
	return candidate


static func _migrate_v15(candidate: Dictionary, source_version: int, sandbox: Variant) -> void:
	# This migration grants no starting cash, gems, contracts or collection.
	# Existing jobs, exact customer choices, trained attributes and RNG stay as
	# saved. New systems are initialized separately from the fresh-game economy.
	var owned_baize := false
	if candidate.get("employees") is Array:
		for employee in candidate.employees:
			if not employee is Dictionary: continue
			if not employee.has("affinity"): employee.affinity = 0.0
			if str(employee.get("id", "")) == "bai_ze": owned_baize = true
	if not candidate.state.has("migration_v15"):
		var marker := {"source_version": source_version, "legacy_campaign": true, "legacy_baize_owned": owned_baize}
		if candidate.state.has("tutorial"): marker.old_tutorial = _copy(candidate.state.tutorial)
		candidate.state.migration_v15 = marker
	if candidate.state.get("effect_resolution") is Dictionary:
		if not candidate.state.effect_resolution.has("pending_complaints"): candidate.state.effect_resolution.pending_complaints = []
		if not candidate.state.effect_resolution.has("next_complaint_id"): candidate.state.effect_resolution.next_complaint_id = 1
	if candidate.state.get("management") is Dictionary:
		var management: Dictionary = candidate.state.management
		var procurement_defaults := {"procurement_strategy":"auto" if bool(management.get("auto_procure", true)) else "pause", "fixed_quantities":{}, "procurement_prepared_day":0, "pending_auto_purchases":[]}
		for key in procurement_defaults:
			if not management.has(key): management[key] = _copy(procurement_defaults[key])
	# Sandbox references only the deep-copied candidate. Default factories may
	# read the candidate's day/cash/roster, never the running game's values.
	sandbox.state = candidate.state
	sandbox._rules = sandbox.full_rules
	if candidate.get("employees") is Array:
		sandbox.employees.clear()
		for employee in candidate.employees:
			if employee is Dictionary: sandbox.employees.append(employee)
	var modules: Dictionary = {
		"finance": sandbox.full_rules.finance,
		"customer_service": sandbox.full_rules.customer_service,
		"synergies": sandbox.full_rules.synergies,
		"sidequests": sandbox.full_rules.sidequests
	}
	for key in modules:
		if candidate.state.has(key): continue
		var module: Variant = modules[key]
		if key == "finance": candidate.state[key] = module.default_state_for(candidate.state)
		else: candidate.state[key] = module.default_state()
		if key == "sidequests":
			candidate.state.sidequests.legacy_baize_owned = owned_baize
			for quest in module.config.get("quests", []):
				candidate.state.sidequests.quests[str(quest.id)] = module._quest_default()
			for employee in sandbox.employees:
				if employee is Dictionary and employee.get("id") is String:
					candidate.state.sidequests.affinity_records[str(employee.id)] = module._affinity_default()
	if candidate.get("customers") is Array:
		for customer in candidate.customers:
			if not customer is Dictionary: continue
			# An old in-flight order already chose a dish. Never re-roll its
			# choice or price by injecting the new recommendation stage.
			if not customer.has("recommendation_done"): customer.recommendation_done = true
	Guide.ensure(sandbox)


static func _empty_inventory(sandbox: Variant) -> Dictionary:
	var result: Dictionary = {}
	for definition in sandbox.full_rules.management.ingredients:
		result[str(definition.id)] = {"quantity": 0.0, "freshness": 100.0, "value": 0.0, "consumption_today": 0.0, "history": []}
	return result


static func _fill_attribute_defaults(saved_employees: Array, sandbox: Variant) -> void:
	for employee in saved_employees:
		if not employee is Dictionary or not employee.get("attributes") is Dictionary: continue
		for attribute in sandbox.full_rules.management.config.get("attributes", []):
			if not employee.attributes.has(attribute): employee.attributes[attribute] = 0


static func _fill_employee_fields(employee: Dictionary, sandbox: Variant) -> void:
	var template: Dictionary = sandbox._create_employee(sandbox._employee_config(str(employee.id)))
	sandbox.full_rules.management._ensure_employee(template)
	var defaults := {"primary_role": employee.role, "secondary_role": "", "branch_id": "", "expansion_until": 0, "expansion_job_id": "", "awakened": false}
	for key in ["skill_level", "wage_extra", "management_until", "management_job_type", "shift_enabled", "shift_periods", "training_history", "training_experience_by_attribute", "phoenix_revived_day"]:
		defaults[key] = _copy(template[key])
	for key in defaults:
		if not employee.has(key): employee[key] = _copy(defaults[key])


static func _migrate_baize(saved_employees: Array, sandbox: Variant) -> void:
	for employee in saved_employees:
		if not employee is Dictionary or str(employee.get("id", "")) != "bai_ze": continue
		if str(employee.get("primary_role", "")) != "all": continue
		var secondary: Variant = employee.get("secondary_role", "")
		if not secondary is String or (secondary != "" and (not secondary in sandbox.full_rules.management.config.get("roles", []) or secondary == "tutor")): continue
		employee.primary_role = "tutor"
		if str(employee.get("role", "")) == "all": employee.role = "tutor"


static func _copy(value: Variant) -> Variant:
	return value.duplicate(true) if value is Dictionary or value is Array else value


static func _integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum and floorf(float(value)) == float(value)
