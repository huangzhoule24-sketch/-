extends RefCounted
## Persistent cultural encounters. All progress comes from real service/stock/clock hooks.
## Reading and localization never call these hooks or draw simulation random numbers.
var _ref: WeakRef
var config: Dictionary = {}
const ACTIONS = ["culture_choose", "culture_defer", "culture_read_letter", "culture_review_menu", "culture_batch_mode", "culture_night_meal", "culture_cancel_booking", "culture_branch_theme", "culture_reduce_fx"]

func _init(host) -> void:
	_ref = weakref(host)
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://config/cultural_experience.json"))
	if parsed is Dictionary: config = parsed
func m(): return _ref.get_ref()
func s() -> Dictionary: return m().state.get("culture_experience", {})
func now() -> int: return int(m().state.total_minutes)
func day() -> int: return now() / maxi(1,int(m()._b("day.minutes")))
func value(key: String) -> float: return float(config.get("settings",{}).get(key,0))
func pair(zh: String,en: String) -> Dictionary: return {"zh":zh,"en":en}
func result(ok: bool,zh: String="",en: String="") -> Dictionary: return {"ok":ok,"reason":zh,"message":zh,"reason_en":en}

func ensure_state() -> void:
	if not m().state.get("culture_experience") is Dictionary: m().state.culture_experience = {}
	var defaults = {"version":1,"events":{},"letters":[],"transactions":[],"applied":[],"counters":{},"route_completed":[],"evidence":[],"introduced":[],"reduce_fx":false,"menu_reviewed":false,"batch_mode":"legacy","guest_memories":{},"branch_themes":{},"booking":{},"night":{},"last_served":int(m().state.served),"opening_inventory":m().full_rules.management.inventory_value()}
	for key in defaults:
		if not s().has(key): s()[key] = defaults[key].duplicate(true) if defaults[key] is Dictionary or defaults[key] is Array else defaults[key]
	for id in ["bifang","menu","harvest"]:
		if not s().events.has(id): s().events[id] = {"status":"unseen","node":"start","choice":"","progress":0,"target":0,"due":0,"deferred_until":0,"training_until":0}

func definition(kind: String,id: String) -> Dictionary:
	for entry in config.get(kind,[]):
		if str(entry.id)==id: return entry
	return {}
func guided() -> bool: return bool(m().state.get("tutorial",{}).get("finished",false))
func active(id: String) -> bool: return m().full_rules.active(id)
func event(id: String) -> Dictionary: return s().get("events",{}).get(id,{})
func count(key: String) -> int: return int(s().counters.get(key,0))
func increment(key: String,amount: int=1) -> void: s().counters[key]=count(key)+amount
func _pending(id: String) -> bool: return str(event(id).get("status","")) in ["offered","waiting","followup","deferred"]
func _eligible(id: String) -> bool:
	if not guided() or bool(m().state.get("rescue171",{}).get("ended",false)): return false
	match id:
		"menu": return int(m().state.served)>0
		"bifang": return int(m().state.stage)>=1 and active("bi_fang") and "bifang_wings" in m().state.unlocked_dishes and not m().full_rules.dollhouse.fixtures("stove").is_empty()
		"harvest": return active("dang_kang") and day()>0 and day()%maxi(1,int(m().balance.get("events.dangkang_period_days",5)))==0
	return false

func tick() -> void:
	ensure_state()
	for id in s().events:
		var item: Dictionary=event(id)
		if item.status=="unseen" and _eligible(id): item.status="offered"
		if item.status=="deferred" and now()>=int(item.deferred_until): item.status="offered"
		if item.status=="followup" and now()>=int(item.due): _finish_event(id)
	if guided() and count("warm_paid")>=3 and not "bi_fang" in s().introduced:
		s().introduced.append("bi_fang")
		_add_letter("introduction:bi_fang",pair("炉边来客 · 一只脚的影子","A visitor by the grill · a one-footed shadow"),pair("门外来了一位青赤披翼的旅人，只用一足站定。毕方问：‘若有一天我来掌厨，你愿意先同我约好几桌、几轮吗？’它留下一个名字，便沿着门前的灯影去往下一站。","A traveller with blue-green and red wings stands on one foot at the door. Bifang asks, ‘If I cook here one day, shall we first agree how many tables and rounds?’ It leaves a name, then follows the doorway lamplight towards the next stop."),"introduction","bi_fang")
	_tick_booking()
	_tick_night()
	for region in config.get("regions",[]):
		if str(region.id) in s().route_completed: continue
		if not region.requires.all(func(id): return id in s().route_completed): continue
		if count(str(region.metric))>=int(region.target):
			s().route_completed.append(str(region.id))
			_add_letter("route:"+str(region.id),region.title,region.letter,"route",str(region.employee))

func on_paid(customer: Dictionary,amount: float,received: float=-1) -> void:
	ensure_state()
	# A payment is observed after the existing model increments its settled-order count.
	if int(m().state.served)<=int(s().last_served): return
	s().last_served=int(m().state.served)
	if amount<=0: return
	var dish=m()._dish(str(customer.get("dish_id","")))
	var id=str(customer.get("dish_id",""))
	increment("paid:"+id)
	if id=="noodles" or str(dish.get("category",""))=="汤品": increment("warm_paid")
	if id in ["phoenix_soup","phoenix_true_soup"]: increment("phoenix_paid")
	var chef=str(customer.get("chef_id",""))
	var fire=event("bifang")
	if fire.status=="waiting" and chef=="bi_fang" and id=="bifang_wings" and now()>=int(fire.training_until) and bool(customer.get("culture_banquet",false)):
		fire.progress=int(fire.progress)+1
		if int(fire.progress)>=int(fire.target): _followup("bifang")
	var night: Dictionary=s().night
	if bool(night.get("active",false)) and chef=="zhu_long" and id=="zhulong_ramen" and now()<=int(night.until):
		night.progress=int(night.progress)+1
		if int(night.progress)>=int(value("night_orders")):
			night.active=false;night.completed=true;night.reply_due=now()+int(value("followup_minutes"))
	var vid=str(customer.get("visitor_id",""))
	if not vid.is_empty():
		var memory: Dictionary=s().guest_memories.get(vid,{"visits":0,"last_dish":"","last_day":0,"promises":[],"orders":0,"last_visit_serial":-1})
		memory.orders=int(memory.get("orders",0))+1
		if int(memory.get("last_visit_serial",-1))!=int(customer.get("visit_serial",0)):
			memory.visits=int(memory.visits)+1;memory.last_visit_serial=int(customer.get("visit_serial",0))
		memory.last_dish=id;memory.last_day=day()
		memory.promises=s().events.keys().filter(func(k): return event(k).status=="resolved")
		s().guest_memories[vid]=memory
	if not str(customer.get("culture_booking_id","")).is_empty():
		var rest=maxf(0,amount-float(s().booking.get("used",0)))
		var cash=rest if received<0 else received
		_transaction("booking:sale_balance","sale",cash,0,0,rest,pair("本订单其余收款/应收","Remaining payment / receivable on this order"),rest-cash)
		var cost=float(customer.get("ingredient_cost",0))
		_transaction("booking:ingredients","cost_of_sales",0,-cost,0,-cost,pair("本订单实际耗用成本","Actual ingredient cost of this order"))
		s().booking.status="served";_followup("menu")

func allow_cooking(employee: Dictionary,customer: Dictionary) -> bool:
	var e=event("bifang")
	if e.get("status","")!="waiting" or str(customer.get("dish_id",""))!="bifang_wings": return true
	if str(employee.id)!="bi_fang": return false
	if bool(customer.get("ingredients_reserved",false)) or e.choice!="small": return true
	var pending=m().customers.filter(func(c):return bool(c.get("culture_banquet",false)) and not bool(c.get("paid",false))).size()
	var goal=2 if int(e.progress)<2 else 3
	return pending<maxi(0,goal-int(e.progress))

func on_cooking_started(customer: Dictionary,employee: Dictionary) -> void:
	if event("bifang").get("status","")=="waiting" and str(employee.id)=="bi_fang" and str(customer.dish_id)=="bifang_wings": customer.culture_banquet=true

func handover(employee_id: String) -> Dictionary:
	# Presentation follows the existing serving timeline; it cannot complete or pause an order.
	if employee_id!="di_jiang":return {}
	for customer in m().customers:
		if str(customer.get("stage",""))!="serving" or str(customer.get("worker",""))!=employee_id:continue
		var motion: Dictionary=customer.get("task_motion",{})
		if not bool(motion.get("teleport",false)):continue
		var progress=clampf((float(now())+m()._fraction-float(motion.started))/maxf(1,float(motion.work_minutes)),0,1)
		return {"progress":progress,"dish_id":str(customer.dish_id),"customer_id":int(customer.id)}
	return {}

func on_story_claim(id: String) -> void:
	if id!="champion":return
	var zh="奖杯旁边，仍放着明日的采购单。小馆已经接待%d笔付款订单，留下%d位特殊来客的往来记录，也收到%d处驿路的回声。"%[int(m().state.served),s().guest_memories.size(),s().route_completed.size()]
	var en="Tomorrow’s shopping list lies beside the trophy. The inn has settled %d orders, kept memories of %d special visitors and heard back from %d stops along the road. "%[int(m().state.served),s().guest_memories.size(),s().route_completed.size()]
	if event("bifang").status=="resolved":
		zh+="有人记住了那一足守火的影子。";en+="Someone remembers the one-footed shadow watching the fire. "
	if event("menu").status=="resolved":
		if s().booking.get("status","")=="served":zh+="Lin说，下次想带家里的食谱来。";en+="Lin hopes to bring a recipe from home next time. "
		else:zh+="Lin留下的食谱仍夹在待试菜牌里，等下一次合适的相约。";en+="Lin’s recipe still waits among the menus to try, for another suitable meeting. "
	if event("harvest").status=="resolved" and event("harvest").choice=="gift":
		zh+="街坊送来的粥方，旁边还画着一束谷穗。";en+="An ear of grain is sketched beside the neighbour’s porridge recipe. "
	zh+="门灯没有熄，故事便还有下一席。";en+="With the doorway lamp still lit, there is room for another meal."
	_add_letter("epilogue",pair("散席之后 · 山海仍有来路","After the meal · the road goes on"),pair(zh,en),"epilogue")

func work_multiplier(employee: Dictionary,task: String,dish: Dictionary) -> float:
	var e=event("bifang")
	if task=="cooking" and str(employee.id)=="bi_fang" and str(dish.get("id",""))=="bifang_wings" and e.get("status","")=="waiting" and e.get("choice","")=="training" and now()>=int(e.training_until): return float(config.settings.get("bifang_trained_cook_multiplier",.95))
	return 1.0

func returning_guest(customer: Dictionary) -> void:
	var id=str(customer.get("visitor_id",""));var memory: Dictionary=s().guest_memories.get(id,{})
	if int(memory.get("visits",0))<1:return
	var dish=str(m()._dish(str(memory.get("last_dish",""))).get("name",memory.get("last_dish","")))
	var lines={"old_gourmand":"上回那份%s的火候，我还记得。","baize_friend":"上次的%s让我又翻了一页旧书。","lost_cub":"我记得这里，也记得上回的%s。","picky_blogger":"今天想看看，上回%s的说明有没有更清楚。","grateful_monster":"谢谢上次的%s，这次我也带来一句家乡的做法。","kunlun_spy":"我还想再看看，你们怎样把%s端给不同的人。"}
	customer.culture_returning=true
	customer.interaction_text=str(lines.get(id,"上次的%s，我还记得。"))%dish
	customer.interaction_until=now()+10

func branch_menu(branch_id: String,candidates: Array) -> Array:
	var theme=str(s().branch_themes.get(branch_id,""))
	var ids={"qianlai":["noodles","qianyang_soup","plum_juice"],"qingqiu":["fox_milk","plum_juice","zhuyu_salad"],"zhange":["bifang_wings","luwu_platter","taowu_barbecue"],"danxue":["phoenix_soup","phoenix_true_soup","baize_hidden_banquet"]}.get(theme,[])
	if ids.is_empty():return candidates
	var selected=candidates.filter(func(d):return str(d.get("id",d)) in ids if d is Dictionary else str(d) in ids)
	return candidates if selected.is_empty() else selected

func on_exploration(job: Dictionary) -> void:
	ensure_state()
	var serial="garden:"+str(job.get("id",job.get("started",now())))+":"+str(now())
	if str(job.get("employee_id",""))=="ying_zhao":
		var items: Array[String]=[];var english: Array[String]=[]
		var en_names={"danmu":"Danmu fruit","pincao":"Pincao","shan_hai_fish":"Shanhai fish","rare":"rare ingredients","zhuyu":"Zhuyu","migu":"Migu shoots"}
		for id in job.get("reward",{}).get("items",{}):
			var name=str(id)
			for ingredient in m().full_rules.management.ingredients:
				if str(ingredient.id)==str(id):name=str(ingredient.name);break
			items.append(name+" ×"+str(job.reward.items[id]));english.append(str(en_names.get(id,id))+" ×"+str(job.reward.items[id]))
		var note=pair("\n第%d日归来，已入库：%s。"%[day()+1," / ".join(items)],"\nReturned on day %d. Recorded stock received: %s."%[day()+1," / ".join(english)])
		_add_letter(serial,pair("英招 · 园圃也有远方","Yingzhao · a garden has distant neighbours"),pair(str(config.letters.garden.zh)+note.zh,str(config.letters.garden.en)+note.en),"exploration","ying_zhao")

func _followup(id: String) -> void:
	var e=event(id)
	e.status="followup";e.due=now()+int(value("followup_minutes"))
func _finish_event(id: String) -> void:
	var e=event(id)
	if e.status=="resolved": return
	e.status="resolved"
	var key=""
	match id:
		"bifang": key="bifang_"+str(e.choice);increment("bifang_followup")
		"menu": key="menu_"+str(e.choice);increment("menu_followup")
		"harvest": key="harvest_"+str(e.choice)
	if config.letters.has(key): _add_letter("event:"+id,pair("山海来信","A letter to the inn"),config.letters[key],"event",{"bifang":"bi_fang","menu":"di_jiang","harvest":"dang_kang"}.get(id,""))
func _add_letter(id: String,title: Dictionary,body: Dictionary,kind: String,employee: String="") -> void:
	if s().letters.any(func(x): return str(x.id)==id): return
	s().letters.append({"id":id,"title":title.duplicate(true),"body":body.duplicate(true),"kind":kind,"employee_id":employee,"minute":now(),"read":false})
	while s().letters.size()>int(value("history_limit")): s().letters.pop_front()
	m()._notify("有一封新的山海来信，可在山海驿路中阅读。")
	m().autosave_requested.emit()

func _transaction(id: String,kind: String,cash_delta: float,inventory_delta: float,liability_delta: float,profit_delta: float,description: Dictionary,receivable_delta: float=0) -> void:
	assert(is_equal_approx(cash_delta+inventory_delta+receivable_delta-liability_delta,profit_delta))
	if id in s().applied: return
	s().applied.append(id)
	s().transactions.append({"id":id,"kind":kind,"minute":now(),"cash":m()._money(cash_delta),"inventory":m()._money(inventory_delta),"liabilities":m()._money(liability_delta),"receivables":m()._money(receivable_delta),"profit":m()._money(profit_delta),"description":description})
	while s().transactions.size()>int(value("history_limit")): s().transactions.pop_front()

func _refund_booking(reason: String="cancelled") -> void:
	var b: Dictionary=s().booking
	var amount=float(b.get("remaining",0))
	if amount>0:
		m().change_cash(amount*-1,"customer_refund","退还Lin的未履行订单预收款")
		_transaction("booking:refund:"+reason,"prepayment_refund",-amount,0,-amount,0,pair("退还未履行预收款","Refund an unfulfilled prepayment"))
	b.remaining=0.0;b.status="refunded"
	b.refund_reason=reason
	if reason=="unfulfilled":
		s().evidence.append({"kind":"unfulfilled_booking","minute":now(),"text":pair("Lin未能完成这次用餐，预收款已退回；下次预约前请先核对队列、备料与服务排班。","Lin could not finish this visit and the prepayment was refunded. Before another booking, check the queue, ingredients and service staffing.")})
		m()._notify("Lin本次用餐未能完成，已退回预收款。请查看排班、等候队列与山海来信。")
	event("menu").choice="refund";_followup("menu")
	if float(m().state.cash)<0:m().full_rules.finance._trigger_rescue("预约退款后现金不足",day()+1)

func collect_payment(customer: Dictionary,gross: float) -> float:
	if str(customer.get("culture_booking_id",""))!="lin": return gross
	var b: Dictionary=s().booking
	if b.get("status","")!="arrived" or int(b.get("customer_id",-1))!=int(customer.id): return gross
	var deposit=float(b.get("remaining",0));var used=minf(maxf(0,gross),deposit)
	var refund=deposit-used
	# The ordinary checkout remains the only place recognizing full revenue and COGS.
	# Only the outstanding amount enters the existing cash/receivable collection system.
	if refund>0: m().change_cash(-refund,"customer_refund","Lin换单后退还预收余款")
	_transaction("booking:settlement","prepayment_applied",-refund,0,-deposit,used,pair("预收款结转与退回余款（营业收入由原订单记录）","Apply prepayment and refund its balance (sales stay in the original order ledger)"))
	b.remaining=0.0;b.used=used;b.status="served" if gross>0 else "refunded"
	if gross<=0: event("menu").choice="refund";_followup("menu")
	return maxf(0,gross-used)

func _tick_booking() -> void:
	var b: Dictionary=s().booking
	if b.is_empty(): return
	if b.get("status","")=="arrived":
		if m()._customer(int(b.customer_id)).is_empty(): _refund_booking("unfulfilled")
		return
	if b.get("status","")!="queued" or not m().business_open(): return
	if now()<int(b.get("next_attempt",0)): return
	b.next_attempt=now()+5
	if not m().full_rules.revision18.accepting_guests() or m().customers.size()>=int(m().state.seats): return
	if not m().full_rules.management.can_make("plum_juice"): return
	var size=m().customers.size()
	m()._spawn_customer("plum_juice",false,"lin")
	if m().customers.size()>size:
		b.customer_id=int(m().customers.back().id);b.status="arrived"

func _tick_night() -> void:
	var n: Dictionary=s().night
	if bool(n.get("active",false)) and (now()>int(n.until) or not m().business_open()):
		n.active=false;n.completed=false
		_add_letter("night:unfinished:"+str(n.started),pair("夜席 · 下次再约","Night meal · another evening"),pair("这一席未能在约定时段完成。烛龙记下已完成的订单，留待下次按伙伴体力与库存重新安排。","The meal did not finish in the agreed period. Zhulong notes the completed orders and will plan again with the team’s stamina and stock in mind."),"night","zhu_long")
	if bool(n.get("completed",false)) and now()>=int(n.get("reply_due",now()+1)) and not bool(n.get("letter_sent",false)):
		n.letter_sent=true
		_add_letter("night:complete:"+str(n.started),pair("烛龙 · 夜饭散席之后","Zhulong · after the night meal"),config.letters.night_meal,"night","zhu_long")

func can(action: String,args: Dictionary={}) -> Dictionary:
	ensure_state()
	if action=="culture_reduce_fx":return result(args.get("enabled") is bool)
	if action=="culture_review_menu": return result(true)
	if action=="culture_read_letter": return result(s().letters.any(func(x):return str(x.id)==str(args.get("id",""))))
	if action=="culture_branch_theme":
		var branch=str(args.get("branch_id",""));var theme=str(args.get("theme",""))
		return result(m().state.expansion.branches.has(branch) and bool(m().state.expansion.branches[branch].get("open",false)) and (theme=="" or theme in s().route_completed),"请先开设分店，并完成对应驿路主题（或选择常规菜单）。","Open the branch and complete the route theme, or choose the regular menu.")
	if action=="culture_batch_mode":
		if not str(args.get("mode","")) in ["legacy","individual","same_table"]: return result(false,"请选择有效出餐方案。","Choose a valid service plan.")
		if args.mode=="same_table" and (not active("jiu_ying") or m().full_rules.dollhouse.fixtures("stove").size()<3): return result(false,"同席协调需要九婴当班和3个已安装炉灶。","Coordinated service needs Jiuying on duty and 3 installed stoves.")
		return result(true)
	if action=="culture_night_meal":
		if bool(s().night.get("active",false)): return result(false,"已有夜席正在进行。","A night meal is already in progress.")
		if not "zhulong_ramen" in m().state.unlocked_dishes or not "zhulong_ramen" in m().state.menu_enabled: return result(false,"先研发并上架烛龙拉面。","Research and enable Zhulong noodles first.")
		return result(active("zhu_long") and m().business_open() and int(m().state.world.get("zhulong_day",-1))!=day(),"需要烛龙当班、正在营业且今日未使用神通。","Requires Zhulong on duty, open service and today’s unused skill.")
	if action=="culture_cancel_booking":
		var b: Dictionary=s().booking;var c=m()._customer(int(b.get("customer_id",-1)))
		return result(float(b.get("remaining",0))>0 and not bool(c.get("ingredients_reserved",false)),"已开始烹饪的订单需完成服务；未开始的预约可退款。","An order already being cooked must finish service. An unstarted booking can be refunded.")
	var id=str(args.get("id",""));var e=event(id)
	if e.is_empty(): return result(false,"来信不存在。","This encounter does not exist.")
	if action=="culture_defer": return result(e.status=="offered","当前事件不能延期。","This encounter cannot be deferred now.")
	if action!="culture_choose" or e.status!="offered": return result(false,"这一选择已处理或尚未开放。","This choice is already handled or not yet available.")
	var choice=str(args.get("choice",""));var node=str(e.node)
	if not choice in choices(id,node): return result(false,"请选择当前可用的处理方式。","Choose an option at the current step.")
	if id=="bifang":
		if not _eligible("bifang"): return result(false,"需要毕方当班、已研发烤翅和可用炉灶。","Requires Bifang on duty, researched wings and an installed stove.")
		if not m().full_rules.management.can_make("bifang_wings"): return result(false,"烤翅所需食材不足，请先补货。","Restock the ingredients for the wings first.")
		if choice=="training":
			var employee=m()._employee("bi_fang")
			if float(m().state.cash)<value("bifang_training_cost"): return result(false,"培训资金不足。","Not enough cash for training.")
			if m()._worker_task_count("bi_fang")>0: return result(false,"请等毕方完成当前任务再开始协作培训。","Wait for Bifang’s current task before training.")
	if id=="harvest" and choice=="buy":
		var qty=value("harvest_budget")/m().full_rules.management.stock_price("generic")
		return m().full_rules.management.can_perform("purchase",{"id":"generic","quantity":qty})
	if id=="harvest" and choice=="gift" and float(m().full_rules.management.item("generic").get("value",0))<value("harvest_gift_cost"):
		return result(false,"可赠出的普通食材账面价值不足。","Not enough ordinary inventory value to share.")
	if id=="menu" and choice=="switch" and (not "plum_juice" in m().state.unlocked_dishes or not m().full_rules.management.can_make("plum_juice")):
		return result(false,"需先备好已解锁酸梅汤的真实用料。","Prepare the actual ingredients for the unlocked plum drink first.")
	if id=="menu" and choice=="refund" and float(m().state.cash)<float(s().booking.get("remaining",0)):
		return result(false,"请保留足额现金退回预收款。","Keep enough cash to refund the prepayment.")
	return result(true)

func choices(id: String,node: String) -> Array:
	match id+":"+node:
		"bifang:start": return ["small","training"]
		"menu:start": return ["accept"]
		"menu:check": return ["verify"]
		"menu:decision": return ["switch","refund"]
		"harvest:start": return ["buy","hold"]
		"harvest:bought": return ["gift","reserve"]
		"harvest:held": return ["contact","revisit"]
	return []

func perform(action: String,args: Dictionary={}) -> Dictionary:
	var check=can(action,args)
	if not bool(check.get("ok",false)): return check
	if action=="culture_reduce_fx":s().reduce_fx=bool(args.enabled)
	elif action=="culture_review_menu": s().menu_reviewed=true
	elif action=="culture_read_letter":
		for letter in s().letters:
			if str(letter.id)==str(args.id): letter.read=true
	elif action=="culture_branch_theme": s().branch_themes[str(args.branch_id)]=str(args.theme)
	elif action=="culture_batch_mode": s().batch_mode=str(args.mode)
	elif action=="culture_night_meal":
		check=m().full_rules.world.perform("zhulong_shift",{"period":"night_market"})
		if not bool(check.get("ok",false)): return check
		s().night={"active":true,"completed":false,"progress":0,"started":now(),"until":now()+int(value("night_duration")),"letter_sent":false}
	elif action=="culture_cancel_booking":
		var c=m()._customer(int(s().booking.get("customer_id",-1)))
		if not c.is_empty(): m()._release_customer(c);m().full_rules.dollhouse.begin_exit(c);m().customers.erase(c)
		_refund_booking("cancelled")
	else:
		var id=str(args.id);var e=event(id)
		if action=="culture_defer": e.status="deferred";e.deferred_until=now()+int(value("followup_minutes"))
		else:
			var choice=str(args.choice)
			match id:
				"bifang":
					e.choice=choice;e.status="waiting";e.target=int(value("bifang_"+choice+"_orders"));e.progress=0
					if choice=="training":
						var cost=value("bifang_training_cost")
						m().change_cash(-cost,"training","毕方与伙伴的炉边协作培训")
						m().full_rules.record("expenses",cost,"毕方炉边培训")
						_transaction("bifang:training","training",-cost,0,0,-cost,pair("炉边协作培训","Team training by the grill"))
						e.training_until=now()+int(value("bifang_training_minutes"))
						m()._employee("bi_fang").management_until=e.training_until
						m()._employee("bi_fang").management_job_type="culture_training"
						m().state.management.projects.append({"type":"culture_training","employee_id":"bi_fang","due":int(e.training_until),"attribute":"","role":""})
				"menu":
					if choice=="accept":
						var deposit=value("deposit")
						m().change_cash(deposit,"customer_prepayment","Lin的下一次用餐预收款（尚非收入）")
						s().booking={"id":"lin","status":"held","remaining":deposit,"customer_id":-1,"next_attempt":0}
						_transaction("menu:deposit","prepayment",deposit,0,deposit,0,pair("收到预约预收款，未确认收入","Receive a booking prepayment; no revenue yet"))
						s().evidence.append({"kind":"menu_record","minute":now(),"text":pair("旧菜牌与预收凭据已留存：无面饺子有面皮，预收20尚未履约。","The old menu and deposit receipt are kept: the dumplings have wrappers; the 20 prepayment is not yet earned.")})
						e.node="check"
					elif choice=="verify":
						e.node="decision";s().menu_reviewed=true
						s().evidence.append({"kind":"request_check","minute":now(),"text":pair("已确认Lin为个人饮食计划避小麦，非严重过敏；复合用料与交叉接触仍列未知项。","Lin confirms a personal wheat-avoidance plan, not a severe allergy. Composite ingredients and cross-contact remain marked unknown.")})
					elif choice=="switch": e.choice="served";e.status="waiting";s().booking.status="queued"
					elif choice=="refund": _refund_booking("declined")
				"harvest":
					if choice=="buy":
						var before=float(m().state.cash);var inv=m().full_rules.management.inventory_value()
						var qty=value("harvest_budget")/m().full_rules.management.stock_price("generic")
						var purchase=m().full_rules.management.purchase("generic",qty)
						if not bool(purchase.get("ok",false)): return purchase
						var paid=before-float(m().state.cash)
						m().full_rules.record("procurement",paid,"当康来信采购")
						_transaction("harvest:purchase","procurement",-paid,m().full_rules.management.inventory_value()-inv,0,0,pair("买粮入库，现金转存货","Buy grain: cash becomes inventory"))
						e.node="bought"
					elif choice=="hold": e.node="held"
					else:
						if choice=="gift":
							var item=m().full_rules.management.item("generic");var cost=value("harvest_gift_cost")
							var qty=float(item.quantity)*cost/float(item.value)
							item.quantity=float(item.quantity)-qty;item.value=float(item.value)-cost
							m().full_rules.management._sync_totals();m().full_rules.record("expenses",cost,"当康赠粮")
							_transaction("harvest:gift","gift",0,-cost,0,-cost,pair("按账面成本赠出食材","Share ingredients at carrying cost"))
						e.choice=choice;_followup("harvest")
	m().changed.emit();m().autosave_requested.emit()
	return result(true,"约定已记下。","The agreement has been recorded.")

func snapshot() -> Dictionary:
	ensure_state()
	return s().duplicate(true)

func validate(saved: Dictionary) -> bool:
	if not saved.has("culture_experience"): return not saved.get("management",{}).get("projects",[]).any(func(p): return p.get("type","")=="culture_training") # Older saves acquire empty optional history.
	var c=saved.culture_experience
	if not c is Dictionary or c.get("version")!=1: return false
	for key in ["events","counters","guest_memories","branch_themes","booking","night"]:
		if not c.get(key) is Dictionary: return false
	for key in ["letters","transactions","applied","route_completed","evidence","introduced"]:
		if not c.get(key) is Array: return false
	if not c.get("menu_reviewed") is bool or not str(c.get("batch_mode","")) in ["legacy","individual","same_table"]: return false
	if not c.get("reduce_fx") is bool or not m()._integer(c.get("last_served"),0) or int(c.last_served)>int(saved.get("served",0)):return false
	for key in ["letters","transactions","applied","evidence"]:
		if c[key].size()>int(value("history_limit")):return false
	for key in ["applied","route_completed","introduced"]:
		var unique: Array=[]
		for id in c[key]:
			if not id is String or id in unique:return false
			unique.append(id)
	for id in c.route_completed:
		if definition("regions",id).is_empty():return false
	for id in c.introduced:
		if definition("cast",id).is_empty():return false
	for letter in c.letters:
		if not letter is Dictionary or not letter.get("id") is String or not letter.get("read") is bool:return false
		if not letter.get("title") is Dictionary or not letter.get("body") is Dictionary or not m()._integer(letter.get("minute"),0):return false
		for field in ["title","body"]:
			for lang in ["zh","en"]:
				if not letter[field].get(lang) is String:return false
	for evidence in c.evidence:
		if not evidence is Dictionary or not evidence.get("text") is Dictionary:return false
	for id in c.guest_memories:
		var memory=c.guest_memories[id]
		if definition("guests",str(id)).is_empty() or not memory is Dictionary:return false
		for key in ["visits","orders","last_day"]:
			if not m()._integer(memory.get(key),0):return false
		if not memory.get("promises") is Array or not memory.get("last_dish") is String:return false
	for id in c.branch_themes:
		if not saved.get("expansion",{}).get("branches",{}).has(id):return false
		if c.branch_themes[id]!="" and not c.branch_themes[id] in c.route_completed:return false
	if not c.night.is_empty():
		for key in ["active","completed","letter_sent"]:
			if not c.night.get(key) is bool:return false
		for key in ["progress","started","until"]:
			if not m()._integer(c.night.get(key),0):return false
		if int(c.night.progress)>int(value("night_orders")) or int(c.night.until)<int(c.night.started):return false
		if c.night.active and c.night.completed:return false
		if c.night.completed and not m()._integer(c.night.get("reply_due"),0):return false
	for id in ["bifang","menu","harvest"]:
		var e=c.events.get(id,{})
		if not e is Dictionary or not str(e.get("status","")) in ["unseen","offered","waiting","followup","resolved","deferred"]: return false
		for key in ["progress","target","due","deferred_until","training_until"]:
			if not m()._integer(e.get(key),0): return false
		if not e.get("node") is String or not e.get("choice") is String:return false
	for n in c.counters.values():
		if not m()._integer(n,0): return false
	for tx in c.transactions:
		if not tx is Dictionary: return false
		for key in ["cash","inventory","liabilities","profit"]:
			if not m()._number(tx.get(key)): return false
		if not is_equal_approx(float(tx.cash)+float(tx.inventory)+float(tx.get("receivables",0))-float(tx.liabilities),float(tx.profit)): return false
	if not c.booking.is_empty():
		if not m()._number(c.booking.get("remaining")) or float(c.booking.remaining)<0: return false
		if not str(c.booking.get("status","")) in ["held","queued","arrived","served","refunded"]: return false
		if c.booking.get("id","")!="lin" or not m()._integer(c.booking.get("customer_id"),-1):return false
		if c.booking.status in ["served","refunded"] and not is_zero_approx(float(c.booking.remaining)):return false
		if "booking:settlement" in c.applied and float(c.booking.remaining)>0:return false
	var outstanding=0.0
	var seen: Array=[]
	for tx in c.transactions:
		if not tx.get("id") is String or tx.id in seen:return false
		seen.append(tx.id)
		if tx.has("receivables") and not m()._number(tx.receivables):return false
		outstanding+=float(tx.liabilities)
	# The initial three encounters never exceed the bounded transaction history.
	if c.transactions.size()<int(value("history_limit")) and not is_equal_approx(outstanding,float(c.booking.get("remaining",0))):return false
	for project in saved.get("management",{}).get("projects",[]):
		if project.get("type","")!="culture_training":continue
		if str(project.get("employee_id",""))!="bi_fang":return false
		var e: Dictionary=c.events.bifang
		if e.get("status","")!="waiting" or e.get("choice","")!="training" or int(e.get("training_until",0))!=int(project.get("due",-1)):return false
	return true

func validate_customers(saved: Dictionary,customers: Array) -> bool:
	if not saved.get("culture_experience") is Dictionary:return not customers.any(func(c):return c.has("culture_booking_id"))
	var booking: Dictionary=saved.culture_experience.get("booking",{})
	var tagged=customers.filter(func(c):return c.has("culture_booking_id"))
	if tagged.size()>1:return false
	for customer in tagged:
		if str(customer.culture_booking_id)!="lin" or int(booking.get("customer_id",-1))!=int(customer.id):return false
	if booking.get("status","")=="arrived":return tagged.size()==1 and float(booking.get("remaining",0))>0
	return true
