extends RefCounted
var host
var audio
var _slots: OptionButton
var _file_callback
var _result = ""
var _sliders: Dictionary = {}

func _init(ui): host = ui; audio = ui.audio

func render():
	_sliders.clear()
	if audio == null:
		host.paragraph("音频服务尚未初始化。", host.MUTED); return
	host.paragraph("声音设置", host.GREEN)
	for channel in ["master", "music", "sfx", "ambience"]:
		var key = str(channel)
		var line = host.row(); host.modal_body.add_child(line)
		var names = {"master":"总音量", "music":"背景音乐", "sfx":"音效", "ambience":"环境声"}
		var title = host.label(names[key], 15); title.custom_minimum_size.x = 90; line.add_child(title)
		var slider = HSlider.new(); slider.min_value = 0; slider.max_value = 100; slider.step = 1
		slider.value = float(audio.levels[key])*100; slider.custom_minimum_size = Vector2(120,44)
		slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL; slider.set_meta("qa_id","audio:volume:"+key); line.add_child(slider)
		_sliders[key] = slider
		var number = host.label("%d%%" % int(slider.value), 14); number.custom_minimum_size.x = 52; line.add_child(number)
		slider.value_changed.connect(func(value): audio.set_level(key,value/100.0); number.text = "%d%%" % int(value))
	var mute = CheckButton.new(); mute.text = "静音"; mute.button_pressed = audio.muted
	for state in ["font_color","font_hover_color","font_pressed_color","font_focus_color"]: mute.add_theme_color_override(state,host.INK)
	mute.custom_minimum_size.y = 44; mute.set_meta("qa_id","audio:mute"); host.modal_body.add_child(mute)
	mute.toggled.connect(func(value): audio.unlock(); audio.set_muted(value))
	host._qa_buttons.append(mute)
	host.paragraph("音量设置自动保存，重新开局也会保留。尚未导入的声音会静默跳过。", host.MUTED)
	host.paragraph("已内置操作、经营动作和事件音效，以及食肆与夜间环境声。背景音乐可另行导入。", host.MUTED)
	host.paragraph("音频素材：导入与试听", host.GREEN)
	_slots = OptionButton.new(); _slots.size_flags_horizontal = Control.SIZE_EXPAND_FILL; _slots.custom_minimum_size.y = 44
	_slots.set_meta("qa_id","audio:slot")
	var available = 0
	for cue in audio.config.get("cues",{}):
		var item: Dictionary = audio.config.cues[cue]; var exists = not audio.resource_paths(cue).is_empty()
		if exists: available += 1
		_slots.add_item(("已就绪 · " if exists else "待导入 · ") + str(item.label))
		_slots.set_item_metadata(_slots.item_count-1,cue)
	host.modal_body.add_child(_slots)
	host._qa_buttons.append(_slots)
	host.paragraph("已就绪 %d / %d" % [available,_slots.item_count], host.MUTED)
	var controls = host.row(); host.modal_body.add_child(controls)
	controls.add_child(host.button("导入音频", select_file, true, "audio:import"))
	controls.add_child(host.button("试听所选", func():
		if not audio.preview(_selected()): host.show_notice("此声音尚未导入，或文件无法读取。"), false,"audio:preview"))
	controls.add_child(host.button("停止试听", func(): audio.stop_preview(), false,"audio:stop"))
	host.modal_body.add_child(host.button("重新加载音频目录", func(): audio.reload(); host.open_panel("声音设置",false), false,"audio:reload"))
	if not _result.is_empty(): host.paragraph(_result, host.GREEN)
	host.paragraph("支持OGG、MP3、WAV，单文件最多64MB。导入后会替换所选声音。网页版保存在当前浏览器，保存后请稍候再刷新。",host.MUTED)
	host.paragraph("音效鸣谢：Kenney Vleugels（kenney.nl）、SFX Kit by Wyzowl，CC0 1.0。",host.MUTED)
	host.paragraph('“Oculus Audio Pack 01” by Oculus VR, LLC\nhttps://developers.meta.com/vr/downloads/package/oculus-audio-pack-1/\nCC BY 4.0 · https://creativecommons.org/licenses/by/4.0/\n源文件曾重命名并转为OGG；本作进一步裁剪、调整音量、淡化端点、处理循环并转换格式。',host.MUTED)
	if bool(host.model.state.get("developer_mode",false)):
		host.paragraph("外置目录：" + audio.custom_root + "\n内置目录：" + audio.builtin_root + "\n事件映射：config/audio.json；文件清单与规格：docs/audio-pipeline.md",host.MUTED)
	if not audio.last_errors.is_empty(): host.paragraph("；".join(audio.last_errors),Color("aa7659"))

func _selected() -> String:
	return str(_slots.get_item_metadata(_slots.selected)) if is_instance_valid(_slots) and _slots.selected >= 0 else ""

func snapshot() -> Dictionary:
	var result = {"selected":_selected(),"sliders":{},"ready":[],"result":_result}
	for key in _sliders:
		var node = _sliders[key]
		if not is_instance_valid(node) or not node.is_visible_in_tree(): continue
		var rect: Rect2 = node.get_global_rect()
		result.sliders[key] = {"x":rect.position.x,"y":rect.position.y,"w":rect.size.x,"h":rect.size.y,"value":node.value}
	for cue in audio.config.get("cues",{}):
		if not audio.resource_paths(cue).is_empty(): result.ready.append(cue)
	return result

func select_file():
	var cue = _selected()
	if cue.is_empty(): return
	if OS.has_feature("web"):
		_file_callback = JavaScriptBridge.create_callback(func(arguments):
			if arguments.size() >= 2: import_file(cue,Marshalls.base64_to_raw(str(arguments[0])),str(arguments[1])))
		JavaScriptBridge.get_interface("window").shanhaiAudioImportCallback = _file_callback
		JavaScriptBridge.eval("""(()=>{const e=document.createElement('input');e.type='file';e.accept='.ogg,.mp3,.wav';e.onchange=()=>{const f=e.files[0];if(!f)return;if(f.size>64*1024*1024){alert(__SIZE_WARNING__);return;}const r=new FileReader();r.onload=()=>window.shanhaiAudioImportCallback(String(r.result).split(',')[1],f.name.split('.').pop().toLowerCase());r.readAsDataURL(f);};e.click();})()""".replace("__SIZE_WARNING__",JSON.stringify(host.localization.translate("单个音频不能超过64MB"))),true)
	else:
		var dialog = FileDialog.new(); dialog.access = FileDialog.ACCESS_FILESYSTEM
		dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE; dialog.filters = PackedStringArray(["*.ogg,*.mp3,*.wav ; "+host.localization.translate("音频文件")]); dialog.title=host.localization.translate("选择音频")
		host.add_child(dialog)
		dialog.file_selected.connect(func(path):
			var file = FileAccess.open(path,FileAccess.READ)
			if file == null or file.get_length() > audio.MAX_BYTES: host.show_notice("文件无法读取或超过64MB。")
			else: import_file(cue,file.get_buffer(file.get_length()),path.get_extension())
			dialog.queue_free())
		dialog.canceled.connect(dialog.queue_free); dialog.popup_centered_ratio(.75)

func import_file(cue: String, bytes: PackedByteArray, extension: String):
	var result: Dictionary = audio.import_bytes(cue,bytes,extension)
	_result = "已导入：" + str(result.path) if bool(result.get("ok",false)) else "导入失败：" + str(result.get("error","未知错误"))
	host.show_notice(_result)
	if host.panel_name == "声音设置": host.open_panel("声音设置",false)
