#!/usr/bin/env python3
"""Exercise offline reconstruction, old-site migration and interrupted-copy recovery."""
import importlib.util
import json
import shutil
import zipfile
import argparse
from pathlib import Path
from package_release import BUILD,sha256,write_json

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['international','visual'],default='international');args=parser.parse_args();profile=args.profile
    out=BUILD/(profile+'-r1');base=BUILD/(profile+'-package-check')
    if base.exists():shutil.rmtree(base)
    base.mkdir();package=base/'package'
    with zipfile.ZipFile(BUILD/('shanhai-'+profile+'-r1-complete-game.zip'))as z:
        assert z.testzip()is None;z.extractall(package)
    spec=importlib.util.spec_from_file_location('prepare',package/'prepare-site.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    checks=[]
    def check(value,label):
        assert value,label
        checks.append({'ok':True,'label':label});print(label,flush=True)
    def tree(root):return {p.relative_to(root).as_posix():sha256(p)for p in root.rglob('*')if p.is_file()}
    check(not list(package.glob('site/game/parts/*.raw.*.bin')),'ZIP bundles compressed resources without duplicate raw payloads')
    site,meta=module.materialize(package)
    check(tree(site)==tree(BUILD/(profile+'-release')),'Offline reconstruction exactly matches the fully tested standalone site')
    combined=base/'combined';shutil.copytree(BUILD/('international-site'if profile=='visual'else'ui-r1-site'),combined)
    report=module.apply(package,combined,base/'backup-combined')
    check(report['layout']=='combined','Existing supported desktop/mobile combined site is recognised')
    for prefix in['','portrait/']:
        check(tree(combined/prefix/'game')==tree(BUILD/(profile+'-site')/prefix/'game'),prefix+'all game files and routing receipts match the new combined export')
    report=module.apply(package,combined,base/'backup-repeat')
    check(report['all_resource_parts_verified'],'Applying the update again preserves a valid playable site')
    if profile=='visual':
        legacy=base/'legacy-ui';shutil.copytree(BUILD/'ui-r1-site',legacy);report=module.apply(package,legacy,base/'backup-legacy-ui')
        check(report['layout']=='combined'and tree(legacy/'game')==tree(BUILD/'visual-site/game')and tree(legacy/'portrait/game')==tree(BUILD/'visual-site/portrait/game'),'The older UI-R1 combined site also migrates to both current game views')
    custom=base/'custom';shutil.copytree(BUILD/'portrait-site',custom)
    custom_home=b'<!doctype html><title>Custom WorkBuddy introduction</title><a href="game/">Play</a>'
    (custom/'index.html').write_bytes(custom_home)
    report=module.apply(package,custom,base/'backup-custom')
    check(report['layout']=='standalone'and(custom/'index.html').read_bytes()==custom_home,'Standalone migration preserves a custom WorkBuddy introduction')
    module.verify_game(custom/'game')
    before=tree(custom);real=module._atomic;counter=[0]
    def interrupted(src,dest):
        counter[0]+=1
        if counter[0]==4:raise OSError('Simulated one-time interrupted copy')
        return real(src,dest)
    module._atomic=interrupted
    try:module.apply(package,custom,base/'backup-interruption')
    except OSError:pass
    else:raise AssertionError('Copy failure was not injected')
    finally:module._atomic=real
    check(tree(custom)==before,'Interrupted update restores every original file and removes every newly written file')
    receipt=custom/'game/export-receipt.json';value=json.loads(receipt.read_text());value['game_source']['sha256']='unrecognised';receipt.write_text(json.dumps(value));before=tree(custom)
    try:module.apply(package,custom,base/'backup-rejected')
    except ValueError:pass
    else:raise AssertionError('Unknown build was accepted')
    check(tree(custom)==before and not(base/'backup-rejected').exists(),'Unknown builds are refused before overwriting or creating a backup')
    write_json(out/'package-verification.json',{'game_source':meta['game_source'],'checks':checks,'network_required':False,'errors':[]})

if __name__=='__main__':main()
