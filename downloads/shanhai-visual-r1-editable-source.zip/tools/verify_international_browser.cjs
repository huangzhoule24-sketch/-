/* Actual touch gameplay only: no fixture grants, time jumps, save injection or QA mutations. */
const{chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8065').replace(/\/$/,''),out=process.argv[2]||'build/international-r1/browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const checks=[],actions=[],errors=[],regions=[];const ua='Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36';let receipt;
 function check(ok,label){checks.push({ok:!!ok,label});if(!ok)throw Error(label)}
 for(const rid of(process.env.SHANHAI_REGIONS||'india,nordic,greece').split(',')){
  const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,userAgent:ua,deviceScaleFactor:2,locale:'zh-CN'}),page=await context.newPage(),cdp=await context.newCDPSession(page);
  page.on('pageerror',e=>errors.push(rid+': '+e.message));page.on('console',m=>{if(/SCRIPT ERROR|Parse Error|ERROR:/.test(m.text()))errors.push(rid+': '+m.text())});
  const state=()=>page.evaluate(()=>window.shanhaiQAState);const sync=()=>page.waitForTimeout(550);
  async function point(r){return page.evaluate(r=>{const b=document.querySelector('canvas').getBoundingClientRect(),s=window.shanhaiQAState;return{x:b.x+(r.x+r.w/2)*b.width/s.viewport.w,y:b.y+(r.y+r.h/2)*b.height/s.viewport.h}},r)}
  async function swipe(reverse=false){
   const s=await state(),r=s.responsive.scroll;let top=r.y+12,bottom=r.y+r.h-12;const m=s.international_view?.scene_rect;
   if(s.panel==='跨国食肆'&&m?.h>0&&m.y<bottom&&m.y+m.h>top){const above=Math.max(0,m.y-top-6),below=Math.max(0,bottom-m.y-m.h-6);if(above>=below)bottom=Math.min(bottom,m.y-8);else top=Math.max(top,m.y+m.h+8)}
   if(bottom-top<35){top=r.y+6;bottom=r.y+r.h-6}
   const a=await point({x:r.x+r.w*.5,y:reverse?top:bottom,w:0,h:0}),b=await point({x:r.x+r.w*.5,y:reverse?bottom:top,w:0,h:0});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...a,id:0}]});for(let i=1;i<=7;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:a.x+(b.x-a.x)*i/7,y:a.y+(b.y-a.y)*i/7,id:0}]});await page.waitForTimeout(25)}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sync();
  }
  async function tap(id){let b;for(let i=0;i<28;i++){const s=await state();b=s?.buttons.find(x=>x.qa_id===id&&!x.disabled);if(b)break;await swipe(i<4)}if(!b)throw Error(rid+': Missing enabled control '+id);const p=await point(b.rect);await page.touchscreen.tap(p.x,p.y);await sync();actions.push(rid+':'+id);fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({region:rid,last:id,checks:checks.length,panel:(await state()).panel}));}
  async function shot(name){await page.screenshot({path:path.join(out,rid+'-'+name+'.png')});const s=await state();fs.writeFileSync(path.join(out,rid+'-'+name+'-view.json'),JSON.stringify({panel:s.panel,view:s.international_view,scroll:s.culture_navigation?.scroll_vertical,responsive:s.responsive,browser:await page.evaluate(()=>({scrollY,innerHeight,visualHeight:visualViewport?.height,canvas:document.querySelector('canvas').getBoundingClientRect().toJSON()}))},null,2))}
  try{
   receipt=await(await page.request.get(root+'/game/export-receipt.json')).json();await page.goto(root+'/game/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});await sync();
   await tap('start:full');if(!(await state()).paused)await tap('time:pause');await tap('tutorial:ack');await tap('nav:员工');await tap('panel:close');await tap('tutorial:ack');await tap('tutorial:destination');await tap('full:marketing:flyer');await tap('tutorial:ack');if((await state()).panel)await tap('panel:close');if((await state()).paused)await tap('time:pause');
   await page.waitForFunction(()=>shanhaiQAState.state.served>=1,null,{timeout:120000});for(const id of['first_order','income']){if(!(await state()).state.tutorial.completed_steps.includes(id)){if(id==='first_order')await page.waitForFunction(id=>shanhaiQAState.state.tutorial.ready_to_ack.includes(id),id,{timeout:20000});await tap('tutorial:ack')}}
   if(!(await state()).state.tutorial.completed_steps.includes('bill')){await tap('tutorial:destination');await tap('tutorial:ack')}if((await state()).panel)await tap('panel:close');if(!(await state()).paused)await tap('time:pause');check((await state()).state.tutorial.finished,rid+' completes actual opening guidance');
   await tap('nav:更多');await tap('full:open:跨国食肆');await tap('int:region:'+rid);await shot('01-invitation');let s=await state();check(s.panel==='跨国食肆'&&s.international_view.region===rid,rid+' opens from the existing More/branch navigation');check(s.international.regions[rid].open===false,rid+' begins with an unopened formal cooperation');
   await tap('int:scene:toggle');await shot('02-storefront');check(!(await state()).international_view.scene_inside,rid+' has a distinct full storefront');await tap('int:scene:toggle');
   await tap('int:int_open:');s=await state();check(s.international.regions[rid].open,rid+' actual opening action succeeds');check(s.culture_navigation.scroll_vertical===0,rid+' opening restores the top navigation and scene instead of keeping the invitation offset');await shot('03-open-room');
   if(process.env.SHANHAI_VISUAL_ONLY==='1'){await page.waitForTimeout(3000);await shot('03b-settled-room');regions.push({region:rid,visual_only:true});await context.close();continue}
   const scene=s.international_view.scene_rect,p=await point({x:scene.x+scene.w*.5,y:scene.y+scene.h*.5,w:0,h:0});await page.touchscreen.tap(p.x,p.y);await tap('int:scene:+');check((await state()).international_view.zoom>1,rid+' scene zoom changes without shrinking the whole UI');await tap('int:scene:fit');check((await state()).international_view.zoom===1,rid+' scene has a recoverable fit action');
   const view=(await state()).international_view,centre=await point({x:view.scene_rect.x+view.scene_rect.w*.5,y:view.scene_rect.y+view.scene_rect.h*.5,w:0,h:0});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...centre,id:0}]});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:centre.x+35,y:centre.y+24,id:0}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sync();
   check(Math.abs((await state()).international_view.pan_x)>1&&(await state()).international_view.touches===0,rid+' map drag owns its gesture and releases cleanly');await tap('int:scene:fit');
   if(process.env.SHANHAI_VISUAL_CHECKS==='1'){
    const v=(await state()).international_view,mid=await point({x:v.scene_rect.x+v.scene_rect.w*.5,y:v.scene_rect.y+v.scene_rect.h*.5,w:0,h:0});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:mid.x-25,y:mid.y,id:0},{x:mid.x+25,y:mid.y,id:1}]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:mid.x-45,y:mid.y,id:0},{x:mid.x+45,y:mid.y,id:1}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sync();
    check((await state()).international_view.zoom>1.5&&(await state()).international_view.touches===0,'Two actual fingers zoom the map and release both contacts');await shot('03c-pinch-zoom');await tap('int:scene:fit');
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...mid,id:0}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:8,y:96,id:0}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sync();
    check((await state()).international_view.touches===0&&Math.abs((await state()).international_view.pan_y)>30,'Dragging beyond the map keeps ownership until the outside release');await tap('int:scene:fit');
    await tap('int:time:pause');await page.waitForTimeout(850);await tap('int:time:pause');await sync();const frozen=(await state()).international_view;await page.waitForTimeout(1000);const held=(await state()).international_view;
    check(frozen.clock===held.clock&&JSON.stringify(frozen.pose)===JSON.stringify(held.pose),'Manual pause freezes the actual fractional pose and walking frame');
    check(held.renders-frozen.renders<=1,'A paused scene avoids continuous decorative redraws');
   }
   await tap('int:tab:来信');const choice={india:'limited',nordic:'reserve',greece:'separate'}[rid];await tap('int:int_story:'+choice);check((await state()).international.regions[rid].story.choice===choice,rid+' chosen reception policy is persistent');
   await tap('int:tab:菜单');await shot('04-local-menu');const first={india:'in_d01',nordic:'nd_d01',greece:'gr_d01'}[rid];const revenue=(await state()).state.total_revenue;await tap('int:int_prepare:'+first+':q3');check((await state()).state.total_revenue===revenue,rid+' buying preparation does not fabricate sales');
   await tap('int:int_auto:'+first);check((await state()).international.regions[rid].auto_recipe===first,rid+' recurring purchases are explicitly enabled');
   await tap('int:tab:店铺');await tap('int:time:2');if((await state()).paused)await tap('int:time:pause');
   await page.waitForFunction(rid=>shanhaiQAState.international.regions[rid].served>=3,rid,{timeout:120000});
   s=await state();check(s.international.regions[rid].served>=3&&s.state.total_revenue>revenue,rid+' three actual handovers produce shared campaign revenue');check(s.international.regions[rid].story.status==='resolved'&&s.international.letters.some(x=>x.region===rid),rid+' a letter follows fulfilled real orders');await shot('05-real-service');
   if(!(await state()).paused)await tap('int:time:pause');const music=(await state()).audio.music_starts;await tap('int:tab:伙伴');await shot('06-partners');await tap('culture:employees:'+{india:'in_01',nordic:'nd_01',greece:'gr_01'}[rid]);s=await state();check(s.culture_entry.image_available&&s.culture_entry.image_style==='pixel',rid+' cultural entry shows the new pixel figure');await shot('07-culture-zh');await tap('culture:language:en');check((await state()).culture_entry.language==='en',rid+' cultural reading has a complete English version');await shot('08-culture-en');await tap('culture:back');check((await state()).panel==='跨国食肆',rid+' culture Back restores the international parent');await tap('int:tab:来信');await shot('09-reply');check((await state()).audio.music_starts===music,rid+' management and reading do not restart music');
   await tap('panel:restaurant');check(!(await state()).panel,rid+' fixed return restores the normal restaurant');await tap('nav:更多');await tap('full:open:系统');
   if(process.env.SHANHAI_VISUAL_CHECKS==='1'){const cash=(await state()).state.cash;await tap('system:visual:reduced');check((await state()).state.culture_experience.reduce_fx&&(await state()).state.cash===cash,'System reduced-effects switch changes the visual preference without spending cash');await shot('10-reduced-effects')}
   await tap('system:save');await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});check((await state()).international.regions[rid].served>=3,rid+' real browser reload retains international progress');
   if(process.env.SHANHAI_VISUAL_CHECKS==='1')check((await state()).state.culture_experience.reduce_fx,'Reduced-effects preference also survives the browser reload');
   regions.push({region:rid,served:(await state()).international.regions[rid].served});
  }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,rid+'-failure-state.json'),JSON.stringify((await state())||null,null,2));}
  await context.close();if(errors.length)break;
 }
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt?.game_source,checks,actions,regions,errors,emulation:'Chromium Android touch, DPR2; no physical device claim'},null,2));console.log(JSON.stringify({checks,actions:actions.length,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
