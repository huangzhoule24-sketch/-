#!/usr/bin/env python3
"""Publish only the validated site and a separate, history-free download snapshot."""
import json,argparse
import urllib.request
import zipfile
from package_release import BUILD,ROOT,game_source_fingerprint,sha256,write_json
import publish_web_site as publisher

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['international','visual'],default='international');args=parser.parse_args();profile=args.profile
    output=BUILD/(profile+'-r1');site=BUILD/(profile+'-site');publisher.REVISION=profile+'-r1'
    build=json.loads((output/'site-build.json').read_text());expected=build['game_source'];assert expected==game_source_fingerprint()
    for name in[('browser'if profile=='visual'else'browser-final'),'music-browser','portrait-browser','device-browser','share-browser','site-browser']:
        report=json.loads((output/name/'report.json').read_text())
        assert not report['errors']and report['checks']and all(x['ok']for x in report['checks']),name
        if 'game_source'in report:assert report['game_source']==expected,name+' used an earlier export'
    assert len(json.loads((output/('browser'if profile=='visual'else'browser-final')/'report.json').read_text())['regions'])==(1 if profile=='visual'else 3)
    for name in['http-desktop.json','http-mobile.json']:
        report=json.loads((output/name).read_text());assert report['game_source']==expected and report['gzip_sha_and_roundtrip_verified']
    report=json.loads((output/'package-verification.json').read_text());assert report['game_source']==expected and not report['errors']and all(x['ok']for x in report['checks'])
    report=json.loads((output/'source-verification.json').read_text());assert report['game_source']==expected and report['source_fingerprint_after_import_matches']and not report['failures']
    for prefix in['','portrait/']:
        manifest=json.loads((site/prefix/'site-receipt.json').read_text());assert manifest['game_source']==expected
        for name,e in manifest['files'].items():
            p=site/prefix/name;assert p.stat().st_size==e['bytes']and sha256(p)==e['sha256'],prefix+name
    artifacts=[json.loads((output/name).read_text())['artifact']for name in['package-build.json','source-package.json']]
    for artifact in artifacts:
        p=BUILD/artifact['file'];assert sha256(p)==artifact['sha256']and p.stat().st_size==artifact['bytes']
        with zipfile.ZipFile(p)as z:assert z.testzip()is None
    title='Refine mythic character art, restaurant materials, scene anchors and mobile gesture recovery'if profile=='visual'else'Add India, Nordic and Greek cooperating eateries, local partners, food, art and cultural reading'
    website=publisher.publish('gh-pages',{p.relative_to(site).as_posix():p for p in site.rglob('*')if p.is_file()},title,build['parent'])
    changed=publisher.git(['diff-tree','-z','--no-commit-id','--name-only','-r',build['parent'],website],raw=True).decode().rstrip('\0').split('\0')
    assert sorted(changed)==sorted(set(build['changes'])|set(build['removed']))
    print(json.dumps({'website_commit':website}),flush=True)
    entries={'downloads/'+a['file']:BUILD/a['file']for a in artifacts}
    entries['downloads/SHA256SUMS.txt']=''.join(a['sha256']+'  '+a['file']+'\n'for a in artifacts).encode()
    entries['instructions/workbuddy-update.txt']=BUILD/(profile+'-game-package')/'给WorkBuddy的更新指令.txt'
    documents=['visual-release-r1.md','visual-art-process-r1.md','visual-art-provenance.json','visual-validation-r1.md']if profile=='visual'else['international-release-r1.md','international-art-process.md','international-art-manifest.json','international-validation-r1.md']
    for name in documents:entries['docs/'+name]=ROOT/'docs'/name
    if profile=='visual':
        for name in['main-desktop','culture-bi_fang','culture-di_jiang','culture-xian_yang']:entries['native-layout-fixtures/'+name+'.png']=output/(name+'.png')
        entries['preview/pinch-map.png']=output/'browser/india-03c-pinch-zoom.png'
    else:
        for rid in['india','nordic','greece']:
            p=output/'browser-final'/(rid+'-07-culture-zh.png');entries['preview/'+p.name]=p
            entries['art/'+rid+'-store.png']=ROOT/'assets/art/International'/(rid+'_store.png')
        entries['preview/greece-browser-room.png']=output/'browser-final/greece-03-open-room.png'
    commit=publisher.publish('visual-r1-20261107'if profile=='visual'else'international-r1-20261106',entries,'Provide complete game and editable source without private development history')
    downloads=[]
    for artifact in artifacts:
        url='https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/downloads/'+artifact['file'];target=output/('public-'+artifact['file'])
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shanhai-release-integrity-verifier'}),timeout=120)as r:
            status=r.status;length=int(r.headers.get('Content-Length','0'))
            with target.open('wb')as f:
                while block:=r.read(1048576):f.write(block)
        assert status==200 and length==artifact['bytes']==target.stat().st_size and sha256(target)==artifact['sha256']
        with zipfile.ZipFile(target)as z:assert z.testzip()is None
        start=1048576;size=64
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes={start}-{start+size-1}'}),timeout=45)as r:partial=r.read();rs=r.status;cr=r.headers.get('Content-Range')
        with(BUILD/artifact['file']).open('rb')as f:f.seek(start);part=f.read(size)
        assert rs==206 and partial==part and cr==f'bytes {start}-{start+size-1}/{length}'
        downloads.append({**artifact,'direct_url':url,'http_status':status,'content_length':length,'sha256_verified':True,'zip_crc_valid':True,'range_status':rs,'range_verified':True})
    proof={'version':build['version'],'game_source':expected,'static_site':{'commit':website,'parent':build['parent'],'both_views_current':True,'pages_url':'https://huangzhoule24-sketch.github.io/-/','live_http_verified':False},'commit':commit,'downloads':downloads,'workbuddy_project_deployed_by_assistant':False,'workbuddy_instructions_url':'https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/instructions/workbuddy-update.txt'}
    write_json(output/'publication.json',proof);print(json.dumps(proof,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
