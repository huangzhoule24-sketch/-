#!/usr/bin/env python3
"""A complete compact site kit; inflate raw fallback parts locally, no downloads."""
import json,argparse
import shutil
from pathlib import Path
from package_release import ROOT,BUILD,sha256,write_json,write_zip,game_source_fingerprint
from publish_web_site import git

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['international','visual'],default='international');args=parser.parse_args();profile=args.profile
    fresh=BUILD/(profile+'-release');combined=BUILD/(profile+'-site');out=BUILD/(profile+'-r1');package=BUILD/(profile+'-game-package')
    build=json.loads((out/'site-build.json').read_text());assert build['game_source']==game_source_fingerprint()
    if package.exists():shutil.rmtree(package)
    shutil.copytree(fresh,package/'site',ignore=shutil.ignore_patterns('*.raw.*.bin'))
    routing=package/'routing';routing.mkdir()
    for variant,prefix in[('desktop',''),('mobile','portrait/')]:shutil.copyfile(combined/prefix/'game/index.html',routing/(variant+'-game.html'))
    updates={}
    names=['index.html','share.html','preview-access.js','share.js','site.js','site.css','device-router.js','device-entry.css']
    for prefix in['','portrait/']:
        for name in names:
            target_name=prefix+name;actual=combined/target_name
            if not actual.is_file():continue
            target=package/'routing/entry'/target_name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(actual,target)
            known=[sha256(actual)]
            for baseline in[build['parent'],'0a8326367ce212fd53f0f8527152eaa009252738','171dc41f719b4bd83abfdc589bb017f4d3c9c9a9','7a01f224562072d554dce448ad04f2536e99f301']:
                try:
                    import hashlib
                    known.append(hashlib.sha256(git(['show',baseline+':'+target_name],raw=True)).hexdigest())
                except RuntimeError:pass
            updates[target_name]={'source':target.relative_to(package).as_posix(),'known_hashes':sorted(set(known))}
    shutil.copyfile(ROOT/'tools/prepare_international_site.py',package/'prepare-site.py')
    text='''请在原WorkBuddy项目更新跨国食肆新版，保留原应用、域名和玩家存档。
解压资源包后，先在包目录运行python prepare-site.py，生成完整site静态网站；包内已包含全部压缩游戏资源，不需要联网下载引擎或数据。
若原项目已有game/export-receipt.json或portrait/game/export-receipt.json，请运行python prepare-site.py --site-root <实际网站根目录>；脚本会识别独立站/电脑手机组合站，核对旧版，自动备份到网站之外，再更新游戏和资源，保留自定义介绍页。失败会恢复覆盖文件。
若这是新建空项目，准备完成后仅将site目录内部作为静态发布内容；不要把压缩包根目录或routing目录当成网站。
请在预览中完成白泽开局，打开更多→跨国食肆，检查印度/北欧/希腊的店内店外、菜单、伙伴、文化阅读、采购备料、自动交付、回信、返回、暂停、手机缩放和保存刷新。
验证后重新部署当前应用到原链接，不新建应用、不换域名、不清除浏览器网站数据。请返还原网址和SH-WEB-INTERNATIONAL-R1版本检查结果，区分真机与模拟。
'''
    if profile=='visual':text=text.replace('跨国食肆新版','美术与技术完善版').replace('SH-WEB-INTERNATIONAL-R1','SH-WEB-VISUAL-R1')+'\n请另检查三位代表角色的新立绘与像素简介、主店工作台、地图双指缩放/框外松手、应用失焦恢复、暂停动作与系统减弱场景特效。\n'
    (package/'给WorkBuddy的更新指令.txt').write_text(text,encoding='utf-8-sig')
    readme='''跨国合作食肆 · SH-WEB-INTERNATIONAL-R1

这是完整网页游戏资源包。全部引擎、人物、场景、音乐与数据均在包内；为减少下载体积，原始兼容分片通过已包含的gzip分片离线恢复。
Windows本地试玩：从本包根目录双击Start-Web.cmd（需要Python3），它会先准备site，再启动本地HTTP服务器。
其他系统：python prepare-site.py --launch。
部署到静态平台：先python prepare-site.py，然后上传site内部的完整内容。学生电脑/手机只需浏览器，不需要Python。
更新原WorkBuddy：上传本包，发送“给WorkBuddy的更新指令.txt”。不要直接把包根目录部署为网站，不要清除浏览器存档。
游戏入口：完成原六步开局后，更多→跨国食肆；图鉴新增跨国伙伴和当地菜品。先采购备料，按需开启循环；各店自动核对交付，真实收款后推进合作与回信。
正式经营、中文英文、手机竖屏/缩放/返回、原主店和音乐保留。此包不是全解锁自由版，也不是Godot可编辑源码包。
'''
    if profile=='visual':readme=(ROOT/'docs/visual-release-r1.md').read_text()
    (package/'请先阅读.txt').write_text(readme,encoding='utf-8-sig')
    cmd='''@echo off
cd /d "%~dp0"
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 prepare-site.py --launch
  goto done
)
python --version >nul 2>&1
if not errorlevel 1 (
  python prepare-site.py --launch
  goto done
)
echo Python 3 is required for this local web server.
:done
pause
'''
    (package/'Start-Web.cmd').write_bytes(cmd.replace('\n','\r\n').encode('ascii'))
    accepted=['71aa6dee3ece74281d41ddac608940233ea2cc1f0ce6bf945ee58e70a842be9a','68d3a7d44d51ea4c4772022609910db61be34d8d200d3918bde82d58269b643c','e5333a5044cde2936c34aad86d0ea0f6e531efb7081b31a51e8ba819519fe737','399b07311ed6a85e0206384a32d8940b90b5bb9a151e1ac130a9f5e6f4b0b4ce',build['game_source']['sha256']]
    if profile=='visual':accepted.append('84578ee905df80a6677bfb1362e737ec957f518e07a592b39f9e86acd73cf29f')
    files={p.relative_to(package).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p)}for p in package.rglob('*')if p.is_file()}
    write_json(package/'PACKAGE.json',{'version':build['version'],'revision':build['revision'],'game_source':build['game_source'],'accepted_sources':accepted,'entry_updates':updates,'files':files,'complete_resources_bundled':True,'raw_parts_restored_without_network':True})
    artifact=write_zip(BUILD/('shanhai-'+profile+'-r1-complete-game.zip'),[(p,p.relative_to(package).as_posix())for p in sorted(package.rglob('*'))if p.is_file()])
    assert artifact['bytes']<100*1024*1024
    write_json(out/'package-build.json',{'game_source':build['game_source'],'artifact':artifact,'raw_fallback_reconstruction':True,'source_and_local_cache_unchanged':True});print(json.dumps(artifact,indent=2))

if __name__=='__main__':main()
