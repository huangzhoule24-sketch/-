extends Control
## A presentation-only scene: stable feet, depth order and captured map gestures.
const Art=preload("res://scripts/services/international_art.gd")
const Visual=preload("res://scripts/services/visual_refinement.gd")
var ui
var rid="india"
var inside=true
var preview=""
var camera: Dictionary={"zoom":1.0,"pan":Vector2.ZERO}
var touches={}
var dragging=false
var touch_used=false
var _elapsed=0.0
var _last_view=""
var _render_count=0
func setup(owner_ui,region_id: String,interior=true):
 ui=owner_ui;rid=region_id;inside=interior;camera=ui.cameras.get(rid,{"zoom":1.0,"pan":Vector2.ZERO});ui.cameras[rid]=camera
 custom_minimum_size=Vector2(0,310);size_flags_horizontal=Control.SIZE_EXPAND_FILL;clip_contents=true;mouse_filter=Control.MOUSE_FILTER_STOP;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
func fit():camera.zoom=1.0;camera.pan=Vector2.ZERO;cancel_gesture();queue_redraw()
func cancel_gesture():touches.clear();dragging=false
func _notification(what):
 if what in[NOTIFICATION_APPLICATION_FOCUS_OUT,NOTIFICATION_EXIT_TREE,NOTIFICATION_RESIZED]:cancel_gesture()
 if what==NOTIFICATION_VISIBILITY_CHANGED and not is_visible_in_tree():cancel_gesture()
func clock() -> float:return float(ui.rules().now())+float(ui.host.model._fraction)
func _process(delta):
 if ui==null:return
 _elapsed+=delta
 var signature=str([camera.zoom,camera.pan,size,ui.host.model.paused,Visual.reduced(ui.host.model)])
 if signature!=_last_view or(not ui.host.model.paused and _elapsed>=(1.0/12 if Visual.reduced(ui.host.model)else 1.0/30)):
  _last_view=signature;_elapsed=0;queue_redraw()
func zoom_at(factor: float,anchor: Vector2):
 var old_extent=maxf(1,minf(size.x,size.y)*float(camera.zoom));var unit=(anchor-size*.5-Vector2(camera.pan))/old_extent
 camera.zoom=clampf(float(camera.zoom)*factor,.65,2.8)
 camera.pan=anchor-size*.5-unit*minf(size.x,size.y)*float(camera.zoom);queue_redraw()
func _touch(event):
 touch_used=true
 if event is InputEventScreenTouch:
  if event.pressed:
   if touches.size()<2:touches[event.index]=event.position
  else:touches.erase(event.index)
 elif event is InputEventScreenDrag and touches.has(event.index):
  if touches.size()==2:
   var old=touches.values();var distance=Vector2(old[0]).distance_to(old[1]);var centre=(Vector2(old[0])+Vector2(old[1]))*.5
   touches[event.index]=event.position;var next=touches.values();var new_centre=(Vector2(next[0])+Vector2(next[1]))*.5
   camera.pan+=new_centre-centre
   if distance>1:zoom_at(Vector2(next[0]).distance_to(next[1])/distance,new_centre)
  else:camera.pan+=event.position-Vector2(touches[event.index]);touches[event.index]=event.position
 queue_redraw()
func _input(event):
 if not is_visible_in_tree():return
 if(event is InputEventScreenDrag or event is InputEventScreenTouch)and touches.has(event.index):
  _touch(event.xformed_by(get_global_transform_with_canvas().affine_inverse()));get_viewport().set_input_as_handled()
 elif event is InputEventMouseMotion and dragging:
  if event.device==-1 and touch_used:return
  camera.pan+=event.relative;queue_redraw();get_viewport().set_input_as_handled()
 elif event is InputEventMouseButton and not event.pressed and event.button_index==MOUSE_BUTTON_LEFT and dragging:
  dragging=false;get_viewport().set_input_as_handled()
func _gui_input(event):
 if event is InputEventScreenTouch or event is InputEventScreenDrag:_touch(event);accept_event()
 elif event is InputEventMouseButton:
  if event.device==-1 and touch_used:return
  if event.button_index in[MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]and event.pressed:zoom_at(1.12 if event.button_index==MOUSE_BUTTON_WHEEL_UP else 1/1.12,event.position);accept_event()
  elif event.button_index==MOUSE_BUTTON_LEFT:dragging=event.pressed;accept_event()
func _point(unit: Vector2,rect: Rect2) -> Vector2:return rect.position+unit*rect.size
static func table_positions(region_id: String,layout: String) -> Array:
 var result=[Vector2(.30,.51),Vector2(.68,.52),Vector2(.31,.73),Vector2(.67,.73)]
 if region_id=="nordic":result=[Vector2(.32,.43),Vector2(.70,.45),Vector2(.32,.66),Vector2(.70,.68)]
 if region_id=="greece":result=[Vector2(.30,.52),Vector2(.68,.53),Vector2(.28,.73),Vector2(.68,.74)]
 if layout=="sharing":result=[Vector2(.30,.53),Vector2(.30,.75)]
 if layout=="storage":result=result.slice(0,3)
 return result
func actor_pose(index: int,minute: float,layout: String) -> Dictionary:
 var phase=fposmod(minute*.055+index*.42,1);var a=Vector2(.51,.34);var b=Vector2(.51,.80)
 if rid=="nordic":a=Vector2(.53,.30);b=Vector2(.53,.78)
 if rid=="greece":a=Vector2(.53,.34);b=Vector2(.53,.80)
 if layout=="sharing":a.x=.58;b.x=.58
 a.x+=(-.038 if index==0 else .038);b.x=a.x
 return {"point":a.lerp(b,phase*2 if phase<.5 else(1-phase)*2),"frame":[0,1,2,1][int(minute*2)%4]+(3 if phase>=.5 else 0)}
func _actor(id: String,frame: int,foot: Vector2,height: float):
 var image=Art.walking(id,frame);var entry=Art.definition("characters",id)
 var geometry=Visual.walking(rid,int(entry.column),frame)
 if image==null:return
 if geometry.is_empty():draw_texture_rect(image,Rect2(foot-Vector2(height/2,height),Vector2.ONE*height),false);return
 var b=geometry.bounds;var source=Rect2(b[0],b[1],b[2]-b[0],b[3]-b[1]);draw_texture_rect_region(image,Visual.sprite_rect(foot,height,geometry),source)
func _draw():
 _render_count+=1
 draw_rect(Rect2(Vector2.ZERO,size),Color("ebe6d6"))
 if ui==null:return
 var background=Art.store(rid,inside)
 if background==null:return
 var extent=minf(size.x,size.y)*float(camera.zoom);var rect=Rect2((size-Vector2.ONE*extent)/2+Vector2(camera.pan),Vector2.ONE*extent)
 draw_texture_rect(background,rect,false)
 if not inside:return
 var rules=ui.rules();var data=rules.region(rid);var layout=preview if not preview.is_empty()else str(data.layout);var tables=table_positions(rid,layout);var minute=clock();var entities=[]
 for index in range(tables.size()):entities.append({"kind":"table","point":tables[index],"serial":index})
 if layout=="storage":entities.append({"kind":"storage","point":Vector2(.68,.74),"serial":30})
 if bool(data.open):
  for index in range(data.partners.size()):
   var pose=actor_pose(index,minute,layout);entities.append({"kind":"actor","point":pose.point,"frame":pose.frame,"id":str(data.partners[index]),"serial":40+index})
  for index in range(mini(3,data.orders.size())):entities.append({"kind":"guest","point":tables[index%tables.size()]+Vector2(0,.065),"index":index,"serial":60+index})
 entities.sort_custom(func(a,b):return a.point.y<b.point.y if not is_equal_approx(a.point.y,b.point.y)else a.serial<b.serial)
 for entity in entities:
  var at=_point(entity.point,rect)
  match entity.kind:
   "table":
    var image=Art.furniture(rid,1 if layout=="sharing"else 0);var dimensions=Vector2(.34 if layout=="sharing"else .22,.18)*extent
    if image!=null:draw_texture_rect(image,Rect2(at-dimensions/2,dimensions),false)
   "storage":
    var image=Art.furniture(rid,3 if rid=="nordic"else 4)
    if image!=null:draw_texture_rect(image,Rect2(at-Vector2(.10,.09)*extent,Vector2(.20,.18)*extent),false)
   "actor":
    draw_ellipse_shadow(at,extent*.025);_actor(entity.id,entity.frame,at,extent*.145)
   "guest":
    var frames=ui.host.assets.get_customer_frames("human","human_%02d"%(int(entity.index)%3+1),"eat"if data.orders[entity.index].status=="serving"else"sit","down")
    if not frames.is_empty():
     var scale=extent*.105/64;draw_texture_rect(frames[int(minute*2)%frames.size()],Rect2(at-Vector2(32,61)*scale,Vector2(64,80)*scale),false)
 for job in data.jobs:
  if job.kind!="service":continue
  var progress=clampf((minute-float(job.started))/maxf(1,float(job.due)-float(job.started)),0,1);var image=Art.dish(str(job.dish_id));var at=_point(Vector2(.70,.31).lerp(Vector2(.52,.67),progress),rect)
  if image!=null:draw_texture_rect(image,Rect2(at-Vector2.ONE*.036*extent,Vector2.ONE*.072*extent),false)
 if not Visual.reduced(ui.host.model):
  for job in data.jobs:
   if job.kind!="prep":continue
   var station=rules.definition("dishes",str(job.dish_id)).station;var origin=_point(Vector2(.75,.27),rect)
   if station in["oven","griddle"]:draw_circle(origin,extent*.035,Color(1,.59,.20,.16))
   for index in range(3):
    var phase=fposmod(minute*.08+index*.34,1);draw_rect(Rect2(origin+Vector2((index-1)*.016,-.02-phase*.075)*extent,Vector2.ONE*.008*extent),Color(.95,.93,.84,.55*(1-phase)))
func draw_ellipse_shadow(at: Vector2,radius: float):
 draw_set_transform(at,0,Vector2(1,.32));draw_circle(Vector2.ZERO,radius,Color(0,0,0,.17));draw_set_transform(Vector2.ZERO)
