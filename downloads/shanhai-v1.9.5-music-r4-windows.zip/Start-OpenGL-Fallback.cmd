@echo off
setlocal
cd /d "%~dp0"
if not exist "shanhai-v1.9.5-music-r4.exe" goto missing
if not exist "shanhai-v1.9.5-music-r4.pck" goto missing
if /i "%PROCESSOR_ARCHITECTURE%"=="x86" if "%PROCESSOR_ARCHITEW6432%"=="" goto arch
if not defined LOCALAPPDATA set "LOCALAPPDATA=%TEMP%"
set "SHANHAI_LOG_DIR=%LOCALAPPDATA%\ShanhaiInn"
if not exist "%SHANHAI_LOG_DIR%" mkdir "%SHANHAI_LOG_DIR%" >nul 2>&1
start "" /d "%~dp0" "%~dp0shanhai-v1.9.5-music-r4.exe" --rendering-method gl_compatibility --rendering-driver opengl3 --max-fps 60 --log-file "%SHANHAI_LOG_DIR%\Start-OpenGL-Fallback.log"
exit /b 0
:missing
echo Please extract the ENTIRE ZIP to a local folder before starting.
echo Keep the EXE and PCK in the same folder. Do not run inside the ZIP.
pause
exit /b 1
:arch
echo This build requires 64-bit Windows 10 or Windows 11.
pause
exit /b 1
