#!/usr/bin/env bash
set -euo pipefail
shanhai_root="$(realpath "$(dirname "${BASH_SOURCE[0]}")/..")"
cd "$shanhai_root"
export XDG_DATA_HOME="${XDG_DATA_HOME:-/workspace/.tools/godot/data}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-/workspace/.tools/godot/config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/workspace/.tools/godot/cache}"
mkdir -p build/check-results "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME"
checks=(run_tests campaign_tests management_tests v13_management_tests expansion_tests event_tests skill_coverage_tests animation_tests asset_tests tutorial_tests ui_smoke save_migration_tests balance_tests navigation_tests story_tests world_completion_tests ui_requirements_tests core_completion_tests customer_preference_tests culture_tests culture_ui_tests v15_customer_tests v15_finance_tests v15_event_tests v15_story_synergy_tests v15_ui_tests v15_integration_tests more_navigation_tests v16_experience_tests v171_rules_tests v171_guest_tests v171_ui_tests v18_rules_tests v18_ui_tests v19_rules_tests v19_ui_tests v191_rules_tests v191_ui_tests v191_stress_tests v193_rules_tests v193_assets_tests v193_ui_tests v195_interaction_tests art_pack_tests seat_layer_tests)
failed=0
for check_name in "${checks[@]}"; do
  test_log="build/check-results/${check_name}.log"
  test_status=0
  # Culture UI visits all 51 readings and restores the full scrolling catalogue.
  suite_timeout=90s
  if [ "$check_name" != culture_ui_tests ] && [ "$check_name" != v15_ui_tests ] && [ "$check_name" != ui_smoke ]; then suite_timeout=45s; fi
  if [ "$check_name" = more_navigation_tests ] || [ "$check_name" = v16_experience_tests ] || [ "$check_name" = v171_ui_tests ]; then suite_timeout=150s; fi
  timeout "$suite_timeout" godot --headless --path "$shanhai_root" --script "res://tests/${check_name}.gd" > "$test_log" 2>&1 || test_status=$?
  if [ "$test_status" -eq 0 ] && ! rg -q 'SCRIPT ERROR:|^ERROR:|Balance configuration is unusable' "$test_log"; then
    printf 'PASS %s: ' "$check_name"
    tail -n 1 "$test_log"
  else
    printf 'FAIL %s (exit %s)\n' "$check_name" "$test_status"
    tail -n 20 "$test_log"
    failed=1
  fi
done
exit "$failed"
