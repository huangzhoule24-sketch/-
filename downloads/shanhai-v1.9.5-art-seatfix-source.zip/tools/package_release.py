#!/usr/bin/env python3
"""Stamp Godot exports and package matching Web, Windows and editable source archives."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
from datetime import datetime, timezone
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
PLATFORMS = {"web": "full-web", "windows": "full-windows"}
ARCHIVES = {
    "web": "山海食肆物语-v1.9.5-art-seatfix-Web.zip",
    "windows": "山海食肆物语-v1.9.5-art-seatfix-Windows.zip",
    "source": "山海食肆物语-v1.9.5-art-seatfix-Source.zip",
}
SOURCE_TOPS = {"assets", "config", "scenes", "scripts", "tests", "tools", "docs", "CustomAssets", "art-source"}
SOURCE_FILES = {"project.godot", "export_presets.cfg", "README.md", "AGENTS.md", ".gitignore", "LICENSE", "LICENSE.txt"}
DENIED_DIRS = {".git", ".godot", "build", "downloads", ".aws", ".ssh", ".codex", ".agents", "node_modules", "__pycache__", ".pytest_cache"}


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def allowed_source(path: Path):
    relative = path.relative_to(ROOT)
    if path.is_symlink() or any(part in DENIED_DIRS for part in relative.parts):
        return False
    name = path.name.lower()
    if name.startswith(".env") or name.startswith("credentials") or name in {"export_credentials.cfg", "id_rsa", "id_ed25519"}:
        return False
    if path.suffix.lower() in {".key", ".pem", ".p12", ".pfx", ".log", ".tmp", ".pyc"}:
        return False
    return relative.parts[0] in SOURCE_TOPS or str(relative) in SOURCE_FILES


def source_paths():
    paths = []
    # Do not traverse unrelated or ignored directories, which can contain old releases or secrets.
    for name in sorted(SOURCE_TOPS | SOURCE_FILES):
        candidate = ROOT / name
        if candidate.is_symlink():
            continue
        if candidate.is_file() and allowed_source(candidate):
            paths.append(candidate)
        elif candidate.is_dir():
            for path in candidate.rglob("*"):
                if path.is_file() and allowed_source(path):
                    paths.append(path)
    return sorted(paths, key=lambda path: path.relative_to(ROOT).as_posix())


def game_source_fingerprint():
    digest = hashlib.sha256()
    count = 0
    for path in source_paths():
        relative = path.relative_to(ROOT)
        if relative.parts[0] not in {"assets", "config", "scenes", "scripts"} and str(relative) not in {"project.godot", "export_presets.cfg"}:
            continue
        name = relative.as_posix().encode("utf-8")
        data_digest = bytes.fromhex(sha256(path))
        digest.update(struct.pack("!I", len(name)))
        digest.update(name)
        digest.update(data_digest)
        count += 1
    return {"sha256": digest.hexdigest(), "files": count, "algorithm": "sha256(path-length + utf8-path + file-sha256), sorted paths"}


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def copy_support(directory: Path, platform: str):
    license_directory = directory / "licenses"
    license_directory.mkdir(parents=True, exist_ok=True)
    for name in ("Godot-LICENSE.txt", "Godot-COPYRIGHT.txt"):
        shutil.copy2(ROOT / "tools/licenses" / name, license_directory / name)
    shutil.copy2(ROOT / "assets/fonts/LICENSE.txt", license_directory / "NotoSansSC-LICENSE.txt")
    shutil.copy2(ROOT / "assets/fonts/DejaVuSans-LICENSE.txt", license_directory / "DejaVuSans-LICENSE.txt")
    shutil.copy2(ROOT / "assets/fonts/NotoCJKSupplement-LICENSE.txt", license_directory / "NotoCJKSupplement-LICENSE.txt")
    shutil.copy2(ROOT / "tools/licenses/NOTICE.txt", license_directory / "NOTICE.txt")
    shutil.copy2(ROOT / "docs/art-pipeline.md", directory / "美术接入说明.md")
    shutil.copy2(ROOT / "docs/art-complete-guide.md", directory / "美术整合说明.md")
    shutil.copy2(ROOT / "docs/山海食肆物语-美术资源清单.md", directory / "山海食肆物语-美术资源清单.md")
    shutil.copy2(ROOT / "docs/art-resource-list-v1.9.3.csv", directory / "art-resource-list-v1.9.3.csv")
    # External art remains outside the PCK. Only bitmap/manifest/documentation files are released.
    for source in (ROOT / "CustomAssets").rglob("*"):
        if source.is_symlink() or not source.is_file() or source.name == ".gdignore":
            continue
        if source.suffix.lower() not in {".png", ".jpg", ".jpeg", ".json", ".md"} and source.name != ".gitkeep":
            continue
        target = directory / "CustomAssets" / source.relative_to(ROOT / "CustomAssets")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    if platform == "windows":
        instructions = """山海食肆物语 v1.9.5 · Windows x64

1. 将ZIP全部解压，双击shanhai-v1.9.5-art-seatfix.exe，保留同目录PCK、CustomAssets和licenses。无需安装Godot。
2. 欢迎页选择开始经营，跟随六步开局教学。新局800元、债务1200元，前三日免租水电且最低还本减半。
3. 更多→系统与存档可保存/读取，日结自动保存。旧完整经营存档会迁移员工ID并保留进度；旧Demo需要手动导入。
"""
    else:
        shutil.copy2(ROOT / "tools/serve_web.py", directory / "serve.py")
        instructions = """山海食肆物语 v1.9.5 · 网页版

全部解压，安装Python3，在本目录运行python serve.py，浏览器打开http://127.0.0.1:8000/。不能直接双击index.html。
存档与导入图片保存在同一浏览器、同一站点的数据中；保存后稍候再刷新，无痕模式或清除站点数据可能移除进度。
"""
    instructions += """
本版变化：固定俯视地图，店内、庭院和街道同图。手机使用固定可读比例，上下平移查看超出部分。员工按主副职业在实际设备间移动，到站后才工作；初始2灶1收银，扩建设备提升并行产能。

服务员独立点单、传菜和基础收银，销售员负责宣传、高效收银和客诉；已删除荐菜与个人溢价。顾客可从全部已启用且有库存的菜单选菜。顶部待办只显示阶段经营任务，教学另有独立卡片；可在系统中重学。

员工列表/详情有照片框，点击放大，缺图显示灰色“立绘待补充”。新六类目录为Portraits/Sprites/UI/Map/Items/FX；旧Backgrounds/Characters/UI/Dishes继续兼容。桌面可把PNG/JPG放在程序同级CustomAssets内，网页从更多→系统与存档→开发者选项→美术资源导入。

本包已接入AI生成的水墨员工立绘与像素美术；此前饕餮独立样例未混入。新增普通提示2.5秒上限、头像168×184、阶段0装修直达简单布置及顶栏三可选图元。完整拼音ID、四方向×10动作、顾客与场景路径见“山海食肆物语-美术资源清单.md”和art-resource-list-v1.9.3.csv；通用接口见“美术接入说明.md”。文化简介、场景小人和立绘互不覆盖。

新局默认2×，可暂停或选择1/2/3/4×，1×每秒3游戏分钟。研发/装修从阶段1开放，分店/中央厨房/探索从阶段3开放，阶段4开放大赛/觉醒/榜单。装修先地图选位置，再指派施工员工，完工后生效；返回、撤销和取消保留。

手动拾取现金/灵石通常15真实秒内有效，暂停冻结寿命；更多中可查账单、流水、顾客反馈、好感支线、山海志和特殊顾客图鉴。紧急救援每局一次5000元，日息2%、20天，再次破产结束。

当前使用中文简介与已导入的AI美术资源。Windows本机与手机实机尚未验收。Godot4.6.3和字体许可在licenses目录。
"""
    (directory / "请先读我.txt").write_text(instructions, encoding="utf-8")


def begin(platform: str):
    directory = BUILD / PLATFORMS[platform]
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "export-receipt.json").unlink(missing_ok=True)
    # Generated runtime files are removed first, so an exporter failure cannot stamp yesterday's PCK.
    # Remove prior version executables/PCKs too, otherwise a new ZIP can include an old game.
    for generated in directory.glob("index*" if platform == "web" else "shanhai-v*"):
        if generated.is_file() and not generated.is_symlink():
            generated.unlink()
    copy_support(directory, platform)
    write_json(directory / ".export-start.json", {"platform": platform, "started_utc": utc_now(), "game_source": game_source_fingerprint()})
    print(f"Export started: {platform}")


def verify_runtime(directory: Path, platform: str):
    if platform == "web":
        required = ["index.html", "index.js", "index.wasm", "index.pck"]
        if not (directory / "index.wasm").is_file() or (directory / "index.wasm").read_bytes()[:4] != b"\0asm":
            raise ValueError("Web 导出缺少有效 WASM")
    else:
        required = ["shanhai-v1.9.5-art-seatfix.exe", "shanhai-v1.9.5-art-seatfix.pck"]
        executable = directory / "shanhai-v1.9.5-art-seatfix.exe"
        if not executable.is_file():
            raise ValueError("Windows 导出缺少 EXE")
        with executable.open("rb") as handle:
            if handle.read(2) != b"MZ":
                raise ValueError("EXE 缺少 DOS 头")
            handle.seek(0x3C)
            offset = struct.unpack("<I", handle.read(4))[0]
            handle.seek(offset)
            if handle.read(4) != b"PE\0\0":
                raise ValueError("EXE 缺少 PE 头")
    for name in required:
        if not (directory / name).is_file() or (directory / name).stat().st_size == 0:
            raise ValueError(f"导出文件缺失：{name}")
    pck = directory / ("index.pck" if platform == "web" else "shanhai-v1.9.5-art-seatfix.pck")
    with pck.open("rb") as handle:
        if handle.read(4) != b"GDPC":
            raise ValueError("PCK 文件头无效")


def release_files(directory: Path):
    return sorted((path for path in directory.rglob("*") if path.is_file() and not path.is_symlink() and (not path.name.startswith(".") or path.name == ".gitkeep")), key=lambda path: path.relative_to(directory).as_posix())


def stamp(platform: str):
    directory = BUILD / PLATFORMS[platform]
    start = json.loads((directory / ".export-start.json").read_text(encoding="utf-8"))
    source = game_source_fingerprint()
    if start["game_source"]["sha256"] != source["sha256"]:
        raise ValueError("导出期间游戏源码变化，请在代码稳定后重新导出")
    verify_runtime(directory, platform)
    files = {path.relative_to(directory).as_posix(): {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in release_files(directory) if path.name != "export-receipt.json"}
    write_json(directory / "export-receipt.json", {"format": 1, "platform": platform, "godot": "4.6.3.stable", "exported_utc": utc_now(), "game_source": source, "files": files})
    (directory / ".export-start.json").unlink()
    print(f"Export verified: {platform}, source {source['sha256']}")


def write_zip(path: Path, entries):
    temporary = path.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source, name in entries:
            archive.write(source, name)
    with zipfile.ZipFile(temporary) as archive:
        corrupt = archive.testzip()
        if corrupt:
            raise ValueError(f"ZIP 校验失败：{corrupt}")
    temporary.replace(path)
    return {"file": path.name, "bytes": path.stat().st_size, "sha256": sha256(path)}


def package():
    BUILD.mkdir(parents=True, exist_ok=True)
    source = game_source_fingerprint()
    receipts = {}
    artifacts = {}
    # Validate every platform before producing any archive, so stale builds cannot appear current.
    for platform, folder in PLATFORMS.items():
        directory = BUILD / folder
        receipt = json.loads((directory / "export-receipt.json").read_text(encoding="utf-8"))
        if receipt["game_source"]["sha256"] != source["sha256"]:
            raise ValueError(f"{platform} 导出对应旧源码，请重新导出")
        verify_runtime(directory, platform)
        for name, evidence in receipt["files"].items():
            path = directory / name
            if not path.is_file() or path.stat().st_size != evidence["bytes"] or sha256(path) != evidence["sha256"]:
                raise ValueError(f"导出后文件发生变化：{platform}/{name}")
        # Documentation/template edits do not change the PCK, but should still reach each release ZIP.
        copy_support(directory, platform)
        receipt["support_updated_utc"] = utc_now()
        receipt["files"] = {path.relative_to(directory).as_posix(): {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in release_files(directory) if path.name != "export-receipt.json"}
        write_json(directory / "export-receipt.json", receipt)
        receipts[platform] = receipt
    for platform, folder in PLATFORMS.items():
        directory = BUILD / folder
        names = list(receipts[platform]["files"]) + ["export-receipt.json"]
        artifacts[platform] = write_zip(BUILD / ARCHIVES[platform], [(directory / name, name) for name in sorted(names)])
    sources = source_paths()
    for required in [
        "project.godot", "export_presets.cfg", "scenes/main.tscn",
        "scripts/core/game_model.gd", "scripts/ui/main.gd", "scripts/services/asset_catalog.gd",
        "config/employees.json", "config/global_balance.json", "assets/fonts/NotoSansSC.otf",
        "config/culture.json", "scripts/services/culture_catalog.gd", "scripts/ui/culture_panel.gd",
        "assets/fonts/DejaVuSans.ttf", "assets/fonts/DejaVuSans-LICENSE.txt",
        "assets/fonts/ShanhaiCJKSupplement.otf", "assets/fonts/NotoCJKSupplement-LICENSE.txt",
        "CustomAssets/.gdignore", "CustomAssets/README.md", "CustomAssets/manifest.json",
        "CustomAssets/Backgrounds/.gitkeep", "CustomAssets/Characters/.gitkeep",
        "CustomAssets/UI/.gitkeep", "CustomAssets/Dishes/.gitkeep",
        "scripts/core/dollhouse_rules.gd", "scripts/services/dollhouse_navigation.gd", "scripts/ui/dollhouse_view.gd", "scripts/core/revision19.gd", "scripts/core/revision18.gd", "scripts/ui/revision18_ui.gd", "scripts/ui/pickup_overlay.gd", "config/revision18.json", "scripts/core/revision171.gd", "scripts/core/rescue171.gd", "scripts/core/special_visitors.gd", "config/revision171.json", "config/stage_tasks.json",
        "docs/art-pipeline.md", "docs/design-v1.9.5.txt", "docs/v1.9.5-delta.md",
        "docs/release-notes-v1.9.5.md", "docs/v1.9.5-validation.md",
    ]:
        if not (ROOT / required) in sources:
            raise ValueError(f"源码包缺少：{required}")
    artifacts["source"] = write_zip(BUILD / ARCHIVES["source"], [(path, path.relative_to(ROOT).as_posix()) for path in sources])
    if game_source_fingerprint()["sha256"] != source["sha256"]:
        raise ValueError("打包期间游戏源码变化，当前 ZIP 不可作为最终版本，请重新导出并打包")
    manifest = {"format": 1, "version": "1.9.5-art-seatfix", "created_utc": utc_now(), "game_source": source, "artifacts": artifacts, "windows_native_playtest": "not_asserted_by_packager"}
    write_json(BUILD / "v1.9.5-art-seatfix-manifest.json", manifest)
    (BUILD / "v1.9.5-art-seatfix-SHA256SUMS.txt").write_text("".join(f"{value['sha256']}  {value['file']}\n" for value in artifacts.values()), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["begin", "stamp", "package", "fingerprint"], nargs="?", default="package")
    parser.add_argument("platform", choices=PLATFORMS, nargs="?")
    args = parser.parse_args()
    if args.action in {"begin", "stamp"} and args.platform is None:
        parser.error("begin/stamp 需要 web 或 windows")
    try:
        if args.action == "begin":
            begin(args.platform)
        elif args.action == "stamp":
            stamp(args.platform)
        elif args.action == "fingerprint":
            print(json.dumps(game_source_fingerprint(), ensure_ascii=False))
        else:
            package()
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as error:
        parser.exit(1, f"打包失败：{error}\n")


if __name__ == "__main__":
    main()
