# 行政公关、税务与刑事（v1.9.7）

市衙与税吏这一层压力。规则尽可能走现成的配置与状态机，不新增子系统。共四块：公关摊派、经营所得税、犒劳、刑事案。

## 一、四条规则

### 1. 公关钱（周期摊派）

- 触发：第 7 天起，每 7 天一次（第 7、14、21、28… 天），`day` 钩子，`min_day: 7`、`day_every: 7`。
- 形态：`admin_levy` 决策事件，两个选项——交钱（`admin.pr_cost`，默认 500）/ 拒绝。
- 效果：交钱后 7 天内卫生检查通过率 +35 个百分点；拒绝后 −25 个百分点。
- 未到第 7 天时检查员不针对本店，通过率保持原始值。

### 2. 经营所得税

- 每笔营业额扣 5%（`admin.tax_rate`），在 `collect_sales_receipt()` 入口、任何暂存之前预扣。
- 营业额仍按全额记账（`ledger.sales`、`state.total_revenue` 不变），税单独记为 `expenses`，资金流水分类为 `tax`。
- 因此升级门槛不受影响，账本能单独看到税负。

### 3. 犒劳

- 入口：店门口街上的「税吏」。点他，或走 更多 → 行政 → 犒劳税吏。
- 价格：`admin.reward_cost`（默认 300），免税 14 天（`admin.tax_exempt_days`）。
- 免税期间不能再点，不能叠加；到期后可再次犒劳。

### 4. 风险值与刑事案

- 每交一次公关钱 **+25**（`admin.risk_per_pay`），每犒劳一次 **+20**（`admin.risk_per_reward`），拒绝一次摊派 **−15**（`admin.risk_relief_refuse`）。
- 上限 `admin.risk_max` = 100。到顶不会自己回落，也不会像血条那样缓慢流失——它是一道**硬墙**，因为只有花钱的动作会推进它。
- 到顶当刻立刻排队 `admin_crime`（优先级 5，`forced: true` 不受事件队列上限限制），玩家看到一张「刑事案：查封与抄没」的公告：
  - 抄没现款 `max(admin.crime_min_fine 600, 现金 × admin.crime_cash_ratio 0.4)`，封顶为「现有现金」，不会变成负债；
  - 查封 `admin.crime_detention_days` = 7 天，**房租与工钱照付**，按查封前的员工数与当前房租一次性扣；
  - 声望清零；
  - 风险值归 0，之前买来的公关与免税一并作废，`crimes + 1`。
- `admin_crime` 的事件定义同时挂了 `day` 钩子 + `requires_admin_risk`，所以读档时风险已满的存档也会在下一个日钩子补触发；两者靠 `event_days` 去重，同一天不会放两次。

风险值的意义在于：这套「花钱买平安」不再是纯收益。交四周公关 = 100 点 = 抄家一次，抄一次家大约拿回 40% 现金 + 7 天停业，远比省下的检查罚款贵。拒绝摊派虽然让检查变难，却是唯一的洗白途径——这就是这一块要的取舍。

**七日查封怎么算。** `game_model.seal_shop_days(days)` 只推进日历，不模拟这七天：清空顾客与调度队列、把 `last_random_minute` 对齐到新时间、`last_day` 设为前一天，让下一日的钩子照常触发。查封期间不产生任何营业、日结与采购，所以房租工资单独按「查封前一天的固定开销 × 7」一次性扣掉——否则富玩家可以靠故意惹官司来躲掉一周固定成本，惩罚反而变成奖励。

## 二、卫生检查的实际概率

```
chance = 基础值(未准备 0.5 / 已准备 0.85) + 舒适度 × 0.005 + 行政加减项
```

行政加减项：

| 状态 | 增减 |
|---|---|
| 公关有效 | +0.35 |
| 拒绝过（或公关到期） | −0.25 |
| 尚未被摊派过（第 7 天前） | 0 |

所以交钱后「侥幸应付」也有 85%，拒绝后「认真应对」只有 60%——原来的 50 元准备选项仍然有意义，但不再是万灵药。

## 三、经济含义

卫生检查约 0.7 次/天（`events.random_interval` 180 分 × `events.hygiene_probability` 0.2，冷却 1 天封顶），一个 7 天周期约 5 次检查。

- 交钱：期望失败 0.75 次 ≈ 150 元罚款 + 少量声望损失。
- 拒绝：期望失败 3.75 次 ≈ 750 元 + 声望 −37，且更容易连续两次失败进入低保洁度，接上民事索赔。

差价约 600 元，公关钱定 500 是「略划算但肉疼」的位置：交，等于用一半的期望罚款买平安；不交，赌自己扛得住连锁反应。

## 四、代码位置

| 位置 | 作用 |
|---|---|
| `config/events.json` → `admin_levy` | 摊派事件与两个选项 |
| `config/events.json` → `admin_crime` | 刑事案公告（`type: notice`，`forced: true`） |
| `config/global_balance.json` → `admin.*` | 全部数值与税吏站位 |
| `world_events.gd` → `admin()` / `pr_active()` / `tax_exempt_active()` | 行政状态读取 |
| `world_events.gd` → `risk_max()` / `admin_risk()` / `risk_capped()` / `_shift_admin_risk()` | 风险值的读写与到顶入队 |
| `world_events.gd` → `_eligible` 的 `day_every` / `requires_admin_risk` | 每 7 天触发；风险满才可触发刑事案 |
| `world_events.gd` → `_apply_effects` 的 `admin_pr` / `admin_refuse` / `admin_tax_exempt` / `admin_crime` | 四个效果类型 |
| `world_events.gd` → `_inspection` | 把行政加减项并入通过率 |
| `world_events.gd` → `_collect_income_tax` | 在收入收口预扣 5% |
| `world_events.gd` → `_admin_crime()` / `_sealed_days_cost()` | 抄没、查封开销、清零与免职 |
| `game_model.gd` → `seal_shop_days()` | 只推进日历的七日查封 |
| `world_events.gd` → `perform("admin_reward")` | 犒劳动作 |
| `full_rules.gd` | 动作白名单与「不重复记支出」例外 |
| `full_panels.gd` → `admin_panel()` | 行政面板（含风险值一行） |
| `restaurant_view.gd` / `dollhouse_view.gd` | 税吏的场景绘制与点击命中 |
| `tests/admin_tests.gd` | 61 条断言：节奏、概率、税、犒劳、风险、刑事、存档 |

## 五、存档兼容

`ensure_state()` 里的 `world.admin` 默认块负责给老存档补字段，并且逐键回填——早一版存档里的 `admin` 已经存在但缺 `risk` / `crimes` / `last_crime_day`，整块覆盖会把旧档的打点记录冲掉，所以走的是和 `legal` 一样的逐键补。`validate_state()` 对未知 key 不做限制，旧档可以直接读入。`admin` 状态没有使用 `flags` 数组——该数组在存档校验里有 5 个 id 的白名单，硬塞会被判为坏档。

## 六、改数值时注意

1. 只改 `global_balance.json` 的 `admin.*` 即可，代码里没有硬编码。
2. `admin.npc_x / npc_y` 是税吏的世界坐标（世界 1020×560，街道带 y≈518–560）。
3. 改 `admin.period_days` 时 `day_every` 要同步改 `config/events.json`，两者不在同一处。
4. 改 `admin.tax_rate` 会打破 `campaign_tests` 里按税率计算的现金断言——那里读的是配置，不是写死的数字，一般不用改。
5. 风险与刑事这一组的旋钮：`risk_max`（到顶阈值）、`risk_per_pay` / `risk_per_reward`（推高速度）、`risk_relief_refuse`（洗白力度）、`risk_warn_ratio`（60% 时的风声提示）、`crime_cash_ratio` / `crime_min_fine`（抄没力度）、`crime_detention_days`（停业天数）、`crime_charge_fixed_costs`（1 收固定开销，0 不收——除非想做成「故意惹官司躲房租」的漏洞，否则别关）。
6. 把 `risk_per_pay` 调大等于缩短「开始要出事」的周期：按当前 25 点计算，纯交钱要交 4 次（约 4 周）才爆表，混着犒劳更快。想让案子来得更晚就调低单次涨幅，不要只调高 `risk_max`——后者会让面板上的进度条读数失去意义。

## 七、验证

- `tests/admin_tests.gd`：61 条断言。覆盖第 6/7/8/14 天的摊派节奏（注意 `day` 钩子会顺带排入「当康报丰年」这类无关事件，所以判的是队列里有没有 `admin_levy`，不是队列是否为空）、交钱与拒绝各自的检查通过率、首摊派前的原始概率、5% 预扣与免税挂起/过期、犒劳的扣款・不可叠加・现金不足・到期重买、风险值的增减与到顶、刑事案的抄没/清零/七日跳时/关系作废/不连环触发，以及存档校验与面板快照。
- 检查概率那一行不是 `_resolution_details` 的最后一行（后面还会跟保洁度变化），断言要倒着找含「通过概率」的那行；交钱/拒绝那条同理，现在后面还跟着一行风险值。
- 全量 51 个测试套件通过。5% 税会让既有套件里按毛额写死的现金断言偏移 5%，`skill_coverage_tests` 已改为按 `admin.tax_rate` 折算，`world_completion_tests` 在夹具里把税率设为 0 以隔离貔貅暂存的算术。
