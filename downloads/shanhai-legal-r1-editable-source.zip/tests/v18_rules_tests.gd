extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func fresh():
	var m=Model.new(20261020);m.start_full();m.events.clear();m.balance["customer.base_flow"]=0;return m
func run():
	var m=fresh();var v=m.full_rules.revision18
	expect(m.catalog.size()==30 and m._b("stage.1.revenue")==4000,"28 employees and4000 threshold")
	m.state.total_minutes=10*1440;expect(m.clock_label().contains("1年2月1日"),"Ten days form a month")
	m.state.total_minutes=120*1440;expect(m.clock_label().contains("2年1月1日"),"120 days form a year")
	for minute in [360,539,540,599,600,659,660,1379,1380,1439,1440]:
		m.state.total_minutes=minute
		expect(v.accepting_guests()==(minute in [360,539,660,1379]),"Entry cutoff at "+str(minute))
		var count=m.customers.size();m._spawn_customer("fried_rice",false)
		expect(m.customers.size()==count+(1 if minute in [360,539,660,1379] else 0),"Actual spawn observes cutoff "+str(minute))
		m.customers.clear();m.scheduler.clear()
	# All waiting stages use the common120-minute cap with the new consumption.
	for stage in ["ordering","recommending","queued","cooking","serving"]:
		m=fresh();m._spawn_customer("fried_rice",false);var c=m.customers[0];c.stage=stage;c.worker="";c.arrival_minute=360
		m.state.total_minutes=439;m._expire_customers();expect(m.customers.size()==1,"79 minutes retain "+stage)
		m.state.total_minutes=440;m._expire_customers();expect(m.customers.is_empty(),"80 minutes expire "+stage)
	# A closing roster cannot be removed by shift/rest/zero-stamina paths.
	m=fresh();v=m.full_rules.revision18;m.state.total_minutes=599;m._spawn_customer("fried_rice",false)
	# Spawn is forbidden at599, so create it during lawful opening then move forward.
	m.state.total_minutes=500;m._spawn_customer("fried_rice",false);var c=m.customers[0];c.arrival_minute=599
	m.state.total_minutes=600;v.before_tick();var e=m._employee("xiao");e.stamina=0
	m.set_employee_rest("xiao",true)
	expect(v.draining("xiao") and not e.resting and m.full_rules.active("xiao"),"Closing work survives zero stamina and rest instruction")
	m._assign_tasks();m.advance_minutes(70)
	expect(m.customers.is_empty(),"Rest-period orders and dirty tables finish")
	e.stamina=100;m.set_employee_rest("xiao",false,false) # Separate the auto-roster check from the zero-stamina close above.
	m.state.total_minutes=601;v.s().period="breakfast";v.s().closing_ids=["xiao"];v.before_tick()
	expect(e.resting and e.v18_auto_rest,"Only automatic closing rest is marked")
	e.stamina=100;m.state.total_minutes=660;v.before_tick();expect(not e.resting and not e.v18_auto_rest,"Automatic roster returns at next opening")
	# Manual pickups never award automatically and do not increase food sales.
	m=fresh();v=m.full_rules.revision18;m.balance.pickup_drop_chance=1
	var rng=m._rng.state;var cash=float(m.state.cash);var revenue=float(m.state.total_revenue)
	for i in range(5):v.on_sale({"id":i},{},10,1)
	expect(v.s().pickups.size()==3 and v.s().pickups[0].id==3,"Only newest three drops remain")
	expect(m.state.cash==cash and m.state.total_revenue==revenue,"Creating drops cannot award money or food revenue")
	var sample=v.s().pickups[0];var original=float(sample.remaining);m.paused=false;m.speed=4;v.advance_pickups(5)
	expect(is_equal_approx(sample.remaining,original-5),"Pickup clock measures real seconds independent of4x")
	m.paused=true;v.advance_pickups(100);expect(sample.remaining==original-5,"Pause freezes pickup lifetime")
	m.paused=false;v.advance_pickups(10);expect(v.s().pickups.is_empty() and m.state.cash==cash,"Expired drops give no automatic reward")
	v.s().pickups=[{"id":6,"kind":"cash","amount":10,"x":500.0,"y":500.0,"remaining":15.0}];v.s().next_pickup=7
	expect(m.full_rules.perform("pickup_collect",{"id":6}).ok and m.state.cash==cash+10,"Public manual action credits cash")
	expect(m.state.total_revenue==revenue,"Picked cash stays outside food turnover")
	expect(not m.full_rules.perform("pickup_collect",{"id":6}).ok and m.state.cash==cash+10,"Repeated click cannot double award")
	v.s().pickups=[{"id":7,"kind":"gems","amount":1,"x":500.0,"y":500.0,"remaining":12.0}];v.s().next_pickup=8
	var gems=m.state.gems;expect(m.full_rules.perform("pickup_collect",{"id":7}).ok and m.state.gems==gems+1 and m.state.cash==cash+10,"Gem collection credits gems only")
	v.s().pickups=[{"id":8,"kind":"cash","amount":5,"x":500.0,"y":500.0,"remaining":7.25}];v.s().next_pickup=9
	var file=OS.get_user_data_dir().path_join("shanhai-v18-test.json");var other=fresh();rng=m._rng.state
	expect(m.save_game(file) and other.load_game(file),"Pickups roundtrip through validated saves")
	expect(other.state.revision18.pickups[0].remaining==7.25 and other._rng.state==rng,"Load preserves remaining time and RNG")
	# Continuous state events coexist, persist and use best-source merging.
	m=fresh();v=m.full_rules.revision18
	for id in v.config.states:
		v.apply_state(id);expect(v.has_state(id),"State applies: "+id)
	expect(v.s().states.size()==6 and m.pending_event().is_empty(),"Five state effects plus the legal gate coexist without choice popup")
	expect(is_equal_approx(m.full_rules.world.modifier("traffic"),1.3),"Similar traffic bonuses take best source")
	expect(is_equal_approx(m.full_rules.world.procurement_multiplier(),0.8),"Ingredient sale reduces actual procurement")
	var base=fresh();expect(is_equal_approx(m.full_rules.effects.complaint_probability({"dish_effects":{"complaint_mult":0.5}}),base.full_rules.effects.complaint_probability({"dish_effects":{"complaint_mult":0.5}})*1.2),"Hygiene alters actual complaint chance")
	expect(m.save_game(file) and other.load_game(file) and other.state.revision18.states.size()==6,"Active state events survive reload")
	m.state.total_minutes+=120;v.tick();expect(not v.has_state("rush_hour") and v.has_state("ingredient_sale"),"States expire by game duration independently")
	v.s().kitchen_uses=60;cash=m.state.cash
	expect(not m.full_rules.perform("kitchen_clean",{}).ok,"Cleaning requires actual idle worker")
	expect(m.full_rules.perform("kitchen_clean",{"employee_id":"xiao"}).ok,"Idle employee can start real cleaning job")
	expect(m.state.cash==cash-20 and not m.full_rules.active("xiao") and v.has_state("hygiene_risk"),"Cleaning charges once, occupies staff, clears risk only when done")
	expect(m.save_game(file) and other.load_game(file),"Cleaning project is loadable")
	m.advance_minutes(14);expect(v.has_state("hygiene_risk"),"Risk remains during cleaning")
	m.advance_minutes(1);expect(not v.has_state("hygiene_risk") and v.s().kitchen_uses==0,"Completion clears risk and use counter")
	# Actual hooks apply states, and new traits use real employee attributes.
	m=fresh();v=m.full_rules.revision18
	# Restore event catalogue, restricted deterministic hooks only.
	m.events=JSON.parse_string(FileAccess.get_file_as_string("res://config/events.json"))
	for i in range(3):v.on_sale({"id":i},{},10,1)
	expect(v.has_state("word_of_mouth"),"Three actual consecutive good checkouts trigger word of mouth")
	v.s().kitchen_uses=59;v.on_cooking();expect(v.has_state("hygiene_risk"),"Sixtieth cook triggers hygiene warning")
	var turtle=m._create_employee(m._employee_config("xuan_gui"));var comparison=turtle.duplicate(true);comparison.id="xian_yang"
	expect(is_equal_approx(m.full_rules.effects.stamina_drain_factor(turtle),m.full_rules.effects.stamina_drain_factor(comparison)*0.9),"Xuangui consumes ten percent less stamina")
	expect(m.full_rules.effects.kitchen_chaos_delay({},turtle)==0,"Xuangui avoids random kitchen delay")
	m=fresh();m.employees.append(m._create_employee(m._employee_config("qing_geng")));m.full_rules.ensure_state_defaults();m._spawn_customer("fried_rice",false)
	c=m.customers[0];var mood=float(c.get("mood",50));m.full_rules.revision18.tick()
	expect(float(c.mood)>mood,"On-duty Qinggeng actually restores customer mood")
	expect(m.full_rules.sidequests.snapshot().pages.size()==25 and not m.full_rules.sidequests.can_perform("baize_page",{"employee_id":"qing_geng"}).ok,"Baize still requires original25 pages only")
	var legacy_bytes=FileAccess.get_file_as_bytes("res://tests/fixtures/v171-day53-save.json.gz").decompress_dynamic(16*1024*1024,FileAccess.COMPRESSION_GZIP)
	var legacy_file=OS.get_user_data_dir().path_join("shanhai-v18-legacy-test.json");var handle=FileAccess.open(legacy_file,FileAccess.WRITE);handle.store_buffer(legacy_bytes);handle.close()
	other=Model.new(1);other.start_full();expect(other.load_game(legacy_file),"Actual v1.7.1 day53 save migrates")
	expect(other.state.has("revision18") and "all_beasts" in other.state.story.completed,"Legacy26-collection achievement is retained")
	DirAccess.remove_absolute(file);DirAccess.remove_absolute(legacy_file)
	print("V1.8 rules: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
