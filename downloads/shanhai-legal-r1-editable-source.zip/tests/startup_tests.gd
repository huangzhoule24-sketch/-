extends SceneTree
var failures: Array[String]=[]
var checks=0
func check(condition:bool,message:String):
	checks+=1
	if not condition:failures.append(message);push_error(message)
func _initialize():call_deferred("run")
func run():
	var catalog=preload("res://scripts/services/asset_catalog.gd").new()
	check(catalog._snapshot.is_empty(),"Normal startup must not hash the art corpus")
	check(catalog._decoded.is_empty(),"Art remains lazy; all resources still available")
	check(catalog.has_image("UI/btn_employee"),"Bundled UI remains available")
	var locale=preload("res://scripts/services/localization.gd").new("user://startup-test-language.cfg")
	check(locale.patterns.is_empty(),"Do not compile unused English patterns during Chinese launch")
	locale.set_language("en")
	check(locale.translate("食材采购需要 ￥60，现金不足")!="食材采购需要 ￥60，现金不足","Lazy template initialization keeps translation")
	check(not locale.patterns.is_empty(),"English compiles templates on first use")
	var boot=load("res://scenes/boot.tscn").instantiate()
	root.add_child(boot)
	current_scene=boot
	var deadline=Time.get_ticks_msec()+20000
	while (current_scene==boot or current_scene==null) and Time.get_ticks_msec()<deadline:
		await process_frame
	check(current_scene!=null and current_scene!=boot,"Loader reaches the actual complete game")
	if current_scene!=null and current_scene!=boot:
		var game=current_scene
		check(game.model.catalog.size()==30,"All staff remain in the game")
		check(game.model.events.size()==42,"All events remain in the game")
		check(game.model.state.mode=="full","Loader starts full campaign")
		check(game.panel_name=="欢迎","Actual welcome controls are ready")
		for i in range(5):await process_frame
		check(FileAccess.file_exists("user://startup-report.json"),"Startup diagnostic written without campaign contents")
		var report=JSON.parse_string(FileAccess.get_file_as_string("user://startup-report.json"))
		check(report.get("complete",false),"Startup diagnostic marks completed boot")
		check(report.stages_ms_since_engine_start.has("loading_screen_presented"),"Visible loading frame precedes full resource load")
		game.free()
		# Allow the audio mixer to release its last streamed-music playback reference.
		await create_timer(.15).timeout
	print("Startup checks: ",checks,"; failures: ",failures)
	quit(0 if failures.is_empty()else 1)
