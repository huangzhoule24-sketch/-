extends SceneTree

## Civil-law block: day gate, cleanliness accounting, court verdicts, payment
## shortfall and save round-trip. Data comes from the shipped JSON, not copies.

const Model = preload("res://scripts/core/game_model.gd")
var passed = 0
var failed = 0


func _init() -> void:
	call_deferred("_run")


func check(condition: bool, message: String) -> void:
	if condition: passed += 1
	else:
		failed += 1
		push_error("LEGAL FAIL: " + message)


func fixture(day: int = 14) -> Variant:
	var m = Model.new(2026)
	m.full_rules.start_full()
	m.state.cash = 10000.0
	m.state.reputation = 500
	m.state.stage = 4
	m.state.comfort = 100
	m.state.total_minutes = (day - 1) * 1440 + 720
	m.employees.clear()
	for definition in m.catalog:
		var employee: Dictionary = m._create_employee(definition)
		employee.resting = false
		m.employees.append(employee)
	m.state.world.clear()
	m.full_rules.world.ensure_state()
	m.full_rules.revision18.ensure_state()
	m.state.revision18.states.clear()
	return m


func _clear_history(m: Variant, id: String) -> void:
	m.state.world.event_days.erase(id)
	m.state.world.cooldowns.erase(id)
	m.state.world.queue.clear()


func _enqueue(m: Variant, id: String) -> void:
	_clear_history(m, id)
	m.full_rules.world._enqueue(id, {})


func _run() -> void:
	_gate_tests()
	_cleanliness_tests()
	_court_tests()
	_payment_tests()
	_save_tests()
	print("LEGAL CHECKS: %d passed, %d failed" % [passed, failed])
	quit(1 if failed > 0 else 0)


func _gate_tests() -> void:
	var early = fixture(5)
	var early_world = early.full_rules.world
	check(early_world._day() + 1 == 5, "fixture sits on day 5")
	check(not early_world.legal_day_started(), "legal window is closed before day 14")
	early.full_rules.revision18.apply_state("low_cleanliness")
	check(early_world._has_state("low_cleanliness"), "day-5 fixture carries the low-cleanliness state")
	check(not early_world._eligible(early_world._definition("wet_floor"), "random", {}), "wet floor cannot fire before day 14")
	check(not early_world._eligible(early_world._definition("food_safety"), "random", {}), "food safety cannot fire before day 14")
	var late = fixture(14)
	var late_world = late.full_rules.world
	check(late_world.legal_day_started(), "legal window opens on day 14")
	check(late.business_open(), "fixture is inside business hours")
	check(not late_world._eligible(late_world._definition("wet_floor"), "random", {}), "wet floor needs the low-cleanliness state")
	check(not late_world._eligible(late_world._definition("food_safety"), "random", {}), "food safety needs the low-cleanliness state")
	late.full_rules.revision18.apply_state("low_cleanliness")
	check(late_world._eligible(late_world._definition("wet_floor"), "random", {}), "wet floor is eligible while cleanliness is low")
	check(late_world._eligible(late_world._definition("food_safety"), "random", {}), "food safety is eligible while cleanliness is low")
	check(not late_world._eligible(late_world._definition("wet_floor"), "cooking", {}), "wrong hook never fires the case")
	# The hygiene event itself stays available from day 1.
	check(early_world._eligible(early_world._definition("hygiene"), "random", {}), "hygiene inspection still rolls from day 1")


func _cleanliness_tests() -> void:
	var m = fixture(14)
	var world = m.full_rules.world
	check(is_equal_approx(world.cleanliness(), 100.0), "cleanliness starts at the maximum")
	world._inspection(true)
	check(is_equal_approx(world.cleanliness(), 100.0), "a prepared pass cannot exceed the cap")
	world._legal_inspection_failure()
	check(is_equal_approx(world.cleanliness(), 85.0), "one failed inspection costs 15 cleanliness")
	check(int(world.legal().hygiene_failures) == 1, "first failure is counted")
	check(not world._has_state("low_cleanliness"), "one failure is not enough")
	world._legal_inspection_failure()
	check(world._has_state("low_cleanliness"), "second failure grants low cleanliness")
	check(world.cleanliness() <= 55.0, "low cleanliness lands below the safety line")
	check(int(world.legal().hygiene_failures) == 0, "counter resets once the state is granted")
	var before = world.cleanliness()
	world.legal_clean_done()
	check(world.cleanliness() >= 70.0, "cleaning the kitchen restores cleanliness")
	check(not world._has_state("low_cleanliness"), "cleaning removes the state")
	check(world.cleanliness() > before, "cleaning raises the reading")
	# Decay only starts with the legal window.
	var early = fixture(3)
	var early_world = early.full_rules.world
	early_world.legal_on_day()
	check(is_equal_approx(early_world.cleanliness(), 100.0), "no decay before day 14")
	early.state.total_minutes = 13 * 1440 + 720
	early_world.legal_on_day()
	check(is_equal_approx(early_world.cleanliness(), 97.0), "one point of decay per new day after the window opens")


func _court_tests() -> void:
	var m = fixture(14)
	var world = m.full_rules.world
	m.full_rules.revision18.apply_state("low_cleanliness")
	m.state.layout.append({"id": "safety_sign", "x": 0, "y": 0, "w": 1, "h": 1, "building": true})
	check(not world.safety_sign_placed(), "an unfinished sign does not count")
	m.state.layout.back().building = false
	check(world.safety_sign_placed(), "a finished sign counts")
	# Losing branch: no sign on the floor.
	m.state.layout.pop_back()
	var cash = float(m.state.cash)
	var reputation = int(m.state.reputation)
	_enqueue(m, "wet_floor")
	var result = world.choose("court")
	check(bool(result.get("ok", false)), "court option resolves")
	check(is_equal_approx(float(m.state.cash), cash - 100.0), "losing pays 100 in compensation")
	check(int(m.state.reputation) == reputation - 15, "losing costs 15 reputation")
	check(int(world.legal().cases_lost) == 1, "loss is tallied")
	var loss_entry: Dictionary = {}
	for entry in m.state.world.modifiers:
		if str(entry.get("source_tag", "")) == "legal_wet_lose": loss_entry = entry
	check(not loss_entry.is_empty(), "losing adds a traffic penalty")
	check(str(loss_entry.get("value_key", "")) == "legal.wet_floor_lose_traffic" and float(loss_entry.get("sign", 1)) < 0, "the penalty is a 20% traffic cut")
	check(int(loss_entry.get("until", 0)) - int(m.state.total_minutes) == 4320, "the penalty lasts three days")
	# Winning branch: sign placed.
	m.state.layout.append({"id": "safety_sign", "x": 0, "y": 0, "w": 1, "h": 1})
	m.state.world.modifiers.clear()
	cash = float(m.state.cash)
	reputation = int(m.state.reputation)
	_enqueue(m, "wet_floor")
	world.choose("court")
	check(is_equal_approx(float(m.state.cash), cash), "winning pays nothing")
	check(int(m.state.reputation) == reputation, "winning keeps reputation")
	check(int(world.legal().cases_won) == 1, "win is tallied")
	var win_entry: Dictionary = {}
	for entry in m.state.world.modifiers:
		if str(entry.get("source_tag", "")) == "legal_wet_win": win_entry = entry
	check(not win_entry.is_empty(), "winning still trims traffic")
	check(str(win_entry.get("value_key", "")) == "legal.wet_floor_win_traffic", "winning uses the milder 10% cut")
	check(int(win_entry.get("until", 0)) - int(m.state.total_minutes) == 4320, "the winning cut also lasts three days")
	check(m.state.world.delayed.any(func(entry): return str(entry.get("title", "")) == "胜诉后客流回升"), "rebound is queued for days 4-6")
	m.state.total_minutes += 4321
	world.tick_minute()
	check(m.state.world.modifiers.any(func(entry): return str(entry.get("source_tag", "")) == "legal_wet_rebound"), "rebound modifier arrives after three days")
	# Food safety is judged by cleanliness, not by the sign.
	var food = fixture(14)
	var food_world = food.full_rules.world
	food.full_rules.revision18.apply_state("low_cleanliness")
	food_world.legal().cleanliness = 40.0
	_enqueue(food, "food_safety")
	food_world.choose("court")
	check(int(food_world.legal().cases_lost) == 1, "a dirty kitchen loses the food-safety case even with a sign")
	food.state.layout.append({"id": "safety_sign", "x": 0, "y": 0, "w": 1, "h": 1})
	food_world.legal_adjust_cleanliness(40)
	food.state.world.modifiers.clear()
	_enqueue(food, "food_safety")
	food_world.choose("court")
	check(int(food_world.legal().cases_won) == 1, "a clean kitchen wins the food-safety case")


func _payment_tests() -> void:
	var m = fixture(14)
	var world = m.full_rules.world
	m.state.cash = 10.0
	_enqueue(m, "wet_floor")
	world.choose("settle")
	check(is_equal_approx(float(m.state.cash), 0.0), "settling pays what is on hand")
	check(is_equal_approx(float(m.state.world.unpaid_fines), 20.0), "the shortfall becomes unpaid compensation")
	var paid = world.perform("pay_fines")
	check(bool(paid.get("ok", false)) == false, "unpaid compensation cannot be settled without cash")
	m.state.cash = 100.0
	paid = world.perform("pay_fines")
	check(bool(paid.get("ok", false)), "unpaid compensation can be settled once cash is back")
	check(is_equal_approx(float(m.state.world.unpaid_fines), 0.0), "settling clears the balance")


func _save_tests() -> void:
	# A real opening save: the legal block and the new state must survive the
	# strict validator, and an older save without any legal block must load too.
	var path := "user://shanhai-legal-tests.json"
	var m = Model.new(2026)
	m.full_rules.start_full()
	m.full_rules.revision18.ensure_state()
	var world = m.full_rules.world
	world.ensure_state()
	world.legal().cleanliness = 55.0
	world.legal().hygiene_failures = 1
	world.legal().cases_won = 2
	world.legal().cases_lost = 1
	m.full_rules.revision18.apply_state("low_cleanliness")
	check(bool(m.save_game(path)), "legal state saves")
	var copy = Model.new(7)
	check(bool(copy.load_game(path)), "legal state reloads through strict validation")
	check(is_equal_approx(copy.full_rules.world.cleanliness(), 55.0), "cleanliness survives reload")
	check(copy.full_rules.world._has_state("low_cleanliness"), "the low-cleanliness state survives reload")
	check(int(copy.full_rules.world.legal().cases_won) == 2, "verdict history survives reload")
	var snapshot = copy.full_rules.snapshot()
	check(snapshot.get("world", {}).get("legal") is Dictionary, "snapshot exposes the legal block")
	check(snapshot.get("world", {}).get("legal", {}).get("start_day") == 14, "snapshot reports the open day")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
