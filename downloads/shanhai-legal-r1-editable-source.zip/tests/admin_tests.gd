extends SceneTree

## Administrative block: the seven-day kickback cadence, its effect on hygiene
## inspection odds, the 5% income tax and the fourteen-day reward that lifts it.
## Every number is read from the shipped balance file rather than duplicated.

const Model = preload("res://scripts/core/game_model.gd")
var passed = 0
var failed = 0


func _init() -> void:
	call_deferred("_run")


func check(condition: bool, message: String) -> void:
	if condition: passed += 1
	else:
		failed += 1
		push_error("ADMIN FAIL: " + message)


func fixture(day: int = 1) -> Variant:
	var m = Model.new(2026)
	m.full_rules.start_full()
	m.state.cash = 10000.0
	m.state.reputation = 500
	m.state.stage = 4
	m.state.comfort = 0
	m.state.total_minutes = (day - 1) * 1440 + 600
	m.employees.clear()
	for definition in m.catalog:
		var employee: Dictionary = m._create_employee(definition)
		employee.resting = false
		m.employees.append(employee)
	m.state.world.clear()
	m.full_rules.world.ensure_state()
	m.state.world.last_random_minute = int(m.state.total_minutes)
	return m


func _to_day(m: Variant, day: int) -> void:
	m.state.total_minutes = (day - 1) * 1440 + 600
	m.state.world.last_day = day - 2
	m.state.world.last_random_minute = int(m.state.total_minutes)


func _clear(m: Variant, id: String) -> void:
	m.state.world.event_days.erase(id)
	m.state.world.cooldowns.erase(id)
	m.state.world.queue.clear()


func _pay_levy(m: Variant, day: int) -> void:
	_to_day(m, day)
	_clear(m, "admin_levy")
	m.full_rules.world._enqueue("admin_levy", {})
	m.full_rules.world.choose("pay")


func _refuse_levy(m: Variant, day: int) -> void:
	_to_day(m, day)
	_clear(m, "admin_levy")
	m.full_rules.world._enqueue("admin_levy", {})
	m.full_rules.world.choose("refuse")


## The day hook can legitimately queue unrelated events such as 当康报丰年, so
## the cadence checks look for the levy itself instead of an empty queue.
func _queued_ids(m: Variant) -> Array:
	var ids: Array = []
	for item in m.state.world.queue:
		if item is Dictionary: ids.append(str(item.get("id", "")))
	return ids


## _inspection logs the odds line first and then the cleanliness fallout, so the
## last line is not reliably the probability. Scan backwards for the chance line.
func _detail_line(w: Variant, needle: String) -> String:
	for i in range(w._resolution_details.size() - 1, -1, -1):
		var line: String = str(w._resolution_details[i])
		if needle in line: return line
	return ""


func _inspection_chance(w: Variant) -> float:
	for i in range(w._resolution_details.size() - 1, -1, -1):
		var line: String = str(w._resolution_details[i])
		if "通过概率" in line:
			return float(line.get_slice("通过概率", 1).get_slice("%", 0))
	return -1.0


func _run() -> void:
	_cadence_tests()
	_leverage_tests()
	_tax_tests()
	_reward_tests()
	_crime_tests()
	_save_tests()
	print("ADMIN CHECKS: %d passed, %d failed" % [passed, failed])
	quit(1 if failed > 0 else 0)


func _cadence_tests() -> void:
	var m = fixture(6)
	var w = m.full_rules.world
	_to_day(m, 6)
	_clear(m, "admin_levy")
	w.on_hook("day")
	check(not "admin_levy" in _queued_ids(m), "no levy before day 7")
	_to_day(m, 7)
	_clear(m, "admin_levy")
	w.on_hook("day")
	check("admin_levy" in _queued_ids(m), "levy arrives on day 7")
	_to_day(m, 8)
	_clear(m, "admin_levy")
	w.on_hook("day")
	check(not "admin_levy" in _queued_ids(m), "levy does not repeat the next day")
	_to_day(m, 14)
	_clear(m, "admin_levy")
	w.on_hook("day")
	check("admin_levy" in _queued_ids(m), "levy repeats on day 14")


func _leverage_tests() -> void:
	var m = fixture(7)
	var w = m.full_rules.world
	_to_day(m, 7)
	_clear(m, "admin_levy")
	w._enqueue("admin_levy", {})
	var paid: Dictionary = w.choose("pay")
	check(bool(paid.get("ok", false)), "levy can be paid")
	check(w.pr_active(), "paying activates the公关 window")
	check(is_equal_approx(float(m.state.cash), 10000.0 - float(m.balance.get("admin.pr_cost", 500))), "levy charges the configured fee once")
	var after_pay: String = _detail_line(w, "公关钱已交")
	check(after_pay.begins_with("公关钱已交"), "paying is explained in the resolution log")
	w._inspection(false)
	var paid_chance: float = _inspection_chance(w)
	check(is_equal_approx(paid_chance, (float(m.balance.get("events.inspection_base_pass")) + float(m.balance.get("admin.pr_pass_bonus", 0.35))) * 100), "paid inspection odds rise by the configured bonus")

	var refused = fixture(7)
	var rw = refused.full_rules.world
	_to_day(refused, 7)
	_clear(refused, "admin_levy")
	rw._enqueue("admin_levy", {})
	var denied: Dictionary = rw.choose("refuse")
	check(bool(denied.get("ok", false)), "levy can be refused")
	check(not rw.pr_active(), "refusing leaves no公关 window")
	check(is_equal_approx(float(refused.state.cash), 10000.0), "refusing costs nothing")
	rw._inspection(false)
	var refused_chance: float = _inspection_chance(rw)
	check(is_equal_approx(refused_chance, (float(refused.balance.get("events.inspection_base_pass")) + float(refused.balance.get("admin.no_pr_pass_penalty", -0.25))) * 100), "refused inspection odds fall by the configured penalty")

	var untouched = fixture(3)
	untouched.full_rules.world._inspection(false)
	var plain_chance: float = _inspection_chance(untouched.full_rules.world)
	check(is_equal_approx(plain_chance, float(untouched.balance.get("events.inspection_base_pass")) * 100), "inspections before the first levy keep their base odds")


func _tax_tests() -> void:
	var m = fixture(3)
	var w = m.full_rules.world
	var cash_before: float = float(m.state.cash)
	var expenses_before: float = float(m.state.ledger.expenses)
	var received: float = float(w.collect_sales_receipt(100.0))
	var rate: float = float(m.balance.get("admin.tax_rate", 0.05))
	check(is_equal_approx(received, 100.0), "the till still hands the gross to the caller")
	check(is_equal_approx(float(m.state.cash), cash_before - 100.0 * rate), "income tax leaves the till in cash")
	check(is_equal_approx(float(m.state.ledger.expenses) - expenses_before, 100.0 * rate), "income tax is booked as an expense")
	check(float(m.state.ledger.sales) == 0.0, "withholding tax is not a sale")

	var exempt = fixture(3)
	exempt.full_rules.world.admin().tax_exempt_until = int(exempt.state.total_minutes) + 1440
	var exempt_cash: float = float(exempt.state.cash)
	exempt.full_rules.world.collect_sales_receipt(100.0)
	check(is_equal_approx(float(exempt.state.cash), exempt_cash), "an active reward suspends the income tax")

	var elapsed = fixture(3)
	elapsed.full_rules.world.admin().tax_exempt_until = int(elapsed.state.total_minutes) - 1
	var elapsed_cash: float = float(elapsed.state.cash)
	elapsed.full_rules.world.collect_sales_receipt(100.0)
	check(float(elapsed.state.cash) < elapsed_cash, "the reward stops once it expires")


func _reward_tests() -> void:
	var m = fixture(3)
	var w = m.full_rules.world
	var cost: float = float(m.balance.get("admin.reward_cost", 300))
	var days: int = int(m.balance.get("admin.tax_exempt_days", 14))
	var expenses_before: float = float(m.state.ledger.expenses)
	check(bool(w.can_perform("admin_reward").ok), "reward is affordable out of the box")
	var result: Dictionary = w.perform("admin_reward")
	check(bool(result.get("ok", false)), "reward executes")
	check(is_equal_approx(float(m.state.cash), 10000.0 - cost), "reward charges the configured fee once")
	check(w.tax_exempt_active(), "reward opens the tax-exempt window")
	check(int(w._admin_day_left("tax_exempt_until")) == days, "reward window lasts the configured days")
	check(is_equal_approx(float(m.state.ledger.expenses) - expenses_before, cost), "reward is booked as one expense, not two")
	check(not bool(w.can_perform("admin_reward").ok), "reward cannot stack while it is running")
	check(not bool(w.perform("admin_reward").get("ok", false)), "a second reward is rejected without a charge")
	check(is_equal_approx(float(m.state.cash), 10000.0 - cost), "the rejected reward charges nothing")

	var poor = fixture(3)
	poor.state.cash = 10.0
	check(not bool(poor.full_rules.world.can_perform("admin_reward").ok), "reward is blocked without enough cash")
	check(not bool(poor.full_rules.world.perform("admin_reward").get("ok", false)), "an unaffordable reward does nothing")
	check(is_equal_approx(float(poor.state.cash), 10.0), "an unaffordable reward charges nothing")

	var idle = fixture(3)
	idle.full_rules.world.admin().tax_exempt_until = int(idle.state.total_minutes) - 1
	check(bool(idle.full_rules.world.can_perform("admin_reward").ok), "an expired reward can be bought again")


func _crime_tests() -> void:
	var m = fixture(7)
	var w = m.full_rules.world
	var cap: float = w.risk_max()
	var per_pay: float = float(m.balance.get("admin.risk_per_pay", 25))
	var per_reward: float = float(m.balance.get("admin.risk_per_reward", 20))
	var relief: float = float(m.balance.get("admin.risk_relief_refuse", 15))

	_pay_levy(m, 7)
	check(is_equal_approx(w.admin_risk(), per_pay), "paying a kickback leaves one line on the risk trail")
	check(not w.risk_capped(), "a single payment does not build a case")
	_refuse_levy(m, 14)
	check(is_equal_approx(w.admin_risk(), maxf(0.0, per_pay - relief)), "refusing a levy erases part of the trail")
	check(bool(w.perform("admin_reward").get("ok", false)), "the reward still executes while the trail is short")
	check(is_equal_approx(w.admin_risk(), maxf(0.0, per_pay - relief) + per_reward), "rewarding the tax officer adds to the trail")

	var day := 21
	for i in range(3):
		_pay_levy(m, day)
		day += 7
	check(w.risk_capped(), "repeated kickbacks max out the risk trail")
	check(is_equal_approx(w.admin_risk(), cap), "risk never climbs past its ceiling")
	check("admin_crime" in _queued_ids(m), "maxing out the trail queues the criminal case at once")

	var cash_before: float = float(m.state.cash)
	var minute_before: int = int(m.state.total_minutes)
	var days: int = int(m.balance.get("admin.crime_detention_days", 7))
	var min_fine: float = float(m.balance.get("admin.crime_min_fine", 600))
	var ratio: float = float(m.balance.get("admin.crime_cash_ratio", 0.4))
	var expected_fine: float = minf(cash_before, maxf(min_fine, cash_before * ratio))
	var case: Dictionary = w.choose("accept")
	check(bool(case.get("ok", false)), "the criminal case can be acknowledged")
	check(int(m.state.reputation) == 0, "the case wipes reputation to zero")
	check(float(m.state.cash) <= cash_before - expected_fine + 0.01, "the case confiscates at least the configured share of cash")
	check(int(m.state.total_minutes) == minute_before, "main-only closure does not skip regional time")
	check(int(w.admin().sealed_until) - minute_before == days * 1440, "the main shop closes for the configured days")
	check(not m.business_open(), "the main shop cannot trade during its closure")
	check(is_equal_approx(w.admin_risk(), 0.0), "the case resets the risk trail")
	check(not w.pr_active(), "the case voids the standing kickback window")
	check(not w.tax_exempt_active(), "the case voids the standing tax exemption")
	check(w.validate_state(m.state.world, m.employees, int(m.state.total_minutes)), "a criminal case survives save validation")
	var case_def: Dictionary = {}
	for definition in m.events:
		if str(definition.id) == "admin_crime": case_def = definition
	check(not case_def.is_empty(), "the criminal case is defined")
	check(not w._eligible(case_def, "day", {}), "the case cannot follow itself once the trail resets")

	var calm = fixture(7)
	var quiet = calm.full_rules.world
	check(not quiet._eligible(case_def, "day", {}), "the case is closed while the trail is short")
	quiet.admin().risk = quiet.risk_max()
	check(quiet._eligible(case_def, "day", {}), "the case opens once the trail is maxed out")
	quiet.on_hook("day")
	check("admin_crime" in _queued_ids(calm), "a maxed trail loaded from a save is picked up by the next day hook")

	var broke = fixture(7)
	broke.state.cash = 120.0
	var bw = broke.full_rules.world
	bw.admin().risk = bw.risk_max()
	bw._enqueue("admin_crime", {})
	bw.choose("accept")
	check(float(broke.state.cash) >= 0.0, "the confiscation never drives cash below zero")
	check(int(broke.state.reputation) == 0, "a broke shop still loses its reputation")


func _save_tests() -> void:
	var m = fixture(7)
	var w = m.full_rules.world
	_to_day(m, 7)
	_clear(m, "admin_levy")
	w._enqueue("admin_levy", {})
	w.choose("pay")
	check(w.validate_state(m.state.world, m.employees, int(m.state.total_minutes)), "paid levy survives save validation")
	w.perform("admin_reward")
	check(w.validate_state(m.state.world, m.employees, int(m.state.total_minutes)), "rewards survive save validation")
	var snapshot: Dictionary = w.snapshot()
	check(bool(snapshot.get("admin", {}).get("pr_active", false)), "the panel snapshot reports an active公关 window")
	check(bool(snapshot.get("admin", {}).get("tax_exempt", false)), "the panel snapshot reports the tax-exempt window")
	check(int(snapshot.get("admin", {}).get("next_levy_day", 0)) == 14, "the panel snapshot points at the next levy day")
