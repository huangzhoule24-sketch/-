extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
const Language=preload("res://scripts/services/localization.gd")
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(ok: bool,message: String):
 checks+=1
 if not ok:failures.append(message);push_error(message)
func fresh():
 var m=Model.new(20261108);m.start_full();m.state.cash=10000.0
 m.state.tutorial={"version":2,"finished":true,"skipped":false,"completed_steps":["welcome","staff","promotion","first_order","income","bill"],"deferred":[],"actions":[],"stage_completed":[],"panel_opened":[],"panel_closed":[],"seen_stage":0}
 return m
func near(a: float,b: float,message: String):expect(absf(a-b)<.011,message)
func settle():
 for i in range(12):await process_frame
func control(ui,id):
 for b in ui._qa_buttons:
  if is_instance_valid(b)and not b.is_queued_for_deletion()and b.get_meta("qa_id","")==id:return b
 return null
func check_scope():
 var m=fresh();var w=m.full_rules.world
 m.state.total_minutes=13*1440+720;m.full_rules.revision18.apply_state("low_cleanliness")
 for rid in["india","nordic","greece"]:
  var r=m.full_rules.international
  expect(r.perform("int_open",{"region":rid}).ok,rid+" original opening is available")
  r.s().active_scene=rid
  for id in["wet_floor","food_safety","admin_levy","admin_crime"]:
   var def=w._definition(id);expect(not w._eligible(def,str(def.trigger.hooks[0]),{}),rid+" excludes main-only event "+id)
  expect(not w.can_perform("admin_reward").ok,rid+" rejects administrative payment")
  var cash=float(m.state.cash);var expense=float(m.state.ledger.expenses)
  var requested={"id":900,"dish_id":r.definition("regions",rid).dishes[0],"quantity":1}
  r.region(rid).orders.append(requested);var sale_before=float(r.region(rid).revenue)
  r.recognize_payment(rid,requested,0)
  var gross=float(r.region(rid).revenue)-sale_before
  near(float(m.state.cash)-cash,gross-.5,rid+" settlement preserves its original cash and service charge")
  near(float(m.state.ledger.expenses)-expense,.5,rid+" has no main-shop tax expense")
  expect(r.region(rid).hired.size()>=2 and not r.floor.available_workers(rid,"chef").is_empty(),rid+" opening chef and recruitment remain")
 m.full_rules.international.s().active_scene="main"
 var cash=float(m.state.cash);var expenses=float(m.state.ledger.expenses)
 w.collect_sales_receipt(100)
 near(float(m.state.cash),cash-5,"main checkout withholds configured tax")
 near(float(m.state.ledger.expenses),expenses+5,"main tax records once as expense")
 w._enqueue("wet_floor",{});m.full_rules.international.s().active_scene="india"
 expect(w.pending_event().is_empty(),"a queued main claim stays deferred while abroad")
 m.full_rules.international.s().active_scene="main"
 expect(w.pending_event().get("id","")=="wet_floor","returning to main restores its pending claim")
 w.choose("settle")
func check_closure():
 var m=fresh();var r=m.full_rules.international;var w=m.full_rules.world
 m.state.total_minutes=720;r.perform("int_open",{"region":"india"});var data=r.region("india")
 data.auto_recipe=str(r.definition("regions","india").dishes[0]);
 var before=int(m.state.total_minutes);var paid=int(data.served)
 m.seal_shop_days(7)
 expect(int(m.state.total_minutes)==before,"main closure never skips shared calendar")
 expect(not m.business_open()and m.business_hours_open(),"main closure preserves the regional business-hours clock")
 m._spawn_customer();expect(m.customers.is_empty(),"forced main spawning cannot bypass closure")
 r.s().active_scene="india";m.balance["customer.base_flow"]=0
 for i in range(220):
  m.state.total_minutes+=1;r.tick()
 expect(int(data.served)>paid,"regional diners complete real payments during main closure")
 expect(m.customers.is_empty(),"regional trading does not reopen main eatery")
 var deadline=int(w.admin().sealed_until)
 m.state.total_minutes=deadline-1;expect(w.main_shop_sealed(),"closure lasts until exact deadline")
 m.state.total_minutes=deadline;expect(not w.main_shop_sealed(),"main reopens at exact deadline")
func check_save():
 var m=fresh();var w=m.full_rules.world
 m.state.world.erase("legal");m.state.world.erase("admin")
 var path="user://legal-merge-old.json"
 expect(m.save_game(path),"baseline save without legal fields writes")
 var copy=fresh();expect(copy.load_game(path),"baseline save without legal fields migrates")
 near(copy.full_rules.world.cleanliness(),100,"baseline migration starts at full cleanliness")
 expect(copy.full_rules.world.admin().risk==0,"baseline migration has no inherited risk")
 m.state.world.admin={"pr_until":1200,"paid_total":500.0};m.state.world.legal={"cleanliness":80.0}
 expect(m.save_game(path),"partial incoming legal save writes")
 copy=fresh();expect(copy.load_game(path),"partial incoming legal save gains new fields")
 near(copy.full_rules.world.admin().paid_total,500,"migration preserves original administrative history")
 near(copy.full_rules.world.cleanliness(),80,"migration preserves original cleanliness")
 var bad=copy.state.world.duplicate(true);bad.admin.risk="broken"
 expect(not w.validate_state(bad,copy.employees,int(copy.state.total_minutes)),"invalid administrative risk is rejected")
 copy.seal_shop_days(7);expect(copy.save_game(path),"main closure writes")
 var restored=fresh();expect(restored.load_game(path),"main closure survives real save validation")
 expect(restored.full_rules.world.main_shop_sealed(),"loaded main closure stays active")
 DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
func check_language():
 var locale=Language.new("user://legal-language-fixture.cfg");locale.language="en"
 var token=RegEx.new();token.compile("(?<!%)%(?!%)[+\\-0-9.]*[dsfi]")
 var strings=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/legal-localization.json"))
 for source in strings:
  var sample=str(source);var found=token.search_all(sample)
  for i in range(found.size()-1,-1,-1):
   var item=found[i];var value="ARG"if item.get_string().ends_with("s")else"17.25"if item.get_string().ends_with("f")else"23"
   sample=sample.left(item.get_start())+value+sample.substr(item.get_end())
  sample=sample.replace("%%","%")
  expect(locale.chinese.search(locale.translate(sample))==null,"legal English copy: "+str(source))
func check_ui():
 for dims in[Vector2i(1280,800),Vector2i(390,844),Vector2i(844,390)]:
  root.size=dims;var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle();ui.return_to_restaurant();await settle()
  for name in["法务","行政"]:
   ui.open_panel(name);await settle()
   expect(ui.panel_name==name,str(dims)+" opens main "+name)
   expect(ui.modal_window.get_global_rect().end.x<=ui.size.x+2,str(dims)+" legal drawer fits width")
   var texts=[];ui._qa_interface_texts(ui.modal_body,texts)
   expect(texts.any(func(t):return str(t).contains("100"))or name=="行政","legal summary reads actual cleanliness")
   ui.return_to_restaurant();await settle();expect(ui.panel_name.is_empty(),"legal page returns to restaurant")
  ui.open_panel("更多");await settle();expect(control(ui,"full:open:法务")!=null,"main More contains legal entry")
  var r=ui.model.full_rules.international;r.perform("int_open",{"region":"india"});ui.scene_switcher.visit("india");await settle()
  ui.open_panel("更多");await settle();expect(control(ui,"full:open:法务")==null and control(ui,"full:open:行政")==null,"regional More excludes legal entries")
  ui.close_panel();ui.open_panel("法务");expect(ui.panel_name!="法务","regional direct legal route is blocked")
  ui.queue_free();await settle()
func run():
 check_scope();check_closure();check_save();check_language();await check_ui()
 print("Legal merge: "+JSON.stringify({"checks":checks,"failures":failures}))
 quit(0 if failures.is_empty()else 1)
