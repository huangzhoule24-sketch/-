#!/usr/bin/env python3
"""Run relevant campaign/UI regressions with isolated user data per suite."""
import concurrent.futures,json,os,re,shutil,subprocess,tempfile,time
from pathlib import Path
from package_release import ROOT,BUILD,game_source_fingerprint,write_json
SUITES='''run_tests campaign_tests management_tests v13_management_tests expansion_tests
event_tests skill_coverage_tests animation_tests asset_tests tutorial_tests ui_smoke
save_migration_tests balance_tests navigation_tests story_tests world_completion_tests
ui_requirements_tests core_completion_tests customer_preference_tests culture_tests
culture_ui_tests v15_customer_tests v15_finance_tests v15_event_tests v15_story_synergy_tests
v15_ui_tests v15_integration_tests more_navigation_tests v16_experience_tests v171_rules_tests
v171_guest_tests v171_ui_tests v18_rules_tests v18_ui_tests v19_rules_tests v19_ui_tests
v191_rules_tests v191_ui_tests v191_stress_tests v193_rules_tests v193_assets_tests
v193_ui_tests v195_interaction_tests art_pack_tests seat_layer_tests cultural_experience_tests
cultural_experience_ui_tests cultural_advanced_tests audio_tests culture_refresh_tests
free_sfx_tests pixel_interaction_tests startup_tests music_settings_tests menu_review_tests
portrait_framing_tests mobile_touch_tests inventory_return_tests international_tests
international_ui_tests branch_floor_tests branch_scene_ui_tests branch_r2_tests
legal_tests admin_tests legal_merge_tests'''.split()
def run(name):
 out=BUILD/'legal-r1/native';out.mkdir(parents=True,exist_ok=True)
 data=Path(tempfile.mkdtemp(prefix=name+'-',dir='/tmp'));log=out/(name+'.log');started=time.monotonic()
 try:
  with log.open('w')as f:
   try:
    result=subprocess.run(['godot','--headless','--path',str(ROOT),'--max-fps','0','--script','res://tests/'+name+'.gd'],cwd=ROOT,env={**os.environ,'XDG_DATA_HOME':str(data)},stdout=f,stderr=subprocess.STDOUT,timeout=180)
    code=result.returncode
   except subprocess.TimeoutExpired:code=124
  text=log.read_text();errors=[s for s in text.splitlines()if'SCRIPT ERROR'in s or s.startswith('ERROR:')or'Parse Error'in s]
  report={'suite':name,'exit':code,'ok':code==0 and not errors,'seconds':round(time.monotonic()-started,2),'errors':errors[:12],'last_line':text.strip().splitlines()[-1]if text.strip()else''}
  print(json.dumps(report,ensure_ascii=False),flush=True);return report
 finally:shutil.rmtree(data)
def main():
 import argparse
 p=argparse.ArgumentParser();p.add_argument('suites',nargs='*');a=p.parse_args()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(run,a.suites or SUITES))
 report={'game_source':game_source_fingerprint(),'suites':results,'failures':[x['suite']for x in results if not x['ok']],
  'language_scope':'New legal copy and actual main-only legal UI are covered by legal_merge_tests. The older global candidate audit also scans already-bilingual regional source literals; its initial diagnostic is retained separately, not reported as passing.'}
 write_json(BUILD/'legal-r1/native-regressions.json',report)
 if report['failures']:raise SystemExit(1)
if __name__=='__main__':main()
