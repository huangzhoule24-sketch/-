extends SceneTree
## Explicit, paused layout fixtures; these images do not claim natural day-14 progress.
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
const Language=preload("res://scripts/services/localization.gd")
var ui
func _init():call_deferred("run")
func settle():
 for n in range(20):await process_frame
func capture(name):
 await settle();ui.modal_body.get_parent().scroll_vertical=0;await settle();await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png("res://build/legal-r1/"+name+".png")
func run():
 root.size=Vector2i(1280,800);ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 await settle();ui.localization=Language.new("user://legal-capture-language.cfg");ui.localization.language="zh"
 ui.return_to_restaurant();await capture("main-officer-desktop")
 ui.open_panel("法务");await capture("legal-desktop")
 root.size=Vector2i(390,844);ui.update_ui_layout();ui.refresh();await capture("legal-phone")
 ui.open_panel("行政");await capture("admin-phone")
 ui.localization.language="en";ui.open_panel("法务");ui.localization.apply_tree(ui);await capture("legal-phone-en")
 ui.localization.language="zh";ui.close_panel();ui.model.state.total_minutes=13*1440+720
 ui.model.full_rules.world.legal().cleanliness=55;ui.model.full_rules.revision18.apply_state("low_cleanliness")
 ui.model.full_rules.world._enqueue("wet_floor",{});ui.open_panel("事件");await capture("civil-case-phone-fixture")
 ui.model.state.world.queue.clear();ui.model.seal_shop_days(7);ui.open_panel("行政");await capture("main-closure-phone-fixture")
 ui.queue_free();await settle();quit()
