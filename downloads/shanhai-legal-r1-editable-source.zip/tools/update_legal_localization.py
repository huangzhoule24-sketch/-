#!/usr/bin/env python3
"""Add the main-shop legal module's copy without changing existing translations."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
COPY={
"主店查封中":"Main eatery sealed",
"主店查封餐点报损":"Meals written off during the main eatery's closure",
"法务":"Legal affairs",
"行政":"Administration",
"%s，风险值 %.0f/%.0f。":"%s; risk %.0f/%.0f.",
"风声渐紧：账上的打点已到 %.0f/%.0f，再交几次就要出事。":"An investigation is approaching: recorded payments have raised risk to %.0f/%.0f.",
"保洁度%+.0f → %.0f":"Cleanliness %+.0f → %.0f",
"保洁度回升到%.0f，「低保洁度」已解除。":"Cleanliness recovered to %.0f; low cleanliness cleared.",
"后厨彻底清洁，保洁度回升到%.0f。":"Kitchen cleaning completed; cleanliness recovered to %.0f.",
"法务赔偿":"Civil compensation",
"赔付￥%.2f，其中现金支付￥%.2f%s。":"Compensation: %.2f; cash paid: %.2f%s.",
"，欠款￥%.2f 记入待付赔偿":", with %.2f recorded as unpaid compensation",
"獬豸查验后厨与检查记录：保洁度%.0f，%s（安全线%.0f）。":"Xiezhi examines the kitchen and inspection records: cleanliness %.0f; %s (threshold %.0f).",
"达到安全线，当庭胜诉":"threshold met; case won",
"未达安全线，当庭败诉":"threshold not met; case lost",
"獬豸查勘现场：%s。":"Xiezhi examines the premises: %s.",
"店内已放置安全提示牌，认定尽到警示义务，当庭胜诉":"a completed safety sign meets this game's warning requirement; case won",
"店内没有安全提示牌，认定未尽到警示义务，当庭败诉":"no completed safety sign meets this game's warning requirement; case lost",
"卫生检查连续未通过，获得「低保洁度」：期间可能触发店内湿滑与食品安全事件，清洁后厨可提前解除。":"Repeated inspection failures caused low cleanliness. Slippery-floor and food-safety claims may occur; kitchen cleaning can clear it early.",
"保洁度":"Cleanliness",
"税":"Tax",
"公关钱已交：接下来%d天卫生检查通过率提高%.0f个百分点。":"Payment made: for %d days, inspection success gains %.0f percentage points.",
"又付了一笔打点钱，账上留下把柄":"another illicit payment left a record",
"拒绝了公关钱：此后卫生检查通过率下降%.0f个百分点。":"Payment refused: subsequent inspection success falls by %.0f percentage points.",
"一笔钱没给，账上少一条可查的记录":"refusing payment reduced the incriminating trail",
"已犒劳：%d天内不再扣经营所得税。":"Tax officer paid: no main-eatery turnover tax for %d days.",
"请税吏喝了一顿，人情账也记上了一笔":"paying the tax officer added to the incriminating trail",
"经营所得税":"Main-eatery turnover tax",
"刑事抄没":"Confiscation",
"抄没家产：￥%.0f，原有现金￥%.0f。":"Cash confiscated: %.0f; cash before confiscation: %.0f.",
"主店查封%d日，房租与工钱按正常日结支付；跨国食肆继续经营。":"The main eatery is sealed for %d days. Rent and wages remain in ordinary daily accounts; regional eateries continue trading.",
"声望由 %d 清零。":"Reputation reset from %d to zero.",
"此前的打点与免税一并作废，风险值归零，第 %d 天才准重开。":"Previous arrangements and tax exemption are cancelled; risk resets. Reopening is permitted on day %d.",
"本次卫生检查通过概率%.0f%%（%s，%s）。":"Inspection success chance: %.0f%% (%s; %s).",
"公关打点生效":"illicit arrangement active",
"无人照应":"no arrangement",
"尚未被盯上":"no levy encountered yet",
"法务与行政操作暂只在主店开放。":"Legal and administrative actions are currently available only at the main eatery.",
"主店仍在查封期间。":"The main eatery is still sealed.",
"刚犒劳过，还剩%d天免税":"Tax exemption already active: %d days remaining",
"现金不足￥%.0f":"Requires %.0f cash",
"已犒劳：%d天内不再扣经营所得税":"Tax officer paid: no main-eatery turnover tax for %d days",
"交￥%.0f打点，卫生检查通过率+%.0f个百分点，风险值+%.0f":"Pay %.0f: inspection success +%.0f percentage points; risk +%.0f",
"拒绝打点，卫生检查通过率-%.0f个百分点，风险值-%.0f":"Refuse payment: inspection success -%.0f percentage points; risk -%.0f",
"支付￥%.0f犒劳税吏，%d天免经营所得税，风险值+%.0f":"Pay the tax officer %.0f: %d days exempt from main-eatery turnover tax; risk +%.0f",
"主店查封%d日、抄没现银的%.0f%%、声望清零；其他店继续经营":"Seal the main eatery for %d days, confiscate %.0f%% of cash and reset reputation; other eateries continue trading",
"税吏":"Tax officer",
"主店法务 · 民事板块。地面湿滑、菜里异物可能引发索赔。下列胜负条件是架空游戏中的简化规则，供经营选择与课堂讨论使用。":"Main eatery · civil affairs. Slippery floors and foreign objects in food may lead to claims. The following outcomes use simplified fictional rules for gameplay and classroom discussion.",
"民事 · 店内安全":"Civil affairs · premises safety",
"保洁度越低越容易出问题。卫生检查连续未通过会获得「低保洁度」，期间可能触发店内湿滑与食品安全事件。":"Repeated inspection failures can cause low cleanliness, allowing slippery-floor and food-safety claims to occur.",
"保洁度 %.0f / %.0f · %s":"Cleanliness %.0f / %.0f · %s",
"低保洁度 · 剩%d分钟":"Low cleanliness · %d minutes remaining",
"正常":"Normal",
"卫生检查连续未通过 %d / %d 次。后厨彻底清洁可把保洁度拉回，并提前解除低保洁度。":"Consecutive inspection failures: %d / %d. Thorough kitchen cleaning restores cleanliness and may clear the condition early.",
"民事案件自第 %d 天起开放；此前的卫生检查只影响声望与罚款。":"Civil claims become available on day %d; earlier inspections do not unlock these cases.",
"安全提示牌：%s。%s":"Safety sign: %s. %s",
"已放置":"Installed",
"未放置":"Not installed",
"店内湿滑的法庭对决必胜，胜诉后客流先抑后扬。":"Under this game's rules, the slippery-floor case is won; traffic initially falls, then rebounds.",
"法庭对决会败诉：赔钱、扣声望、客流压低三天。":"Under this game's rules, the case is lost: compensation, reputation loss and three days of reduced traffic.",
"前往装修 · 安全提示牌 ￥%.0f":"Open furnishings · safety sign %.0f",
"案件记录":"Case history",
"已上公堂 %d 次 · 胜诉 %d · 败诉 %d。胜负只看证据：湿滑看是否放置提示牌，食品安全看保洁度是否达 %.0f。":"Court cases %d · won %d · lost %d. Game criteria: a completed sign for slippery-floor claims; cleanliness at least %.0f for food-safety claims.",
"还没有发生过民事索赔。":"No civil claims recorded.",
"第%d天 · %s · %s":"Day %d · %s · %s",
"待付赔偿与罚款":"Unpaid compensation and fines",
"尚未结清 ￥%.2f。未付部分不影响营业，但会一直挂在账上；结清后案件才算真正了结。":"Outstanding: %.2f. The unpaid balance remains on record until settled; trading may continue.",
"补缴 ￥%.2f":"Settle %.2f",
"提示：店内湿滑与食品安全事件都只会在「低保洁度」期间出现，且不会早于第 %d 天。保持卫生检查通过、定期清洁后厨，就能让这两个事件无事可做。":"Slippery-floor and food-safety claims require low cleanliness and cannot occur before day %d. Maintain inspections and clean the kitchen regularly.",
"主店行政 · 公关与税务。本页为架空游戏规则：市衙周期摊派与打点会积累风险。税务仅作用于主店堂食，跨国食肆沿用原有规则。":"Main eatery · administration and tax. These fictional rules model periodic levies and the risk of illicit payments. Tax applies only to main-eatery dining; regional eateries retain their existing rules.",
"主店查封中 · 剩 %d 天。其他店照常经营，时间不会直接跳过。":"Main eatery sealed · %d days remaining. Other eateries trade normally; the calendar is not skipped.",
"行政公关":"Administrative levy",
"第 %d 天起每 %d 天上门一次。交钱后卫生检查更容易通过；拒绝则检查员格外苛刻。之前的检查只看后厨准备，之后还要看有没有打点。":"Starting on day %d, a levy arrives every %d days. Under this fictional system, paying improves inspection odds while refusal reduces them.",
"已打点 · 剩 %d 天":"Arrangement active · %d days remaining",
"无人照应 · 检查通过率 -%.0f%%":"No arrangement · inspection chance -%.0f percentage points",
"下一次摊派：第 %d 天 · 行价 ￥%.0f":"Next levy: day %d · payment %.0f",
"交钱后卫生检查通过率 +%.0f 个百分点；拒绝后 -%.0f 个百分点。连续两次检查未通过仍会进入低保洁度。":"Payment: inspection chance +%.0f percentage points; refusal: -%.0f percentage points. Repeated failures can still cause low cleanliness.",
"累计打点 ￥%.0f · 已拒绝 %d 次":"Total levy payments %.0f · refusals %d",
"风险值":"Risk",
"打点和犒劳都会在账上留下痕迹。痕迹攒满，刑房就上门：抄没现款、查封七日、声望清零。拒绝一次摊派，能抹掉一笔可查的记录。":"Illicit payments leave evidence. At maximum risk, cash is confiscated, the main eatery closes for seven days and reputation resets. Refusal reduces risk.",
"每交一次公关钱 +%.0f · 每犒劳一次 +%.0f · 拒绝摊派 −%.0f":"Each levy payment +%.0f · each officer payment +%.0f · each refusal -%.0f",
"爆表后果：抄没现款 %.0f%%、查封 %d 日（房租工钱照付）、声望清零、打点与免税一并作废。":"At maximum risk: confiscate %.0f%% of cash, seal the main eatery for %d days with ordinary rent and wages, reset reputation and cancel arrangements and tax exemption.",
"账已经查上了门，下一次见面就是抄家。":"The case is queued; confiscation is pending.",
"已被抄家 %d 次。":"Confiscation cases: %d.",
"主店经营所得税":"Main-eatery turnover tax",
"主店堂食营业额扣取 %.0f%%，营业额仍按全额记账，税款单列费用。跨国店、分店与外卖不应用本轮新增税务规则。":"Main-eatery dining turnover is taxed at %.0f%%. Gross sales remain intact and tax is a separate expense. Regional eateries, branches and delivery retain their previous tax treatment.",
"免税中 · 剩 %d 天":"Exempt · %d days remaining",
"照常征税":"Tax collected normally",
"已犒劳 · 剩 %d 天":"Officer payment active · %d days remaining",
"犒劳税吏 ￥%.0f · 免 %d 天":"Pay officer %.0f · %d days exempt",
"累计犒劳 %d 次 · ￥%.0f":"Officer payments: %d · total %.0f",
"提示：税吏站在店门外的街上，点他也能直接犒劳。犒劳只在免税到期后才能再点，不能叠加。":"Select the tax officer outside the main eatery to open this panel. Payment cannot be repeated while an exemption is active.",
"脏":"Dirty",
"保洁度 %.0f/%.0f · 卫生检查连续未通过 %d/%d 次 · 安全提示牌%s":"Cleanliness %.0f/%.0f · inspection failures %d/%d · safety sign %s",
"查看法务":"Open legal affairs",
"安全提示牌":"Safety sign",
"牌":"Sign",
"「小心地滑」警示牌。店内已放置时，店内湿滑碰瓷案的法庭对决必胜；未放置则必败。":"A wet-floor warning sign. In this game's simplified slippery-floor case, a completed sign wins the case; without it the case is lost.",
"店内湿滑":"Slippery floor",
"地面湿滑，一位客人在店里摔了一跤，捂着腰要求赔偿。他开口就是一套熟练的价码，倒像是摔惯了的。可以私下赔钱了事，也可以请獬豸在公堂上分辨这一跤究竟该谁负责。":"A guest slips on the floor and demands compensation. Settle privately or ask Xiezhi to hear the dispute under this game's rules.",
"赔一点小钱：付30元了事，不进公堂":"Settle privately: pay 30 without a hearing",
"法庭对决：不赔，对簿公堂（店内已放置安全提示牌则胜诉）":"Court hearing: a completed safety sign wins under the game rules",
"胜诉后客流回升":"Traffic rebound after winning the case",
"食品安全":"Food safety",
"客人在菜里挑出一根不属于这道菜的东西，要求赔偿，扬言要举报。后厨经不经得起查，取决于眼下的保洁度是否过关。":"A guest finds a foreign object in a dish and demands compensation. The kitchen's current cleanliness determines the case under this game's rules.",
"赔一点小钱：赔80元并道歉，声望-3":"Settle and apologise: pay 80; reputation -3",
"法庭对决：接受检查，保洁度≥60可胜诉":"Accept inspection: cleanliness at least 60 wins under the game rules",
"第7天起每7天，市衙的协办都会上门「例行联络」。交钱，往后一周的卫生检查会睁一只眼闭一只眼；不交，检查员会格外仔细。":"From day 7, a fictional official demands payment every seven days. Payment improves inspection odds for a week; refusal leads to harsher inspections.",
"交钱打点：一周内卫生检查更容易通过":"Pay: improve inspection odds for one week",
"拒绝：一分不给，检查时处处被卡":"Refuse: no payment; harsher inspections",
"刑事案：查封与抄没":"Criminal case: closure and confiscation",
"打点的次数太多，账册被一并查走。新来的主事不认旧账：铺子当场贴封条，家产折价抄没，攒了许久的名声一夜清零。七日之后才准重新开张。":"Repeated illicit payments have prompted an investigation. The main eatery is sealed for seven days, cash is confiscated and reputation resets.",
"认罚：交钱、关店七日":"Accept penalty: confiscation and seven-day main-eatery closure",
"行政与公关":"Administration and levies",
"法务与合规":"Legal affairs and compliance",
"低保洁度":"Low cleanliness",
"卫生检查连续未通过，店内保洁度跌破安全线。期间可能触发店内湿滑与食品安全事件；后厨清洁或把保洁度恢复到70以上可提前解除。":"Repeated inspection failures reduced cleanliness below the safety threshold. Slippery-floor and food-safety claims may occur. Kitchen cleaning or recovery to at least 70 can clear the condition early.",
}
TOKEN=re.compile(r'%%|%[+\-0-9.]*[dsfi]')
def pattern(zh,en):
 matches=list(TOKEN.finditer(zh));captures=[m for m in matches if m[0]!='%%']
 if not captures:return None
 # This one prose translation must preserve argument order like every other.
 pieces=[];pos=0;index=0
 for m in matches:
  pieces.append(re.escape(zh[pos:m.start()]));pos=m.end()
  if m[0]=='%%':pieces.append('%');continue
  index+=1;pieces.append('(.+?)'if m[0].endswith('s')else'([+−-]?[0-9]+(?:\\.[0-9]+)?)')
 pieces.append(re.escape(zh[pos:]));number=0
 def repl(m):
  nonlocal number
  if m[0]=='%%':return '%'
  number+=1;return '{'+str(number)+'}'
 result=TOKEN.sub(repl,en)
 assert number==len(captures),(zh,en)
 return {'regex':'^'+''.join(pieces)+'$','en':result}
def main():
 p=ROOT/'config/localization.json';data=json.loads(p.read_text());new=[]
 for zh,en in COPY.items():
  data['strings'][zh]=en
  item=pattern(zh,en)
  if item:new.append(item)
 replaced={x['regex']for x in new};data['patterns']=new+[x for x in data['patterns']if x['regex']not in replaced]
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 fixture=ROOT/'tests/fixtures/legal-localization.json'
 fixture.write_text(json.dumps(list(COPY),ensure_ascii=False,indent=2)+'\n')
 print(f'Updated {len(COPY)} legal translations and {len(new)} formatted patterns.')
if __name__=='__main__':main()
