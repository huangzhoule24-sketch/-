extends Control



signal placement_requested(id: String, x: int, y: int)
signal placement_cancelled
signal employee_selected(id: String)
signal admin_npc_selected

var model
var localization
var font: Font
var assets
var placement_validator: Callable
const Rarity = preload("res://scripts/ui/rarity_display.gd")
const Navigation = preload("res://scripts/services/grid_navigation.gd")
const Space = preload("res://scripts/services/restaurant_space.gd")
const ANIMATION_CONFIG_PATH := "res://config/animation.json"
static var _animation_settings: Dictionary = {}
var _actors: Dictionary = {}
var elapsed: = 0.0
var placement_id: = ""
var preview_cell: = Vector2i(-1, -1)
var ink: = Color("354b46")
var green: = Color("528575")
var orange: = Color("c78555")
var _previous_served: = -1
var _previous_revenue: = 0.0
var _coin_popups: Array[Dictionary] = []
var _last_checkout_position: = Vector2.ZERO
var thoughts
var dollhouse
var crowd = preload("res://scripts/ui/crowd_presentation.gd").new()
var scene_labels: Array = []
var scene_label_rects: Array[Rect2] = []
var collect_scene_labels = false
var scene_text_priority = 0
func is_dollhouse() -> bool:return model!=null and model.state.has("revision191")
func house():
	if dollhouse==null:dollhouse=preload("res://scripts/ui/dollhouse_view.gd").new(self)
	return dollhouse

func _ready() -> void :
	mouse_filter = Control.MOUSE_FILTER_PASS
	clip_contents = true
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	resized.connect(func():
		if dollhouse!=null:dollhouse.cancel_gesture())

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT and dollhouse!=null:dollhouse.cancel_gesture()

func _input(event: InputEvent) -> void:
	if is_dollhouse()and house().regional_view()!=null:return
	if not is_dollhouse() or not placement_id.is_empty():return
	if not (event is InputEventScreenTouch or event is InputEventScreenDrag):return
	var ui=house().host()
	if ui==null or not ui.panel_name.is_empty() or ui.landscape_required:
		house().cancel_gesture();return
	var local=event.xformed_by(get_global_transform_with_canvas().affine_inverse())
	if event is InputEventScreenTouch and event.pressed:
		# The guide overlays the map. Let its buttons and ScrollContainer receive
		# their own gesture instead of starting a camera drag underneath it.
		if ui.tutorial_overlay!=null:
			var guide=ui.tutorial_overlay.tutorial_card
			if guide.is_visible_in_tree() and guide.get_global_rect().has_point(event.position):return
		if not house().content_rect().has_point(local.position):return
		# Pickups retain their own click targets. Once a map gesture starts, its
		# moves and releases stay captured even after leaving the map rectangle.
		for child in get_children():
			if child.get_script()!=null and child.get_script().resource_path.ends_with("pickup_overlay.gd"):
				for button in child.buttons.values():
					if button.is_visible_in_tree() and button.get_global_rect().has_point(event.position):return
	elif not house().touches.has(event.index):return
	house().input(local)
	get_viewport().set_input_as_handled()

func set_placement(id: String) -> void :
	placement_id = id
	preview_cell = Vector2i(-1, -1)
	mouse_filter = Control.MOUSE_FILTER_STOP if not id.is_empty() else Control.MOUSE_FILTER_PASS
	tooltip_text = ""
	queue_redraw()

func _process(delta: float) -> void :
	if model == null: return
	if is_dollhouse()and house().regional_view()!=null:
		queue_redraw();return
	var visual_delta := _visual_delta(delta)
	elapsed += visual_delta
	_update_employee_animation(visual_delta)
	_resolve_actor_spacing(visual_delta)
	if thoughts == null: thoughts = preload("res://scripts/ui/actor_thoughts.gd").new(self)
	thoughts.update(delta)
	for index in range(_coin_popups.size() - 1, -1, -1):
		_coin_popups[index].age = float(_coin_popups[index].age) + visual_delta
		if float(_coin_popups[index].age) >= 1.8: _coin_popups.remove_at(index)
	_track_checkout()
	if placement_id.is_empty():
		_update_guest_tooltip()
	else:
		preview_cell = cell_at(get_local_mouse_position())
	queue_redraw()

func _gui_input(event: InputEvent) -> void :
	if is_dollhouse()and house().regional_view()!=null:return
	if is_dollhouse() and placement_id.is_empty() and house().input(event):accept_event();return
	if placement_id.is_empty():
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			select_employee_at(event.position)
		return
	if event is InputEventMouseMotion:
		preview_cell = cell_at(event.position)
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_RIGHT:
			placement_cancelled.emit()
			accept_event()
		elif event.button_index == MOUSE_BUTTON_LEFT:
			_request_placement(event.position)
	elif event is InputEventScreenTouch and event.pressed:
		_request_placement(event.position)

func select_employee_at(point: Vector2):
	if point.distance_to(_to_view(officer_point())) <= 28:
		admin_npc_selected.emit()
		return
	for id in _actors:
		var actor: Dictionary=_actors[id]
		if point.distance_to(_to_view(actor.get("display_position",actor.position)))<=24:
			if thoughts==null:thoughts=preload("res://scripts/ui/actor_thoughts.gd").new(self)
			for employee in model.employees:
				if str(employee.id)==str(id):thoughts.speak(employee,true)
			employee_selected.emit(str(id));break

func officer_point() -> Vector2:
	if model == null: return Vector2.ZERO
	return Vector2(float(model.balance.get("admin.npc_x", 300.0)), float(model.balance.get("admin.npc_y", 543.0)))

func _draw_officer(p: Vector2) -> void:
	var image = null
	if assets != null:
		var frames = assets.get_customer_frames("human", "human_03", "idle", "down")
		if not frames.is_empty() and not assets.is_placeholder(frames[0]): image = frames[0]
	draw_circle(p - Vector2(0, 2), 15, Color(0.2, 0.2, 0.2, 0.08))
	if image != null:
		draw_texture_rect(image, Rect2(p - Vector2(32, 77), Vector2(64, 80)), false)
	else:
		draw_circle(p - Vector2(0, 27), 14, Color("a4b9ad"))
		box(Rect2(p - Vector2(12, 16), Vector2(24, 20)), Color("8b95a6"), 4)
	centered_text("税吏", p - Vector2(0, 84), 11, orange)

func _request_placement(position: Vector2) -> void :
	preview_cell = cell_at(position)
	if preview_cell.x >= 0:

		placement_requested.emit(placement_id, preview_cell.x, preview_cell.y)
	accept_event()

func _demo_config() -> Dictionary:
	if model != null and model.has_method("can_place_decoration"): return model.demo_config
	return {}

func _world_scale() -> Vector2:
	if is_dollhouse():return house().linear_scale()
	return size / Space.WORLD_SIZE

func _to_world(position: Vector2) -> Vector2:
	if is_dollhouse():return house().to_world(position)
	return position / _world_scale().max(Vector2(0.001, 0.001))

func _to_view(position: Vector2) -> Vector2:
	if is_dollhouse():return house().to_view(position)
	return position * _world_scale()

func grid_dimensions() -> Vector2i:
	return Space.grid_dimensions(model)

func grid_rect() -> Rect2:
	return Space.grid_rect(model)

func cell_at(position: Vector2) -> Vector2i:
	var bounds := grid_rect()
	var world_position := _to_world(position)
	if not bounds.has_point(world_position): return Vector2i(-1, -1)
	var dimensions := grid_dimensions()
	var local := world_position - bounds.position
	return Vector2i(int(local.x / bounds.size.x * dimensions.x), int(local.y / bounds.size.y * dimensions.y))

func cell_rect(x: int, y: int, columns: int = 1, rows: int = 1) -> Rect2:
	return Space.cell_rect(model, x, y, columns, rows)

func _layout() -> Array:
	return Space.layout(model)

func _tables() -> Array:
	var result: Array = []
	for item in _layout():
		if str(item.get("id", "")) in ["table_two", "table_four"]: result.append(item)
	return result

func table_center(table: int) -> Vector2:
	var tables: = _tables()
	if table < 0 or table >= tables.size(): return grid_rect().get_center()
	var item: Dictionary = tables[table]
	return cell_rect(int(item.x), int(item.y), int(item.get("w", 1)), int(item.get("h", 1))).get_center()

func _seat_position(seat: int) -> Vector2:
	return Space.seat_position(model, seat)

func _chair_position(rect: Rect2, chair: int, capacity: int) -> Vector2:
	return Space.chair_position(rect, chair, capacity)

func _decoration_entry(id: String) -> Dictionary:
	if model != null and model.has_method("can_place_decoration"):
		for item in model.decorations:
			if str(item.get("id", "")) == id: return item
	return {}

func _placement_allowed() -> bool:
	if preview_cell.x < 0 or model == null or not model.has_method("can_place_decoration"): return false
	if placement_validator.is_valid(): return bool(placement_validator.call(placement_id,preview_cell.x,preview_cell.y))
	return bool(model.can_place_decoration(placement_id, preview_cell.x, preview_cell.y))

func text_at(text: String, pos: Vector2, font_size: int = 15, color: Color = Color("687e72")) -> void :
	if localization!=null:text=localization.translate(text)
	if is_dollhouse():
		# Text is rasterized at its readable UI size, never shrunk with the floor sprites.
		var screen_pos: Vector2 = house().to_view(pos).round()
		var readable_size = maxi(14,font_size)
		if collect_scene_labels:
			scene_labels.append({"text":text,"point":screen_pos,"size":readable_size,"color":color,"priority":scene_text_priority})
			return
		draw_set_transform(Vector2.ZERO)
		draw_string_outline(font,screen_pos,text,HORIZONTAL_ALIGNMENT_LEFT,-1,readable_size,2,Color("fffaf0"))
		draw_string(font,screen_pos,text,HORIZONTAL_ALIGNMENT_LEFT,-1,readable_size,color)
		draw_set_transform(house().offset(),0,Vector2.ONE*house().scale_factor())
		return
	draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)

func draw_scene_labels(entities: Array) -> void:
	collect_scene_labels = false
	scene_label_rects.clear()
	var bodies: Array[Rect2] = []
	var scale = house().scale_factor()
	for entity in entities:
		if entity.type in ["staff","guest","leaving"]:
			var foot: Vector2 = house().to_view(entity.point)
			bodies.append(Rect2(foot-Vector2(20,77)*scale,Vector2(40,78)*scale))
	scene_labels.sort_custom(func(a,b):return int(a.priority)>int(b.priority))
	draw_set_transform(Vector2.ZERO)
	for item in scene_labels:
		var extent = font.get_string_size(item.text,HORIZONTAL_ALIGNMENT_LEFT,-1,item.size)
		var height = font.get_height(item.size)
		for shift in [Vector2.ZERO,Vector2(0,-22),Vector2(0,-44)]:
			var baseline: Vector2 = item.point+shift
			var rect = Rect2((baseline-Vector2(4,font.get_ascent(item.size)+2)).round(),Vector2(extent.x+8,height+4).ceil())
			if rect.position.y<54 or not Rect2(Vector2.ZERO,size).encloses(rect): continue
			if bodies.any(func(body):return rect.intersects(body)) or scene_label_rects.any(func(other):return rect.intersects(other.grow(2))): continue
			box(rect,Color("fff8e9"),0,Color("b8b09a"))
			draw_string(font,baseline.round(),item.text,HORIZONTAL_ALIGNMENT_LEFT,-1,item.size,item.color)
			scene_label_rects.append(rect)
			break

func centered_text(text: String, position: Vector2, font_size: int, color: Color) -> void :
	if localization!=null:text=localization.translate(text)
	if is_dollhouse():
		var width = font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,maxi(14,font_size)).x/house().scale_factor()
		text_at(text,position-Vector2(width*.5,0),font_size,color)
		return
	text_at(text, position - Vector2(font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x * 0.5, 0), font_size, color)

func box(rect: Rect2, color: Color, radius: int = 12, border: Color = Color.TRANSPARENT) -> void :
	var style: = StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = 0
	style.corner_radius_top_right = 0
	style.corner_radius_bottom_left = 0
	style.corner_radius_bottom_right = 0
	if border.a > 0:
		style.border_color = border
		style.set_border_width_all(1)
	draw_style_box(style, rect)

func _draw() -> void :
	if model == null or font == null or size.x < 10: return
	if is_dollhouse():house().draw();return
	draw_set_transform(Vector2.ZERO, 0.0, _world_scale())
	box(Rect2(Vector2.ZERO, Space.WORLD_SIZE), Color("eee7d8"), 18)
	var background := _asset_texture("Scenes", "restaurant_stage_%d" % int(model.state.get("stage", 0)))
	if background == null: background = _asset_texture("Scenes", "restaurant")
	if background != null: draw_texture_rect(background, Rect2(Vector2.ZERO, Space.WORLD_SIZE), false)
	var bounds: = grid_rect()
	var dimensions: = grid_dimensions()
	for x in range(dimensions.x + 1):
		var line_x: = bounds.position.x + bounds.size.x * x / dimensions.x
		draw_line(Vector2(line_x, bounds.position.y), Vector2(line_x, bounds.end.y), Color("dfd8c9"), 1)
	for y in range(dimensions.y + 1):
		var line_y: = bounds.position.y + bounds.size.y * y / dimensions.y
		draw_line(Vector2(bounds.position.x, line_y), Vector2(bounds.end.x, line_y), Color("dfd8c9"), 1)
	_draw_stations()
	var occupied: = {}
	for guest in model.customers: occupied[int(guest.get("seat", 0))] = guest
	var table_index: = 0
	var seat_index: = 0
	for item in _layout():
		var rect: = cell_rect(int(item.x), int(item.y), int(item.get("w", 1)), int(item.get("h", 1)))
		if bool(item.get("building",false)):
			box(rect.grow(-4),Color("e7d4ac"),8)
			centered_text("施工中",rect.get_center()+Vector2(0,5),13,orange)
			continue
		if str(item.id) in ["table_two", "table_four"]:
			var capacity: = 4 if str(item.id) == "table_four" else 2
			_draw_table(rect, table_index, seat_index, capacity, occupied)
			table_index += 1
			seat_index += capacity
		else:
			_draw_decoration(str(item.id), rect)
	_draw_employees()
	_draw_officer(officer_point())
	box(Rect2(Space.WORLD_SIZE.x * 0.4, Space.WORLD_SIZE.y - 38, Space.WORLD_SIZE.x * 0.2, 38), Color("f4f0e5"), 6)
	centered_text("有 间 小 馆", Vector2(Space.WORLD_SIZE.x * 0.5, Space.WORLD_SIZE.y - 12), 15, ink)
	plant(Vector2(45, Space.WORLD_SIZE.y - 42))
	plant(Vector2(Space.WORLD_SIZE.x - 45, Space.WORLD_SIZE.y - 42))
	if model.customers.is_empty() and placement_id.is_empty():
		var hint: = "客人正在路上…" if model.business_open() else "稍歇片刻，准备下一场营业"
		centered_text(hint, Vector2(Space.WORLD_SIZE.x * 0.5, bounds.end.y - 13), 13, Color("948b7b"))
	if not placement_id.is_empty(): _draw_placement()
	_draw_coin_popups()

func _draw_stations() -> void :
	box(Rect2(18, 16, Space.WORLD_SIZE.x - 36, 64), Color("dedecd"), 12)
	var stations: = [Vector2(Space.WORLD_SIZE.x * 0.2, 43), Vector2(Space.WORLD_SIZE.x * 0.51, 43), Vector2(Space.WORLD_SIZE.x * 0.8, 43)]
	for i in range(3):
		var p: Vector2 = stations[i]
		box(Rect2(p.x - 36, p.y - 20, 72, 40), Color("f8f5ed"), 8)
		if i == 0:
			draw_circle(p - Vector2(15, 0), 10, Color("e7b688"))
			draw_circle(p + Vector2(15, 0), 10, Color("e7b688"))
			draw_arc(p - Vector2(15, 0), 5, 0, TAU, 20, orange, 2)
		elif i == 1:
			bowl(p, Color("688d77"))
		else:
			box(Rect2(p.x - 17, p.y - 13, 34, 26), Color("819084"), 5)
			box(Rect2(p.x - 12, p.y - 9, 24, 9), Color("cbdabd"), 2)
			text_at("￥", p + Vector2(-6, 11), 13, Color.WHITE)
		centered_text(["后厨", "出餐台", "收银台"][i], p + Vector2(0, 30), 12, ink)

func _draw_table(rect: Rect2, index: int, first_seat: int, capacity: int, occupied: Dictionary) -> void :
	var c: = rect.get_center()
	var table_size: = Space.table_extent(rect)
	var table_texture := _asset_texture("Decorations", "table_four" if capacity == 4 else "table_two")
	if table_texture != null:
		draw_texture_rect(table_texture, Rect2(c - Vector2(42, 36), Vector2(84, 72)), false)
	else:
		box(Rect2(c - table_size * 0.5, table_size), Color("dcc3a2"), 9, Color("c8af8c"))
		box(Rect2(c - table_size * 0.5 + Vector2(5, 5), table_size - Vector2(10, 10)), Color("ebd6b6"), 6)
	centered_text("%02d" % (index + 1), c + Vector2(0, 5), 13, Color("b29470"))
	for chair in range(capacity):
		var p: = _chair_position(rect, chair, capacity)
		box(Rect2(p - Vector2(13, 16), Vector2(26, 32)), Color("c8b598"), 7)
		if occupied.has(first_seat + chair): draw_guest(occupied[first_seat + chair], p, minf(1, rect.size.x / 126.0))

func _draw_decoration(id: String, rect: Rect2) -> void :
	var p: = rect.get_center()
	var decoration_texture := _asset_texture("Decorations", id)
	if decoration_texture != null:
		draw_texture_rect(decoration_texture, rect.grow(-8), false)
		return
	match id:
		"wall_mural":
			box(Rect2(p - Vector2(29, 25), Vector2(58, 50)), Color("c5d4bd"), 6, green)
			draw_arc(p - Vector2(3, 1), 15, 0.2, PI * 1.6, 24, green, 4)
			draw_circle(p + Vector2(11, -10), 6, green)
			draw_circle(p + Vector2(12, -12), 1.7, Color("f8f5ed"))
			centered_text("山海壁画", p + Vector2(0, 42), 12, ink)
		"lantern":
			draw_line(p - Vector2(0, 35), p - Vector2(0, 20), Color("9c8264"), 2)
			box(Rect2(p - Vector2(16, 20), Vector2(32, 35)), Color("d9996b"), 12)
			draw_line(p + Vector2(0, 15), p + Vector2(0, 28), orange, 3)
			draw_line(p - Vector2(8, 17), p + Vector2(-8, 12), Color("f7cca0"), 2)
			centered_text("暖灯", p + Vector2(0, 42), 12, ink)
		"kitchen":
			box(Rect2(p - Vector2(43, 22), Vector2(86, 49)), Color("8a9c8f"), 8)
			for dx in [-20, 20]:
				draw_circle(p + Vector2(dx, -9), 12, Color("eee7d8"))
				draw_arc(p + Vector2(dx, -9), 7, 0, TAU, 20, orange, 3)
			centered_text("扩建灶台", p + Vector2(0, 44), 12, ink)
		_:
			plant(p - Vector2(0, 7))

func _draw_placement() -> void :
	for x in range(grid_dimensions().x):
		for y in range(grid_dimensions().y):
			box(cell_rect(x, y).grow(-3), Color(0.96, 0.98, 0.93, 0.14), 6, Color(0.32, 0.52, 0.46, 0.3))
	if preview_cell.x < 0: return
	var item: = _decoration_entry(placement_id)
	var rect: = cell_rect(preview_cell.x, preview_cell.y, int(item.get("width", 1)), int(item.get("height", 1)))
	var allowed: = _placement_allowed()
	var color: = Color("528575") if allowed else Color("bd7359")
	box(rect.grow(-3), Color(color, 0.28), 7, color)
	var p: = rect.get_center()
	centered_text(str(item.get("icon", "放")), p + Vector2(0, 4), 23, color)
	centered_text("点击放置" if allowed else "这里不能放置", p + Vector2(0, 25), 11, ink)

func _draw_employees() -> void:
	for employee in model.employees:
		var id := str(employee.get("id", ""))
		if not _actors.has(id): continue
		var actor: Dictionary = _actors[id]
		var p: Vector2 = actor.get("display_position",actor.position)
		var action := str(actor.action)
		var phase := float(actor.phase)
		var resting := bool(actor.get("resting", false))
		var bob := sin(phase * TAU) * (2.0 if action == "Move" else 0.7)
		var draw_position := p + Vector2(0, bob)
		var blend := clampf(float(actor.blend_age) / float(animation_settings(_live_balance()).transition_seconds), 0.0, 1.0)
		var rendered := false
		if blend < 1.0 and str(actor.previous_action) != action:
			rendered = _draw_employee_frame(employee, actor, str(actor.previous_action), draw_position, 1.0 - blend)
		rendered = _draw_employee_frame(employee, actor, action, draw_position, blend if rendered else 1.0) or rendered
		if not rendered:
			draw_set_transform(_to_view(draw_position), sin(phase * TAU) * 0.035 if action == "Move" else 0.0, Vector2(float(actor.facing), 1) * _world_scale())
			var blink = int(phase*2+posmod(hash(id),12)) % 12 == 11
			animal(Vector2.ZERO, str(employee.get("role", "")) == "chef", resting or blink, id, str(employee.get("icon", "")))
			draw_set_transform(Vector2.ZERO, 0.0, _world_scale())
		_draw_action_prop(actor, draw_position)
		centered_text(str(employee.get("name", "员工")), p + Vector2(0, 33), 11, ink)
		if Rarity.scene_marker_for(str(employee.get("rarity", ""))) != "": _draw_ssr_star(p + Vector2(0, -42))
		var labels := {"Idle": "待命", "Move": "移动", "Cook": "烹饪", "Serve": "服务", "Clean": "清台", "Cashier": "收银", "Promote": "宣传"}
		var label := str(actor.get("rest_label", labels.get(action, action))) if resting else str(labels.get(action, action))
		if employee.has("level") and model.full_rules.revision.is_building(str(employee.id)):label="装修中"
		if int(actor.get("task_count", 0)) > 1: label += " ×%d" % int(actor.task_count)
		centered_text(label, p + Vector2(0, 46), 10, green)
		if int(actor.get("task_count", 0)) > 0 and action != "Move":
			box(Rect2(p + Vector2(-17, -35), Vector2(34, 4)), Color("d8cebb"), 2)
			box(Rect2(p + Vector2(-17, -35), Vector2(34 * float(actor.progress), 4)), green, 2)

func _draw_employee_frame(employee: Dictionary, actor: Dictionary, action: String, p: Vector2, alpha: float) -> bool:
	if assets == null or not assets.has_method("get_frames"): return false
	var character_id: String = str(employee.get("id", ""))
	var appearance: String = str(employee.get("appearance", ""))
	if not appearance.is_empty() and assets.has_method("has_frames") and assets.has_frames(appearance, action,str(actor.get("direction","down"))): character_id = appearance
	var image_action=action
	
	var frames: Array = assets.get_frames(character_id, image_action, str(actor.get("direction","down")))
	if frames.is_empty(): return false
	if assets.has_method("has_frames") and not assets.has_frames(character_id, image_action,str(actor.get("direction","down"))): return false
	var index := int(floor(float(actor.phase) * float(animation_settings(_live_balance()).frames_per_second))) % frames.size()
	var texture: Texture2D = frames[index] as Texture2D
	if texture == null: return false
	var extent := Vector2(64, 80) if is_dollhouse() else Vector2(64,72)
	var lift=preload("res://scripts/services/art_motion.gd").lift(character_id,action)
	var destination := Rect2(p+Vector2(0,22-lift)-Vector2(32,77),extent) if is_dollhouse() else Rect2(p - extent * Vector2(0.5, 0.65), extent)
	if not is_dollhouse() and int(actor.facing) < 0:
		destination.position.x += destination.size.x
		destination.size.x = -destination.size.x
	draw_texture_rect(texture, destination, false, Color(1, 1, 1, alpha))
	return true

func _draw_action_prop(actor: Dictionary, p: Vector2) -> void:
	var action := str(actor.action)
	var phase := float(actor.phase) * TAU
	match action:
		"Move":
			for direction in [-1, 1]:
				var foot := p + Vector2(direction * 8, 20 + sin(phase + direction) * 3)
				draw_line(foot, foot + Vector2(direction * 4, 0), ink, 3)
		"Cook":
			bowl(p + Vector2(22, 10), orange)
			draw_line(p + Vector2(6, 0), p + Vector2(26 + sin(phase) * 5, -8), ink, 2)
			for index in range(3):
				var rise = fposmod(float(actor.phase)+index*0.3,1.0)
				draw_arc(p+Vector2(18+index*5,-8-rise*19),3,-PI/2,PI/2,8,Color(0.7,0.6,0.5,1-rise),1.2)
		"Serve":
			draw_line(p + Vector2(11, 8), p + Vector2(35, 8), orange, 3)
			bowl(p + Vector2(25, 9), green)
		"Clean":
			var hand := p + Vector2(21 + sin(phase) * 8, 12)
			box(Rect2(hand - Vector2(7, 3), Vector2(14, 6)), Color("a7c7c2"), 2)
		"Cashier":
			box(Rect2(p + Vector2(16, 0), Vector2(15, 20)), Color("8b9a80"), 3)
			centered_text("￥", p + Vector2(23, 14), 11, Color.WHITE)
		"Promote":
			draw_line(p + Vector2(10, 0), p + Vector2(23, -17), ink, 2)
			draw_arc(p + Vector2(27, -15), 8 + sin(phase) * 2, -0.8, 0.8, 10, orange, 2)

func _draw_ssr_star(p: Vector2) -> void:
	var points := PackedVector2Array()
	for index in range(10):
		var angle := -PI * 0.5 + index * PI / 5.0
		var radius := 7.0 if index % 2 == 0 else 3.2
		points.append(p + Vector2(cos(angle), sin(angle)) * radius)
	draw_colored_polygon(points, Rarity.color_for("SSR"))

func draw_guest(guest: Dictionary, p: Vector2, scale_factor: float = 1.0) -> void :
	var palette: = [Color("94aaba"), Color("b0a0bd"), Color("c9a07c"), Color("7da991")]
	var c: Color = palette[int(guest.get("id", 0)) % palette.size()]
	var stage: = str(guest.get("stage", "ordering"))
	p.y += sin(elapsed * 2 + int(guest.get("id", 0))) * 1.2
	var radius: = maxf(12, 16 * scale_factor)
	if str(guest.get("type", "human")) != "human":
		draw_colored_polygon(PackedVector2Array([p + Vector2( - radius, -5), p + Vector2( - radius, - radius - 5), p + Vector2(-4, - radius)]), c)
		draw_colored_polygon(PackedVector2Array([p + Vector2(radius, -5), p + Vector2(radius, - radius - 5), p + Vector2(4, - radius)]), c)
	draw_circle(p, radius, c)
	draw_circle(p + Vector2(-5, -2), 1.8, ink)
	draw_circle(p + Vector2(5, -2), 1.8, ink)
	draw_arc(p + Vector2(0, 1), 5, 0.2, PI - 0.2, 12, ink, 1.5)
	var labels: = {"ordering": "点单", "recommending": "点单", "queued": "等餐", "cooking": "制作", "serving": "上菜", "eating": "用餐", "paying": "结账", "cleaning": "清台"}
	var tag: = str(labels.get(stage, stage))
	box(Rect2(p.x - 22, p.y - 42, 44, 20), Color("fffdf7"), 6)
	centered_text(tag, p + Vector2(0, -28), 11, ink)
	if guest.has("visitor_id"):
		centered_text("!",p+Vector2(24,-28),23,Color("d8a642"))
		var image=_asset_texture("Characters","guest_"+str(guest.visitor_id)+"_idle")
		if image!=null:draw_texture_rect(image,Rect2(p-Vector2(20,20),Vector2(40,40)),false)
	if int(guest.get("interaction_until",0))>int(model.state.total_minutes):
		var visible_bubbles: Array=model.customers.filter(func(c):return int(c.get("interaction_until",0))>int(model.state.total_minutes))
		visible_bubbles.sort_custom(func(a,b):return int(a.interaction_until)>int(b.interaction_until))
		if visible_bubbles.find(guest)<2:
			var speech=Rect2(p+Vector2(-96,-75),Vector2(192,25))
			box(speech,Color("fffdf7"),6)
			centered_text(str(guest.get("interaction_text","")),speech.get_center()+Vector2(0,4),10,ink)
	if stage == "eating":
		var dish: = _dish(str(guest.get("dish_id", "")))
		var icon_position: = p + Vector2(23 if int(guest.get("seat", 0)) % 2 == 0 else -23, 0)
		draw_circle(icon_position, 10, Color("fff6e8"))
		var dish_texture := _asset_texture("Dishes", str(guest.get("dish_id", "")))
		if dish_texture != null: draw_texture_rect(dish_texture, Rect2(icon_position - Vector2(13, 13), Vector2(26, 26)), false)
		else: centered_text(str(dish.get("icon", "餐")), icon_position + Vector2(0, 4), 12, orange)
	if stage in ["ordering", "queued", "cooking", "serving"]:
		var waited: = float(int(model.state.total_minutes) - int(guest.get("arrival_minute", model.state.total_minutes)))
		var patience: = maxf(1, float(model.balance.get("customer.patience", 120)))
		box(Rect2(p.x - 15, p.y + 21, 30, 4), Color("d8cebb"), 2)
		box(Rect2(p.x - 15, p.y + 21, 30 * clampf(1 - waited / patience, 0, 1), 4), Color("a3b68b") if waited < patience * 0.7 else orange, 2)

func animal(p: Vector2, chef: bool, resting: bool, id: String = "", icon: String = "") -> void :
	var c: = Color("faf9ef") if chef else Color("d5bcaa")
	match id:
		"bi_fang", "feng_huang":
			c = Color("d98759")
			draw_colored_polygon(PackedVector2Array([p + Vector2(-10, -13), p + Vector2(-3, -34), p + Vector2(2, -21), p + Vector2(10, -31), p + Vector2(14, -12)]), Color("e7b958"))
			draw_circle(p + Vector2(-19, 4), 8, c)
			draw_circle(p + Vector2(19, 4), 8, c)
		"jiu_wei_hu":
			c = Color("d99864")
			for offset in [-14, 0, 14]: draw_circle(p + Vector2(offset, 18), 10, Color("ebbd92"))
			for direction in [-1, 1]:
				draw_colored_polygon(PackedVector2Array([p + Vector2(direction * 18, -3), p + Vector2(direction * 16, -29), p + Vector2(direction * 3, -15)]), c)
		"tao_tie":
			c = Color("86a9af")
			for direction in [-1, 1]: draw_arc(p + Vector2(direction * 16, -14), 8, PI * 0.75, TAU + 0.5, 16, Color("537c87"), 5)
		"pi_xiu":
			c = Color("d4b16a")
			draw_circle(p + Vector2(-15, -15), 8, Color("b99450"))
			draw_circle(p + Vector2(15, -15), 8, Color("b99450"))
			draw_colored_polygon(PackedVector2Array([p + Vector2(-3, -16), p + Vector2(0, -30), p + Vector2(5, -16)]), Color("a68447"))
		"xiao":
			for direction in [-1, 1]:
				draw_colored_polygon(PackedVector2Array([p + Vector2(direction * 18, 0), p + Vector2(direction * 16, -27), p + Vector2(direction * 4, -13)]), c)
		"xian_yang", "er_shu":
			draw_circle(p + Vector2(-15, -12), 8 if chef else 11, Color("ab967d") if chef else c)
			draw_circle(p + Vector2(15, -12), 8 if chef else 11, Color("ab967d") if chef else c)
		_:
			draw_circle(p, 22, Color("cbd7c4"))
	draw_circle(p, 18, c)
	if id == "xiao":
		draw_circle(p + Vector2(-7, -3), 7, Color("fbf6e9"))
		draw_circle(p + Vector2(7, -3), 7, Color("fbf6e9"))
	if resting:
		draw_line(p + Vector2(-9, -2), p + Vector2(-3, -2), ink, 2)
		draw_line(p + Vector2(3, -2), p + Vector2(9, -2), ink, 2)
	else:
		draw_circle(p + Vector2(-6, -2), 2, ink)
		draw_circle(p + Vector2(6, -2), 2, ink)
	if id in ["bi_fang", "feng_huang", "xiao"]:
		draw_colored_polygon(PackedVector2Array([p + Vector2(-4, 4), p + Vector2(4, 4), p + Vector2(0, 10)]), orange)
	elif id == "tao_tie":
		draw_arc(p + Vector2(0, 4), 8, 0, PI, 18, ink, 3)
	else:
		draw_circle(p + Vector2(0, 5), 3, Color("d29d87"))
	if chef: box(Rect2(p.x - 13, p.y - 25, 26, 10), Color.WHITE, 5)
	else: box(Rect2(p.x - 10, p.y + 14, 20, 7), Color("b99550") if id == "pi_xiu" else green, 2)
	if not id in ["bi_fang", "feng_huang", "jiu_wei_hu", "tao_tie", "pi_xiu", "xiao", "xian_yang", "er_shu"]:
		centered_text(icon.left(1) if not icon.is_empty() else id.left(1).to_upper(), p + Vector2(0, -9), 10, green)

func _dish(id: String) -> Dictionary:
	for entry in model.dishes:
		if str(entry.get("id", "")) == id: return entry
	return {}

func _update_guest_tooltip() -> void :
	var position: = _to_world(get_local_mouse_position())
	var detail: = ""
	for guest in model.customers:
		if position.distance_to(model.full_rules.dollhouse.guest_position(guest) if is_dollhouse() else _seat_position(int(guest.get("seat",0))))<28:
			var dish: = _dish(str(guest.get("dish_id", "")))
			var types: = {"human": "人类食客", "monster": "山海异兽", "descendant": "神兽后裔", "special": "神秘来客"}
			detail = "%s · %s\n预计消费 ￥%d · 当前品质 %d" % [types.get(str(guest.get("type", "human")), "食客"), dish.get("name", "等待点单"), int(guest.get("price", 0)), int(guest.get("quality", 0))]
			break
	if tooltip_text != detail: tooltip_text = detail

func _track_checkout() -> void :
	var served: = int(model.state.get("served", 0))
	var revenue: = float(model.state.get("total_revenue", 0))
	for guest in model.customers:
		if str(guest.get("stage", "")) == "paying": _last_checkout_position = _seat_position(int(guest.get("seat", 0)))
	if _previous_served >= 0 and served > _previous_served and revenue > _previous_revenue:
		var p: = _last_checkout_position if _last_checkout_position != Vector2.ZERO else Vector2(Space.WORLD_SIZE.x * 0.8, 90)
		if not has_meta("presentation_host"):_coin_popups.append({"position": p, "age": 0.0, "amount": revenue - _previous_revenue})
	elif served < _previous_served:
		_coin_popups.clear()
	_previous_served = served
	_previous_revenue = revenue

func _draw_coin_popups() -> void :
	for popup in _coin_popups:
		var age: = float(popup.age)
		var p: Vector2 = popup.position + Vector2(0, -35 - age * 24)
		var alpha: = clampf(1 - age / 1.8, 0, 1)
		box(Rect2(p - Vector2(27, 16), Vector2(54, 24)), Color(1, 0.98, 0.87, alpha), 7)
		centered_text("+￥%d" % int(popup.amount), p + Vector2(0, 1), 13, Color(0.64, 0.48, 0.23, alpha))

func bowl(p: Vector2, color: Color) -> void :
	draw_arc(p - Vector2(0, 5), 14, 0, PI, 20, color, 8)
	draw_line(p + Vector2(-15, -5), p + Vector2(15, -5), color, 3)
	draw_line(p + Vector2(-4, -13), p + Vector2(-2, -20), color, 2)
	draw_line(p + Vector2(4, -13), p + Vector2(6, -20), color, 2)

func plant(p: Vector2) -> void :
	box(Rect2(p.x - 10, p.y, 20, 20), Color("c4a681"), 4)
	draw_line(p + Vector2(0, 2), p - Vector2(0, 24), green, 3)
	draw_circle(p - Vector2(8, 13), 9, Color("8daa89"))
	draw_circle(p + Vector2(8, -20), 10, Color("779a7c"))

## Shared by presentation and the authoritative task scheduler.
static func animation_settings(overrides: Dictionary = {}) -> Dictionary:
	if not _animation_settings.is_empty(): return _overlay_animation(_animation_settings, overrides)
	var fallback := {
		"base_move_pixels_per_game_minute": 210.0, "arrival_distance": 0.01,
		"transition_seconds": 0.15, "frames_per_second": 8.0,
		"move": {"attribute": "speed", "baseline": 5.0, "coefficient": 0.08, "minimum": 0.6, "maximum": 2.0},
		"cook": {"attribute": "cooking", "baseline": 5.0, "coefficient": 0.06, "minimum": 0.7, "maximum": 1.8},
		"charm": {"attribute": "charm", "baseline": 5.0, "coefficient": 0.05, "minimum": 0.8, "maximum": 1.5},
		"mood": {"threshold": 80.0, "coefficient": 0.001, "maximum": 100.0}}
	var content: Variant = JSON.parse_string(FileAccess.get_file_as_string(ANIMATION_CONFIG_PATH)) if FileAccess.file_exists(ANIMATION_CONFIG_PATH) else null
	if content is Dictionary:
		fallback.merge(content, true)
	_animation_settings = fallback
	return _overlay_animation(_animation_settings, overrides)

static func _overlay_animation(source: Dictionary, overrides: Dictionary) -> Dictionary:
	if overrides.is_empty(): return source
	var result: Dictionary = source.duplicate(true)
	for key in result:
		if result[key] is Dictionary:
			for field in result[key]:
				var lookup = "animation." + str(key) + "." + str(field)
				if overrides.has(lookup): result[key][field] = overrides[lookup]
		elif overrides.has("animation." + str(key)): result[key] = overrides["animation." + str(key)]
	return result

func _live_balance() -> Dictionary:
	return model.balance if model != null and "balance" in model else {}

static func animation_factor(employee: Dictionary, action: String, overrides: Dictionary = {}) -> float:
	var settings := animation_settings(overrides)
	var normalized := action.to_lower()
	var category := "move"
	if normalized in ["cook", "cooking", "research", "researching"]: category = "cook"
	elif normalized in ["cashier", "paying", "promote", "promoting"]: category = "charm"
	elif normalized in ["order","ordering"]:category="move"
	if normalized in ["cashier","paying"] and not str(employee.get("primary_role",employee.get("role",""))) in ["salesman","all"] and not str(employee.get("secondary_role","")) in ["salesman","all"]:category="move"
	if normalized=="rest":return 1.0
	var rule: Dictionary = settings.get(category,{"attribute":"eloquence","baseline":5.0,"coefficient":.05,"minimum":.8,"maximum":1.5})
	var attributes: Dictionary = employee.get("attributes", {})
	var attribute := float(attributes.get(str(rule.attribute), 0))
	var factor := clampf(1.0 + (attribute - float(rule.baseline)) * float(rule.coefficient), float(rule.minimum), float(rule.maximum))
	if normalized in ["idle", "rest", "train"]: factor = 1.0
	var mood_rule: Dictionary = settings.mood
	var mood := clampf(float(employee.get("mood", 100.0)), 0.0, float(mood_rule.maximum))
	var mood_factor := 1.0 + maxf(0.0, mood - float(mood_rule.threshold)) * float(mood_rule.coefficient)
	var rarity = float(overrides.get("rarity_speed_mult."+str(employee.get("rarity","N")),{"N":0.82,"R":0.89,"SR":0.97,"SSR":1.07}.get(str(employee.get("rarity","N")),1))) if employee.has("level") and not normalized in ["idle","rest","train"] else 1.0
	return factor * mood_factor * rarity

func _visual_delta(delta: float) -> float:
	if model == null or model.paused: return 0.0
	if model.has_method("real_time_rate"): return maxf(0.0,delta) * model.real_time_rate()
	var factor := 1.0
	if str(model.state.get("mode", "normal")) == "demo":
		var time_settings: Dictionary = model.demo_config.get("time", {})
		factor = float(time_settings.get("time_factor", 6.0))
	return maxf(0.0, minf(delta, 0.1)) * float(model.speed) * factor

## Rendering is an observer: none of these routines mutates model task or economy data.
func _update_employee_animation(visual_delta: float) -> void:
	var present: Dictionary = {}
	var station_slots := {"chef": 0, "waiter": 0, "salesman": 0, "rest": 0}
	var obstacles := _navigation_obstacles()
	var layout_signature := hash(obstacles)
	for employee in model.employees:
		var id := str(employee.get("id", ""))
		if str(employee.get("branch_id", "")) != "" or int(employee.get("expansion_until", 0)) > int(model.state.get("total_minutes", 0)): continue
		if is_dollhouse() and not model.full_rules.world._present(str(employee.id)):continue
		present[id] = true
		var role := str(employee.get("role", "waiter"))
		if role == "all": role = "waiter"
		var now := int(model.state.get("total_minutes", 0))
		var management_job: String = str(employee.get("management_job_type", ""))
		var management_active: bool = int(employee.get("management_until", 0)) > now
		var training := int(employee.get("training_until", 0)) > now or (management_active and management_job.begins_with("train_"))
		var research := int(employee.get("research_until", 0)) > now or (management_active and management_job == "research")
		var resting := bool(employee.get("resting", false)) or training or research
		var bucket := "rest" if resting else role
		var slot := int(station_slots.get(bucket, 0))
		station_slots[bucket] = slot + 1
		var tasks := _employee_tasks(employee)
		if employee.get("motion", {}) is Dictionary and not employee.get("motion", {}).is_empty():
			var label := "研发" if research else ("训练" if training else "休息")
			if not _actors.has(id):
				_actors[id] = {"position":Space.entry_position(), "target":Space.entry_position(),
					"action":"Idle", "previous_action":"Idle", "phase":0.0, "blend_age":1.0,
					"facing":1, "progress":0.0, "task_count":0, "resting":resting,
					"rest_label":label, "task_id":-1}
			var authoritative_actor: Dictionary = _actors[id]
			authoritative_actor.resting = resting
			authoritative_actor.rest_label = label
			authoritative_actor.task_count = tasks.size()
			var autonomous_action := "Cook" if research else ("Promote" if role == "salesman" and int(model.state.get("promotion_until", 0)) > now and not resting else "Idle")
			_update_authoritative_actor(employee, authoritative_actor, tasks, visual_delta, autonomous_action)
			continue
		var target := _station_position(role, slot)
		var requested := "Idle"
		var rest_label := "休息" if not training else "训练"
		if research: rest_label = "研发"
		if resting:
			target = Vector2(Space.WORLD_SIZE.x - 74 - (slot % 5) * 62, Space.WORLD_SIZE.y - 62 - (slot / 5) * 58)
			if research: requested = "Cook"
		elif not tasks.is_empty():
			var primary: Dictionary = tasks[0]
			var stage := str(primary.get("stage", ""))
			match stage:
				"cooking", "queued":
					requested = "Cook"
					target = _station_position("chef", slot)
				"paying":
					requested = "Cashier"
					target = _station_position("salesman", slot)
				"cleaning":
					requested = "Clean"
					target = Space.service_point(model, int(primary.get("seat", 0)))
				_:
					requested = "Serve"
					target = Space.service_point(model, int(primary.get("seat", 0)))
		elif role == "salesman" and int(model.state.get("promotion_until", 0)) > now:
			requested = "Promote"
			target = Vector2(Space.WORLD_SIZE.x * 0.5, Space.WORLD_SIZE.y - 72)
		if not _actors.has(id):
			_actors[id] = {"position": Vector2(Space.WORLD_SIZE.x * 0.5, Space.WORLD_SIZE.y - 48), "target": target,
				"action": "Idle", "previous_action": "Idle", "phase": 0.0, "blend_age": 1.0,
				"facing": 1, "progress": 0.0, "task_count": 0, "resting": resting,
				"rest_label": rest_label, "task_id": -1}
		var actor: Dictionary = _actors[id]
		actor.resting = resting
		actor.rest_label = rest_label
		actor.task_count = tasks.size()
		var position: Vector2 = actor.position
		var ignores_obstacles := _navigation_ignores_obstacles(employee, tasks)
		var bounds := Rect2(8, 80, maxf(1, Space.WORLD_SIZE.x - 16), maxf(1, Space.WORLD_SIZE.y - 88)).expand(position).expand(target).grow(0.01)
		var station_route: Dictionary = {}
		var desired_target := target
		if not ignores_obstacles and requested in ["Idle", "Cook", "Cashier", "Promote"] and not Navigation.point_is_clear(target, obstacles):
			if int(actor.get("navigation_layout", -1)) == layout_signature and actor.get("navigation_station", Vector2(INF, INF)) == desired_target and not bool(actor.get("navigation_ignore", false)):
				target = actor.get("navigation_target", desired_target)
			else:
				station_route = Navigation.nearest_reachable_target(position, target, obstacles, bounds)
				if not bool(station_route.blocked): target = station_route.point
		actor.navigation_station = desired_target
		actor.target = target
		if int(actor.get("navigation_layout", -1)) != layout_signature or actor.get("navigation_target", Vector2(INF, INF)) != target or bool(actor.get("navigation_ignore", false)) != ignores_obstacles:
			var route: Dictionary = {"points": [target], "blocked": false} if ignores_obstacles else station_route if not station_route.is_empty() else Navigation.find_path(position, target, obstacles, bounds)
			actor.navigation_path = route.points
			actor.navigation_waypoint = 0
			actor.navigation_blocked = bool(route.blocked)
			actor.navigation_layout = layout_signature
			actor.navigation_target = target
			actor.navigation_ignore = ignores_obstacles
		var arriving := position.distance_to(target) <= float(animation_settings(_live_balance()).arrival_distance)
		var blocked := bool(actor.get("navigation_blocked", false)) and not arriving
		if not arriving and not blocked and visual_delta > 0.0:
			var speed := float(animation_settings(_live_balance()).base_move_pixels_per_game_minute) * animation_factor(employee, "Move", _live_balance())
			var advanced := Navigation.advance(position, actor.navigation_path, int(actor.navigation_waypoint), speed * visual_delta)
			var next: Vector2 = advanced.position
			if absf(next.x - position.x) > 0.01: actor.facing = 1 if next.x > position.x else -1
			actor.position = next
			actor.navigation_waypoint = int(advanced.waypoint)
			arriving = next.distance_to(target) <= float(animation_settings(_live_balance()).arrival_distance)
		if blocked:
			actor.resting = true
			actor.rest_label = "通路受阻"
		var next_action := "Idle" if blocked else requested if arriving else "Move"
		if str(actor.action) != next_action:
			actor.previous_action = actor.action
			actor.action = next_action
			actor.blend_age = 0.0
			actor.phase = 0.0
		actor.blend_age = minf(float(animation_settings(_live_balance()).transition_seconds), float(actor.blend_age) + visual_delta)
		actor.phase = float(actor.phase) + visual_delta * animation_factor(employee, next_action, _live_balance())
		actor.progress = 0.0
		if not tasks.is_empty():
			var primary: Dictionary = tasks[0]
			actor.task_id = int(primary.get("id", -1))
			var began := int(primary.get("task_started_minute", now))
			var due := int(primary.get("due_minute", -1))
			if due > began:
				actor.progress = clampf(float(now - began) / float(due - began), 0.0, 0.99)
		else: actor.task_id = -1
	for id in _actors.keys():
		if not present.has(id): _actors.erase(id)

func _update_authoritative_actor(employee: Dictionary, actor: Dictionary, tasks: Array, visual_delta: float, requested: String = "Idle") -> void:
	var motion: Dictionary = employee.motion
	var now := float(model.state.get("total_minutes", 0)) + (float(model._fraction) if "_fraction" in model else 0.0)
	var previous: Vector2 = actor.position
	var points: Array[Vector2] = []
	for point in motion.get("path", []):
		points.append(Vector2(float(point.get("x", 0)), float(point.get("y", 0))))
	var target_data: Dictionary = motion.get("target", {})
	var target := Vector2(float(target_data.get("x", previous.x)), float(target_data.get("y", previous.y)))
	var elapsed_motion := maxf(0.0, now - float(motion.get("started", now)))
	var travel := maxf(0.0, float(motion.get("travel_minutes", 0)))
	var work := maxf(0.0, float(motion.get("work_minutes", 0)))
	if model.has_method("motion_position"):
		actor.position = model.motion_position(employee, now)
	else:
		var origin: Dictionary = motion.get("origin", {})
		actor.position = Navigation.advance(Vector2(float(origin.get("x", previous.x)), float(origin.get("y", previous.y))), points, 0, maxf(0.0, float(motion.get("speed", 0))) * elapsed_motion).position
	var position: Vector2 = actor.position
	if absf(position.x - previous.x) > 0.01: actor.facing = 1 if position.x > previous.x else -1
	var facing_delta=position-previous
	if facing_delta.length()>.01:
		actor.direction=("right" if facing_delta.x>0 else "left") if absf(facing_delta.x)>=absf(facing_delta.y) else ("down" if facing_delta.y>0 else "up")
	elif elapsed_motion>=travel and not tasks.is_empty():
		var fixture=model.full_rules.dollhouse.by_id(str(tasks[0].get("device_uid","")))
		var look=Space.cell_rect(model,fixture.x,fixture.y,fixture.w,fixture.h).get_center()-position if not fixture.is_empty() else Vector2(0,-1)
		actor.direction=("right" if look.x>0 else "left") if absf(look.x)>=absf(look.y) else ("down" if look.y>0 else "up")
	actor.target = target
	actor.navigation_path = points
	actor.navigation_blocked = bool(motion.get("blocked", false))
	actor.navigation_ignore = bool(motion.get("ignore_obstacles", false))
	var action := "Move" if elapsed_motion < travel and position.distance_to(target) > 0.01 else str(motion.get("action", "Idle"))
	if action=="Recommend":action="Order" # Finish old in-flight saves with a current Chinese action label.
	if tasks.is_empty() and action != "Move" and not (model.state.get("revision191",{}).get("aux_jobs",{}).has(str(employee.id)) or model.full_rules.revision.is_building(str(employee.id))): action = requested
	if model.state.has("revision191") and model.full_rules.revision.is_building(str(employee.id)) and model.period()=="closed":action="Rest"
	if bool(actor.navigation_blocked):
		action = "Idle"
		actor.resting = true
		actor.rest_label = "通路受阻"
	if str(actor.action) != action:
		actor.previous_action = actor.action
		actor.action = action
		actor.blend_age = 0.0
		actor.phase = 0.0
	actor.blend_age = minf(float(animation_settings(_live_balance()).transition_seconds), float(actor.blend_age) + visual_delta)
	actor.phase = float(actor.phase) + visual_delta * animation_factor(employee, action, _live_balance())
	actor.progress = clampf((elapsed_motion - travel) / work, 0.0, 0.99) if not tasks.is_empty() and work > 0.0 else 0.0
	actor.task_id = int(tasks[0].get("id", -1)) if not tasks.is_empty() else -1

func _navigation_obstacles() -> Array[Rect2]:
	return Space.obstacles(model)

func _navigation_ignores_obstacles(employee: Dictionary, tasks: Array) -> bool:
	if tasks.is_empty(): return false
	if str(employee.get("id", "")) == "di_jiang" and not tasks.is_empty() and str(tasks[0].get("stage","")) == "serving": return true
	if model != null and "full_rules" in model and model.full_rules != null and "effects" in model.full_rules and model.full_rules.effects != null:
		var task: Dictionary = tasks[0] if not tasks.is_empty() else {}
		var dish: Dictionary = model._dish(str(task.get("dish_id", ""))) if model.has_method("_dish") else {}
		return bool(model.full_rules.effects.ignores_obstacles(employee, dish, str(task.get("stage", "serving"))))
	return false

func _employee_tasks(employee: Dictionary) -> Array[Dictionary]:
	var tasks: Array[Dictionary] = []
	var id := str(employee.get("id", ""))
	var primary := int(employee.get("busy_customer", 0))
	var additional: Array = employee.get("busy_customers", [])
	for guest in model.customers:
		var guest_id := int(guest.get("id", 0))
		if str(guest.get("worker", "")) == id or str(guest.get("employee_id", "")) == id or guest_id == primary or guest_id in additional:
			if str(guest.get("stage", "")) in ["ordering", "recommending", "queued", "cooking", "serving", "cleaning", "paying"]: tasks.append(guest)
	return tasks

func _station_position(role: String, slot: int) -> Vector2:
	return Space.station_position(model, role, slot)

func employee_animation_state(id: String) -> Dictionary:
	return _actors.get(id, {}).duplicate(true)

func _resolve_actor_spacing(delta: float) -> void:
	if is_dollhouse():
		var entries: Array = []
		var at = float(model.state.total_minutes)+model._fraction
		for id in _actors:
			var actor: Dictionary = _actors[id]
			entries.append({"key":"staff:"+str(id),"point":actor.position,"pinned":str(actor.action)!="Move","radius":minf(53,actor.position.distance_to(actor.target)*.65)})
		for guest in model.customers:
			if str(guest.stage)=="cleaning": continue
			var motion: Dictionary = guest.get("checkout_motion",guest.get("arrival_motion",{}))
			var walking = not motion.is_empty() and at < float(motion.get("started",0))+float(motion.get("travel_minutes",0))
			var base: Vector2 = model.full_rules.dollhouse.guest_position(guest,at)
			var target: Vector2 = model._motion_point(motion.get("target",{})) if walking else base
			entries.append({"key":"guest:"+str(guest.id),"point":base,"pinned":not walking,"radius":minf(53,base.distance_to(target)*.65)})
		for guest in model.state.revision191.departures:
			entries.append({"key":"leaving:"+str(guest.id),"point":model.motion_position(guest,at),"pinned":false})
		crowd.update(model,entries,delta)
		for id in _actors:
			var actor: Dictionary = _actors[id]
			actor.display_position = crowd.point("staff:"+str(id),actor.position)
			actor.display_offset = actor.display_position-actor.position
		return
	var occupied: Array[Vector2] = []
	var walls = _navigation_obstacles()
	var spacing = Space.presentation("body_spacing",44)
	var limit = Space.presentation("local_offset_limit",64)
	for id in _actors:
		var actor: Dictionary = _actors[id]
		var position: Vector2 = actor.position
		var chosen = position
		for offset in [Vector2.ZERO,Vector2(0,-44),Vector2(0,44),Vector2(-44,0),Vector2(44,0),Vector2(-32,-32),Vector2(32,32)]:
			var point = position+offset.limit_length(limit)
			if not Space.walk_bounds().has_point(point) or not Navigation.point_is_clear(point,walls): continue
			var free = true
			for previous in occupied:
				if previous.distance_to(point) < spacing-2: free = false;break
			if free: chosen = point;break
		var desired_offset = chosen-position
		var old_offset: Vector2 = actor.get("display_offset",Vector2.ZERO)
		var next_offset = old_offset.move_toward(desired_offset,maxf(0,delta)*80)
		# A display offset never changes the scheduler's route, arrival or result.
		if not Navigation.point_is_clear(position+next_offset,walls): next_offset = Vector2.ZERO
		actor.display_offset = next_offset
		actor.display_position = position+next_offset
		occupied.append(actor.display_position)

func first_customer_bounds() -> Rect2:
	if model == null or model.customers.is_empty(): return Rect2()
	return customer_bounds(int(model.customers[0].get("id", -1)))

func customer_bounds(id: int) -> Rect2:
	if model == null: return Rect2()
	for guest in model.customers:
		if int(guest.get("id", -1)) == id:
			if is_dollhouse():return Rect2(_to_view(guest_display_position(guest))-Vector2(28,60)*house().scale_factor(),Vector2(56,78)*house().scale_factor())
			return Rect2(_to_view(_seat_position(int(guest.get("seat", 0))) - Vector2(28, 45)), Vector2(56, 78) * _world_scale())
	return Rect2()

func guest_display_position(guest: Dictionary, leaving: bool = false) -> Vector2:
	var at = float(model.state.total_minutes)+model._fraction
	var base: Vector2 = model.motion_position(guest,at) if leaving else model.full_rules.dollhouse.guest_position(guest,at)
	return crowd.point(("leaving:" if leaving else "guest:")+str(guest.id),base)

func _asset_texture(category: String, id: String) -> Texture2D:
	if assets == null: return null
	var canonical := category + "/" + id
	if category == "Scenes": canonical = "Backgrounds/" + id
	elif category == "Decorations": canonical = "UI/decor_" + id
	if assets.has_method("has_image") and not assets.has_image(canonical): return null
	if assets.has_method("get_texture"): return assets.get_texture(canonical) as Texture2D
	return null
