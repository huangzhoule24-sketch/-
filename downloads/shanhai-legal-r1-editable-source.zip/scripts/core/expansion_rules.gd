extends RefCounted

var cultural_adapter # Optional policy; isolated expansion rules keep their original behaviour.
## Persistent stage 2–4 systems. All waits are game minutes, never wall clock.

const BalanceRegistry = preload("res://scripts/core/balance_registry.gd")

var _model_ref: WeakRef
var model: Variant:
	get:
		return _model_ref.get_ref()
var config: Dictionary = {}


func _init(host: RefCounted) -> void:
	_model_ref = weakref(host)
	var file := FileAccess.open("res://config/expansion.json", FileAccess.READ)
	if file != null:
		var parsed: Variant = JSON.parse_string(file.get_as_text())
		if parsed is Dictionary: config = parsed


func _now() -> int:
	return int(model.state.get("total_minutes", 0))


func _state() -> Dictionary:
	return model.state.get("expansion", {})


func _section(id: String) -> Dictionary:
	return BalanceRegistry.overlay(config.get(id, {}), "expansion." + id, _balance())


func _balance() -> Dictionary:
	var values: Variant = model.get("balance")
	return values if values is Dictionary else {}


func _definitions(section: String) -> Array:
	return BalanceRegistry.overlay(config.get(section, []), "expansion." + section, _balance())


func _management() -> Variant:
	return model.full_rules.management


func _result(ok: bool, message: String, extra: Dictionary = {}) -> Dictionary:
	var result := {"ok": ok, "message": message, "reason": "" if ok else message}
	result.merge(extra, true)
	return result


func ensure_state() -> void:
	if not model.state.get("expansion") is Dictionary: model.state.expansion = {}
	var state := _state()
	var defaults := {
		"version": 1, "membership": {"enabled": false, "members": 0, "points": 0, "voucher": false, "redeemed": 0, "served_remainder": 0, "observed_served": int(model.state.get("served", 0))},
		"campaigns": [], "delivery_enabled": false, "delivery_offer": {}, "delivery_orders": [], "delivery_next_offer": _now(), "next_id": 1,
		"delivery_revenue": 0.0, "delivery_completed": 0, "branches": {}, "central": {"enabled": false, "stock": {}, "stock_cost": {}, "jobs": [], "shipments": []},
		"explorations": [], "exploration_history": [], "competition": {"active": {}, "best_score": 0.0, "attempts": 0, "wins": 0, "first_reward_claimed": false, "next_entry": 0, "last_result": {}},
		"last_day": int(_now() / 1440), "costs": 0.0, "revenue": 0.0
	}
	for key in defaults:
		if not state.has(key): state[key] = defaults[key].duplicate(true) if defaults[key] is Array or defaults[key] is Dictionary else defaults[key]
	for definition in _definitions("branches"):
		var id := str(definition.id)
		if not state.branches.has(id): state.branches[id] = {"open": false, "stock": {}, "stock_cost": {}, "next_order": _now(), "served": 0, "missed": 0, "revenue": 0.0, "rent_arrears": 0.0}
		if not state.branches[id].has("stock_cost"): state.branches[id].stock_cost = {}
	if not state.central.has("stock_cost"): state.central.stock_cost = {}
	for employee in model.employees:
		if not employee.has("branch_id"): employee.branch_id = ""
		if not employee.has("expansion_until"): employee.expansion_until = 0
		if not employee.has("expansion_job_id"): employee.expansion_job_id = ""
		if not employee.has("awakened"): employee.awakened = false
	if not state.has("league"): state.league = _new_league(int(_now() / 1440))


func _next_id(prefix: String) -> String:
	var id := prefix + str(int(_state().next_id))
	_state().next_id = int(_state().next_id) + 1
	return id


func _definition(section: String, id: String) -> Dictionary:
	for definition in _definitions(section):
		if str(definition.get("id", "")) == id: return definition
	return {}


func _employee(id: String) -> Dictionary:
	return model._employee(id)


func _dish(id: String) -> Dictionary:
	return model._dish(id)


func _available(employee: Dictionary) -> bool:
	if employee.is_empty() or bool(employee.get("pending_resignation", false)): return false
	return str(employee.get("branch_id", "")).is_empty() and int(employee.get("expansion_until", 0)) <= _now() and int(employee.get("management_until", 0)) <= _now() and int(employee.get("training_until", 0)) <= _now() and int(employee.get("research_until", 0)) <= _now() and int(employee.get("busy_customer", 0)) == 0 and float(employee.get("stamina", 0)) > 0


func _chef(id: String = "") -> Dictionary:
	if not id.is_empty():
		var employee := _employee(id)
		return employee if _available(employee) and str(employee.get("role", "")) in ["chef", "all"] else {}
	for employee in model.employees:
		if _available(employee) and str(employee.get("role", "")) in ["chef", "all"]: return employee
	return {}


func _can_pay(cash: float, gems: int = 0) -> bool:
	return float(model.state.get("cash", 0)) + 0.00001 >= cash and int(model.state.get("gems", 0)) >= gems


func _pay(cash: float, gems: int = 0) -> void:
	model.change_cash(-cash,"expansion","长期经营项目支出")
	model.state.gems = int(model.state.gems) - gems
	_state().costs = snappedf(float(_state().costs) + cash, 0.01)


func _record(kind: String, amount: float, memo: String) -> void:
	if model.full_rules.has_method("record"): model.full_rules.record(kind, amount, memo)


func _income(amount: float, gross: float = -1.0, tips: float = 0.0) -> void:
	amount = snappedf(amount, 0.01)
	if gross < 0: gross = amount
	gross = snappedf(gross, 0.01)
	var receipts := amount
	var world: Variant = model.full_rules.get("world")
	if world != null and world.has_method("collect_sales_receipt"): receipts = float(world.collect_sales_receipt(amount, gross, false))
	var received_tips: float=minf(maxf(0,tips),receipts)
	model.change_cash(receipts-received_tips,"sales","分店或外卖营业款")
	model.change_cash(received_tips,"tips","分店小费")
	model.full_rules.finance.record_sale(gross,tips)
	model.state.daily_revenue = snappedf(float(model.state.get("daily_revenue", 0)) + gross, 0.01)
	model.state.total_revenue = snappedf(float(model.state.get("total_revenue", 0)) + gross, 0.01)
	_state().revenue = snappedf(float(_state().revenue) + amount, 0.01)
	_record("sales", gross, "分店或外卖销售")
	if gross > amount: _record("expenses", snappedf(gross - amount, 0.01), "外卖平台服务费")


func _reserve(employee: Dictionary, id: String, due: int) -> void:
	if model.state.has("revision191"):model.full_rules.dollhouse.release_aux(str(employee.id))
	employee.expansion_job_id = id
	employee.expansion_until = due


func _release(employee_id: String, job_id: String) -> void:
	var employee := _employee(employee_id)
	if not employee.is_empty() and str(employee.get("expansion_job_id", "")) == job_id:
		employee.expansion_until = 0
		employee.expansion_job_id = ""
		if _management().has_method("settle_pending_departures"): _management().settle_pending_departures()


func _notify(message: String) -> void:
	if model.has_method("_log"): model._log(message)


func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	ensure_state()
	var stage := int(model.state.get("stage", 0))
	var state := _state()
	var minimum := 2
	if action in ["branch_open", "branch_assign", "branch_return", "central_unlock", "central_cook", "supply_send", "explore"]: minimum = 3
	if action in ["awaken", "compete"]: minimum = 4
	var action_sections := {"membership_enable": "membership", "member_redeem": "membership", "delivery_toggle": "delivery", "delivery_accept": "delivery", "central_unlock": "central", "central_cook": "central", "supply_send": "central", "explore": "exploration", "awaken": "awakening", "compete": "competition"}
	if action_sections.has(action): minimum = int(_section(str(action_sections[action])).get("stage", minimum))
	if action == "campaign": minimum = int(_definition("campaigns", str(args.get("id", ""))).get("stage", minimum))
	if action in ["branch_open", "branch_assign"]: minimum = int(_definition("branches", str(args.get("id", ""))).get("stage", minimum))
	if action == "branch_return":
		var returning := _employee(str(args.get("employee_id", "")))
		minimum = int(_definition("branches", str(returning.get("branch_id", ""))).get("stage", minimum))
	if stage < minimum: return _result(false, "需要阶段 %d" % minimum)
	match action:
		"membership_enable":
			if bool(state.membership.enabled): return _result(false, "会员系统已开放")
			if not _can_pay(float(_section("membership").setup_cost)): return _result(false, "钞票不足")
		"member_redeem":
			if not bool(state.membership.enabled): return _result(false, "请先开通会员")
			if bool(state.membership.voucher): return _result(false, "上一张优惠券尚未使用")
			if int(state.membership.points) < int(_section("membership").redeem_points): return _result(false, "积分不足")
		"delivery_toggle": pass
		"delivery_accept":
			var offer: Dictionary = state.delivery_offer
			if not bool(state.delivery_enabled) or offer.is_empty() or int(offer.get("expires", 0)) <= _now(): return _result(false, "暂无可接外卖单")
			if not str(args.get("offer_id", str(offer.id))) == str(offer.id): return _result(false, "外卖单已更新")
			if state.delivery_orders.size() >= int(_section("delivery").capacity): return _result(false, "外卖配送已满")
			if _chef(str(args.get("employee_id", ""))).is_empty(): return _result(false, "需要空闲厨师")
			if not _management().can_make(str(offer.dish_id)): return _result(false, "菜品食材不足")
			if not _can_pay(float(_section("delivery").courier_cost)): return _result(false, "运费不足")
		"campaign":
			var definition := _definition("campaigns", str(args.get("id", "")))
			if definition.is_empty(): return _result(false, "未知营销活动")
			if stage < int(definition.stage): return _result(false, "阶段尚未开放该活动")
			for campaign in state.campaigns:
				if str(campaign.id) == str(definition.id) and int(campaign.until) > _now(): return _result(false, "该营销活动仍在进行")
			if not _can_pay(float(definition.cash), int(definition.gems)): return _result(false, "营销预算不足")
		"branch_open":
			var definition := _definition("branches", str(args.get("id", "")))
			if definition.is_empty(): return _result(false, "未知分店")
			if stage < int(definition.stage): return _result(false, "该世界尚未开放")
			if bool(state.branches[str(definition.id)].open): return _result(false, "分店已营业")
			if not _can_pay(float(definition.cost)): return _result(false, "开店资金不足")
		"branch_assign":
			var id := str(args.get("id", ""))
			if not state.branches.has(id) or not bool(state.branches[id].open): return _result(false, "分店尚未开业")
			if not _available(_employee(str(args.get("employee_id", "")))): return _result(false, "员工正在工作、培训、研究或已调往分店")
		"branch_return":
			var employee := _employee(str(args.get("employee_id", "")))
			if employee.is_empty() or str(employee.get("branch_id", "")).is_empty(): return _result(false, "该员工未派驻分店")
		"central_unlock":
			if bool(state.central.enabled): return _result(false, "中央厨房已开放")
			if not _can_pay(float(_section("central").unlock_cost)): return _result(false, "建设资金不足")
		"central_cook":
			if not bool(state.central.enabled): return _result(false, "请先建设中央厨房")
			var quantity := int(args.get("quantity", 5))
			var dish_id := str(args.get("dish_id", "noodles"))
			if quantity < 1 or quantity > int(_section("central").batch_max): return _result(false, "批量数量超出范围")
			if not model.state.get("unlocked_dishes", []).has(dish_id) or _dish(dish_id).is_empty(): return _result(false, "菜品未研发")
			if _chef(str(args.get("employee_id", ""))).is_empty(): return _result(false, "需要空闲厨师主持")
			if _central_total() + quantity > int(_section("central").storage_capacity): return _result(false, "中央厨房库存与在制品超过容量")
			if not _management().can_make(dish_id, quantity): return _result(false, "批量原料不足")
		"supply_send":
			var id := str(args.get("id", ""))
			var dish_id := str(args.get("dish_id", "noodles"))
			var quantity := int(args.get("quantity", 5))
			if not state.branches.has(id) or not bool(state.branches[id].open): return _result(false, "分店尚未开业")
			if quantity < 1 or int(state.central.stock.get(dish_id, 0)) < quantity: return _result(false, "中央厨房成品不足")
			if not _can_pay(quantity * float(_section("central").shipping_cost_each)): return _result(false, "调拨运费不足")
		"explore":
			if not str(args.get("location","old_restaurant")) in ["old_restaurant","kunlun_path","three_realms_rift"]: return _result(false,"未知探索地点")
			if state.explorations.size() >= int(_section("exploration").capacity): return _result(false, "探索队已满")
			if not _available(_employee(str(args.get("employee_id", "")))): return _result(false, "请选择空闲员工")
			if not _can_pay(float(_section("exploration").cash), int(_section("exploration").gems)): return _result(false, "探索资源不足")
		"awaken":
			var employee := _employee(str(args.get("employee_id", "")))
			if employee.is_empty(): return _result(false, "员工不存在")
			# Repeated awakening raises the rarity level cap by10 each time.
			if not _available(employee): return _result(false, "觉醒需要空闲员工")
			if int(model.state.get("fragments", {}).get(str(employee.id), 0)) < int(_section("awakening").fragments): return _result(false, "同名员工碎片不足")
			if not _can_pay(float(_section("awakening").cash), int(_section("awakening").gems)): return _result(false, "觉醒资源不足")
		"compete":
			if not state.competition.active.is_empty(): return _result(false, "比赛正在进行")
			if int(state.competition.next_entry) > _now(): return _result(false, "下一场比赛尚未开始")
			if not model.state.get("unlocked_dishes", []).has(str(args.get("dish_id", ""))): return _result(false, "参赛菜品未研发")
			if _chef(str(args.get("employee_id", ""))).is_empty(): return _result(false, "请选择空闲厨师")
			if not _management().can_make(str(args.get("dish_id", ""))): return _result(false, "参赛食材不足")
			if not _can_pay(float(_section("competition").cash), int(_section("competition").gems)): return _result(false, "报名资源不足")
		_: return _result(false, "未知后期操作：" + action)
	return _result(true, "可以执行")


func perform(action: String, args: Dictionary = {}) -> Dictionary:
	var check := can_perform(action, args)
	if not bool(check.ok): return check
	var state := _state()
	var message := "操作完成"
	match action:
		"membership_enable":
			_pay(float(_section("membership").setup_cost))
			state.membership.enabled = true
			state.membership.observed_served = int(model.state.get("served", 0))
			message = "会员计划开放：每三笔堂食发展一名会员，真实结账积累积分"
		"member_redeem":
			state.membership.points = int(state.membership.points) - int(_section("membership").redeem_points)
			state.membership.voucher = true
			state.membership.redeemed = int(state.membership.redeemed) + 1
			message = "积分已兑换下笔堂食九折券，结账时自动核销"
		"delivery_toggle":
			state.delivery_enabled = bool(args.get("enabled", not bool(state.delivery_enabled)))
			if not bool(state.delivery_enabled): state.delivery_offer = {}
			message = "外卖接单已开启" if bool(state.delivery_enabled) else "外卖接单已暂停；在途订单继续配送"
		"delivery_accept":
			var offer: Dictionary = state.delivery_offer.duplicate(true)
			var worker := _chef(str(args.get("employee_id", "")))
			var consumed: Dictionary = _management().consume(str(offer.dish_id), 1, false)
			if not bool(consumed.get("ok", false)): return _result(false, "食材刚刚发生变化")
			_pay(float(_section("delivery").courier_cost))
			var due := _now() + int(_dish(str(offer.dish_id)).get("cook_minutes", 5)) + int(_section("delivery").travel_minutes)
			var job := {"id": str(offer.id), "dish_id": str(offer.dish_id), "employee_id": str(worker.id), "due": due, "gross": float(offer.price), "net": snappedf(float(offer.price) * (1.0 - float(_section("delivery").commission)), 0.01), "ingredient_cost": float(consumed.get("cost", 0))}
			state.delivery_orders.append(job)
			_reserve(worker, str(job.id), due)
			state.delivery_offer = {}
			state.delivery_next_offer = _now() + int(_section("delivery").offer_interval)
			message = "外卖已接单：已扣食材和运费，送达后扣平台费再到账"
		"campaign":
			var definition := _definition("campaigns", str(args.id))
			_pay(float(definition.cash), int(definition.gems))
			state.campaigns.append({"id": str(definition.id), "until": _now() + int(definition.minutes)})
			message = str(definition.name) + "已启动"
		"branch_open":
			var definition := _definition("branches", str(args.id))
			_pay(float(definition.cost))
			state.branches[str(args.id)].open = true
			state.branches[str(args.id)].next_order = _now() + int(definition.order_minutes)
			message = str(definition.name) + "已开业；请派驻厨师与前厅员工并调拨成品"
		"branch_assign":
			var employee := _employee(str(args.employee_id))
			employee.branch_id = str(args.id)
			if model.state.has("revision191"):model.full_rules.dollhouse.release_aux(str(employee.id))
			employee.branch_previous_rest = bool(employee.get("resting", false))
			employee.branch_recovering = float(employee.get("stamina", 0)) <= 0
			employee.resting = true
			message = str(employee.name) + "已派驻分店，不再参与主店任务；工资照常结算"
		"branch_return":
			var employee := _employee(str(args.employee_id))
			employee.branch_id = ""
			employee.branch_recovering = false
			employee.resting = bool(employee.get("branch_previous_rest", true))
			message = str(employee.name) + "已返回主店"
			if not bool(employee.resting) and model.full_rules.has_method("can_return_to_work"):
				# Check while resting so the returning employee is not counted twice.
				employee.resting = true
				if model.full_rules.can_return_to_work(str(employee.id)): employee.resting = false
				else: message += "；当班容量已满，先安排休息，腾出岗位后可恢复当班"
		"central_unlock":
			_pay(float(_section("central").unlock_cost))
			state.central.enabled = true
			message = "中央厨房建设完成"
		"central_cook":
			var dish_id := str(args.get("dish_id", "noodles"))
			var quantity := int(args.get("quantity", 5))
			var consumed: Dictionary = _management().consume(dish_id, quantity, false)
			if not bool(consumed.get("ok", false)): return _result(false, "批量原料刚刚发生变化")
			var worker := _chef(str(args.get("employee_id", "")))
			var due := _now() + maxi(1, int(_section("central").cook_minutes_each) * quantity)
			var id := _next_id("central_")
			state.central.jobs.append({"id": id, "dish_id": dish_id, "quantity": quantity, "employee_id": str(worker.id), "due": due, "ingredient_cost": float(consumed.get("cost", 0))})
			_reserve(worker, id, due)
			message = "中央厨房已投料，成品将在批次完成后入库"
		"supply_send":
			var dish_id := str(args.get("dish_id", "noodles"))
			var quantity := int(args.get("quantity", 5))
			_pay(quantity * float(_section("central").shipping_cost_each))
			var inventory_cost := float(state.central.stock_cost.get(dish_id, 0)) * quantity / maxi(1, int(state.central.stock.get(dish_id, 0)))
			state.central.stock[dish_id] = int(state.central.stock.get(dish_id, 0)) - quantity
			state.central.stock_cost[dish_id] = maxf(0, float(state.central.stock_cost.get(dish_id, 0)) - inventory_cost)
			state.central.shipments.append({"id": _next_id("shipment_"), "branch_id": str(args.id), "dish_id": dish_id, "quantity": quantity, "ingredient_cost": inventory_cost, "due": _now() + int(_section("central").shipping_minutes)})
			message = "成品已从中央仓出库，在途调拨不会提前产生销售收入"
		"explore":
			var worker := _employee(str(args.employee_id))
			_pay(float(_section("exploration").cash), int(_section("exploration").gems))
			var rewards: Array = _section("exploration").rewards
			var reward: Dictionary = rewards[model._rng.randi_range(0, rewards.size() - 1)].duplicate(true)
			var fragment_id := str(model.catalog[model._rng.randi_range(0, model.catalog.size() - 1)].id)
			var id := _next_id("explore_")
			var due := _now() + int(_section("exploration").minutes)
			state.explorations.append({"id":id,"employee_id":str(worker.id),"due":due,"reward":reward,"fragment_id":fragment_id,"location":str(args.get("location","old_restaurant"))})
			_reserve(worker, id, due)
			message = "探索队出发：员工暂离岗位，返回后自动结算并记录"
		"awaken":
			var employee := _employee(str(args.employee_id))
			_pay(float(_section("awakening").cash), int(_section("awakening").gems))
			model.state.fragments[str(employee.id)] = int(model.state.fragments[str(employee.id)]) - int(_section("awakening").fragments)
			employee.awake_base_attributes = employee.attributes.duplicate(true)
			for key in employee.attributes: employee.attributes[key] = float(employee.attributes[key]) + float(_section("awakening").attribute_gain)
			if model.has_method("initialize_employee_motion"): model.initialize_employee_motion(employee, true)
			employee.awakened = true
			employee.awakening_count=int(employee.get("awakening_count",0))+1
			employee.appearance_state = "awakened"
			message = str(employee.name) + "已觉醒：全属性提升，外观资源使用 awakened 状态"
		"compete":
			var dish_id := str(args.dish_id)
			var consumed: Dictionary = _management().consume(dish_id, 1, false)
			if not bool(consumed.get("ok", false)): return _result(false, "参赛原料刚刚发生变化")
			var worker := _chef(str(args.get("employee_id", "")))
			_pay(float(_section("competition").cash), int(_section("competition").gems))
			var id := _next_id("competition_")
			var due := _now() + int(_section("competition").minutes)
			state.competition.active = {"id": id, "employee_id": str(worker.id), "dish_id": dish_id, "due": due, "score": _competition_score(worker, _dish(dish_id)), "ingredient_cost": float(consumed.get("cost", 0))}
			state.competition.attempts = int(state.competition.attempts) + 1
			_reserve(worker, id, due)
			message = "厨神大赛开始：按当前厨艺、创意、参赛菜品与觉醒状态评分"
	_notify(message)
	return _result(true, message)


func _central_total() -> int:
	var total := 0
	for quantity in _state().central.stock.values(): total += int(quantity)
	for job in _state().central.jobs: total += int(job.quantity)
	return total


func _competition_score(employee: Dictionary, dish: Dictionary) -> float:
	var settings := _section("competition")
	var attributes: Dictionary = employee.get("attributes", {})
	var score := float(settings.base_score) + float(attributes.get("cooking", 0)) * float(settings.cooking_weight) + float(attributes.get("creativity", 0)) * float(settings.creativity_weight) + float(dish.get("price", 0)) * float(settings.dish_value_weight)
	if bool(employee.get("awakened", false)): score += float(settings.awakened_bonus)
	return snappedf(clampf(score, 0, 100), 0.1)


func tick_minute() -> void:
	ensure_state()
	var state := _state()
	_tick_membership()
	for index in range(state.campaigns.size() - 1, -1, -1):
		if int(state.campaigns[index].until) <= _now(): state.campaigns.remove_at(index)
	_tick_delivery()
	_tick_central()
	_tick_branches()
	_tick_exploration()
	_tick_competition()


func _tick_membership() -> void:
	var membership: Dictionary = _state().membership
	var served := int(model.state.get("served", 0))
	var difference := maxi(0, served - int(membership.observed_served))
	membership.observed_served = served
	if not bool(membership.enabled) or difference == 0: return
	var multiplier := 1
	for campaign in _state().campaigns:
		if int(campaign.until) > _now(): multiplier = maxi(multiplier, int(_definition("campaigns", str(campaign.id)).get("member_multiplier", 1)))
	membership.points = int(membership.points) + difference * int(_section("membership").points_per_order)
	membership.served_remainder = int(membership.served_remainder) + difference * multiplier
	var every := maxi(1, int(_section("membership").enroll_every_orders))
	membership.members = int(membership.members) + int(int(membership.served_remainder) / every)
	membership.served_remainder = int(membership.served_remainder) % every


func checkout_adjustment(amount: float) -> float:
	ensure_state()
	var membership: Dictionary = _state().membership
	if bool(membership.enabled) and bool(membership.voucher) and amount > 0:
		membership.voucher = false
		return snappedf(amount * (1.0 - float(_section("membership").voucher_discount)), 0.01)
	return amount


func traffic_bonus() -> float:
	ensure_state()
	var bonus := 0.0
	if bool(_state().membership.enabled): bonus += minf(float(_section("membership").max_traffic_bonus), int(_state().membership.members) * float(_section("membership").member_traffic_each))
	for campaign in _state().campaigns:
		if int(campaign.until) > _now(): bonus += float(_definition("campaigns", str(campaign.id)).get("traffic_bonus", 0))
	return bonus


func _tick_delivery() -> void:
	var state := _state()
	for index in range(state.delivery_orders.size() - 1, -1, -1):
		var order: Dictionary = state.delivery_orders[index]
		if int(order.due) > _now(): continue
		_income(float(order.net), float(order.gross))
		_management().recognize_cost(float(order.get("ingredient_cost", 0)))
		_record("cost_of_sales", float(order.get("ingredient_cost", 0)), "外卖耗用食材")
		state.delivery_revenue = snappedf(float(state.delivery_revenue) + float(order.net), 0.01)
		state.delivery_completed = int(state.delivery_completed) + 1
		_release(str(order.employee_id), str(order.id))
		state.delivery_orders.remove_at(index)
		_notify("外卖送达，扣除平台费用后到账 ￥%.2f" % float(order.net))
	if not state.delivery_offer.is_empty() and int(state.delivery_offer.expires) <= _now(): state.delivery_offer = {}
	if int(model.state.get("stage", 0)) < int(_section("delivery").stage) or not bool(state.delivery_enabled) or not state.delivery_offer.is_empty() or _now() < int(state.delivery_next_offer) or not model.business_open(): return
	var menu: Array = model.state.get("menu_enabled", [])
	if menu.is_empty(): return
	var dish_id := str(menu[model._rng.randi_range(0, menu.size() - 1)])
	var dish := _dish(dish_id)
	if dish.is_empty(): return
	state.delivery_offer = {"id": _next_id("delivery_"), "dish_id": dish_id, "price": float(dish.get("price", 0)), "expires": _now() + int(_section("delivery").offer_expiry)}
	state.delivery_next_offer = _now() + int(_section("delivery").offer_interval)


func _tick_central() -> void:
	var central: Dictionary = _state().central
	for index in range(central.jobs.size() - 1, -1, -1):
		var job: Dictionary = central.jobs[index]
		if int(job.due) > _now(): continue
		central.stock[str(job.dish_id)] = int(central.stock.get(str(job.dish_id), 0)) + int(job.quantity)
		central.stock_cost[str(job.dish_id)] = float(central.stock_cost.get(str(job.dish_id), 0)) + float(job.get("ingredient_cost", 0))
		_release(str(job.employee_id), str(job.id))
		central.jobs.remove_at(index)
	for index in range(central.shipments.size() - 1, -1, -1):
		var shipment: Dictionary = central.shipments[index]
		if int(shipment.due) > _now(): continue
		var branch: Dictionary = _state().branches[str(shipment.branch_id)]
		branch.stock[str(shipment.dish_id)] = int(branch.stock.get(str(shipment.dish_id), 0)) + int(shipment.quantity)
		branch.stock_cost[str(shipment.dish_id)] = float(branch.stock_cost.get(str(shipment.dish_id), 0)) + float(shipment.get("ingredient_cost", 0))
		central.shipments.remove_at(index)


func _branch_staff(id: String) -> Dictionary:
	var result := {"chefs":0,"front":0,"quality":0.0,"staff":[],"chef_id":"","cashier_id":"","salespeople":[]}
	for employee in model.employees:
		if str(employee.get("branch_id", "")) != id: continue
		if bool(employee.get("branch_recovering",false)) or (bool(employee.get("shift_enabled",false)) and not model.period() in employee.get("shift_periods",[])): continue
		if float(employee.get("stamina", 0)) <= 0 or float(employee.get("mood", 0)) <= 0: continue
		result.staff.append(str(employee.id))
		var role := str(employee.get("role", ""))
		if role in ["chef", "all"]:
			result.chefs = int(result.chefs) + 1
			if float(employee.get("attributes",{}).get("cooking",0))>=float(result.quality):
				result.quality=float(employee.get("attributes",{}).get("cooking",0))
				result.chef_id=str(employee.id)
		if role in ["waiter","salesman","all"]:
			result.front=int(result.front)+1
			result.cashier_id=str(employee.id)
		if role in ["salesman","all"]: result.salespeople.append(str(employee.id))
	return result


func _branch_order_dish(branch: Dictionary, _staffing: Dictionary, customer: Dictionary, branch_id: String="") -> Dictionary:
	var choices: Array=[]
	for id in branch.stock:
		if int(branch.stock[id])<=0 or not id in model.state.menu_enabled or not id in model.state.unlocked_dishes:continue
		var dish=_dish(str(id))
		if not dish.is_empty() and (str(id)!="jiuying_platter" or int(customer.get("group_size",1))>=3):choices.append(dish)
	if cultural_adapter!=null:choices=cultural_adapter.branch_menu(branch_id,choices)
	return model.full_rules.customer_service._weighted_dish(choices,customer)

func _tick_branches() -> void:
	for definition in _definitions("branches"):
		if int(model.state.get("stage", 0)) < int(definition.stage): continue
		var branch: Dictionary = _state().branches[str(definition.id)]
		if not bool(branch.open) or int(branch.next_order) > _now(): continue
		branch.next_order = _now() + int(definition.order_minutes)
		if not model.business_open(): continue
		var staffing := _branch_staff(str(definition.id))
		var demand := int(definition.base_demand) + mini(3, int(int(model.state.get("reputation", 0)) / 2000))
		var capacity := mini(int(staffing.chefs), int(staffing.front)) * 3
		var served := 0
		branch.last_sales=[]
		for order_index in mini(demand,capacity):
			var customer: Dictionary={"type":model._roll_customer_type(),"preference_profile":model.full_rules.preferences.generate_profile(),"group_size":1,"recommendation_premium":0.0}
			var dish: Dictionary=_branch_order_dish(branch,staffing,customer,str(definition.id))
			if dish.is_empty(): continue
			var dish_id: String=str(dish.id)
			var ingredient_cost: float=float(branch.stock_cost.get(dish_id,0))/maxi(1,int(branch.stock[dish_id]))
			branch.stock_cost[dish_id]=maxf(0,float(branch.stock_cost.get(dish_id,0))-ingredient_cost)
			branch.stock[dish_id]=int(branch.stock[dish_id])-1
			var chef: Dictionary=_employee(str(staffing.chef_id))
			var cashier: Dictionary=_employee(str(staffing.cashier_id))
			var quality: float=clampf((_management().dish_quality(dish_id)+float(staffing.quality)*model._b("prototype.quality_per_cooking_point"))*float(_management().modifiers(dish_id,chef).quality_mult),0,model._b("dish.quality_max"))
			var sources: Dictionary=model.full_rules.customer_service.collect_price_sources(dish,chef,cashier)
			sources.skill["branch:location"]=float(definition.price_multiplier)-1.0
			var attributes: Dictionary=cashier.get("attributes",{})
			var personal: Dictionary={}
			var quote: Dictionary=model.full_rules.customer_service.price_quote(dish,quality,customer,personal,sources)
			var amount: float=float(quote.final)
			var tips: float=0.0
			if model._rng.randf()<minf(1,model._b("customer.tip_chance")+model.full_rules.tip_bonus(cashier)):
				tips=minf(floorf(amount*model._b("customer.tip_fraction")),maxf(0,float(quote.cap)-amount))
			amount+=tips
			_income(amount,-1,tips)
			_management().recognize_cost(ingredient_cost)
			_record("cost_of_sales",ingredient_cost,str(definition.name)+"成品耗用")
			branch.revenue=snappedf(float(branch.revenue)+amount,0.01)
			branch.last_sales.append({"dish_id":dish_id,"amount":amount,"tips":tips,"recommended":bool(customer.get("recommendation_success",false)),"quote":quote})
			served+=1
		branch.served = int(branch.served) + served
		branch.missed = int(branch.missed) + demand - served
		if served > 0:
			model.state.reputation = int(model.state.reputation) + mini(2, served)
			for employee_id in staffing.staff:
				var employee := _employee(str(employee_id))
				if employee.is_empty(): continue
				employee.stamina = maxf(0.0, float(employee.stamina) - served * 0.5)


func _tick_exploration() -> void:
	var state := _state()
	for index in range(state.explorations.size() - 1, -1, -1):
		var job: Dictionary = state.explorations[index]
		if int(job.due) > _now(): continue
		var reward: Dictionary = job.reward
		for id in reward.items: _management().add_item(str(id), float(reward.items[id]))
		model.state.gems = int(model.state.gems) + int(reward.gems)
		model.state.reputation = int(model.state.reputation) + int(_section("exploration").reputation)
		var fragments: Dictionary = model.state.get("fragments", {})
		fragments[str(job.fragment_id)] = int(fragments.get(str(job.fragment_id), 0)) + int(reward.fragments)
		model.state.fragments = fragments
		_release(str(job.employee_id), str(job.id))
		state.exploration_history.append({"id":str(job.id),"minute":_now(),"reward":reward.duplicate(true),"fragment_id":str(job.fragment_id),"location":str(job.get("location","old_restaurant"))})
		if model.full_rules.get("sidequests")!=null: model.full_rules.sidequests.on_exploration(str(job.get("location","old_restaurant")),job)
		while state.exploration_history.size() > 20: state.exploration_history.pop_front()
		state.explorations.remove_at(index)
		# Publish the letter only after rewards, release and history are committed.
		if cultural_adapter!=null:cultural_adapter.on_exploration(job)
		_notify("山海探索队返回，食材、灵石与员工碎片已入库")


func _tick_competition() -> void:
	var competition: Dictionary = _state().competition
	var job: Dictionary = competition.active
	if job.is_empty() or int(job.due) > _now(): return
	var settings := _section("competition")
	var won := float(job.score) >= float(settings.win_score)
	var first := won and not bool(competition.first_reward_claimed)
	var cash := 0.0
	var gems := 0
	var reputation := int(settings.participation_reputation)
	if won:
		competition.wins = int(competition.wins) + 1
		cash = float(settings.first_win_cash) if first else float(settings.repeat_win_cash)
		gems = int(settings.first_win_gems) if first else 0
		reputation = int(settings.first_win_reputation) if first else int(settings.repeat_win_reputation)
		competition.first_reward_claimed = true
		## Prize is a grant, not restaurant sales revenue.
		model.change_cash(cash,"reward","厨神大赛奖金")
		model.state.gems = int(model.state.gems) + gems
		_record("financing", cash, "厨神大赛奖励")
	model.state.reputation = int(model.state.reputation) + reputation
	competition.best_score = maxf(float(competition.best_score), float(job.score))
	competition.next_entry = _now() + int(settings.cooldown_minutes)
	competition.last_result = {"id": str(job.id), "score": float(job.score), "won": won, "first_reward": first, "cash": cash, "gems": gems, "reputation": reputation}
	_release(str(job.employee_id), str(job.id))
	_record("expenses", float(job.get("ingredient_cost", 0)), "厨神大赛参赛食材")
	competition.active = {}
	_notify("厨神大赛 %.1f 分：%s" % [float(job.score), "夺冠！" if won else "积累经验后可再次挑战"])


func on_day() -> void:
	ensure_state()
	var state := _state()
	var day := int(_now() / 1440)
	_tick_league(day)
	if day <= int(state.last_day): return
	var days := day - int(state.last_day)
	state.last_day = day
	for definition in _definitions("branches"):
		var branch: Dictionary = state.branches[str(definition.id)]
		if not bool(branch.open): continue
		var due := float(definition.rent) * days + float(branch.rent_arrears)
		var paid := minf(due, maxf(0, float(model.state.cash)))
		_pay(paid)
		_record("expenses", paid, str(definition.name) + "租金")
		branch.rent_arrears = snappedf(due - paid, 0.01)
		if paid < due: model.state.reputation = maxi(0, int(model.state.reputation) - 5)


func _league_player_stats() -> Dictionary:
	var branches := 0
	for branch in _state().branches.values():
		if bool(branch.open): branches += 1
	return {"revenue": float(model.state.get("total_revenue", 0)), "reputation": int(model.state.get("reputation", 0)), "branches": branches, "wins": int(_state().competition.wins)}


func _new_league(day: int) -> Dictionary:
	var companies := {}
	for definition in _section("leaderboard").get("companies", []):
		companies[str(definition.id)] = {"revenue": 0.0, "costs": 0.0, "cash": float(definition.start_cash), "reputation": 0, "branches": int(definition.branches), "daily_revenue": 0.0, "daily_profit": 0.0}
	return {"season": 1, "start_day": day, "last_day": day, "player_baseline": _league_player_stats(), "companies": companies, "history": []}


func _league_score(revenue: float, reputation: int, branches: int, champion: bool) -> float:
	var settings := _section("leaderboard")
	return snappedf(maxf(0, revenue) * float(settings.revenue_weight) + maxi(0, reputation) * float(settings.reputation_weight) + branches * float(settings.branch_weight) + (float(settings.champion_bonus) if champion else 0.0), 0.1)


func _league_rows(league: Dictionary) -> Array:
	var settings := _section("leaderboard")
	var rows: Array = []
	for definition in settings.get("companies", []):
		var company: Dictionary = league.companies.get(str(definition.id), {})
		if company.is_empty(): continue
		rows.append({"id": str(definition.id), "name": str(definition.name) + "（单机NPC）", "score": _league_score(float(company.revenue), int(company.reputation), int(company.branches), false), "player": false, "revenue": float(company.revenue), "reputation": int(company.reputation), "branches": int(company.branches), "daily_revenue": float(company.daily_revenue), "daily_profit": float(company.daily_profit)})
	var current := _league_player_stats()
	var baseline: Dictionary = league.player_baseline
	var revenue := maxf(0, float(current.revenue) - float(baseline.revenue))
	var reputation := maxi(0, int(current.reputation) - int(baseline.reputation))
	var champion := int(current.wins) > int(baseline.wins)
	rows.append({"id": "player", "name": "有间小馆（玩家）", "score": _league_score(revenue, reputation, int(current.branches), champion), "player": true, "revenue": revenue, "reputation": reputation, "branches": int(current.branches)})
	rows.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if not is_equal_approx(float(a.score), float(b.score)): return float(a.score) > float(b.score)
		return str(a.id) < str(b.id))
	return rows


func _tick_league(day: int) -> void:
	var league: Dictionary = _state().league
	var settings := _section("leaderboard")
	var season_days := maxi(1, int(settings.get("season_days", 30)))
	for settled_day in range(int(league.last_day) + 1, day + 1):
		var age := settled_day - int(league.start_day)
		for index in range(settings.get("companies", []).size()):
			var definition: Dictionary = settings.companies[index]
			var company: Dictionary = league.companies[str(definition.id)]
			# Deterministic market/weather cycles never consume the player's recruitment RNG.
			var market := 1.0 + sin(float(settled_day + index * 3) * 0.71) * float(settings.get("market_volatility", 0.18))
			var trend := 1.0 + minf(float(settings.get("growth_cap", 1.0)), age * float(definition.daily_growth))
			var revenue := snappedf(float(definition.daily_revenue) * market * trend * (1.0 + maxi(0, int(company.branches) - int(definition.branches)) * float(settings.get("expansion_sales_gain", 0.12))), 0.01)
			var costs := snappedf(revenue * float(definition.expense_ratio) + int(company.branches) * float(settings.get("branch_daily_cost", 100)), 0.01)
			company.revenue = snappedf(float(company.revenue) + revenue, 0.01)
			company.costs = snappedf(float(company.costs) + costs, 0.01)
			company.cash = snappedf(maxf(0, float(company.cash) + revenue - costs), 0.01)
			company.daily_revenue = revenue
			company.daily_profit = snappedf(revenue - costs, 0.01)
			company.reputation = maxi(0, int(company.reputation) + int(round(float(definition.daily_reputation) * market)) - (5 if revenue < costs else 0))
			if int(company.branches) < int(definition.max_branches) and float(company.cash) >= float(definition.expansion_cost) * 1.5:
				company.cash = snappedf(float(company.cash) - float(definition.expansion_cost), 0.01)
				company.branches = int(company.branches) + 1
		league.last_day = settled_day
		if age >= season_days:
			var rows := _league_rows(league)
			var player_rank := 0
			for index in range(rows.size()):
				if bool(rows[index].player): player_rank = index + 1
			league.history.append({"season": int(league.season), "start_day": int(league.start_day), "end_day": settled_day, "player_rank": player_rank, "rows": rows.duplicate(true)})
			while league.history.size() > int(settings.get("history_limit", 12)): league.history.pop_front()
			league.season = int(league.season) + 1
			league.start_day = settled_day
			league.player_baseline = _league_player_stats()
			for company in league.companies.values():
				company.revenue = 0.0
				company.costs = 0.0
				company.reputation = 0
			_notify("单机世界榜第%d赛季结束：本店第%d名，历史成绩已保存" % [int(league.season) - 1, player_rank])


func leaderboard() -> Array:
	ensure_state()
	return _league_rows(_state().league)


func snapshot() -> Dictionary:
	ensure_state()
	var result := _state().duplicate(true)
	result.config = BalanceRegistry.overlay(config, "expansion", _balance())
	result.stage = int(model.state.get("stage", 0))
	result.traffic_bonus = traffic_bonus()
	result.leaderboard_label = str(_section("leaderboard").get("label", "本地单机模拟榜"))
	result.leaderboard_rules = str(_section("leaderboard").get("rules", ""))
	result.league_season_days = int(_section("leaderboard").get("season_days", 30))
	result.leaderboard = leaderboard()
	result.prepared_inventory_value = prepared_inventory_value()
	result.available_employees = []
	for employee in model.employees:
		var entry: Dictionary = employee.duplicate(true)
		entry.available = _available(employee)
		result.available_employees.append(entry)
	for definition in _definitions("branches"):
		result.branches[str(definition.id)].definition = definition.duplicate(true)
		result.branches[str(definition.id)].staffing = _branch_staff(str(definition.id))
	return result


func prepared_inventory_value() -> float:
	var value := 0.0
	if "international" in model.full_rules and model.full_rules.international!=null:value+=model.full_rules.international.inventory_value()
	for cost in _state().central.stock_cost.values(): value += float(cost)
	for job in _state().central.jobs: value += float(job.get("ingredient_cost", 0))
	for job in _state().central.shipments: value += float(job.get("ingredient_cost", 0))
	for job in _state().delivery_orders: value += float(job.get("ingredient_cost", 0))
	for branch in _state().branches.values():
		for cost in branch.stock_cost.values(): value += float(cost)
	return snappedf(value, 0.01)


func _valid_number(value: Variant, minimum: float = 0.0) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum


func _valid_integer(value: Variant, minimum: int = 0) -> bool:
	return _valid_number(value, minimum) and float(value) == floorf(float(value))


func _valid_stock(value: Variant, integer_quantity: bool = true) -> bool:
	if not value is Dictionary: return false
	for id in value:
		if not id is String or _dish(id).is_empty(): return false
		if not _valid_number(value[id]): return false
		if integer_quantity and not _valid_integer(value[id]): return false
	return true


func _valid_job(job: Variant, employees: Dictionary, jobs: Dictionary) -> bool:
	if not job is Dictionary or not job.get("id") is String or str(job.id).is_empty() or jobs.has(str(job.id)): return false
	if not job.get("employee_id") is String or not employees.has(str(job.employee_id)) or not _valid_integer(job.get("due")): return false
	var employee: Dictionary = employees[str(job.employee_id)]
	if int(employee.get("expansion_until", -1)) != int(job.due) or str(employee.get("expansion_job_id", "")) != str(job.id): return false
	for existing in jobs.values():
		if str(existing.employee_id) == str(job.employee_id): return false
	jobs[str(job.id)] = job
	return true


func _valid_league_stats(stats: Variant) -> bool:
	if not stats is Dictionary: return false
	return _valid_number(stats.get("revenue")) and _valid_integer(stats.get("reputation")) and _valid_integer(stats.get("branches")) and _valid_integer(stats.get("wins"))


func _valid_league(league: Variant, saved: Dictionary) -> bool:
	if not league is Dictionary or not league.get("companies") is Dictionary or not league.get("history") is Array: return false
	for key in ["season", "start_day", "last_day"]:
		if not _valid_integer(league.get(key)): return false
	if int(league.season) < 1 or int(league.start_day) > int(league.last_day) or int(league.last_day) > int(int(saved.get("total_minutes", 0)) / 1440): return false
	if not _valid_league_stats(league.get("player_baseline")): return false
	if float(league.player_baseline.revenue) > float(saved.get("total_revenue", 0)): return false
	var settings := _section("leaderboard")
	if league.companies.size() != settings.get("companies", []).size(): return false
	for definition in settings.get("companies", []):
		var company: Variant = league.companies.get(str(definition.id))
		if not company is Dictionary: return false
		for key in ["revenue", "costs", "cash", "daily_revenue"]:
			if not _valid_number(company.get(key)): return false
		if not _valid_number(company.get("daily_profit"), -1e15): return false
		if not _valid_integer(company.get("reputation")) or not _valid_integer(company.get("branches")) or int(company.branches) > int(definition.max_branches): return false
	if league.history.size() > int(settings.get("history_limit", 12)): return false
	var previous_season := 0
	for history in league.history:
		if not history is Dictionary or not history.get("rows") is Array or history.rows.size() != league.companies.size() + 1: return false
		for key in ["season", "start_day", "end_day", "player_rank"]:
			if not _valid_integer(history.get(key)): return false
		if int(history.season) <= previous_season or int(history.season) >= int(league.season) or int(history.start_day) > int(history.end_day) or int(history.end_day) > int(league.start_day): return false
		if int(history.player_rank) < 1 or int(history.player_rank) > history.rows.size(): return false
		var seen := {}
		var player_found := false
		for row in history.rows:
			if not row is Dictionary or not row.get("id") is String or not row.get("name") is String or not row.get("player") is bool or not _valid_number(row.get("score")): return false
			if seen.has(str(row.id)) or (str(row.id) != "player" and not league.companies.has(str(row.id))): return false
			seen[str(row.id)] = true
			if bool(row.player):
				if str(row.id) != "player" or player_found: return false
				player_found = true
		if not player_found or not bool(history.rows[int(history.player_rank) - 1].player): return false
		previous_season = int(history.season)
	return true


func validate_state(saved: Dictionary, saved_employees: Array = []) -> bool:
	## Called before installing a loaded save, so validation never mutates live state.
	var state: Variant = saved.get("expansion")
	if not state is Dictionary: return false
	# Prior saves acquire a fresh league on load, without fabricated history.
	if state.has("league") and not _valid_league(state.league, saved): return false
	for key in ["membership", "delivery_offer", "branches", "central", "competition"]:
		if not state.get(key) is Dictionary: return false
	for key in ["campaigns", "delivery_orders", "explorations", "exploration_history"]:
		if not state.get(key) is Array or state[key].size() > 1000: return false
	for key in ["version", "next_id", "delivery_next_offer", "delivery_completed", "last_day"]:
		if not _valid_integer(state.get(key)): return false
	if int(state.next_id) < 1 or not state.get("delivery_enabled") is bool: return false
	for key in ["delivery_revenue", "costs", "revenue"]:
		if not _valid_number(state.get(key)): return false
	var membership: Dictionary = state.membership
	for key in ["enabled", "voucher"]:
		if not membership.get(key) is bool: return false
	for key in ["members", "points", "redeemed", "served_remainder", "observed_served"]:
		if not _valid_integer(membership.get(key)): return false
	if int(membership.observed_served) > int(saved.get("served", 0)): return false
	for campaign in state.campaigns:
		if not campaign is Dictionary or _definition("campaigns", str(campaign.get("id", ""))).is_empty() or not _valid_integer(campaign.get("until")): return false
	var employees := {}
	for employee in saved_employees:
		if not employee is Dictionary or not employee.get("id") is String: return false
		employees[str(employee.id)] = employee
	var jobs := {}
	var offer: Dictionary = state.delivery_offer
	if not offer.is_empty():
		if not offer.get("id") is String or _dish(str(offer.get("dish_id", ""))).is_empty() or not _valid_integer(offer.get("expires")) or not _valid_number(offer.get("price")): return false
	for order in state.delivery_orders:
		if not _valid_job(order, employees, jobs) or _dish(str(order.get("dish_id", ""))).is_empty(): return false
		for key in ["gross", "net", "ingredient_cost"]:
			if not _valid_number(order.get(key)): return false
		if float(order.net) > float(order.gross): return false
	var central: Dictionary = state.central
	if not central.get("enabled") is bool or not _valid_stock(central.get("stock")) or not _valid_stock(central.get("stock_cost"), false): return false
	if not central.get("jobs") is Array or not central.get("shipments") is Array: return false
	for job in central.jobs:
		if not _valid_job(job, employees, jobs) or _dish(str(job.get("dish_id", ""))).is_empty() or not _valid_integer(job.get("quantity"), 1) or not _valid_number(job.get("ingredient_cost")): return false
	for shipment in central.shipments:
		if not shipment is Dictionary or not shipment.get("id") is String or not _valid_integer(shipment.get("due")) or not _valid_integer(shipment.get("quantity"), 1) or not _valid_number(shipment.get("ingredient_cost")): return false
		if _dish(str(shipment.get("dish_id", ""))).is_empty() or not state.branches.has(str(shipment.get("branch_id", ""))): return false
		if jobs.has(str(shipment.id)): return false
		jobs[str(shipment.id)] = {"employee_id": ""}
	for definition in _definitions("branches"):
		if not state.branches.get(str(definition.id)) is Dictionary: return false
		var branch: Dictionary = state.branches[str(definition.id)]
		if not branch.get("open") is bool or not _valid_stock(branch.get("stock")) or not _valid_stock(branch.get("stock_cost"), false): return false
		for key in ["next_order", "served", "missed"]:
			if not _valid_integer(branch.get(key)): return false
		for key in ["revenue", "rent_arrears"]:
			if not _valid_number(branch.get(key)): return false
	for exploration in state.explorations:
		if not _valid_job(exploration, employees, jobs) or not exploration.get("reward") is Dictionary: return false
		if not exploration.get("fragment_id") is String: return false
		if exploration.has("location") and not str(exploration.location) in ["old_restaurant","kunlun_path","three_realms_rift"]: return false
		var reward: Dictionary = exploration.reward
		if not reward.get("items") is Dictionary or not _valid_integer(reward.get("gems")) or not _valid_integer(reward.get("fragments")): return false
		for id in reward.items:
			if not id is String or not _valid_number(reward.items[id]): return false
	var competition: Dictionary = state.competition
	for key in ["active", "last_result"]:
		if not competition.get(key) is Dictionary: return false
	for key in ["attempts", "wins", "next_entry"]:
		if not _valid_integer(competition.get(key)): return false
	if not _valid_number(competition.get("best_score")) or float(competition.best_score) > 100 or not competition.get("first_reward_claimed") is bool: return false
	if not competition.active.is_empty():
		var job: Dictionary = competition.active
		if not _valid_job(job, employees, jobs) or _dish(str(job.get("dish_id", ""))).is_empty() or not _valid_number(job.get("ingredient_cost")) or not _valid_number(job.get("score")) or float(job.score) > 100: return false
	for employee in saved_employees:
		if not employee.get("branch_id", "") is String or not _valid_integer(employee.get("expansion_until", 0)) or not employee.get("expansion_job_id", "") is String: return false
		var branch_id := str(employee.get("branch_id", ""))
		if not branch_id.is_empty():
			if not state.branches.has(branch_id) or not bool(state.branches[branch_id].open) or not bool(employee.get("resting", false)): return false
		var job_id := str(employee.get("expansion_job_id", ""))
		if not job_id.is_empty() and (not jobs.has(job_id) or str(jobs[job_id].employee_id) != str(employee.id)): return false
		if int(employee.get("expansion_until", 0)) > 0 and job_id.is_empty(): return false
	return true
