extends RefCounted
## Local cooperating eateries share the campaign clock, cash ledger and save.
## Food only earns revenue after a prepared portion is handed over to an order.
const ACTIONS=["int_open","int_prepare","int_partner","int_serve","int_swap","int_decline","int_story","int_upgrade","int_layout","int_skill","int_arrears","int_auto","int_menu","int_visit","int_business","int_marketing","int_train","int_research","int_move_fixture","int_recruit"]
var _ref: WeakRef
var config: Dictionary={}
var _dirty=false
var floor
func _init(model):
	_ref=weakref(model)
	config=JSON.parse_string(FileAccess.get_file_as_string("res://config/international.json"))
	floor=preload("res://scripts/core/international_floor.gd").new(self)
func m():return _ref.get_ref()
func now() -> int:return int(m().state.total_minutes)
func s() -> Dictionary:return m().state.get("international",{})
func definition(kind: String,id: String) -> Dictionary:
	for entry in config.get(kind,[]):
		if str(entry.id)==id:return entry
	return {}
func ensure_state():
	if not m().state.get("international")is Dictionary:m().state.international={"version":1,"serial":0,"regions":{},"letters":[]}
	if not s().has("active_scene"):s().active_scene="main"
	for region in config.regions:
		if not s().regions.has(str(region.id)):
			s().regions[str(region.id)]={"open":false,"started":0,"served":0,"missed":0,"revenue":0.0,"costs":0.0,"arrears":0.0,"level":0,"layout":"balanced","stock":[],"jobs":[],"orders":[],"partners":region.characters.slice(0,1),"rest":{},"next_order":0,"verified_until":0,"rush":false,"story":{"choice":"","status":"available","baseline":0,"missed":0},"log":[]}
		var data=s().regions[str(region.id)]
		if not data.has("auto_service"):data.auto_service=true
		if not data.has("auto_recipe"):data.auto_recipe=""
		if not data.has("active_menu"):data.active_menu=region.dishes.slice(0,1)
		ensure_recruitment(str(region.id))
		floor.ensure(str(region.id))
func staff_limit() -> int:return mini(5,maxi(3,m().full_rules.active_limit()))
func recruit_quote(payment: String="cash") -> Dictionary:
	var gems=payment=="gems"
	return {"cost":float(m()._b("hire.ticket_cost_advanced"if gems else"hire.ticket_cost_normal")),"currency":"gems"if gems else"cash"}
func ensure_recruitment(rid: String):
	var data=region(rid);var def=definition("regions",rid)
	if not data.has("hired"):
		data.hired=data.partners.duplicate()
		var known=data.get("floor",{}).get("workers",{}).keys()+data.get("training",{}).keys()+data.rest.keys()
		for cid in known:
			if cid in def.characters and not cid in data.hired:data.hired.append(cid)
	if not data.has("starter_staffed"):data.starter_staffed=false
	if not data.has("recruit_log"):data.recruit_log=[]
	if bool(data.open)and not bool(data.starter_staffed):
		for role in["chef","host"]:
			if data.partners.any(func(cid):return floor.worker_role(str(cid))==role):continue
			var candidates=def.characters.filter(func(cid):return floor.worker_role(str(cid))==role)
			if candidates.is_empty():continue
			var cid=str(candidates[0])
			if not cid in data.hired:data.hired.append(cid)
			if data.partners.size()<staff_limit():data.partners.append(cid)
		data.starter_staffed=true
func region(id: String) -> Dictionary:return s().get("regions",{}).get(id,{})
func fail(zh: String,en: String="") -> Dictionary:return {"ok":false,"reason":zh,"reason_en":en}
func ok() -> Dictionary:return {"ok":true,"reason":"","reason_en":""}
func money(value) -> float:return snappedf(float(value),.01)
func label(value: Dictionary,english=false) -> String:return str(value.get("en"if english else"zh",""))
func partner(rid: String,skill: String) -> bool:
	var data=region(rid)
	for cid in data.get("partners",[]):
		if str(definition("characters",cid).get("skill",""))==skill and int(data.rest.get(cid,0))<=now():return true
	return false
func weather(rid: String,at: int=-1) -> String:
	var minute=now()if at<0 else at
	if rid!="nordic":return "clear"
	return ["clear","wind","rain"][posmod(int(minute/120),3)]
func ready(rid: String,dish_id: String) -> int:
	var count=0
	for lot in region(rid).get("stock",[]):
		if str(lot.dish_id)==dish_id:count+=int(lot.quantity)
	return count
func unlocked(rid: String,entry: Dictionary) -> bool:return entry.has("skill")or int(region(rid).get("served",0))>=int(entry.get("unlock_orders",0))
func order(rid: String,id: int) -> Dictionary:
	for entry in region(rid).get("orders",[]):
		if int(entry.id)==id:return entry
	return {}
func _pay(rid: String,amount: float,category: String,memo: String,expense=true):
	m().change_cash(-amount,category,memo)
	region(rid).costs=money(float(region(rid).costs)+amount)
	m().full_rules.record("expenses"if expense else"procurement",amount,memo)
	_log(rid,memo,-amount)
func _log(rid: String,text: String,amount=0.0,en=""):
	var entries=region(rid).log
	entries.append({"minute":now(),"text":text,"text_en":en if not en.is_empty()else"Local transaction recorded","amount":money(amount)})
	while entries.size()>80:entries.pop_front()
func _serial() -> int:s().serial=int(s().serial)+1;return int(s().serial)
func prep_quote(rid: String,dish: Dictionary,quantity: int) -> Dictionary:
	var cost=float(dish.cost)*quantity
	if partner(rid,"stock"):cost*=.94
	if partner(rid,"season")and"vegetable"in dish.tags:cost*=.9
	if partner(rid,"grain")and"grain"in dish.tags:cost*=.92
	var minutes=int(dish.minutes)+int(config.settings.supplier_delay)
	if rid=="nordic"and weather(rid)!="clear":minutes+=3 if partner(rid,"route")else 10
	if "fermented"in dish.tags and partner(rid,"ferment"):minutes=int(ceil(minutes*.8))
	if "spice"in dish.tags and partner(rid,"spice"):minutes=int(ceil(minutes*.85))
	if str(dish.station)=="oven"and(partner(rid,"oven")or partner(rid,"batch")):minutes=int(ceil(minutes*.85))
	if bool(region(rid).rush):minutes=int(ceil(minutes*.6))
	minutes=maxi(3,minutes-int(region(rid).get("mastery",{}).get(str(dish.id),0)))
	return {"cost":money(cost),"minutes":maxi(3,minutes)}
func can(action: String,args: Dictionary) -> Dictionary:
	if action=="int_visit"and str(args.get("region",""))=="main":return ok()
	var rid=str(args.get("region",""));var def=definition("regions",rid);var data=region(rid)
	if def.is_empty()or data.is_empty():return fail("找不到这处食肆。","Unknown eatery.")
	if not bool(m().state.get("tutorial",{}).get("finished",false)):return fail("先完成白泽的六步开店引导，再接受跨国合作邀请。","Finish the six opening steps before starting an international cooperation.")
	if action=="int_open":
		if data.open:return fail("这家食肆已开门。","Already open.")
		if float(m().state.cash)<float(def.opening_cost):return fail("现金不足以支付合作筹备费。","Not enough cash for the opening fee.")
		return ok()
	if not bool(data.open):return fail("先接受邀请并开设这家合作食肆。","Open this collaborating eatery first.")
	if action=="int_recruit":
		var cid=str(args.get("id",""));var payment=str(args.get("payment","cash"))
		if not cid in def.characters or not payment in["cash","gems"]:return fail("请选择本店候选员工和招聘方式。","Choose a local candidate and payment method.")
		if cid in data.hired:return fail("这位员工已录用，请到员工页安排当班。","Already hired; assign this employee from Staff.")
		var quote=recruit_quote(payment)
		return ok()if float(m().state[quote.currency])>=float(quote.cost)else fail("招聘资源不足。","Not enough recruitment resources.")
	if action=="int_visit":return ok()
	if action=="int_business":return ok()if args.get("enabled")is bool else fail("请选择是否接待新客。")
	if action=="int_marketing":return ok()if float(m().state.cash)>=20 and not data.jobs.any(func(j):return j.kind=="marketing")else fail("现金不足，或宣传已在进行。","Not enough cash, or promotion is already under way.")
	if action in["int_train","int_research"]:
		var id=str(args.get("id",""));var training=action=="int_train";var entry=definition("characters"if training else"dishes",id)
		if entry.get("region","")!=rid or not unlocked(rid,entry):return fail("先完成相应当地订单，认识这位伙伴或学会这道菜。","Complete the local order requirement first.")
		if training and not id in data.partners:return fail("先安排这位伙伴当班。","Assign this partner first.")
		if int((data.training if training else data.mastery).get(id,0))>=3:return fail("本项已完成三次进修。","All three improvements are complete.")
		if data.jobs.any(func(j):return j.kind==("training"if training else"research")and str(j.get("character",j.get("dish_id","")))==id):return fail("这项进修已经安排。","This improvement is already scheduled.")
		if training and(int(data.floor.workers[id].job)>0 or int(data.rest.get(id,0))>now()):return fail("等伙伴完成当前工作和休息，再安排培训。","Wait for the current work and rest to finish.")
		return ok()if float(m().state.cash)>=(30 if training else 25)else fail("现金不足。","Not enough cash.")
	if action=="int_move_fixture":
		if not floor.can_remodel(rid):return fail("先停接新客，等客人离店、清台和当前工作完成。","Stop new arrivals and finish service and cleaning first.")
		return ok()if floor.can_move(rid,str(args.get("uid","")),args.get("x"),args.get("y"))else fail("该位置会挡住座位、设备或进出路线。","That position blocks a seat, station or route.")
	if action in["int_auto","int_menu"]:
		if str(args.get("id",""))=="service":return ok()
		var dish=definition("dishes",str(args.get("id","")))
		if dish.get("region","")!=rid or not unlocked(rid,dish):return fail("请选择本店已学会的配方。","Choose a learned local recipe.")
		if action=="int_menu"and str(dish.id)in data.active_menu and data.active_menu.size()<=1:return fail("至少保留一道在售餐点。","Keep at least one dish on the menu.")
		return ok()
	if action=="int_partner":
		var char=definition("characters",str(args.get("id","")))
		if char.get("region","")!=rid:return fail("这位伙伴不属于本店。")
		if str(char.id)in data.partners and int(data.floor.workers[str(char.id)].job)>0:return fail("等这位伙伴完成当前任务再结束当班。","Finish the current task before releasing this partner.")
		if not str(char.id)in data.hired:return fail("先到招聘页录用这位员工。","Hire this employee from Recruitment first.")
		if not str(char.id)in data.partners and data.partners.size()>=staff_limit():return fail("当班岗位已满，请先安排一位员工候补。","All active slots are filled; move an employee to standby first.")
		return ok()
	if action=="int_arrears":return ok()if float(data.arrears)>0 and float(m().state.cash)>=float(data.arrears)else fail("没有待付费用，或现金不足。","No arrears, or insufficient cash.")
	if action=="int_prepare":
		var dish=definition("dishes",str(args.get("id","")));var q=int(args.get("quantity",3))
		if dish.get("region","")!=rid or not unlocked(rid,dish):return fail("这道菜需完成相应当地订单后学习。","Complete the required local orders to learn this dish.")
		if q<1 or q>(4 if partner(rid,"batch")else 3):return fail("本批数量超出当前上限。","Batch size exceeds the current limit.")
		if float(data.arrears)>0:return fail("先结清本店待付费用，再新增采购。","Settle the eatery’s arrears before new purchases.")
		if data.jobs.filter(func(j):return j.kind=="prep").size()>=(2+(1 if partner(rid,"night")else 0)+(1 if data.story.choice=="extra"else 0)):return fail("备料位已满，请等一批完成。","All preparation slots are occupied.")
		if data.jobs.any(func(j):return(j.kind=="prep"and str(definition("dishes",j.dish_id).station)==str(dish.station))or(j.kind=="upgrade"and str(dish.station)=="oven")):return fail("所需设备正在使用或维护中。","The required station is busy or under maintenance.")
		if float(m().state.cash)<float(prep_quote(rid,dish,q).cost):return fail("现金不足以采购本批用料。","Not enough cash for this batch.")
		return ok()
	if action in ["int_serve","int_swap","int_decline"]:
		var requested=order(rid,int(args.get("order",-1)))
		if requested.is_empty()or requested.status!="waiting":return fail("订单已交付、取消或正在出餐。","The order is no longer waiting.")
		if action=="int_decline":return ok()
		if not floor.ready_to_serve(rid,int(requested.id)):return fail("请等客人落座并完成点单。","Wait until the guest is seated and has ordered.")
		var dish=definition("dishes",str(args.get("id",requested.dish_id))if action=="int_swap"else str(requested.dish_id))
		if dish.get("region","")!=rid or not unlocked(rid,dish):return fail("请选择本店已学会的餐点。","Choose a learned local dish.")
		if requested.request=="no_milk"and"milk"in dish.contains:return fail("这份配方含乳，不能兑现本单的无乳要求。","This recipe contains milk and cannot fulfil this request.")
		if requested.request=="mild"and not"mild"in dish.suits:return fail("本配方没有确认可用的低辣版本，请换单或婉拒。","No confirmed mild version; offer another dish or decline.")
		if action=="int_swap":return ok()
		if ready(rid,str(dish.id))<int(requested.quantity):return fail("已完成的餐点不足，请先采购备料。","Not enough prepared portions; prepare a batch first.")
		if data.jobs.any(func(j):return j.kind=="service"):return fail("交接台正在出餐，请稍候。","The handover station is busy.")
		return ok()
	if action=="int_story":
		if data.story.choice!="":return fail("本次接待方案已经确定。","This reception plan has been chosen.")
		var choices={"india":["limited","extra","alternative"],"nordic":["stocks","rush","reserve"],"greece":["shared","separate","mixed"]}
		var choice=str(args.get("choice",""))
		if not choice in choices[rid]:return fail("无效的接待方案。")
		if choice in["extra","rush"]and float(m().state.cash)<35:return fail("本方案需要额外35元。","This plan requires an extra35.")
		return ok()
	if action in ["int_upgrade","int_layout"]:
		if data.jobs.any(func(j):return j.kind in["upgrade","layout"]):return fail("本店已有改装进行中。","An improvement is already in progress.")
		if action=="int_layout"and not floor.can_remodel(rid):return fail("先停接新客，等当前接待、清台和备料结束。","Stop new arrivals and finish current work first.")
		if action=="int_layout"and not str(args.get("layout",""))in["balanced","service","storage","sharing"]:return fail("未知桌席方案。")
		if action=="int_upgrade"and int(data.level)>=2:return fail("设备已完成两次改进。","Equipment improvements are complete.")
		var cost=45 if action=="int_layout"else 80+int(data.level)*40
		if float(m().state.cash)<cost:return fail("现金不足以安排本次改装。","Not enough cash for this improvement.")
		if action=="int_upgrade"and data.jobs.any(func(j):return j.kind=="prep"and definition("dishes",j.dish_id).station=="oven"):return fail("先让当前炉次完成，再停炉维护。","Finish the current oven batch before maintenance.")
		return ok()
	if action=="int_skill":
		var skill=str(args.get("skill",""))
		if not skill in["rush","verify"]or not partner(rid,skill):return fail("先安排对应伙伴当班，并等其休息结束。","Assign the relevant available partner first.")
		if skill=="rush"and bool(data.rush):return fail("下一批加急安排已经就绪。","The next rush batch is already arranged.")
		if skill=="verify"and data.jobs.any(func(j):return j.kind=="verify"):return fail("消息正在核实中。","A verification is already under way.")
		if float(m().state.cash)<(35 if skill=="rush"else 8):return fail("现金不足以安排本次合作。","Not enough cash for this cooperation.")
		return ok()
	return fail("未知跨国经营操作。","Unknown international action.")
func perform(action: String,args: Dictionary,notify=true) -> Dictionary:
	ensure_state();var check=can(action,args)
	if not check.ok:return check
	var rid=str(args.region)
	if action=="int_visit":
		s().active_scene=rid;m().changed.emit();m().autosave_requested.emit();return ok()
	var data=region(rid);var def=definition("regions",rid)
	match action:
		"int_recruit":
			var cid=str(args.id);var quote=recruit_quote(str(args.get("payment","cash")))
			if quote.currency=="cash":_pay(rid,float(quote.cost),"recruitment",label(definition("characters",cid).name)+"当地招聘")
			else:m().state.gems=int(m().state.gems)-int(quote.cost);_log(rid,"灵石招聘："+label(definition("characters",cid).name),0,"Hired with spirit gems")
			data.hired.append(cid)
			var active=data.partners.size()<staff_limit()
			if active:data.partners.append(cid)
			data.recruit_log.append({"id":cid,"payment":quote.currency,"cost":float(quote.cost),"minute":now(),"active":active})
			while data.recruit_log.size()>20:data.recruit_log.pop_front()
		"int_business":data.accepting=bool(args.enabled)
		"int_marketing":
			_pay(rid,20,"international_promotion","当地食街宣传")
			floor.queue(rid,{"id":_serial(),"kind":"marketing","cost":0.0,"started":now(),"due":now()+8},"host","door",8)
		"int_train":
			_pay(rid,30,"international_training","当地伙伴岗位培训")
			floor.queue(rid,{"id":_serial(),"kind":"training","character":str(args.id),"cost":0.0,"started":now(),"due":now()+30},floor.worker_role(str(args.id)),"training",30)
		"int_research":
			_pay(rid,25,"international_research","当地配方改良")
			floor.queue(rid,{"id":_serial(),"kind":"research","dish_id":str(args.id),"cost":0.0,"started":now(),"due":now()+20},"chef",floor.station_for(definition("dishes",str(args.id))),20)
		"int_move_fixture":
			var fixture=floor.by_uid(rid,str(args.uid));fixture.x=float(args.x);fixture.y=float(args.y)
		"int_menu":
			if str(args.id)in data.active_menu:data.active_menu.erase(str(args.id))
			else:data.active_menu.append(str(args.id))
		"int_auto":
			if str(args.id)=="service":data.auto_service=not bool(data.auto_service)
			else:data.auto_recipe=""if str(data.auto_recipe)==str(args.id)else str(args.id)
		"int_open":
			_pay(rid,float(def.opening_cost),"international_setup",label(def.shop)+"合作筹备费")
			data.open=true;data.started=now();data.next_order=now()+6
		"int_prepare":
			var dish=definition("dishes",str(args.id));var q=int(args.get("quantity",3));var quote=prep_quote(rid,dish,q)
			_pay(rid,float(quote.cost),"procurement",label(dish.name)+"采购用料×"+str(q),false)
			if not str(dish.id)in data.active_menu:data.active_menu.append(str(dish.id))
			floor.prepare(rid,{"id":_serial(),"kind":"prep","dish_id":str(dish.id),"quantity":q,"cost":float(quote.cost),"started":now(),"due":now()+int(quote.minutes)},int(quote.minutes))
			if data.rush:
				data.rush=false
				for cid in data.partners:
					if definition("characters",cid).skill=="rush":data.rest[cid]=now()+int(quote.minutes)+20
		"int_partner":
			var cid=str(args.id)
			if cid in data.partners:data.partners.erase(cid)
			else:data.partners.append(cid)
		"int_serve":
			var requested=order(rid,int(args.order));var dish=definition("dishes",requested.dish_id);var count=int(requested.quantity);var cost=0.0
			for lot in data.stock:
				if lot.dish_id!=dish.id or count<=0:continue
				var take=mini(count,int(lot.quantity));var used=float(lot.value)*take/maxi(1,int(lot.quantity));lot.value=money(float(lot.value)-used);lot.quantity=int(lot.quantity)-take;count-=take;cost+=used
			data.stock=data.stock.filter(func(lot):return int(lot.quantity)>0)
			requested.status="serving"
			var duration=3 if partner(rid,"host")or partner(rid,"water")else 5
			if str(data.layout)=="service":duration=maxi(2,duration-1)
			if int(requested.quantity)>1:duration+=2
			floor.guest(rid,int(requested.id)).stage="serving"
			floor.service(rid,{"id":_serial(),"kind":"service","order_id":int(requested.id),"dish_id":str(dish.id),"quantity":int(requested.quantity),"cost":money(cost),"started":now(),"due":now()+duration},duration)
		"int_swap":order(rid,int(args.order)).dish_id=str(args.id)
		"int_decline":
			floor.cancel_order(rid,int(args.order));data.orders.erase(order(rid,int(args.order)));data.missed=int(data.missed)+1;_log(rid,"已说明原因，婉拒一笔未收款订单")
		"int_story":
			var choice=str(args.choice);data.story.choice=choice;data.story.status="waiting";data.story.baseline=int(data.served);data.story.missed=int(data.missed)
			if choice in["extra","rush"]:_pay(rid,35,"international_service","接待方案的额外人手或运输")
			if choice=="rush":data.rush=true
		"int_layout","int_upgrade":
			var layout=action=="int_layout";var cost=45 if layout else 80+int(data.level)*40
			_pay(rid,cost,"international_improvement","桌席调整"if layout else"炉具与工作台维护")
			floor.queue(rid,{"id":_serial(),"kind":"layout"if layout else"upgrade","layout":str(args.get("layout","balanced")),"cost":0.0,"started":now(),"due":now()+(12 if layout else 30)},"builder","renovation"if layout else"hot",12 if layout else 30)
		"int_skill":
			if args.skill=="rush":_pay(rid,35,"international_freight","迦楼罗加急采购预约");data.rush=true
			else:
				_pay(rid,8,"international_verification","核实天气与供货消息")
				floor.queue(rid,{"id":_serial(),"kind":"verify","cost":0.0,"started":now(),"due":now()+8},"host","verify",8)
		"int_arrears":
			var paid=float(data.arrears);m().change_cash(-paid,"international_arrears","跨国食肆已记费用的结清");data.arrears=0.0;_log(rid,"已结清待付费用",-paid)
	ensure_recruitment(rid)
	floor.ensure(rid)
	if notify:m().changed.emit();m().autosave_requested.emit()
	else:_dirty=true
	return ok()
func _new_order(rid: String):
	var data=region(rid);var ids=definition("regions",rid).dishes;var available=ids.filter(func(id):return unlocked(rid,definition("dishes",id))and id in data.active_menu)
	if available.is_empty():return
	if data.story.choice=="stocks":
		var stocked=available.filter(func(id):return ready(rid,id)>0)
		if not stocked.is_empty():available=stocked
	if data.story.choice=="alternative":
		var suitable=available.filter(func(id):return "vegan"in definition("dishes",id).suits)
		if not suitable.is_empty():available=suitable
	var serial=_serial();var dish_id=str(available[posmod(serial,available.size())]);var request="standard"
	if serial%4==0 and available.any(func(id):return not"milk"in definition("dishes",id).contains):request="no_milk"
	elif serial%4==2 and available.any(func(id):return "mild"in definition("dishes",id).suits):request="mild"
	var quantity=2 if rid=="greece"and(data.story.choice=="shared"or(data.story.choice=="mixed"and serial%2==0))else 1
	var window=int(config.settings.order_window)+(15 if partner(rid,"promise")else 0)+(20 if data.story.choice in["reserve","limited"]else 0)
	var incoming={"id":serial,"dish_id":dish_id,"quantity":quantity,"request":request,"status":"arriving","created":now(),"due":now()+window}
	if floor.spawn(rid,incoming):data.orders.append(incoming)
func _finish_job(rid: String,job: Dictionary):
	var data=region(rid)
	if floor.finish(rid,job):return
	match job.kind:
		"prep":
			var dish=definition("dishes",job.dish_id);var life=int(dish.shelf_minutes)+(40 if str(data.layout)=="storage"else 0)
			data.stock.append({"dish_id":str(job.dish_id),"quantity":int(job.quantity),"value":float(job.cost),"expires":now()+life})
			if partner(rid,"night"):
				for cid in data.partners:
					if definition("characters",cid).skill=="night":data.rest[cid]=now()+20
		"upgrade":data.level=int(data.level)+1
		"layout":
			data.layout=str(job.layout)
			if data.floor.guests.is_empty():floor.apply_layout(rid)
			else:data.floor.pending_layout=str(job.layout)
		"verify":data.verified_until=now()+120
func recognize_payment(rid: String,requested: Dictionary,cost: float):
	var data=region(rid);var dish=definition("dishes",str(requested.dish_id))
	var price=money(float(dish.price)*int(requested.quantity)*(1.0+int(data.level)*.03))
	m().full_rules.expansion._income(price)
	m().full_rules.management.recognize_cost(cost);m().full_rules.record("cost_of_sales",cost,label(definition("regions",rid).shop)+"餐点结账耗用")
	_pay(rid,money(.5*int(requested.quantity)),"international_service","当地餐点装盘与交接")
	data.revenue=money(float(data.revenue)+price);data.served=int(data.served)+1;m().state.reputation=int(m().state.reputation)+1
	data.orders.erase(requested);_log(rid,"已结账："+label(dish.name)+"×"+str(requested.quantity),price,"Paid: "+label(dish.name,true)+" ×"+str(requested.quantity))
func tick():
	ensure_state()
	for rid in s().regions:
		var data=region(rid)
		if not bool(data.open):continue
		if floor.tick(rid):_dirty=true
		if data.floor.has("pending_layout")and floor.can_remodel(rid):floor.apply_layout(rid);data.floor.erase("pending_layout")
		for index in range(data.jobs.size()-1,-1,-1):
			var job=data.jobs[index]
			if not str(job.get("phase","working"))in["working","delivery"]or int(job.due)>now():continue
			_finish_job(rid,job);data.jobs.remove_at(index)
			_dirty=true
		for index in range(data.stock.size()-1,-1,-1):
			var lot=data.stock[index]
			if int(lot.expires)>now():continue
			m().full_rules.record("expenses",float(lot.value),"跨国食肆临期餐点报损");_log(rid,"临期餐点已报损");data.stock.remove_at(index)
		for index in range(data.orders.size()-1,-1,-1):
			if data.orders[index].status=="waiting"and int(data.orders[index].due)<=now():floor.cancel_order(rid,int(data.orders[index].id));data.orders.remove_at(index);data.missed=int(data.missed)+1
		if now()>=int(data.next_order)and m().business_hours_open()and bool(data.accepting)and not data.jobs.any(func(j):return j.kind=="layout"):
			data.next_order=now()+int(float(config.settings.order_interval)*(.65 if now()<int(data.marketing_until)else 1.0))+(6 if data.story.choice in["limited","reserve"]else 0)
			var capacity=2+int(data.level)+(1 if data.layout=="sharing"else 0)+(1 if partner(rid,"layout")and data.layout=="sharing"else 0)
			if data.story.choice=="limited":capacity=1
			if data.orders.size()<capacity:_new_order(rid)
		if bool(data.auto_service):
			for requested in data.orders:
				var args={"region":rid,"order":int(requested.id)}
				if requested.status=="waiting"and can("int_serve",args).ok:perform("int_serve",args,false);break
		if not str(data.auto_recipe).is_empty()and float(m().state.cash)>200 and(bool(data.accepting)or not data.orders.is_empty()):
			var did=str(data.auto_recipe);var dish=definition("dishes",did);var quote=prep_quote(rid,dish,3)
			var args={"region":rid,"id":did,"quantity":3}
			if ready(rid,did)<=1 and float(m().state.cash)-float(quote.cost)>=200 and can("int_prepare",args).ok:perform("int_prepare",args,false)
		if data.story.status=="waiting"and int(data.served)-int(data.story.baseline)>=3:
			data.story.status="resolved"
			var missed=int(data.missed)-int(data.story.missed)
			var letter={"id":rid+":"+str(data.story.choice),"region":rid,"minute":now(),"choice":str(data.story.choice),"fulfilled":int(data.served)-int(data.story.baseline),"missed":missed}
			s().letters.append(letter)
			var def=definition("regions",rid)
			m().full_rules.culture_experience._add_letter("international:"+str(letter.id),{"zh":label(def.shop)+"的回信","en":"A letter from "+label(def.shop,true)},letter_body(letter),"international")
			_log(rid,"收到本次接待方案的回信")
	if _dirty and now()%60==0:_dirty=false;m().autosave_requested.emit()
func letter_body(letter: Dictionary) -> Dictionary:
	var zh={"limited":"预约板上留下了你愿意接下的数量。少接的订单没有变成含糊的承诺，蒸位与煎板终于有了自己的节奏。","extra":"多安排的准备班次记在账上，也让厨房有时间完成下一批。我们记住了人手与费用应当一起商量。","alternative":"你把已经确认的用料写清楚，也给做不到的要求留了另一道菜的选择。对话终于落到真正端上的餐点。","stocks":"短菜单没有掩饰缺货。储备柜里的余量、汤锅的热气和门口的说明，一起撑过了等船的这段时间。","rush":"那一笔加急运输写在采购记录里。我们也看见，快送到的原料仍需要备料和交接，不能直接变成已经履行的订单。","reserve":"新的时段写进预约单，客人能选择等候或另作安排。船期的不确定，没有再藏进一个含糊的很快里。","shared":"长桌上的共享份有对应的数量和交接记录。热闹没有代替对每一位客人的说明。","separate":"每一只独立餐盘都有自己的用料和份量。多出来的装盘工时，让我们把相聚与个人需要同时安排进晚餐。","mixed":"共享和独立份量分别记在单上。院子没有要求每个人用同一种方式吃饭，厨房也学会为不同份量安排炉次。"}
	var en={"limited":"The booking board held the number you could accept. The griddle and steamer found their own rhythm without promises beyond capacity.","extra":"The extra preparation shift appears in the accounts and gives the kitchen time for the next batch. Staffing and its cost were discussed together.","alternative":"Declared ingredients and a genuine alternative turned the conversation into a meal that could actually be served.","stocks":"The shorter menu did not hide the missing supplies. Stored portions, warm soup and a clear notice kept the eatery going while waiting for the ship.","rush":"The rush freight charge remains in the purchase record. Even early ingredients still need preparation and handover before an order is fulfilled.","reserve":"The new time went on the booking sheet. Guests could wait or make other plans; uncertainty was no longer hidden behind soon.","shared":"Shared portions had matching quantities and handover records. A lively table did not replace explaining the meal to each guest.","separate":"Each individual plate had declared ingredients and its own portion. The added plating work made room for both company and personal needs.","mixed":"Shared and individual quantities were recorded separately. The courtyard did not ask everyone to dine in the same way."}
	var choice=str(letter.choice)
	return {"zh":str(zh.get(choice,"这次相遇留下了实际的服务记录。"))+"\n本次方案后已交付%d笔订单，取消或超时%d笔。"%[letter.fulfilled,letter.missed]+("仍有未完成的接待，下一次要提前说清等待与替换。"if int(letter.missed)>0 else"已完成的约定，让下一次相约有了依据。"),"en":str(en.get(choice,"This meeting left an actual service record."))+"\nAfter this plan: %d orders fulfilled; %d declined or late. "%[letter.fulfilled,letter.missed]+("There were missed orders; next time, explain waiting and alternatives sooner."if int(letter.missed)>0 else"The fulfilled agreements give the next meeting a starting point.")}
func on_day():
	ensure_state()
	for rid in s().regions:
		var data=region(rid)
		if not bool(data.open):continue
		var due=float(definition("regions",rid).daily_cost)+(10 if data.story.choice=="extra"else 0)
		var paid=minf(maxf(0,float(m().state.cash)),due);m().change_cash(-paid,"international_daily",label(definition("regions",rid).shop)+"日常协作与场地费用")
		m().full_rules.record("expenses",due,"跨国食肆当日费用");data.arrears=money(float(data.arrears)+due-paid);data.costs=money(float(data.costs)+due)
func inventory_value() -> float:
	var total=0.0
	for data in s().get("regions",{}).values():
		for lot in data.stock:total+=float(lot.value)
		for job in data.jobs:
			if job.kind in["prep","service"]:total+=float(job.cost)
		for order in data.orders:total+=float(order.get("meal_cost",0))
	return money(total)
func arrears_total() -> float:
	var total=0.0
	for data in s().get("regions",{}).values():total+=float(data.arrears)
	return money(total)
func snapshot() -> Dictionary:
	var result=s().duplicate(true)
	for rid in result.get("regions",{}):
		result.regions[rid].weather=weather(rid)
		result.regions[rid].next_weather=weather(rid,now()+120)if int(result.regions[rid].verified_until)>now()else"unverified"
	return result
func validate(saved: Dictionary) -> bool:
	if not saved.has("international"):return true
	var value=saved.international
	if not value is Dictionary or value.get("version")!=1 or not m()._integer(value.get("serial"),0):return false
	if not value.get("regions")is Dictionary or not value.get("letters")is Array:return false
	if value.has("active_scene"):
		if not value.active_scene is String or not str(value.active_scene)in["main","india","nordic","greece"]:return false
		if str(value.active_scene)!="main"and not bool(value.regions.get(str(value.active_scene),{}).get("open",false)):return false
	for def in config.regions:
		var data=value.regions.get(str(def.id))
		if not data is Dictionary or not data.get("open")is bool:return false
		if data.has("auto_service")and not data.auto_service is bool:return false
		if data.has("auto_recipe")and(not data.auto_recipe is String or(not str(data.auto_recipe).is_empty()and not str(data.auto_recipe)in def.dishes)):return false
		if data.has("active_menu"):
			if not data.active_menu is Array or data.active_menu.is_empty():return false
			var menu_seen={}
			for did in data.active_menu:
				if not str(did)in def.dishes or menu_seen.has(str(did)):return false
				menu_seen[str(did)]=true
		for field in["started","served","missed","revenue","costs","arrears","level","next_order","verified_until"]:
			if not m()._number(data.get(field))or float(data[field])<0:return false
		for field in["started","served","missed","level","next_order","verified_until"]:
			if not m()._integer(data[field],0):return false
		if int(data.level)>2 or not data.get("rush")is bool or not data.get("layout")in["balanced","service","storage","sharing"]:return false
		for field in["stock","jobs","orders","partners","log"]:
			if not data.get(field)is Array:return false
		if not data.get("rest")is Dictionary or not data.get("story")is Dictionary or data.partners.size()>5 or data.jobs.size()>32 or data.orders.size()>8:return false
		if data.has("hired"):
			if not data.hired is Array or data.hired.size()>5 or not data.get("starter_staffed")is bool or not data.get("recruit_log")is Array or data.recruit_log.size()>20:return false
			var hired_seen={}
			for cid in data.hired:
				if not cid in def.characters or hired_seen.has(cid):return false
				hired_seen[cid]=true
			for cid in data.partners:
				if not cid in data.hired:return false
			for record in data.recruit_log:
				if not record is Dictionary or not str(record.get("id",""))in data.hired or not record.get("payment")in["cash","gems"]or not m()._number(record.get("cost"))or float(record.cost)<0 or not m()._integer(record.get("minute"),0)or not record.get("active")is bool:return false
		var seen={}
		for cid in data.partners:
			if not cid in def.characters or seen.has(cid):return false
			seen[cid]=true
		for cid in data.rest:
			if not cid in def.characters or not m()._number(data.rest[cid])or float(data.rest[cid])<0:return false
		for lot in data.stock:
			if not lot is Dictionary or not str(lot.get("dish_id",""))in def.dishes:return false
			for field in["quantity","value","expires"]:
				if not m()._number(lot.get(field))or float(lot[field])<0:return false
			if not m()._integer(lot.quantity,1)or not m()._integer(lot.expires,0):return false
		seen={}
		for entry in data.orders:
			if not entry is Dictionary or not str(entry.get("dish_id",""))in def.dishes or not str(entry.get("status",""))in["arriving","ordering","waiting","serving","eating","paying"]or not str(entry.get("request",""))in["standard","no_milk","mild"]:return false
			for field in["id","quantity","created","due"]:
				if not m()._integer(entry.get(field),0):return false
			if int(entry.quantity)<1 or int(entry.quantity)>2 or seen.has(int(entry.id)):return false
			seen[int(entry.id)]=true
		var service_seen={}
		for job in data.jobs:
			if not job is Dictionary or not str(job.get("kind",""))in["prep","service","upgrade","layout","verify","order","checkout","clean","training","research","marketing"]:return false
			for field in["id","cost","started","due"]:
				if not m()._number(job.get(field))or float(job[field])<0:return false
			for field in["id","started","due"]:
				if not m()._integer(job[field],0):return false
			if job.kind in["prep","service"]:
				if not str(job.get("dish_id",""))in def.dishes or not m()._integer(job.get("quantity"),1)or int(job.quantity)>4:return false
			if job.kind=="service":
				if not seen.has(int(job.get("order_id",-1)))or service_seen.has(int(job.order_id)):return false
				service_seen[int(job.order_id)]=true
			if job.kind=="layout"and not str(job.get("layout",""))in["balanced","service","storage","sharing"]:return false
		for entry in data.orders:
			if(entry.status=="serving")!=service_seen.has(int(entry.id)):return false
		if not str(data.story.get("status",""))in["available","waiting","resolved"]or not data.story.get("choice")is String:return false
		if data.has("floor")and not floor.validate(str(def.id),data):return false
		var valid_choices={"india":["","limited","extra","alternative"],"nordic":["","stocks","rush","reserve"],"greece":["","shared","separate","mixed"]}
		if not str(data.story.choice)in valid_choices[str(def.id)]:return false
		for field in["baseline","missed"]:
			if not m()._integer(data.story.get(field),0):return false
	for letter in value.letters:
		if not letter is Dictionary or not letter.get("id")is String or definition("regions",str(letter.get("region",""))).is_empty():return false
		for field in["minute","fulfilled","missed"]:
			if not m()._integer(letter.get(field),0):return false
		if not letter.get("choice")is String:return false
	return true
