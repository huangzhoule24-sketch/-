#!/usr/bin/env python3
"""Standalone C-major flute revision. Never writes game assets or config."""
import hashlib,json,math,shutil,subprocess,wave,urllib.request
from fractions import Fraction
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly,fftconvolve,butter,sosfilt
import compose_business_music as helpers
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'build/music-major-flute'
SR=48000;BPM=88;BEAT=60/BPM

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    chords={
      'C':('C2',['C3','G3','C4','E4']), 'Am':('A1',['A3','C4','E4']),
      'F':('F2',['F3','A3','C4']), 'G':('G1',['G3','B3','D4']),
      'Dm':('D2',['D3','A3','D4','F4']), 'Em':('E2',['E3','G3','B3']),
      'G7':('G1',['G3','B3','D4','F4'])}
    progression=['C','Am','F','G','C','F','Dm','G7',
                 'C','Am','F','G','Em','Am','Dm','G7',
                 'F','C','Dm','G','Em','Am','F','G7',
                 'C','Am','F','G','C','F','G7','C']
    bars=[
      [('E5',1),('G5',1),('C6',2)], [('B5',1),('A5',1),('E5',2)],
      [('A5',1),('G5',1),('F5',1),('E5',1)], [('D5',2),('B4',1),('D5',1)],
      [('E5',2),('G5',1),('E5',1)], [('F5',1),('A5',1),('G5',1),('F5',1)],
      [('F5',1),('E5',1),('D5',2)], [('B4',2),(None,1),('D5',1)],
      [('E5',1),('G5',1),('B5',1),('C6',1)], [('B5',1),('A5',2),('E5',1)],
      [('F5',2),('A5',1),('G5',1)], [('B5',1),('A5',1),('G5',2)],
      [('G5',1),('B5',1),('G5',2)], [('E5',2),('C5',1),('E5',1)],
      [('F5',1),('E5',1),('D5',2)], [('D5',1),('F5',1),('B4',2)],
      [('C5',2),('F5',2)], [('E5',1),('D5',1),('C5',2)],
      [('D5',1),('F5',1),('A5',2)], [('G5',2),('D5',1),('B4',1)],
      [('B4',1),('E5',1),('G5',2)], [('A5',1),('G5',1),('E5',2)],
      [('F5',2),('E5',1),('F5',1)], [('D5',1),('B4',1),('G4',2)],
      [('E5',1),('G5',1),('C6',2)], [('B5',1),('A5',1),('E5',2)],
      [('A5',1),('G5',1),('F5',1),('E5',1)], [('D5',1),('G5',1),('B5',2)],
      [('C6',2),('G5',1),('E5',1)], [('A5',1),('G5',1),('F5',2)],
      [('D5',1),('F5',1),('B4',2)], [('C5',4)]]
    events=[]
    def event(part,beat,length,note,velocity):
        events.append({'part':part,'beat':beat,'duration':length,'note':helpers.pitch(note) if isinstance(note,str) else note,'velocity':velocity})
    for bar,melody in enumerate(bars):
        t=0
        for note,length in melody:
            if note:event('flute_melody',bar*4+t,length*.91,note,.82 if t in [0,2] else .69)
            t+=length
        assert t==4
        bass,tones=chords[progression[bar]]
        # A quiet root on beats 1/3, piano chords on 2/4; no repeated offbeat ostinato.
        for b in [0,2]:event('bass_guitar',bar*4+b,1.65,bass,.80 if b==0 else .64)
        for b in ([0] if bar==31 else [0,2]):
            for note in tones:event('warm_strings',bar*4+b,3.8 if bar==31 else 1.9,note,.48 if b==3 else .55)
        if bar<31:
            for b,n in [(0,36),(1,37),(2,36),(3,37)]:event('drums',bar*4+b,.2,n,.42 if n==36 else .28)
        if bar in [3,7,11,15,19,23,27,30]:event('triangle',bar*4+3,.6,81,.52)
    score={'title':'有间晨炊·晴日长笛版','bpm':BPM,'meter':[4,4],'key':'C major (C D E F G A B)','bars':32,'progression':progression,'chords':chords,'melody':bars,'instruments':['synthesised concert flute','quiet sustained strings','reduced synthesised bass guitar','soft kick and sidestick','synthesised triangle'],'installed_in_game':False}
    (OUT/'score.json').write_text(json.dumps(score,ensure_ascii=False,indent=2)+'\n')
    (OUT/'arrangement.json').write_text(json.dumps(events,indent=2)+'\n')
    count=round((32*4*BEAT+4)*SR)
    tracks={p:np.zeros((count,2),np.float32)for p in ['flute_melody','warm_strings','bass_guitar','drums','triangle']}
    cache={};rng=np.random.default_rng(20261028)
    for e in events:
        p,n=e['part'],e['note'];seconds=e['duration']*BEAT
        if p=='flute_melody':
            mono=helpers.timbre('bamboo_lead',n,seconds,SR,rng)*.18
            signal=np.stack([mono,mono*.97],axis=1)
        elif p=='warm_strings':
            mono=helpers.timbre('warm_pad',n,seconds,SR,rng)*.037
            signal=np.stack([mono*.95,mono],axis=1)
        elif p=='bass_guitar':
            t=np.arange(round((seconds+.18)*SR))/SR;f=helpers.frequency(n)
            mono=sum(np.sin(2*np.pi*f*k*t+.10*k)*np.exp(-t/(.55/(k**.4)))/k**1.7 for k in range(1,8))
            mono*=helpers.fade_envelope(len(t),SR,.006,.12)*.063
            signal=np.stack([mono,mono],axis=1)
        elif p=='triangle':
            t=np.arange(round(1.6*SR))/SR
            mono=sum(a*np.sin(2*np.pi*f*t)*np.exp(-t/d)for f,a,d in [(3800,1,.42),(6213,.66,.32),(8791,.35,.2),(11341,.16,.14)])
            mono*=helpers.fade_envelope(len(t),SR,.001,.08)*.018
            signal=np.stack([mono*.72,mono],axis=1)
        else:
            mono=helpers.timbre('light_percussion',n,seconds,SR,rng)*.10
            signal=np.stack([mono,mono],axis=1)
        start=round(e['beat']*BEAT*SR);length=min(len(signal),count-start)
        tracks[p][start:start+length]+=signal[:length]*e['velocity']
    dry=sum(tracks.values())
    ir=np.zeros((round(1.0*SR),2),np.float32)
    for i,delay in enumerate([.027,.043,.069,.103,.149,.211,.293,.397,.521,.683,.859]):
        ir[round(delay*SR),i%2]=.13*math.exp(-delay/.25)
    wet=np.stack([fftconvolve(dry[:,c],ir[:,c])[:count]for c in [0,1]],axis=1).astype(np.float32)
    mix=dry+wet
    mix=sosfilt(butter(2,30,'highpass',fs=SR,output='sos'),mix,axis=0).astype(np.float32)
    fade=round(.9*SR);mix[-fade:]*=np.linspace(1,0,fade)[:,None]
    raw=OUT/'unmastered.wav';helpers.write_wav(raw,mix,SR)
    stats=helpers.loudness(raw)
    gain=min(10**((-18-float(stats['input_i']))/20),10**((-2-float(stats['input_tp']))/20))
    mix*=gain
    wav=OUT/'youjian-major-flute.wav';helpers.write_wav(wav,mix,SR);raw.unlink()
    for ext,args in [('mp3',['-c:a','libmp3lame','-b:a','192k']),('ogg',['-c:a','libvorbis','-q:a','6'])]:
        helpers.ffmpeg(['-v','error','-i',wav,*args,'-metadata','title=有间晨炊·晴日长笛版',OUT/f'youjian-major-flute.{ext}'])
    # Verify delivered codecs and diatonic/on-beat composition rather than only file existence.
    validation={}
    for ext in ['wav','mp3','ogg']:
        f=OUT/f'youjian-major-flute.{ext}'
        decoded=subprocess.check_output(['ffmpeg','-v','error','-i',str(f),'-ar',str(SR),'-ac','2','-f','f32le','pipe:1'])
        a=np.frombuffer(decoded,dtype='<f4');assert np.isfinite(a).all() and abs(a).max()<.99
        validation[ext]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'seconds':len(a)/2/SR,'peak':float(abs(a).max()),'clipped_samples':int((abs(a)>=1).sum())}
    pitched=[e for e in events if e['part']!='drums' and e['part']!='triangle']
    assert all(e['note']%12 in [0,2,4,5,7,9,11]for e in pitched)
    assert all(e['beat']==int(e['beat'])for e in events)
    report={'installed_in_game':False,'mode':'C major','bpm':BPM,'bars':32,'triangle_hits':8,'note_onsets_on_quarter_beats_percent':100,'melody_pitch_classes':sorted(set(e['note']%12 for e in events if e['part']=='flute_melody')),'loudness':helpers.loudness(wav),'formats':validation,'bass_gain_change_db':-9.12,'synthesized_no_external_samples':True}
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
