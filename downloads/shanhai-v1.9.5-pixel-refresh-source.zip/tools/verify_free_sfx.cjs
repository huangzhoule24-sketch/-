/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8005').replace(/\/$/, '');
const out = process.argv[2] || 'build/free-sfx/browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function sceneReady() {
    for(let attempt=0;attempt<10;attempt++){
      const s=await state();if(!s.panel)return;
      const event=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id.endsWith(':1'))||s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
      if(event)await click(event.qa_id);
      else if(s.buttons.some(b=>b.qa_id==='panel:close'&&!b.disabled))await click('panel:close');
      else throw Error('Unresolved natural interruption during pickup verification: '+s.panel);
    }
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  const cueIds=Object.keys(JSON.parse(fs.readFileSync('config/audio.json','utf8')).cues);
  async function selectCue(cue){
    await click('audio:slot');await page.keyboard.press('Home');
    for(let i=0;i<=cueIds.indexOf(cue);i++)await page.keyboard.press('ArrowDown');
    await page.keyboard.press('Enter');await sync();
    if((await state()).audio_panel.selected!==cue)throw Error('Wrong selected cue: '+cue);
  }
  async function openAudio(){await click('nav:更多');await click('full:open:系统',true);await click('system:audio',true);}
  // Read an extra analyser branch; the original output connection is left intact.
  await page.addInitScript(()=>{
    window.shanhaiAudioMeters=[];window.shanhaiAudioMeasurements=[];
    const original=AudioNode.prototype.connect, seen=new WeakSet();
    const disconnect=AudioNode.prototype.disconnect;
    AudioNode.prototype.disconnect=function(...args){seen.delete(this);return disconnect.apply(this,args);};
    AudioNode.prototype.connect=function(destination,...args){
      const result=original.call(this,destination,...args);
      if(destination instanceof AudioDestinationNode&&!seen.has(this)){
        seen.add(this);const analyser=this.context.createAnalyser();analyser.fftSize=2048;
        const sink=this.context.createGain();sink.gain.value=0;
        original.call(this,analyser,args[0]||0);original.call(analyser,sink);original.call(sink,destination);
        window.shanhaiAudioMeters.push(analyser);
      }
      return result;
    };
    setInterval(()=>{
      let peak=0,squares=0,count=0;
      for(const a of window.shanhaiAudioMeters){const b=new Float32Array(a.fftSize);a.getFloatTimeDomainData(b);for(const v of b){peak=Math.max(peak,Math.abs(v));squares+=v*v;count++;}}
      window.shanhaiAudioMeasurements.push({time:performance.now(),peak,rms:Math.sqrt(squares/Math.max(1,count))});
      if(window.shanhaiAudioMeasurements.length>6000)window.shanhaiAudioMeasurements.shift();
    },40);
  });
  async function measurement(ms=600){
    const from=await page.evaluate(()=>performance.now());await page.waitForTimeout(ms);
    return page.evaluate(from=>{const a=window.shanhaiAudioMeasurements.filter(x=>x.time>=from);return {frames:a.length,peak:Math.max(0,...a.map(x=>x.peak)),rms:Math.sqrt(a.reduce((v,x)=>v+x.rms*x.rms,0)/Math.max(1,a.length)),meters:window.shanhaiAudioMeters.length,contexts:window.shanhaiAudioMeters.map(a=>a.context.state)};},from);
  }
  function recorded(label,ok,evidence){checks.push({label,ok,evidence});if(!ok)throw Error(label+' '+JSON.stringify(evidence));}
  try{
    receipt=await(await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:full');await click('tutorial:ack');
    await click('nav:员工');await click('panel:close');await click('tutorial:ack');
    await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');
    if((await state()).panel)await click('panel:close');
    await page.waitForFunction(()=>window.shanhaiQAState?.state.served>=1,undefined,{timeout:60000});
    if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');
    await click('tutorial:ack');await click('tutorial:destination');await click('tutorial:ack');await click('panel:close');
    await click('time:1');
    await page.waitForFunction(()=>['action.order','action.cook','action.serve','event.checkout'].every(c=>window.shanhaiQAState?.audio?.played?.[c]>0),undefined,{timeout:60000});
    const played=(await state()).audio.played;
    for(const cue of ['ui.click','ui.back','action.order','action.cook','action.serve','event.checkout'])recorded('Natural opening triggers '+cue,(played[cue]||0)>0,played[cue]);
    await sceneReady();
    const live=await measurement(1600);recorded('Actual Web Audio output contains bundled sound',live.meters>0&&live.peak>.0001,live);
    await click('time:pause');await page.waitForTimeout(650);
    const quiet=await measurement(500);recorded('Paused scene stops world effects and ambience',quiet.peak<.00001&&(await state()).audio.ambience_paused,quiet);
    await openAudio();
    const ready=(await state()).audio_panel.ready;
    recorded('All 30 non-music cues bundled; five music slots stay empty',ready.length===30&&ready.every(c=>!c.startsWith('music.')),ready);
    await shot('desktop');
    await selectCue('ambience.night');await click('audio:preview');
    await check('Night ambience preview actually plays',()=>window.shanhaiQAState.audio.preview_playing);
    const preview=await measurement(800);recorded('Preview sends actual audio samples to output',preview.peak>.0001,preview);
    await click('audio:mute',true);await page.waitForTimeout(350);
    const muted=await measurement(600);recorded('Master mute silences actual output including preview',muted.peak<.00001&&(await state()).audio.muted,muted);
    await click('audio:mute',true);const unmuted=await measurement(600);recorded('Unmute restores the existing preview',unmuted.peak>.0001,unmuted);
    await click('audio:stop');
    for(const cue of ['action.cook','move.fly','guest.eat','event.stage']){
      await selectCue(cue);const from=await page.evaluate(()=>performance.now());await click('audio:preview');await page.waitForTimeout(750);
      const metrics=await page.evaluate(from=>({peak:Math.max(0,...window.shanhaiAudioMeasurements.filter(x=>x.time>=from).map(x=>x.peak))}),from);
      recorded('Bundled '+cue+' is playable without import',metrics.peak>.00001,metrics);await click('audio:stop');
    }
    await page.setViewportSize({width:844,height:390});await sync();await wheel(-20000);
    recorded('Mobile fixed back button remains visible',(await state()).buttons.some(b=>b.qa_id==='panel:back'),{viewport:'844x390'});await shot('mobile');
    await click('panel:back');recorded('Mobile returns to actual system parent',(await state()).panel==='系统');
    await click('system:save',true);await page.waitForTimeout(1000);await page.reload();
    await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:continue');await sceneReady();await openAudio();
    recorded('Bundled sounds survive reload without manual import',(await state()).audio_panel.ready.length===30);
    const measurements=await page.evaluate(()=>window.shanhaiAudioMeasurements);
    recorded('Measured output has no clipped samples',Math.max(...measurements.map(x=>x.peak))<.99,{maximum_sampled_block_peak:Math.max(...measurements.map(x=>x.peak))});
    fs.writeFileSync(path.join(out,'final-state.json'),JSON.stringify(await state(),null,2));
    fs.writeFileSync(path.join(out,'output-measurements.json'),JSON.stringify(measurements));
  }catch(e){errors.push(String(e.stack||e));fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify(await state(),null,2));await shot('failure').catch(()=>{});}
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt?.game_source,actions,checks,errors,measurement_note:'An extra browser analyser branch samples rendered output; no subjective listening or Windows hardware test is claimed.'},null,2));
  console.log(JSON.stringify({actions:actions.length,checks:checks.length,errors},null,2));
  await browser.close();if(errors.length)process.exitCode=1;
})();
