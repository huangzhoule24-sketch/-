#!/usr/bin/env python3
"""Rebuild the selected, licensed online sound effects; never changes music."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.parse
import urllib.request
import wave

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RATE = 48000


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--download", action="store_true", help="Fetch pinned source files if absent from cache")
    args = parser.parse_args()
    selection = json.loads((ROOT / "docs/free-sfx/selection.json").read_text())
    cache = ROOT / "build/free-sfx/source-cache"
    cache.mkdir(parents=True, exist_ok=True)
    report = {"sample_rate": RATE, "files": [], "music_written": False}
    for entry in selection["files"]:
        source = entry["source"]
        cached = cache / (source["sha256"] + "." + source["path"].split(".")[-1])
        if not cached.exists():
            if not args.download:
                raise ValueError("Missing source; run with --download: " + source["path"])
            url = urllib.parse.quote(source["download_url"], safe=":/%")
            with urllib.request.urlopen(url, timeout=40) as response:
                data = response.read(32 * 1024 * 1024)
            if digest(data) != source["sha256"]:
                raise ValueError("Source hash changed: " + source["path"])
            cached.write_bytes(data)
        if digest(cached.read_bytes()) != source["sha256"]:
            raise ValueError("Cached source hash mismatch: " + source["path"])
        decoded = subprocess.check_output([
            "ffmpeg", "-v", "error", "-i", str(cached), "-f", "f32le", "-ar", str(RATE), "-ac", "2", "pipe:1"
        ])
        samples = np.frombuffer(decoded, dtype="<f4").reshape(-1, 2).astype(np.float64)
        edit = entry["edit"]
        start = round(edit.get("start", 0) * RATE)
        samples = samples[start:start + round(edit.get("max_seconds", 120) * RATE)].copy()
        if not edit.get("loop", False):
            samples = samples.mean(axis=1, keepdims=True)
            rate = edit.get("playback_rate", 1)
            if rate != 1:
                positions = np.arange(0, len(samples) - 1, rate)
                samples = np.interp(positions, np.arange(len(samples)), samples[:, 0])[:, None]
            envelope = np.max(np.abs(samples), axis=1)
            audible = np.flatnonzero(envelope > max(0.00002, envelope.max() * .0015))
            if not len(audible):
                raise ValueError("Silent source: " + source["path"])
            samples = samples[max(0, audible[0] - 96):min(len(samples), audible[-1] + 1440)]
            fade_in = min(round(RATE * .003), len(samples) // 4)
            fade_out = min(round(RATE * .025), len(samples) // 4)
            samples[:fade_in] *= np.linspace(0, 1, fade_in)[:, None]
            samples[-fade_out:] *= np.linspace(1, 0, fade_out)[:, None]
        else:
            # Overlap the original end with its beginning. The join has no fade to silence.
            overlap = round(RATE * .25)
            fade = np.linspace(0, 1, overlap)[:, None]
            join = samples[-overlap:] * (1 - fade) + samples[:overlap] * fade
            samples = np.concatenate([samples[overlap:-overlap], join])
        samples -= samples.mean(axis=0)
        peak_target = 10 ** (edit["peak_dbfs"] / 20)
        gain = peak_target / max(float(np.max(np.abs(samples))), 1e-9)
        if "rms_dbfs" in edit:
            gain = min(gain, 10 ** (edit["rms_dbfs"] / 20) / max(float(np.sqrt(np.mean(samples ** 2))), 1e-9))
        samples *= gain
        if not edit.get("loop", False):
            samples[0] = 0; samples[-1] = 0
        target = ROOT / "assets/audio" / entry["output"]
        target.parent.mkdir(parents=True, exist_ok=True)
        pcm = np.round(np.clip(samples, -1, 1) * 32767).astype("<i2")
        if target.suffix == ".wav":
            with wave.open(str(target), "wb") as output:
                output.setnchannels(pcm.shape[1]); output.setsampwidth(2); output.setframerate(RATE); output.writeframes(pcm.tobytes())
        else:
            subprocess.run([
                "ffmpeg", "-v", "error", "-y", "-f", "s16le", "-ar", str(RATE), "-ac", str(pcm.shape[1]),
                "-i", "pipe:0", "-c:a", "libvorbis", "-q:a", "4", "-map_metadata", "-1", str(target)
            ], input=pcm.tobytes(), check=True)
        # Measure the actual delivered codec, not only its pre-encode array.
        delivered = subprocess.check_output(["ffmpeg", "-v", "error", "-i", str(target), "-f", "f32le", "-ar", str(RATE), "-ac", str(pcm.shape[1]), "pipe:1"])
        actual = np.frombuffer(delivered, dtype="<f4").reshape(-1, pcm.shape[1])
        peak = float(np.max(np.abs(actual)))
        if not np.isfinite(actual).all() or peak >= .99:
            raise ValueError("Clipping or invalid samples: " + entry["output"])
        differences = np.max(np.abs(np.diff(actual, axis=0)), axis=1)
        report["files"].append({
            "cue": entry["cue"], "path": "assets/audio/" + entry["output"], "source_sha256": source["sha256"],
            "sha256": digest(target.read_bytes()), "bytes": target.stat().st_size, "seconds": len(actual) / RATE,
            "channels": pcm.shape[1], "peak_dbfs": round(20 * np.log10(max(peak, 1e-9)), 2),
            "rms_dbfs": round(float(20 * np.log10(max(float(np.sqrt(np.mean(actual ** 2))), 1e-9))), 2),
            "loop": edit.get("loop", False), "boundary_step": float(np.max(np.abs(actual[0] - actual[-1]))),
            "ordinary_step_p999": float(np.quantile(differences, .999)), "clipped_samples": int(np.count_nonzero(np.abs(actual) >= 1)),
        })
    report["cue_count"] = len(set(item["cue"] for item in report["files"]))
    destination = ROOT / "docs/validation-artifacts/free-sfx/audio-files.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"files": len(report["files"]), "cues": report["cue_count"], "bytes": sum(s["bytes"] for s in report["files"]), "clipped_samples": sum(s["clipped_samples"] for s in report["files"])}))


if __name__ == "__main__":
    main()
