#!/usr/bin/env python3
"""Fetch cited public files with TLS verification and check short quotations.

Run after build_culture_catalog.py. Downloads stay in ignored build/; the report
records provenance, not full third-party texts. --offline rechecks cached bytes.
Matching checks transcription, not historical truth or edition authenticity.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import lzma
import re
import urllib.request
import urllib.parse

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "build/culture-source-cache"


def letters(text):
    return "".join(character for character in text if character.isalnum())


def without_annotations(text):
    # Kanripo parenthesised interlinear notes can interrupt a main-text quote.
    previous = None
    while previous != text:
        previous = text
        text = re.sub(r"\([^()]*\)", "", text)
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    data = json.loads((ROOT / "config/culture.json").read_text(encoding="utf-8"))
    groups = {}
    for source in data["sources"]:
        groups.setdefault(source["url"], []).append(source["id"])
    CACHE.mkdir(parents=True, exist_ok=True)

    def fetch(item):
        url, ids = item
        path = CACHE / (hashlib.sha256(url.encode()).hexdigest() + ".bin")
        if not args.offline:
            request = urllib.request.Request(urllib.parse.quote(url,safe=":/%?=&+#"), headers={"User-Agent": "ShanhaiCultureSourceCheck/2.0"})
            with urllib.request.urlopen(request, timeout=40) as response:
                status = response.status
                raw = response.read(32 * 1024 * 1024 + 1)
                if status != 200 or len(raw) > 32 * 1024 * 1024:
                    raise ValueError(f"Source response/size rejected: {url}")
            path.write_bytes(raw)
        else:
            raw = path.read_bytes()
        return {"url": url, "source_ids": ids, "http_status": None if args.offline else 200,
                "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "cache_file": path.name}

    with ThreadPoolExecutor(max_workers=4) as pool:
        receipts = list(pool.map(fetch, groups.items()))
    by_id = {source_id: receipt for receipt in receipts for source_id in receipt["source_ids"]}
    text_cache = {}
    quotations = []
    for kind in ["employees", "dishes", "guests"]:
        for entry_id, entry in data[kind].items():
            for quote in entry.get("quotes", []):
                source_id = quote["source_id"]
                receipt = by_id[source_id]
                path = CACHE / receipt["cache_file"]
                if path.name not in text_cache:
                    raw = path.read_bytes()
                    if receipt["url"].endswith(".xz"):
                        raw = lzma.decompress(raw)
                    text = re.sub(r"^#\+.*$|\[[^\]\n]*\]", "", raw.decode("utf-8-sig"), flags=re.M)
                    text_cache[path.name] = (letters(text), letters(without_annotations(text)))
                needle = letters(quote["text"])
                matched = bool(needle) and any(needle in version for version in text_cache[path.name])
                quotations.append({"kind": kind, "id": entry_id, "source_id": source_id,
                                   "quote": quote["text"], "matches_retrieved_text": matched})
    result = {"checked_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
              "mode": "cached_recheck" if args.offline else "actual_https_get",
              "catalogue_sha256": hashlib.sha256((ROOT / "config/culture.json").read_bytes()).hexdigest(),
              "source_records": len(data["sources"]), "unique_files": len(receipts),
              "receipts": receipts, "quotations": quotations,
              "unmatched_quotes": sum(not item["matches_retrieved_text"] for item in quotations),
              "limit": "Electronic transcriptions; matching removes layout, punctuation and optional interlinear notes. It does not establish historical truth, earliest attestation or a critical edition."}
    destination = ROOT / "docs/culture-research/source-verification.json"
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ["mode", "source_records", "unique_files", "unmatched_quotes"]}, ensure_ascii=False))
    if result["unmatched_quotes"]:
        for item in quotations:
            if not item["matches_retrieved_text"]: print(json.dumps(item, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
