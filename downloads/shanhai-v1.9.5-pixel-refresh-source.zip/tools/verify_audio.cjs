/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8003').replace(/\/$/, '');
const out = process.argv[2] || 'build/v195-browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function sceneReady() {
    for(let attempt=0;attempt<10;attempt++){
      const s=await state();if(!s.panel)return;
      const event=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id.endsWith(':1'))||s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
      if(event)await click(event.qa_id);
      else if(s.buttons.some(b=>b.qa_id==='panel:close'&&!b.disabled))await click('panel:close');
      else throw Error('Unresolved natural interruption during pickup verification: '+s.panel);
    }
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  const cueIds=Object.keys(JSON.parse(fs.readFileSync('config/audio.json','utf8')).cues);
  async function selectCue(cue){
    await click('audio:slot');
    await page.keyboard.press('Home');
    for(let i=0;i<=cueIds.indexOf(cue);i++)await page.keyboard.press('ArrowDown');
    await page.keyboard.press('Enter'); await sync();
    if((await state()).audio_panel.selected!==cue)throw Error('Wrong selected audio slot: '+cue+' got '+(await state()).audio_panel.selected);
  }
  async function importAudio(cue,extension){
    await selectCue(cue);
    const chooser=page.waitForEvent('filechooser'); await click('audio:import');
    await(await chooser).setFiles(path.resolve('build/audio-fixtures/probe.'+extension));
    const expectedPath=JSON.parse(fs.readFileSync('config/audio.json','utf8')).cues[cue].files[0].replace(/\.[^.]+$/,'.'+extension);
    await page.waitForFunction(expected=>window.shanhaiQAState?.audio_panel?.result?.includes(expected),expectedPath,{timeout:10000});
    checks.push({label:'Physical file chooser imports '+extension+' into '+cue,ok:true});
    await sync();
    if(!(await state()).audio_panel.ready.includes(cue))throw Error('Import did not populate '+cue);
  }
  async function openAudio(){
    await click('nav:更多');await click('full:open:系统',true);await click('system:audio',true);
  }
  try {
    receipt=await(await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:full');await click('tutorial:ack');
    await click('nav:员工');await click('panel:close');await click('tutorial:ack');
    await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');
    if((await state()).panel)await click('panel:close');
    await page.waitForFunction(()=>window.shanhaiQAState?.state.served>=1,undefined,{timeout:60000});
    if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');
    await click('tutorial:ack');await click('tutorial:destination');await click('tutorial:ack');await click('panel:close');
    await openAudio();
    if((await state()).audio_panel.ready.length!==30)throw Error('Fresh export must provide 30 non-music sound cues');
    checks.push({label:'Fresh production export has 30 bundled sound cues and five empty music slots',ok:true});
    await importAudio('music.day','mp3');await selectCue('music.day');await click('audio:preview');
    await check('MP3 preview plays',()=>window.shanhaiQAState.audio.preview_playing);
    await click('audio:stop');
    await importAudio('music.explore','ogg');await selectCue('music.explore');await click('audio:preview');
    await check('OGG Vorbis preview plays',()=>window.shanhaiQAState.audio.preview_playing);await click('audio:stop');
    await importAudio('ui.click','wav');await selectCue('ui.click');await click('audio:preview');
    await check('PCM WAV preview plays',()=>window.shanhaiQAState.audio.preview_playing);await click('audio:stop');
    await wheel(-20000);
    const slider=(await state()).audio_panel.sliders.music;
    const p=await point({...slider,x:slider.x+slider.w*.33,w:0});await page.mouse.click(p.x,p.y);actions.push({slider:'music',point:p});await sync();
    const savedVolume=(await state()).audio.levels.music;
    if(!(savedVolume>.2&&savedVolume<.45))throw Error('Volume slider did not apply: '+savedVolume);
    await click('audio:mute');await check('Mute control applies',()=>window.shanhaiQAState.audio.muted);
    await click('audio:mute');await sync();
    await shot('desktop');
    await click('panel:back');await click('system:save',true);
    await page.waitForTimeout(1000);
    await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:continue');await sceneReady();await openAudio();
    const restored=await state();
    if(!['music.day','music.explore','ui.click'].every(cue=>restored.audio_panel.ready.includes(cue)))throw Error('Audio files lost after reload');
    if(Math.abs(restored.audio.levels.music-savedVolume)>.0001||restored.audio.muted)throw Error('Audio settings lost after reload');
    checks.push({label:'All three formats and volume/mute persist through browser reload',ok:true});
    await page.setViewportSize({width:844,height:390});await sync();await wheel(-20000);
    if(!(await state()).buttons.some(b=>b.qa_id==='panel:back'))throw Error('Mobile back control is not visible');
    await shot('mobile');await click('panel:back');
    if((await state()).panel!=='系统')throw Error('Mobile back lost actual parent');
    checks.push({label:'Mobile 844x390 sound controls and actual-parent return work',ok:true});
    await click('panel:close');
    const starts=(await state()).audio.music_starts;
    await page.waitForTimeout(4500);await sync();
    if((await state()).audio.music_starts!==starts||(await state()).audio.active_music!=='music.day'||!(await state()).audio.music_playing)throw Error('Looping MP3 restarted with UI refresh');
    checks.push({label:'Imported business music persists across more than one full loop',ok:true});
    fs.writeFileSync(path.join(out,'final-state.json'),JSON.stringify(await state(),null,2));
  } catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});}
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt?.game_source,actions,checks,errors},null,2));
  console.log(JSON.stringify({actions:actions.length,checks:checks.length,errors},null,2));
  await browser.close();if(errors.length)process.exitCode=1;
})();
