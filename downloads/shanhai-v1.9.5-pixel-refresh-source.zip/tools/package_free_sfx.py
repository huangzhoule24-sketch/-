#!/usr/bin/env python3
"""Build a standalone, offline-auditionable pack of the game's licensed SFX."""
import hashlib
import html
import io
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent


def main():
    config = json.loads((ROOT / "config/audio.json").read_text())
    selection = json.loads((ROOT / "docs/free-sfx/selection.json").read_text())
    report = json.loads((ROOT / "docs/validation-artifacts/free-sfx/audio-files.json").read_text())
    measured = {s["path"]: s for s in report["files"]}
    entries = {}
    rows = []
    for item in selection["files"]:
        source = ROOT / "assets/audio" / item["output"]
        data = source.read_bytes()
        assert hashlib.sha256(data).hexdigest() == measured[str(source.relative_to(ROOT))]["sha256"]
        target = "audio/" + item["output"]
        entries[target] = data
        cue = config["cues"][item["cue"]]
        rows.append('<tr><td>' + html.escape(cue["label"]) + '<br><small>' + html.escape(item["cue"]) + '</small></td><td>' + html.escape(Path(item["output"]).name) + '</td><td><audio controls preload="none" src="' + html.escape(target, quote=True) + '"></audio></td></tr>')
    for source in (ROOT / "assets/audio/licenses").glob("*.txt"):
        entries["licenses/" + source.name] = source.read_bytes()
    entries["CREDITS.md"] = (ROOT / "assets/audio/CREDITS.md").read_bytes()
    for name in ["selection.json", "sources.json", "guide.md"]:
        entries[name] = (ROOT / "docs/free-sfx" / name).read_bytes()
    entries["audio.json"] = (ROOT / "config/audio.json").read_bytes()
    entries["audio-files.json"] = (ROOT / "docs/validation-artifacts/free-sfx/audio-files.json").read_bytes()
    entries["试听.html"] = ('''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>山海食肆物语 · 音效试听</title><style>body{font:16px/1.6 system-ui,sans-serif;background:#f6f3eb;color:#273c37;max-width:1080px;margin:auto;padding:24px}h1{font-size:24px}table{width:100%;border-collapse:collapse}td{padding:12px;border-bottom:1px solid #d6ded8;vertical-align:top}small{color:#526c65}audio{width:290px;max-width:100%}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.6 system-ui} @media(max-width:650px){td{display:block;border:0;padding:6px}tr{display:block;border-bottom:1px solid #d6ded8;padding:12px 0}}</style><h1>山海食肆物语 · 音效试听</h1><p>42个文件，28类短音效与2类环境声。解压全部文件后打开本页，点击各播放器试听；无需联网。此页播放原文件，游戏中还会叠加槽位音量与总音量。背景音乐不包含在本包中。</p><p>请查看 <a href="guide.md">整合说明</a>、<a href="CREDITS.md">作者与许可</a>。再次发布时保留Oculus素材的署名、许可及编辑说明。</p><table>''' + "".join(rows) + '</table><h2>Credits</h2><pre>' + html.escape(entries["CREDITS.md"].decode()) + '</pre></html>').encode()
    entries["请先阅读.txt"] = "全部解压后打开 试听.html，即可离线逐个试听。\n游戏已内置这些音效，无需再导入。audio/是编辑后的交付文件；音量在游戏中另按audio.json和玩家设置混合。\n来源与授权见CREDITS.md、licenses/、sources.json和selection.json；Oculus文件使用CC BY 4.0，须保留署名、许可链接及编辑说明。\n没有背景音乐。\n".encode("utf-8-sig")
    entries["SHA256SUMS.txt"] = "".join(hashlib.sha256(data).hexdigest() + "  " + name + "\n" for name, data in sorted(entries.items())).encode()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(entries.items()):
            archive.writestr(name, data)
    data = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert archive.testzip() is None
    target = ROOT / "build/shanhai-free-sfx-audio.zip"
    target.write_bytes(data)
    result = {"file": target.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "audio_files": len(selection["files"]), "entries": len(entries)}
    (ROOT / "build/free-sfx/audio-pack.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
