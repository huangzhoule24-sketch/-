#!/usr/bin/env python3
"""Render an original, standalone restaurant BGM sketch with free DSP tools.

No sample libraries, model API, paid assets, or existing-song melodies are used.
Requires Python, numpy, scipy and ffmpeg. Outputs stay in ignored build/.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import subprocess
import wave

import numpy as np
from scipy.signal import butter, fftconvolve, sosfilt

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_SCORE = Path(__file__).with_name("score.json") if Path(__file__).with_name("score.json").exists() else ROOT / "tools/music-samples/youjian_chenchui.score.json"
PARTS = ["bamboo_lead", "plucked_strings", "bell_counterline", "round_bass", "warm_pad", "light_percussion"]
PAN = {"bamboo_lead":-.06, "plucked_strings":-.24, "bell_counterline":.30, "round_bass":0, "warm_pad":0, "light_percussion":.04}
GAIN = {"bamboo_lead":.105, "plucked_strings":.12, "bell_counterline":.040, "round_bass":.17, "warm_pad":.050, "light_percussion":.09}


def pitch(name):
    semitone = {"C":0, "D":2, "E":4, "F":5, "G":7, "A":9, "B":11}[name[0]]
    semitone += 1 if "#" in name else -1 if "b" in name else 0
    return (int(name[-1])+1)*12 + semitone


def frequency(note):
    return 440 * 2 ** ((note - 69) / 12)


def fade_envelope(count, sr, attack, release):
    envelope = np.ones(count)
    a, r = min(count, round(attack*sr)), min(count, round(release*sr))
    if a: envelope[:a] *= np.sin(np.linspace(0, np.pi/2, a))**2
    if r: envelope[-r:] *= np.sin(np.linspace(np.pi/2, 0, r))**2
    return envelope


def lowpass(data, sr, cutoff):
    return sosfilt(butter(2, cutoff, fs=sr, output="sos"), data)


def timbre(part, note, seconds, sr, rng):
    f = frequency(note)
    if part == "bamboo_lead":
        count = round((seconds+.12)*sr)
        t = np.arange(count)/sr
        vibrato = .0021 * np.sin(2*np.pi*5.05*t) * np.clip((t-.20)/.35, 0, 1)
        # A small breath/embouchure bend settles at the beginning of each note.
        bend = -.0025*np.exp(-t/.045)
        phase = 2*np.pi*np.cumsum(f*(1+vibrato+bend))/sr
        harmonics = [(1,1.0),(2,.24),(3,.085),(4,.025),(5,.009)]
        signal = sum(a*np.sin(k*phase) for k,a in harmonics)
        noise = rng.normal(0,1,count)
        breath = sosfilt(butter(2,[1300,4800],btype="bandpass",fs=sr,output="sos"),noise)
        signal += .017*breath
        envelope = fade_envelope(count,sr,.065,min(.15,seconds*.32))
        envelope *= .96 + .035*np.sin(2*np.pi*2.2*t)
        return lowpass(signal*envelope,sr,6500)
    if part == "plucked_strings":
        count = round((1.9+min(seconds,.7))*sr)
        t = np.arange(count)/sr
        signal = np.zeros(count)
        # Stiff-string modes, faster high-partial decay and a soft finger attack.
        for k in range(1,13):
            fk = f*k*math.sqrt(1+.00011*k*k)
            if fk > sr*.43: break
            amplitude = (1/k**1.25) * (.76 + .24*math.cos(k*1.3))
            decay = np.exp(-t/(1.3/(k**.63)+.10))
            bend_phase = -.025*np.exp(-t/.032)
            signal += amplitude*decay*np.cos(2*np.pi*fk*t + bend_phase + .11*k)
        signal += .016*lowpass(rng.normal(size=count),sr,3500)*np.exp(-t/.014)
        return signal*fade_envelope(count,sr,.005,.16)
    if part == "bell_counterline":
        count = round(2.8*sr); t = np.arange(count)/sr
        signal = sum(a*np.sin(2*np.pi*f*ratio*t)*np.exp(-t/decay)
                     for ratio,a,decay in [(1,1,1.2),(2,.22,.65),(3.01,.08,.32),(4.03,.025,.20)])
        return signal*fade_envelope(count,sr,.008,.2)
    if part == "round_bass":
        count = round((seconds+.13)*sr); t = np.arange(count)/sr
        signal = np.sin(2*np.pi*f*t)+.19*np.sin(2*np.pi*f*2*t)+.035*np.sin(2*np.pi*f*3*t)
        return signal*fade_envelope(count,sr,.025,.17)*(.75+.25*np.exp(-t/.3))
    if part == "warm_pad":
        count = round((seconds+.65)*sr); t = np.arange(count)/sr
        signal = np.zeros(count)
        for detune in [-2.5,2.5]:
            root = f*2**(detune/1200)
            signal += .5*(np.sin(2*np.pi*root*t)+.13*np.sin(2*np.pi*root*2*t)+.025*np.sin(2*np.pi*root*3*t))
        return signal*fade_envelope(count,sr,.55,.85)
    if part == "light_percussion":
        if note == 36:
            count = round(.25*sr); t = np.arange(count)/sr
            phase = 2*np.pi*(48*t+1.4*(1-np.exp(-t/.015)))
            signal = .8*np.sin(phase)*np.exp(-t/.075)+.15*np.sin(2*np.pi*146*t)*np.exp(-t/.035)
        elif note in [41,45,48]:
            count = round(.32*sr); t = np.arange(count)/sr
            root = {41:94,45:125,48:167}[note]
            signal = (.68*np.sin(2*np.pi*root*t)+.22*np.sin(2*np.pi*root*1.53*t))*np.exp(-t/.085)
            signal += .025*lowpass(rng.normal(size=count),sr,2800)*np.exp(-t/.02)
        elif note == 37:
            count = round(.085*sr); t = np.arange(count)/sr
            signal = (.22*np.sin(2*np.pi*740*t)+.11*np.sin(2*np.pi*1190*t))*np.exp(-t/.013)
            signal += .04*lowpass(rng.normal(size=count),sr,5000)*np.exp(-t/.009)
        else:
            count = round(.075*sr); t = np.arange(count)/sr
            noise = sosfilt(butter(2,[3800,9000],btype="bandpass",fs=sr,output="sos"),rng.normal(size=count))
            signal = .15*noise*np.exp(-t/.017)
        return signal*fade_envelope(count,sr,.0015,.018)
    raise ValueError(part)


def arrangement(score):
    rng = np.random.default_rng(score["seed"])
    events = []
    def add(part, beat, duration, note, velocity):
        events.append({"part":part,"beat":float(beat),"duration":float(duration),"note":pitch(note) if isinstance(note,str) else note,"velocity":float(velocity)})
    style = score.get("arrangement",{}).get("style","business")
    settings = score.get("arrangement",{})
    for bar, notes in enumerate(score["melody"]):
        offset = 0.0
        for name, length in notes:
            if name:
                # Leave gaps for breath; sections vary the instrumental emphasis.
                velocity = settings.get("lead_velocity",.76 if 16 <= bar < 24 else .84) * rng.uniform(.92,1.02)
                add("bamboo_lead",bar*4+offset+rng.uniform(-.008,.008),length*settings.get("lead_gate",.90),name,velocity)
            offset += length
    for bar, chord_name in enumerate(score["progression"]):
        chord = score["chords"][chord_name]
        tones = chord["tones"]
        sparse = 16 <= bar < 24
        offsets = [0,.75,1.5,2,2.75,3.5] if not sparse else [0,1.5,2.75,3.5]
        indices = [0,2,3,1,4,2] if not sparse else [0,2,4,1]
        if style == "title":
            offsets = [0,.08,1.5,2.75,3.5]; indices = [0,2,4,1,3]
        elif style == "night":
            offsets = [0,1.75,3.25]; indices = [0,2,4]
        elif style == "explore":
            offsets = [0,.5,1.5,2,2.5,3.5]; indices = [0,2,1,3,2,4]
        elif style == "contest":
            offsets = [0,.5,1,1.5,2,2.5,3,3.5]; indices = [0,2,1,3,0,2,4,2]
        for index,(offset,tone) in enumerate(zip(offsets,indices)):
            add("plucked_strings",bar*4+offset+rng.uniform(-.009,.009),.65,tones[tone],rng.uniform(.62,.82)*(1 if index%3==0 else .83))
        # Small upper-register answers appear in melody gaps, once per two bars.
        bell_turn = bar%2 == 1 if style in ["business","contest"] else bar%4 == 3
        if bell_turn:
            add("bell_counterline",bar*4+3.10,.35,tones[2],.68)
            add("bell_counterline",bar*4+3.65,.30,tones[4],.53)
        root = pitch(chord["bass"])
        add("round_bass",bar*4,2.8 if style == "night" else 1.48,root,.77)
        if style != "night": add("round_bass",bar*4+2.50,1.05,root+(7 if bar%4==3 else 12),.48)
        if style == "contest":
            add("round_bass",bar*4+1.5,.45,root+7,.38)
        for index,name in enumerate(tones[:4]):
            add("warm_pad",bar*4+index*.016,3.9,pitch(name)-12,.55 if not sparse else .64)
        if style == "night":
            if bar%2 == 0: add("light_percussion",bar*4+2.5,.1,82,.17)
            continue
        kicks = [0,1.5,2.5] if style == "contest" else [0,2]
        for beat in kicks: add("light_percussion",bar*4+beat,.2,36,.65 if beat==0 else .45)
        for beat in [1,3]: add("light_percussion",bar*4+beat+.012,.1,37,.43 if not sparse else .29)
        if style == "contest" and bar%4==3:
            for beat,note in [(2.75,48),(3.25,45),(3.75,41)]: add("light_percussion",bar*4+beat,.15,note,.52)
        for eighth in range(8):
            if sparse and eighth%2==0: continue
            if style == "title" and eighth%2==0: continue
            add("light_percussion",bar*4+eighth*.5+(.018 if eighth%2 else 0),.08,82,rng.uniform(.24,.38))
    return sorted(events,key=lambda e:e["beat"])


def add_wrapped(track, signal, start, pan, gain):
    start %= len(track)
    stereo = np.stack([signal*math.cos((pan+1)*math.pi/4),signal*math.sin((pan+1)*math.pi/4)],axis=1).astype(np.float32)*gain
    first = min(len(stereo),len(track)-start)
    track[start:start+first] += stereo[:first]
    if first < len(stereo): track[:len(stereo)-first] += stereo[first:]


def reverb(send,sr):
    rng = np.random.default_rng(716)
    ir = np.zeros((round(1.65*sr),2),dtype=np.float32)
    times = [31,47,73,101,137,179,223,271,331,397,463,541,631,733,853,997,1151,1337,1511]
    for i,ms in enumerate(times):
        start = round(ms*sr/1000)
        count = round((.006+.0007*i)*sr)
        cloud = rng.normal(size=(count,2))
        cloud = lowpass(cloud.T,sr,5000).T
        cloud *= np.hanning(count)[:,None]
        cloud *= math.exp(-ms/430)*.30/math.sqrt(count)
        ir[start:start+count] += cloud
    result = np.zeros_like(send)
    for channel in range(2):
        wet = fftconvolve(.80*send[:,channel]+.20*send[:,1-channel],ir[:,channel])
        result[:,channel] = wet[:len(send)]
        tail = wet[len(send):]
        result[:len(tail),channel] += tail
    return result


def write_wav(path,data,sr):
    path.parent.mkdir(parents=True,exist_ok=True)
    data = np.rint(np.clip(data,-1,1)*32767).astype("<i2")
    with wave.open(str(path),"wb") as handle:
        handle.setnchannels(2); handle.setsampwidth(2); handle.setframerate(sr)
        handle.writeframes(data.tobytes())


def variable_length(value):
    result = [value&127]
    while value>>7:
        value >>= 7; result.insert(0,(value&127)|128)
    return bytes(result)


def midi_file(score,events,path):
    ticks = 480; end = score["bars"]*4*ticks
    def track(items):
        data = bytearray(); previous = 0
        for tick,order,event in sorted(items,key=lambda x:(x[0],x[1])):
            data.extend(variable_length(max(0,tick-previous))); data.extend(event); previous=tick
        data.extend(variable_length(max(0,end-previous))+b"\xff\x2f\x00")
        return b"MTrk"+struct.pack(">I",len(data))+data
    tempo = round(60_000_000/score["bpm"])
    key = score.get("key_signature",[2,0])
    tracks = [track([(0,0,b"\xff\x51\x03"+tempo.to_bytes(3,"big")),(0,1,b"\xff\x58\x04\x04\x02\x18\x08"),(0,2,b"\xff\x59\x02"+bytes([key[0]&255,key[1]]))])]
    programs = [73,107,10,32,89,0]
    for index,part in enumerate(PARTS):
        channel = index if part!="light_percussion" else 9
        name = part.encode(); items = [(0,0,b"\xff\x03"+variable_length(len(name))+name),(0,1,bytes([0xC0|channel,programs[index]]))]
        for event in events:
            if event["part"] != part: continue
            start = max(0,round(event["beat"]*ticks)); stop = min(end,round((event["beat"]+event["duration"])*ticks))
            velocity = max(1,min(127,round(event["velocity"]*95)))
            items += [(start,3,bytes([0x90|channel,event["note"],velocity])),(max(start+1,stop),2,bytes([0x80|channel,event["note"],0]))]
        tracks.append(track(items))
    path.write_bytes(b"MThd"+struct.pack(">IHHH",6,1,len(tracks),ticks)+b"".join(tracks))


def ffmpeg(args):
    result = subprocess.run(["ffmpeg","-hide_banner","-nostdin","-y",*map(str,args)],capture_output=True,text=True,encoding="utf-8",errors="replace")
    if result.returncode: raise RuntimeError(result.stderr[-3000:])
    return result.stderr


def loudness(path):
    log = ffmpeg(["-i",path,"-af","loudnorm=I=-18:TP=-1.5:LRA=9:print_format=json","-f","null","-"])
    return json.JSONDecoder().raw_decode(log[log.rfind("{\n"):])[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--score",type=Path,default=DEFAULT_SCORE)
    parser.add_argument("--output",type=Path,default=ROOT/"build/music-sample" if (ROOT/"project.godot").exists() else Path(__file__).parent/"rendered")
    parser.add_argument("--stems-wav",action="store_true",help="Keep lossless WAV stems in addition to delivery OGGs")
    args = parser.parse_args()
    score = json.loads(args.score.read_text(encoding="utf-8")); sr=score["sample_rate"]
    if len(score["melody"]) != score["bars"] or len(score["progression"]) != score["bars"]:
        raise ValueError("Every bar requires a melody and a chord")
    if any(not math.isclose(sum(note[1] for note in bar),4) for bar in score["melody"]):
        raise ValueError("Each melody bar must sum to four beats")
    stem = score.get("output_stem","business_day")
    preview_stem = score.get("preview_stem","youjian_chenchui")
    beat_seconds = 60/score["bpm"]; count=round(score["bars"]*4*beat_seconds*sr)
    output=args.output; output.mkdir(parents=True,exist_ok=True)
    events=arrangement(score); rng=np.random.default_rng(score["seed"]+1)
    tracks={part:np.zeros((count,2),dtype=np.float32) for part in PARTS}
    for index,event in enumerate(events):
        part=event["part"]
        signal=timbre(part,event["note"],event["duration"]*beat_seconds,sr,rng)
        multiplier = score.get("mix",{}).get("gain_multipliers",{}).get(part,1.0)
        add_wrapped(tracks[part],signal,round(event["beat"]*beat_seconds*sr),PAN[part],GAIN[part]*multiplier*event["velocity"])
        if index%200==0: print(f"Rendered {index}/{len(events)} notes",flush=True)
    send=tracks["bamboo_lead"]*.35+tracks["plucked_strings"]*.48+tracks["bell_counterline"]*.55+tracks["warm_pad"]*.25
    tracks["room_reverb"]=reverb(send,sr)*score.get("mix",{}).get("reverb_multiplier",1.0)
    mix=sum(tracks.values())
    # Periodic warm-up prevents a filter reset transient at the loop boundary.
    prefix=round(.5*sr)
    for channel in range(2):
        sos=butter(2,30,btype="highpass",fs=sr,output="sos")
        mix[:,channel]=sosfilt(sos,np.concatenate([mix[-prefix:,channel],mix[:,channel]]))[prefix:]
    mix=np.tanh(mix*1.20)/1.20
    unmastered=output/".unmastered.wav"
    write_wav(unmastered,mix,sr)
    measured=loudness(unmastered)
    gain=min(10**((score.get("target_lufs",-18)-float(measured["input_i"]))/20),10**((-1.5-float(measured["input_tp"]))/20))
    mix*=gain
    master=output/(stem+".wav"); write_wav(master,mix,sr); unmastered.unlink()
    metadata=["-metadata","title="+score["title"],"-metadata","artist=Shanhai Restaurant AI-assisted composition"]
    ffmpeg(["-loglevel","error","-i",master,*metadata,"-c:a","libvorbis","-q:a","6",output/(stem+".ogg")])
    # A listening copy has a gentle ending; the WAV/OGG masters retain the loop.
    duration=count/sr
    ffmpeg(["-loglevel","error","-i",master,"-af",f"afade=t=in:d=0.035,afade=t=out:st={duration-1.8}:d=1.8",*metadata,"-c:a","libmp3lame","-b:a","192k",output/(preview_stem+"_preview.mp3")])
    stems=output/"stems"; stems.mkdir(exist_ok=True)
    for part,data in tracks.items():
        path=stems/(part+".wav"); write_wav(path,data*gain,sr)
        ffmpeg(["-loglevel","error","-i",path,"-c:a","libvorbis","-q:a","5",path.with_suffix(".ogg")])
        if not args.stems_wav: path.unlink()
    midi_file(score,events,output/(preview_stem+".mid"))
    shutil.copy2(args.score,output/"score.json"); shutil.copy2(__file__,output/"compose_business_music.py")
    (output/"arrangement.json").write_text(json.dumps(events,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    report={"title":score["title"],"bpm":score["bpm"],"bars":score["bars"],"sample_rate":sr,"channels":2,"frames":count,"duration_seconds":duration,"notes":len(events),"stems":list(tracks),"synthesized_no_external_samples":True,"installed_in_game":False,"output_stem":stem,"preview_stem":preview_stem,"loudness":loudness(master),"peak_sample":float(abs(mix).max()),"loop_boundary_step":float(abs(mix[0]-mix[-1]).max()),"max_sample_step":float(abs(np.diff(mix,axis=0)).max()),"render_script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"score_sha256":hashlib.sha256(args.score.read_bytes()).hexdigest()}
    (output/"render-report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)


if __name__=="__main__": main()
