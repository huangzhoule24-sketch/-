# 《有间晨炊》· 免费制作路线样曲

为《山海食肆物语》的日常营业场景原创的独立合成音乐样曲。没有加入游戏或替换现有音频。不是已有传统曲目的改编，不使用外部录音、收费音源或音频生成API。

乐谱在 `youjian_chenchui.score.json`，编曲和音色合成器在 `../compose_business_music.py`。旋律采用D宫五声音阶（D、E、F♯、A、B），配合现代和声、轻打击及柔和铺底；音色为拨弦与竹笛感合成音，不是真实古筝/竹笛录音。

## 重新制作

需要Python 3、numpy、scipy及支持libvorbis/libmp3lame的FFmpeg；均可使用免费工具，不需要音乐网站会员或API密钥。

```bash
python3 tools/compose_business_music.py
```

默认输出到忽略的 `build/music-sample/`。加 `--stems-wav` 可保留无损分轨，默认提供较小的OGG分轨。修改乐谱JSON中的melody、progression、bpm，再运行即可重做。

独立素材包内也附 `compose_business_music.py` 和 `score.json`，可在解压目录运行：

```bash
python compose_business_music.py --score score.json --output rendered --stems-wav
```

MIDI使用通用乐器编号方便编辑，换用其他音源播放时，声音会与本次合成母版不同。
