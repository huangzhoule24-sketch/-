# 山海食肆文化读本 · Chinese & English

修订：2026-10-28。30位员工、25道菜品、6位来客。中文与英文分别润写，原文节选配英文释意。

来客小传在游戏中仍须遇见后阅读；完整游戏界面的语言尚未全部翻译。美术资源与后续替换通道保留。

## 山海伙伴

### 羬羊 · Qián yáng

羬羊是有间食肆的厨师，尤其擅长照料汤品。这位羊身马尾的山中来客，也把钱来山的故事带到了灶边。

**松影中的异客**

翻开《山海经·西山经》，最先遇见的山叫钱来山。山上长松，山下出石，羬羊便生活在这里：模样像羊，身后却摇着一条马尾。寥寥几笔，寻常山景就多了一点让人回头看的奇趣。

**在有间食肆**

在有间食肆，羬羊负责烹饪，对汤品格外拿手：安排它掌勺，汤类菜品的品质会得到提升。它愿意守着炉火慢慢熬，也让匆匆赶路的客人有机会坐下来，喝上一碗热汤。

**从熟悉走进陌生**

羊身与马尾，不需要懂得许多古文也能想象。许多神话都用熟悉的动物拼出奇妙生命；认识羬羊，便是从一个亲切的小细节，走进中国古人的山海世界。

> 其狀如羊而馬尾
> ——《山海经》
> It has the shape of a sheep and the tail of a horse.

**Qianyang, the Mountain Sheep**

Qianyang is a chef at Youjian, with a particular gift for soups. This mountain creature brings a horse’s tail and a story from Qianlai Mountain to the kitchen.

**Among the mountain pines**

The Western Mountains begin at Qianlai Mountain, where pines grow above unusual stone. There lives Qianyang: sheep-shaped, but with a horse’s tail. One unexpected detail turns a familiar landscape into a place worth exploring.

**At Youjian**

At Youjian, Qianyang works as a chef and improves the quality of soups when assigned to cook. Patiently tending a simmering pot, Qianyang gives weary travellers a good reason to sit down for a warm bowl.

**A familiar doorway**

You do not need to read Classical Chinese to picture a sheep with a horse’s tail. Like many mythic creatures, Qianyang invites us into the unfamiliar through something we already know.

### 鸮 · Xiāo

鸮是食肆的服务员，夜市时动作更快。古诗中的夜鸟在这里穿梭于灯火与餐桌之间，照顾晚归的客人。

**暮色里的眼睛**

中国古诗里早有鸮的身影。《诗经》写过梅树上聚集的鸮，古人也常把它的夜鸣听作幽深山林中的信号。它不一定属于某一只独一无二的神兽，更像从漫长夜色里走来的熟面孔。

**在有间食肆**

在有间食肆，鸮是一位服务员。夜市营业时，它的工作速度会提升；替深夜的客人点单、端菜时，那份对夜色的熟悉便派上了用场。它也留意谁刚从雨里进门，谁的面该趁热端上。

**同一双眼，不同的故事**

若你曾在雅典娜身旁见过猫头鹰，也许会先想到智慧；在中国诗歌里，它又可能带来孤寂与夜的气息。让这些不同的联想坐在同一张桌旁，正是认识它的乐趣。

> 墓门有梅，有鸮萃止。
> ——《诗经》
> By the gateway stands a plum tree, where owls gather.

**Xiao, the Night Owl**

Xiao is a server who works faster at the night market. The owl of ancient poetry now moves between lamplight and tables, looking after late arrivals.

**Eyes after sunset**

Owls appear in early Chinese poetry, including the Book of Songs. Their calls could make an evening landscape feel mysterious or uneasy. Xiao belongs to this long tradition of watching and listening at night.

**At Youjian**

At Youjian, Xiao serves guests and works faster during the night market. Taking orders and carrying dishes after dark comes naturally; Xiao also notices the guest arriving from the rain and the noodles that should be served hot.

**One bird, several stories**

An owl beside Athena may suggest wisdom; an owl in Chinese verse may bring a different mood. Neither association has to erase the other. Xiao leaves room at the table for both.

### 耳鼠 · Ěr shǔ

耳鼠是一位动作轻快的服务员。传说中它能借尾巴飞行，在食肆里则灵巧地穿行于餐桌之间。

**尾巴也能当翅膀**

《北山经》把耳鼠安放在丹熏山，那里有树、有韭薤，也有流向西方的水。最让人记住的，却是“以其尾飞”：飞翔不一定要照着鸟儿的办法来，想象力自有另一条路。

**一只托盘的小冒险**

耳鼠端菜时很轻，转身也快，偏偏怕突如其来的响声。若谁肯先轻声说一句“借过”，它就能把托盘护得稳稳当当，再偷偷松一口气。

**奇异也可以很可亲**

神话里的组合动物，并不只有威严和可怕。耳鼠带着一点笨拙、一点机敏，让陌生的形貌变成容易亲近的性格；先喜欢上它，再去认它的名字，也很好。

> 以其尾飛
> ——《山海经》
> It flies by means of its tail.

**Ershu, the Flying-Tailed Mouse**

Ershu is a nimble server. In the old account it flies with its tail; at Youjian, its light movements help it carry dishes between tables.

**Another way to fly**

In the Northern Mountains, Ershu lives on Danxun Mountain among trees, herbs and running water. The memorable surprise is its flight: the book says it flies with its tail. Wings are not the only possibility in a mythic landscape.

**A tray-sized adventure**

Ershu moves lightly, but a sudden crash can startle it. A gentle warning before someone passes makes all the difference. Then the dishes reach the table safely, and their small carrier can breathe again.

**Strangeness with a gentle side**

A creature made from several animals need not be frightening. Ershu makes an unusual appearance feel approachable through familiar feelings: curiosity, nervousness and the pleasure of doing a job well.

### 灌灌 · Guàn guàn

灌灌是负责招徕的店员，最醒目的本领是一副好嗓子；它的鸣声也早已写进《山海经》。

**青丘的另一位邻居**

《南山经》说灌灌形似鸠，叫声像人在呵呼。山海间有许多以声音留下印象的异鸟，灌灌便是其中直爽的一位：先听到它，再抬头找它，大约是最自然的相识方式。

**热情得稍微响了一点**

它真心觉得新出锅的饭菜值得让所有人知道，于是把每一句欢迎都喊得很认真。熟客会笑着应一声，怕吵的客人却可能缩缩肩——招呼客人的分寸，它还在慢慢学。

**听见名字里的节奏**

灌灌读作Guànguàn，重复的音节像短促的鸟鸣。把名字念出声，往往比背下一个译名更容易亲近它，也能听见中文给异兽命名时的声音趣味。

> 其狀如鳩其音若呵
> ——《山海经》
> It resembles a dove, and its voice is like a person calling out.

**Guanguan, the Calling Bird**

Guanguan welcomes and attracts guests with a remarkable voice, a trait already recorded in the Classic of Mountains and Seas.

**A voice from Qingqiu**

The Southern Mountains describe Guanguan as dove-like, with a call resembling a human shout. Some marvellous birds are remembered for their plumage; this one announces itself before you even see it.

**An enthusiastic welcome**

Guanguan believes a good meal deserves a proper announcement. Regulars answer cheerfully; quieter guests may wince a little. Learning how warmly—and how loudly—to welcome someone is part of its life at the inn.

**A name you can hear**

Say Guànguàn aloud: the repeated syllables have a call-and-response rhythm. Keeping the Chinese name lets that small pleasure travel further than a descriptive translation alone.

### 讹兽 · É shòu

讹兽是善于宣传的店员，也是一位出了名会说话的异兽。它的故事提醒人们：动听的话也需要辨别真假。

**好听的话，未必可靠**

《神异经》中的讹兽有着兔一样的身形、人一样的面孔，而且能说话。它的奇处就在那张嘴：能把方向说反，把好坏倒过来。这个传说把语言的魅力和不可靠，揉进了同一个身影里。

**小馆门前的说书人**

让讹兽介绍一道菜，故事总比菜单长。它会把一缕香气说成山风，把一碗热汤说成远行的归处。掌柜欣赏它的口才，也常在旁边轻轻补上一句：“故事好听，答应客人的事可得算数。”

**幽默要能越过误会**

语言里的双关和夸张，换一种语言未必还一样好笑。认识讹兽，也像练习做一位体贴的讲述者：保留故事的趣味，同时让远来的客人听得明白。

> 其状若菟，人面能言。
> ——《神异经》
> It is rabbit-like in form, with a human face, and can speak.

**Eshou, the Charming Storyteller**

Eshou is a persuasive promoter and a creature famous for talking. Its old story reminds us to listen closely as well as enjoy a good tale.

**A delightful, unreliable voice**

The Classic of Strange Wonders describes a rabbit-like creature with a human face and the gift of speech. Its words turn directions and meanings around. The tale makes language both captivating and slippery.

**The storyteller outside**

Ask Eshou about a dish and you may hear a whole journey. A scent becomes a mountain breeze; soup becomes a homecoming. The innkeeper enjoys the performance, while making sure every promise to a guest is kept.

**Humour across a table**

Puns and exaggeration do not always travel neatly between languages. Eshou reminds a good host to keep the charm of a story while giving a newcomer enough context to enjoy it.

### 饕餮 · Tāo tiè

饕餮是食肆的厨师，对美食有着旺盛的好奇心。它的名字也让人想起古代兽面纹与关于食欲的故事。

**从古鼎上望来的脸**

古代青铜器上醒目的兽面，常被人称作饕餮纹；《吕氏春秋》也讲过鼎上饕餮的故事。张口欲吞的形象，把对食欲的惊叹与警醒一起留了下来。它的名字，从来不只是“很会吃”那么简单。

**把大胃口用在好地方**

来到小馆后，饕餮最喜欢的事是试味：这一口少点香，那一锅还能更鲜。它依旧对美食毫无抵抗力，却也开始关心最后一盘是否有人吃、忙了一天的厨师有没有留饭。

**别急着只叫它怪物**

许多文化都会借巨口或无尽饥饿讲贪欲。饕餮的故事还与礼器、宴饮和分享相连：丰富的一桌饭，既能叫人满足，也让人看见自己怎样对待别人。

> 周鼎着饕餮有首无身
> ——《吕氏春秋》
> On Zhou vessels appears Taotie, with a head and no body.

**Taotie, the Great Appetite**

Taotie is a chef with an enormous appetite for discovering flavours. Its name recalls ancient animal-face designs and stories about desire.

**A face on an ancient vessel**

The name Taotie is commonly associated with striking animal-mask designs on ancient Chinese bronzes. Early writing also uses it to explore appetite and greed. Awe and warning meet in the same open mouth.

**An appetite with somewhere to belong**

At the inn, Taotie channels its appetite into tasting and improving dishes. It still loves another helping, but is learning to notice the last unclaimed plate—and whether the cooks have eaten too.

**More than a monster’s hunger**

Stories everywhere give hunger larger-than-life shapes. Taotie also belongs to a world of ceremonial vessels, feasts and sharing. A full table can reveal as much about generosity as about appetite.

### 冉遗鱼 · Rǎn yí yú

冉遗鱼是擅长汤品的厨师。古书中的它出没于山间水泽，来到食肆后把水乡的记忆带进了汤锅。

**涴水里的奇梦**

《西山经》写英鞮山的鸟兽皆白，涴水从山中流出，冉遗之鱼便游在其中。古人还把它与安稳的睡梦相联，仿佛把夜里的不安，也托付给了水中这位奇异的住客。

**听水声的人会煮汤**

它照看汤锅时，喜欢等水声从急促转为细密，再慢慢下料。客人问起六只脚有什么用，它只把刚温好的碗推近些：“至少端汤的时候，很稳。”

**奇形之中，也有安慰**

看见蛇首或六足，第一眼也许觉得古怪；再读到古人对安眠的期盼，距离就近了一点。神话不只有惊险，也装着人们想睡个好觉这样朴素的愿望。

> 魚身蛇首六足
> ——《山海经》
> A fish’s body, a serpent’s head, and six feet.

**Ranyiyu, the Six-Legged Fish**

Ranyiyu is a chef fond of soups. Once described in mountain waters, it brings a memory of rivers to the inn’s simmering pots.

**A river and a peaceful dream**

In the Western Mountains, birds and beasts on Yingdi Mountain are white, and the Ranyiyu lives in the river below. Old accounts link it with untroubled sleep, giving the strange fish a quietly comforting place in the imagination.

**Listening to the pot**

Ranyiyu waits for a lively boil to settle before adding its ingredients. Asked what six feet are good for, it nudges a warm bowl towards the guest: “They do help me keep steady.”

**Comfort inside the unfamiliar**

A serpent-like head may look unsettling at first. The wish for a peaceful night is easier to recognise. Myth holds both kinds of wonder: the extraordinary creature and the very ordinary hope.

### 当康 · Dāng kāng

当康是食肆的服务员，也是一位与丰收相连的山海来客。传说中它的出现，寄托着人们对好年成的期盼。

**把丰收叫出来**

《东山经》中的当康形似有牙的猪，鸣叫像在呼唤自己的名字，出现时预示天下“大穰”。在依靠田地与时令生活的人心里，丰收不是抽象的幸运，而是一家人安稳过冬的底气。

**满仓之外，还要满桌**

当康喜欢看新米入库，也喜欢给晚来的客人添一小勺饭。它觉得丰收最好的样子，不是库房门关得紧，而是忙完一日的人坐下来，都能吃得安心。

**丰收是很容易懂的祝福**

无论熟悉的是收获节、感恩餐桌，还是秋收后的家宴，对丰年的盼望都容易相通。认识当康，不妨先从那句简单的好消息开始：这一季，我们可以分享更多。

> 見則天下大穰
> ——《山海经》
> When it appears, the world enjoys a plentiful harvest.

**Dangkang, Herald of the Harvest**

Dangkang is a server associated with a good harvest. Its appearance in an old mountain tale expresses the hope for a plentiful year.

**Calling in a good year**

The Eastern Mountains describe a tusked, pig-like creature whose call sounds like its own name. Its appearance heralds a great harvest: grain enough to feed people and carry them through the winter.

**From granary to table**

Dangkang enjoys seeing fresh grain arrive, but it also notices a late guest’s half-empty bowl. To this generous helper, a good harvest is most convincing when everyone at the table can eat their fill.

**A blessing that travels**

Harvest celebrations take many forms. Their hope for enough food, security and shared plenty is widely recognisable. Dangkang offers one Chinese expression of that hope, complete with a very distinctive face.

### 天狗 · Tiān gǒu

天狗负责宣传与收银，待客之余也留心店里的钱款。这个名字在中国古书和后世传说中有着不同的面貌。

**名字一样，模样未必一样**

《西山经》中的天狗形似狸、头部白色，古人赋予它抵御凶险的意味。后来民间又流传“天狗食月”的故事，把天上的明暗变化说成一次惊动乡里的吞食。一个名字，能在不同故事里长出不同模样。

**认得每一位出入的客人**

它对门口的脚步格外留意：谁淋了雨，谁忘了东西，谁走得有点匆忙。看起来严肃，其实最爱听熟客离开时说一句“明天见”。

**在名字的旅行中相遇**

日本也有名为天狗的形象，常让人想到长鼻或鸟翼。带着那个印象来认识阴山天狗，也很有趣：名字彼此相望，故事却不必长成同一个样子。

> 有獸焉其狀如狸而白首
> ——《山海经》
> There is a creature shaped like a wildcat, with a white head.

**Tiangou, the White-Headed Guardian**

Tiangou promotes the inn and helps at the till, keeping an eye on payments. The name has taken different forms in Chinese texts and later stories.

**A name with more than one life**

In the Western Mountains, Tiangou is cat-like and white-headed, with a protective association. Later tales of a heavenly dog swallowing the moon gave the name another memorable life. Mythic names can gather stories over time.

**Watching the doorway**

Tiangou notices a soaked coat, a forgotten parcel, or a guest in a hurry. Its stern expression softens most readily at the promise of a regular’s “See you tomorrow.”

**Meeting a travelling name**

Japanese tengu may bring long noses or bird-like features to mind. The shared written name opens a conversation, while the Chinese mountain creature still keeps its own appearance and stories.

### 蛊雕 · Gǔ diāo

蛊雕是一位服务员，特殊的叫声常让人先闻其声、再见其人；如何让新客安心，也是它在店里的功课。

**山林里出人意料的声音**

《南山经》写鹿吴山多金石，泽更之水流经其间；蛊雕就在这里出没。它的形体与叫声并不相称，古书又把它写得危险，让旅人明白：陌生山林里，耳朵听见的未必就是眼前的真相。

**让客人慢慢习惯自己**

在小馆，它正学着先点头，再开口招呼。偶尔一声叫得满堂回头，便赶紧把碗筷摆得更整齐些。它知道，让人放心这件事，有时需要比解释多一点耐心。

**先看行动，再下判断**

许多故事喜欢把不寻常的声音写成危险信号；而在一间愿意接纳异客的食肆里，人们还可以多看一步：这位模样陌生的伙伴，怎样对待眼前的人？

> 其狀如雕而有角
> ——《山海经》
> It resembles a great bird of prey, but has horns.

**Gudiao, the Antlered Bird**

Gudiao is a server whose unusual call may be heard before its owner is seen. Helping newcomers feel comfortable is part of its life at the inn.

**A sound that surprises**

The Southern Mountains place Gudiao among the rocky slopes and waters of Luwu Mountain. Its bird-like shape and infant-like cry do not match. In the old, dangerous encounter, sound is part of what makes the creature uncanny.

**Earning a familiar welcome**

Gudiao now tries a nod before a greeting. If its voice startles the room, it quietly makes the next table especially neat. Becoming familiar sometimes takes a little longer than introducing yourself.

**Look beyond the first impression**

A strange voice can carry strong associations in a folktale. At a welcoming inn, it can also be a reason to look more closely at someone’s actions, rather than deciding everything at first hearing.

### 旋龟 · Xuán Guī

旋龟是稳重的厨师，长于持久地照看灶台。它的龟身、鸟首与蛇尾，来自《山海经》对异兽的奇妙描绘。

**鸟首蛇尾的水中住客**

《南山经》写杻阳山有怪水，水中有旋龟，龟形而鸟首、虺尾，声音如判木。古人还把避疾求安的愿望寄在它身上。它的奇处不在一味长寿，而在熟悉的龟形里藏着几处出人意料的细节。

**不抢一步，也不少一步**

它习惯先把案台收好，再开始下一道菜。高峰时，别人担心它太慢，后来却发现它很少返工，也总能记得哪只锅该添水。炉边留一处稳当的位置，整间厨房都轻松些。

**慢，不等于没有力量**

不同故事里的龟常让人想到时间与耐心。旋龟多了鸟首、蛇尾和清脆的声音，也让人多看一眼：可靠的力量，未必总以最快、最响的方式出现。

> 其狀如龜而鳥首虺尾
> ——《山海经》
> Turtle-shaped, with a bird’s head and a serpent’s tail.

**Xuangui, the Steady River Turtle**

Xuangui is a steady chef who can keep working at the stove. Its turtle body, birdlike head and snake tail come from an ancient description.

**An unexpected river dweller**

The Southern Mountains place Xuangui in the waters of Niuyang Mountain: turtle-shaped, but with a bird-like head and a snake-like tail. Its wooden-sounding call makes this calm creature rather more surprising than an ordinary turtle.

**A steady place in a rush**

Xuangui clears its workspace before beginning again. Other cooks once mistook this care for slowness, until they noticed how rarely it has to redo a task—and how reliably it remembers a pot needs water.

**Strength at another pace**

Turtles can invite thoughts of patience and time. Xuangui adds its own memorable features, while leaving room for a familiar idea: dependable strength does not always need to arrive first.

### 青蚨 · Qīng Fú

青蚨是食肆服务员，也与“青蚨还钱”的民间故事相连。它在主店当班时，拾取钞票能带来更多收益。

**母与子的归路**

《搜神记》讲一种形似蝉的青蚨，母虫总能寻到被带走的幼子。故事又把这种相寻的力量借给铜钱，于是有了“青蚨还钱”的想象，“青蚨”也渐渐成为钱的别称。财富的故事深处，原来还有牵挂。

**一枚也别落下**

它找零钱很细心，归还失物时却比捡到钱还高兴。店里的人开玩笑说，青蚨真正守的也许不是钱袋，而是客人回头时那句“原来还在这里”的安心。

**名字里藏着一段小故事**

就像有些语言会用贝壳、金属或颜色借指金钱，中文也把一个神奇小虫的名字放进了钱袋。知道“青蚨”之后，再碰见古诗里的这个词，便能多听见一层回家的声音。

> 取其子，母即飞来，不以远近。
> ——《搜神记》
> Take away its young, and the mother flies to them, no matter the distance.

**Qingfu, the Returning Coin**

Qingfu serves at the inn and is linked to a folk tale about coins that return. While on the main shop’s shift, it increases the value of collected cash pickups.

**A story of finding one another**

In In Search of the Supernatural, a mother Qingfu can find her young wherever they are taken. A related tale lends that returning bond to coins. Qingfu thus became another name for money, with a story of attachment behind it.

**Nothing left behind**

Qingfu checks the change carefully, but seems happiest returning something a guest has lost. Its companions suspect that what it really guards is the relief in hearing, “You kept it for me.”

**A small story inside a word**

Languages find many indirect names for money. Chinese sometimes borrows the name of this marvellous insect. Recognising Qingfu in an old poem lets a financial word open onto a tale of return.

### 九尾狐 · Jiǔ wěi hú

九尾狐是善于照顾客人的服务员。青丘的狐在不同传说中时而令人敬畏，时而象征祥瑞。

**青丘来的九道风**

《南山经》写青丘山有九尾之狐，声音像婴儿；在另一些古代叙事里，九尾白狐又与祥瑞、婚姻和王者的功业相联。它能显得危险，也能成为好兆头，正因为它从未只住在一种讲法里。

**先记得客人，再记得夸奖**

小馆的九尾狐很会照顾气氛。它记得谁爱坐窗边，也看得出谁今日没精神。好看固然容易让人回头，能让人愿意再来一趟的，却常是这些不张扬的小事。

**尾巴走过了许多地方**

中国的九尾狐、日本的狐与韩国的九尾狐，在东亚的故事中彼此映照，又各有变化。保留“九尾狐”这个名字，便能沿着同一条尾影，认识几种并不相同的想象。

> 其狀如狐而九尾
> ——《山海经》
> It has the form of a fox, with nine tails.

**Jiuweihu, the Nine-Tailed Fox**

The Nine-Tailed Fox is an attentive server. In stories of Qingqiu, the fox can be awe-inspiring or auspicious, depending on the telling.

**Nine tails from Qingqiu**

The Southern Mountains give Qingqiu a fox with nine tails and an infant-like cry. Other old stories associate a nine-tailed white fox with auspicious events. Its long life in storytelling has room for more than one meaning.

**A welcome worth returning to**

The fox remembers a favourite seat by the window and notices when a regular seems tired. Beauty may turn a head; a thoughtful welcome is what brings a guest back.

**Following a travelling fox**

Fox traditions in China, Japan and Korea have met and changed over time. Shared features make a useful starting point, while each tradition keeps its own moods, meanings and memorable tales.

### 毕方 · Bì fāng

毕方是擅长烤制的厨师。古书里这只独足异鸟与火的征兆相连，到了灶边，火候便成了它的手艺。

**赤纹青羽的一足鸟**

《西山经》中的毕方形似鹤，却只有一足，青色身躯上带着红纹、白喙。它的出现与火灾的征兆相连。古人把难以捉摸的灾异，记在这只醒目的鸟身上，也留下了格外鲜明的配色。

**把火看成一位老熟人**

小馆的毕方烤东西时并不心急。它先等炭火收住明焰，再翻动食材，让焦香停在最恰好的地方。客人只看见一盘热腾腾的烤物，它看见的却是每一次靠近与退让。

**火鸟也有不同性情**

有些火鸟故事讲重生，有些讲光明，毕方则带着警觉走来。听懂这份不同，就能在同样耀眼的羽毛之外，看见中国山林传说里对火的敬畏。

> 其狀如鶴一足赤文青質而白喙
> ——《山海经》
> Crane-like and one-legged, with red markings, blue plumage and a white beak.

**Bifang, the One-Legged Firebird**

Bifang is a chef skilled with grilled food. The one-legged bird was once an omen associated with fire; here, managing the flame becomes a craft.

**Blue feathers, red markings**

In the Western Mountains, Bifang resembles a crane with one leg, a white beak, and red markings on blue plumage. Its appearance accompanies a warning of fire: a vivid creature carrying an equally vivid concern.

**An old acquaintance at the stove**

Bifang waits for the flame to settle before turning the food. A good char comes from knowing when to move closer and when to pull back. For this cook, restraint is part of working with fire.

**Different kinds of firebird**

Not every bird associated with fire tells a story of rebirth. Bifang carries vigilance instead. Its striking colours open a different conversation about the power—and unpredictability—of flame.

### 貔貅 · Pí xiū

貔貅是负责宣传和收银的店员，擅长经营钱柜。它从古代猛兽形象走来，也承载着后世聚财守护的愿望。

**从威猛走向吉祥**

早期文献里的貔貅带着猛兽的气势，《史记》把它列在熊罴等兽之间。漫长流传中，它又逐渐成为常见的吉祥兽，出现在摆件与佩饰上，把勇猛的力量化作守护与聚财的愿望。

**一枚铜钱也有来处**

它爱清点钱，也爱听钱背后的故事：这一枚来自赶早市的老人，那一张是客人攒着请朋友吃饭的。账目算清之后，它才会放心把今日收入收好，像收好每个人认真生活的心意。

**把祝愿留在身边**

许多地方都有象征好运的护符。认识貔貅，不必先相信一件东西真能带来财富；先读懂人们为何愿意把“愿日子更好”的心情做成一只小兽，就已经很亲近它了。

> 教熊罴貔貅貙虎
> ——《史记》
> He trained bears, pixiu and other fierce beasts.

**Pixiu, the Auspicious Guardian**

Pixiu promotes the inn and works the till. Its image travelled from ancient accounts of fierce beasts into later wishes for protection and prosperity.

**From strength to good fortune**

Early texts place Pixiu among powerful beasts. Over time, it also became a familiar auspicious figure in ornaments and personal objects, carrying wishes for protection and prosperity.

**Every coin has a story**

Pixiu enjoys balancing the till, but the money matters because of the people behind it. An early customer, a meal saved up for friends: keeping an honest account is its way of taking their effort seriously.

**Keeping a wish close**

Lucky charms appear in many places. Pixiu offers one way to make a wish tangible: a small, strong creature that can stand beside someone’s hope for a more secure life.

### 英招 · Yīngsháo

英招是接待旅人的服务员。《山海经》中的它照管天帝园圃、巡行四海，在小馆里则把远方的见闻带给客人。

**会巡游的园圃守护者**

《西山经》把英招写成人面、马身、虎纹、鸟翼的神，掌管天帝园圃，又巡行四海。花木与远游并在一起，让它既有照看一隅的细心，也有走向远方的开阔。

**一张桌子的远方**

它爱听旅人说起家乡的菜，也愿意讲讲某种叶子的香气从何而来。招呼客人时，它从不急着把话说完，总留一点空，让对方也把自己的故事端上桌。

**好客不只靠共同语言**

一杯温水、一处座位，或耐心等对方把一句话说完，都能成为欢迎。英招擅长的，正是这些不必先懂同一套神话，也能够感受到的体贴。

> 神英招司之
> ——《山海经》
> The god Yingzhao watches over it.

**Yingzhao, Keeper of the Celestial Garden**

Yingzhao is a server who welcomes travellers. The ancient guardian of a heavenly garden and wanderer of the seas now shares stories at the inn.

**A gardener with far horizons**

The Western Mountains give Yingzhao a human face, a horse’s body, tiger markings and wings. It tends a celestial garden and travels the four seas: care for one place, joined to curiosity about many.

**A place for another story**

Yingzhao asks travellers about food from home and shares the story of a fragrant leaf in return. It leaves space in every conversation, inviting the guest to bring something of their own to the table.

**Hospitality before fluency**

A seat, a drink, or the patience to let someone finish a sentence can welcome a guest before a shared language does. Yingzhao begins with those small, easily understood gestures.

### 陆吾 · Lùwú

陆吾是食肆的厨师，擅长烤制菜品。传说中的昆仑守护者，也有照看园苑和时节的职责。

**昆仑山上的大管家**

《西山经》称昆仑为天帝下都，由陆吾掌管。它有人面、虎身、虎爪和九尾，还照看天之九部与帝苑时节。这幅形象不只威严，也让人想到：再宏大的地方，也需要有人细心照料。

**让忙碌各得其所**

午市最忙时，陆吾不抢着喊大声。它只看一眼灶台，便知道哪盘该先出、哪位伙伴该歇一口气。尾巴多，事情也多；好在它很享受把一团忙乱慢慢理顺。

**山，也可以是世界的中心**

昆仑在中国神话里常连接人间与神圣之地。若你熟悉别的文化中的神山，可以带着那份敬意来想象它，再慢慢认识这里的园圃、神灵和守护者。

> 是神也司天之九部及帝之囿時
> ——《山海经》
> This god oversees the nine divisions of heaven and the seasons of the imperial gardens.

**Luwu, Steward of Kunlun**

Luwu is a chef who excels at grilled dishes. The legendary guardian of Kunlun also tended a divine garden and its seasons.

**The steward of a mythic mountain**

Kunlun is a dwelling of the celestial ruler in the Western Mountains. Luwu, human-faced and tiger-bodied with nine tails, oversees its affairs and the seasons of its gardens. Even a divine estate needs thoughtful care.

**Order in the lunch rush**

Luwu does not need to shout over the kitchen. It spots the next plate to send and the helper who needs a pause. Turning a hectic rush into a shared rhythm gives it quiet satisfaction.

**A mountain at the centre**

Sacred mountains offer a useful point of connection across stories. Kunlun has its own gardens, dwellers and geography; a familiar sense of wonder can be the beginning of learning those details.

### 精卫 · Jīngwèi

精卫是勤快的服务员，清理餐桌时尤其利落。衔木石填海的故事，让这位小鸟的坚持流传至今。

**海没有带走的名字**

《北山经》说炎帝的女儿女娃游东海而溺，化作白喙赤足的小鸟，名为精卫。它反复衔来西山木石，想把东海填平。悲伤没有在故事里消失，而是变成了一次又一次的飞行。

**小事，也值得认真做完**

它会把最后一张桌子擦净，把落在地上的一粒米拾起。旁人说这些事太小，它却很认真：“做完一件，就少一件。”忙完之后，它最喜欢坐在窗边，听大家平平安安地聊天。

**坚持不只有胜负**

如果想到的是一个永远做不完的任务，也别急着替精卫判输赢。它的故事动人之处，还在于不肯向伤痛低头；而在小馆，伙伴们也会记得请它歇一歇。

> 常銜西山之木石以堙于東海
> ——《山海经》
> It continually carries wood and stone from the western mountains to fill the eastern sea.

**Jingwei, the Sea-Filling Bird**

Jingwei is a diligent server, especially quick to clear tables. The little bird is remembered for carrying twigs and stones in its determination to fill the sea.

**A name the sea could not take**

The Northern Mountains tell of Nüwa (女娃), a daughter of the Flame Emperor, who drowned in the eastern sea and became Jingwei. The bird carries wood and stone from the western hills, trying to fill the water that took her life.

**One small task at a time**

Jingwei cleans the last table and picks up the stray grain of rice. “One thing finished is one less thing unfinished,” it says. Afterwards, it likes to listen to the ordinary comfort of friends talking safely nearby.

**Beyond winning or losing**

An endless task need not be read only as failure. Jingwei can speak of grief, memory and refusal to give in. At the inn, that determination also meets friends who make room for rest.

### 穷奇 · Qióngqí

穷奇是偏爱浓烈滋味的厨师，拿手菜有麻辣火锅。关于它的外形与性情，古代故事留下了不止一种讲法。

**古书里不止一种模样**

穷奇在山海故事中，有像牛、披刺毛的模样，也有似虎而生翼的形象；在另一些古代叙事里，它又位列四凶。流传的故事像几条山路，彼此交错，却不必每一步都重合。

**烈性子遇上热锅**

它下料果断，偏爱能让人精神一振的香味，见不得一锅汤煮得毫无脾气。可若客人认真说吃不了辣，它也会皱着眉另备一份——被需要，正慢慢改变它看待人的方式。

**凶名之外，再看一眼**

许多神话里的危险存在，也能在后来的故事中获得新的相遇。和穷奇同桌，不是忘记它的来路，而是愿意看看：一个不好相处的伙伴，还能长出怎样的分寸。

**Qiongqi, the Untamed One**

Qiongqi is a chef drawn to bold flavours, including a spicy hotpot. Ancient accounts offer more than one version of its appearance and character.

**Several trails through the stories**

Some mountain accounts make Qiongqi ox-like and bristly; another gives it a tiger-like, winged form. Other texts place the name among the Four Perils. The traditions meet without forming one tidy biography.

**A strong temper at a hot stove**

Qiongqi likes bold aromas and decisive seasoning. Yet when a guest genuinely cannot take the heat, it will grudgingly prepare another bowl. Being useful is giving its fierce pride somewhere new to settle.

**Another encounter with a fearsome name**

Retelling a dangerous creature can create space for a new relationship. Qiongqi’s reputation remains part of the story, while everyday encounters offer something a label alone cannot show.

### 梼杌 · Táowù

梼杌是负责宣传的店员，认准的主意不容易改变。它的名字在古代叙事中常与顽固的性情相连。

**一个让人头疼的名字**

《左传》用梼杌形容顽固难教的性情，后来的异兽故事又给它添上虎形、长尾等外貌。名字里仿佛早写着一场争执，难怪它总要把自己的想法从头讲到尾。

**先听它把话说完**

在小馆门前，梼杌会为一句招牌词较真，也会为客人记错的口味争两句。掌柜渐渐发现，先问它“你为什么这样想”，往往比直接下命令更有用。

**把不同意见留在桌上**

“固执”并不是一个人的全部。和它相处，像在练习一件各地的人都可能遇见的事：怎样既说清自己的理由，也给别人留下改变想法的余地。

**Taowu, the Stubborn One**

Taowu promotes the inn and is reluctant to abandon an idea once decided. Its name has long been associated with stubbornness in Chinese storytelling.

**A name with an argument in it**

In the Zuo Tradition, Taowu is associated with an obstinate, unteachable character. Later beast lore gives the name a striking bodily form. A difficult temperament and a formidable appearance grew together in its afterlife.

**Let it finish first**

Taowu debates the wording on a sign and remembers a customer’s order with surprising intensity. The innkeeper has found that “Tell me why” usually works better than another command.

**Room for disagreement**

Stubbornness is not a whole personality. Taowu turns a familiar problem into a daily conversation: how to explain your reasons while leaving another person room to reconsider.

### 混沌 · Hùndùn

混沌是一位爱尝试新味道的厨师。它的名字也让人想到《庄子》中关于无七窍者的寓言。

**七窍之前的世界**

《庄子》讲中央之帝浑沌没有人的七窍，朋友为了报答它，替它每日凿一窍，七日后浑沌却死了。这则奇妙又令人难忘的寓言，让人停下来想：好意若只照自己的样子去做，会发生什么？

**给新味道一点空白**

混沌试菜时不太守现成的次序。它先闻、再想，有时把两种原本没坐过一桌的味道轻轻放在一起。偶尔弄得满台狼藉，偶尔又真能让全店安静一瞬，然后齐声问：“这是什么？”

**理解，不一定从改造开始**

面对陌生习惯，人们很容易热心地替对方安排。混沌的故事提醒来客先留一点空白：不同的生活方式，也许需要先被看见，再被解释。

> 日鑿一竅，七日而渾沌死。
> ——《庄子》
> They opened one aperture each day; on the seventh day Hundun died.

**Hundun, Before the World Took Shape**

Hundun is a chef who likes experimenting with flavours. Its name also recalls a Zhuangzi parable about a being without the usual seven openings.

**Before the seven openings**

In Zhuangzi’s fable, Hundun has none of the seven openings people possess. Grateful visitors decide to make them, one each day; on the seventh day Hundun dies. Their kindness carries an unsettling assumption about how another being ought to be.

**Leaving a little space**

Hundun experiments by setting unfamiliar flavours beside each other. Some attempts become a mess; others make the whole kitchen stop and ask what they have just tasted. An unfinished idea is welcome here.

**Understanding before improving**

Encountering an unfamiliar custom can tempt us to improve it immediately. Hundun leaves a gentler possibility: look carefully first, and allow difference to remain before deciding what it means.

### 獬豸 · Xièzhì

獬豸负责宣传、收银与客诉，是食肆中善于辨明曲直的伙伴。独角神兽的形象长期与公正审断相联系。

**把公正想象成一只兽**

古人把辨别曲直的愿望寄在獬豸身上，传说它能分辨争讼是非，后来獬豸冠也成为司法象征。形貌在不同记载里有所变化，那份希望却很清楚：愿判断不偏不倚，愿受委屈的人有处可说。

**先让一杯茶凉下来**

客人与伙计吵起来时，它常先请双方坐下，把菜、账单和经过一件件问明白。等茶不再烫口，许多原本只剩火气的话，也终于能说得清楚些。

**看见彼此熟悉的公平**

有的地方用天平或蒙眼的人物表达公正，这里则用一只有角的神兽。外形不同，却都在追问人怎样判断、怎样信任；认识这种共同的期盼，比急着寻找完全相同的对应更有意思。

> 獬豸知曲直獄訟平則至
> ——《宋书》
> Xiezhi knows right from wrong, and appears when judgements are fair.

**Xiezhi, the One-Horned Judge**

Xiezhi promotes the inn, works the till and helps with complaints. The one-horned creature has long been associated with fair judgment.

**Giving fairness a visible form**

Old accounts associate Xiezhi with discerning right from wrong, and its image entered the symbolism of law. The creature’s form varies, but the wish is recognisable: an impartial judgement and a hearing for someone who has been wronged.

**Let the tea cool**

When tempers rise, Xiezhi invites everyone to sit. What was ordered, what was served, and what happened next? By the time the tea cools, the conversation often has room for facts as well as feelings.

**Different images, a shared question**

Scales or a blindfolded figure may be familiar images of justice elsewhere. Xiezhi offers another. The images differ, while the questions about judgement, trust and fairness can open a conversation.

### 青耕 · Qīng Gēng

青耕是细心的服务员，善于照顾顾客情绪。古人把祈求平安的心愿寄托在这只青白相间的异鸟身上。

**把平安寄在羽毛上**

《中山经》写堇理山有青耕，形似喜鹊，青身、白喙、白目、白尾，叫声像自呼其名。古人相信它能御疫，把对平安的盼望，寄在了一位轻巧的山林来客身上。

**先照顾眼前的小事**

客人因等待皱起眉，青耕会先把茶续上，再认真说明还要多久。它知道一句“别着急”不如一次真切的照应；许多不愉快，正是在这些小事里慢慢散开的。

**祝福也有轻轻的样子**

吉祥不一定要金光耀眼，也可以是一只看起来清爽、叫声熟悉的小鸟。把这份安宁放到餐桌旁，不同来处的人也容易明白：被好好照顾，是一种很亲切的福气。

> 青身白喙白目白尾名曰青耕
> ——《山海经》
> Blue-green in body, with white beak, eyes and tail: it is called Qinggeng.

**Qinggeng, the Bird of Reassurance**

Qinggeng is an attentive server who helps care for guests’ moods. Ancient descriptions of this blue-and-white bird also express a wish for safety.

**A hope carried on feathers**

In the Central Mountains, Qinggeng resembles a magpie, with blue-green plumage and white features. Old hopes of protection from illness gather around this bird. Its appearance becomes a reassuring sign in an uncertain world.

**Care in practical things**

Qinggeng refills the tea and gives an honest waiting time. It knows that a real act of care can mean more than telling someone not to worry. A tense table often settles through small, useful gestures.

**A quieter kind of blessing**

An auspicious presence need not glitter with gold. Qinggeng’s clear colours and attentive company offer a gentler form of good fortune: the easily recognised comfort of being looked after.

### 天禄 · Tiān Lù

天禄是负责宣传与收银的店员，名字寄托了人们对福禄与安稳生活的祝愿。

**随身而行的吉祥**

“禄”常使人想到福分与生活的安稳。天禄作为瑞兽，也进入了古人的装饰世界；《后汉书》所记步摇六兽中，就有写作“天鹿”的名字。珠玉与兽形相映，让祝愿能够被佩在身上。

**让好消息多停一会儿**

它会替抱着东西的客人扶门，也爱把今天第一句夸奖转告厨房。偶尔看见小伙伴失落，便认真数起今日已经做好的事，仿佛真能把散落的好运一件件捡回来。

**一眼看见的心意**

门上的吉祥纹、衣饰上的护符、随身的小挂件，都能让人把愿望带在身边。天禄也这样走近远方来客：先是一只好看的小兽，随后是一句无需复杂翻译的祝福。

**Tianlu, the Auspicious Companion**

Tianlu promotes the inn and works the till. Its name carries wishes for good fortune and a secure life.

**Good wishes made visible**

Lu suggests good fortune and a secure livelihood. Related auspicious beasts entered the world of ornaments: the Book of the Later Han names a Tianlu among creatures decorating an elaborate headdress. A wish could travel with its wearer.

**Helping good news linger**

Tianlu holds a door, passes a compliment to the cooks, and reminds a discouraged helper what went well today. Its gift is often simply noticing a good thing and making sure somebody else notices it too.

**A wish at first sight**

An ornament or small charm can carry a hope before anyone explains it. Tianlu offers that kind of welcome: first a memorable creature, then a good wish that does not require a long translation.

### 凤凰 · Fènghuáng

凤凰是能够胜任多种岗位的食肆伙伴。五彩凤凰在中国传统中常与美德、安宁和吉祥相连。

**丹穴山的五彩来客**

《南山经》里的凤凰住在丹穴山，五彩羽纹与德、义、礼、仁、信相联。它自然饮食，自歌自舞，出现时天下安宁。古人把美丽与美好的秩序，写在同一双翅膀上。

**让一间屋子重新有精神**

忙过了头，凤凰会先把自己的呼吸放慢，再请伙伴喝口水。它知道恢复精神不总要声势浩大：有人肯陪着坐一会儿，一间屋子就可能慢慢亮起来。

**与重生之鸟相望**

若你熟悉的是浴火重生的phoenix，这里还有另一份值得认识的愿景：让好日子来到人间。“凤凰”与“phoenix”可以彼此照亮，也各自保留最动人的那一束光。

> 自歌自舞見則天下安寧
> ——《山海经》
> It sings and dances of itself; when it appears, the world is at peace.

**Fenghuang, the Auspicious Bird**

Fenghuang is a versatile member of the inn’s team. In Chinese tradition this colourful bird is associated with virtue, peace and good fortune.

**Colours that carry a wish**

The Southern Mountains place Fenghuang on Danxue Mountain. Its coloured markings are linked with virtues, and its song and dance herald peace. Beauty is joined to a wish for a world in which people can live well together.

**Helping the room brighten**

After an exhausting rush, Fenghuang slows down and asks its companions to drink and rest. Renewed spirits need not arrive dramatically. Sometimes a little company is enough to bring the room back to life.

**Meeting another phoenix**

If a phoenix first suggests rebirth to you, Fenghuang also offers the hope of peace and good order. The two traditions can illuminate each other without giving up what makes each distinctive.

### 白泽 · Báizé

白泽是食肆的导师，陪伴伙伴培训，也能参与菜品研发。善于辨识万物的神兽故事，让它成为一位耐心的引路人。

**把未知画成一本书**

古书中有《白泽图》的线索，也有黄帝遇见能言神兽、向它问知万物的故事。白泽因此常与博识、辨识怪异相连：让令人害怕的未知有名可认、有话可讲，便是一种温柔的力量。

**问一遍，再试一遍**

小馆里，新来的伙伴做错一道菜，白泽会陪它重新看一遍火候、闻一遍香气。它相信懂得多的人，最该记得初学时的不安；所谓导师，不过是愿意陪别人多走几步的人。

**好奇心也是共同语言**

神话图册、旅行见闻与异兽百科，都在回应“世界上还有什么”。白泽欢迎带着不同背景的客人来提问，因为相识往往不从相同的答案开始，而从一个真心的问题开始。

> 得白澤神獸能言達於萬物之情
> ——《云笈七签》
> He encountered Baize, a speaking divine beast that understood the nature of all things.

**Baize, Keeper of Many Stories**

Baize is the inn’s mentor, helping train partners and develop recipes. Tales of a creature knowledgeable about the world make it a fitting guide.

**Making the unknown knowable**

Old texts mention a Diagram of Baize and tell of a speaking marvellous beast sharing knowledge with the Yellow Emperor. Naming unfamiliar beings gives the unknown a shape—and makes it a little less frightening.

**A patient teacher**

When a newcomer makes a mistake, Baize returns to the stove with them. Look again, smell again, try again. Someone who knows a great deal can still remember what it feels like to be learning.

**Curiosity as a shared language**

Bestiaries, travel accounts and books of wonders all ask what else the world might hold. Baize welcomes questions from different backgrounds. A sincere curiosity can begin a conversation before any shared answer exists.

### 应龙 · Yìnglóng

应龙是擅长水产料理的厨师。古老传说中的有翼之龙与水、旱雨相连，海鲜锅也因此成了它的招牌。

**翅膀与雨一起落下**

《山海经》的应龙参与过黄帝与蚩尤的战争，也与蓄水、旱雨相连。人们盼雨时，还会借应龙的形象表达愿望。于是那双有翼之龙的翅膀，既有传奇的力量，也有农田最需要的希望。

**雨天，总想留人吃饭**

它会在下雨前留意门外的风，把热汤备得更足一点。客人躲雨进来时，应龙很少问从哪里来，通常先问：“要不要吃点暖的？”

**龙可以承载怎样的盼望**

如果你熟悉的龙守着洞窟与宝藏，也可以从应龙开始，认识龙与雨、江河、农事相连的另一条故事线。想象并非只有一种方向，一场及时雨也足以写出传奇。

> 旱而為應龍之狀乃得大雨
> ——《山海经》
> In drought they made the form of Yinglong, and abundant rain came.

**Yinglong, the Rain-Bearing Dragon**

Yinglong is a chef skilled with seafood. Stories of the winged dragon link it with water and rain, inspiring its signature seafood pot.

**Wings above a thirsty field**

Yinglong appears in stories of the Yellow Emperor and in accounts connecting the dragon with water and rainfall. Its image also belongs to wishes for rain. A mighty creature becomes part of a very practical hope for growing things.

**A place to wait out the rain**

Yinglong watches the wind and keeps extra broth ready. When someone rushes inside to escape a downpour, its first question is usually whether they would like something warm.

**Another kind of dragon story**

A dragon may suggest treasure or a cavern in familiar fantasy. Yinglong opens another path, through rainfall, rivers and the needs of a field. Timely rain can be a wonder worthy of a powerful creature.

### 烛龙 · Zhúlóng

烛龙是食肆的厨师，也能运用与昼夜相关的能力影响营业时段。神话中，它的开眼与闭眼关系着白昼和黑夜。

**一呼一吸之间**

《海外北经》写钟山之神烛阴，视为昼、瞑为夜；《大荒北经》又写人面蛇身、通体赤色的烛龙。昼夜、风息与季候，在这样的神话里有了可以想象的生命。

**再大的神，也得等面熟**

烛龙知道夜市何时最热闹，却不会因为客人着急，就让一锅面少煮半分。它喜欢看灯从街头逐盏亮起，也喜欢收工后那一小段终于安静下来的时光。

**用故事回答天为什么变了**

太阳、季节与昼夜的来去，曾让许多地方的人讲起宏大的故事。烛龙给出的是一双眼睛、一具长身与一次呼吸；带着好奇认识它，也像重温人类观察天空的惊奇。

> 視為晝暝為夜
> ——《山海经》
> Its looking makes day; its closing eyes make night.

**Zhulong, Keeper of Day and Night**

Zhulong is a chef whose power can affect the flow of guests at different times. In myth, its opening and closing eyes are linked to day and night.

**A living rhythm of light**

Accounts in the Classic of Mountains and Seas link Zhulong with a red, serpent-like body and the turning of light and darkness. What we experience as the rhythm of a day becomes the presence of an immense living being.

**Even a great being waits for noodles**

Zhulong knows the night market’s rhythm, but a hurried guest still has to wait until the noodles are ready. It enjoys both the lanterns coming on and the quiet interval after the last bowl has gone out.

**Stories for a changing sky**

People in many places have told stories about daylight and the seasons. Zhulong answers with eyes, breath and an enormous body: a distinctive way to remember the wonder of watching the sky change.

### 帝江 · Dìjiāng

帝江是轻盈的服务员，负责把菜送到客人面前。古书中它六足四翼、没有面目，却懂得歌舞。

**天山上会跳舞的神**

《西山经》把帝江写成黄囊似的形体，赤如丹火，六足四翼，浑敦无面目，却“识歌舞”。一串看似矛盾的特征凑在一起，竟成了古书中格外轻盈、令人难忘的形象。

**托盘上的小小舞步**

帝江端菜时总带着一点节拍，等客人接稳盘子，才轻轻转身。有人看不出它笑没笑，它便用一个笨拙又认真的鞠躬，把“请慢用”表达得明明白白。

**不用同一种表情，也能相懂**

语言和表情会因人而异，身体的节奏、等待与回应却常能搭起一座桥。认识帝江，可以先不问它像不像谁；跟着它的动作，便知道它正在努力欢迎你。

> 渾敦無面目是識歌舞
> ——《山海经》
> Without a distinct face, yet knowing song and dance.

**Dijiang, the Faceless Dancer**

Dijiang is a light-footed server who carries dishes to guests. Ancient writing describes it as faceless, with six feet and four wings, yet able to sing and dance.

**A dancer in the mountains**

The Western Mountains describe a rounded, bag-like god, red as cinnabar fire, with six feet and four wings. It has no face, yet understands song and dance. The unexpected combination is part of its enduring charm.

**A little dance with a tray**

Dijiang waits for a guest to take the plate, then turns with a small rhythmic step. Its careful bow makes “Enjoy your meal” wonderfully clear, even without a face to smile with.

**Understanding through movement**

Expressions and languages differ. Rhythm, waiting and response can still create a bridge. Follow Dijiang’s movements and you can recognise its welcome without deciding what its face ought to look like.

### 九婴 · Jiǔyīng

九婴是能同时照看多道菜的厨师，忙碌时也需要留心体力。它的传说与水、火和多首异兽的想象相连。

**凶水边的旧事**

《淮南子》写羿替世间除害，在凶水之上杀九婴；古注又说它是“水火之怪”。水与火原本难以并立，这个名字却把两者的危险都聚到了一起，后来也常被想象成多首的异兽。

**同一顿饭的不同火候**

小馆里的九婴擅长同时照看几处灶火，忙时恨不得替每一锅都长一双眼睛。可几道菜要一起端上桌，靠的不只多几个脑袋，也靠伙伴彼此报时、接盘和提醒。

**多首之外，还有不同来路**

世界故事里，多首怪物并不少见；九婴的记忆却系在羿、凶水与水火相争之间。认出一个相似的轮廓之后，再听它自己的故事，才会看见名字里的细节。

> 殺九嬰於㐫水之上
> ——《淮南子（淮南鸿烈解）》
> He slew Jiuying upon the fierce waters.

**Jiuying, Many Heads at the Stove**

Jiuying is a chef able to tend several dishes at once, though busy work takes stamina. Its legend brings together water, fire and the image of a many-headed creature.

**An old story of water and fire**

Huainanzi tells of the archer Yi overcoming Jiuying at the fierce waters. An old commentary calls it a creature of water and fire. Later many-headed images give that double danger an especially striking form.

**Several pots, one meal**

Jiuying can keep track of several pans, but sending a shared meal out together still takes teamwork. Other helpers call the timing, take a plate, and notice when even this energetic cook needs a pause.

**Beyond the many-headed outline**

Many-headed beings appear in different storytelling traditions. Jiuying’s path runs through Yi, fierce waters and the pairing of fire with water. A familiar outline is a beginning, rather than the whole introduction.

## 一桌山海

### 阳春面 · Yáng chūn miàn

阳春面是食肆开张时就能供应的主食：清汤、面条与一点葱香，组成江南日常餐桌上熟悉的一碗。

**清简，也要有滋味**

阳春面也叫光面，常见于江南一带的日常饮食。汤清、面净，看似没多少东西，却格外考验汤底、面条与调味是否相衬。简单不是少做几步，而是每一步都不肯将就。

**在有间食肆**

这碗面从开店起就能供应，是小馆最初的主食之一。清汤托住面条，葱香轻轻浮在上面；食材和滋味都不张扬，却适合让刚进门的客人先暖暖胃，也为刚起步的食肆带来稳定收入。

**从一碗面认识“鲜”**

“鲜”不一定浓重，也不必依靠昂贵配料。若初尝中国汤面，不妨先留意温度、面条的弹性和汤的余味：朴素的一碗，也有很丰富的层次。

> 味要清鲜，不可淡薄。
> ——《随园食单》
> Flavour should be fresh and clear, without being thin.

**Yangchun Noodles**

Yangchun noodles are available from the start: a simple bowl of noodles, clear broth and spring onion, familiar in the everyday food culture of Jiangnan.

**Simplicity with care**

Also called plain noodles, Yangchun noodles belong to everyday food traditions associated with the Jiangnan region. With so few distractions, broth, seasoning and texture all have to work together.

**At Youjian**

Available as soon as the inn opens, this is one of Youjian’s first staple dishes. Clear broth carries the noodles and a little spring onion adds fragrance. It welcomes a hungry guest and provides a steady early source of income.

**Meeting the idea of xian**

Xian can suggest a clear, savoury freshness rather than richness alone. A simple noodle soup offers a gentle introduction: notice its warmth, texture and the flavour that remains after a sip.

### 蛋炒饭 · Dàn chǎo fàn

蛋炒饭是食肆开张时就能供应的主食。熟米饭、鸡蛋与热锅相遇，炒出的既是家常滋味，也是忙碌时可靠的一餐。

**把一粒米炒得分明**

熟米饭与鸡蛋相遇，靠的是火候、翻炒与调味的配合。各地会加不同配料，也会留下各自的家常习惯；没有必要只认一种样子，才肯承认这一碗好吃。

**在有间食肆**

小馆一开门就能供应蛋炒饭。它出餐较快，适合忙碌时为客人送上一份热饭；米粒、鸡蛋和锅中的火候彼此照应，寻常食材也能做出让人惦记的滋味。

**家的味道，各有版本**

世界各地都有人把米饭重新翻炒，做成自己熟悉的一餐。先尝这碗蛋炒饭，再聊聊你家的那一种，常常比争论哪一种才算正确，更容易交到朋友。

**Egg Fried Rice**

Egg fried rice is a staple available from the opening of Youjian. Cooked rice and egg meet a hot pan to make a dependable, familiar meal.

**Making each grain count**

Cooked rice and egg become a meal through heat, movement and seasoning. Different kitchens add different ingredients. The pleasure lies as much in a well-handled pan as in any single fixed recipe.

**At Youjian**

Egg fried rice is on the menu from the start and can be prepared quickly when the inn gets busy. Rice, egg and the heat of the pan work together, turning everyday ingredients into a meal worth remembering.

**Many versions of home**

Fried-rice dishes take many forms in different places. This bowl can begin a conversation about another kitchen, rather than a competition over which version deserves to count.

### 酸梅汤 · Suān méi tāng

酸梅汤是食肆开张时便可供应的酸甜饮品。乌梅的香气让一顿饭多了一份清爽。

**酸甜之间的一点回味**

酸梅汤是中国饮食中熟悉的酸甜饮品，常用乌梅调味，不同地方与人家也会添出不同香气。它的好处在滋味相接：不是把酸盖住，而是让酸与甜彼此有了照应。

**给一桌热菜留个转身**

吃过烤物或一口浓汤，再捧起杯子，舌尖便换了一段节奏。小馆喜欢把它留给不想继续吃得太厚重的客人，也留给只想坐一会儿的人。

**名字里的“汤”**

这里的“汤”是一杯饮料，不是另一道咸汤。中文菜单里的词常有这样的伸展：记住酸梅的味道，再记住suān méi tāng，名字就不再难懂了。

**Suanmeitang, Sour Plum Drink**

Suanmei tang is a sweet-and-tart drink available from opening day. Its smoked-plum fragrance offers a refreshing companion to a meal.

**Sweetness meeting sourness**

Often made with smoked or dried dark plums, this familiar Chinese drink varies between households and shops. Its character comes from balancing sweetness with the plum’s tartness, rather than hiding one beneath the other.

**A change of pace**

After a roast or a rich spoonful of broth, a sip changes the rhythm of the meal. The inn keeps a glass ready for guests who want a lighter turn—or simply somewhere to linger.

**When tang means a drink**

Tang often means soup, but here it names a beverage. A menu word can stretch beyond its first dictionary meaning. Taste the plum, learn suān méi tāng, and the unfamiliar name becomes much easier to remember.

### 羬羊羊肉汤 · Qián yáng yáng ròu tāng

羬羊羊肉汤是一道由羬羊带来灵感的热汤。羊肉的醇香与慢火熬煮，呼应中国各地丰富的羊汤传统。

**一碗汤的厚与清**

羊肉汤有许多地方风味：有的浓白，有的清亮，有的靠香料，有的重本味。《随园食单》谈味道，讲浓厚却不可油腻；一碗汤的分寸，往往就在这看似相近的一步之间。

**钱来山的风，炉边的火**

羬羊记得钱来山的松，也记得山路上天冷时最想念的热食。它不急着替汤添很多东西，只耐心照看火，让一碗普通饭食慢慢有了自己的性格。

**认得一碗“舒服”**

即使从没喝过羊肉汤，也可能熟悉某一碗让人安心的家乡汤。带着那份记忆来尝它，就能从异兽的招牌名字背后，认出很相近的待客心意。

> 味要浓厚，不可油腻。
> ——《随园食单》
> Flavour should have depth without becoming greasy.

**Qianyang’s Mutton Soup**

Qianyang’s mutton soup is a warming dish inspired by the mountain chef, with a place among China’s many regional traditions of slow-cooked lamb soup.

**Richness without heaviness**

Mutton soups vary widely between regions and kitchens. Some are clear, others rich and pale. The Suiyuan Food Lists praise depth without greasiness—a useful way to think about the balance of a comforting broth.

**A mountain memory at the stove**

Qianyang remembers mountain pines and the wish for something hot after a cold walk. Rather than crowding the pot with additions, it tends the fire until the bowl develops a quiet character of its own.

**Recognising comfort**

A guest may be new to mutton soup and still know what a comforting bowl means. A memory of another home’s broth offers a welcoming way into this dish, long before the mythic name becomes familiar.

### 毕方烤翅 · Bì fāng kǎo chì

毕方烤翅是以火鸟毕方命名的烤制菜。焦香外皮与丹木果的想象，让山海故事走上了餐桌。

**烤，是与火商量**

烤物的香气，来自表面受热之后的变化，也来自厨师判断何时翻面、何时离火的经验。古人谈“炙”，同样把食物与火紧紧相连；那一点焦香，至今仍容易叫人围过来。

**把危险的羽色变成晚饭**

毕方的青羽赤纹本与火的征兆相连，在小馆却成了熟悉的灶边颜色。丹木果带来一缕山海厨房的果香，让这盘烤翅既有烟火气，也藏一点远山的想象。

**一起分食的轻松**

不用先懂神话，也知道一盘烤物适合边聊边分。等最后一只烤翅被礼让了两次，陌生的名字或许就已经变成一段热乎的共同记忆。

**Bifang’s Ember-Roasted Wings**

Bifang’s grilled wings bring the firebird’s name to a roasted dish, pairing a fragrant crust with the imagined flavour of danmu fruit.

**Working with the flame**

Roasting depends on the cook’s sense of heat, distance and timing. The old Chinese word zhi also belongs to food cooked by fire. Across time, the smell of a roast has been good at gathering people.

**A different place for a firebird**

Bifang’s colours once accompanied a warning of fire; at the inn they belong beside a carefully watched stove. A fictional danmu fruit note adds a little mountain wonder to the familiar appeal of roasted wings.

**An easy dish to share**

A shared platter can make introductions easier. By the time the last wing has been offered around twice, an unfamiliar name may already belong to a warm memory at the table.

### 九尾仙奶 · Jiǔ wěi xiān nǎi

九尾仙奶是一杯九尾狐主题的乳饮。轻柔奶香与山海草木的想象，组成青丘来客递给食客的一份心意。

**把青丘放进一杯柔软**

九尾狐的故事，有幽深山林，也有祥瑞与美好的联想。小馆把那份轻盈留在乳饮的口感里，又用薲草添上一点山海想象，让一只神话异兽有了可以慢慢亲近的味道。

**慢慢喝，也是一种心情**

它适合跟一位朋友多坐片刻，也适合独自看一会儿窗外。九尾狐说，招待不是替每个人决定喜欢什么，而是留出足够多的选择，让人自在地挑一杯。

**“仙”字带来的轻盈**

中文里的“仙”可以让人想到轻盈、美好和超出日常的一点想象。这里先尝奶香，再去体会这个字的语气，比把每个字都硬译成一种神奇力量更自然。

**Nine-Tailed Fox’s Cloud Milk**

Nine-Tailed Fox Milk is a gentle dairy drink inspired by the fox of Qingqiu and the imagined plants of the mountains and seas.

**Qingqiu in a gentler key**

The nine-tailed fox carries both mysterious and auspicious associations. This drink draws on the gentler mood, using a soft texture and a touch of the inn’s imagined pincao herb to make Qingqiu feel close at hand.

**A little time of your own**

A cup can accompany a long conversation or a quiet look out of the window. The fox’s idea of good hospitality is not guessing everyone’s taste, but making enough room for each person to choose.

**The feeling of xian**

Xian can lend a name an airy, otherworldly charm. In this cup, that feeling matters more than a literal promise of magic. Let the flavour introduce the mood of the word.

### 应龙海鲜锅 · Yìng lóng hǎi xiān guō

应龙海鲜锅是一道热汤海鲜料理。与水和雨相连的应龙，为围桌共享的火锅添上了神话色彩。

**一口锅，把人留在一起**

火锅让食物在桌边继续受热，也让一顿饭多了一些共同等待、互相照应的时间。汤底与配料各有地方习惯，共同的是那份围着热气坐下来、慢慢吃的自在。

**雨水与海味的相逢**

应龙与水、旱雨相连，小馆便把它的招牌留给一锅海鲜。窗外的雨把街道洗亮，桌上的汤把鲜味托起；两种水声放在一起，像远方与此刻终于见了面。

**第一次围锅，也不必拘谨**

围锅的乐趣不只在吃到什么，也在一起吃的过程。若是第一次尝试，先看同桌如何照顾火候、如何递过一只干净的碗，很快就能找到属于自己的节奏。

**Yinglong’s Seafood Hot Pot**

Yinglong’s seafood pot is a hot broth for sharing. The dragon’s links to water and rain give this communal meal a mythic setting.

**A pot at the centre**

Hot pot keeps the meal cooking at the table. Ingredients and broths vary, while the shared waiting creates space to talk, pass a bowl, and look after one another.

**Water meeting water**

Yinglong’s rain-bearing stories find a place beside seafood broth. Rain brightens the street outside; the simmering pot brings out the flavour within. The mythic waters and the everyday meal answer each other.

**Joining the table**

The pleasure is in the shared process as well as the food. For a newcomer, watching the table’s rhythm—when to wait, when to pass a bowl—can make an unfamiliar meal feel welcoming.

### 饕餮自助套餐 · Tāo tiè zì zhù tào cān

饕餮自助套餐是一份选择丰富的组合餐，以饕餮与食欲的传说为引，也邀请食客按自己的胃口取用。

**丰盛，不等于把盘子堆满**

自助餐把选择交到食客手里，一次可以尝许多种味道。饕餮的名字带着强烈食欲的旧故事，放在这里便添了一点会心的趣味：再大的胃口，也要听一听自己真正想吃什么。

**少取一点，还能再添**

饕餮最爱看客人发现新味道，也渐渐学会把新出锅的一盘分给别人。小馆的规矩很温和：先取合适的份量，喜欢就再来，让最后一位客人也能尝到热乎的。

**在共享的餐桌上认识节制**

许多文化都重视一桌丰盛的待客饭，节制也不一定等于拘束。享受选择、愿意分享，让食物得到认真相待，可以同时发生在同一顿饭里。

**Taotie’s Feast of Choices**

Taotie’s buffet offers a choice of dishes, drawing on stories of appetite while inviting each guest to choose what they want.

**Abundance and choice**

A buffet invites a guest to try several dishes. Taotie’s old appetite makes the name playful, while the table asks a more everyday question: what would you actually enjoy eating now?

**There is time for another helping**

Taotie enjoys seeing a guest find a new favourite. At the inn, it is also learning to leave enough for others. Take a comfortable portion, return if you like, and let the last guest taste something warm too.

**A generous kind of moderation**

A full table and thoughtful eating need not oppose one another. Pleasure, choice and sharing can belong to the same meal. Taotie’s feast makes that conversation a little easier to begin.

### 凤凰涅槃羹 · Fèng huáng niè pán gēng

凤凰涅槃羹是一道以凤凰为主题的羹汤。绵润的一勺，承载安宁与重新出发的祝愿。

**羹里藏着的细心**

羹常以细碎食材与汤相合，口感可以绵润，也可以清鲜。它不靠大块堆叠显得丰盛，而把好几种味道收进同一勺里，像把不容易说清的照顾，慢慢煮得具体。

**把安宁与重新振作放在一起**

凤凰曾是安宁的好兆头，后来的故事又常把它与复起相联。这碗羹把两种心情放在一起：愿眼前的人先安稳下来，再带着一点力气，走向明天。

**一个跨过语言的名字**

“涅槃”随佛教语汇从梵语来到中文，后来也进入许多文学表达。小馆借的是重新出发的诗意；沿着一个菜名，便能看见词语如何在不同传统之间旅行。

**Fenghuang’s Renewal Broth**

Phoenix Rebirth Geng is a smooth, spoonable soup inspired by the phoenix and wishes for peace and renewal.

**Care gathered in a spoon**

Geng is a Chinese style of soup or thickened broth that can bring small ingredients together in a smooth texture. Its generosity lies less in a towering portion than in the flavours held within one spoonful.

**Peace, then a fresh start**

Fenghuang’s old promise of peace meets later imagery of renewal in this dish. The wish is simple: may the guest first feel safe and settled, then find the strength for tomorrow.

**A word that has travelled**

Niepan entered Chinese through Buddhist language, from Sanskrit nirvana. The menu borrows a later poetic sense of renewal. A dish’s name can reveal how a word has travelled, without exhausting all of its meanings.

### 祝余轻食 · Zhù yú qīng shí

祝余轻食是一道以山海奇草为灵感的清爽菜。祝余在古书中形似韭，开着青色花朵。

**山海开篇的一株草**

《南山经》开篇的招摇山，不只有金玉，也有状如韭、开青花的祝余。古书说食之不饥，把“远行时有东西可吃”的愿望写得奇妙又直接。读山海，从一株小草开始也很好。

**一盘绿意，不必太喧闹**

小馆的祝余轻食偏爱轻巧的调味，让脆嫩与清香自己说话。它不是要求客人吃得越少越好，而是在许多选择之外，留下一个可以吃得轻松些的选项。

**从“轻食”走近一份古老愿望**

“轻食”是今天熟悉的菜单词，祝余却来自很早的山海想象。一新一旧在盘中相遇，让人既看见当代饮食的选择，也想起古人盼望安稳饱足的心情。

> 其狀如韭而青花其名曰祝餘
> ——《山海经》
> It resembles chives, with blue flowers, and is called Zhuyu.

**Zhuyu Greens**

Zhuyu Salad is a light dish inspired by a plant in the Classic of Mountains and Seas, described as chive-like with blue-green flowers.

**A plant at the beginning**

Among the first wonders of the Southern Mountains is Zhuyu, a chive-like plant with blue flowers. The old claim that it stills hunger gives a traveller’s ordinary need an extraordinary answer.

**A lighter choice**

The inn seasons these imagined mountain greens lightly so their texture can lead. The invitation is not to eat as little as possible, but to have another comfortable option at the table.

**An old wish on a modern menu**

A contemporary lighter dish meets an ancient imagined plant. The pairing can begin with a familiar menu choice and lead towards an older wish for enough food and a safe journey.

### 陆吾烤肉拼盘 · Lù wú kǎo ròu pīn pán

陆吾烤肉拼盘把几样烤物盛在一盘，是昆仑守护者陆吾的招牌料理。

**一盘里，也有先后轻重**

拼盘把不同食物放到一起，好看之外，还要让口感与味道彼此相衬。古人讲烹饪，也会留意同席菜肴的安排；丰富若有次序，便不只是把东西堆在同一个盘子里。

**昆仑管家的一点习惯**

照看过天帝园囿的陆吾，总会先把出菜的次序想清楚。它不愿哪一块等凉，也不愿浓味把细味盖住。盘子端出来时看着利落，背后却藏着一场小小的调度。

**分享，也可以照顾不同偏好**

同桌的人未必喜欢同一种部位、同一种火候。拼盘让选择留在桌上：各取所爱，也尝一小口别人的推荐，一顿饭便多了一点认识彼此的机会。

**Luwu’s Roast Platter**

Luwu’s grilled platter brings several roasted foods together under the name of Kunlun’s guardian.

**Abundance with a little order**

A platter brings different foods together. The pleasure depends on contrast and balance as much as on quantity: something richer beside something lighter, a crisp edge beside a tender centre.

**A steward’s habit**

Luwu plans before the first piece comes off the heat. Nothing should go cold waiting for the rest, and a bold flavour should leave the gentler one a chance. A neat plate conceals quite a bit of care.

**Choices at a shared table**

Guests need not enjoy the same texture or richness. A platter lets each person choose, while leaving room for a small taste of someone else’s recommendation. Sharing can make difference comfortable.

### 英招时蔬沙拉 · Yīng zhāo shí shū shā lā

英招时蔬沙拉是一道草木主题的清爽菜，借园圃守护者英招与山海植物的形象讲述四时蔬味。

**跟着时令挑颜色**

时蔬的趣味，是季节一换，盘里的绿也跟着变化。食物不只来自厨房，还来自天气、土地与照料它们的人；尝一口当季的脆嫩，也像听见这一阵子的风。

**不迷路的树，遇见园圃之神**

《南山经》的迷榖是一种令人不迷路的神木，英招则照看天帝园圃。小馆把两段草木故事放在一起，取它们明亮、清爽的心情，写成这盘带一点远游意味的绿意。

**一个词，也能从远方来**

“沙拉”这个词随着饮食交流进入中文，盘中却可以装进本地时蔬和山海想象。借来的吃法，遇见自己的食材与故事，也能长成新的、自然的日常。

**Yingzhao’s Garden Salad**

Yingzhao’s seasonal salad is a fresh vegetable dish inspired by the garden guardian and the plants of the mountain stories.

**Colours that follow the season**

Seasonal vegetables change the plate as the year changes. They invite a guest to notice that food begins before the kitchen, in weather, soil and someone’s patient care.

**A garden and a traveller’s tree**

The migu tree is associated with finding one’s way; Yingzhao watches over a celestial garden. This imagined plate brings the two plant-filled stories together, suggesting both a place to grow and the courage to travel.

**A travelling word, a local plate**

Salad is a borrowed word in Chinese, but a plate can hold local vegetables and local stories. A food form that travels need not remain unchanged; it can become part of a new everyday life.

### 精卫石锅拌饭 · Jīng wèi shí guō bàn fàn

精卫石锅拌饭让精卫衔石的故事与韩国拌饭相遇，热锅、米饭和配菜带来丰富口感。

**一口锅里的许多颜色**

这道菜借来韩国拌饭的灵感，让不同颜色与口感在饭上相遇，再由食客亲手拌开。石锅多添了一层热度与锅底的香脆，最后一口常和第一口有不同的滋味。

**把木石的故事，化作耐心**

精卫一次衔起一小块木石，小馆则借它的坚持，记住每一步看似不起眼的准备。丹粟米是山海厨房想象中的红亮米粒，像把海上朝霞也添进碗里；拌好的饭，暖得很踏实。

**让两段文化坐到同一桌**

精卫的故事来自中国古籍，拌饭的饮食灵感来自韩国。名字与吃法不必来自同一个地方，仍可以互相尊重地相遇：记得各自的来路，也享受这一口新的组合。

**Jingwei’s Stone-Pot Bibimbap**

Jingwei’s stone-pot bibimbap brings the Chinese story of the determined bird into conversation with Korean mixed rice.

**Many colours in one pot**

Inspired by Korean bibimbap, the dish brings contrasting vegetables, rice and sauce together for the guest to mix. A hot stone pot adds warmth and a crisp layer below, so the final spoonful can differ from the first.

**A small task, repeated with care**

Jingwei’s repeated journeys echo in the careful preparation of this meal. The inn’s imagined red-tinted Dansu rice adds a colour like dawn over the sea. The result is an ordinary comfort carrying an extraordinary story.

**Two traditions, one table**

Jingwei’s tale comes from Chinese literature; the food inspiration comes from Korea. Remembering both origins makes the meeting more interesting. A creative pairing can welcome another tradition without claiming it as its own.

### 当康丰收炒饭 · Dāng kāng fēng shōu chǎo fàn

当康丰收炒饭是一道当康主题的炒饭，把丰收的祝愿和一锅粒粒分明的家常饭结合起来。

**丰收先从一粒米开始**

当康是报丰收的异兽，炒饭则是把谷物认真做好的一种日常手艺。把两者放在一起，丰年便不再只是远处满仓的画面，而是眼前这一口热乎、分明的饭粒。

**盛一碗，再给人留一碗**

当康总喜欢多问一句：“厨房里的人吃了吗？”它想象的丰收有很多张嘴，不只有先坐下来的客人。于是这盘饭端得很踏实，也带一点愿人人有份的心意。

**节日之外的丰年愿望**

庆祝收获的仪式各不相同，一碗不浪费、也不吝啬的饭，却容易让人懂得共同的盼望。丰收可以很隆重，也可以就是今天有人愿意替你添饭。

> 見則天下大穰
> ——《山海经》
> Its appearance foretells a plentiful harvest for the world.

**Dangkang’s Harvest Fried Rice**

Dangkang’s harvest fried rice combines an everyday pan of rice with the creature’s association with a plentiful harvest.

**A harvest close enough to taste**

Dangkang heralds a plentiful year, while fried rice gives grain an everyday place at the table. The pairing brings abundance out of a distant granary and into a warm spoonful.

**A portion for the people cooking**

Dangkang asks whether the kitchen helpers have eaten. A plentiful year should have room for more than the guests who sat down first. That generous thought gives the dish much of its character.

**A good year beyond the festival**

Harvest customs differ, but a meal that is neither wasteful nor grudging is easy to appreciate. A good year may be celebrated grandly—or felt in the simple offer of another spoonful.

### 天狗天妇罗 · Tiān gǒu tiān fù luó

天狗天妇罗是一道裹衣油炸的菜。中国天狗的名字与日本天妇罗相遇，呈现山海食肆的跨文化餐桌。

**轻薄的外衣，热气里的分寸**

天妇罗是日本饮食中常见的裹浆油炸菜式，外衣要衬出食材，而不把它的滋味完全盖住。趁热入口时，脆与嫩相接，最能让人明白为什么厨师如此在意上桌的时机。

**阴山来客的一道异乡菜**

小馆请中国山海故事里的天狗照看这盘日式料理，名字因此多了一重相遇。它的白头从门边一晃，盘子已经放稳，像替刚出锅的热度也尽了一份守护。

**字形相识，故事各有风景**

日本的天狗与中国古籍里的天狗，并不总有同样的模样；天妇罗又有自己的饮食来路。先尝这一口，再聊名字怎样跨海，正是这道菜最有趣的余味。

**Tiangou’s Tempura**

Tiangou tempura pairs the name of a Chinese mythic creature with Japan’s battered, fried cooking tradition at one cross-cultural table.

**A delicate coat**

Tempura is a Japanese style of battered frying. The coating gives a crisp contrast while leaving the ingredient recognisable. Its freshly cooked texture explains why the timing between pan and table matters so much.

**A guardian meeting another cuisine**

The inn pairs its Chinese mountain guardian with a Japanese food form. A glimpse of Tiangou’s white head at the doorway, and the plate is safely on the table: two different arrivals sharing a menu.

**Names that cross the sea**

Chinese Tiangou and Japanese tengu do not always look or behave alike, while tempura has its own culinary history. The dish makes a meeting point, leaving each story room to remain itself.

### 冉遗鱼汤 · Rǎn yí yú tāng

冉遗鱼汤是一道清鲜的鱼汤，名字借自山间水泽中的异鱼，也呼应厨师对汤品的偏爱。

**清汤也能有深度**

鱼汤不一定要熬得厚重，清亮的汤色也能托住细致的鲜味。选择怎样下料、何时收火，让鱼与汤彼此成全，是看似安静、其实很见耐心的手艺。

**涴水的故事在碗边停一停**

冉遗之鱼来自《西山经》的涴水，形貌奇特，却与古人安眠避凶的愿望相连。它在小馆把故乡的水声讲得很慢，等故事说完，汤也正好到了可以安心入口的温度。

**用一碗熟悉的温度走近异兽**

即使名字陌生，端碗时的暖意也无需解释。先让味道把距离拉近，再听鱼身、蛇首、六足的故事，奇异就不再只有令人发怵的一面。

**Ranyiyu’s Clear Fish Soup**

Ranyiyu fish soup is a delicate broth named for the strange fish of mountain waters and the chef’s fondness for soups.

**Depth in a clear bowl**

A fish soup need not be heavy to have flavour. Care with the ingredients and the heat lets the fish and broth support one another. A clear-looking bowl can carry plenty of patient work.

**A river story beside the bowl**

The Ranyiyu of the Western Mountains belongs to unusual river lore and old hopes for reassurance. Its cook tells the story slowly, giving both guest and soup a little time to settle.

**Warmth before explanation**

A guest may not know how to pronounce Ranyiyu, but a warm bowl needs little translation. Familiar comfort makes room for the creature’s unfamiliar appearance and the story behind it.

### 穷奇麻辣火锅 · Qióng qí má là huǒ guō

穷奇麻辣火锅是一道以花椒和辣椒风味为主的热锅，适合喜欢鲜明滋味的客人。

**“麻”和“辣”不是同一种感觉**

今天熟悉的麻辣，常把花椒的微麻与辣椒的热烈放在一起。两种感觉相互推动，却并非越强越有滋味；好锅底还要让香气、咸鲜和食材有处说话。

**烈性子也学着照顾人**

穷奇喜欢看客人吃得精神起来，却慢慢明白，不能把自己的痛快当作所有人的标准。有人喜欢热烈，有人只愿尝一点；一锅饭能容得下这些不同，才算真的有本事。

**用滋味来聊“分寸”**

说一句“我吃不了这么辣”，并不是扫兴，而是告诉同桌怎样一起吃得舒服。第一次认识麻辣，也可以从少量尝起，慢慢分辨那份香、麻与热。

**Qiongqi’s Mala Hot Pot**

Qiongqi’s spicy hotpot is a bold dish built around the tingling warmth of Sichuan pepper and chilli.

**Ma and la are different**

In mala, ma names the tingling sensation associated with huajiao, while la points to chilli heat. Neither alone tells the whole flavour story: aroma, savouriness and the ingredients still need room.

**A bold cook learning care**

Qiongqi enjoys a lively response to its cooking, but is learning that its own tolerance is not everyone’s measure. Making room for several preferences is becoming part of its pride.

**Finding a comfortable measure**

Saying a dish is too hot is useful information for a shared meal. A small first taste can make mala easier to explore, giving its separate sensations time to become recognisable.

### 梼杌秘制烤肉 · Táo wù mì zhì kǎo ròu

梼杌秘制烤肉是一道烤肉料理，倔强的梼杌把对火候与调味的坚持留在了招牌里。

**“秘制”里，常有普通的功夫**

腌味、添火、翻面，许多招牌烤物的差别，都藏在这些反复练熟的步骤里。秘制可以是一份自家的配料，也可以是厨师只肯在最合适的时刻动那一下手。

**固执，也能守住一种好味道**

梼杌最听不得“差不多就行”。这脾气有时让伙伴头疼，有时却让一盘烤肉值得等待。掌柜学着提醒它照顾出菜的节奏，它也学着把坚持用在客人真正能尝到的地方。

**每家店，都有自己的那一点**

“本店招牌”“house special”，都在说一间厨房如何留下自己的性格。尝这道菜时，不妨把秘方先放一边，留意厨师到底在坚持哪一种口感。

**Taowu’s House Barbecue**

Taowu’s special barbecue is a grilled dish whose stubborn namesake brings its persistence to seasoning and fire.

**The ordinary work behind a secret**

Marinating, tending the heat and turning at the right moment give a house roast its character. A secret may be a seasoning blend, but it may also be a habit patiently practised.

**Stubbornness with a useful place**

“That will do” is not Taowu’s favourite phrase. Its exacting habits can frustrate the kitchen, yet also make a dish worth waiting for. Cook and companions are learning where persistence helps the whole meal.

**What makes a house special**

A house special tells something about a kitchen’s character. The interesting question is not always what ingredient is hidden, but what particular texture or flavour the cook is determined to keep.

### 混沌云吞 · Hùn dùn yún tūn

混沌云吞是一碗薄皮包馅的汤食，借“混沌”与“馄饨”的近音，把神话名字变成餐桌上的巧趣。

**薄皮包住的许多叫法**

馄饨、云吞、抄手，都是认识这一类包馅面食时常会遇到的名字，各地的皮、馅、汤与吃法又有变化。它们彼此有亲近之处，也值得分开细尝。

**给还没定形的世界包个馅**

混沌爱听人把“混沌”与“馄饨”念在一起。它觉得一张软皮慢慢合拢，像一团还未分明的世界终于藏好一点秘密。等汤面浮起，秘密便成了一口鲜香。

**双关，需要有人搭一座桥**

英文wonton保留了粤语云吞的声音，却不会自动带出“混沌”的近音趣味。多讲这一句，远来的客人便不只知道在吃什么，也能和同桌一起笑出声。

**Hundun’s Cloud Wontons**

Hundun wontons are filled dumplings in broth. Their name plays on the similar sounds of hundun, the mythic being, and huntun, wontons.

**A family of names**

Huntun, yuntun and chaoshou are names you may meet around these filled-wrapper foods. Regional textures, fillings, broths and ways of serving offer both family resemblances and differences worth noticing.

**A little world inside a wrapper**

Hundun enjoys hearing its name beside huntun. Folding a soft wrapper feels like giving an unfinished little world somewhere to keep a secret. Once the bowl is served, that secret becomes a savoury mouthful.

**Helping a wordplay travel**

English wonton carries the sound of a Cantonese name, but does not automatically reveal the resemblance between Hundun and huntun. A little explanation lets a newcomer share the joke as well as the food.

### 獬豸正义套餐 · Xiè zhì zhèng yì tào cān

獬豸正义套餐是一份搭配均衡的组合餐，以獬豸辨曲直的故事寄托公平待客的心意。

**一套饭，也是在安排照顾**

套餐把几样菜提前配好，方便客人少一点犹豫，也让一餐有相互衬托的滋味。安排得好，不是每样都放一点便算齐全，而是主食、菜肴与汤饮合起来恰好舒适。

**把公平放进待客的小事**

獬豸关心的不只是争执时的道理，也是一开始有没有说清价钱、记住约定、照顾等待的人。它为这份套餐取的名字很郑重，做起来却全是日常里可看见的小事。

**同样认真，不必一模一样**

有人吃得少，有人有忌口，有人需要多一点解释。公平的招待可以给这些差异留位置；把每个人都当回事，比把每张盘子摆得完全相同更重要。

**Xiezhi’s Fair-Table Set**

Xiezhi’s Fairness Set is a balanced meal inspired by the creature’s association with impartial judgment and attentive hospitality.

**Care in an arranged meal**

A set meal makes choices easier while bringing different dishes into balance. Its success lies not in adding a little of everything, but in making the whole meal feel considered and comfortable.

**Fairness before a dispute**

Xiezhi notices clear prices, remembered promises and attention to someone still waiting. The name sounds grand, but much of its meaning is made in small, visible acts before anything goes wrong.

**Equal care can look different**

A guest may need a smaller portion, a dietary adjustment, or more explanation. Giving such differences room is part of fair hospitality. The same seriousness of care need not produce identical plates.

### 烛龙火焰拉面 · Zhú lóng huǒ yàn lā miàn

烛龙火焰拉面是一碗汤面，以烛龙掌昼夜的神话与醒目的火焰意象为灵感。

**一根面条，可以走很远**

“拉面”会让不同地方的人想起不同的面馆：有人先想到手工拉伸的面条，有人先想到日本的ramen。面食在交流中生长出许多样子，面条、汤底与配料也各自留着地方的性格。

**借一双眼，把夜点亮**

烛龙的故事以明暗与昼夜动人，小馆便借那份光亮，为这碗面取了“火焰”的名字。丹木果的山海香气绕着碗沿，让一顿夜食像缩小了的日出。

**先尝味道，再追问来路**

一碗面可以从熟悉的吃法开始，又把人带到新的汤味与故事里。远来的客人不必先选边站，慢慢尝，也慢慢认识各处的不同，就已经是一段很好的旅行。

**Zhulong’s Flame Noodles**

Zhulong’s flame ramen is a noodle soup inspired by the dragon of day and night and the warmth of a bright flame.

**A noodle with many journeys**

Lamian may first suggest hand-pulled noodles; ramen may suggest a Japanese noodle shop. Related food words have travelled and changed. Broth, texture and toppings give each bowl a local character of its own.

**A little light for the night**

Zhulong’s turning of light and darkness inspires the bowl’s flame-bright name. An imagined danmu-fruit note belongs to the inn’s mountain pantry. A late meal becomes a very small sunrise.

**Taste first, then follow the story**

A familiar noodle form can open onto an unfamiliar broth and a new tale. There is no need to choose one tradition against another. Taking time with their differences can be its own small journey.

### 帝江无面饺子 · Dì jiāng wú miàn jiǎo zi

帝江无面饺子是一盘圆润的饺子，借帝江“无面目”的形象玩了一个温和的名字游戏。

**包住馅，也包住相聚**

饺子有煮、蒸、煎等多种吃法，不同地方也有不同的皮馅与形状。许多人记住它，不只因为味道，还因为围着案板包一会儿、等热锅开一会儿的共同时间。

**没有五官，也有表情**

帝江没有面目却懂歌舞，这盘小点也借了它那份不靠眉眼表达的趣味。饺子摆得有一点跳跃的节奏，仿佛下一瞬就要跟着托盘上的步子轻轻挪开。

**“无面”的小小双关**

中文里的“面”既能让人想到脸，也可能让人想到面粉与面食。这里说的是没有面目般的造型；知道这层字趣，再看一盘软软的饺子，便更容易会心一笑。

> 是識歌舞實惟帝江也
> ——《山海经》
> It knows song and dance: this is Dijiang.

**Dijiang’s Faceless Dumplings**

Dijiang’s faceless dumplings are rounded dumplings named with a gentle nod to the creature’s faceless appearance.

**A filling and a little company**

Dumplings may be boiled, steamed or pan-fried, with regional shapes and fillings. Their appeal often includes the time around the worktable: folding together, waiting together, then eating something hot.

**Expression without a face**

Dijiang understands song and dance without having a face. These little dumplings borrow that playful thought, arranged as though they might move with the rhythm of the tray carrying them.

**A small joke in mian**

Mian can refer to a face, but also to flour and noodle foods. Here “faceless” describes the playful shape. Explaining that little overlap gives a newcomer access to the humour behind the name.

### 九婴九味拼盘 · Jiǔ yīng jiǔ wèi pīn pán

九婴九味拼盘把多种口味放在一盘，借九婴多首的形象，为多人同桌增添选择。

**“九”也可以说丰盛**

中文里的数字有时不只负责计数，也能添出丰富、长久与热闹的意味。“九味”在这盘菜里先是一份邀请：不必急着给每种滋味排次序，试一试，再说说最喜欢哪一种。

**把水火的脾气调到一起**

九婴的旧故事带着水与火的猛烈，小馆却让它把不同火候、不同口感放到同一盘里。几处灶台一起忙，伙伴互相报着时，最后端出的热闹，得靠大家共同照看。

**口味不同，正好有话可聊**

拼盘很适合把“我喜欢这个”说给同桌听。有人爱脆，有人爱软，差异不必马上分出高下；互相递一筷子推荐，文化交流也能从这样小的一口开始。

**Jiuying’s Nine-Flavour Platter**

Jiuying’s nine-flavour platter brings different tastes together, echoing the many-headed creature and giving a group choices to share.

**Nine as an invitation**

Numbers in Chinese can carry associations as well as counts. Here, “nine flavours” suggests abundance and variety. It invites guests to explore the plate before deciding which taste they like best.

**Bringing different tempers together**

Jiuying’s older stories join water and fire. At the inn, that force becomes a chance to coordinate different cooking methods and textures. The lively result depends on several helpers listening to one another.

**Difference gives a table something to say**

A shared platter makes it easy to recommend a favourite. Crisp or soft, gentle or bold: the differences need not become a ranking. A small offered taste can start a generous conversation.

### 白泽万象宴 · Bái zé wàn xiàng yàn

白泽万象宴是食肆的一道隐藏宴席，以博识的白泽为引，把不同山海风味汇成一桌。

**一席饭，也能收藏见闻**

宴席常把滋味、次序与人情安排在一起。古人以饮食相会，酒食之外还有问候、礼让与谈话；白泽的“万象”，正想把这份能够容纳许多人和故事的气度留下来。

**一道菜，接着一位伙伴**

有山野草木的清气，有灶边守候的热香，也有伙伴们反复试过的小心思。白泽愿意说清每一道从哪里得到启发，却不会替客人规定该先喜欢哪一种。

**让不同的故事互相款待**

宴席最动人的地方，不是每个人吃同一种东西，而是许多来处的人愿意一起坐下。听到陌生的名字，可以问一句；尝到熟悉的味道，也可以把自己的故事说出来。

> 夫礼之初，始诸饮食。
> ——《礼记正义》
> At the beginning of ritual, there was food and drink.

**Baize’s Banquet of Many Wonders**

Baize’s myriad banquet is a hidden feast that gathers many mountain-and-sea flavours around the knowledgeable guide Baize.

**A meal that can hold many stories**

A banquet arranges flavours, timing and company together. Beyond the dishes are greetings, conversation and ways of making room for others. Baize’s “many wonders” begins with that generous idea of a table.

**One dish, then another companion**

There is the brightness of mountain greens, the warmth of a watched stove, and the care of dishes tried again and again. Baize shares what inspired each part while leaving the guest free to choose a favourite.

**Stories offering hospitality to stories**

A shared banquet need not make everyone the same. An unfamiliar name invites a question; a familiar flavour can invite a memory. The meal grows richer when guests bring their own stories into it.

### 凤凰涅槃羹·真 · Fèng huáng niè pán gēng · zhēn

凤凰涅槃羹·真是食肆中的隐藏羹品，沿着凤凰的意象，将重逢与重新出发的心意再添一笔。

**有些味道，靠经历才记住**

一道菜可能因为节日、重逢，或某段不容易的日子，变得与平时不同。凤凰涅槃羹的这一碗，记住的便是伙伴之间的守望；食材的温热之外，还多了一层被故事照亮的滋味。

**把重新出发，煮给彼此**

凤凰曾带来安宁的好消息，小馆则把这份好意递给身边的人。羹仍要认真煮，碗仍要稳稳端；所谓重新振作，有时就是有人还愿意同你把这些小事再做一遍。

**“真”字里的一点真切**

这个字让人想到真心、真切与终于做到的承诺。它标记的是小馆的一段纪念，而不是一份更古老的秘方；把这一点讲给远方来客听，名字便有了可以共同感受的温度。

**Fenghuang’s Renewal Broth: A Shared Promise**

True Phoenix Rebirth Geng is a hidden soup that returns to the phoenix motif with a wish for reunion and renewal.

**A flavour remembered through experience**

A meal can change through a reunion, a celebration, or a hard stretch of life. This version of the renewal broth remembers the companions who kept watch for one another. Experience adds something an ingredient list cannot describe.

**Beginning again, together**

The wish for peace becomes a kindness offered nearby. The broth still needs tending and the bowl still needs carrying. Sometimes renewal is simply having someone willing to do these ordinary things with you once more.

**The warmth of zhen**

Zhen can suggest sincerity, something felt as real, or a promise fulfilled. Here it marks a shared memory at the inn. Explaining that feeling lets the title carry warmth beyond a literal translation.

## 来客小传

### 饕客·老饕 · Lǎo tāo

饕客·老饕是一位隐居的美食评论家。来到食肆后，他会点价格最高的菜，并给出一次评价。

**懂吃，也懂得等**

“老饕”可以是对懂吃、爱吃之人的趣称，语气里常带一点欣赏与自嘲。饮食随笔爱写这样的食客：既记得远方的珍馐，也会为眼前一碗认真做好的饭停下筷子。

**一句好吃，背后有许多次相逢**

他吃饭不急，常问这道菜是谁做的、为何这样调味。若真觉得好，夸奖也很具体。厨房里的人后来发现，被他说中自己最费心的那一点，比一句笼统称赞更让人高兴。

**先听对方怎样品尝**

不同地方的人描述滋味，未必用同一套词。向一位有经验的食客学习，也可以从听他怎么说开始，再把自己的感受放进去，慢慢找到能互相理解的说法。

**Laotao, the Seasoned Diner**

Laotao is a reclusive food critic. When he visits, he orders the most expensive dish and gives one evaluation.

**A fond name for a serious eater**

Laotao can be an affectionate name for an experienced lover of food. It leaves room for humour as well as admiration: someone who remembers a splendid feast may still be delighted by a carefully made ordinary bowl.

**A precise compliment**

He asks who cooked a dish and why a flavour was chosen. When he praises it, he names the detail. The cooks find that having their particular care noticed means more than a grand but general compliment.

**Learning another way to taste**

Descriptions of flavour vary between people and places. Listening to how someone tastes—and adding your own experience—can create shared words without requiring identical preferences.

### 白泽的故人 · Báizé de gùrén

白泽的故人是一位认得白泽的仙家来客。这位故人会点一杯茶饮，聊起这位导师不为新伙伴熟悉的往事。

**一盏饮，留出说话的时间**

在许多待客场景里，先递上一杯饮品，是把忙碌暂且放下的信号。茶、汤饮或清水，各有习惯，共同的是一句无声的邀请：请坐一会儿，我们可以慢慢谈。

**旧识带来的另一面**

在新伙伴眼里，白泽似乎总是无所不知；故人却记得它也有初学、犹疑与走错路的时候。几句旧事说开，那位可靠的导师便多了一点可以亲近的温度。

**给陌生人留一句解释**

老朋友之间的暗号，旁人未必听得懂。愿意停下来解释一句，让新来的伙伴也能笑进故事里，旧交情便不再是一扇关上的门，而成了欢迎更多人的座位。

**An Old Friend of Baize**

An old acquaintance of Baize visits for a tea drink and shares memories of the mentor’s earlier days.

**A drink makes time**

Offering a guest something to drink can create a pause before conversation. Tea, a warm infusion or plain water may carry different customs, while sharing a simple invitation to sit and take a little time.

**Another side of a wise companion**

Newcomers may see Baize as someone who always knows. An old friend remembers the uncertain beginnings and mistaken turns as well. Those memories make the dependable teacher feel a little closer.

**Let a newcomer into the story**

Old friends share references a newcomer cannot know. Taking time to explain one makes the memory more generous, turning an inside joke into a place where another person can join.

### 小神兽 · Xiǎo shénshòu

小神兽是走失的幼崽，初到食肆会点一份基础菜；吃饱之后，它还需要一个安心的归处。

**看见陌生的小小来客**

山海故事里有许多难以叫出名字的生命。对一个幼小、走失的来客而言，被看见不一定要先被认全：有人愿意让它坐下，便已经是走进世界的一点安全感。

**先吃饱，再慢慢找路**

它对基本的饭食格外认真，一口口吃得很慢。伙伴们有人替它添水，有人留意门外，谁也没有因为它的模样不熟悉，就把这份照顾推给别人。

**好客也包括不知如何开口的人**

有些客人不懂语言，有些太紧张，有些还没学会把需要讲清楚。愿意先观察、少催促，让照顾发生在问答之前，往往就是最容易被感受到的善意。

**The Lost Little Beast**

The little creature is a lost cub who orders a basic dish on arrival and needs a safe place after the meal.

**A welcome before a name**

Books of wonders hold many unfamiliar beings. A lost young visitor need not be perfectly identified before it can be welcomed. A seat and a kind response can be a beginning.

**Food first, then the way home**

The cub eats slowly and carefully. One helper brings water; another watches the doorway. Its unfamiliar appearance does not stop the companions from sharing the work of looking after it.

**Care before fluent words**

A guest may not share a language, may feel nervous, or may not yet know how to ask. Watching patiently and offering practical care can make kindness understandable before a conversation begins.

### 挑剔的美食家 · Tiāoti de měishíjiā

挑剔的美食家是一位严格的美食博主。这位博主会连续品尝三道菜，逐一给出评价。

**把一顿饭讲给没来过的人**

食评与饮食随笔，都要把舌尖的经验转成别人能想象的文字。写香、写脆、写余味，也写等候与招待；一道菜怎样被讲述，常影响下一位客人带着怎样的期待进门。

**挑剔，也要说得有用**

这位食评人会分清是口味不合，还是火候出了问题；也愿意追问厨师原本想做出什么感觉。并非每句批评都舒服，但说清理由，便给双方都留下了再理解一次的机会。

**自己的口味，不是所有人的标准**

写给远方读者时，尤其需要说明地方习惯与个人偏好。把“我不熟悉”写清楚，而不急着写成“不好吃”，能让评价更诚实，也给不同文化的食物留出呼吸。

> 物有本性，不可穿凿为之。
> ——《随园食单》
> Things have their own nature; do not force them into something else.

**The Exacting Food Writer**

The discerning food blogger is a demanding critic who orders three dishes and evaluates them one by one.

**Describing a meal to someone absent**

Food writing turns a taste into words another person can imagine. Aroma, texture and service all contribute. The way a meal is described helps shape what a future guest expects to find.

**Making criticism useful**

She distinguishes a personal dislike from a cooking problem, and asks what the cook intended. Criticism need not feel pleasant to be useful; reasons and specifics make room for another understanding.

**Preference is not a universal measure**

Writing across cultures calls for care with local habits and personal taste. Naming unfamiliarity honestly, instead of treating it as failure, gives another cuisine room to be understood.

### 报恩的妖怪 · Bào’ēn de yāoguài

报恩的妖怪是一位记住善意的来客。它再次来到食肆，用一份谢礼表达感激。

**好意会有回声**

民间故事常让受过帮助的鸟兽回来报恩，把人与异类之间的距离拉近。故事动人的地方不只在礼物有多重，还在于一件看似细小的善意，竟被另一位生命认真记住。

**再坐回那张桌子**

它特意选了原先坐过的位置，问候今天值班的每一位伙伴。忙过一阵后，掌柜才发现桌上多了一份心意；比礼物更早留下的，是它说话时终于放松的神情。

**感谢可以有很多种说法**

有人当面道谢，有人留下小礼，有人日后再来帮忙。理解不同的表达，不急着把好意算成一次交换，便能让一段接待长成更长久的来往。

**The Grateful Visitor**

The grateful creature is a visitor who remembers being comforted and returns to express thanks with a gift.

**Kindness with an echo**

Many tales let a helped bird or beast return with gratitude. The moving part is not always a valuable gift, but the thought that another life has carefully remembered a small act of kindness.

**Returning to a familiar seat**

The visitor chooses its old place and greets the helpers. Only later does the innkeeper notice what it has left behind. Its relaxed expression had already offered another sign of what the earlier welcome meant.

**Many ways to say thank you**

Gratitude may arrive as words, a small gift, or help offered another day. Recognising different expressions without reducing them to a transaction can let one welcome grow into an ongoing relationship.

### 昆仑集团密探 · Kūnlún jítuán mìtàn

昆仑集团密探假扮食客来到店里，暗中观察经营；细心的伙伴可能识破他的真实身份。

**老地名，遇见新招牌**

昆仑在中国神话里是引人遐想的神圣山岳，这里的集团则把它用作自己的名号。一个古老名字走入现代商业故事，既借来了气势，也让人好奇：招牌背后，到底站着怎样的人？

**守住的，是伙伴的安心**

面对不太寻常的打探，獬豸会问清缘由，伙伴们也更留意彼此的约定。照常待客，并不妨碍他们把重要的事情说清、把应当守护的信任放稳。

**别把陌生，都叫作危险**

这段相遇的关键在具体行为，不在客人来自何方。愿意先核实、再判断，才能同时保留欢迎新朋友的门，也照顾好已经一起做事的人。

**The Visitor from Kunlun Group**

The Kunlun Group spy visits disguised as a diner and quietly observes the business; an attentive teammate may see through the disguise.

**An old name on a modern sign**

Kunlun carries the grandeur of a mythic mountain. The company using its name belongs to the inn’s contemporary story. A familiar cultural name can lend a sign prestige, while leaving questions about the people behind it.

**Protecting a place of trust**

Unusual questions lead the companions to pay closer attention to their promises and responsibilities. They can remain courteous while taking care of the trust that makes the inn a comfortable place to work.

**Judge actions, not unfamiliarity**

What matters in this encounter is behaviour, not where a guest comes from. Asking and checking carefully can keep a door open to new friends while protecting the people already sharing the work.
