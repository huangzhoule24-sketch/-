extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
const Assets=preload("res://scripts/services/asset_catalog.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,text: String):
	checks+=1
	if not ok:failures+=1;push_error(text)
func settle():
	for frame in range(8):await process_frame
func find(node: Node,id: String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children(true):
		var match_node=find(child,id)
		if match_node!=null:return match_node
	return null
func run():
	root.size=Vector2i(1440,900);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	# Dedicated custom root keeps all test images out of the packaged project.
	var custom="/tmp/shanhai-v193-ui-"+str(Time.get_ticks_usec());ui.assets=Assets.new(custom+"/empty-builtin",custom);ui.map_view.assets=ui.assets
	var rng=ui.model._rng.state
	for dimensions in [Vector2i(1440,900),Vector2i(844,390)]:
		root.size=dimensions;ui.update_ui_layout();ui.refresh();await settle()
		var map=ui.map_view.house();var point=ui.map_view.cell_rect(8,2).get_center()
		if dimensions.x==844:expect(map.scale_factor()>=.55,"Phone uses a readable fixed map scale with vertical panning")
		expect(map.linear_scale().x==map.linear_scale().y,"Top-down map preserves equal X/Y floor scale")
		expect(ui.map_view.cell_at(map.to_view(point))==Vector2i(8,2),"Ground cell click uses the same projection as visible equipment")
		expect(find(ui,"scene:up")==null and find(ui,"scene:zoom_in")==null,"Camera uses direct dragging without pan buttons")
		for id in ["scene:overview","scene:left","scene:right","scene:up","scene:down"]:expect(find(ui,id)==null,"No camera button needed "+id)
	ui.close_panel(false);ui.model.full_rules.revision19.spawn("cash",10);await settle()
	var pickup=ui.model.state.revision18.pickups.back();var overlay=ui.map_view.get_node_or_null("PickupOverlay")
	if overlay==null:
		for child in ui.map_view.get_children():
			if child.get_script()!=null and child.get_script().resource_path.ends_with("pickup_overlay.gd"):overlay=child;break
	var hidden_point=ui.map_view.house().to_world(Vector2(120,30));pickup.x=hidden_point.x;pickup.y=hidden_point.y;overlay._process(0)
	expect(not overlay.buttons[int(pickup.id)].visible,"Camera toolbar never exposes an intercepted pickup target")
	var visible_point=ui.map_view.house().to_world(Vector2(120,100));pickup.x=visible_point.x;pickup.y=visible_point.y;overlay._process(0)
	expect(overlay.buttons[int(pickup.id)].visible,"Pickup target becomes available inside the safe scene area")
	# The visual placement check must not leave synthetic coordinates in later state assertions.
	ui.model.state.revision18.pickups.clear();overlay._process(0);rng=ui.model._rng.state
	ui.open_panel("员工");await settle();var id=str(ui.model.employees[0].id)
	expect(find(ui,"employee:portrait:"+id)!=null,"Employee list has a portrait thumbnail")
	ui.revision_ui.employee_id=id;ui.open_panel("员工详情");await settle();var portrait=find(ui,"employee:portrait:"+id)
	expect(portrait!=null and ui.assets.is_placeholder(ui.assets.get_portrait(id)),"Employee detail uses the grey missing-portrait state")
	portrait.pressed.emit();await settle();var popup=ui.get_node_or_null("EmployeePortrait")
	expect(popup!=null and popup.visible,"Clicking employee photo opens a centered enlargement")
	if popup!=null:popup.hide();await settle()
	expect(ui.get_node_or_null("EmployeePortrait")==null,"Photo enlargement closes and releases its popup")
	var image=Image.create(8,8,false,Image.FORMAT_RGBA8);image.fill(Color.GREEN)
	expect(ui.assets.import_image(image.save_png_to_buffer(),"Portraits/"+id+".png").ok,"Dedicated portrait imports without touching the scene sprite")
	ui.open_panel("员工详情");await settle();portrait=find(ui,"employee:portrait:"+id)
	expect(not ui.assets.is_placeholder(portrait.assets.get_portrait(id)),"Employee photo reads the actual imported portrait")
	ui.close_panel(false);ui.tutorial_overlay.restart_tutorial();await settle()
	var guide=ui.tutorial_overlay
	expect(guide.portrait_frame.visible and guide.portrait_frame.character_id=="bai_ze","Mandatory welcome displays the configured Baize portrait placeholder")
	ui.model.state.tutorial.completed_steps=["welcome","staff","promotion"];guide.poll(0);await settle()
	expect(guide.current_step().id=="first_order" and not guide.portrait_frame.visible,"Pure observation tutorial deliberately hides the portrait")
	ui.model.state.tutorial.completed_steps=["welcome","staff","promotion","first_order","income","bill"];guide.poll(0);ui.open_panel("美术资源");await settle()
	var slots=preload("res://scripts/ui/art_targets.gd").slots(ui.model)
	expect(ui._art_culture_slots.item_count==82+slots.size(),"Developer picker includes every legacy slot and the complete new resource matrix")
	var wanted="Sprites/tao_tie/cook_up_0.png";var selected=-1
	for i in ui._art_culture_slots.item_count:
		if str(ui._art_culture_slots.get_item_metadata(i))==wanted:selected=i;break
	expect(selected>0,"Taotie Cook up frame has an explicit import target")
	ui._art_culture_slots.select(selected);ui._art_culture_slots.item_selected.emit(selected)
	expect(ui._import_path.text==wanted,"Selecting a directional frame writes its exact developer path")
	expect(ui.model._rng.state==rng,"Opening photos, inspecting the map and importing images do not consume business RNG")
	ui.queue_free();await settle();print("V1.9.3 UI: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
