extends SceneTree
const Audio = preload("res://scripts/services/audio_system.gd")
const Bridge = preload("res://scripts/services/game_audio_bridge.gd")
const Model = preload("res://scripts/core/game_model.gd")
const Harness = preload("res://tests/ui_requirements_tests.gd").Harness
const Recorder = preload("res://tests/audio_tests.gd").Recorder
var checks = 0
var failures = 0
func _init(): call_deferred("run")
func expect(ok: bool, message: String):
	checks += 1
	if not ok: failures += 1; push_error(message)
func settle():
	for i in range(5): await process_frame
func run():
	var audio = Audio.new("res://assets/audio","user://free-sfx-no-overrides-%d" % OS.get_process_id(),"user://free-sfx-settings-%d.cfg" % OS.get_process_id())
	root.add_child(audio); await settle()
	audio.set_muted(false); audio.set_level("master",.8); audio.set_level("sfx",.75)
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://docs/free-sfx/selection.json"))
	var sources: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://docs/free-sfx/sources.json"))
	expect(manifest.files.size()==42,"All 42 selected files are present")
	for entry in manifest.files:
		var path = "res://assets/audio/"+str(entry.output)
		var stream = load(path) as AudioStream
		expect(stream != null and stream.get_length()>.02 and stream.get_length()<60,"Godot decodes actual shipped file: "+path)
		expect(str(entry.source.sha256).length()==64 and int(entry.source.http_status)==200,"Each source has actual download/hash evidence")
		expect(sources.sources[entry.pack].license in ["CC0-1.0","CC-BY-4.0"],"Every selected file has redistribution terms")
	var loaded = 0
	for cue in audio.config.cues:
		if str(cue).begins_with("music."):
			expect(audio.cue_stream(cue)==null,"Music remains unpopulated: "+cue)
			continue
		loaded += 1
		expect(audio.cue_stream(cue,str(cue).begins_with("ambience.")) != null,"Every sound-effect cue resolves: "+cue)
	expect(loaded==30 and audio.last_errors.is_empty(),"30 non-music cues load without errors")
	var first = audio.cue_stream("move.walk"); var second = audio.cue_stream("move.walk")
	expect(first is AudioStreamWAV and second is AudioStreamWAV and first.data!=second.data,"Walking uses distinct takes without campaign RNG")
	audio.set_world_paused(false); audio.set_ambience("ambience.dining"); await create_timer(.1).timeout
	expect(audio._ambient[int(audio._active.ambience)].playing,"Bundled restaurant loop actually starts")
	audio.set_world_paused(true)
	expect(audio._ambient[int(audio._active.ambience)].stream_paused,"Bundled ambience pauses with gameplay")
	# Isolated observer fixtures verify result/review detection, never campaign completion.
	var model=Model.new(20261027);model.start_full();model.set_paused(false)
	var rec=Recorder.new();rec.config=audio.config.duplicate(true);var bridge=Bridge.new(rec)
	bridge.update(.3,model,{},"");rec.calls.clear()
	model.state.expansion.competition.last_result={"id":"test-result","won":true}
	bridge.update(.3,model,{},"")
	expect(rec.calls==["event.success"],"A newly completed winning contest triggers success once")
	rec.calls.clear();bridge.update(.3,model,{},"")
	expect(rec.calls.is_empty(),"Opening/refreshing result never replays its sound")
	model.state.expansion.competition.last_result={"id":"test-loss","won":false}
	bridge.update(.3,model,{},"")
	expect(rec.calls==["event.failure"],"A new non-winning result triggers the quieter failure cue")
	rec.calls.clear();model.state.customer_service.today.bad_reviews+=1
	bridge.update(.3,model,{},"")
	expect(rec.calls==["guest.unhappy"],"Only an actual new negative review triggers dissatisfaction")
	rec.calls.clear();model.state.customer_service.today.good_reviews+=1;model.state.served=5
	bridge.update(.3,model,{},"")
	expect(rec.calls==["guest.happy"],"A fifth sale with a new positive review uses one positive cue")
	rec.calls.clear();model.state.customer_service.today.day+=1;model.state.customer_service.today.good_reviews=0;model.state.customer_service.today.bad_reviews=0
	bridge.update(.3,model,{},"")
	expect(rec.calls.is_empty(),"Day reset does not fabricate guest feedback")
	var fresh_bridge=Bridge.new(rec);fresh_bridge.update(.3,model,{},"")
	expect(rec.calls.is_empty(),"Loading a save never replays old contest/review sounds")
	var before=JSON.stringify(model.state);var rng=model._rng.state
	fresh_bridge.update(.3,model,{"bi_fang":{"action":"Move"}},"")
	expect(before==JSON.stringify(model.state) and rng==model._rng.state,"Sound observation leaves simulation and RNG unchanged")
	var ui=Harness.new();root.add_child(ui);await settle();ui.setup_audio()
	ui.audio.settings_path="user://free-sfx-ui-%d.cfg" % OS.get_process_id()
	ui.audio.custom_root="user://free-sfx-ui-custom-%d" % OS.get_process_id()
	ui.audio.set_muted(false);ui.audio.set_level("master",.8);ui.audio.set_level("sfx",.75)
	var pickup=preload("res://scripts/ui/pickup_overlay.gd").new();pickup.setup(ui);ui.map_view.add_child(pickup)
	ui.model.state.revision18.pickups=[{"id":1001,"kind":"gems","amount":1,"x":500.0,"y":500.0,"remaining":15.0}]
	pickup.collect(1001)
	expect(ui.model.state.revision18.pickups.is_empty() and int(ui.audio.played.get("event.pickup",0))==1,"Real successful pickup action uses the common sound service")
	ui.audio._clock+=1;ui.audio.set_muted(true)
	ui.model.state.revision18.pickups=[{"id":1002,"kind":"cash","amount":10,"x":500.0,"y":500.0,"remaining":15.0}]
	pickup.collect(1002)
	expect(ui.model.state.revision18.pickups.is_empty() and int(ui.audio.played.get("event.pickup",0))==1,"Muted pickup still collects but never bypasses the master mute")
	ui.audio.set_muted(false);ui.queue_free();audio.queue_free();await settle();await create_timer(.15).timeout
	var report={"checks":checks,"failures":failures,"files":42,"ready_cues":30,"fixture_results_not_natural_campaign":true}
	FileAccess.open("res://build/free-sfx/tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Free sound effects: ",JSON.stringify(report));quit(1 if failures else 0)
