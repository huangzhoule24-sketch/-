extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,label: String):
	checks+=1
	if not ok:failures+=1;push_error(label)
func settle():
	for i in range(8):await process_frame
func find(node: Node,id: String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children(true):
		var match_node=find(child,id)
		if match_node!=null:return match_node
	return null
func run():
	root.size=Vector2i(1440,900);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	expect(ui.map_view.is_dollhouse() and not ui.sidebar.visible,"Full campaign uses a full-width front cutaway")
	var camera=ui.map_view.house();var random=ui.model._rng.state
	for dimensions in [Vector2i(1440,900),Vector2i(844,390)]:
		root.size=dimensions;ui.update_ui_layout();ui.refresh();await settle()
		for id in ["scene:up","scene:down","scene:overview","scene:left","scene:right"]:
			expect(find(ui,id)==null,"Direct camera dragging replaces scene control "+id)
		var center=ui.map_view.cell_rect(11,0).get_center()
		camera.set_zoom(2) # Exercise inverse projection at a nondefault internal scale, without exposing free zoom.
		camera.pan(120);await settle()
		expect(camera.zoom>1 and camera.camera.x>=0,"Camera zoom and pan change only projection")
		expect(ui.map_view.cell_at(ui.map_view._to_view(center))==Vector2i(11,0),"Projection inverse keeps placement aligned after camera changes")
		camera.set_zoom(1);await settle()
		expect(camera.zoom==1 and camera.camera==Vector2.ZERO and ui.bottom_ui.first.get_global_rect().end.x<=ui.size.x,"Overview restores camera while preserving top HUD")
	expect(ui.model._rng.state==random,"Camera and cutaway drawing never consume gameplay random sequence")
	root.size=Vector2i(1440,900);ui.update_ui_layout();ui.model.state.stage=1;ui.model.state.cash=10000;ui.open_panel("装修");await settle()
	find(ui,"place:stove").pressed.emit();await settle()
	expect(ui.map_view.placement_id=="stove" and not is_instance_valid(ui._requirement_dialog),"Equipment preview precedes builder assignment")
	var location=Vector2i(-1,-1)
	for y in range(5):
		for x in range(16):
			if ui.model.can_place_decoration("stove",x,y):location=Vector2i(x,y);break
		if location.x>=0:break
	expect(location.x>=0,"Real equipment preview has a reachable build location")
	var cash=ui.model.state.cash;ui.place_decoration("stove",location.x,location.y);await settle()
	expect(is_instance_valid(ui._builder_dialog) and ui.model.state.cash==cash,"Confirming a location prompts assignment before spending")
	var selection=find(ui,"decor:assign_employee");selection.select(1);find(ui,"decor:assign").pressed.emit();await settle()
	expect(ui.model.state.revision171.builds.size()==1 and ui.model.state.cash==cash-600,"Assigning a real employee books the specified stove cost")
	expect(ui.model.full_rules.dollhouse.fixtures("stove").size()==2,"Construction preview cannot provide premature capacity")
	ui.finish_decoration(true);await settle()
	expect(ui.model.state.revision171.builds[0].active and ui.model.employees.any(func(e):return e.get("motion",{}).get("action")=="Build"),"Committed builder physically walks to the construction site")
	ui.open_panel("美术资源");await settle();expect(ui._art_culture_slots.item_count>=82+preload("res://scripts/ui/art_targets.gd").slots(ui.model).size(),"All culture, guest, pickup and12cutaway asset selectors exist")
	ui.queue_free();await settle();print("V1.9.1 UI: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
