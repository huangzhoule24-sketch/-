extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
const Space=preload("res://scripts/services/restaurant_space.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func settle():
	for i in range(6):await process_frame
func run():
	var ui=Harness.new();root.add_child(ui);await settle();ui.close_panel(false);await settle()
	var view=ui.map_view;var house=view.house();var before=JSON.stringify(ui.model.state);var rng=ui.model._rng.state
	var press=InputEventMouseButton.new();press.button_index=MOUSE_BUTTON_LEFT;press.pressed=true;press.position=Vector2(350,200)
	view._gui_input(press)
	var motion=InputEventMouseMotion.new();motion.position=Vector2(400,230);motion.relative=Vector2(50,30);view._gui_input(motion)
	var release=InputEventMouseButton.new();release.button_index=MOUSE_BUTTON_LEFT;release.position=motion.position;view._gui_input(release)
	expect(house.camera.length()>10,"Plain left mouse drag pans the scene")
	var camera=house.camera;motion.relative=Vector2(20,10);view._gui_input(motion)
	expect(house.camera==camera and not house.pointer_down,"Released pointer does not keep dragging")
	expect(before==JSON.stringify(ui.model.state) and rng==ui.model._rng.state,"Dragging changes neither business state nor RNG")
	var chairs=house.draw_entities().filter(func(e):return e.type=="chair")
	expect(chairs.any(func(c):return c.direction=="left") and chairs.any(func(c):return c.direction=="right"),"Paired chairs face one another")
	var cell=Space.cell_rect(ui.model,1,1);expect(Space.table_extent(cell).x>=72,"Tabletop is wide enough for two distinct places")
	var thoughts=view.thoughts
	var customer={"id":900,"seat":0,"stage":"eating","arrival_minute":int(ui.model.state.total_minutes),"dish_id":"noodles"}
	ui.model.customers.append(customer)
	var texts={}
	for i in range(12):texts[thoughts.guest_message(customer)]=true
	expect(texts.size()>=8,"Eating guests have at least eight different lines")
	thoughts.bubbles.clear();thoughts.clock=10;thoughts.speak_waiting_guest()
	expect(thoughts.bubbles.is_empty(),"Guests do not speak immediately on arrival")
	thoughts.clock=20;thoughts.speak_waiting_guest();expect(thoughts.bubbles.size()==1,"Guest speech becomes available after the quiet interval")
	thoughts.clock=38;thoughts.speak_waiting_guest();expect(thoughts.bubbles.size()==1,"Same guest cannot repeat within sixty real seconds")
	thoughts.place()
	for b in thoughts.bubbles:
		if b.node.visible:
			for rect in thoughts.body_rectangles():expect(not b.node.get_rect().intersects(rect),"Visible bubble never overlaps an actor body or nameplate")
	ui.queue_free();await settle()
	var report={"checks":checks,"failures":failures}
	FileAccess.open("res://build/pixel-interaction-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Pixel interaction: ",JSON.stringify(report));quit(1 if failures else 0)
