extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const View=preload("res://scripts/ui/restaurant_view.gd")
const Grid=preload("res://scripts/services/dollhouse_navigation.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func run():
	var m=Model.new(191020);m.start_full();m.events.clear();m.state.stage=4;m.state.cash=100000;m.balance["customer.base_flow"]=60;m.employees.clear()
	for definition in m.catalog.slice(0,20):m.employees.append(m._create_employee(definition))
	for cell in [Vector2i(4,1),Vector2i(8,1),Vector2i(4,3),Vector2i(8,3)]:m.state.layout.append({"id":"table_four","x":cell.x,"y":cell.y,"w":1,"h":1})
	m.state.seats=24
	for item in [{"id":"stove","x":13,"y":0,"w":1,"h":1},{"id":"stove","x":11,"y":2,"w":1,"h":1},{"id":"serving_counter","x":14,"y":2,"w":1,"h":1},{"id":"cashier","x":15,"y":1,"w":1,"h":1}]:m.state.layout.append(item)
	m.full_rules.ensure_state_defaults();m.full_rules.management.purchase("generic",10000);m.full_rules.revision18.apply_state("rush_hour")
	var started=Time.get_ticks_msec();var peak_guests=0;var exclusive=true
	for minute in range(120):
		m.advance_minutes(1);peak_guests=maxi(peak_guests,m.customers.size());var used: Array=[]
		for customer in m.customers:
			var id=str(customer.get("device_uid",""))
			if id.is_empty():continue
			if id in used:exclusive=false
			used.append(id)
	var elapsed_ms=Time.get_ticks_msec()-started
	expect(peak_guests>=20 and m.employees.size()==20,"High-flow fixture actually reaches20 guests and20 employees")
	expect(exclusive and int(m.state.served)>0,"Crowded service still completes real sales without duplicate equipment locks")
	var view=View.new();view.model=m;view.font=ThemeDB.fallback_font;view.size=Vector2(1400,600);root.add_child(view);view.set_process(false)
	var searches=Grid.searches;var rng=m._rng.state
	for frame in range(120):view._update_employee_animation(.016)
	expect(Grid.searches==searches and m._rng.state==rng,"120 observer frames do not replan grid routes or consume business randomness")
	var path="/tmp/shanhai-v191-stress.json";var restored=Model.new(2);restored.start_full();restored.events.clear()
	expect(m.save_game(path) and restored.load_game(path),"Crowded orders and equipment reservations pass strict save/load")
	print("STRESS_METRICS ",JSON.stringify({"employees":m.employees.size(),"peak_guests":peak_guests,"served":m.state.served,"game_minutes":120,"elapsed_ms":elapsed_ms,"grid_searches":Grid.searches}))
	DirAccess.remove_absolute(path);view.queue_free();await process_frame
	print("V1.9.1 stress: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
