extends RefCounted
var host
var employee_id=""
var report_open=false
var feedback: Dictionary={}
var pulse=0.0
func _init(ui) -> void:host=ui
func m():return host.model
func rules():return m().full_rules.revision
func body(title: String,detail: String="") -> VBoxContainer:return host.full_panels._body(title,detail)
func text(parent: Node,value: String,color: Color=Color("718078")) -> void:host.full_panels._text(parent,value,color)
func action(parent: Node,label: String,kind: String,args: Dictionary={},destination: String="",primary: bool=false) -> void:
	parent.add_child(host.button(label,func():
		var outcome: Dictionary=m().full_rules.perform(kind,args)
		if not outcome.get("ok",false):host.show_requirement(str(outcome.get("reason","操作条件不足")));return
		m().autosave_requested.emit()
		if not destination.is_empty():host.open_panel(destination)
		else:host.close_panel(),primary,("employee:restore_shift:"+str(args.get("id",""))) if label=="恢复全天排班" else "revision:"+kind+":"+str(args.get("id",args.get("serial","")))))
func render(name: String) -> bool:
	match name:
		"员工详情":employee_detail()
		"经营状态":status_panel();host.bottom_ui.status_extras()
		"现场来客":live_guests()
		"来客往事":guest_history()
		"今日收支结算":daily_report()
		"现金流预警":warning()
		"破产救援":rescue()
		"经营失败":failure()
		"事件结果":event_feedback()
		"特殊顾客图鉴":guest_catalog()
		_:return false
	return true
func forced_panel() -> String:
	if not m().state.has("rescue171"):return ""
	var rescue_state: Dictionary=m().state.rescue171
	if rescue_state.ended:return "" if rescue_state.menu else "经营失败"
	if bool(m().state.finance.rescue.pending):return "破产救援"
	if rescue_state.warning_pending:return "现金流预警"
	if m().full_rules.world.has_notice():return "事件"
	if (bool(rules().s().daily_auto) or bool(rules().s().get("daily_pending",false)) or report_open) and int(m().state.finance.last_bill_day)>int(rules().s().daily_seen):return "今日收支结算"
	return ""
func poll(delta: float) -> void:
	pulse+=delta
	if not m().state.has("revision171"):return
	var required=forced_panel()
	if not required.is_empty() and host.panel_name!=required:host.open_panel(required)
	if host.money_label!=null:
		host.money_label.modulate.a=0.7+0.3*absf(sin(pulse*4)) if float(m().state.cash)<m().full_rules.rescue.fixed_cost() else 1.0
func refresh_header() -> void:
	if host.live_status==null or not m().state.has("revision171"):return
	var training: Array[String]=[];var building: Array[String]=[];var low: Array[String]=[]
	for employee in m().employees:
		var status: String=rules().status(employee)
		if status.begins_with("培训") or status.begins_with("研发"):training.append(str(employee.name)+" "+status)
		if status.begins_with("装修"):building.append(str(employee.name)+" "+status)
		if float(employee.stamina)<=20 or float(employee.mood)<=30:low.append(str(employee.name))
	var guests: Array=m().customers.filter(func(c):return c.has("visitor_id"))
	host.guest_status.text="来客×%d" % guests.size()
	host.guest_status.add_theme_color_override("font_color",Color("bc8d31") if not guests.is_empty() else host.MUTED)
	host.guest_status.tooltip_text="特殊顾客到访：点击定位" if not guests.is_empty() else "当前没有特殊顾客"
	var preview: Dictionary=m().full_rules.finance.preview_bill()
	var danger=float(m().state.cash)<m().full_rules.rescue.fixed_cost()
	var next=int(m().state.stage)+1
	var badge=""
	if next<=4 and int(m().state.reputation)>=int(m().balance.get("stage.%d.reputation" % next,0)):
		badge=" · 可升级" if float(m().state.total_revenue)>=float(m().balance.get("stage.%d.revenue" % next,0)) else " · 声望达标"
	host.live_status.text=("现金流告急 | " if danger else "")+"培训/研发×%d · 装修×%d · 状态预警×%d%s | 食材%.1f / 新鲜%d%% · 预计工资￥%.0f" % [training.size(),building.size(),low.size(),badge,float(m().state.ingredients),int(m().state.freshness),float(preview.get("wages_due",0))]
	host.live_status.tooltip_text="\n".join(training+building+low)+"\n点击查看剩余工期、债务与全部人员状态。"
	host.money_label.add_theme_color_override("font_color",Color("b14e40") if danger else host.INK)
	host.debt_label.add_theme_color_override("font_color",Color("b14e40") if float(m().state.cash)<float(preview.get("minimum_due",0)) else host.MUTED)
	host.training_status.text="培训×%d" % training.size()
	host.building_status.text="装修×%d" % building.size()
	for pair in [[host.training_status,training],[host.building_status,building]]:pair[0].tooltip_text="\n".join(pair[1])
	var active=m().employees.filter(func(e):return int(e.get("management_until",0))>int(m().state.total_minutes))
	host.training_status.icon=host.assets.get_texture("FX/icon_training") if not active.is_empty() and host.assets.has_image("FX/icon_training") else host.assets.get_texture("Characters/"+str(active[0].id)+"_idle") if not active.is_empty() else null
	host.building_status.icon=host.assets.get_texture("Characters/"+str(m().state.revision171.builds[0].employee_id)+"_idle") if not m().state.revision171.builds.is_empty() else null
func staff_controls(parent: Node,employee: Dictionary) -> void:
	if m().state.has("revision191"):
		var d=m().full_rules.dollhouse;var names: Array[String]=[]
		for pair in [["chef","灶台"],["waiter","传菜口、餐桌、基础收银"],["salesman","收银、宣传"]]:
			if d.capable(employee,str(pair[0])):names.append(str(pair[1]))
		text(parent,"可操作设备："+" / ".join(names))
	var id=str(employee.id)
	var quote: Dictionary=rules().dismissal_quote(id)
	text(parent,"Lv.%d / %d · %s" % [int(employee.get("level",1)),rules().level_cap(employee),rules().status(employee)])
	var flow=host.full_panels._flow(parent)
	flow.add_child(host.button("排班 / 详情",func():employee_id=id;host.open_panel("员工详情"),false,"employee:detail:"+id))
	flow.add_child(host.button("培训",func():employee_id=id;host.open_panel("员工培养"),true,"employee:training:"+id))
	var fire=host.button("解雇 ￥%.0f" % float(quote.get("cost",0)) if id!="bai_ze" else "白泽不可解雇",func():confirm_dismiss(id),false,"employee:dismiss:"+id)
	fire.add_theme_color_override("font_color",Color("ae5146"));flow.add_child(fire)
	var panel=parent.get_parent()
	panel.mouse_filter=Control.MOUSE_FILTER_STOP
	panel.gui_input.connect(func(event):
		if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:employee_id=id;host.open_panel("员工详情"))
func employee_detail() -> void:
	var employee: Dictionary=m()._employee(employee_id)
	if employee.is_empty():text(host.modal_body,"请选择一位在职员工。");return
	var parent=body(str(employee.name),rules().status(employee))
	host.full_panels._identity(parent,employee)
	text(parent,"等级%d/%d · 体力%d · 心情%d · 忠诚%d · 日工资￥%.2f" % [int(employee.level),rules().level_cap(employee),int(employee.stamina),int(employee.mood),int(employee.loyalty),m().employee_wage(employee)])
	var flow=host.full_panels._flow(parent)
	flow.add_child(host.button("培训",func():host.open_panel("员工培养"),true,"employee:training:"+employee_id))
	flow.add_child(host.button("解雇",func():confirm_dismiss(employee_id),false,"employee:dismiss:"+employee_id))
	flow.add_child(host.button("休息" if not employee.resting else "恢复当班",func():
		if int(employee.get("management_until",0))>int(m().state.total_minutes) or rules().is_building(employee_id):host.show_requirement("培训、研发或装修期间不可重新排班");return
		m().set_employee_rest(employee_id,not employee.resting);host.open_panel("员工详情"),false,"employee:rest:"+employee_id))
	text(parent,"主职业："+host.role_name(str(employee.primary_role))+" · 副职业："+(host.role_name(str(employee.secondary_role)) if not str(employee.secondary_role).is_empty() else "尚未培训"))
	if not str(employee.secondary_role).is_empty():action(parent,"设为主职业："+host.role_name(str(employee.secondary_role)),"switch_role",{"id":employee_id,"role":str(employee.secondary_role)},"员工详情")
	text(parent,"主副职业共同决定可操作设备；培训新职业请点培训。")
	text(parent,"在下列营业时段安排此员工：")
	var periods: Array=employee.get("shift_periods",host.full_panels.PERIODS.keys()).duplicate()
	var shifts=host.full_panels._flow(parent)
	for key in host.full_panels.PERIODS:
		var period=str(key);var box=CheckBox.new();box.text=str(host.full_panels.PERIODS[key]);box.custom_minimum_size.y=44;box.button_pressed=period in periods
		box.add_theme_color_override("font_color",host.INK)
		for color_key in ["font_pressed_color","font_hover_color","font_hover_pressed_color","font_focus_color"]:box.add_theme_color_override(color_key,host.INK)
		box.set_meta("qa_id","shift:"+employee_id+":"+period)
		box.toggled.connect(func(on):
			if on and not period in periods:periods.append(period)
			elif not on:periods.erase(period))
		shifts.add_child(box)
	action(shifts,"保存排班","set_shift",{"id":employee_id,"periods":periods,"enabled":true},"员工详情",true)
	action(shifts,"恢复全天排班","set_shift",{"id":employee_id,"periods":host.full_panels.PERIODS.keys(),"enabled":true},"员工详情")
	text(parent,"相生相克与岗位冲突请查看排班关系。")
	parent.add_child(host.button("查看相生相克",func():host.open_panel("相生相克"),false,"employee:synergy"))
func confirm_dismiss(id: String) -> void:
	var quote: Dictionary=rules().dismissal_quote(id)
	if not quote.ok:host.show_requirement(str(quote.reason));return
	var e: Dictionary=m()._employee(id)
	host.confirm_action("确认解雇 "+str(e.name),"等级%d×50 + 训练属性点%d×10 + 忠诚%.0f×5 + 遣散费100\n合计支付￥%.2f。员工离场，图鉴和支线记录保留。\n以上为本游戏规则。" % [int(quote.level),int(quote.points),float(quote.loyalty),float(quote.cost)],func():
		var outcome: Dictionary=m().full_rules.perform("dismiss_employee",{"id":id})
		if not outcome.ok:host.show_requirement(str(outcome.reason));return
		m().autosave_requested.emit();host.open_panel("员工"),"dismiss:confirm")
func builder_picker() -> void:
	var parent=body("指派装修负责人","必须为当班且空闲的员工；闭店0:00–6:00暂停装修，其他时段按游戏分钟推进。完工前不增加座位或经营效果。")
	var select=OptionButton.new();select.custom_minimum_size=Vector2(230,44);select.add_item("请选择装修负责人");select.set_meta("qa_id","decor:builder")
	var ids=[""]
	for e in m().employees:
		if not rules().builder_available(e):continue
		ids.append(str(e.id));select.add_item(str(e.name)+" · "+str(e.rarity))
		if str(e.id)==host.decoration_session.builder_id:select.selected=ids.size()-1
	select.item_selected.connect(func(index):host.decoration_session.builder_id=ids[index]);parent.add_child(select)
	for job in rules().s().builds:text(parent,"%s · %s · %d/%d分钟%s" % [str(m().full_rules.decoration(str(job.id)).name),str(m()._employee(str(job.employee_id)).get("name",job.employee_id)),int(job.duration)-int(job.remaining),int(job.duration),"（待确认开工）" if not job.active else ""])
func status_panel() -> void:
	var parent=body("实时经营状态",host.live_status.text)
	var preview: Dictionary=m().full_rules.finance.preview_bill()
	for pair in [["wages_due","预计工资"],["rent_due","预计房租"],["utilities_due","预计水电"],["interest_due","原债利息"],["minimum_due","最低还本"],["loan_interest_due","常规贷款利息"]]:text(parent,"%s ￥%.2f" % [pair[1],float(preview.get(pair[0],0))])
	text(parent,"原债本金￥%.2f · 工资/房租欠款￥%.2f · 紧急贷款本金￥%.2f" % [float(m().state.debt),float(m().state.wage_arrears)+float(m().state.rent_arrears),float(m().state.rescue171.loan.principal)])
	for e in m().employees:text(parent,str(e.name)+" · "+rules().status(e)+" · 体力%d/心情%d" % [int(e.stamina),int(e.mood)])
	parent.add_child(host.button("前往员工",func():host.open_panel("员工"),false,"status:employees"))
func daily_report() -> void:
	report_open=true
	var seen=int(rules().s().daily_seen)
	var bills: Array=m().state.finance.bills.filter(func(bill):return int(bill.day)>seen)
	if bills.is_empty():bills=m().state.finance.bills.slice(-1)
	for bill in bills:
		var parent=body("第%d日 · 今日收支结算" % int(bill.day),"期初现金￥%.2f → 期末现金￥%.2f" % [float(bill.opening_cash),float(bill.closing_cash)])
		host.bottom_ui.bill(parent,bill)
	var option=CheckBox.new();option.text="以后不再自动弹出（仍可在系统→账单查看）";option.button_pressed=not bool(rules().s().daily_auto);option.custom_minimum_size.y=44;option.add_theme_color_override("font_color",host.INK)
	option.toggled.connect(func(on):m().full_rules.perform("daily_auto",{"enabled":not on}));host.modal_body.add_child(option)
	host.modal_body.add_child(host.button("确认，继续经营",func():m().full_rules.perform("daily_ack");report_open=false;host.close_panel();m().set_paused(false);m().autosave_requested.emit(),true,"daily:ack"))
func warning() -> void:
	text(host.modal_body,"白泽：现金连续下降，已不足预计固定支出￥%.2f。" % m().full_rules.rescue.fixed_cost(),Color("b25343"))
	text(host.modal_body,"请优先备齐基础食材、安排厨师和服务员，暂缓装修与高成本培养。紧急救援本局仅一次，5000元、日息2%、20日到期；再次破产将结束经营。")
	action(host.modal_body,"知道了，调整经营","warning_ack",{},"",true)
func rescue() -> void:
	text(host.modal_body,str(m().state.finance.rescue.reason),Color("b25343"))
	text(host.modal_body,"最后一次自救：紧急贷款5000元，日息2%，20游戏日到期；逾期声望−50并罚款400元。本局仅可使用1次，救援失败或再次破产将强制结束。常规贷款禁贷不影响此次救援。")
	host.modal_body.add_child(host.button("接受紧急救援（先确认代价）",func():host.confirm_action("紧急救援代价确认","此救援贷款利率2%/天，20日到期，逾期声望−50、罚款400元。\n本局仅此一次；若再次破产，将直接结束游戏。",func():
		m().full_rules.perform("emergency_accept",{"confirmed":true});host.open_panel("经营失败" if m().state.rescue171.ended else "今日收支结算" if int(m().state.finance.last_bill_day)>int(rules().s().daily_seen) else "经营状态"),"rescue:confirm"),true,"rescue:accept"))
	action(host.modal_body,"放弃救援，结束经营","rescue_decline",{},"经营失败")
func failure() -> void:
	var final: Dictionary=m().state.rescue171.final
	text(host.modal_body,"经营失败 · "+str(final.get("reason","")),Color("b25343"))
	text(host.modal_body,"累计营业额￥%.2f · 最高声望%d · 已收集员工%d位 · 经营%d天" % [float(final.get("revenue",0)),int(final.get("peak_reputation",0)),int(final.get("collected",0)),int(final.get("days",0))])
	text(host.modal_body,"重开保留永久图鉴、成就、特殊顾客见闻、山海志与白泽支线，重置本局资金、研发和雇佣。")
	host.modal_body.add_child(host.button("重新开局",func():m().restart_campaign_with_keepsakes();host.close_panel(false);m().set_paused(false),true,"failure:restart"))
	host.modal_body.add_child(host.button("返回主菜单",func():m().state.rescue171.menu=true;m().autosave_requested.emit();host.open_panel("欢迎"),false,"failure:menu"))
func event_feedback() -> void:
	var parent=body(str(feedback.get("title","事件结果")),"已执行："+str(feedback.get("label","")))
	for change in feedback.get("changes",[]):text(parent,"%s %.2f → %.2f（%+.2f）" % [str(change.label),float(change.before),float(change.after),float(change.delta)],Color("427b6c") if float(change.delta)>0 else Color("b25343"))
	for line in feedback.get("details",[]):text(parent,str(line))
	host.modal_body.add_child(host.button("确认结果",func():feedback={};host.close_panel(),true,"event:result:ack"))
func guest_catalog() -> void:
	var data: Dictionary=m().state.special_visitors
	text(host.modal_body,"已遇见%d/6 · %s" % [data.records.size(),"山海来客全收集成就已解锁（无数值奖励）" if data.achievement else "亲自接待后揭示身份与反馈"])
	host.modal_body.add_child(host.button("回看全部接待与互动记录",func():host.open_panel("来客往事"),false,"guest:history"))
	for guest in m().full_rules.visitors.definitions():
		var record: Dictionary=data.records.get(str(guest.id),{})
		var new_entry=not record.is_empty() and not host.action_notifications._state().read.has("guest_entry:"+str(guest.id))
		var parent=body((str(guest.name)+(" · 新" if new_entry else "")) if not record.is_empty() else "？？？",str(guest.identity) if not record.is_empty() else "尚未遇见的特殊顾客")
		if new_entry:host.action_notifications.read_entry("guest_entry:"+str(guest.id))
		if record.is_empty():text(parent,"剪影 · 图片待补充");continue
		parent.add_child(host.button("来客小传 / Story",func():host.open_culture("guests",str(guest.id)),false,"culture:guests:"+str(guest.id)))
		var portrait_id=str(preload("res://scripts/ui/art_targets.gd").GUEST_IDS.get(str(guest.id),str(guest.id)))
		var art="Portraits/"+portrait_id if host.assets.has_image("Portraits/"+portrait_id) else "Characters/guest_"+str(guest.id)+"_lore"
		if host.assets.has_image(art):
			var picture=TextureRect.new();picture.texture=host.assets.get_texture(art);picture.custom_minimum_size=Vector2(132,132);picture.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;picture.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED;parent.add_child(picture)
		else:text(parent,"图像待补充")
		text(parent,"出现条件："+str(guest.condition));text(parent,"到店行为："+str(guest.behavior));text(parent,"遇见%d次 · 最佳结果：%s" % [int(record.met),str(record.best)])
		for entry in data.history.filter(func(entry):return str(entry.id)==str(guest.id)).slice(-8):text(parent,("前局接待 · " if int(entry.minute)==0 else "第%d天 · " % (int(entry.minute)/1440+1))+str(entry.text))
		if str(guest.id)=="lost_cub":
			for entry in data.adoptions:
				if not entry.claimed:action(parent,"收养幼崽 · 领取神兽线索碎片×1","guest_adopt",{"serial":int(entry.serial)},"图鉴")

func live_guests() -> void:
	var guests: Array=m().customers.filter(func(c):return c.has("visitor_id"))
	if guests.is_empty():text(host.modal_body,"当前没有特殊顾客到访。")
	for guest in guests:
		var definition: Dictionary=m().full_rules.visitors.definition(str(guest.visitor_id))
		var parent=body(str(definition.name),str(definition.behavior))
		text(parent,"位置：第%d号座位 · 正在%s" % [int(guest.seat)+1,str({"ordering":"点单","queued":"等餐","cooking":"制作","serving":"上菜","eating":"用餐","paying":"结账","cleaning":"离席"}.get(str(guest.stage),guest.stage))])
		parent.add_child(host.button("定位这位顾客",func():locate_guest(int(guest.id)),true,"guest:locate:"+str(guest.id)))
	host.modal_body.add_child(host.button("查看特殊顾客图鉴",func():host.full_panels.catalog_tab="特殊顾客";host.open_panel("图鉴"),false,"guest:catalog"))
func locate_guest(id: int) -> void:
	var guest: Dictionary=m()._customer(id)
	if guest.is_empty():host.show_requirement("这位顾客已经离店，可以在图鉴回看结果。");return
	host.close_panel()
	var marker=Label.new()
	marker.text="▼ 特殊顾客"
	marker.add_theme_color_override("font_color",Color("b18425"))
	marker.add_theme_font_size_override("font_size",14)
	marker.mouse_filter=Control.MOUSE_FILTER_IGNORE
	host.map_view.add_child(marker)
	marker.position=host.map_view._to_view(host.map_view._seat_position(int(guest.seat)))+Vector2(-45,-64)
	var tween=host.create_tween()
	tween.tween_property(marker,"modulate:a",0.2,0.6)
	tween.tween_property(marker,"modulate:a",1.0,0.6)
	tween.tween_interval(4.0)
	tween.tween_callback(marker.queue_free)

func guest_history() -> void:
	var parent=body("接待记录","保留最近120次特殊接待结果与40次实际互动；图鉴永久保留遇见次数和最佳结果。")
	for entry in m().state.special_visitors.history.duplicate().slice(-120):
		var definition: Dictionary=m().full_rules.visitors.definition(str(entry.id))
		text(parent,str(definition.name)+" · "+str(entry.text))
	var dialogue=body("店员与顾客的互动")
	for entry in m().state.special_visitors.interactions:
		text(dialogue,"顾客%d · %s / %s" % [int(entry.customer_id),str(entry.text),str(entry.response)])
