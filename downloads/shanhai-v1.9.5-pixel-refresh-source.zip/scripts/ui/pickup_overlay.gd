extends Control
## Real pointer targets, outside navigation occupancy. All rewards use model actions.
var host
var buttons: Dictionary={}
var pulse=0.0
func setup(ui):host=ui;mouse_filter=Control.MOUSE_FILTER_IGNORE;z_index=30
func _ready():
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _process(delta):
	if host==null or not host.model.state.has("revision18"):return
	visible=str(host.panel_name).is_empty()
	pulse+=delta;var active: Array=[]
	for pickup in host.model.state.revision18.pickups:
		var id=int(pickup.id);active.append(id)
		if not buttons.has(id):
			var button=host.button("",func():collect(id),false,"pickup:"+str(id));button.custom_minimum_size=Vector2(44,44);button.size=Vector2(44,44)
			button.add_theme_font_size_override("font_size",12);button.focus_mode=Control.FOCUS_NONE;add_child(button);buttons[id]=button
		var b=buttons[id];var gem=str(pickup.kind)=="gems"
		var amount=host.model.full_rules.revision19.reward(pickup)
		b.text=("灵" if gem else "￥")+str(amount).trim_suffix(".0");b.tooltip_text="点击手动拾取，剩%.1f真实秒" % float(pickup.remaining)
		var point=host.map_view._to_view(Vector2(float(pickup.x),float(pickup.y)))
		var top=52.0 if host.map_view.is_dollhouse() else 0.0
		var safe_area=Rect2(Vector2(22,top+22),Vector2(maxf(0,size.x-44),maxf(0,size.y-top-44)))
		b.visible=host.map_view.get_rect().size.x>=0 and safe_area.has_point(point)
		b.position=Vector2(clampf(point.x-22,0,maxf(0,size.x-44)),clampf(point.y-22,0,maxf(0,size.y-44)))
		var style=host.style(Color("a38cce") if gem else Color("e0ba69"),18,Color.WHITE);style.content_margin_left=0;style.content_margin_right=0;style.content_margin_top=0;style.content_margin_bottom=0;b.add_theme_stylebox_override("normal",style)
		var key="UI/pickup_gem" if gem else "UI/pickup_cash"
		if host.assets.has_image(key):b.icon=host.assets.get_texture(key);b.expand_icon=true;b.add_theme_constant_override("icon_max_width",26)
		b.modulate.a=0.65+0.35*absf(sin(pulse*(5 if gem else 2))) if gem or float(pickup.remaining)<4 else 1.0
	for id in buttons.keys():
		if not id in active:buttons[id].queue_free();buttons.erase(id)
	queue_redraw()
func collect(id: int):
	var result=host.model.full_rules.perform("pickup_collect",{"id":id})
	if result.ok and "audio" in host and host.audio != null: host.audio.play_cue("event.pickup")
func _draw():
	for id in buttons:
		var b=buttons[id]
		if not b.visible:continue
		if b.text.begins_with("灵"):
			var center=b.position+Vector2(22,22)
			for i in range(5):
				var angle=pulse*2+i*TAU/5;var point=center+Vector2(cos(angle),sin(angle))*27
				draw_line(point-Vector2(3,0),point+Vector2(3,0),Color("b7a2dc"),2);draw_line(point-Vector2(0,3),point+Vector2(0,3),Color("b7a2dc"),2)
