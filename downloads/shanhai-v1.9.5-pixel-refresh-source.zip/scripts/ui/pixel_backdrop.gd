extends Control
## Low-contrast pixel tile background for the complete game canvas.
func _ready():
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _draw():
	draw_rect(Rect2(Vector2.ZERO,size),Color("c7c9a8"))
	for y in range(0,int(size.y),24):
		for x in range(0,int(size.x),24):
			var odd=(x/24+y/24)%2
			draw_rect(Rect2(x,y,24,24),Color("c3c5a3") if odd else Color("ccceb0"))
			draw_rect(Rect2(x+4,y+4,2,2),Color("babc9c"))
	for y in range(0,int(size.y),96):draw_rect(Rect2(0,y,size.x,2),Color("b3b795"))
