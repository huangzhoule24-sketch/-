extends RefCounted
## Observe the model and the renderer's real actions; no timers/values are fed back.
const Motion = preload("res://scripts/services/art_motion.gd")
var audio
var _last: Dictionary = {}
var _customers: Dictionary = {}
var _next_scan = 0.0
var _clock = 0.0
var _last_panel = ""
var _event_key = ""

func _init(service): audio = service

func update(delta: float, model, actors: Dictionary, panel: String):
	_clock += maxf(0, delta)
	var minute = int(model.state.get("total_minutes", 0))
	var current = {"minute":minute, "served":int(model.state.get("served",0)), "stage":int(model.state.get("stage",0)), "employees":model.employees.size(), "recipes":model.state.get("unlocked_dishes",[]).size(), "bill":int(model.state.get("finance",{}).get("last_bill_day",0))}
	var reviews: Dictionary = model.state.get("customer_service",{}).get("today",{})
	current.review_day = int(reviews.get("day",-1))
	current.good = int(reviews.get("good_reviews",0)); current.bad = int(reviews.get("bad_reviews",0))
	var contest: Dictionary = model.state.get("expansion",{}).get("competition",{}).get("last_result",{})
	var festival: Dictionary = model.state.get("world",{}).get("festival",{}).get("last_result",{})
	current.contest = JSON.stringify(contest); current.festival = JSON.stringify(festival)
	var fresh = _last.is_empty() or minute < int(_last.minute) or current.served < int(_last.served)
	var context: Dictionary = audio.config.get("contexts",{})
	var period = model.period()
	var night = period in ["closed", "rest", "night_market"]
	audio.set_music(str(context.get(panel, "music.night" if night else "music.day")))
	audio.set_ambience("" if panel == "欢迎" else "ambience.night" if night else "ambience.dining")
	audio.set_world_paused(model.paused or panel == "欢迎")
	if panel != _last_panel:
		audio.stop_preview()
		if panel == "事件":
			var pending: Dictionary = model.pending_event()
			var key = str(pending.get("id","")) + ":" + str(pending.get("serial",pending.get("queued_minute",0)))
			if not pending.is_empty() and key != _event_key: audio.play_cue("event.random"); _event_key = key
	_last_panel = panel
	if not fresh:
		# Important feedback wins over routine coins when several changes arrive together.
		var feedback: Array = []
		if current.stage > _last.stage: feedback.append("event.stage")
		if current.contest != _last.contest and not contest.is_empty(): feedback.append("event.success" if bool(contest.get("won",false)) else "event.failure")
		if current.festival != _last.festival and not festival.is_empty(): feedback.append("event.success" if bool(festival.get("won",false)) else "event.failure")
		if current.bill > _last.bill: feedback.append("event.settlement")
		if current.employees > _last.employees: feedback.append("event.recruit")
		if current.recipes > _last.recipes: feedback.append("event.research")
		if not audio.world_paused:
			if current.review_day == _last.review_day and current.bad > _last.bad: feedback.append("guest.unhappy")
			if current.review_day == _last.review_day and current.good > _last.good and (current.served == _last.served or current.served % 5 == 0): feedback.append("guest.happy")
			if current.served > _last.served: feedback.append("event.checkout")
		for cue in feedback:
			if audio.play_cue(str(cue), str(cue) in ["event.checkout","guest.happy","guest.unhappy"]): break
	_last = current
	if fresh: _customers.clear()
	if _clock < _next_scan: return
	_next_scan = _clock + .2
	var present: Dictionary = {}
	for guest in model.customers:
		var id = str(guest.id); var stage = str(guest.get("stage", ""))
		var motion: Dictionary = guest.get("checkout_motion", guest.get("arrival_motion", {}))
		var walking = not motion.is_empty() and float(minute)+model._fraction < float(motion.get("started",0))+float(motion.get("travel_minutes",0))
		var seated = not walking and stage in ["ordering","queued","cooking","serving","eating"]
		present[id] = seated
		if not fresh and not audio.world_paused:
			if not _customers.has(id) and not str(guest.get("visitor_id", "")).is_empty(): audio.play_cue("guest.special", true)
			if seated and not bool(_customers.get(id,false)): audio.play_cue("guest.sit", true)
			if seated and stage == "eating": audio.play_cue("guest.eat", true)
	_customers = present
	if fresh or audio.world_paused: return
	# Round-robin staff order avoids one employee taking the entire world budget.
	var ids = actors.keys()
	if ids.is_empty(): return
	var start = int(_clock * 5) % ids.size()
	for i in range(ids.size()):
		var id = str(ids[(start+i)%ids.size()]); var actor: Dictionary = actors[id]
		var action = str(actor.get("action", "Idle"))
		var cue = "move." + Motion.kind(id) if action in ["Move","Walk"] else str(audio.config.get("actions",{}).get(action,""))
		if not cue.is_empty(): audio.play_cue(cue, true)
