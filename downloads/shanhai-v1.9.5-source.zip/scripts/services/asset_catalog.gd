class_name AssetCatalog
extends RefCounted
## The only image loading boundary. Custom files are decoded as pixels, never resources/scripts.

signal changed

const CATEGORIES := ["Portraits", "Sprites", "UI", "Map", "Items", "FX", "Backgrounds", "Characters", "Dishes"]
const Identity=preload("res://scripts/services/employee_identity.gd")
const EXTENSIONS := ["png", "jpg", "jpeg"]
const MAX_FILE_BYTES := 32 * 1024 * 1024
const MAX_IMAGE_DIMENSION := 8192
const MAX_IMAGE_PIXELS := 32 * 1024 * 1024
const DEFAULT_BUILTIN_ROOT := "res://assets/art"

var developer_mode := false
var poll_interval := 1.0
var builtin_root: String
var custom_root: String
var last_errors: Array[String] = []
var _builtin_entries: Dictionary = {}
var _custom_entries: Dictionary = {}
var _aliases: Dictionary = {}
var _cache: Dictionary = {}
var _decoded: Dictionary = {}
var _frame_cache: Dictionary = {}
var _snapshot: Dictionary = {}
var _poll_elapsed := 0.0
var _placeholder: Texture2D


func _init(builtin_directory: String = DEFAULT_BUILTIN_ROOT, custom_directory: String = "") -> void:
	builtin_root = builtin_directory.trim_suffix("/")
	custom_root = custom_directory.trim_suffix("/") if not custom_directory.is_empty() else default_custom_root()
	_placeholder = _make_placeholder()
	reload()


static func default_custom_root() -> String:
	if OS.has_feature("web"):
		return "user://CustomAssets"
	if OS.has_feature("editor"):
		return "res://CustomAssets"
	return OS.get_executable_path().get_base_dir().path_join("CustomAssets")


func reload() -> void:
	last_errors.clear()
	_builtin_entries = _scan_images(builtin_root)
	_custom_entries = _scan_images(custom_root)
	_aliases.clear()
	_read_manifest(builtin_root)
	_read_manifest(custom_root)
	_cache.clear()
	_decoded.clear()
	_frame_cache.clear()
	_snapshot = _take_snapshot()
	_poll_elapsed = 0.0
	changed.emit()


func poll(delta: float) -> void:
	if not developer_mode:
		return
	_poll_elapsed += maxf(delta, 0.0)
	if _poll_elapsed < maxf(poll_interval, 0.1):
		return
	_poll_elapsed = 0.0
	if _take_snapshot() != _snapshot:
		reload()


func get_texture(resource_id: String) -> Texture2D:
	var canonical := _resolve_id(resource_id)
	if canonical.is_empty():
		return _placeholder
	if _cache.has(canonical):
		return _cache[canonical]
	var texture := _texture_or_null(canonical)
	_cache[canonical] = texture if texture != null else _placeholder
	return _cache[canonical]


func culture_resource_id(kind: String, entry_id: String) -> String:
	# Lore pictures have their own slot; replacing one never changes a worker sprite or menu icon.
	if not _is_identifier(entry_id):
		return ""
	match kind:
		"employee", "employees":
			return "Characters/%s_lore" % entry_id
		"dish", "dishes":
			return "Dishes/%s_lore" % entry_id
	return ""


func culture_texture(kind: String, entry_id: String) -> Texture2D:
	var resource_id := culture_resource_id(kind, entry_id)
	if resource_id.is_empty():
		return _placeholder
	var dedicated := _texture_or_null(resource_id)
	if dedicated != null:
		return dedicated
	if kind in ["employee", "employees"]:
		for texture in get_frames(entry_id, "idle"):
			if not is_placeholder(texture):
				return texture
		var portrait := _texture_or_null("Characters/" + entry_id)
		return portrait if portrait != null else _placeholder
	return get_texture("Dishes/" + entry_id)


func has_image(resource_id: String) -> bool:
	var canonical := _resolve_id(resource_id)
	return not canonical.is_empty() and _texture_or_null(canonical) != null


func get_resource_info(resource_id: String) -> Dictionary:
	var canonical := _resolve_id(resource_id)
	return {
		"id": canonical,
		"available": not canonical.is_empty() and _texture_or_null(canonical) != null,
		"custom_path": _custom_entries.get(canonical, ""),
		"builtin_path": _builtin_entries.get(canonical, ""),
	}


func has_frames(character_id: String, state: String, direction: String="down") -> bool:
	for texture in get_frames(character_id, state,direction):
		if texture != _placeholder:
			return true
	return false


func is_placeholder(texture: Texture2D) -> bool:
	return texture == null or texture == _placeholder


func _legacy_frames(character_id: String, state: String) -> Array[Texture2D]:
	var result: Array[Texture2D] = []
	if not _is_identifier(character_id) or not _is_identifier(state):
		result.append(_placeholder)
		return result
	var base := "Characters/%s_%s" % [character_id, state.to_lower()]
	if _frame_cache.has(base):
		return _frame_cache[base]
	var frame_ids: Dictionary = {}
	for entries in [_builtin_entries, _custom_entries]:
		for key in entries:
			var resource_id := str(key)
			if not resource_id.begins_with(base + "_"):
				continue
			var suffix := resource_id.trim_prefix(base + "_")
			if not suffix.is_valid_int() or suffix.begins_with("-"):
				continue
			# Canonical decimal suffixes avoid ambiguous _00 / _0 duplicates.
			if str(int(suffix)) == suffix:
				frame_ids[int(suffix)] = resource_id
	if (_custom_entries.has(base) or _builtin_entries.has(base)) and not frame_ids.has(0):
		frame_ids[0] = base
	var indexes: Array = frame_ids.keys()
	indexes.sort()
	for index in indexes:
		var frame_id: String = frame_ids[index]
		var texture: Texture2D = null
		# A custom unnumbered image replaces frame zero only. The remaining built-in frames survive.
		if int(index) == 0 and _custom_entries.has(base) and not _custom_entries.has(base + "_0"):
			texture = _load_image_texture(_custom_entries[base], false)
		if texture == null:
			texture = _texture_or_null(frame_id)
		result.append(texture if texture != null else _placeholder)
	if result.is_empty():
		result.append(get_texture(base))
	_frame_cache[base] = result
	return result


func import_image(bytes: PackedByteArray, relative_path: String) -> Dictionary:
	var relative := _valid_relative_image_path(relative_path)
	if relative.is_empty():
		return {"ok": false, "error": "仅可导入约定美术目录中的 PNG/JPG 图片，文件名不能含路径跳转。"}
	var decoded := _decode_image(bytes, relative.get_extension().to_lower())
	if decoded == null:
		return {"ok": false, "error": "图片无法解码、格式不符或超过 32 MiB / 8192 像素边长限制。"}
	var target := custom_root.path_join(relative)
	if _has_symlink(custom_root, relative):
		return {"ok": false, "error": "资源路径不能经过符号链接。"}
	var directory_error := DirAccess.make_dir_recursive_absolute(target.get_base_dir())
	if directory_error != OK:
		return {"ok": false, "error": "无法创建资源目录（错误 %d）。" % directory_error}
	var file := FileAccess.open(target, FileAccess.WRITE)
	if file == null:
		return {"ok": false, "error": "无法写入资源图片（错误 %d）。" % FileAccess.get_open_error()}
	file.store_buffer(bytes)
	file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error != OK:
		return {"ok": false, "error": "资源图片未完整写入（错误 %d）。" % write_error}
	reload()
	return {"ok": true, "error": "", "id": relative.get_basename(), "path": target}


func _resolve_id(resource_id: String) -> String:
	var candidate := resource_id
	if EXTENSIONS.has(candidate.get_extension().to_lower()):
		candidate = candidate.get_basename()
	if _is_canonical_id(candidate):
		return candidate
	if not _is_identifier(candidate):
		return ""
	if _aliases.has(candidate):
		return str(_aliases[candidate])
	# Legacy short names are accepted only if their category is unambiguous.
	var matches: Dictionary = {}
	for entries in [_builtin_entries, _custom_entries]:
		for key in entries:
			if str(key).get_file() == candidate:
				matches[key] = true
	return str(matches.keys()[0]) if matches.size() == 1 else ""


func _scan_images(root: String) -> Dictionary:
	var found: Dictionary={}
	for category in CATEGORIES:_scan_directory(root,category,found)
	return found

func _scan_directory(root: String, relative: String, found: Dictionary) -> void:
	if _has_symlink(root,relative):return
	var directory=DirAccess.open(root.path_join(relative))
	if directory==null:return
	for child in directory.get_directories():
		if _is_identifier(child) and relative.split("/").size()<6:_scan_directory(root,relative+"/"+child,found)
	for filename in directory.get_files():
		var actual_name=filename.trim_suffix(".remap").trim_suffix(".import") if root==builtin_root else filename
		var path=_valid_relative_image_path(relative+"/"+actual_name)
		if path.is_empty() or _has_symlink(root,path):continue
		var id=path.get_basename()
		if not found.has(id) or path.get_extension().to_lower()=="png":found[id]=root.path_join(path)

func _read_manifest(root: String) -> void:
	var manifest_path := root.path_join("manifest.json")
	if not FileAccess.file_exists(manifest_path) or _has_symlink(root, "manifest.json"):
		return
	var file := FileAccess.open(manifest_path, FileAccess.READ)
	if file == null or file.get_length() > 1024 * 1024:
		last_errors.append("无法读取资源清单：" + manifest_path)
		return
	var data: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not data is Dictionary or not data.get("aliases", {}) is Dictionary:
		last_errors.append("资源清单应包含 aliases 对象：" + manifest_path)
		return
	for alias in data.get("aliases", {}):
		var target: Variant = data["aliases"][alias]
		if _is_identifier(str(alias)) and target is String and _is_canonical_id(target):
			_aliases[str(alias)] = target
		else:
			last_errors.append("忽略不合法的资源别名：" + str(alias))


func _texture_or_null(canonical: String) -> Texture2D:
	var candidates=[canonical]
	for pair in [["UI/btn_decorate","UI/btn_decoration"],["UI/btn_promote","UI/btn_promotion"]]:
		if canonical in pair: candidates.append(pair[1] if canonical == pair[0] else pair[0])
	var prefix = ""
	for candidate_prefix in ["UI/decor_","Map/decor_","Map/equip_","UI/equip_"]:
		if canonical.begins_with(candidate_prefix): prefix = candidate_prefix; break
	if not prefix.is_empty():
		for candidate_prefix in ["UI/decor_","Map/decor_","Map/equip_","UI/equip_"]:
			var candidate = candidate_prefix + canonical.trim_prefix(prefix)
			if not candidate in candidates: candidates.append(candidate)
	if canonical.begins_with("Characters/"):
		var tail=canonical.trim_prefix("Characters/")
		for old in Identity.OLD_TO_NEW:
			var id=str(Identity.OLD_TO_NEW[old])
			if tail==id or tail.begins_with(id+"_"):candidates.append("Characters/"+old+tail.trim_prefix(id));break
	if canonical.begins_with("Dishes/"):candidates.push_front("Items/dish_"+canonical.trim_prefix("Dishes/"))
	if canonical.begins_with("Map/equip_"):candidates.append("UI/decor_"+canonical.trim_prefix("Map/equip_"))
	if canonical.begins_with("Map/decor_"):candidates.append("UI/decor_"+canonical.trim_prefix("Map/decor_"))
	for entries in [_custom_entries,_builtin_entries]:
		for candidate in candidates:
			if not entries.has(candidate):continue
			var image=_load_image_texture(str(entries[candidate]),entries==_builtin_entries)
			if image!=null:return image
	return null

func _load_image_texture(path: String, builtin: bool) -> Texture2D:
	if _decoded.has(path):
		return _decoded[path]
	var result: Texture2D = null
	# Godot packs built-in PNG/JPG as imported Texture2D. Only trusted res:// assets use ResourceLoader.
	if builtin and path.begins_with("res://") and ResourceLoader.exists(path, "Texture2D"):
		result = ResourceLoader.load(path, "Texture2D", ResourceLoader.CACHE_MODE_REUSE) as Texture2D
	else:
		var file := FileAccess.open(path, FileAccess.READ)
		if file != null and file.get_length() <= MAX_FILE_BYTES:
			var decoded := _decode_image(file.get_buffer(file.get_length()), path.get_extension().to_lower())
			file.close()
			if decoded != null:
				result = ImageTexture.create_from_image(decoded)
	if result == null:
		last_errors.append("图片不可用，已回退：" + path)
	_decoded[path] = result
	return result


func _decode_image(bytes: PackedByteArray, extension: String) -> Image:
	if bytes.is_empty() or bytes.size() > MAX_FILE_BYTES:
		return null
	var image := Image.new()
	var error: Error = ERR_FILE_UNRECOGNIZED
	if extension == "png":
		if bytes.size() < 33 or bytes.slice(0, 8) != PackedByteArray([137, 80, 78, 71, 13, 10, 26, 10]):
			return null
		var width := _big_endian_u32(bytes, 16)
		var height := _big_endian_u32(bytes, 20)
		if width <= 0 or height <= 0 or width > MAX_IMAGE_DIMENSION or height > MAX_IMAGE_DIMENSION or width * height > MAX_IMAGE_PIXELS:
			return null
		error = image.load_png_from_buffer(bytes)
	elif extension == "jpg" or extension == "jpeg":
		if bytes.size() < 4 or bytes[0] != 255 or bytes[1] != 216 or bytes[bytes.size() - 2] != 255 or bytes[bytes.size() - 1] != 217:
			return null
		error = image.load_jpg_from_buffer(bytes)
	if error != OK or image.is_empty():
		return null
	if image.get_width() > MAX_IMAGE_DIMENSION or image.get_height() > MAX_IMAGE_DIMENSION or image.get_width() * image.get_height() > MAX_IMAGE_PIXELS:
		return null
	return image


func _take_snapshot() -> Dictionary:
	var snapshot: Dictionary = {}
	for root in [builtin_root, custom_root]:
		var paths: Dictionary = _scan_images(root)
		paths["manifest"] = root.path_join("manifest.json")
		for path in paths.values():
			if not FileAccess.file_exists(path):
				continue
			var file := FileAccess.open(path, FileAccess.READ)
			if file != null:
				# The hash also catches an editor saving a same-size image twice in one timestamp second.
				var digest := FileAccess.get_md5(path) if file.get_length() <= MAX_FILE_BYTES else "oversize"
				snapshot[path] = [FileAccess.get_modified_time(path), file.get_length(), digest]
				file.close()
	return snapshot


func _valid_relative_image_path(path: String) -> String:
	if path.contains("\\") or path.contains(":") or path.to_utf8_buffer().has(0):return ""
	var parts=path.split("/")
	if parts.size()<2 or parts.size()>7 or not CATEGORIES.has(parts[0]):return ""
	if not EXTENSIONS.has(parts[-1].get_extension().to_lower()):return ""
	for index in range(1,parts.size()):
		if not _is_identifier(parts[index].get_basename() if index==parts.size()-1 else parts[index]):return ""
	return path

func _is_canonical_id(resource_id: String) -> bool:
	return not _valid_relative_image_path(resource_id+".png").is_empty()

func _is_identifier(value: String) -> bool:
	if value.is_empty() or value.length() > 128:
		return false
	for character in value:
		if not ((character >= "a" and character <= "z") or (character >= "A" and character <= "Z") or (character >= "0" and character <= "9") or character == "_" or character == "-"):
			return false
	return true


func _has_symlink(root: String, relative: String) -> bool:
	# Check every existing component, including the root itself. Never follow a user-created escape.
	var absolute_root := ProjectSettings.globalize_path(root).simplify_path()
	var current := absolute_root.get_base_dir()
	var root_parent := DirAccess.open(current)
	if root_parent != null and root_parent.is_link(absolute_root.get_file()):
		return true
	current = absolute_root
	for component in relative.split("/"):
		var directory := DirAccess.open(current)
		if directory != null and directory.is_link(component):
			return true
		current = current.path_join(component)
	return false


func _big_endian_u32(bytes: PackedByteArray, offset: int) -> int:
	return (int(bytes[offset]) << 24) | (int(bytes[offset + 1]) << 16) | (int(bytes[offset + 2]) << 8) | int(bytes[offset + 3])


func _make_placeholder() -> Texture2D:
	var image := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	image.fill(Color("dedbd2"))
	for y in range(64):
		for x in range(64):
			if x < 2 or y < 2 or x >= 62 or y >= 62:
				image.set_pixel(x, y, Color("999789"))
			elif absi(x - 32) + absi(y - 32) < 17:
				image.set_pixel(x, y, Color("8e9984"))
	return ImageTexture.create_from_image(image)

func get_sprite(resource_id: String) -> Texture2D:return get_texture(resource_id)

func get_portrait(character_id: String, tutorial: bool=false) -> Texture2D:
	var id=Identity.canonical(character_id)
	if not _is_identifier(id):return _placeholder
	var names=["Portraits/tutorial_"+id,"Portraits/"+id] if tutorial else ["Portraits/"+id]
	for name in names:
		var texture=_texture_or_null(name)
		if texture!=null:return texture
	return _placeholder # Portraits deliberately never enlarge an in-scene sprite.

func _sequence(prefix: String) -> Array[Texture2D]:
	var ids: Dictionary={}
	for entries in [_builtin_entries,_custom_entries]:
		for key in entries:
			if not str(key).begins_with(prefix+"_"):continue
			var suffix=str(key).trim_prefix(prefix+"_")
			if suffix.is_valid_int() and int(suffix)>=0 and str(int(suffix))==suffix:ids[int(suffix)]=str(key)
	var result: Array[Texture2D]=[];var indices=ids.keys();indices.sort()
	for index in indices:
		var texture=_texture_or_null(ids[index])
		if texture!=null:result.append(texture)
	return result

func get_frames(character_id: String, state: String, direction: String="down") -> Array[Texture2D]:
	var id=Identity.canonical(character_id)
	if not _is_identifier(id) or not _is_identifier(state) or not direction in ["up","down","left","right"]:return _missing_frames()
	var action={"move":"walk","build":"cook","recommend":"order"}.get(state.to_lower(),state.to_lower())
	var cache_key="direction:"+id+":"+action+":"+direction
	if _frame_cache.has(cache_key):return _frame_cache[cache_key]
	var prefixes=["Sprites/"+id+"/"+action+"_"+direction,"Sprites/"+id+"/"+action+"_down","Sprites/"+id+"/"+action,"Sprites/"+id+"/idle_"+direction,"Sprites/"+id+"/idle_down","Sprites/"+id+"/idle"]
	for prefix in prefixes:
		var result=_sequence(prefix)
		if not result.is_empty():_frame_cache[cache_key]=result;return result
	# Existing Characters paths and original IDs remain a supported compatibility channel.
	for legacy_id in [Identity.legacy(id),id]:
		var result=_legacy_frames(legacy_id,state)
		if result.any(func(texture):return texture!=_placeholder):_frame_cache[cache_key]=result;return result
	_frame_cache[cache_key]=_missing_frames();return _missing_frames()

func get_frame(character_id: String, action: String, direction: String, frame: int=0) -> Texture2D:
	var frames=get_frames(character_id,action,direction)
	return frames[posmod(frame,frames.size())]

func get_customer_frames(kind: String, appearance: String, action: String, direction: String) -> Array[Texture2D]:
	if not _is_identifier(kind) or not _is_identifier(appearance) or not action in ["walk","idle","sit","eat"] or not direction in ["up","down","left","right"]:return _missing_frames()
	var key="guest:"+kind+":"+appearance+":"+action+":"+direction
	if _frame_cache.has(key):return _frame_cache[key]
	var roots=["Sprites/customer/"+kind+"/"+appearance+"/"+appearance]
	if kind=="special":roots.push_front("Sprites/customer/"+appearance+"/"+appearance)
	for root in roots:
		for tail in [action+"_"+direction,action+"_down","idle_"+direction,"idle_down"]:
			var result=_sequence(root+"_"+tail)
			if not result.is_empty():_frame_cache[key]=result;return result
	_frame_cache[key]=_missing_frames();return _missing_frames()

func _missing_frames() -> Array[Texture2D]:
	var frames: Array[Texture2D]=[_placeholder];return frames
