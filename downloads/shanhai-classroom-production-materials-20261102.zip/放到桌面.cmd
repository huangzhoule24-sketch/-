@echo off
chcp 65001 >nul
setlocal
set "SHANHAI_MATERIALS_SOURCE=%~dp0材料"
powershell -NoProfile -Command "$src=$env:SHANHAI_MATERIALS_SOURCE; if(!(Test-Path -LiteralPath $src)){throw '请先全部解压压缩包'}; $desktop=[Environment]::GetFolderPath('Desktop'); if(!$desktop){throw '无法确定桌面路径，请手动复制材料文件夹'}; $target=Join-Path $desktop '材料'; if(Test-Path -LiteralPath $target){$target=Join-Path $target ('山海食肆_制作过程_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))}; New-Item -ItemType Directory -Path $target -ErrorAction Stop | Out-Null; Get-ChildItem -LiteralPath $src | Copy-Item -Destination $target -Recurse -ErrorAction Stop; Write-Host ('材料已复制到：'+$target); Invoke-Item -LiteralPath $target"
if errorlevel 1 echo 复制未完成，可手动把“材料”文件夹拖到桌面。
pause
