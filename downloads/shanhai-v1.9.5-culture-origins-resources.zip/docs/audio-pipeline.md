# 音频接入说明 · 2026-10-27

已内置42个免费授权音频文件，覆盖28类短音效和2类循环环境声，来源与编辑说明见[音效整合](free-sfx/guide.md)。五个音乐槽仍留空。缺失的音频静默跳过，原经营数值、存档格式、美术和座位图层修复保留。临时测试声只在测试目录/浏览器测试存储中，不随游戏交付。

## 最快的使用方式

1. 在 AI 音乐网站生成纯器乐配乐，下载 MP3、WAV 或 OGG。
2. 游戏内打开「更多 → 系统与存档 → 声音设置与音频导入」。也可以从「开发者选项 → 音频资源：导入与试听」进入。
3. 选择「日常营业」槽位，点「导入音频」，选择文件，再点「试听所选」。停止试听或返回会恢复场景音乐。
4. 关闭面板继续经营，营业时段将自动使用新配乐。夜市、闭店与休息时段使用另一首曲目。

单文件最多 64 MiB；仅支持真实可解码的 OGG Vorbis、MP3、WAV。改后缀不能转换音频，OGG Opus 不在当前支持范围。

## 开发者路径

内置资源为 `assets/audio/`，外置资源为桌面程序同级 `CustomAudio/`。Godot 编辑器运行时，外置目录为项目内 `CustomAudio/`；网页版为 `user://CustomAudio/`，只能经文件选择器导入。网页素材、音量保存在当前站点/浏览器，清除站点数据会删除它们；后台同步并不等于每次调用返回即已持久化完成。

两套目录的子目录一致：

```text
music/      标题、营业、夜间、探索、比赛配乐
ambience/   食肆与夜间庭院环境声
ui/         点击、返回、操作受限
actions/    点单、烹饪、收银、清洁、施工、步行/飞行/爬行等
events/     成交、结算、升级、研发、招聘、特殊顾客等
```

配置与清单：

- `config/audio.json`：35个槽位、中文名、路径、通道、增益、冷却间隔、场景/动作映射。
- `docs/audio-resource-list.csv`：可交给组员分工制作的完整清单，标明当前触发或仅预留接口。
- `docs/audio-creation-log.csv`：本轮逐槽来源、授权、编辑及交付哈希；五个音乐槽仍未导入。
- `scripts/services/audio_system.gd`：统一加载、播放、音量、导入、试听接口。
- `scripts/services/game_audio_bridge.gd`：只读观察经营状态及实际到站动作，不改变模拟或随机数。

路径示例：`assets/audio/music/business_day.ogg`，或者 `CustomAudio/music/business_day.mp3`。每个槽位自动接受同名 `.ogg`、`.mp3`、`.wav`，无需为了MP3改配置。外置文件优先于内置文件；导入器会记住所选格式，后续重导其他格式也能生效。手工替换后点击「重新加载音频目录」，或重启程序。

如果同一音效需要变体，可在 `files` 中列出不同基名，按顺序轮换；同一基名存在多种格式时只选一种。变体不使用游戏RNG。若已存在自定义变体，默认不再混入内置变体。

```json
"files": ["actions/cook_01.wav", "actions/cook_02.wav", "actions/cook_03.wav"]
```

## 播放与混音规则

- Master、Music、SFX、Ambience四通道；总音量、分通道音量和静音独立保存在 `user://audio_settings.cfg`，不进入游戏存档。拖动音量条约0.4秒后保存，退出时补存。
- 曲目默认整段循环，切换约1.2秒淡入淡出；同一场景刷新不会重头播放。是否真正无缝取决于源文件首尾处理；系统不会自动补齐节拍或修复接缝。
- 欢迎页使用标题曲，探索/比赛页面使用各自曲目；平时按营业时段选择日间/夜间曲。探索是页面配乐，不是为后台每个探索队伍各开一个播放器。
- 经营暂停时停止动作短音并暂停环境声；背景音乐与UI操作声保留。暂停、倍速不会改变音频音高或把音效按游戏分钟密集重放。
- 最多6个世界短音、2个UI/反馈短音，另有单独试听播放器。世界声至少间隔0.16真实秒，并有各槽位冷却；过密声音直接略过，不排队补播。
- 员工声音依据实际渲染动作触发；移动区分walk/fly/crawl，烹饪不在走向灶台途中发出。播放使用普通AudioStreamPlayer，当前没有空间定位、距离衰减或设备逐个循环混音。
- 仅接入实际在本版观察器中的事件；满意/不满、拾取、成功/失败等部分槽位先预留显式调用，不宣称全部已经自动触发。完整对应表见CSV。
- 试听不循环，会暂时压住背景音乐和环境声；结束/停止/返回恢复原音乐。试听也遵守对应通道音量与总静音。
- 浏览器首次真实按钮交互后开放音频；浏览器仍可由用户/系统控制音频权限。

开发者显式触发接口（主界面已有 `audio` 实例）：

```gdscript
audio.play_cue("event.pickup", true) # 第二参数表示经营现场声音；暂停时略过
audio.play_cue("ui.error")
audio.set_music("music.explore")
audio.set_level("music", 0.5)
audio.reload()                       # 更换外置文件后清缓存，重新加载
```

不要在 `_draw()` 或每个动画帧里直接创建播放器；统一服务已经管理通道、并发和冷却。

## 给音乐制作同学的规格

先做营业循环曲，再扩展标题、夜间、探索和比赛，共5首。日常配乐建议90–150秒，纯器乐，国风旋律结合轻量电子编曲，动态平稳。环境声建议30–60秒循环。短音效避免不必要的前后静音和尖锐峰值，先做点击/返回/烹饪/上菜/收银。

建议保留48kHz WAV母版；音乐交付OGG Vorbis或MP3，动作音效交付PCM WAV。音乐可以从约−18至−16 LUFS、真峰值低于−1dBTP起步，在实际游戏内按听感再调整；数值是制作参考，非自动验收标准。

无缝循环须在音频编辑软件中剪辑并连续试听，特别检查混响尾音和MP3接缝。当前只支持整段循环，不支持intro+loop双段或多轨自适应音乐。

## AI制作网站建议

推荐 [Suno](https://suno.com/create)，先制作纯器乐营业曲，适合用自然语言试风格。生成结果仍需要人工挑选与首尾剪辑。本环境访问该站时受到网络代理限制，未核实当日界面、价格、地区可用性或套餐授权；实际导出能力、使用范围以网站当前说明为准。

可尝试以下提示词，并选择纯器乐选项（若界面提供）：

> Instrumental background music for a cozy pixel-art restaurant management game inspired by Chinese mythology. Warm bamboo flute, guzheng and pipa motifs, gentle percussion, subtle modern synth textures. Around 88 BPM. Calm, playful, slightly magical, suitable for repeated listening. Simple melody, stable dynamics, no vocals, no dramatic drops. Leave a clean musical phrase for seamless loop editing.

AI创作过程记录提示词、生成日期、选用片段和人工修改；素材文件另记来源与使用条件，便于课程展示及后续鸣谢。

## 验证范围

专项测试用真实生成的临时PCM WAV检验导入/解码、循环、快速切歌、试听、暂停、限频、音量保存、旧经营数据隔离、三类移动及手机返回。浏览器另外通过真实文件选择器导入测试音频、试听、刷新验证持久化。实际完成数与证据见 `docs/audio-validation.md`。

正式音乐/音效尚未制作，Windows声卡与手机扬声器的实际听感也尚未验收。
