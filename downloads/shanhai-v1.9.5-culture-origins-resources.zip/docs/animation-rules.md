# 动画与属性联动

本实现沿用既有 Godot 4.6.3 工程，将策划 v1.2 中 Unity Animator 的行为要求转换为 Godot Control 绘制与员工视图状态机。正式角色图尚未提供，默认使用随动作变化的矢量占位形象；后续图片统一从 AssetCatalog 读取。

## 数值与冲突处理

所有映射参数保存在 `config/animation.json`，由 `RestaurantView.animation_settings()` 读取；模型调度器与视图共用 `RestaurantView.animation_factor(employee, action)`，不在两个系统分别维护公式。

| 动作 | 对应属性 | 公式 | 基础因子范围 |
| --- | --- | --- | --- |
| Move、Serve、Clean | 速度 speed | 1 + (属性 - 5) × 0.08 | 0.6–2.0 |
| Cook | 厨艺 cooking | 1 + (属性 - 5) × 0.06 | 0.7–1.8 |
| Cashier、Promote | 魅力 charm | 1 + (属性 - 5) × 0.05 | 0.8–1.5 |
| Idle、休息、训练 | 无 | 1.0 | 1.0 |

基础因子先限制范围，再乘心情因子 `1 + max(心情 - 80, 0) × 0.001`。心情限制到 0–100，因此心情加速为 0%–2%。策划第 20 章同时写了“额外 +5%”及上述公式，两者矛盾；本实现采用可计算的公式。第 16.4 节早期移动系数 0.05 与第 20 章 0.08 也不一致，本实现采用后出现、参数更完整的第 20 章。耐力不直接加速动画，疲劳恢复仍属于模型规则。

## 平滑位移与结果边界

每名员工有独立且持续保留的 `position`、`target`、`facing`、`action`、`phase`、`progress`。新员工从门口入场，任务、岗位或休息状态变化只更新目标，逐帧 `move_toward`，不会把当前位置改为目标。无顾客时从真实当前位置回到岗位；不会用顾客任务百分比在站台和桌位之间来回跳转。

默认移动速度为每游戏分钟 210 画面像素，再乘移动因子。移动过程中为 Move，到达后切换 Cook / Serve / Clean / Cashier / Promote；空闲为 Idle。按水平方向翻转角色图，状态交叉渐变时长 0.15。动画、移动和收入浮标均使用同一模拟时钟：暂停为零，正常模式乘 1/2/3 倍，Demo 再乘配置的时间因子。单帧时间上限 0.1 秒，避免浏览器恢复显示时的一帧跳跃。

视图绝不扣食材、结账、改顾客阶段或完成任务。工作条只反映模型已过去的任务时间，在模型完成前最多显示 99%；顾客仍由模型调度器完成后续流转。模型应为移动和完整工作保留时间，不得让动画本身直接触发结果。九婴等并发厨师会收集所有属于该员工的订单，以 `×数量` 显示同时烹饪；多厨师各有独立站位。

高倍率下工作状态会随模拟时钟加快，模型任务仍按完整的游戏分钟调度；这不将单帧画面等同于一次真实任务完成。

## 美术接入

`main.gd` 为视图注入 `assets: AssetCatalog`。所有员工均调用 `get_frames(id, state)`；`has_frames` 为 false 时保留动作矢量替身。

- 员工：`Characters/<id>_<state>.png` 或 `<id>_<state>_<frame>.png`，state 为 idle/move/cook/serve/clean/cashier/promote。
- 场景：优先 `Backgrounds/restaurant_stage_<stage>.png`，缺失则 `Backgrounds/restaurant.png`，再回退矢量场景。
- 桌椅和装修：`UI/decor_<decoration_id>.png`，如 `decor_table_two`、`decor_lantern`。
- 菜品：`Dishes/<dish_id>.png`，顾客用餐时显示。

所有 ID 由 AssetCatalog 解析，视图不直接打开外部图片；自定义目录、合法格式和导入方法见资源接入文档。缺失场景、装修、菜品时保留原简易图形。仅 SSR 员工头顶显示金色五角星，N/R/SR 均不显示星级。

## 外部接口与验证

- `static animation_factor(employee: Dictionary, action: String) -> float`：动作名称不区分大小写，支持 cooking / serving / cleaning / paying 调度器别名。
- `employee_animation_state(id) -> Dictionary`：返回副本，供诊断当前动画、位置、目标、朝向、工作进度与并发任务数。
- `first_customer_bounds()` 和 `customer_bounds(id)`：返回视图局部坐标矩形，供引导层高亮顾客；不存在时为空矩形。

运行 `godot --headless --path . --script res://tests/animation_tests.gd`。检查属性上下限、低/高心情、暂停与倍率、实际平滑位移、任务切换不跳位、各工作状态、视图不改模型、九婴并发订单与顾客高亮。
