# 免费音效整合 · 2026-10-27

本次将网上免费素材编辑成42个内置文件，覆盖28类短音效与2类循环环境声。启动游戏即可使用，无需自行下载或逐个导入。原来的五个背景音乐槽保持留空，未恢复此前暂停的配乐扩展。

界面点击/返回/条件提示，点单、切菜/锅具/沸水、上菜、收银、擦拭、施工、招徕，以及步行/振翅/爬行都有声音。动作仍需实际到站才触发；人物的移动与工作规则未改动。加入食肆人声餐具背景和夜间虫鸣，两者随营业时段切换，暂停经营时暂停。

事件包括特殊来客、成交、日结、阶段提升、研发、招募、任务奖励和随机事件；另把比赛胜负、好差评、拾取接入原有预留音效。灵石原先独立生成的提示音已移除，现在现金和灵石都遵守总静音及音效音量。读取旧档不补播历史奖励；比赛结果刷新不重复播放。评价按真实增量观察，好评通常在每五单选一次，负评优先于普通成交提示；不会把某种国籍或角色外观配成固定情绪声音。

## 来源与授权

| 作者 / 素材包 | 免费资源入口 | 许可 | 选用内容 |
| --- | --- | --- | --- |
| Kenney / UI Audio | https://kenney.nl/assets/ui-audio | CC0 1.0 | 点击、返回 |
| Kenney / RPG Audio | https://kenney.nl/assets/rpg-audio | CC0 1.0 | 硬币、锅具、切菜、布料 |
| Kenney / Impact Sounds | https://kenney.nl/assets/impact-sounds | CC0 1.0 | 木地板脚步、轻餐盘、木工敲击 |
| Wyzowl / SFX Kit | https://github.com/wyzowl/sfx-kit | CC0 1.0 | 记单、门铃、柔和提示、奖励和结果短音 |
| Oculus VR, LLC / Oculus Audio Pack 01 | https://github.com/facebookincubator/Meta-open-sound/tree/main/corpora/oculus-audio-pack | CC BY 4.0 | 餐馆/虫鸣循环、陶器、汤匙、布旗、沸水 |

CC0可免费使用、修改和再分发；保留作者鸣谢。Oculus文件需携带作者、许可链接与修改说明，本项目已在声音设置页、`assets/audio/CREDITS.md` 和发布包的 `licenses/audio/` 中提供。再次发布游戏或转交音效时保留这些材料。完整条款在 `assets/audio/licenses/`。

Kenney、OpenGameArt、Freesound、BigSoundBank和普通搜索入口在本云环境的实际访问返回代理403，未声称读过这些网站的检索结果。资源通过GitHub公开仓库搜索、Kenney资源镜像、Wyzowl和Meta公开仓库实际取回，使用固定提交的原文件与随包许可。没有登录、订阅或付费下载。`sources.json`记录五组来源、许可原文地址/哈希；`selection.json`逐文件记录原始路径、下载URL、实际HTTP200、SHA256和编辑参数。Wyzowl条目还与作者目录中声明的文件哈希核对。

Wyzowl注明其素材由AI辅助代码合成；本次没有把这些声音标成现场录音，也没有调用AI网站生成音频。餐馆环境来自通用餐饮录音，低声混入作生活气氛，不将它当作古代中国餐馆的历史声景复原。

## 混音与替换

短音转换为48kHz/16bit单声道WAV，裁去明显空白、保留短尾音，端点做3ms/25ms淡化。常见动作峰值约−12dBFS，少数重要结果约−9dBFS，另叠加原槽位增益。环境声使用48kHz立体声OGG，并在首尾重叠0.25秒；循环没有刻意留静音。动作变体顺序轮换，不消耗经营随机数。招徕间隔改为8真实秒、成交提示降至−9dB，避免频繁盖住其他声音。

仍使用6个现场声部、2个界面/反馈声部及现场总限频，1×至4×不会改变音高或以游戏分钟追赶播放。设置位于「更多 → 系统与存档 → 声音设置与音频导入」。总音量、音效、环境声与静音单独保存；可逐槽试听。

实际浏览器输出检查发现原来的动态 `add_bus()` 在Godot 4.6网页采样桥中会改变声音通道的顺序，导致Master失去最终输出连接。已改为扩展 `AudioServer.bus_count` 后命名通道，保留Master索引与实际输出；仅检查“playing=true”不能覆盖这类问题。

内置目录 `assets/audio/`；替换目录是桌面程序同级 `CustomAudio/`，网页通过游戏内导入保存。原导入通道及同名OGG/MP3/WAV优先覆盖保留。自定义声音按自己的许可记录，不能沿用本包的CC0标签。

重建选中素材：

```sh
python3 tools/build_free_sfx.py --download
```

需要Python3、numpy和FFmpeg。原始缓存保存在忽略目录 `build/free-sfx/source-cache/`，下载后核对固定SHA256；不执行来源仓库内的脚本。相同参数产生相同PCM编辑结果，OGG容器序号可能造成文件字节哈希不同，重建后以新报告为准。

## 验证边界

逐文件实际解码、峰值、长度、循环首尾与削波统计见 `../validation-artifacts/free-sfx/audio-files.json`；Godot测试、浏览器操作及下载校验见本轮验证记录。数值和播放检测不能代替耳机/扬声器听审，团队可试玩后继续调整声音喜好与音量。此次未改经营数值、存档结构或文化正文。
