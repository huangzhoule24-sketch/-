内置正式音效：42个音频文件，覆盖28类短音效及2类环境声；5个配乐槽仍留空。

作者及许可见CREDITS.md与licenses/，逐文件原始下载、固定版本、哈希和编辑过程见docs/free-sfx/selection.json。内置音效可被程序同级CustomAudio或游戏内导入的同名文件覆盖，接口见docs/audio-pipeline.md。

重建：python tools/build_free_sfx.py --download，需要免费Python3、numpy、FFmpeg。程序只读取固定HTTPS音频文件并核对SHA256，不执行素材仓库中的代码。
