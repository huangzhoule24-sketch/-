# 内置美术资源入口

当前保留程序绘制图形与中性占位纹理；没有伪造正式美术。正式资源可按以下路径补入并重新导出：

- `Backgrounds/restaurant.png`：餐厅背景，建议 1920 × 1080。
- `Characters/qianyang_idle_0.png`：羬羊待机第 0 帧，角色帧建议 64 × 64 或 128 × 128，透明 PNG。
- `Characters/qianyang_cook_0.png`：羬羊做菜第 0 帧，其余角色 ID 见 `config/employees.json`。
- `Dishes/noodles.png`：阳春面图标，其余菜品 ID 见 `config/dishes.json`。
- `UI/btn_employee.png`：员工导航图标；其余接入名称见 `docs/art-pipeline.md`。

四个子目录允许暂时为空；图片统一通过 `scripts/services/asset_catalog.gd` 获取。详见 [开发者美术接入说明](../../docs/art-pipeline.md)。
