# SH-STARTUP-R3 · 启动与Windows课堂兼容

基线：SH-EN-R2，技术提交76ca6ee。当前为完整正式游戏的启动优化，保留中文/English、阶段0–4、30员工、25篇菜品读本与6位特殊来客、61篇文学文化介绍、54段古文、全部图片音效和开发者资源替换入口。不是删减版；旧档目录与数据版本未变。

## 实施

- 常规游玩不再建立开发者美术热重载校验快照；开启开发者模式后仍能发现新增、删除、同尺寸同时间覆盖及手动重新加载。
- 导出包内的只读可信res://assets/art不再逐文件探测操作系统符号链接。外置CustomAssets、编辑器工程及测试目录继续使用原有路径、图片和链接验证。热重载不扫描只读PCK。
- 启动先显示轻量加载画面，再在线程中加载完整游戏场景。进度来自资源加载器；失败有提示及重试。主规则的固定依赖在资源加载阶段解析，避免在主线程初始化时逐个解析；没有删除任何规则模块。
- 中文启动暂不编译未使用的909个英文正则模板；现因修复事件结果漏译增加到910个，首次需要模板匹配时编译。英译完整句子及动态字段规则保留。
- Windows偏好Direct3D 11 ANGLE，保留原生OpenGL回退；提供普通60帧、低占用30帧、OpenGL备用三个CMD。帧率限制只影响呈现，游戏时间倍率、动作位移与经营规则保持不变。
- Windows窗口按实际屏幕可用区域缩小并居中。1024×768兼容测试中实际窗口992×720，未超出屏幕。
- 在玩家数据目录生成startup-report.json，记录版本、系统、驱动名称与阶段耗时，不记录存档内容；启动器日志在本机LocalAppData，安装目录无需写权限。
- 回归浏览器实际随机事件时发现原有英文结果数值行漏译，补充通用带符号变化模板，并验证真正的事件结果页面。除此之外，美术、音频、文化数据及经营配置均逐字节未变。

## 性能测量口径

同一Linux环境、Godot4.6.3，基线与优化后各5个新进程，无界面渲染的脚本直接实例化完整游戏。文件系统缓存未清空，未模拟学校磁盘与杀毒软件；不把这些数值当作Windows首次冷启动保证。

| 指标（中位数） | 基线 | 优化后 |
|---|---:|---:|
| 主界面初始化 | 594.379 ms | 315.251 ms |
| 场景载入 | 806.302 ms | 1091.320 ms |
| 进入欢迎页总耗时 | 1525.896 ms | 1451.657 ms |
| 常规启动美术校验快照条目 | 276 | 0 |

初始化耗时约降低47.0%，总耗时约降低4.9%；部分工作移到了资源载入阶段，因此不能把初始化降低幅度当成整个启动时间降低幅度。真实加载画面另有独立时间点。原始五轮记录见验证目录的benchmarks.json。Windows兼容环境的耗时与来源见windows-verification.json，不能与Linux表格作横向速度比较。

## Windows支持范围与实际检查

交付Windows 10/11 x64免安装包，不依赖用户安装Godot、Python或Visual Studio。检查实际PE32+ AMD64导入表，未静态依赖独立VCRUNTIME/MSVCP运行库。Windows 7/8、32位系统和ARM不是本次原生包承诺范围；学校应用白名单、损坏/禁用的驱动及缺少设备权限需要在现场确认。

在Linux上的Wine10/Xvfb/Mesa软件渲染兼容环境，实际Windows EXE通过OpenGL备用路径显示了中文欢迎页、切换为英文、进入完整教学，并检查1024×768屏幕适配。最终构建另行重复启动并保存画面和日志。该结果不是Windows10/11实体设备、真实触摸屏、学校管理软件或真实声卡验收。

Wine自带的D3D着色器编译器不支持ANGLE所需的部分几何着色器语法，ANGLE图形检查因此不算通过。微软编译器下载受本执行环境网络限制，未通过不明DLL网站获取，未在交付包混入测试DLL。Windows渲染设置依据Godot4.6官方文档和引擎实现；实际学校设备仍建议在上课前用同一下载包试开。

参考：
- https://docs.godotengine.org/en/4.6/about/system_requirements.html
- https://docs.godotengine.org/en/4.6/classes/class_projectsettings.html#class-projectsettings-property-rendering-gl-compatibility-driver-windows
- https://github.com/godotengine/godot/blob/4.6-stable/platform/windows/display_server_windows.cpp
- https://github.com/godotengine/godot/blob/4.6-stable/doc/classes/ProjectSettings.xml

完整功能回归、当前英文专项、启动检查、浏览器及下载结果由本目录最终证据汇总；不以目录数量或静态参数代替实际试玩。

## 最终检查与证据

运行源码指纹`4fa823e8f893aaba091e34d207b38c8b5a94dc701ac43d0fb2f386518f075c8e`，827项，Web/Windows回执一致。54组回归通过，随后对实际浏览器新发现的带符号事件结果行补译并专项复验：英文4701项、启动14项通过。最终浏览器86次真实操作、8结果检查、0错误，涵盖首单、原文读本、随机事件、实际日结与来信、小屏返回、存档刷新及中英切换。专项修复后没有重复宣称整轮源码全程未变化；实际记录保留。

最终Windows EXE在Wine/OpenGL/1024×768环境启动到完整欢迎页，无脚本错误；此处不声明真实Windows课堂硬件或ANGLE实体显卡已验收。证据见[summary.json](validation-artifacts/startup-r3/summary.json)及同目录原始记录。后验下载核验在公开发布后追加，不重打包覆盖已发布文件。


## 公开交付

独立根提交`f2762f201d87cb450886b8bab0296d34acc7ac33`，分支`startup-r3-v1.9.5-20261101`。四包实际匿名下载HTTP200、SHA256、ZIP CRC、运行回执及源码母图并集完整性均通过。见[公开下载核验](validation-artifacts/startup-r3/public-download.json)。此证明在发布后追加；已验证的四个ZIP保持原字节。
