extends SceneTree
const Audio=preload("res://scripts/services/audio_system.gd")
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=[]
func expect(ok:bool,message:String):
	checks+=1
	if not ok:failures.append(message);push_error(message)
func _init():call_deferred("run")
func settle():
	for i in range(4):await process_frame
func find(node:Node,id:String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var found=find(child,id)
		if found!=null:return found
	return null
func run():
	var preferences="user://music-r4-%d.cfg"%OS.get_process_id()
	var audio=Audio.new("res://assets/audio","user://music-r4-no-override",preferences)
	root.add_child(audio);await settle();audio.set_process(false)
	for cue in ["music.title","music.day","music.night","music.explore","music.contest"]:
		var stream=audio.cue_stream(cue,true)
		expect(stream is AudioStreamOggVorbis and stream.loop,"Every context resolves the actual user music with looping: "+cue)
		expect(absf(stream.get_length()-87.2727)<.1,"Music has the full 32-bar loop and no four-second gap: "+cue)
	audio.set_music("music.title");await create_timer(.08).timeout
	var starts=audio.music_starts
	for cue in ["music.day","music.night","music.explore","music.contest","music.title"]:audio.set_music(cue)
	expect(audio.music_starts==starts,"Navigating shared music contexts never restarts the recording")
	expect(audio.snapshot().music_playing,"Actual background player starts")
	audio.set_level("music",.37);audio.set_channel_enabled("music",false)
	expect(AudioServer.is_bus_mute(AudioServer.get_bus_index("Music")) and audio.snapshot().music_paused,"Music switch mutes and pauses the music player")
	expect(not AudioServer.is_bus_mute(AudioServer.get_bus_index("SFX")),"Music switch keeps effects available")
	expect(not audio.preview("music.day"),"Preview cannot bypass the music switch")
	audio.set_channel_enabled("music",true)
	expect(not audio.snapshot().music_paused and audio.levels.music==.37 and audio.music_starts==starts,"Re-enable resumes the same track and retains the chosen volume")
	audio.set_world_paused(false);audio.set_ambience("ambience.dining")
	audio.set_channel_enabled("sfx",false)
	expect(AudioServer.is_bus_mute(AudioServer.get_bus_index("SFX")) and AudioServer.is_bus_mute(AudioServer.get_bus_index("Ambience")),"Effects switch includes environment sounds")
	expect(not AudioServer.is_bus_mute(AudioServer.get_bus_index("Music")),"Effects switch keeps music audible")
	expect(not audio.play_cue("event.stage") and not audio.preview("ambience.dining"),"Effects and previews cannot bypass disabled effects")
	expect(audio.snapshot().ambience_paused,"Environment player pauses when effects are disabled")
	audio.set_channel_enabled("sfx",true)
	expect(not audio.snapshot().ambience_paused,"Environment resumes on effects re-enable")
	audio._clock+=2;audio.play_cue("event.stage");audio._process(.06)
	expect(is_equal_approx(audio._duck_gain_db,-3.0),"Important actual effects duck music by 3dB in 60ms")
	expect(AudioServer.get_bus_volume_db(AudioServer.get_bus_index("Music"))<linear_to_db(.37)-2.9,"Ducking reaches the actual Music bus")
	audio._process(1.0)
	expect(is_zero_approx(audio._duck_gain_db),"Music smoothly returns after the alert")
	audio._clock+=2;audio.play_cue("move.walk",true);audio._process(.06)
	expect(is_zero_approx(audio._duck_gain_db),"Routine footsteps do not cause pumping")
	audio.set_channel_enabled("music",false);audio.set_channel_enabled("sfx",false);audio.save_settings()
	var restored=Audio.new("res://assets/audio","user://music-r4-no-override",preferences)
	root.add_child(restored);await settle()
	expect(not restored.enabled.music and not restored.enabled.sfx and restored.levels.music==.37,"Both independent switches and volume survive service recreation")
	restored.queue_free();audio.queue_free();await settle()
	var ui=Harness.new();root.add_child(ui);await settle()
	ui.setup_audio();ui.audio.settings_path="user://music-r4-ui.cfg"
	ui.open_panel("系统");await settle()
	var before=JSON.stringify(ui.model.state);var rng=ui.model._rng.state
	var music=find(ui,"system:audio:music");var sfx=find(ui,"system:audio:sfx")
	expect(music is CheckButton and sfx is CheckButton,"System settings expose both real channel switches")
	music.button_pressed=false;sfx.button_pressed=false
	expect(not ui.audio.enabled.music and not ui.audio.enabled.sfx,"Actual settings controls change the audio service")
	expect(before==JSON.stringify(ui.model.state) and rng==ui.model._rng.state,"Audio switches cannot alter campaign values or RNG")
	ui.open_panel("声音设置");await settle()
	expect(not find(ui,"audio:enabled:music").button_pressed and not find(ui,"audio:enabled:sfx").button_pressed,"Detailed sound settings reflect the system switches")
	find(ui,"audio:enabled:music").button_pressed=true
	expect(ui.audio.enabled.music and not ui.audio.enabled.sfx,"Music can be enabled independently from effects in the real UI")
	ui.return_to_parent_panel();await settle()
	expect(find(ui,"system:audio:music").button_pressed and not find(ui,"system:audio:sfx").button_pressed,"Returning to system settings rebuilds current switch state")
	ui.queue_free();await settle();await create_timer(.15).timeout
	var result={"checks":checks,"failures":failures}
	FileAccess.open("res://build/music-r4/music-settings-tests.json",FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	print("Music settings: ",JSON.stringify(result));quit(0 if failures.is_empty()else 1)
