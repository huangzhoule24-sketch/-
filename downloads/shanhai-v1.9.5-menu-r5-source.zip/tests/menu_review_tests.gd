extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Harness=preload("res://tests/culture_ui_tests.gd").Harness
const Language=preload("res://scripts/services/localization.gd")
var checks=0
var failures=[]
func expect(ok:bool,message:String):
	checks+=1
	if not ok:failures.append(message);push_error(message)
func _init():call_deferred("run")
func find(node:Node,id:String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var hit=find(child,id)
		if hit!=null:return hit
	return null
func texts(node:Node) -> String:
	var value=str(node.text) if node is Label or node is Button else ""
	for child in node.get_children():
		if not child.is_queued_for_deletion():value+="\n"+texts(child)
	return value
func settle():
	for i in range(3):await process_frame
func fresh():
	var model=Model.new(20261101);model.start_full()
	model.state.tutorial.finished=true
	model.state.tutorial.completed_steps=preload("res://scripts/core/tutorial_progress.gd").config().steps.map(func(step):return str(step.id))
	model.state.cash=5000.0
	model.full_rules.management.add_item("generic",100,300)
	return model
func run():
	var model=fresh();var c=model.full_rules.culture_experience
	expect(c.menu_review_catalog.entries.size()==25,"Every existing dish has a specific three-part review")
	var before=JSON.stringify(model.state);var rng=model._rng.state
	for menu in c.config.menus:
		var card=c.menu_review_card(str(menu.id))
		for field in ["name_meaning","plate_components","question"]:
			expect(not str(card[field].zh).is_empty() and not str(card[field].en).is_empty(),"Bilingual review field "+str(menu.id)+":"+field)
	expect(before==JSON.stringify(model.state) and rng==model._rng.state,"Reading all cards does not mutate campaign or RNG")
	expect(not c.can("culture_review_menu",{}).ok and not c.can("culture_review_menu",{"id":"missing"}).ok,"Confirmation requires the actual selected dish")
	var hidden=c.menu_review_card("baize_hidden_banquet")
	expect(not hidden.available and not str(hidden.plate_components.zh).contains("祝余"),"Hidden recipe ingredients are not revealed before discovery")
	expect(not c.can("culture_review_menu",{"id":"baize_hidden_banquet"}).ok,"An undiscovered recipe cannot be marked fully reviewed")
	model.state.culture_experience.menu_reviewed=true
	expect(c.reviewed_menu_count()==0,"The old global flag cannot fabricate 25 reviewed dishes")
	var cash=model.state.cash;var ingredients=model.state.ingredients;var unlocked=model.state.unlocked_dishes.duplicate();var ledger=model.state.ledger.duplicate(true)
	expect(model.full_rules.perform("culture_review_menu",{"id":"noodles"}).ok,"A real per-dish confirmation succeeds")
	expect(c.menu_review_status("noodles")=="checked" and c.menu_review_status("fried_rice")=="unreviewed","Confirmation affects only the selected dish")
	expect(model.state.cash==cash and model.state.ingredients==ingredients and model.state.unlocked_dishes==unlocked and model.state.ledger==ledger and model._rng.state==rng,"Reviewing does not spend ingredients, change prices, unlock recipes or draw RNG")
	var count=c.s().evidence.size();var record=c.s().menu_reviews.noodles.duplicate()
	model.full_rules.perform("culture_review_menu",{"id":"noodles"})
	expect(c.s().evidence.size()==count and c.s().menu_reviews.noodles==record,"Repeated confirmation is idempotent")
	var path="user://menu-review-test.json";expect(model.save_game(path),"Save the actual per-dish record")
	var loaded=fresh();expect(loaded.load_game(path) and loaded.full_rules.culture_experience.menu_review_status("noodles")=="checked","Per-dish confirmation survives real save/load")
	# Simulate an old save with only the unidentifiable global flag.
	var payload=JSON.parse_string(FileAccess.get_file_as_string(path));payload.state.culture_experience.erase("menu_reviews")
	FileAccess.open(path,FileAccess.WRITE).store_string(JSON.stringify(payload))
	expect(loaded.load_game(path) and loaded.full_rules.culture_experience.reviewed_menu_count()==0,"Old saves load without marking unrelated dishes reviewed")
	# A malformed new record is rejected without replacing the running campaign.
	payload.state.culture_experience.menu_reviews={"missing":{"signature":"a".repeat(64),"minute":360,"source":"menu"}}
	FileAccess.open(path,FileAccess.WRITE).store_string(JSON.stringify(payload))
	expect(not loaded.load_game(path),"Unknown dish records cannot enter a saved campaign")
	payload.state.culture_experience.menu_reviews={"noodles":{"signature":"broken","minute":360,"source":"menu"}}
	FileAccess.open(path,FileAccess.WRITE).store_string(JSON.stringify(payload))
	expect(not loaded.load_game(path),"Malformed review signatures are rejected")
	c.menu_review_catalog.entries.noodles.question.zh+=" 新用料待核对。"
	expect(c.menu_review_status("noodles")=="updated","Changed notes invalidate only their content signature")
	model.full_rules.perform("culture_review_menu",{"id":"noodles"})
	expect(c.menu_review_status("noodles")=="checked","Updated notes can be confirmed again")
	var price=model._dish("noodles").price;model._dish("noodles").price=price+1
	expect(c.menu_review_status("noodles")=="checked","Price changes do not erase ingredient knowledge")
	model.full_rules.management.config.recipes.noodles.generic+=.1
	expect(c.menu_review_status("noodles")=="updated","A changed actual ingredient recipe also invalidates the record")
	# A new campaign uses the real Lin encounter, not a booking completion command.
	model=fresh();c=model.full_rules.culture_experience;model.state.served=1;c.tick();model.full_rules.perform("culture_choose",{"id":"menu","choice":"accept"})
	model.full_rules.perform("culture_review_menu",{"id":"dijiang_dumplings"});model.full_rules.perform("culture_review_menu",{"id":"plum_juice"})
	expect(c.event("menu").node=="check" and c.s().booking.status=="held","Reading notes alone cannot fulfil or skip a reservation")
	model.full_rules.perform("culture_choose",{"id":"menu","choice":"verify"})
	expect(c.s().evidence.any(func(e):return str(e.get("kind",""))=="menu_notebook_used"),"Lin’s conversation consumes the actual two-dish notebook context")
	expect(c.s().booking.status=="held" and c.event("menu").node=="decision","Guest confirmation still needs an actual service or refund decision")
	# The real UI opens a separate page, preserves selected dish and uses fixed Back.
	var ui=Harness.new();root.add_child(ui);await settle();ui.localization=Language.new("user://menu-review-locale.cfg");ui.localization.language="en"
	ui.open_panel("更多");ui.open_panel("菜牌说明");await settle()
	find(ui,"culture:menu:review").pressed.emit();await settle()
	expect(ui.panel_name=="菜牌核对" and ui._panel_back.visible,"The menu button opens a real review page with fixed Back")
	var content=texts(ui.modal_body)
	for title in ["The story in the name","What goes into this dish","One more question before serving"]:expect(title in content,"Review page shows "+title)
	var money=ui.model.state.cash
	find(ui,"culture:review:confirm").pressed.emit();await settle()
	expect(ui.model.full_rules.culture_experience.menu_review_status("noodles")=="checked" and find(ui,"culture:review:confirm").disabled,"Actual confirm control records progress and shows completed state")
	expect(ui.model.state.cash==money,"UI confirmation carries no fee")
	find(ui,"culture:review:reading").pressed.emit();await settle();ui.return_from_culture();await settle()
	expect(ui.panel_name=="菜牌核对","Cultural reading returns to the same review page")
	ui.return_to_parent_panel();await settle()
	expect(ui.panel_name=="菜牌说明" and ui.cultural_ui.selected_dish=="noodles","Review Back returns to the same dish notes")
	ui.localization.language="zh";ui.open_panel("菜牌说明",false);await settle()
	expect("已核对" in find(ui,"culture:menu:review").text,"Reviewed state appears in Chinese too")
	ui.open_panel("菜牌核对");root.size=Vector2i(844,390);ui.queue_ui_layout();await settle()
	expect(ui.modal_window.get_global_rect().encloses(ui._panel_back.get_global_rect()),"Small landscape retains the fixed return button")
	ui.queue_free();await settle();await create_timer(.15).timeout
	var report={"checks":checks,"failures":failures};FileAccess.open("res://build/menu-r5/menu-review-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
	print("Menu review: ",JSON.stringify(report));quit(0 if failures.is_empty()else 1)
