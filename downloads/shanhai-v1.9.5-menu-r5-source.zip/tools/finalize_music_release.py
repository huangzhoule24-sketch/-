#!/usr/bin/env python3
"""Preserve real native, WebAudio, content and Windows evidence for music R4."""
from pathlib import Path
import json,re,shutil
from package_release import ROOT,game_source_fingerprint
B=ROOT/'build/music-r4';D=ROOT/'docs/validation-artifacts/music-r4'
def read(path):return json.loads(path.read_text())
def main():
 source=game_source_fingerprint();assert read(B/'tested-source.json')==source
 log=(B/'full-checks.log').read_text();passed=re.findall(r'^PASS (\w+):',log,re.M);failed=re.findall(r'^FAIL (\w+) ',log,re.M)
 assert len(passed)==54 and failed==['startup_tests']
 cleanup=(B/'startup-tests-final.log').read_text();assert '14; failures: []'in cleanup and 'ERROR:'not in cleanup
 groups=passed+['startup_tests'];assert len(set(groups))==55
 english=read(ROOT/'build/english-r2/localization-tests.json');assert english['checks']==4703 and english['failures']==0 and not english['missing']
 music=read(B/'music-settings-tests.json');assert music['checks']==32 and not music['failures']
 browser=read(B/'browser-final/report.json');assert browser['game_source']==source and not browser['errors']and len(browser['checks'])==13 and all(c['ok']for c in browser['checks'])
 assert browser['samples'][0]['peak']==0 and 0<browser['samples'][1]['peak']<.95 and browser['samples'][2]['peak']==0
 windows=read(B/'windows-verification.json');assert windows['game_source']==source and not windows['errors']
 track=read(ROOT/'docs/music-r4/track.json');loop=read(B/'loop-integrity.json');assert loop['clipped_samples']==0 and loop['boundary_jump']<.01
 assert abs(float(track['runtime_loudness']['input_i'])+23.5)<.2
 for platform in ['web','windows']:assert read(ROOT/f'build/full-{platform}/export-receipt.json')['game_source']==source
 preservation=read(B/'content-preservation.json');assert preservation['art_fonts_culture_balance_and_original_42_audio_unchanged']
 summary={'version':'SH-MUSIC-R4','validated_on':'2026-11-01','game_source':source,'native_group_count':55,'native_passed_first_run':54,'rechecked_group':'startup_tests','startup_fixture_fix':'Wait 150ms for mixer playback references after freeing the game; 14 checks and clean exit pass. No game-code change. Original failed cleanup log retained.','english_checks':4703,'audio_foundation_checks':134,'free_sfx_checks':176,'music_settings_checks':32,'startup_checks':14,'browser_actions':len(browser['actions']),'browser_checks':13,'browser_errors':[],'web_audio_samples':browser['samples'],'music_seconds':track['loop_seconds'],'music_lufs':float(track['runtime_loudness']['input_i']),'music_true_peak_dbtp':float(track['runtime_loudness']['input_tp']),'original_42_sfx_preserved':True,'windows_scope':'Actual Windows EXE via Wine/OpenGL/Dummy audio at 1024x768; no physical classroom sound-card or listening evaluation claimed.'}
 D.mkdir(parents=True,exist_ok=True)
 for name in ['full-checks.log','audio-tests.log','free-sfx-tests.log','music-settings-tests.log','startup-tests-final.log','windows-final.log','windows-final-1024x768.png','windows-verification.json','content-preservation.json','loop-integrity.json']:
  shutil.copyfile(B/name,D/(name[:-4]+'.txt'if name.endswith('.log')else name))
 shutil.copyfile(ROOT/'build/english-r2/localization-tests.json',D/'localization-tests.json')
 shutil.copyfile(B/'browser-final/report.json',D/'browser-report.json')
 for name in ['01-system-switches','02-sound-settings','03-mobile-switches','04-chinese-settings']:shutil.copyfile(B/f'browser-final/{name}.png',D/f'{name}.png')
 (D/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'docs/music-r4/validation.md').write_text(f'''# SH-MUSIC-R4 验证与交付\n\n运行指纹`{source['sha256']}`，{source['files']}项；Web/Windows回执一致。55组功能检查完成：首次完整运行54组通过，启动夹具立即退出时仍有音乐播放引用，增加150ms清理等待后启动14项和退出检查通过。没有改动游戏代码来掩盖此夹具退出问题；原始失败记录和专项复验均保留。\n\n英文4703项、音频基础134项、原音效176项、新音乐与开关32项通过。浏览器{len(browser['actions'])}次物理点击/滑杆操作、13结果检查，0错误，覆盖真实首单、系统与详细开关、小屏、总静音和刷新后的独立偏好。通过只读WebAudio分析节点测得：关闭音乐且暂停经营时峰值0；仅音乐峰值{browser['samples'][1]['peak']:.6f}，未接近削波；总静音峰值0。此次采样证明测试时段的真实输出，不声称验证所有硬件或所有可能叠音组合。\n\n循环87.2727秒，输出约-23.46 LUFS、-12.42dBTP，未出现满幅样本；端点跳变{loop['boundary_jump']:.6f}。原始MP3、处理脚本及参数保留。重要反馈压低音乐3dB的实际总线变化、脚步不触发反复压低、独立开关与音量保存、共用曲目跨场景续播，均有原生检查。\n\n原美术、字体、文化资料、经营数值及42音效逐字节未变。Windows EXE在Wine/OpenGL/1024×768兼容环境成功启动，使用Dummy音频；并未声称完成真实Windows声卡或教室扬声器听感验收。既有Direct3D11、OpenGL备用、30帧入口和旧档目录保留。\n\n证据见[summary.json](../validation-artifacts/music-r4/summary.json)及同目录原始日志、截图、音频输出统计。公开下载核验在发布之后追加。\n''')
 print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
