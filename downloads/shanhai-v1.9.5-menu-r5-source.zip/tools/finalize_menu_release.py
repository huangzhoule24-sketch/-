#!/usr/bin/env python3
"""Freeze evidence for the dish-specific menu review release."""
import json,re,shutil
from package_release import ROOT,game_source_fingerprint
B=ROOT/'build/menu-r5';D=ROOT/'docs/validation-artifacts/menu-r5'
def read(p):return json.loads(p.read_text())
def main():
 source=game_source_fingerprint();assert read(B/'tested-source.json')==source
 log=(B/'full-checks.log').read_text();groups=re.findall(r'^PASS (\w+):',log,re.M);assert len(groups)==56 and 'FAIL 'not in log
 menu=read(B/'menu-review-tests.json');assert menu['checks']==107 and not menu['failures']
 english=read(ROOT/'build/english-r2/localization-tests.json');assert english['checks']==4803 and english['failures']==0 and not english['missing']
 browser=read(B/'browser/report.json');assert browser['game_source']==source and len(browser['checks'])==14 and not browser['errors']and all(c['ok']for c in browser['checks'])
 windows=read(B/'windows-verification.json');assert windows['game_source']==source and not windows['errors']and windows['startup']['complete']
 preservation=read(B/'content-preservation.json');assert preservation['existing_art_music_sfx_fonts_culture_and_balance_unchanged']
 for platform in ['web','windows']:assert read(ROOT/f'build/full-{platform}/export-receipt.json')['game_source']==source
 summary={'version':'SH-MENU-R5','validated_on':'2026-11-01','game_source':source,'native_group_count':56,'menu_review_checks':107,'english_checks':4803,'browser_actions':len(browser['actions']),'browser_checks':14,'browser_errors':[],'dishes':25,'legacy_save_compatible':True,'content_preserved':True,'windows_scope':'Wine/OpenGL/Dummy at 1024x768; complete welcome startup, no script/runtime errors. Not physical classroom hardware.','windows_shutdown_diagnostics':windows.get('shutdown_diagnostics',[])}
 D.mkdir(parents=True,exist_ok=True)
 for name in ['full-checks.log','culture-core-tests.log','culture-ui-tests.log','menu-review-tests.log','windows-final.log','windows-final-1024x768.png','windows-verification.json','content-preservation.json']:
  shutil.copyfile(B/name,D/(name[:-4]+'.txt'if name.endswith('.log')else name))
 shutil.copyfile(ROOT/'build/english-r2/localization-tests.json',D/'localization-tests.json');shutil.copyfile(B/'menu-review-tests.json',D/'menu-review-tests.json');shutil.copyfile(B/'browser/report.json',D/'browser-report.json')
 for name in ['01-review-english','02-reviewed','03-lin-notebook','04-mobile-review','05-chinese-reviewed']:shutil.copyfile(B/f'browser/{name}.png',D/f'{name}.png')
 (D/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'docs/menu-r5/validation.md').write_text(f'''# 菜牌核对版验证 · SH-MENU-R5\n\n运行指纹`{source['sha256']}`，{source['files']}项；完整检查与Web/Windows导出保持同一运行源。56组原生回归通过，新增核对107项、英文4803项。\n\n原生检查覆盖25道菜的三栏双语字段、隐藏配方遮蔽与提示、按菜品记录、幂等确认、存档加载、旧总标记不伪造全量进度、损坏记录拒绝、内容/配方变更后重新核对、改价不擦掉记录、Lin实际对话引用、返回原菜品/读本与小屏固定返回。使用夹具构造部分条件，不冒称自然通关。\n\n实际浏览器{len(browser['actions'])}次物理点击/滚动、14结果检查、0错误：从真实首单完成教学，打开原菜牌按钮、看到三栏、确认单菜、阅读文化故事并返回、核查另一道菜未被误标、未发现配方有提示、由Lin来访跳转两道菜再返回、实际使用菜牌本、退款、844×390返回、保存刷新并切中文核对原进度。阅读未消耗现金食材、未冒充订单完成。\n\n原美术、字体、文化读本、经营数值、音乐、音效及音频开关保留。Windows EXE在Wine/OpenGL/Dummy兼容环境1024×768显示完整欢迎页，无脚本或运行阶段错误。自动quit-after退出保留了一个音乐播放引用的退出诊断；原日志如实保留，不冒称干净退出或Windows实体设备、声卡、课堂触摸已验收。\n\n说明见[guide.md](guide.md)，证据见[summary.json](../validation-artifacts/menu-r5/summary.json)与同目录原始日志/截图。公开下载校验在发布后另行追加，不重写已核验归档。\n''')
 print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
