#!/usr/bin/env python3
"""Rebuild the user-supplied background loop with measured, gentle EQ.
Requires ffmpeg and numpy; preserves the uploaded MP3 for future re-editing.
"""
from pathlib import Path
import hashlib,json,subprocess,tempfile
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'art-source/audio/youjian-major-flute-balanced-original.mp3'
OUTPUT=ROOT/'assets/audio/music/youjian_major_flute.ogg'
REPORT=ROOT/'docs/music-r4/track.json'
EQ='highpass=f=40,bass=g=0.8:f=160:w=0.7,equalizer=f=700:t=q:w=0.8:g=-1.2,treble=g=-0.5:f=4500:w=0.7'
def probe(path):
 p=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af','loudnorm=I=-23.5:LRA=11:TP=-2:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 return json.loads(p.stderr[p.stderr.rindex('{'):p.stderr.rindex('}')+1])
def main():
 OUTPUT.parent.mkdir(parents=True,exist_ok=True);REPORT.parent.mkdir(parents=True,exist_ok=True)
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(SOURCE),'-f','f32le','-ar','48000','-ac','2','-'])
 pcm=np.frombuffer(raw,dtype='<f4').reshape(-1,2).copy();rate=48000
 # 32 bars, 4/4, 88 BPM. The upload contains the complete piece plus 4s tail.
 samples=round(32*4*60/88*rate);loop=pcm[:samples].copy()
 tail=pcm[samples:samples+round(.5*rate)]
 if len(tail):
  envelope=np.cos(np.linspace(0,np.pi/2,len(tail)))**2
  loop[:len(tail)]+=tail*envelope[:,None]
 # Very short edge ramps remove waveform discontinuities, not musical beats.
 ramp=round(.006*rate);loop[:ramp]*=np.linspace(0,1,ramp)[:,None];loop[-ramp:]*=np.linspace(1,0,ramp)[:,None]
 with tempfile.TemporaryDirectory(prefix='shanhai-music-')as td:
  td=Path(td);wav=td/'equalised.wav'
  subprocess.run(['ffmpeg','-v','error','-y','-f','f32le','-ar',str(rate),'-ac','2','-i','-','-af',EQ,'-c:a','pcm_f32le',str(wav)],input=loop.astype('<f4').tobytes(),check=True)
  measured=probe(wav);gain=-23.5-float(measured['input_i'])
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),'-af',f'volume={gain:.4f}dB','-c:a','libvorbis','-q:a','5','-ar','48000','-metadata','title=有间晨炊·游戏背景循环版',str(OUTPUT)],check=True)
 result=probe(OUTPUT)
 proof={'source':'User-uploaded downloads_youjian-major-flute-balanced.mp3','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_bytes':SOURCE.stat().st_size,'original_decoded_seconds':len(pcm)/rate,'runtime_file':OUTPUT.relative_to(ROOT).as_posix(),'runtime_sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),'runtime_bytes':OUTPUT.stat().st_size,'loop_seconds':samples/rate,'loop_basis':'32 bars in 4/4 at 88 BPM; tail wrapped into intro; 6ms edge ramps','eq':EQ,'static_gain_db':round(gain,4),'source_loudness':probe(SOURCE),'runtime_loudness':result,'mix':'Music cue -2dB; Music bus user level; important SFX duck music 3dB, 60ms attack / 220ms hold / 350ms release. No routine-footstep ducking.'}
 REPORT.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps(proof,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
