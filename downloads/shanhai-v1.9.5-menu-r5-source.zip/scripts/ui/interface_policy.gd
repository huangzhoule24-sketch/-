extends RefCounted
## Stage visibility is shared by the bottom bar, More and task suggestions.
static var _settings: Dictionary = {}
static func settings() -> Dictionary:
	if _settings.is_empty():
		var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://config/experience.json"))
		if parsed is Dictionary: _settings = parsed
	return _settings
static func destination(name: String) -> String:
	return str(settings().get("routes",{}).get(name,name))
static func navigation(stage: int) -> Array:
	return settings().get("navigation",{}).get(str(clampi(stage,0,4)),[]).duplicate()
static func more_entries(stage: int) -> Array:
	var primary = navigation(stage).map(func(name):return destination(str(name)))
	var result: Array = []
	for entry in settings().get("more",[]):
		if stage < int(entry.stage) or stage > int(entry.get("last_stage",4)): continue
		if str(entry.panel) in primary: continue
		var visible = entry.duplicate(true)
		if stage >= 1 and str(entry.panel) == "员工培养": visible.label = "培养、技能与排班"
		result.append(visible)
	return result
static func branch(name: String) -> bool:
	if name in ["声音设置","菜牌核对"]: return true
	for entry in settings().get("more",[]):
		if str(entry.panel) == name: return true
	return name in ["员工详情","来客往事","现场来客","经营状态","特殊顾客图鉴","事件结果","任务","菜单","配方研发","宣传","连锁经营","会员外卖","三界集团","事件","采购设置","资金流水","贷款","财务账本","待办汇总"]
static func minimum_stage(name: String) -> int:
	name = destination(name)
	if name in ["研发","配方研发","菜单定价","装修","员工技能"]: return 1
	if name in ["会员外卖","会员计划","外卖服务","羁绊图鉴","相生相克"]: return 2
	if name in ["连锁经营","分店管理","中央厨房","供应链","山海探索","封锁对抗"]: return 3
	if name in ["三界集团","厨神大赛","神兽觉醒","世界排行榜"]: return 4
	return 0
