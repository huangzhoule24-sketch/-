extends Control

const GameModel = preload("res://scripts/core/game_model.gd")
const RestaurantView = preload("res://scripts/ui/restaurant_view.gd")
const StoryPanel = preload("res://scripts/ui/story_panel.gd")
const FullPanels = preload("res://scripts/ui/full_panels.gd")
const CulturePanel = preload("res://scripts/ui/culture_panel.gd")
const TutorialOverlay = preload("res://scripts/ui/tutorial_overlay.gd")
const AssetCatalog = preload("res://scripts/services/asset_catalog.gd")
const AudioSystem = preload("res://scripts/services/audio_system.gd")
const GameAudioBridge = preload("res://scripts/services/game_audio_bridge.gd")
const AudioPanel = preload("res://scripts/ui/audio_panel.gd")
const RarityDisplay = preload("res://scripts/ui/rarity_display.gd")
const ActionNotifications = preload("res://scripts/ui/action_notifications.gd")
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const Revision18UI = preload("res://scripts/ui/revision18_ui.gd")
const Revision171Panels = preload("res://scripts/ui/revision171_panels.gd")
const V15Panels = preload("res://scripts/ui/v15_panels.gd")
const Policy = preload("res://scripts/ui/interface_policy.gd")
const DecorationSession = preload("res://scripts/ui/decoration_session.gd")
const StartupMetrics=preload("res://scripts/services/startup_metrics.gd")
const FONT = preload("res://assets/fonts/ReadableUI.tres")
const GREEN = Color("5A7A4A")
const INK = Color("3A5A63")
const MUTED = Color("7A6F63")
const PAPER = Color("F5F0E6")
const BORDER = Color("e4e6dc")
const SAVE_PATH = "user://campaign_savegame.json"

var model
var assets
var audio
var audio_bridge
var audio_panel
var full_panels
var culture_panel
var localization
var cultural_ui
var _locale_clock=0.0
var _culture_return: Dictionary = {}
var _more_history: Array[Dictionary] = []
var story_panel
var tutorial_overlay
var _file_callback
var _art_import_result: Dictionary = {}
var _art_controls: Array[Dictionary] = []
var _import_path: LineEdit
var _art_culture_slots: OptionButton
var money_label: Label
var gem_label: Label
var reputation_label: Label
var clock_label: Label
var period_label: Label
var guest_label: Label
var revenue_label: Label
var served_label: Label
var stock_label: Label
var debt_label: Label
var log_label: Label
var goal_bar: ProgressBar
var map_view: Control
var staff_status: VBoxContainer
var pause_button: Button
var speed_buttons: Array[Button] = []
var sidebar: VBoxContainer
var toast_label: RichTextLabel
var toast_timer: = 0.0
var overlay: Control
var modal_body: VBoxContainer
var panel_name: = ""
var catalog_tab: = "菜品"
var panel_refresh: = 0.0
var quest_title: Label
var quest_description: Label
var quest_reward: Label
var quest_button: Button
var team_summary: Label
var mode_label: Label
var menu_label: Label
var stage_label: Label
var event_button: Button
var placement_label: Label
var current_quest: Dictionary = {}
var _panel_resume: = false
var _placement_resume: = false
var _event_popup_key: = ""
var _ending_shown: = false
var _resumed: = false
var _qa_enabled: = false
var _qa_elapsed: = 0.0
var _qa_buttons: Array[Button] = []
var _recruit_result: Dictionary = {}
var action_notifications
var revision_ui
var bottom_ui
var live_status: Button
var training_status: Button
var guest_status: Button
var building_status: Button
var _requirement_dialog: AcceptDialog
var _action_dialog: ConfirmationDialog
var v15_panels
var todo_button: Button
var todo_anchor: HBoxContainer
var _notice_queue: Array[String] = []
var _toast_source=""
var _toast_language=""
var _notice_clock=0.0
var _builder_dialog: ConfirmationDialog
var _notice_last: Dictionary={}
var _cash_float_last: Dictionary={}
var _cash_flow_seen: int = -1
var _cash_floats: Array[Dictionary] = []
var _finance_bill_seen: int = -1
var navigation_buttons: Dictionary = {}
var drawer_slot: Control
var modal_window: PanelContainer
var _drawer_tween: Tween
var compact_layout: bool = false
var landscape_required: bool = false
var _layout_controls: Dictionary = {}
var _layout_size: Vector2i = Vector2i.ZERO
var _layout_render_size: Vector2i = Vector2i.ZERO
var _layout_queued: bool = false
var _orientation_hint: PanelContainer
var _welcome_action: Button
var _culture_back: Button
var _panel_back: Button
var decoration_session
var decoration_footer: HBoxContainer
var _move_index = -1
var _decoration_dialog: ConfirmationDialog
var _qa_placement_signature = 0
var _qa_placement_cells: Array = []

func queue_ui_layout() -> void:
	# Window emits size_changed while recalculating its stretch transform. Apply
	# layout after that calculation, so it cannot overwrite the new aspect ratio.
	if _layout_queued: return
	_layout_queued = true
	call_deferred("update_ui_layout")

func update_ui_layout() -> void:
	_layout_queued = false
	if _layout_controls.is_empty(): return
	var render_size: Vector2i = get_window().size
	var physical: Vector2i = render_size
	var touch_layout: bool = OS.has_feature("mobile")
	if OS.has_feature("web"):
		# Godot's window size uses backing pixels on high-DPI browsers. Interface
		# dimensions use CSS pixels so one 44px touch target stays 44px on screen.
		var css_size = JSON.parse_string(str(JavaScriptBridge.eval("JSON.stringify([document.getElementById('canvas').clientWidth, document.getElementById('canvas').clientHeight, window.matchMedia('(pointer: coarse)').matches])", true)))
		if css_size is Array and css_size.size() >= 2 and float(css_size[0]) > 0 and float(css_size[1]) > 0:
			physical = Vector2i(int(css_size[0]), int(css_size[1]))
			if css_size.size() > 2: touch_layout = bool(css_size[2])
	if physical == _layout_size and render_size == _layout_render_size: return
	_layout_size = physical
	_layout_render_size = render_size
	compact_layout = touch_layout or physical.x < 1100 or physical.y < 650
	landscape_required = compact_layout and physical.y > physical.x
	# Use the actual landscape viewport on small screens, so 44px controls remain
	# touch targets instead of scaling the 1440px desktop interface down to fit.
	get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_IGNORE if compact_layout else Window.CONTENT_SCALE_ASPECT_KEEP
	get_window().content_scale_size = physical if compact_layout else Vector2i(1440, 900)
	var margin: MarginContainer = _layout_controls.margin
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 8 if compact_layout else (28 if side in ["left", "right"] else 20))
	_layout_controls.root.add_theme_constant_override("separation", 6 if compact_layout else 18)
	_layout_controls.header.add_theme_constant_override("separation", 8 if compact_layout else 24)
	_layout_controls.toolbar.add_theme_constant_override("separation", 8 if compact_layout else 12)
	_layout_controls.content.add_theme_constant_override("separation", 8 if compact_layout else 18)
	_layout_controls.brand_icon.custom_minimum_size = Vector2(32, 32) if compact_layout else Vector2(60, 60)
	_layout_controls.brand_title.add_theme_font_size_override("font_size", 20 if compact_layout else 27)
	_layout_controls.brand_subtitle.visible = not compact_layout
	for value in [money_label, gem_label, reputation_label]:
		value.add_theme_font_size_override("font_size", 20 if compact_layout else 24)
		var pill: PanelContainer = value.get_parent().get_parent()
		pill.custom_minimum_size.x = 105 if compact_layout else 130
		var pill_style = style(Color("faf9f3"), 12)
		pill_style.content_margin_left = 10 if compact_layout else 20
		pill_style.content_margin_right = 10 if compact_layout else 20
		pill_style.content_margin_top = 3 if compact_layout else 9
		pill_style.content_margin_bottom = 3 if compact_layout else 9
		pill.add_theme_stylebox_override("panel", pill_style)
	period_label.visible = not compact_layout
	_layout_controls.time_legend.visible = not compact_layout
	clock_label.add_theme_font_size_override("font_size", 16 if compact_layout else 20)
	guest_label.visible = not compact_layout
	menu_label.visible = not compact_layout
	stage_label.visible = not compact_layout
	map_view.custom_minimum_size = Vector2(160, 90) if compact_layout else Vector2(400, 300)
	_layout_controls.restaurant.add_theme_constant_override("separation", 4 if compact_layout else 12)
	var restaurant_style = style()
	if compact_layout:
		restaurant_style.content_margin_left = 10
		restaurant_style.content_margin_right = 10
		restaurant_style.content_margin_top = 6
		restaurant_style.content_margin_bottom = 6
	_layout_controls.restaurant_card.add_theme_stylebox_override("panel", restaurant_style)
	var bottom_style = style()
	if compact_layout:
		bottom_style.content_margin_left = 8
		bottom_style.content_margin_right = 8
		bottom_style.content_margin_top = 6
		bottom_style.content_margin_bottom = 6
	_layout_controls.bottom.add_theme_stylebox_override("panel", bottom_style)
	_orientation_hint.visible = landscape_required
	toast_label.offset_left = -minf(220,physical.x*.5-12)
	toast_label.offset_right = -toast_label.offset_left
	toast_label.offset_top = 106 if compact_layout else 122
	if bottom_ui!=null:bottom_ui.layout()
	configure_panel_layout(panel_name)
	if tutorial_overlay != null and tutorial_overlay.has_method("update_layout"): tutorial_overlay.update_layout()

func _ready() -> void :
	StartupMetrics.mark("game_initialization_started")
	var game_theme: = Theme.new()
	game_theme.default_font = FONT
	game_theme.default_font_size = 16
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	theme = game_theme
	localization = preload("res://scripts/services/localization.gd").new()
	model = GameModel.new()
	StartupMetrics.mark("model_created")
	assets = AssetCatalog.new()
	StartupMetrics.mark("art_catalog_ready")
	setup_audio()
	if FileAccess.file_exists(SAVE_PATH):
		_resumed = model.load_game(SAVE_PATH)
	if not _resumed:
		model.start_full()
	_ending_shown = _resumed and bool(model.state.completed)
	model.set_paused(true)
	build_interface()
	full_panels = FullPanels.new(self)
	story_panel = StoryPanel.new(self)
	revision_ui = Revision171Panels.new(self)
	tutorial_overlay = TutorialOverlay.new()
	add_child(tutorial_overlay)
	tutorial_overlay.setup(self)
	assets.changed.connect(func():
		_refresh_art_controls()
		map_view.queue_redraw()
		if not panel_name.is_empty(): open_panel(panel_name))
	model.changed.connect(refresh)
	model.notice.connect(show_notice)
	model.autosave_requested.connect( func(): model.save_game(SAVE_PATH))
	if OS.has_feature("web"):
		_qa_enabled = bool(JavaScriptBridge.eval("new URLSearchParams(location.search).get('qa') === '1'", true))
	refresh()
	open_panel("欢迎")
	get_window().title="Shanhai Inn" if localization!=null and localization.language=="en" else "山海食肆物语"
	get_tree().auto_accept_quit = false
	_record_startup.call_deferred()

func _record_startup():
	await get_tree().process_frame
	await get_tree().process_frame
	if not is_queued_for_deletion():StartupMetrics.finish()

func setup_audio():
	if audio != null: return
	audio = AudioSystem.new()
	add_child(audio)
	audio_bridge = GameAudioBridge.new(audio)
	audio_panel = AudioPanel.new(self)

func _notification(what: int) -> void :
	if what == NOTIFICATION_WM_CLOSE_REQUEST and model != null:
		if decoration_active():
			request_decoration_exit(func(): model.save_game(SAVE_PATH);get_tree().quit())
			return
		model.save_game(SAVE_PATH)
		get_tree().quit()

func _process(delta: float) -> void :
	if model == null:
		return
	if not decoration_active(): model.advance_real(delta)
	if audio_bridge != null: audio_bridge.update(delta,model,map_view._actors,panel_name)
	assets.developer_mode = bool(model.state.get("developer_mode", false))
	assets.poll(delta)
	if not decoration_active():
		if tutorial_overlay != null: tutorial_overlay.poll(delta)
		revision_ui.poll(delta)
		_poll_finance_ui(delta)
	_notice_clock+=maxf(0,delta)
	toast_timer -= delta
	if toast_label != null:
		toast_label.visible = toast_timer > 0
		if toast_timer <= 0 and not _notice_queue.is_empty():
			var message=_notice_queue.pop_front()
			_set_toast_text(message)
			toast_label.size.y=0
			toast_timer = notice_duration(message)
			toast_label.visible = true
	panel_refresh += delta
	if panel_refresh >= 1.0:
		panel_refresh = 0

		if panel_name == "员工":
			refresh_employee_values()
		if panel_name == "研发":
			refresh_research_values()
		var pending: Dictionary = model.pending_event()
		if not pending.is_empty() and panel_name.is_empty() and map_view.placement_id.is_empty():
			var key: = str(pending.id) + ":" + str(pending.get("serial", pending.get("queued_minute", 0)))
			if key != _event_popup_key:
				_event_popup_key = key
				open_panel("事件")
		if bool(model.state.completed) and not _ending_shown and panel_name.is_empty():
			_ending_shown = true
			open_panel("开张庆典")
	# Live status and the guide assign their latest values above. Localize afterwards
	# every frame so those assignments cannot flash back to Chinese between polls.
	if localization!=null and _toast_language!=localization.language:_set_toast_text(_toast_source)
	if localization!=null and localization.language=="en":localization.apply_tree(self)
	if _qa_enabled:
		_qa_elapsed += delta
		if _qa_elapsed >= 0.2:
			_qa_elapsed = 0
			publish_qa_state()

func _input(event: InputEvent) -> void :
	if is_instance_valid(_decoration_dialog) and _decoration_dialog.visible: return
	if decoration_active():
		var point = Vector2(INF, INF)
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT: point = event.position
		elif event is InputEventScreenTouch and event.pressed: point = event.position
		if point != Vector2(INF, INF) and not modal_window.get_global_rect().has_point(point) and not map_view.get_global_rect().has_point(point):
			var on_button = false
			for control in _qa_buttons:
				if is_instance_valid(control) and not control.is_queued_for_deletion() and control.is_visible_in_tree() and control.get_global_rect().has_point(point): on_button = true;break
			if not on_button: close_panel()
	if event.is_action_pressed("ui_cancel"):
		if not map_view.placement_id.is_empty():
			cancel_placement()
		else:
			close_panel()
		get_viewport().set_input_as_handled()
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_SPACE:
		toggle_pause()
		get_viewport().set_input_as_handled()

func style(color: Color = PAPER, radius: int = 16, border: Color = BORDER) -> StyleBoxFlat:
	var s: = StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(0)
	s.border_color = border
	s.set_border_width_all(2)
	s.shadow_color=Color("6b7059",0.28)
	s.shadow_size=3
	s.shadow_offset=Vector2(3,3)
	s.content_margin_left = 20
	s.content_margin_right = 20
	s.content_margin_top = 12
	s.content_margin_bottom = 12
	return s

func label(text: String, font_size: int = 16, color: Color = INK) -> Label:
	var node: = Label.new()
	node.text = localization.translate(text) if localization!=null else text
	node.set_meta("l10n_source",text)
	node.set_meta("l10n_last",node.text)
	node.add_theme_font_size_override("font_size", font_size)
	node.add_theme_color_override("font_color", color)
	return node

func button(text: String, action: Callable, primary: bool = false, qa_id: String = "") -> Button:
	var node: = Button.new()
	node.text = localization.translate(text) if localization!=null else text
	node.set_meta("l10n_source",text)
	node.set_meta("l10n_last",node.text)
	node.custom_minimum_size.y = 44
	node.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var normal: = style(GREEN if primary else Color("f1f3eb"), 10, GREEN if primary else BORDER)
	normal.content_margin_top = 8
	normal.content_margin_bottom = 8
	normal.content_margin_left = 16
	normal.content_margin_right = 16
	node.add_theme_stylebox_override("normal", normal)
	node.add_theme_stylebox_override("hover", style(Color("568e7e") if primary else Color("e4ebdf"), 10))
	node.add_theme_stylebox_override("pressed", style(Color("356354") if primary else Color("d5e1d0"), 10))
	node.add_theme_stylebox_override("focus", style(Color.TRANSPARENT, 10, Color("b79662")))
	node.add_theme_color_override("font_color", Color.WHITE if primary else INK)
	node.add_theme_color_override("font_hover_color", Color.WHITE if primary else INK)
	node.add_theme_color_override("font_pressed_color", Color.WHITE if primary else INK)
	if assets!=null and assets.has_image("UI/button_primary"):
		for state_name in ["normal","hover","pressed","disabled"]:
			var skin=pixel_skin("UI/button_primary" if primary else "UI/button_secondary",8)
			skin.modulate_color=Color(1.1,1.1,1.1) if state_name=="hover" else Color(.82,.82,.82) if state_name=="pressed" else Color(1,1,1,.55) if state_name=="disabled" else Color.WHITE
			node.add_theme_stylebox_override(state_name,skin)
		node.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	node.pressed.connect(func():
		if audio != null: audio.unlock()
		if decoration_active() and qa_id.begins_with("time:"):
			show_notice("请先完成装修，或确认放弃本次调整。")
			return
		if not guide_button_allowed(qa_id):
			show_notice("请先完成白泽当前教学；阶段功能可稍后继续。")
			return
		if audio != null: audio.play_cue("ui.back" if qa_id in ["panel:close","panel:back","culture:back"] else "ui.click")
		action.call())
	if not qa_id.is_empty(): node.set_meta("qa_id", qa_id)
	_qa_buttons.append(node)
	return node

func open_menu_explanation(id: String) -> void:
	if cultural_ui==null:cultural_ui=load("res://scripts/ui/cultural_experience_panel.gd").new(self)
	cultural_ui.selected_dish=id
	open_panel("菜牌说明")

func row(spacing: int = 12) -> HBoxContainer:
	var node: = HBoxContainer.new()
	node.add_theme_constant_override("separation", spacing)
	return node

func column(spacing: int = 12) -> VBoxContainer:
	var node: = VBoxContainer.new()
	node.add_theme_constant_override("separation", spacing)
	return node

func expand(node: Control) -> Control:
	node.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return node

func card() -> PanelContainer:
	var node: = PanelContainer.new()
	node.add_theme_stylebox_override("panel", style())
	if assets!=null and assets.has_image("UI/panel_employee"):
		var skin=StyleBoxTexture.new();skin.texture=assets.get_texture("UI/panel_employee");skin.set_content_margin_all(12);skin.texture_margin_left=12;skin.texture_margin_right=12;skin.texture_margin_top=12;skin.texture_margin_bottom=12;node.add_theme_stylebox_override("panel",skin)
	return node

func build_interface() -> void :
	var background=preload("res://scripts/ui/pixel_backdrop.gd").new()
	add_child(background)
	var margin: = MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28 if side in ["left", "right"] else 20)
	add_child(margin)
	var root: = column(18)
	margin.add_child(root)
	var header: = row(24)
	root.add_child(header)
	var brand: = row(14)
	var icon: = TextureRect.new()
	icon.texture = assets.get_texture("UI/logo")
	_art_controls.append({"node":weakref(icon),"id":"UI/logo","type":"texture"})
	icon.custom_minimum_size = Vector2(60, 60)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	brand.add_child(icon)
	var titles: = column(0)
	brand.add_child(titles)
	var brand_title = label("山海食肆物语", 27)
	var brand_subtitle = label("大荒市 · 有间小馆 / 三界食肆", 14, MUTED)
	titles.add_child(brand_title)
	titles.add_child(brand_subtitle)
	header.add_child(expand(brand))
	money_label = resource_pill(header, "钞票", Color("b18a47"))
	gem_label = resource_pill(header, "灵石", Color("9583ae"))
	reputation_label = resource_pill(header, "声望", Color("7192a4"))
	var toolbar: = row(12)
	root.add_child(toolbar)
	clock_label = label("", 20)
	toolbar.add_child(clock_label)
	period_label = label("", 14, GREEN)
	toolbar.add_child(expand(period_label))
	event_button = button("事件待处理", func(): open_panel("事件"), true, "event:open")
	toolbar.add_child(event_button)
	todo_anchor = row(0)
	toolbar.add_child(todo_anchor)
	todo_button = button("待办",open_priority_todo,false,"todo:primary")
	todo_button.custom_minimum_size.x = 210
	todo_button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	todo_button.clip_text = true
	todo_anchor.add_child(todo_button)
	var todo_expand = button("▾",func(): open_panel("待办汇总"),false,"todo:summary")
	todo_expand.add_theme_font_override("font",preload("res://assets/fonts/DejaVuSans.ttf"))
	todo_expand.tooltip_text = "展开全部待办"
	todo_expand.custom_minimum_size.x = 44
	todo_anchor.add_child(todo_expand)
	var time_legend = label("时间", 13, MUTED)
	toolbar.add_child(time_legend)
	pause_button = button("暂停", toggle_pause, false, "time:pause")
	toolbar.add_child(pause_button)
	for speed in range(1, 5):
		var value: = speed
		var b: = button("%d×" % speed, func(): model.set_speed(value);model.set_paused(false);_panel_resume = true, false, "time:%d" % speed)
		b.custom_minimum_size.x = 50
		toolbar.add_child(b)
		speed_buttons.append(b)
	var status_row = row(6)
	root.add_child(status_row)
	live_status = button("经营状态",func(): open_panel("经营状态"),false,"status:live")
	live_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	live_status.clip_text = true
	live_status.add_theme_font_size_override("font_size",12)
	status_row.add_child(live_status)
	training_status = button("培训×0",func(): open_panel("员工"),false,"status:training")
	building_status = button("装修×0",func(): open_panel("经营状态"),false,"status:building")
	guest_status=button("来客×0",func():open_panel("现场来客"),false,"status:guests")
	for status_button in [training_status,building_status,guest_status]:
		status_button.expand_icon = true
		status_button.add_theme_constant_override("icon_max_width",24)
		status_button.add_theme_font_size_override("font_size",12)
		status_row.add_child(status_button)
	var content: = row(18)
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(content)
	var restaurant_card: = card()
	content.add_child(expand(restaurant_card))
	var restaurant: = column(12)
	restaurant_card.add_child(restaurant)
	var map_header: = row()
	restaurant.add_child(map_header)
	map_header.add_child(expand(label("有间小馆", 22)))
	guest_label = label("", 14, MUTED)
	map_header.add_child(guest_label)
	menu_label = label("", 14, Color("a08053"))
	menu_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	restaurant.add_child(menu_label)
	map_view = RestaurantView.new()
	map_view.localization=localization
	map_view.set_meta("presentation_host",weakref(self))
	map_view.model = model
	map_view.assets = assets
	map_view.font = FONT
	map_view.custom_minimum_size = Vector2(400, 300)
	map_view.size_flags_vertical = Control.SIZE_EXPAND_FILL
	restaurant.add_child(map_view)
	map_view.placement_requested.connect(place_decoration)
	map_view.placement_cancelled.connect(cancel_placement)
	var map_footer: = row(16)
	restaurant.add_child(map_footer)
	placement_label = label("", 13, MUTED)
	placement_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	map_footer.add_child(expand(placement_label))
	stage_label = label("", 13, GREEN)
	map_footer.add_child(stage_label)
	sidebar = column(14)
	sidebar.custom_minimum_size.x = 292
	content.add_child(sidebar)
	build_sidebar()
	drawer_slot = Control.new()
	drawer_slot.resized.connect(_fit_drawer)
	drawer_slot.custom_minimum_size.x = 340
	drawer_slot.size_flags_vertical = Control.SIZE_EXPAND_FILL
	drawer_slot.clip_contents = true
	drawer_slot.visible = false
	content.add_child(drawer_slot)
	var bottom: = card()
	root.add_child(bottom)
	var navigation: = row(10)
	bottom.add_child(navigation)
	for entry in ["员工", "图鉴", "系统", "装修", "研发", "宣传", "招聘", "营销", "分店", "中央厨房", "探索"]:
		var name: String = entry
		var b: = button(name, func(): toggle_panel(name), false, "nav:" + name)
		var art_id = {"员工":"btn_employee", "图鉴":"btn_encyclopedia", "系统":"btn_system", "装修":"btn_decoration", "研发":"btn_research","宣传":"btn_promotion","营销":"btn_promotion","招聘":"btn_recruit","分店":"btn_branch","中央厨房":"btn_central","探索":"btn_exploration"}.get(name, "")
		_art_controls.append({"node":weakref(b),"id":"UI/" + art_id,"type":"button"})
		if assets.has_image("UI/" + art_id):
			b.icon = assets.get_texture("UI/" + art_id)
			b.expand_icon = true
			b.add_theme_constant_override("icon_max_width", 28)
		b.custom_minimum_size.y = 45
		navigation.add_child(expand(b))
		navigation_buttons[name] = b
	var more_button: Button = button("···", func(): toggle_panel("更多"), false, "nav:更多")
	more_button.custom_minimum_size = Vector2(48,44)
	more_button.tooltip_text = "更多：经营工具、图鉴、账单与设置"
	_art_controls.append({"node":weakref(more_button),"id":"UI/btn_more","type":"button"})
	navigation.add_child(more_button)
	navigation_buttons["更多"] = more_button
	_refresh_art_controls()

	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.offset_top = 150
	overlay.offset_bottom = -115
	overlay.visible = false
	add_child(overlay)
	var scrim: = ColorRect.new()
	scrim.color = Color(0.14, 0.22, 0.19, 0.2)
	scrim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scrim.gui_input.connect( func(event):
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			close_panel())
	overlay.add_child(scrim)
	var modal: = card()
	modal_window = modal
	modal.name = "Modal"
	modal.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	modal.offset_left = -375
	modal.offset_right = 375
	modal.offset_top = -240
	modal.offset_bottom = 240
	overlay.add_child(modal)
	var modal_column: = column(10)
	modal.add_child(modal_column)
	var modal_header: = row()
	modal_header.name = "Header"
	modal_column.add_child(modal_header)
	var heading: = label("", 23)
	heading.name = "Title"
	modal_header.add_child(expand(heading))
	_culture_back = button("返回", return_from_culture, false, "culture:back")
	_culture_back.visible = false
	modal_header.add_child(_culture_back)
	_panel_back = button("返回", return_to_parent_panel, false, "panel:back")
	_panel_back.visible = false
	modal_header.add_child(_panel_back)
	_welcome_action = button("开始经营", func(): close_panel(false); model.set_paused(false), true)
	_welcome_action.visible = false
	modal_header.add_child(_welcome_action)
	modal_header.add_child(button("关闭 ×", close_panel, false, "panel:close"))
	var scroll: = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	modal_column.add_child(scroll)
	modal_body = column(12)
	modal_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(modal_body)
	decoration_footer = row(6)
	decoration_footer.visible = false
	modal_column.add_child(decoration_footer)
	for entry in [["完成装修","decor:finish",func(): finish_decoration(true)],["撤销","decor:undo",undo_decoration],["取消预览","decor:cancel",cancel_placement]]:
		var control = button(entry[0],entry[2],entry[1] == "decor:finish",entry[1])
		var compact_style = style(GREEN if entry[1] == "decor:finish" else Color("f1f3eb"),8)
		compact_style.content_margin_left = 8
		compact_style.content_margin_right = 8
		control.add_theme_stylebox_override("normal",compact_style)
		decoration_footer.add_child(expand(control))
	toast_label = RichTextLabel.new()
	toast_label.bbcode_enabled = true
	toast_label.fit_content = true
	toast_label.scroll_active = false
	toast_label.add_theme_font_size_override("normal_font_size", 13)
	toast_label.add_theme_color_override("default_color", Color.WHITE)
	var notice_style=small_notice_style();notice_style.bg_color=Color("365d4e");toast_label.add_theme_stylebox_override("normal",notice_style)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast_label.offset_top = 122
	toast_label.offset_bottom = 167
	toast_label.offset_left = -220
	toast_label.offset_right = 220
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(toast_label)
	_orientation_hint = card()
	_orientation_hint.name = "LandscapeHint"
	_orientation_hint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_orientation_hint.visible = false
	add_child(_orientation_hint)
	var orientation_center = CenterContainer.new()
	_orientation_hint.add_child(orientation_center)
	var orientation_body = column(16)
	orientation_center.add_child(orientation_body)
	var rotate_title = label("请横屏游玩", 26, GREEN)
	rotate_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	orientation_body.add_child(rotate_title)
	var rotate_detail = label("旋转手机后继续经营\n横屏可同时查看餐厅与操作按钮", 16)
	rotate_detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	orientation_body.add_child(rotate_detail)
	_layout_controls = {"margin":margin, "root":root, "header":header, "toolbar":toolbar, "content":content, "brand_icon":icon, "brand_title":brand_title, "brand_subtitle":brand_subtitle, "time_legend":time_legend, "restaurant":restaurant, "restaurant_card":restaurant_card, "bottom":bottom}
	bottom_ui=Revision18UI.new(self)
	bottom_ui.setup(status_row)
	get_window().size_changed.connect(queue_ui_layout)
	update_ui_layout()

func resource_pill(parent: HBoxContainer, title: String, accent: Color) -> Label:
	var panel: = card()
	var s: = style(Color("faf9f3"), 12)
	s.content_margin_top = 9
	s.content_margin_bottom = 9
	panel.add_theme_stylebox_override("panel", s)
	panel.custom_minimum_size.x = 130
	parent.add_child(panel)
	var body: = column(0)
	panel.add_child(body)
	var heading = HBoxContainer.new()
	body.add_child(heading)
	var icon = TextureRect.new()
	var art_id = "UI/" + str({"钞票":"icon_money","灵石":"icon_spirit","声望":"icon_reputation"}.get(title,"icon_money"))
	icon.custom_minimum_size = Vector2(20,20)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.visible = assets.has_image(art_id)
	icon.texture = assets.get_texture(art_id) if icon.visible else null
	heading.add_child(icon)
	_art_controls.append({"node":weakref(icon),"id":art_id,"type":"texture_optional"})
	heading.add_child(label(title, 12, accent))
	var value: = label("", 24)
	body.add_child(value)
	return value

func build_sidebar() -> void :
	var status_card: = card()
	sidebar.add_child(status_card)
	var stats: = column(8)
	status_card.add_child(stats)
	stats.add_child(label("今日经营", 18))
	revenue_label = label("", 30, GREEN)
	stats.add_child(revenue_label)
	served_label = label("", 13, MUTED)
	stats.add_child(served_label)
	stock_label = label("", 14)
	stats.add_child(stock_label)
	var actions: = row(8)
	stats.add_child(actions)
	var purchase_button: = button("采购", func():
		model.buy_ingredients(int(model.balance.get("prototype.manual_purchase_amount", 20))), false, "stock:purchase")
	purchase_button.tooltip_text = "采购 %d 份普通食材，花费 ￥%d" % [int(model.balance.get("prototype.manual_purchase_amount", 20)), int(model.balance.get("prototype.manual_purchase_amount", 20) * model.balance.get("ingredient.unit_price", 3))]
	actions.add_child(expand(purchase_button))
	var promotion_button: = button("宣传", func(): model.promote(), false, "promotion:flyers")
	promotion_button.tooltip_text = "花费 ￥%d 发传单，持续 %d 游戏分钟" % [int(model.balance.get("promotion.cost", 20)), int(model.balance.get("promotion.duration", 120))]
	actions.add_child(expand(promotion_button))
	var goal_card: = card()
	sidebar.add_child(goal_card)
	var goal: = column(6)
	goal_card.add_child(goal)
	mode_label = label("", 12, GREEN)
	goal.add_child(mode_label)
	quest_title = label("", 17)
	quest_title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	goal.add_child(quest_title)
	quest_description = label("", 13, MUTED)
	quest_description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal.add_child(quest_description)
	debt_label = label("", 13)
	goal.add_child(debt_label)
	goal_bar = ProgressBar.new()
	goal_bar.custom_minimum_size.y = 6
	goal_bar.show_percentage = false
	goal_bar.add_theme_stylebox_override("background", style(Color("e9e6d9"), 3))
	goal_bar.add_theme_stylebox_override("fill", style(Color("b1bf9c"), 3))
	goal.add_child(goal_bar)
	quest_reward = label("", 12, Color("a08053"))
	quest_reward.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	goal.add_child(quest_reward)
	quest_button = button("查看目标", quest_action, true, "quest:current")
	goal.add_child(quest_button)
	var team_card: = card()
	sidebar.add_child(team_card)
	staff_status = column(7)
	team_card.add_child(staff_status)
	staff_status.add_child(label("当班伙伴", 17))
	team_summary = label("", 13, MUTED)
	team_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	staff_status.add_child(team_summary)

func refresh() -> void :
	if revision_ui==null and full_panels!=null:revision_ui=Revision171Panels.new(self)
	if money_label == null:
		return
	var state: Dictionary = model.state
	money_label.text = "￥ %.2f" % float(state.cash)
	gem_label.text = "%d" % int(state.gems)
	reputation_label.text = "%d" % int(state.reputation)
	clock_label.text = model.clock_label()
	period_label.text = model.period_label()
	if int(state.get("promotion_until", 0)) > int(state.total_minutes):
		period_label.text += " · 宣传中"
	guest_label.text = "%d / %d 座 · 舒适度 %d" % [model.customers.size(), int(state.seats), int(state.comfort)]
	revenue_label.text = "￥ %.2f" % float(state.daily_revenue)
	served_label.text = "累计接待 %d 位  ·  流失 %d 位" % [int(state.served), int(state.lost)]
	stock_label.text = "食材 %.1f 份  /  新鲜度 %d%%" % [float(state.ingredients), int(state.freshness)]
	debt_label.text = "待还本金 ￥%.2f" % float(state.debt)
	refresh_quest()
	pause_button.text = "继续" if model.paused else "暂停"
	for i in range(speed_buttons.size()):
		speed_buttons[i].modulate = Color("d5e7c9") if model.speed == i + 1 and not model.paused else Color.WHITE
	var team_lines: Array[String] = []
	var standby: = 0
	for employee in model.employees:
		if employee.get("resting", false):
			standby += 1
			continue
		var working: = "当班"
		if int(employee.get("training_until", 0)) > int(state.total_minutes):
			working = "训练中"
		if int(employee.get("research_until", 0)) > int(state.total_minutes): working = "研发中"
		team_lines.append("%s · %s · 体力 %d" % [employee.name, working, int(employee.stamina)])
	if team_lines.size() > 3: team_lines = team_lines.slice(0, 3)
	if standby > 0: team_lines.append("候补/休息 %d 位 · 在员工面板排班" % standby)
	team_summary.text = "\n".join(team_lines)
	var menu_names: Array[String] = []
	for dish in model.dishes:
		if dish.id in state.menu_enabled: menu_names.append("%s ￥%d" % [dish.name, int(dish.price)])
	menu_label.text = "今日菜单   " + "  ·  ".join(menu_names)
	stage_label.text = "%s / 阶段 %d" % [model.full_rules.config.stage_names[int(state.stage)], int(state.stage)]
	placement_label.text = "绿格可放置 · 点击确认 · 右键/Esc取消" if not map_view.placement_id.is_empty() else "● 点单 → 制作 → 上菜 → 结账  /  更多中管理菜单"
	if "customer_service" in model.full_rules and model.full_rules.customer_service != null:
		var sold_out: Array = model.full_rules.customer_service.snapshot().get("sold_out",[])
		if not sold_out.is_empty():
			var sold_names: Array[String] = []
			for entry in sold_out: sold_names.append(str(entry.name))
			placement_label.text = "食材不足：" + "、".join(sold_names) + "售罄"
	# Pending events use the same task anchor, with their existing modal queue.
	event_button.visible = false
	refresh_notifications()
	if revision_ui != null: revision_ui.refresh_header()
	if bottom_ui!=null:bottom_ui.refresh()
	map_view.queue_redraw()

func refresh_notifications() -> void:
	if action_notifications == null: action_notifications = ActionNotifications.new(model)
	action_notifications.update()
	var primary_panels = Policy.navigation(int(model.state.stage)).map(func(name):return Policy.destination(name))
	var visible_sources = 0
	for name in navigation_buttons:
		var nav: Button = navigation_buttons[name]
		nav.visible = (name == "更多" or name in Policy.navigation(int(model.state.stage))) if str(model.state.mode) == "full" else name in ["员工","图鉴","系统","装修","研发","更多"]
		if not nav.visible: continue
		var destination = Policy.destination(str(name))
		var entries: Array = action_notifications.entries().filter(func(item):return str(item.destination) == destination)
		if name == "更多": entries = action_notifications.entries().filter(func(item):return not str(item.destination) in primary_panels and str(item.destination) != "事件")
		var count = entries.size() if visible_sources < 3 else 0
		if count > 0: visible_sources += 1
		navigation_buttons[name].text = "···" if name == "更多" else str(name)
		navigation_buttons[name].set_meta("unread",count > 0)
		set_notification_dot(navigation_buttons[name],count > 0,count,str(entries[0].level) if count > 0 else "strong")
	event_button.text = "事件" if compact_layout else "事件待处理"
	var event_count = action_notifications.count("events") if visible_sources < 3 else 0
	set_notification_dot(event_button,event_count > 0,event_count)
	if todo_button != null:
		var item: Dictionary = action_notifications.primary()
		todo_button.text = str(item.get("title","查看经营目标")).replace("第", "").replace("名员工", "人") if compact_layout else "待办：" + str(item.get("title","查看经营目标"))
		todo_button.tooltip_text = todo_button.text + "；点击直达，右侧箭头展开全部待办。"
		todo_button.disabled = str(item.get("destination","")).is_empty()
		todo_button.custom_minimum_size.x = (78 if compact_layout else 145) if bottom_ui!=null else (170 if compact_layout else 250)

func open_priority_todo() -> void:
	if action_notifications == null: return
	var destination = str(action_notifications.primary().get("destination",""))
	if not destination.is_empty(): open_panel(destination)

func set_notification_dot(control: Button, unread: bool, count: int = 1, level: String = "strong") -> void:
	var dot: Label = control.get_node_or_null("ImportantActionDot")
	if dot == null:
		dot = label("●",12,Color("d64c4c"))
		dot.name = "ImportantActionDot"
		dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
		dot.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
		dot.offset_left = -29
		dot.offset_right = -3
		dot.offset_top = 1
		dot.offset_bottom = 19
		dot.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		control.add_child(dot)
	dot.text = "●" + (str(count) if count > 1 else "")
	dot.add_theme_color_override("font_color",Color("d64c4c") if level == "strong" else Color("d3a33f"))
	dot.visible = unread

func acknowledge_panel(_name: String) -> void:
	# Visiting a panel is not completing its pending actions.
	pass

func configure_panel_layout(name: String) -> void:
	if _drawer_tween != null and _drawer_tween.is_valid(): _drawer_tween.kill()
	var drawer: bool = name in ["装修","简单布置"]
	decoration_footer.visible = drawer
	decoration_footer.get_child(0).text = "完成布置" if name == "简单布置" else "完成装修"
	_welcome_action.visible = name == "欢迎" and not bool(model.state.get("rescue171",{}).get("ended",false))
	_culture_back.visible = name == "文化简介"
	_panel_back.visible = not name in ["", "更多", "文化简介", "欢迎", "重新开始", "破产救援"] and (not _more_history.is_empty() or is_more_branch(name))
	var parent_panel = str(_more_history.back().panel) if not _more_history.is_empty() else "更多"
	_panel_back.disabled = not Guide.allows_panel(model,parent_panel) or rescue_pending()
	_panel_back.tooltip_text = "返回" + parent_panel if not _panel_back.disabled else "请先完成白泽当前教学或救援选择"
	_welcome_action.text = "继续经营" if _resumed else "开始经营"
	_welcome_action.set_meta("qa_id", "start:continue" if _resumed else "start:full")
	sidebar.visible = not drawer and not compact_layout and not model.state.has("revision191")
	drawer_slot.visible = drawer
	if drawer:
		var animate: bool = modal_window.get_parent() != drawer_slot
		if animate: modal_window.reparent(drawer_slot)
		modal_window.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		modal_window.offset_left = 0
		modal_window.offset_top = 0
		modal_window.offset_right = 0
		modal_window.offset_bottom = 0
		_fit_drawer()
		overlay.visible = false
		if animate:
			modal_window.position.x = drawer_slot.custom_minimum_size.x
			_drawer_tween = create_tween().set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
			_drawer_tween.tween_property(modal_window, "position:x", 0.0, 0.18)
	else:
		if modal_window.get_parent() != overlay: modal_window.reparent(overlay)
		modal_window.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
		var guide_active = tutorial_overlay != null and not tutorial_overlay.current_step().is_empty() and not name in ["欢迎","文化简介","美术资源","开发者选项","破产救援","贷款"]
		var width: float = minf(750, _layout_size.x - ((306 if compact_layout else 480) if guide_active else 24))
		var height: float = maxf(120, _layout_size.y - 184) if compact_layout else 480
		overlay.offset_top = 106 if compact_layout else 150
		overlay.offset_bottom = -70 if compact_layout else -115
		modal_window.offset_left = -width / 2 - ((140 if compact_layout else 235) if guide_active else 0)
		modal_window.offset_right = width / 2 - ((140 if compact_layout else 235) if guide_active else 0)
		modal_window.offset_top = -height / 2
		modal_window.offset_bottom = height / 2

	if bottom_ui!=null:bottom_ui.fit_panel()

func _fit_drawer() -> void:
	if modal_window == null or drawer_slot == null or modal_window.get_parent() != drawer_slot: return
	# The slot has zero height while hidden. Anchoring a minimum-size panel
	# before its first container sort otherwise leaves an extra bottom offset.
	if drawer_slot.size.y >= modal_window.get_combined_minimum_size().y:
		modal_window.size = drawer_slot.size

func refresh_quest() -> void :
	current_quest = {}
	var demo: = str(model.state.mode) == "demo"
	mode_label.text = "开张篇 · 1秒=%d分钟" % int(model.demo_config.time.time_factor) if demo else "标准经营 · 1×每秒3分钟"
	if demo or str(model.state.mode) == "full":
		for quest in model.quest_status():
			if not quest.claimed and quest.unlocked:
				current_quest = quest
				break
	if not current_quest.is_empty():
		quest_title.text = current_quest.title
		quest_description.text = current_quest.description
		quest_reward.text = "奖励 " + str(current_quest.reward_summary) if not str(current_quest.reward_summary).is_empty() else "完成开张篇"
		goal_bar.value = float(current_quest.progress) / maxf(1, float(current_quest.target)) * 100
		quest_button.text = "领取奖励" if current_quest.complete else "查看目标与提示"
	else:
		quest_title.text = "三界食肆，继续经营" if int(model.state.stage) == 4 else "还清债务，提升口碑"
		var next_stage = mini(4, int(model.state.stage) + 1)
		quest_description.text = "下阶段：累计营业额%.0f，声望%d；在更多→经营目标中确认。" % [model._b("stage.%d.revenue" % next_stage), int(model._b("stage.%d.reputation" % next_stage))]
		quest_reward.text = "招牌菜与神兽组合，让小馆更热闹"
		goal_bar.value = maxf(0, (1.0 - float(model.state.debt) / float(model.balance.get("initial.debt", 1200))) * 100)
		quest_button.text = "查看成长目标"

func quest_action() -> void :
	if not current_quest.is_empty() and current_quest.complete:
		claim_quest(str(current_quest.id))
	else:
		open_panel("任务")

func clear(container: Node) -> void :
	for child in container.get_children():
		container.remove_child(child)
		child.queue_free()

func show_notice(message: String) -> void :
	if toast_label == null:
		return
	var matcher=RegEx.new();matcher.compile("[0-9.]+")
	var key=matcher.sub(message,"#",true)
	if _notice_clock-float(_notice_last.get(key,-1000))<1:return
	_notice_last[key]=_notice_clock
	if _notice_last.size()>200:_notice_last.clear();_notice_last[key]=_notice_clock
	if toast_timer > 0:
		if not message in _notice_queue:_notice_queue.append(message)
		while _notice_queue.size()>8:_notice_queue.pop_front()
		return
	_set_toast_text(message)
	toast_label.size.y=0
	toast_timer = notice_duration(message)
	toast_label.visible = true

func notice_duration(message: String,base: float=1.5) -> float:
	return minf(2.5,base+ceilf(maxf(0,message.length()-12)/6.0)*.5)

func rarity_marked_text(message: String) -> String:
	# Translate complete prose before applying BBCode; inserting tags into the
	# Chinese sentence first would break sentence templates and name matching.
	var result: String = (localization.translate(message) if localization!=null else message).replace("[", "[lb]")
	for employee in model.catalog:
		var employee_name: String = localization.translate(str(employee.name)) if localization!=null else str(employee.name)
		if employee_name in result:
			result = result.replace(employee_name, "[color=#%s]● %s[/color]" % [RarityDisplay.color_for(str(employee.get("rarity", "N"))).to_html(false), employee_name])
	return result

func _set_toast_text(message: String) -> void:
	if toast_label==null:return
	_toast_source=message
	_toast_language=localization.language if localization!=null else "zh"
	toast_label.text=rarity_marked_text(message)
	# The original message is retained above so both language directions can
	# re-render the colours; generic text translation must not parse the tags.
	toast_label.set_meta("l10n_managed_text",true)

func close_panel(restore_time: bool = true) -> void :
	if bool(model.state.get("rescue171",{}).get("ended",false)):
		show_notice("本局已经结束，请重新开局或返回主菜单。")
		return
	if decoration_active():
		request_decoration_exit(func(): close_panel(restore_time))
		return
	if revision_ui != null and not revision_ui.forced_panel().is_empty():
		show_notice("请先完成当前页面的确认操作。")
		return
	if rescue_pending() and not bool(model.state.get("rescue171",{}).get("menu",false)):
		show_notice("请先处理经营救援。")
		return
	if tutorial_overlay != null and not panel_name.is_empty(): tutorial_overlay.observe("closed:" + ("员工" if panel_name in ["员工","招聘"] else panel_name))
	if panel_name == "文化简介" and restore_time:
		return_from_culture()
		return
	_more_history.clear()
	overlay.visible = false
	configure_panel_layout("")
	panel_name = ""
	if audio != null: audio.stop_preview()
	if restore_time and _panel_resume:
		model.set_paused(false)
	_panel_resume = false

func toggle_pause() -> void :
	if decoration_active():
		show_notice("请先完成装修，或确认放弃本次调整。")
		return
	model.set_paused( not model.paused)
	if not panel_name.is_empty(): _panel_resume = not model.paused
	if not map_view.placement_id.is_empty(): _placement_resume = not model.paused

func toggle_panel(name: String) -> void :
	name = Policy.destination(name)
	if name == "装修" and int(model.state.stage) == 0: name = "简单布置"
	if decoration_active():
		request_decoration_exit(func(): toggle_panel(name))
		return
	if name == panel_name:
		close_panel()
	else:
		# Bottom navigation starts a new route rather than extending a submenu.
		if not Guide.allows_panel(model,name):
			open_panel(name)
			return
		_more_history.clear()
		open_panel(name,false)

func is_more_branch(name: String) -> bool:
	if Policy.branch(name): return true
	for section in FullPanels.MORE_SECTIONS:
		if name in section[1]: return true
	return false

func remember_more_panel(name: String) -> void:
	if name == panel_name or name == "文化简介" or panel_name == "文化简介": return
	if name == "声音设置" and not panel_name.is_empty():
		_more_history.append({"panel":panel_name,"scroll":modal_body.get_parent().scroll_vertical})
		return
	if name in ["更多", "欢迎", "重新开始", "破产救援"]:
		_more_history.clear()
		return
	# A shortcut to an ancestor unwinds the route instead of forming a loop.
	for index in range(_more_history.size()):
		if str(_more_history[index].panel) == name:
			_more_history.resize(index)
			return
	if panel_name == "更多" or is_more_branch(panel_name) or not _more_history.is_empty() or (panel_name=="员工" and name in ["员工详情","员工培养"]):
		_more_history.append({"panel":panel_name,"scroll":modal_body.get_parent().scroll_vertical})

func return_to_parent_panel() -> void:
	if decoration_active():
		var prior: Array[Dictionary] = _more_history.duplicate(true)
		request_decoration_exit(func(): _more_history = prior;return_to_parent_panel())
		return
	if rescue_pending(): return
	var context: Dictionary = _more_history.back().duplicate() if not _more_history.is_empty() else {"panel":"更多","scroll":0}
	var destination = str(context.panel)
	if not Guide.allows_panel(model,destination):
		show_notice("请先完成白泽当前教学，阶段功能可选择稍后引导。")
		return
	if not _more_history.is_empty(): _more_history.pop_back()
	if tutorial_overlay != null: tutorial_overlay.observe("closed:" + ("员工" if panel_name in ["员工","招聘"] else panel_name))
	open_panel(destination,false)
	_restore_panel_scroll(destination,int(context.get("scroll",0)))

func open_panel(name: String, record_history: bool = true) -> void :
	if decoration_active() and name != panel_name:
		request_decoration_exit(func(): open_panel(name,record_history))
		return
	name = Policy.destination(name)
	if name == "装修" and int(model.state.stage) == 0: name = "简单布置"
	if bool(model.state.get("rescue171",{}).get("ended",false)) and bool(model.state.rescue171.menu) and not name in ["欢迎","重新开始"]: name="欢迎"
	if revision_ui != null:
		var required: String = revision_ui.forced_panel()
		if not required.is_empty(): name = required
	var required_stage = Policy.minimum_stage(name)
	if required_stage > int(model.state.stage):
		show_requirement("%s尚未解锁。需要阶段%d：累计营业额￥%.0f（当前￥%.0f），声望%d（当前%d）。请先在经营升级页达成并确认升级。" % [name,required_stage,float(model.balance.get("stage.%d.revenue" % required_stage,0)),float(model.state.total_revenue),int(model.balance.get("stage.%d.reputation" % required_stage,0)),int(model.state.reputation)])
		return
	if not Guide.allows_panel(model,name) and not name in ["今日收支结算","现金流预警","经营失败","事件结果","破产救援"] and not (name=="事件" and model.full_rules.world.has_notice()):
		show_requirement("白泽：先完成当前教学，阶段新功能可选择稍后引导。")
		return
	if record_history: remember_more_panel(name)
	if name != panel_name: modal_body.get_parent().set_deferred("scroll_vertical",0)
	if name != "文化简介": _culture_return = {}
	if not map_view.placement_id.is_empty(): cancel_placement()
	if panel_name.is_empty():
		_panel_resume = not model.paused
		if not tutorial_time_runs(): model.set_paused(true)
	panel_name = name
	if audio != null and name != "声音设置": audio.stop_preview()
	if name in ["装修","简单布置"]:
		if decoration_session == null: decoration_session = DecorationSession.new(model)
		decoration_session.begin()
	if tutorial_time_runs() and _panel_resume and model.paused: model.set_paused(false)
	if decoration_active(): model.set_paused(true)
	overlay.visible = true
	configure_panel_layout(name)
	acknowledge_panel(name)
	var modal: Node = modal_window
	modal.get_child(0).get_node("Header/Title").text = name
	clear(modal_body)
	if tutorial_overlay != null: tutorial_overlay.observe("panel:" + name)
	if revision_ui != null and revision_ui.render(name):
		enforce_touch_targets(modal_body)
		refresh()
		return
	if v15_panels == null: v15_panels = V15Panels.new(self)
	if v15_panels.render(name):
		enforce_touch_targets(modal_body)
		refresh()
		return
	if full_panels!=null and name in ["山海驿路","山海来信","菜牌说明","角色特征","菜牌核对"]:
		if cultural_ui==null: cultural_ui=preload("res://scripts/ui/cultural_experience_panel.gd").new(self)
		if cultural_ui.render(name):
			enforce_touch_targets(modal_body);refresh();return
	if full_panels != null and full_panels.render(name):
		enforce_touch_targets(modal_body)
		refresh()
		return
	match name:
		"文化简介":
			if culture_panel != null: culture_panel.render()
		"欢迎": welcome_panel()
		"任务": quests_panel()
		"员工": employee_panel()
		"图鉴": catalog_panel()
		"系统": system_panel()
		"声音设置":
			if audio == null: setup_audio()
			audio_panel.render()
		"更多": more_panel()
		"装修", "简单布置": decoration_panel()
		"研发": research_panel()
		"菜单": menu_panel()
		"事件": event_panel()
		"招聘结果": recruit_result_panel()
		"开张庆典": ending_panel()
		"重新开始": reset_panel()
		"营业日志":
			for entry in model.logs.slice(maxi(0, model.logs.size() - 15)):
				paragraph(str(entry), MUTED)
		"说明": help_panel()
		"开发者选项": developer_panel()
		"数值面板": balance_panel()
		"美术资源": art_panel()
		"财务账本": ledger_panel()
		"主线故事": story_panel.render()
	enforce_touch_targets(modal_body)
	refresh()

func culture_button(kind: String, id: String) -> Button:
	return button("文化简介", func(): open_culture(kind, id), false, "culture:%s:%s" % [kind, id])

func open_culture(kind: String, id: String) -> void:
	if kind == "guests" and model.state.get("special_visitors",{}).get("records",{}).get(id,{}).is_empty():
		show_notice("亲自接待这位来客后，可以阅读来客小传。")
		return
	if action_notifications != null and kind in ["employees","dishes"]: action_notifications.read_entry("catalog:%s:%s" % ["employee" if kind == "employees" else "dish",id])
	if culture_panel == null: culture_panel = CulturePanel.new(self)
	if not culture_panel.select_entry(kind, id):
		show_notice("此条文化资料暂不可用。")
		return
	if panel_name != "文化简介":
		_culture_return = {"panel":panel_name, "tab":full_panels.catalog_tab if full_panels != null else catalog_tab, "scroll":modal_body.get_parent().scroll_vertical}
	open_panel("文化简介")
	modal_body.get_parent().set_deferred("scroll_vertical", 0)

func return_from_culture() -> void:
	var context: Dictionary = _culture_return.duplicate()
	var destination: String = str(context.get("panel", "图鉴"))
	_culture_return = {}
	if destination.is_empty():
		var resume: bool = _panel_resume
		close_panel(false)
		if resume: model.set_paused(false)
		return
	if full_panels != null: full_panels.catalog_tab = str(context.get("tab", full_panels.catalog_tab))
	else: catalog_tab = str(context.get("tab", catalog_tab))
	open_panel(destination,false)
	_restore_panel_scroll(destination, int(context.get("scroll", 0)))

func _restore_panel_scroll(destination: String, offset: int) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	if panel_name == destination: modal_body.get_parent().scroll_vertical = offset

func valid_culture_source_url(url: String) -> bool:
	return CulturePanel.Catalog.safe_source_url(url)

func open_culture_source(url: String) -> void:
	if not valid_culture_source_url(url):
		show_notice("来源链接格式无效。")
		return
	if OS.shell_open(url) != OK: show_notice("未能打开浏览器，可复制资料中的网址。")

func enforce_touch_targets(node: Node) -> void:
	if node is BaseButton or node is LineEdit or node is SpinBox:
		node.custom_minimum_size.y = maxf(44, node.custom_minimum_size.y)
	for child in node.get_children(): enforce_touch_targets(child)

func paragraph(text: String, color: Color = INK) -> Label:
	var p: = label(text, 16, color)
	p.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	modal_body.add_child(p)
	return p

func role_name(role: String) -> String:
	return {"chef": "厨师", "waiter": "服务员", "salesman": "销售员", "all": "全能", "tutor": "培训/研发"}.get(role, role)

func employee_panel() -> void :
	var limit: = 3 if int(model.state.stage) == 0 else 5
	var working: = 0
	for employee in model.employees:
		if not employee.resting: working += 1
	paragraph("当班 %d/%d · 已拥有 %d 位。休息、训练和研发期间无法接单；候补仍领取工资。" % [working, limit, model.employees.size()], MUTED)
	var hires: = row(8)
	modal_body.add_child(hires)
	var contract: = button("故事契约 ×%d" % model.state.contracts.size(), func(): recruit_employee("contract"), true, "hire:contract")
	contract.disabled = model.state.contracts.is_empty()
	hires.add_child(contract)
	for kind in ["normal", "advanced"]:
		var hire_kind: String = kind
		var offer: Dictionary = model.full_rules.can_perform("recruit", {"kind":hire_kind})
		var hire: Button = button(recruitment_text(hire_kind, offer), func(): recruit_employee(hire_kind), false, "hire:" + hire_kind)
		hire.disabled = not bool(offer.get("ok", false))
		hire.tooltip_text = str(offer.get("reason", ""))
		hires.add_child(hire)
	paragraph("普通：每10次SR+、50次SSR；高级：每10次SR+、30次SSR。重复员工转为5碎片。", MUTED)
	if not find_employee("bi_fang").is_empty() and not find_employee("jiu_wei_hu").is_empty():
		modal_body.add_child(button("组合排班：毕方掌厨 · 九尾狐传菜", assign_flame_team, true, "team:flame_charm"))
	for bond in model.active_bonds():
		paragraph("已激活羁绊：" + str(bond.name) + " · " + str(bond.description), GREEN)
	for employee in model.employees:
		var id: String = employee.id
		var panel: = card()
		panel.name = id
		modal_body.add_child(panel)
		var body: = column(10)
		panel.add_child(body)
		body.add_child(label("%s  ·  %s / %s" % [employee.name, employee.rarity, role_name(employee.role)], 20))
		var values: = label("", 14, MUTED)
		values.name = "Values"
		body.add_child(values)
		var actions: = row()
		body.add_child(actions)
		var rest_button: = button("", func():
			model.set_employee_rest(id, not find_employee(id).get("resting", false))
			refresh_employee_values(), false, "rest:" + id)
		rest_button.name = "Rest"
		actions.add_child(rest_button)
		actions.add_child(button("训练厨艺 +1" if employee.role == "chef" else "训练速度 +1", func():
			if model.train_employee(id): close_panel(), false, "train:" + id))
		var skill: = label(("神通已实现：" if model.skills_enabled(id) else "图鉴资料：") + str(employee.get("skill_description", "")), 13, MUTED)
		skill.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.add_child(skill)
		body.add_child(culture_button("employees", id))
	refresh_employee_values()

func find_employee(id: String) -> Dictionary:
	for employee in model.employees:
		if employee.id == id:
			return employee
	return {}

func refresh_employee_values() -> void :
	for employee in model.employees:
		var panel: = modal_body.get_node_or_null(str(employee.id))
		if panel == null:
			continue
		var body: Node = panel.get_child(0)
		var attrs: Dictionary = employee.get("attributes", {})
		var status: = "训练中（剩余 %d 分钟）" % (int(employee.training_until) - int(model.state.total_minutes)) if int(employee.get("training_until", 0)) > int(model.state.total_minutes) else "休息中" if employee.get("resting", false) else "当班中"
		if int(employee.get("research_until", 0)) > int(model.state.total_minutes): status = "研发中"
		body.get_node("Values").text = "体力 %d  /  心情 %d  /  忠诚 %d\n厨艺 %d  /  速度 %d  ·  %s" % [int(employee.stamina), int(employee.mood), int(employee.loyalty), int(attrs.get("cooking", 1)), int(attrs.get("speed", 1)), status]
		body.get_child(2).get_node("Rest").text = "返回工作" if employee.get("resting", false) else "安排休息"
		body.get_child(2).get_node("Rest").set_meta("qa_id", ("work:" if employee.get("resting", false) else "rest:") + str(employee.id))

func catalog_panel() -> void :
	var tabs: = row()
	modal_body.add_child(tabs)
	for entry in ["菜品", "员工"]:
		var name: String = entry
		tabs.add_child(button(name, func(): catalog_tab = name;open_panel("图鉴"), name == catalog_tab))
	paragraph("23道菜 · 28位神兽。本章实现7位员工神通、2组羁绊，其余为后续内容资料。", MUTED)
	var entries: Array = model.dishes if catalog_tab == "菜品" else model.catalog
	for entry in entries:
		var line: = card()
		modal_body.add_child(line)
		var body: = column(5)
		line.add_child(body)
		body.add_child(culture_button("dishes" if catalog_tab == "菜品" else "employees", str(entry.id)))
		if catalog_tab == "菜品":
			body.add_child(label("%s  ·  %s  ·  ￥ %d" % [entry.name, entry.category, int(entry.price)], 18))
			var status: = "已解锁" if entry.id in model.state.unlocked_dishes else "可在研发面板查看条件" if entry.id in model.demo_config.research.supported_ids else "后续内容"
			body.add_child(label("成本 ￥ %d   /   %s" % [int(entry.cost), status], 13, GREEN if entry.id in model.state.unlocked_dishes else MUTED))
			var desc: = label(entry.get("description", ""), 14, MUTED)
			desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			body.add_child(desc)
		else:
			body.add_child(label("%s  ·  %s / %s %s" % [entry.name, entry.rarity, role_name(entry.role), "· 神通可生效" if model.skills_enabled(str(entry.id)) else "· 神通待开放"], 18))
			var desc: = label(entry.get("skill_description", ""), 14, MUTED)
			desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			body.add_child(desc)

func system_panel() -> void :
	language_controls(modal_body)
	setup_audio()
	audio_panel.render_switches(modal_body,"system:audio")
	modal_body.add_child(button("声音设置与音频导入",func(): open_panel("声音设置"),false,"system:audio"))
	paragraph("进度不会在关闭期间推进。每日结算后自动存档，也可以随时手动保存。", MUTED)
	if OS.has_feature("web"):
		paragraph("浏览器会在后台将存档和导入图片写入站点存储，保存后请稍候再刷新或关闭页面。", MUTED)
	var actions: = row()
	modal_body.add_child(actions)
	actions.add_child(button("保存进度", func():
		if model.save_game(SAVE_PATH):
			show_notice("进度已保存；浏览器后台写入中，请稍候再关闭页面。" if OS.has_feature("web") else "进度已保存，包括未完成订单。"), true, "system:save"))
	actions.add_child(button("读取进度", func():
		if model.load_game(SAVE_PATH):
			model.set_paused(true)
			_panel_resume = false
			show_notice("进度已恢复，点击继续即可营业。")
		open_panel("系统"), false, "system:load"))
	actions.add_child(button("新的一局", func(): open_panel("重新开始"), false, "system:new"))
	if FileAccess.file_exists("user://savegame.json"):
		modal_body.add_child(button("读取旧版基础框架进度", func():
			if model.load_game("user://savegame.json"):
				model.set_paused(true)
				_panel_resume = false
				open_panel("系统")))
	var report: Dictionary = model.state.get("last_report", {})
	if not report.is_empty():
		paragraph("上次日结", INK)
		for key in ["revenue", "interest", "repayment", "wages", "rent_utilities", "procurement"]:
			if report.has(key):
				var names: = {"revenue": "营业额", "interest": "利息", "repayment": "还款", "wages": "工资", "rent_utilities": "房租水电", "procurement": "采购"}
				paragraph("%s：￥ %.2f" % [names[key], float(report[key])], MUTED)
	else:
		paragraph("还没有日结记录。可在【更多→账单】中结算至次日清晨。", MUTED)
	if FileAccess.file_exists("user://demo_savegame.json"):
		modal_body.add_child(button("导入开张篇 Demo 存档", func():
			if model.load_game("user://demo_savegame.json", true):
				model.set_paused(true)
				open_panel("系统")))
	arrears_control()
	modal_body.add_child(button("开发者选项", func(): open_panel("开发者选项"), false, "system:developer"))
	var notifications_on: bool = action_notifications.enabled()
	modal_body.add_child(button("可选黄点提示：" + ("开启" if notifications_on else "关闭"), func():
		action_notifications.set_enabled(not notifications_on)
		model.autosave_requested.emit()
		open_panel("系统"), false, "system:notifications"))
	modal_body.add_child(button("开发者：重载数值配置", func(): model.reload_balance()))
	paragraph("开发者选项更新后续计算，已取得的奖励和经营进度保留。", MUTED)

func confirm_reset() -> void :
	paragraph("重新开始将重置当前未保存的进度。已有存档仍可读取。", Color("ad6e51"))
	modal_body.add_child(button("确认重新开始", func(): model.reset_game();close_panel();show_notice("新的小馆开张了。")))

func more_panel() -> void :
	var shortcuts: = row()
	modal_body.add_child(shortcuts)
	for entry in ["任务", "菜单", "事件", "营业日志", "说明"]:
		var destination: String = entry
		shortcuts.add_child(button(destination, func(): open_panel(destination), false, "more:" + destination))
	var batch: = int(model.balance.get("prototype.manual_purchase_amount", 20))
	var discount: = float(model.state.procurement_discount) if int(model.state.discount_until) > int(model.state.total_minutes) else 1.0
	modal_body.add_child(button("采购 %d 份食材 · ￥ %.0f" % [batch, batch * float(model.balance.get("ingredient.unit_price", 3)) * discount], func(): model.buy_ingredients(batch), true, "more:purchase"))
	var payments: = row()
	modal_body.add_child(payments)
	for amount in [100, 500]:
		var value: int = amount
		payments.add_child(button("还款 ￥%d" % value, func(): model.repay_debt(value), false, "repay:%d" % value))
	payments.add_child(button("还清剩余债务", func(): model.repay_debt(int(ceil(float(model.state.debt)))), false, "repay:all"))
	modal_body.add_child(button("快进到下一营业时段", func(): model.advance_to_next_period();open_panel("更多"), false, "next:period"))
	modal_body.add_child(button("快进到次日 06:00", func():
		model.skip_to_next_morning()
		open_panel("系统"), false, "next:day"))
	paragraph("快进会逐分钟处理订单、员工状态与财务，正常扣除每日费用。", MUTED)

func welcome_panel() -> void:
	language_controls(modal_body)
	if assets.has_image("UI/title"):
		var scene=TextureRect.new();scene.texture=assets.get_texture("UI/title");scene.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;scene.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED;scene.custom_minimum_size=Vector2(0,150);scene.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;modal_body.add_child(scene)
	paragraph("白泽：欢迎来到大荒市。你接手了负债1200元的有间小馆，要让这间小馆成长为三界餐饮集团。")
	paragraph("完整经营：30位员工、23道常规菜品与隐藏配方、34个山海事件与状态事件、11组羁绊及10组相生相克。阶段升级后开放会员外卖、分店供应链、探索觉醒与厨神大赛。", GREEN)
	paragraph("标准节奏：1×每秒3游戏分钟，新局默认2×，支持暂停与1–4倍速。顶部待办直达当前目标，右侧箭头查看全部；低频工具收在更多。管理面板通常暂停；阶段教学期间继续经营，装修会话始终暂停。", MUTED)
	if _resumed:
		modal_body.add_child(button("重新开始", func(): open_panel("重新开始"), false, "start:new"))
	if bool(model.state.get("rescue171",{}).get("ended",false)):
		modal_body.add_child(button("重新开局（保留永久收藏）",func(): model.restart_campaign_with_keepsakes();_ending_shown=false;close_panel(false);model.set_paused(false),true,"failure:restart"))
	paragraph("已接入水墨员工立绘与像素场景、人物、界面和物品；开发者可继续替换图片。玩法进度会自动保存。", MUTED)

func reset_panel() -> void:
	paragraph("重新开始会重置当前这一局。请先保存需要保留的进度。", Color("ad6e51"))
	modal_body.add_child(button("确认重新开始完整经营", func():
		model.restart_campaign_with_keepsakes()
		_ending_shown = false
		_event_popup_key = ""
		close_panel(false)
		model.set_paused(false), true, "reset:full"))

func claim_quest(id: String) -> void :
	if model.claim_quest(id):
		if audio != null: audio.play_cue("event.quest")
		model.save_game(SAVE_PATH)
		if bool(model.state.completed):
			_ending_shown = true
			open_panel("开张庆典")
		elif panel_name == "任务": open_panel("任务")

func quests_panel() -> void :
	upgrade_controls()
	if str(model.state.mode) != "demo":
		paragraph("标准节奏按原始升级条件经营，不发放开张篇任务奖励。", MUTED)
	else:
		paragraph("已完成的目标需要领取奖励，才会开放下一个目标。", MUTED)
		var ordered: Array = []
		for item in model.quest_status():
			if item.unlocked and not item.claimed: ordered.append(item)
		for item in model.quest_status():
			if not (item.unlocked and not item.claimed): ordered.append(item)
		for quest in ordered:
			var id: String = quest.id
			var item: = card()
			modal_body.add_child(item)
			var body: = column(7)
			item.add_child(body)
			body.add_child(label(str(quest.title) + (" · 已领取" if quest.claimed else ""), 18))
			var detail: = label(str(quest.description), 14, MUTED)
			detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			body.add_child(detail)
			body.add_child(label("进度 %d/%d · %s" % [int(quest.progress), int(quest.target), str(quest.reward_summary)], 13, GREEN))
			var claim: = button("领取奖励" if quest.complete else "等待达成" if quest.unlocked else "完成前置目标后开放", func(): claim_quest(id), true, "claim:" + id)
			claim.disabled = quest.claimed or not quest.complete or not quest.unlocked
			body.add_child(claim)
func upgrade_controls() -> void :
	var threshold: = float(model.demo_config.stage.demo_revenue) if str(model.state.mode) == "demo" else float(model.balance.get("stage.1.revenue", 4000))
	var rep: = int(model.demo_config.stage.demo_reputation) if str(model.state.mode) == "demo" else int(model.balance.get("stage.1.reputation", 100))
	paragraph("街角饭店：累计营业额 ￥%.0f/%.0f · 声望 %d/%d · 债务 ￥%.0f" % [float(model.state.total_revenue), threshold, int(model.state.reputation), rep, float(model.state.debt)], GREEN)
	var upgrade: = button("升级为街角饭店", func():
		if model.upgrade_restaurant():
			open_panel("任务")
			model.save_game(SAVE_PATH), true, "upgrade:confirm")
	upgrade.disabled = int(model.state.stage) > 0 or float(model.state.total_revenue) < threshold or int(model.state.reputation) < rep or (str(model.state.mode) == "demo" and float(model.state.debt) > 0)
	modal_body.add_child(upgrade)

func recruit_employee(kind: String) -> void :
	var result: Dictionary = model.recruit(kind)
	if not result.is_empty():
		_recruit_result = result
		open_panel("招聘结果")

func recruitment_text(kind: String, offer: Dictionary) -> String:
	var currency: String = str(offer.get("currency", "cash"))
	var cost: float = float(offer.get("cost", 0))
	var payment: String = "%s灵石" % str(cost) if currency == "gems" else "￥%s" % str(cost)
	return ("高级招聘" if kind == "advanced" else "普通招聘") + " · " + payment

func recruit_result_panel() -> void :
	var rarity: String = str(_recruit_result.get("rarity", "N"))
	modal_body.add_child(RarityDisplay.create_badge(rarity, false, assets))
	paragraph("● " + str(_recruit_result.get("name", "新伙伴")), RarityDisplay.color_for(rarity))
	var strip = ColorRect.new()
	strip.color = RarityDisplay.color_for(rarity)
	strip.custom_minimum_size.y = 5
	var employee: Dictionary = find_employee(str(_recruit_result.get("id", "")))
	if _recruit_result.get("duplicate", false):
		paragraph("熟悉的伙伴再次应聘，已转为 %d 个碎片。可在【员工培养】中升级技能。" % int(_recruit_result.get("fragments", 5)))
	else:
		paragraph("新伙伴已经加入小馆。" + ("当前排班已满，先安排一位员工休息，再让它上班。" if employee.get("resting", false) else "它会自动参与当班工作。"))
		paragraph(str(employee.get("skill_description", "")), MUTED)
	modal_body.add_child(strip)
	modal_body.add_child(button("安排伙伴工作", func(): open_panel("员工"), true, "hire:roster"))
	modal_body.add_child(button("回到小馆", close_panel, false, "hire:return"))

func assign_flame_team() -> void :

	for employee in model.employees:
		if str(employee.id) not in ["bi_fang", "jiu_wei_hu"] and str(employee.role) in ["chef", "all"]:
			model.set_employee_rest(str(employee.id), true)
	var limit: = 3 if int(model.state.stage) == 0 else 5
	for employee in model.employees:
		var count: = 0
		for colleague in model.employees:
			if not colleague.resting: count += 1
		if count >= limit - 1 and str(employee.id) not in ["bi_fang", "jiu_wei_hu"]:
			model.set_employee_rest(str(employee.id), true)
	model.set_employee_rest("bi_fang", false)
	model.set_employee_rest("jiu_wei_hu", false)
	open_panel("员工")
	show_notice("毕方掌厨，九尾狐传菜。火焰魅惑使客单价提升15%。")

func research_panel() -> void :
	paragraph("研发消耗 ￥%d 与 %d 份食材，耗时 %d 游戏分钟。主持厨师暂时停止做菜；关闭面板后时间继续。" % [int(model.demo_config.research.cash_cost), int(model.demo_config.research.ingredient_cost), int(model.demo_config.research.minutes)], MUTED)
	for id in model.demo_config.research.supported_ids:
		var dish: = find_dish(str(id))
		var item: = card()
		item.name = str(id)
		modal_body.add_child(item)
		var body: = column(6)
		item.add_child(body)
		body.add_child(label("%s · ￥%d" % [dish.name, int(dish.price)], 18))
		var owner: = find_employee(str(dish.required_employee))
		body.add_child(label("关联伙伴：" + str(catalog_employee(str(dish.required_employee)).get("name", "")), 13, MUTED))
		var status: = label("", 13, GREEN)
		status.name = "Status"
		body.add_child(status)
		var key: String = str(id)
		var action: = button("开始研发", func():
			if model.research_dish(key): close_panel(), true, "research:" + key)
		action.name = "Research"
		action.disabled = owner.is_empty() or key in model.state.unlocked_dishes
		body.add_child(action)
	refresh_research_values()

func refresh_research_values() -> void :
	for id in model.demo_config.research.supported_ids:
		var item: = modal_body.get_node_or_null(str(id))
		if item == null: continue
		var body: Node = item.get_child(0)
		var text: = "配方尚未研发"
		var busy: = false
		if id in model.state.unlocked_dishes: text = "配方已解锁，可在菜单中上架"
		for project in model.state.research_projects:
			if str(project.dish_id) == str(id):
				text = "研发中 · 剩余 %d 分钟" % (int(project.due) - int(model.state.total_minutes))
				busy = true
		body.get_node("Status").text = text
		body.get_node("Research").disabled = busy or id in model.state.unlocked_dishes or find_employee(str(find_dish(str(id)).required_employee)).is_empty()

func find_dish(id: String) -> Dictionary:
	for dish in model.dishes:
		if str(dish.id) == id: return dish
	return {}

func catalog_employee(id: String) -> Dictionary:
	for employee in model.catalog:
		if str(employee.id) == id: return employee
	return {}

func menu_panel() -> void :
	paragraph("上架菜品决定顾客点单。菜单至少保留一道菜；招牌菜更贵，也需要更长制作时间。", MUTED)
	for id in model.state.unlocked_dishes:
		var dish: = find_dish(str(id))
		var name: String = str(id)
		var enabled: bool = id in model.state.menu_enabled
		modal_body.add_child(button("%s · %s ￥%d" % ["已上架" if enabled else "未上架", dish.name, int(dish.price)], func():
			model.set_menu_enabled(name, not name in model.state.menu_enabled)
			open_panel("菜单"), enabled, "menu:" + name))

func decoration_panel() -> void :
	paragraph("布置期间暂停经营。选中后点击地图绿格，底部完成后保留；可撤销或取消预览。红格表示占用、影响通路或条件不足。", MUTED)
	var move_flow = HFlowContainer.new()
	move_flow.add_theme_constant_override("h_separation",6)
	move_flow.add_theme_constant_override("v_separation",6)
	modal_body.add_child(move_flow)
	for index in range(model.state.get("layout",[]).size()):
		var selected = index
		var item: Dictionary = model.state.layout[index]
		var definition = model.full_rules.decoration(str(item.id))
		move_flow.add_child(button("移动%d·%s" % [index+1,str(definition.get("name",item.id))],func(): begin_move(selected),false,"decor:move:%d" % index))
	if int(model.state.stage) < 1:
		paragraph("当前可调整已有家具；升级到阶段1后可购买正式装修。",MUTED)
		return
	revision_ui.builder_picker()
	for decoration in model.decorations:
		if bool(decoration.get("initial_only",false)):continue
		var id: String = decoration.id
		var price: = float(model.balance.get(str(decoration.cost_key), 0))
		var item: = card()
		modal_body.add_child(item)
		var body: = column(6)
		item.add_child(body)
		var identity = row(8)
		body.add_child(identity)
		var thumbnail = label(str(decoration.get("icon", "饰")), 26, GREEN)
		thumbnail.custom_minimum_size = Vector2(48, 48)
		thumbnail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		thumbnail.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		thumbnail.add_theme_stylebox_override("normal", style(Color("e4ebdf"), 8))
		identity.add_child(thumbnail)
		var title = label("%s\n￥%.0f" % [decoration.name, price], 16)
		title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		identity.add_child(expand(title))
		var description = label(decoration_effect_summary(decoration)+" · 工期%d分钟" % int(decoration.get("build_minutes",60)), 14, MUTED)
		description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.add_child(description)
		var action: = button("预览并摆放", func(): begin_placement(id), true, "place:" + id)
		action.tooltip_text = "点击查看所需资金、员工和摆放条件"
		body.add_child(action)

func decoration_effect_summary(decoration: Dictionary) -> String:
	var values: Array[String] = []
	for effect in decoration.get("effects", []):
		var value: float = float(model.balance.get(str(effect.get("value_key", "")), effect.get("value", 0)))
		var title: String = {"seats":"座位", "comfort":"舒适度", "traffic_bonus":"客流量", "price_bonus":"客单价", "cooking_speed":"烹饪速度", "cashier_speed":"结账速度", "escape_reduction":"逃单风险降低"}.get(str(effect.type), str(effect.type))
		values.append("%s +%s" % [title, str(int(value)) if str(effect.type) in ["seats", "comfort"] else "%.0f%%" % (value * 100)])
	if decoration.has("device_type"):values.push_front(str(decoration.get("description","")))
	return " · ".join(values)

func begin_placement(id: String) -> void :
	if str(model.state.mode) == "full" or decoration_active():
		if str(model.state.mode) == "full" and int(model.state.stage) < 1:
			show_notice("正式装修在阶段1开放；现在可移动已有家具。")
			return
		if not decoration_active(): open_panel("装修")
		var check: Dictionary = model.full_rules.revision.build_check(id,decoration_session.builder_id)
		if not check.ok:
			var reasons=str(check.reason).replace("请选择1名装修负责人", "").strip_edges() if decoration_session.builder_id.is_empty() else str(check.reason)
			if not reasons.is_empty():show_requirement(reasons);return
		_move_index = -1
		map_view.set_placement(id)
		map_view.placement_validator = func(kind,x,y): return model.can_place_decoration(kind,x,y)
		show_notice("点击绿色格子预览购买；完成装修后保留，撤销可收回本次操作。")
		return
	_placement_resume = _panel_resume
	close_panel(false)
	model.set_paused(true)
	map_view.set_placement(id)
	refresh()
	show_notice("移动到绿色格子，点击确认。右键或Esc取消。")

func place_decoration(id: String, x: int, y: int) -> void :
	if decoration_active():
		if _move_index<0 and decoration_session.builder_id.is_empty():
			if model.can_place_decoration(id,x,y):choose_builder_for_placement(id,x,y)
			else:show_requirement("位置不可施工，请检查设备占位、操作站位和通路。")
			return
		if _move_index >= 0 and int(model.state.layout[_move_index].x) == x and int(model.state.layout[_move_index].y) == y:
			cancel_placement()
			return
		var okay = decoration_session.move_item(_move_index,x,y) if _move_index >= 0 else decoration_session.purchase(id,x,y)
		if okay:
			cancel_placement()
			open_panel(panel_name,false)
		else: show_requirement(decoration_session.last_error if not decoration_session.last_error.is_empty() else "此处无法放置：请避开使用中的餐桌、家具、员工和通路。")
		return
	if model.buy_decoration(id, x, y):
		if tutorial_overlay != null: tutorial_overlay.observe("buy_decoration")
		if action_notifications != null: action_notifications.complete_action("buy_decoration")
		cancel_placement()
		model.save_game(SAVE_PATH)

func choose_builder_for_placement(id: String,x: int,y: int) -> void:
	if is_instance_valid(_builder_dialog):return
	var dialog=ConfirmationDialog.new();_builder_dialog=dialog;dialog.title="指派装修负责人";add_child(dialog)
	var definition=model.full_rules.decoration(id)
	dialog.dialog_text="%s · ￥%.0f · 工期%d游戏分钟\n确认负责人后预订，完成布置后开工。" % [str(definition.name),float(model.balance.get(str(definition.cost_key),0)),int(definition.get("build_minutes",60))]
	var selection=OptionButton.new();selection.custom_minimum_size=Vector2(300,44);selection.set_meta("qa_id","decor:assign_employee");selection.add_item("请选择一位当班空闲员工");selection.set_item_metadata(0,"")
	for employee in model.employees:
		if model.full_rules.revision.builder_available(employee):selection.add_item(str(employee.name));selection.set_item_metadata(selection.item_count-1,str(employee.id))
	dialog.add_child(selection);dialog.get_ok_button().text="确认负责人";dialog.get_ok_button().custom_minimum_size.y=44;dialog.get_ok_button().set_meta("qa_id","decor:assign");_qa_buttons.append(dialog.get_ok_button())
	dialog.get_cancel_button().text="返回预览";dialog.get_cancel_button().custom_minimum_size.y=44;dialog.get_cancel_button().set_meta("qa_id","decor:assign_cancel");_qa_buttons.append(dialog.get_cancel_button())
	dialog.confirmed.connect(func():
		var worker=str(selection.get_selected_metadata())
		dialog.queue_free()
		if worker.is_empty():show_requirement("请选择1名装修负责人；本次尚未扣费。");return
		decoration_session.builder_id=worker;place_decoration(id,x,y))
	dialog.canceled.connect(func():dialog.queue_free())
	dialog.popup_centered(Vector2i(500,230))
	selection.position=Vector2(24,105)

func cancel_placement() -> void :
	map_view.set_placement("")
	map_view.placement_validator = Callable()
	_move_index = -1
	if decoration_active():
		refresh()
		return
	if _placement_resume: model.set_paused(false)
	_placement_resume = false
	refresh()

func decoration_active() -> bool:
	return decoration_session != null and decoration_session.active

func begin_move(index: int) -> void:
	if not decoration_active(): return
	_move_index = index
	map_view.set_placement(str(model.state.layout[index].id))
	map_view.placement_validator = func(_kind,x,y):return decoration_session.can_move(_move_index,x,y)
	show_notice("仅空闲家具可移动，点击绿色格子确认。")

func undo_decoration() -> void:
	if not decoration_active(): return
	cancel_placement()
	if decoration_session.undo(): open_panel(panel_name,false)
	else: show_notice("还没有可以撤销的步骤。")

func finish_decoration(keep: bool) -> void:
	if not decoration_active(): return
	var bought = decoration_session.finish(keep)
	map_view.set_placement("")
	map_view.placement_validator = Callable()
	_move_index = -1
	if bought: show_notice("装修已开工，完工后生效；0:00–6:00暂停施工。")
	close_panel()
	model.save_game(SAVE_PATH)

func request_decoration_exit(after: Callable) -> void:
	if is_instance_valid(_decoration_dialog): return
	_decoration_dialog = ConfirmationDialog.new()
	_decoration_dialog.title = "装修尚未完成"
	_decoration_dialog.dialog_text = "完成并保留本次调整，或放弃后退出。也可以继续布置。"
	_decoration_dialog.ok_button_text = "完成并退出"
	_decoration_dialog.cancel_button_text = "继续布置"
	var discard = _decoration_dialog.add_button("放弃本次调整",false,"discard")
	add_child(_decoration_dialog)
	for entry in [[_decoration_dialog.get_ok_button(),"decor:confirm"],[_decoration_dialog.get_cancel_button(),"decor:continue"],[discard,"decor:discard"]]:
		entry[0].set_meta("qa_id",entry[1])
		_qa_buttons.append(entry[0])
	var dialog = _decoration_dialog
	var leave = func(keep):
		dialog.hide()
		dialog.queue_free()
		finish_decoration(keep)
		after.call()
	dialog.confirmed.connect(func(): leave.call(true))
	dialog.custom_action.connect(func(action):
		if action == "discard": leave.call(false))
	dialog.canceled.connect(func(): dialog.queue_free())
	dialog.popup_centered(Vector2i(430,170))

func event_panel() -> void :
	var event: Dictionary = model.pending_event()
	if event.is_empty():
		paragraph("暂时没有待处理事件。事件会在营业中出现，部分需要对应神兽当班。", MUTED)
		return
	_event_popup_key = str(event.id) + ":" + str(event.get("serial", event.get("queued_minute", 0)))
	paragraph(str(event.title), GREEN)
	var employee_id: String = str(event.get("trigger", {}).get("employee_id", ""))
	if not employee_id.is_empty():
		var involved = catalog_employee(employee_id)
		paragraph("● " + str(involved.get("name", employee_id)), RarityDisplay.color_for(str(involved.get("rarity", "N"))))
	paragraph(str(event.description))
	if str(event.id) == "food_festival" and full_panels != null: full_panels.festival_selection()
	if str(event.id) == "kunlun_trouble":
		modal_body.add_child(button("查看商业封锁与对抗进度", func(): open_panel("封锁对抗"), false, "world:blockade"))
	for index in range(event.options.size()):
		var option_index: = index
		var id: String = str(event.id)
		modal_body.add_child(button(str(event.options[index].label), func():
			if model.choose_event(id, option_index):
				revision_ui.feedback=model.state.world.get("feedback",{}).duplicate(true)
				open_panel("事件结果"), index == 0, "event:%s:%d" % [id, index]))
	if str(event.get("type",""))=="notice":
		var preview=event.get("result_preview",[])
		var explanation="\n".join(preview) if preview is Array else str(preview)
		paragraph("确认后生效：\n"+explanation,GREEN)
	else: paragraph("可以先关闭面板，稍后通过顶部待办处理。", MUTED)

func ending_panel() -> void:
	paragraph("白泽：三界食肆的香气，终于传到了厨神大赛！", GREEN)
	var result: Dictionary = model.state.expansion.competition.last_result
	paragraph("厨神大赛最高 %.1f 分 · 已获胜 %d 次" % [float(model.state.expansion.competition.best_score),int(model.state.expansion.competition.wins)])
	paragraph("从有间小馆到三界餐饮集团，累计营业额￥%.2f，收集%d位员工、研发%d道菜。" % [float(model.state.total_revenue),model.employees.size(),model.state.unlocked_dishes.size()])
	paragraph("可以继续经营、收集神兽和挑战大赛；排行榜中的其他食肆为本地模拟对手。", MUTED)
	modal_body.add_child(button("继续经营三界食肆", close_panel, true, "ending:continue"))

func help_panel() -> void:
	paragraph("开店：跟随白泽完成六步必修教学：认识负债、查看并关闭员工面板、花20元发传单、观察第一单、认识收入与利润、查看真实账单预览。阶段0没有免费研发。")
	paragraph("库存供应：按菜品对应采购原料。新鲜度随日结下降，自动备货可开关；没有原料的菜品暂停销售。餐厅没有离线收益。")
	paragraph("培养：员工可训练属性、学习副职、升级神通、安排时段或休息。训练、研发及派遣期间不会在主店接单。候补也领取工资。")
	paragraph("成长：累计营业额与声望同时达标后，在更多→经营目标中确认。阶段2开放会员外卖，3开放三分店、中央厨房与探索，4开放跨界、觉醒及厨神大赛。")
	paragraph("更多→账单与资金流水页底部可快进到下一营业时段或次日，期间依旧逐分钟处理订单、费用与员工状态。开局教学不可跳过；每次升级逐项教学，阶段教学可稍后继续，可从系统与存档重新学习。")
	modal_body.add_child(button("重放开局教学",func(): tutorial_overlay.restart_tutorial();close_panel(),false,"tutorial:replay"))
	for step in Guide.config().get("stage_steps",[]):
		if int(step.stage) <= int(model.state.stage):
			var id = str(step.id)
			modal_body.add_child(button("重放阶段%d · %s" % [int(step.stage),str(step.label)],func(): tutorial_overlay.restart_tutorial(id);close_panel(),false,"tutorial:replay:" + id))
	paragraph("美术：系统→开发者选项→美术资源。桌面版可在程序旁CustomAssets放置图片；详细路径见随包美术接入说明。")

func _qa_interface_texts(node: Node, result: Array) -> void:
	if node.is_queued_for_deletion() or bool(node.get_meta("culture_body_text",false)):return
	if node is Control and node.is_visible_in_tree():
		if node is Label or node is RichTextLabel or node is Button:
			result.append(str(node.text))
	if node is Window and node.visible:result.append(str(node.title))
	for child in node.get_children():_qa_interface_texts(child,result)

func publish_qa_state() -> void :

	if not _qa_enabled: return
	var controls: Array = []
	var retained: Array[Button] = []
	for control in _qa_buttons:
		if not is_instance_valid(control) or control.is_queued_for_deletion(): continue
		retained.append(control)
		if not control.is_visible_in_tree(): continue
		var rect: Rect2 = control.get_global_rect()
		if control.get_window() != get_window(): rect.position += Vector2(control.get_window().position)
		var center: = rect.get_center()
		var visible: = get_viewport_rect().has_point(center)
		var ancestor: Node = control.get_parent()
		while ancestor != null:
			if ancestor is Control and ancestor.clip_contents and not ancestor.get_global_rect().has_point(center): visible = false
			ancestor = ancestor.get_parent()
		if control.get_window()==get_window() and overlay.visible and overlay.get_global_rect().has_point(center) and not overlay.is_ancestor_of(control) and not tutorial_overlay.is_ancestor_of(control): visible = false
		if visible:
			controls.append({"text": control.text, "qa_id": str(control.get_meta("qa_id", "")), "disabled": control.disabled, "icon_available": control.icon != null, "rect": {"x": rect.position.x, "y": rect.position.y, "w": rect.size.x, "h": rect.size.y}})
	_qa_buttons = retained
	var grid: Rect2 = map_view.grid_rect()
	if map_view.has_method("_to_view"):
		grid = Rect2(map_view._to_view(grid.position), grid.size * map_view._world_scale())
	grid.position += map_view.get_global_position()
	var dimensions: Vector2i = map_view.grid_dimensions()
	var art_input_rect: Dictionary = {}
	if panel_name == "美术资源" and is_instance_valid(_import_path):
		var input_bounds: Rect2 = _import_path.get_global_rect()
		art_input_rect = {"x":input_bounds.position.x,"y":input_bounds.position.y,"w":input_bounds.size.x,"h":input_bounds.size.y}
	var payload: = {"art_input_rect":art_input_rect, "nav_art_probe": assets.get_resource_info("UI/btn_employee"), "panel": panel_name, "last_saved_minute": model.last_saved_minute, "placement_id": map_view.placement_id, "paused": model.paused, "speed": model.speed, "state": model.state.duplicate(true), "quests": model.quest_status(), "employees": model.employees.duplicate(true), "research_projects": model.state.research_projects.duplicate(true), "pending_event": model.pending_event(), "art_import": _art_import_result.duplicate(true), "art_probe": assets.get_resource_info("Characters/qianyang_idle"), "bonds": model.active_bonds(), "buttons": controls, "viewport": {"w": size.x, "h": size.y}, "layout_grid": {"x": grid.position.x, "y": grid.position.y, "w": grid.size.x, "h": grid.size.y, "cols": dimensions.x, "rows": dimensions.y}}
	var screen: Transform2D = get_viewport().get_screen_transform()
	payload["culture_entry"] = culture_panel.snapshot() if panel_name == "文化简介" and culture_panel != null else {}
	payload["interface_language"]=localization.language if localization!=null else "zh"
	var interface_texts: Array=[]
	_qa_interface_texts(self,interface_texts)
	payload["interface_texts"]=interface_texts
	payload["scene_texts"]=map_view.scene_labels.map(func(item):return str(item.text))
	payload["customers"]=model.customers.duplicate(true)
	if audio != null: payload["audio"] = audio.snapshot()
	if audio_panel != null and panel_name == "声音设置": payload["audio_panel"] = audio_panel.snapshot()
	payload["culture_navigation"] = {"catalog_tab":full_panels.catalog_tab if full_panels != null else catalog_tab, "scroll_vertical":modal_body.get_parent().scroll_vertical, "return_context":_culture_return.duplicate()}
	payload["experience"] = {"navigation":Policy.navigation(int(model.state.stage)),"more":Policy.more_entries(int(model.state.stage)),"priority":action_notifications.primary() if action_notifications != null else {},"real_time_rate":model.real_time_rate(),"decoration_active":decoration_active(),"undo_steps":decoration_session.history.size() if decoration_active() else 0,"move_index":_move_index,"bubbles":map_view.thoughts.snapshot() if map_view.thoughts != null else []}
	payload["bottom_status"]=bottom_ui.snapshot() if bottom_ui!=null else {}
	payload["top_status"]=payload.bottom_status
	payload["tutorial_reminder"]=tutorial_overlay.reminder_snapshot() if tutorial_overlay!=null else {}
	payload["portrait_preview"]=get_node_or_null("EmployeePortrait")!=null and get_node("EmployeePortrait").visible
	payload["v193_art"]={}
	for path in ["Portraits/xian_yang","Sprites/xian_yang/walk_up_0","Portraits/tutorial_bai_ze"]:payload["v193_art"][path]=assets.has_image(path)
	payload["art_slot_count"]=_art_culture_slots.item_count if is_instance_valid(_art_culture_slots) else 0
	payload["presentation"]={"toast_left":toast_timer,"toast_text":toast_label.get_parsed_text(),"toast_queue":_notice_queue.size(),"cash_floats":_cash_floats.size()}
	payload.experience["bubble_art"] = assets.get_resource_info("UI/thought_bubble")
	var placement_signature = hash([map_view.placement_id,_move_index,model.state.get("layout",[]),model.state.cash])
	if placement_signature != _qa_placement_signature:
		_qa_placement_signature = placement_signature
		_qa_placement_cells.clear()
		if not map_view.placement_id.is_empty():
			var dims = map_view.grid_dimensions()
			for y in range(dims.y):
				for x in range(dims.x):
					var valid = decoration_session.can_move(_move_index,x,y) if decoration_active() and _move_index >= 0 else model.can_place_decoration(map_view.placement_id,x,y)
					if valid: _qa_placement_cells.append({"x":x,"y":y})
	payload.experience["placement_cells"] = _qa_placement_cells.duplicate(true)
	var actors: Array = []
	for id in map_view._actors:
		var actor: Dictionary = map_view._actors[id]
		var point = map_view._to_view(actor.get("display_position",actor.position)) + map_view.global_position
		actors.append({"id":id,"action":actor.action,"x":point.x,"y":point.y,"target":{"x":actor.target.x,"y":actor.target.y}})
	payload["scene_viewport"]={"x":map_view.global_position.x,"y":map_view.global_position.y,"w":map_view.size.x,"h":map_view.size.y}
	payload["actors"] = actors
	if model.state.has("revision191"):
		payload["dollhouse"]={"projection":"top_down","zoom":map_view.house().zoom,"camera":{"x":map_view.house().camera.x,"y":map_view.house().camera.y},"devices":model.full_rules.dollhouse.fixtures().map(func(item):return {"id":model.full_rules.dollhouse.identity(item),"type":model.full_rules.dollhouse.kind(item),"locked":model.full_rules.dollhouse.locked(model.full_rules.dollhouse.identity(item))}),"grid_searches":preload("res://scripts/services/dollhouse_navigation.gd").searches}
		var map_rect=map_view.get_global_rect()
		payload.dollhouse["viewport"]={"x":map_rect.position.x,"y":map_rect.position.y,"w":map_rect.size.x,"h":map_rect.size.y}
		payload.dollhouse["chairs"]=map_view.house().draw_entities().filter(func(e):return e.type=="chair").map(func(e):return {"x":e.point.x,"y":e.point.y,"direction":e.direction})
		payload.dollhouse["people"]=map_view.house().draw_entities().filter(func(e):return e.type in ["staff","guest","leaving"]).map(func(e):return {"type":e.type,"id":str(e.data.id),"x":e.point.x,"y":e.point.y})
		payload.dollhouse["pinned_conflicts"]=map_view.crowd.pinned_conflicts
		payload["text_rendering"]={"body_font":"NotoSansSC","scene_min_font_size":14,"scene_text_scales_with_map":false}
		if map_view.thoughts!=null:payload.experience["bubble_exclusion_rects"]=map_view.thoughts.body_rectangles().map(func(r):return {"x":r.position.x+map_rect.position.x,"y":r.position.y+map_rect.position.y,"w":r.size.x,"h":r.size.y})

		payload.dollhouse["draw_order"]=map_view.house().draw_entities().map(func(entity):return {"type":str(entity.type),"y":float(entity.point.y),"serial":int(entity.serial),"id":str(entity.get("data",{}).get("id","")),"stage":str(entity.get("data",{}).get("stage",""))})
	var art_slot_rect: Dictionary = {}
	if panel_name == "美术资源" and is_instance_valid(_art_culture_slots):
		var slot_bounds: Rect2 = _art_culture_slots.get_global_rect()
		art_slot_rect = {"x":slot_bounds.position.x, "y":slot_bounds.position.y, "w":slot_bounds.size.x, "h":slot_bounds.size.y}
	payload["art_slot_rect"] = art_slot_rect
	var final: Transform2D = get_viewport().get_final_transform()
	payload["screen_transform"] = {"a":screen.x.x, "b":screen.x.y, "c":screen.y.x, "d":screen.y.y, "tx":screen.origin.x, "ty":screen.origin.y}
	payload["final_transform"] = {"a":final.x.x, "b":final.x.y, "c":final.y.x, "d":final.y.y, "tx":final.origin.x, "ty":final.origin.y}
	payload["window_scale"] = {"render_width":get_window().size.x, "render_height":get_window().size.y, "content_width":get_window().content_scale_size.x, "content_height":get_window().content_scale_size.y, "aspect":get_window().content_scale_aspect, "mode":get_window().content_scale_mode, "factor":get_window().content_scale_factor}
	JavaScriptBridge.eval("window.shanhaiQAState = " + JSON.stringify(payload) + ";", true)

func developer_panel() -> void:
	paragraph("开发者选项", GREEN)
	var enabled: bool = bool(model.state.get("developer_mode", false))
	modal_body.add_child(button("关闭开发者模式" if enabled else "开启开发者模式", func():
		model.state.developer_mode = not enabled
		assets.developer_mode = not enabled
		open_panel("开发者选项"), enabled, "dev:toggle"))
	modal_body.add_child(button("美术资源：导入与重载", func(): open_panel("美术资源"), false, "dev:art"))
	modal_body.add_child(button("音频资源：导入与试听", func(): open_panel("声音设置"), false, "dev:audio"))
	modal_body.add_child(button("数值面板", func(): open_panel("数值面板"), false, "dev:balance"))
	modal_body.add_child(button("重新显示新手教程", func(): tutorial_overlay.restart_tutorial(); close_panel(), false, "dev:tutorial"))
	paragraph("开发者模式会按文件变化刷新图片。数值面板改动作用于本次存档，重载配置可恢复默认。", MUTED)

func balance_panel() -> void:
	if not bool(model.state.get("developer_mode", false)):
		paragraph("请先在开发者选项中开启开发者模式。", MUTED)
		return
	paragraph("更改影响后续计算；已发生的收入、支出与订单不追溯重算。", MUTED)
	var filter = LineEdit.new()
	filter.placeholder_text = "输入参数名过滤，例如 hire 或 stage"
	modal_body.add_child(filter)
	var selector = OptionButton.new()
	selector.custom_minimum_size.x = 450
	modal_body.add_child(selector)
	var keys: Array = model.balance.keys()
	keys.sort()
	var listed: Array[String] = []
	var value = SpinBox.new()
	value.min_value = -10000000
	value.max_value = 10000000
	value.step = 0.001
	value.custom_minimum_size.x = 300
	modal_body.add_child(value)
	var rebuild = func(query: String):
		selector.clear(); listed.clear()
		for key in keys:
			if query.to_lower() in str(key).to_lower(): selector.add_item(str(key)); listed.append(str(key))
		if not listed.is_empty(): value.value = float(model.balance[listed[0]])
	filter.text_changed.connect(rebuild)
	selector.item_selected.connect(func(index):
		if index < listed.size(): value.value = float(model.balance[listed[index]]))
	rebuild.call("")
	modal_body.add_child(button("应用数值", func():
		var index = selector.selected
		if index >= 0 and index < listed.size():
			if model.apply_balance_override(listed[index], value.value): show_notice("已应用 " + listed[index]);open_panel("数值面板")
			else: show_notice("数值不符合规则，当前参数已保留"), true, "dev:apply"))
	modal_body.add_child(button("重载配置并清除本局覆盖", func():
		model.state.balance_overrides = {}
		model.reload_balance()
		open_panel("数值面板"), false, "dev:reload"))
	var initial_loyalty: float = float(model.balance.get("initial.loyalty", 60))
	var loyalty_factor: float = 1.0
	if initial_loyalty >= float(model.balance.get("employee.loyalty_high_threshold", 80)): loyalty_factor = float(model.balance.get("employee.loyalty_high_mult", 0.9))
	elif initial_loyalty < float(model.balance.get("employee.loyalty_low_threshold", 30)): loyalty_factor = float(model.balance.get("employee.loyalty_low_mult", 1.2))
	var wage: float = float(model.balance.get("employee.base_wage", 40)) * (2 + 2 * float(model.balance.get("employee.rarity_N", 0)) + float(model.balance.get("employee.role_chef", 0.2)) + float(model.balance.get("employee.role_waiter", 0))) * loyalty_factor
	var interest: float = float(model.balance.get("initial.debt", 1200)) * float(model.balance.get("economy.interest_rate", 0.005))
	var normal_fixed: float = wage + float(model.balance.get("economy.rent",60)) + float(model.balance.get("economy.utilities",20)) + interest
	var protection_cash: float = wage + interest + minf(float(model.balance.get("initial.debt",1200)),float(model.balance.get("economy.minimum_repayment",100)) * float(model.balance.get("finance.protection.minimum_repayment_multiplier",0.5)))
	var fixed_cash: float = normal_fixed + minf(float(model.balance.get("initial.debt",1200)),float(model.balance.get("economy.minimum_repayment",100)))
	paragraph("当前配置开局测算：两名N级厨师/服务员日工资￥%.2f；保护期免租金水电，含利息和减半还本的现金支出￥%.2f/天；保护期后现金支出￥%.2f/天。还本不计利润费用。" % [wage,protection_cash,fixed_cash],MUTED)
	paragraph("按日营业额400–500元、食材约30%%估算：保护期日现金结余￥%.2f至￥%.2f；保护期后￥%.2f至￥%.2f。此为调参诊断，实际经营受客流、缺货与效率影响。" % [280 - protection_cash,350 - protection_cash,280 - fixed_cash,350 - fixed_cash],Color("ad6e51") if 350 - fixed_cash < 0 else MUTED)
	var loss_dishes: Array[String] = []
	for dish in model.dishes:
		if float(dish.cost) >= float(dish.price): loss_dishes.append(str(dish.name))
	paragraph("售价与成本检查：" + ("所有当前菜品售价均高于配方成本。" if loss_dishes.is_empty() else "以下菜品售价不高于成本：" + "、".join(loss_dishes)), MUTED if loss_dishes.is_empty() else Color("ad6e51"))

func art_panel() -> void:
	paragraph("替换美术", GREEN)
	paragraph("自定义目录：" + str(assets.custom_root), MUTED)
	paragraph("六类资源：Portraits立绘、Sprites四方向动作、UI界面、Map箱庭、Items菜品道具、FX图标。旧四类目录仍兼容，接入说明随构建附带。", MUTED)
	_import_path = LineEdit.new()
	_import_path.placeholder_text = "目标相对路径，例如 Sprites/xian_yang/idle_down_0.png"
	_import_path.text = "Characters/qianyang_idle.png"
	modal_body.add_child(_import_path)
	paragraph("选择资源类别与角色/动作/方向后导入；立绘、场景和文化专图相互独立。也可手填约定路径。", MUTED)
	var culture_slots = OptionButton.new()
	_art_culture_slots = culture_slots
	culture_slots.set_meta("qa_id", "art:culture-slot")
	culture_slots.add_item("手动填写目标路径")
	culture_slots.set_item_metadata(0, "")
	var groups: Array = [{"kind":"employees", "entries":model.catalog}]
	var dish_entries: Array = model.dishes.duplicate()
	var hidden: Dictionary = model.full_rules.management.config.get("hidden_recipe", {}) if model.full_rules != null else {}
	if not hidden.is_empty() and not dish_entries.any(func(dish): return str(dish.id) == str(hidden.get("id", ""))): dish_entries.append(hidden)
	groups.append({"kind":"dishes", "entries":dish_entries})
	for group in groups:
		for entry in group.entries:
			var resource_id: String = assets.culture_resource_id(str(group.kind), str(entry.id))
			culture_slots.add_item(("员工 · " if group.kind == "employees" else "菜品 · ") + str(entry.name))
			culture_slots.set_item_metadata(culture_slots.item_count - 1, resource_id + ".png")
	for guest in model.full_rules.visitors.definitions():
		for suffix in ["_lore","_idle"]:
			culture_slots.add_item("来客 · "+str(guest.name)+(" · 简介" if suffix=="_lore" else " · 场景"))
			culture_slots.set_item_metadata(culture_slots.item_count-1,"Characters/guest_"+str(guest.id)+suffix+".png")
	for slot in [["钞票拾取图标","UI/pickup_cash.png"],["灵石拾取图标","UI/pickup_gem.png"]]:
		culture_slots.add_item(slot[0]);culture_slots.set_item_metadata(culture_slots.item_count-1,slot[1])
	for slot in JSON.parse_string(FileAccess.get_file_as_string("res://assets/art/manifest.json")).get("dollhouse_slots",[]):
		culture_slots.add_item("箱庭 · "+str(slot.name));culture_slots.set_item_metadata(culture_slots.item_count-1,str(slot.path))
	for slot in preload("res://scripts/ui/art_targets.gd").slots(model):
		culture_slots.add_item(str(slot.name));culture_slots.set_item_metadata(culture_slots.item_count-1,str(slot.path))
	culture_slots.item_selected.connect(func(index):
		var path: String = str(culture_slots.get_item_metadata(index))
		if not path.is_empty(): _import_path.text = path)
	modal_body.add_child(culture_slots)
	modal_body.add_child(button("选择PNG/JPG图片并导入", select_art_file, true, "art:import"))
	modal_body.add_child(button("立即重新扫描素材目录", func(): assets.reload(); show_notice("美术资源已重载"), false, "art:reload"))
	paragraph("自定义图片优先，缺图时使用内置素材或占位图。桌面版可直接把图片放入程序旁CustomAssets；网页版使用此处选择文件，文件保存于浏览器本地存储。", MUTED)
	if not assets.last_errors.is_empty(): paragraph("加载提示：" + "；".join(assets.last_errors), Color("aa7659"))

func select_art_file() -> void:
	var target_path: String = _import_path.text.strip_edges()
	if OS.has_feature("web"):
		_file_callback = JavaScriptBridge.create_callback(func(arguments):
			if arguments.size() < 1: return
			var bytes = Marshalls.base64_to_raw(str(arguments[0]))
			_import_art(bytes, target_path))
		var window = JavaScriptBridge.get_interface("window")
		window.shanhaiImportCallback = _file_callback
		JavaScriptBridge.eval("""(()=>{const e=document.createElement('input');e.type='file';e.accept='image/png,image/jpeg';e.onchange=()=>{const f=e.files[0];if(!f)return;if(f.size>32*1024*1024){alert(__SIZE_WARNING__);return;}const r=new FileReader();r.onload=()=>window.shanhaiImportCallback(String(r.result).split(',')[1]);r.readAsDataURL(f);};e.click();})()""".replace("__SIZE_WARNING__",JSON.stringify(localization.translate("图片不能超过32MB"))), true)
	else:
		var dialog = FileDialog.new()
		dialog.access = FileDialog.ACCESS_FILESYSTEM
		dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		dialog.filters = PackedStringArray(["*.png,*.jpg,*.jpeg ; "+localization.translate("PNG/JPG 图片")])
		dialog.title=localization.translate("选择图片")
		add_child(dialog)
		dialog.file_selected.connect(func(path):
			_import_art(FileAccess.get_file_as_bytes(path), target_path)
			dialog.queue_free())
		dialog.canceled.connect(dialog.queue_free)
		dialog.popup_centered_ratio(0.75)

func _import_art(bytes: PackedByteArray, path: String) -> void:
	var result: Dictionary = assets.import_image(bytes, path)
	if OS.has_feature("web") and bool(result.get("ok",false)):JavaScriptBridge.force_fs_sync()
	_art_import_result = result.duplicate(true)
	show_notice("图片已导入：" + path if bool(result.get("ok", false)) else "导入失败：" + str(result.get("error", "图片格式或路径无效")))

func ledger_panel() -> void:
	if not model._full(): paragraph("完整经营模式开放财务账本。", MUTED); return
	arrears_control()
	var ledger: Dictionary = model.state.ledger
	var raw: float = model.full_rules.management.inventory_value()
	var prepared: float = model.full_rules.expansion.prepared_inventory_value()
	for customer in model.customers:
		if bool(customer.get("ingredients_reserved", false)) and not bool(customer.get("paid",false)): prepared += float(customer.get("ingredient_cost",0))
	var receivables: float = float(ledger.get("receivables",0))
	var liabilities: float = float(model.state.debt) + float(model.state.interest_arrears) + float(model.state.wage_arrears) + float(model.state.rent_arrears)
	var assets_total: float = float(model.state.cash) + raw + prepared + receivables + float(ledger.get("capital", 0))
	var profit: float = float(ledger.get("sales", 0)) + float(ledger.get("other_income", 0)) - float(ledger.get("cost_of_sales", 0)) - float(ledger.get("expenses", 0))
	paragraph("资产 ￥%.2f · 负债 ￥%.2f · 净资产 ￥%.2f" % [assets_total, liabilities, assets_total-liabilities], GREEN)
	paragraph("现金 ￥%.2f · 原料存货 ￥%.2f · 在制/成品 ￥%.2f · 应收款 ￥%.2f" % [float(model.state.cash),raw,prepared,receivables])
	paragraph("累计收入 ￥%.2f · 已结转成本 ￥%.2f · 费用 ￥%.2f · 简化利润 ￥%.2f" % [float(ledger.get("sales",0)) + float(ledger.get("other_income",0)),float(ledger.get("cost_of_sales",0)),float(ledger.get("expenses",0)),profit])
	paragraph("教学简化：采购先计存货，实际耗用再结转成本；还本减少现金和负债，利息计费用。资本投入暂不折旧，事件奖励单列；退款、赠送与测试调参可能需要人工复核。", MUTED)
	for item in ledger.get("records", []).slice(-30):
		paragraph("%s · %s ￥%.2f" % [str(item.get("description","")),str(item.get("type","")),float(item.get("amount",0))],MUTED)

func arrears_control() -> void:
	if not model._full(): return
	paragraph("待清偿：欠息￥%.2f · 欠薪￥%.2f · 欠租￥%.2f" % [float(model.state.interest_arrears), float(model.state.wage_arrears), float(model.state.rent_arrears)], MUTED)
	var destination: String = panel_name
	var action: Button = button("用现有现金清偿欠款", func():
		var result: Dictionary = model.full_rules.perform("settle_arrears")
		if bool(result.get("ok", false)):
			model.autosave_requested.emit()
			show_notice("已清偿￥%.2f，余欠￥%.2f" % [float(result.get("paid", 0)), float(result.get("remaining", 0))])
		else: show_notice(str(result.get("reason", "当前无法清偿")))
		open_panel(destination), false, "finance:settle_arrears")
	var check: Dictionary = model.full_rules.can_perform("settle_arrears")
	action.disabled = not bool(check.get("ok", false))
	action.tooltip_text = str(check.get("reason", "")) if action.disabled else "依次清偿欠息、欠薪和欠租；不重复计入费用。"
	modal_body.add_child(action)


func _refresh_art_controls() -> void:
	for binding in _art_controls:
		var node: Variant = binding.node.get_ref()
		if node == null or not is_instance_valid(node): continue
		if str(binding.type) == "texture_optional":
			node.visible = assets.has_image(str(binding.id))
			node.texture = assets.get_texture(str(binding.id)) if node.visible else null
		elif str(binding.type) == "texture": node.texture = assets.get_texture(str(binding.id))
		else:
			node.icon = assets.get_texture(str(binding.id)) if assets.has_image(str(binding.id)) else null
			node.expand_icon = true
			node.add_theme_constant_override("icon_max_width", 28)

func guide_button_allowed(id: String) -> bool:
	if id.begins_with("locale:"): return true
	if panel_name in ["欢迎","文化简介","开发者选项","美术资源","声音设置","数值面板","破产救援","贷款"]: return true
	return Guide.allows_button(model,id)

func tutorial_time_runs() -> bool:
	if tutorial_overlay == null: return false
	return tutorial_overlay.current_step().has("stage")

func rescue_pending() -> bool:
	return model != null and bool(model.state.get("finance",{}).get("rescue",{}).get("pending",false))

func _poll_finance_ui(delta: float) -> void:
	for index in range(_cash_floats.size() - 1,-1,-1):
		var floating: Dictionary = _cash_floats[index]
		floating.left = float(floating.left) - delta
		var node = floating.node.get_ref()
		if node == null or float(floating.left) <= 0:
			if node != null: node.queue_free()
			_cash_floats.remove_at(index)
		else:
			node.position.y += delta * 10
			node.modulate.a = minf(1,float(floating.left))
	var flows: Array = model.state.get("finance",{}).get("flows",[])
	var flow_sequence = int(model.state.get("finance",{}).get("sequence",0))
	if _cash_flow_seen < 0 or flow_sequence < _cash_flow_seen: _cash_flow_seen = flow_sequence
	if int(model.state.get("finance",{}).get("sequence",0)) > _cash_flow_seen:
		var new_entries: Array = []
		for index in range(flows.size() - 1,-1,-1):
			if int(flows[index].get("id",0)) <= _cash_flow_seen: break
			new_entries.push_front(flows[index])
		for entry in new_entries:
			_cash_flow_seen = int(entry.id)
			cash_float(str(entry.get("description",entry.get("type","资金变动"))),float(entry.get("amount",0)),str(entry.get("type","other")))
	if rescue_pending() and not model.state.rescue171.ended and panel_name != "破产救援" and panel_name != "贷款":
		model.set_paused(true)
		open_panel("破产救援")
	var bill_day = int(model.state.get("finance",{}).get("last_bill_day",0))
	if _finance_bill_seen < 0 or bill_day < _finance_bill_seen: _finance_bill_seen = bill_day
	if bill_day > _finance_bill_seen:
		_finance_bill_seen = bill_day
		show_notice("第%d日已结算：打开更多→账单查看每笔收支与现金核对。" % bill_day)

func cash_float(description: String, amount: float,kind: String="other") -> void:
	if _notice_clock-float(_cash_float_last.get(kind,-1000))<1:return
	_cash_float_last[kind]=_notice_clock
	if _cash_floats.size()>=2:return
	var node = label("%s %s￥%.2f" % [description,"+" if amount >= 0 else "−",absf(amount)],13,GREEN if amount >= 0 else Color("c25148"))
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	node.add_theme_stylebox_override("normal",small_notice_style())
	node.position = Vector2(maxf(8,money_label.global_position.x-80),money_label.global_position.y+money_label.size.y+6+(_cash_floats.size()%2)*22)
	node.z_index = 100
	add_child(node)
	_cash_floats.append({"node":weakref(node),"left":notice_duration(description)})

func small_notice_style() -> StyleBoxFlat:
	var paper=style(Color(1,1,.97,.96),6)
	paper.content_margin_left=6;paper.content_margin_right=6;paper.content_margin_top=3;paper.content_margin_bottom=3
	return paper

func show_requirement(message: String) -> void:
	if audio != null: audio.play_cue("ui.error")
	if is_instance_valid(_requirement_dialog): _requirement_dialog.dialog_text=message;return
	_requirement_dialog=AcceptDialog.new()
	_requirement_dialog.title="操作提示"
	_requirement_dialog.dialog_text=message
	add_child(_requirement_dialog)
	var dialog=_requirement_dialog
	dialog.get_ok_button().set_meta("qa_id","requirement:ack")
	_qa_buttons.append(dialog.get_ok_button())
	dialog.confirmed.connect(func():dialog.queue_free())
	dialog.canceled.connect(func():dialog.queue_free())
	dialog.popup_centered(Vector2i(460,180))

func confirm_action(title: String,message: String,on_confirm: Callable,qa_id: String) -> void:
	if is_instance_valid(_action_dialog):return
	_action_dialog=ConfirmationDialog.new()
	_action_dialog.title=title
	_action_dialog.dialog_text=message
	_action_dialog.ok_button_text="确认"
	_action_dialog.cancel_button_text="取消"
	add_child(_action_dialog)
	var dialog=_action_dialog
	dialog.get_ok_button().set_meta("qa_id",qa_id)
	dialog.get_cancel_button().set_meta("qa_id",qa_id+":cancel")
	_qa_buttons.append(dialog.get_ok_button());_qa_buttons.append(dialog.get_cancel_button())
	dialog.confirmed.connect(func():dialog.hide();dialog.queue_free();on_confirm.call())
	dialog.canceled.connect(func():dialog.queue_free())
	dialog.popup_centered(Vector2i(480,230))

func pixel_skin(id: String,margin: int=8) -> StyleBoxTexture:
	var skin=StyleBoxTexture.new();skin.texture=assets.get_texture(id);skin.set_content_margin_all(12)
	skin.texture_margin_left=margin;skin.texture_margin_right=margin;skin.texture_margin_top=margin;skin.texture_margin_bottom=margin
	return skin


func language_controls(parent: Node) -> void:
	var controls=row(8)
	parent.add_child(controls)
	for code in ["zh","en"]:
		var next=str(code)
		controls.add_child(button("中文" if next=="zh" else "English",func():set_interface_language(next),localization!=null and localization.language==next,"locale:"+next))

func set_interface_language(code: String) -> void:
	if localization==null: localization=preload("res://scripts/services/localization.gd").new()
	localization.set_language(code)
	get_window().title="Shanhai Inn" if code=="en" else "山海食肆物语"
	_set_toast_text(_toast_source)
	if culture_panel!=null: culture_panel.language=code
	var settings=ConfigFile.new()
	settings.set_value("reading","language",code)
	settings.save("user://culture_preferences.cfg")
	if OS.has_feature("web"): JavaScriptBridge.force_fs_sync()
	if not panel_name.is_empty(): open_panel(panel_name,false)
	refresh()
	localization.apply_tree(self)
	if map_view!=null: map_view.localization=localization;map_view.queue_redraw()
