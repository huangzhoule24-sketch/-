extends Node
## Audio is a presentation service. It never reads/writes the campaign or its RNG.
signal changed
const CONFIG_PATH = "res://config/audio.json"
const CHANNELS = {"master":"Master", "music":"Music", "sfx":"SFX", "ambience":"Ambience"}
const EXTENSIONS = ["ogg", "mp3", "wav"]
const MAX_BYTES = 64 * 1024 * 1024
var builtin_root: String
var custom_root: String
var settings_path: String
var config: Dictionary = {}
var levels = {"master":0.8, "music":0.65, "sfx":0.75, "ambience":0.4}
var muted = false
var enabled = {"music":true, "sfx":true}
var _duck_until = 0.0
var _duck_gain_db = 0.0
var world_paused = true
var unlocked = false
var requested_music = ""
var requested_ambience = ""
var music_starts = 0
var played: Dictionary = {}
var last_errors: Array[String] = []
var _cache: Dictionary = {}
var _overrides: Dictionary = {}
var _next_allowed: Dictionary = {}
var _variant: Dictionary = {}
var _music: Array[AudioStreamPlayer] = []
var _ambient: Array[AudioStreamPlayer] = []
var _voices: Array[AudioStreamPlayer] = []
var _preview: AudioStreamPlayer
var _active = {"music":-1, "ambience":-1}
var _current = {"music":"", "ambience":""}
var _fades: Dictionary = {}
var _clock = 0.0
var _save_in = -1.0

func _init(builtin_directory = "res://assets/audio", custom_directory = "", preferences = "user://audio_settings.cfg"):
	builtin_root = builtin_directory.trim_suffix("/")
	custom_root = custom_directory.trim_suffix("/") if not custom_directory.is_empty() else default_custom_root()
	settings_path = preferences

static func default_custom_root() -> String:
	if OS.has_feature("web"): return "user://CustomAudio"
	if OS.has_feature("editor"): return "res://CustomAudio"
	return OS.get_executable_path().get_base_dir().path_join("CustomAudio")

func _ready():
	for channel in ["Music", "SFX", "Ambience"]:
		if AudioServer.get_bus_index(channel) < 0:
			# add_bus() normalizes end insertion to -1; the Web sample bridge
			# moves that index differently. Resizing appends without reordering Master.
			var index = AudioServer.bus_count
			AudioServer.bus_count = index + 1
			AudioServer.set_bus_name(index, channel); AudioServer.set_bus_send(index, "Master")
	for i in range(2):
		_music.append(_player("Music")); _ambient.append(_player("Ambience"))
	for i in range(8): _voices.append(_player("SFX"))
	_preview = _player("SFX")
	_preview.finished.connect(stop_preview)
	unlocked = not OS.has_feature("web")
	_load_settings(); _apply_levels(); reload()

func _player(bus_name: String) -> AudioStreamPlayer:
	var player = AudioStreamPlayer.new(); player.bus = bus_name
	add_child(player); return player

func _process(delta: float):
	_clock += maxf(0, delta)
	_update_music_duck(delta)
	if _save_in >= 0:
		_save_in -= delta
		if _save_in < 0: save_settings()

func _exit_tree():
	if _save_in >= 0: save_settings()

func unlock():
	if unlocked: return
	unlocked = true
	_switch_loop("music", requested_music, true)
	_switch_loop("ambience", requested_ambience, true)

func reload():
	stop_preview()
	for tween in _fades.values():
		if is_instance_valid(tween): tween.kill()
	_fades.clear()
	for player in _music + _ambient + _voices: player.stop()
	_cache.clear(); _next_allowed.clear(); last_errors.clear()
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(CONFIG_PATH))
	config = parsed if parsed is Dictionary else {}
	_active = {"music":-1, "ambience":-1}; _current = {"music":"", "ambience":""}
	_switch_loop("music", requested_music, true); _switch_loop("ambience", requested_ambience, true)
	changed.emit()

static func safe_path(path: String) -> bool:
	return not path.is_empty() and not path.is_absolute_path() and not ":" in path and not "\\" in path and not ".." in path.split("/") and path.get_extension().to_lower() in EXTENSIONS

func _candidates(cue: String) -> Array:
	var definition: Dictionary = config.get("cues", {}).get(cue, {})
	var result: Array = []
	var override = str(_overrides.get(cue, ""))
	if safe_path(override): result.append(override)
	for base in definition.get("files", []):
		if not safe_path(str(base)): continue
		for ext in EXTENSIONS:
			var file = str(base).get_basename() + "." + ext
			if not file in result: result.append(file)
	return result

func resource_paths(cue: String) -> Array:
	# Custom files have priority over every bundled format, not only a matching suffix.
	var result: Array = []
	for root_path in [custom_root, builtin_root]:
		for relative in _candidates(cue):
			var path = root_path.path_join(relative)
			if FileAccess.file_exists(path) or (root_path == builtin_root and ResourceLoader.exists(path)):
				result.append(path)
	return result

func _decode(bytes: PackedByteArray, extension: String) -> AudioStream:
	if bytes.size() < 16 or bytes.size() > MAX_BYTES: return null
	match extension:
		"ogg":
			if bytes.slice(0,4).get_string_from_ascii() != "OggS": return null
			return AudioStreamOggVorbis.load_from_buffer(bytes)
		"wav":
			if bytes.slice(0,4).get_string_from_ascii() != "RIFF" or bytes.slice(8,12).get_string_from_ascii() != "WAVE": return null
			return AudioStreamWAV.load_from_buffer(bytes)
		"mp3":
			if bytes.slice(0,3).get_string_from_ascii() != "ID3" and not (bytes[0] == 255 and (bytes[1] & 224) == 224): return null
			return AudioStreamMP3.load_from_buffer(bytes)
	return null

func _stream(path: String) -> AudioStream:
	if _cache.has(path): return _cache[path]
	var stream: AudioStream
	if path.begins_with("res://assets/audio/") and ResourceLoader.exists(path):
		stream = load(path) as AudioStream
	else:
		var file = FileAccess.open(path, FileAccess.READ)
		if file != null and file.get_length() <= MAX_BYTES:
			stream = _decode(file.get_buffer(file.get_length()), path.get_extension().to_lower())
	_cache[path] = stream
	if stream == null: last_errors.append("无法读取音频：" + path)
	return stream

static func set_loop(stream: AudioStream, enabled: bool):
	if stream is AudioStreamWAV:
		var samples = roundi(stream.get_length() * stream.mix_rate)
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD if enabled else AudioStreamWAV.LOOP_DISABLED
		stream.loop_begin = 0; stream.loop_end = samples
	elif stream is AudioStreamOggVorbis or stream is AudioStreamMP3:
		stream.loop = enabled

func cue_stream(cue: String, looped = false) -> AudioStream:
	var paths = resource_paths(cue)
	if paths.is_empty(): return null
	# Pick one format per variant basename; prefer the custom root as a whole.
	for root_path in [custom_root, builtin_root]:
		var variants: Array = []; var basenames: Dictionary = {}
		for path in paths:
			if not str(path).begins_with(root_path + "/"): continue
			var base = str(path).get_basename()
			if basenames.has(base): continue
			var raw = _stream(str(path))
			if raw != null:
				raw.set_meta("audio_source_path",str(path))
				variants.append(raw); basenames[base] = true
		if variants.is_empty(): continue
		var index = int(_variant.get(cue, 0)) % variants.size()
		var stream = variants[index].duplicate() as AudioStream
		set_loop(stream, looped); _variant[cue] = index + 1
		return stream
	return null

func play_cue(cue: String, world = false) -> bool:
	if not unlocked or not bool(enabled.sfx) or muted or float(levels.master) <= 0 or float(levels.sfx) <= 0 or (world and world_paused): return false
	var definition: Dictionary = config.get("cues", {}).get(cue, {})
	if definition.is_empty() or str(definition.get("bus", "SFX")) != "SFX": return false
	var gate = "world" if world else "ui" if cue in ["ui.click","ui.back"] else "feedback"
	if _clock < float(_next_allowed.get(cue, -1)) or _clock < float(_next_allowed.get(gate, -1)): return false
	var pool = _voices.slice(0, 6) if world else _voices.slice(6, 8)
	var voice: AudioStreamPlayer
	for player in pool:
		if not player.playing: voice = player; break
	if voice == null: return false
	var stream = cue_stream(cue)
	if stream == null: return false
	voice.stream = stream; voice.volume_db = clampf(float(definition.get("gain_db", 0)), -40, 6)
	voice.set_meta("world", world); voice.play()
	if cue.begins_with("event.") or cue in ["guest.special","ui.error"]:
		_duck_until = maxf(_duck_until,_clock + float(config.get("mixing",{}).get("duck_hold_seconds",.22)))
	_next_allowed[cue] = _clock + maxf(.04, float(definition.get("cooldown", .15)))
	_next_allowed[gate] = _clock + (.16 if world else .04)
	played[cue] = int(played.get(cue, 0)) + 1
	return true

func set_music(cue: String):
	if requested_music == cue: return
	requested_music = cue; _switch_loop("music", cue)

func set_ambience(cue: String):
	if requested_ambience == cue: return
	requested_ambience = cue; _switch_loop("ambience", cue)

func _switch_loop(kind: String, cue: String, immediate = false):
	if not unlocked or _music.is_empty(): return
	if not bool(enabled.music if kind=="music" else enabled.sfx):return
	var players = _music if kind == "music" else _ambient
	var stream = cue_stream(cue, true) if not cue.is_empty() else null
	var old = int(_active[kind])
	# Shared background fallback is one recording, even across five contexts.
	# Keep the playing cursor (and any running crossfade) when its source is unchanged.
	if stream!=null and old>=0 and players[old].playing and players[old].stream!=null and str(stream.get_meta("audio_source_path",""))==str(players[old].stream.get_meta("audio_source_path","different")):
		_current[kind]=cue
		_apply_playback_pause()
		return
	if _fades.has(kind) and is_instance_valid(_fades[kind]): _fades[kind].kill()
	var next = 0 if old != 0 else 1
	var tween = create_tween().set_parallel(true)
	_fades[kind] = tween
	var duration = .01 if immediate else clampf(float(config.get("crossfade_seconds", 1.2)), .05, 5)
	if stream != null:
		players[next].stop(); players[next].stream = stream
		players[next].volume_db = -60
		players[next].stream_paused = false; players[next].play()
		_apply_playback_pause()
		var definition: Dictionary = config.cues.get(cue, {})
		tween.tween_property(players[next], "volume_db", clampf(float(definition.get("gain_db", 0)), -40, 6), duration)
		_active[kind] = next; _current[kind] = cue
		if kind == "music": music_starts += 1
	else:
		_active[kind] = -1; _current[kind] = ""
	for i in range(players.size()):
		if stream != null and i == next: continue
		tween.tween_property(players[i], "volume_db", -60.0, duration)
		tween.chain().tween_callback(players[i].stop)

func set_world_paused(value: bool):
	if world_paused == value: return
	world_paused = value
	_apply_playback_pause()
	if value:
		for player in _voices:
			if bool(player.get_meta("world", false)): player.stop()

func preview(cue: String) -> bool:
	if not is_cue_enabled(cue):return false
	unlock(); stop_preview()
	var stream = cue_stream(cue)
	if stream == null: return false
	var definition: Dictionary = config.cues.get(cue, {})
	_preview.bus = str(definition.get("bus", "SFX"))
	_preview.volume_db = clampf(float(definition.get("gain_db", 0)), -40, 6)
	_preview.stream = stream; _preview.play()
	for player in _music + _ambient: player.stream_paused = true
	return true

func stop_preview():
	if _preview == null: return
	_preview.stop()
	_apply_playback_pause()

func _apply_playback_pause():
	var previewing=_preview!=null and _preview.playing
	for player in _music:player.stream_paused=previewing or not bool(enabled.music)
	for player in _ambient:player.stream_paused=previewing or world_paused or not bool(enabled.sfx)

func is_cue_enabled(cue:String) -> bool:
	var bus=str(config.get("cues",{}).get(cue,{}).get("bus",""))
	if muted or float(levels.master)<=0:return false
	if bus=="Music":return bool(enabled.music) and float(levels.music)>0
	if bus=="SFX":return bool(enabled.sfx) and float(levels.sfx)>0
	if bus=="Ambience":return bool(enabled.sfx) and float(levels.ambience)>0
	return false

func set_channel_enabled(channel:String,value:bool):
	if not enabled.has(channel) or bool(enabled[channel])==value:return
	enabled[channel]=value
	if not value:
		if channel=="sfx":
			for voice in _voices:voice.stop()
			_duck_until=_clock
		if _preview!=null and _preview.playing and ((_preview.bus=="Music")== (channel=="music")):stop_preview()
	_apply_levels()
	_apply_playback_pause()
	if value:_switch_loop(channel if channel=="music" else "ambience",requested_music if channel=="music" else requested_ambience)
	_save_in=.4
	changed.emit()

func _music_bus_db() -> float:
	return linear_to_db(maxf(.00001,float(levels.music)))+_duck_gain_db

func _update_music_duck(delta:float):
	var mixing:Dictionary=config.get("mixing",{})
	var depth=clampf(float(mixing.get("music_duck_db",-3.0)),-9.0,0.0)
	var target=depth if _clock<_duck_until and bool(enabled.sfx) else 0.0
	var seconds=maxf(.01,float(mixing.get("duck_attack_seconds",.06) if target<_duck_gain_db else mixing.get("duck_release_seconds",.35)))
	var next=move_toward(_duck_gain_db,target,absf(depth)*maxf(delta,0)/seconds)
	if is_equal_approx(next,_duck_gain_db):return
	_duck_gain_db=next
	var index=AudioServer.get_bus_index("Music")
	if index>=0:AudioServer.set_bus_volume_db(index,_music_bus_db())

func set_level(channel: String, value: float):
	if not levels.has(channel) or not is_finite(value): return
	levels[channel] = clampf(value, 0, 1); _apply_levels(); _save_in = .4

func set_muted(value: bool):
	muted = value; _apply_levels(); _save_in = .4

func _apply_levels():
	for channel in CHANNELS:
		var index = AudioServer.get_bus_index(CHANNELS[channel])
		if index < 0: continue
		AudioServer.set_bus_volume_db(index, _music_bus_db() if channel=="music" else linear_to_db(maxf(.00001, float(levels[channel]))))
		AudioServer.set_bus_mute(index, (channel == "master" and muted) or float(levels[channel]) <= 0 or (channel=="music" and not bool(enabled.music)) or (channel in ["sfx","ambience"] and not bool(enabled.sfx)))

func _load_settings():
	var file = ConfigFile.new()
	if file.load(settings_path) != OK: return
	for channel in levels:
		var value = float(file.get_value("volume", channel, levels[channel]))
		if is_finite(value): levels[channel] = clampf(value, 0, 1)
	muted = bool(file.get_value("volume", "muted", false))
	for channel in enabled:enabled[channel]=bool(file.get_value("switches",channel,true))
	var overrides = file.get_value("audio", "overrides", {})
	if overrides is Dictionary: _overrides = overrides

func save_settings() -> Error:
	var file = ConfigFile.new()
	for channel in levels: file.set_value("volume", channel, levels[channel])
	for channel in enabled:file.set_value("switches",channel,enabled[channel])
	file.set_value("volume", "muted", muted); file.set_value("audio", "overrides", _overrides)
	var result = file.save(settings_path)
	if result == OK and OS.has_feature("web"): JavaScriptBridge.force_fs_sync()
	_save_in = -1; return result

func import_bytes(cue: String, bytes: PackedByteArray, extension: String) -> Dictionary:
	extension = extension.to_lower().trim_prefix(".")
	var definition: Dictionary = config.get("cues", {}).get(cue, {})
	if definition.is_empty() or not extension in EXTENSIONS: return {"ok":false, "error":"请选择有效槽位及OGG、MP3或WAV文件。"}
	if bytes.size() > MAX_BYTES: return {"ok":false, "error":"单个音频不能超过64MB。"}
	var stream = _decode(bytes, extension)
	if stream == null or stream.get_length() <= 0: return {"ok":false, "error":"音频无法解码，请重新导出文件。"}
	var relative = str(definition.files[0]).get_basename() + "." + extension
	if not safe_path(relative): return {"ok":false, "error":"音频槽位路径无效。"}
	var path = custom_root.path_join(relative)
	if DirAccess.make_dir_recursive_absolute(path.get_base_dir()) != OK: return {"ok":false, "error":"音频目录无法写入。"}
	var file = FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if file == null: return {"ok":false, "error":"音频文件无法写入。"}
	file.store_buffer(bytes); var error = file.get_error(); file.close()
	if error != OK or DirAccess.rename_absolute(path + ".tmp", path) != OK: return {"ok":false, "error":"保存音频失败。"}
	_overrides[cue] = relative; save_settings(); reload()
	if OS.has_feature("web"): JavaScriptBridge.force_fs_sync()
	return {"ok":true, "path":relative, "seconds":stream.get_length()}

func snapshot() -> Dictionary:
	var index = int(_active.music)
	var playing = index >= 0 and _music[index].playing
	var ambient_index = int(_active.ambience)
	var ambient_playing = ambient_index >= 0 and _ambient[ambient_index].playing
	return {"requested_music":requested_music, "active_music":_current.music, "music_playing":playing, "music_position":_music[index].get_playback_position() if index>=0 else 0.0, "requested_ambience":requested_ambience, "active_ambience":_current.ambience, "ambience_playing":ambient_playing, "ambience_position":_ambient[ambient_index].get_playback_position() if ambient_index>=0 else 0.0, "ambience_paused":ambient_index>=0 and _ambient[ambient_index].stream_paused, "world_paused":world_paused, "unlocked":unlocked, "muted":muted, "enabled":enabled.duplicate(), "duck_gain_db":_duck_gain_db, "music_paused":index>=0 and _music[index].stream_paused, "levels":levels.duplicate(), "music_starts":music_starts, "played":played.duplicate(), "cue_count":config.get("cues",{}).size(), "preview_playing":_preview != null and _preview.playing}
