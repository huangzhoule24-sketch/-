# 山海食肆物语 · 山海小传文学新编

当前下载：[Windows游戏](https://github.com/huangzhoule24-sketch/-/raw/culture-literary-v1.9.5-20261029/downloads/shanhai-v1.9.5-culture-literary-windows.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/culture-literary-v1.9.5-20261029/downloads/shanhai-v1.9.5-culture-literary-source.zip) · [独立中英读本](https://github.com/huangzhoule24-sketch/-/raw/culture-literary-v1.9.5-20261029/downloads/shanhai-culture-literary-reading.zip)。

2026-10-29：61篇中英文小传全部文学重写，角色形貌与性情、菜品火候与滋味、名字和故事的跨文化旅行；34处古文新增中文白话。菜单分开展示招牌伙伴与用料。详见[说明](docs/culture-literary.md)与[验证](docs/culture-literary-validation.md)。

人物与字体修订版：[Windows游戏](https://github.com/huangzhoule24-sketch/-/raw/c7af10bdcc974ac7458122feeffa8244c3a4af4f/downloads/shanhai-v1.9.5-clarity-fix-windows.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/c7af10bdcc974ac7458122feeffa8244c3a4af4f/downloads/shanhai-v1.9.5-clarity-fix-source.zip)。

2026-10-28：分开服务员与顾客座位，移动人物局部避让；限制新增桌位重叠，旧档可保留并逐步调整。正文使用清晰中文字体，场景文字不随地图缩小，姓名及设施标签避让。详见[修订说明](docs/clarity-fix.md)。

[柔和长笛MP3](https://github.com/huangzhoule24-sketch/-/raw/af899157d14aaf5657bb7a71ff30c84817c34a87/downloads/youjian-major-flute-balanced.mp3)：降低长笛并柔化高频，提高低音，音乐独立交付，未导入游戏。

上一版像素更新下载：[Windows游戏](https://github.com/huangzhoule24-sketch/-/raw/816e9362e687c7dae5a0d5912f9235bdc2a869ac/downloads/shanhai-v1.9.5-pixel-refresh-windows.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/816e9362e687c7dae5a0d5912f9235bdc2a869ac/downloads/shanhai-v1.9.5-pixel-refresh-source.zip)。


本版下载：[Windows游戏](https://github.com/huangzhoule24-sketch/-/raw/8be69dd44fbe99a5397c8e8684d50b25c6b1aedb/downloads/shanhai-v1.9.5-culture-intro-windows.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/8be69dd44fbe99a5397c8e8684d50b25c6b1aedb/downloads/shanhai-v1.9.5-culture-intro-source.zip) · [中英读本](https://github.com/huangzhoule24-sketch/-/raw/8be69dd44fbe99a5397c8e8684d50b25c6b1aedb/downloads/shanhai-culture-intro-reading.zip)。

2026-10-28 画面与交互更新：左键直接拖动、低频且多样的顾客气泡、气泡避让人物、像素画布与字体、加大并相对的桌椅。新局桌位分两排，旧档布局保留。详见[本轮说明](docs/pixel-refresh.md)。音乐继续单独试听。

2026-10-28 文化简介更新：30位员工、25道菜品和6位特殊来客的中英文开篇均已重新撰写，明确游戏身份与文化背景，保留详细文化故事和古文短引。

2026-10-27 音效整合：已加入42个免费授权音频文件，覆盖28类短音效、2类环境声，含步行/飞行/爬行和工作动作变体。打开游戏即可使用，在「更多 → 系统与存档 → 声音设置与音频导入」调整音量、静音或替换素材。作者、许可、编辑过程见[整合说明](docs/free-sfx/guide.md)。背景音乐仍留空。实际验证见[音效检查记录](docs/free-sfx-validation.md)。

音效整合版下载：[Windows游戏](https://github.com/huangzhoule24-sketch/-/raw/b9020e7cce7837a1dc65414ff1f388d9acdea681/downloads/shanhai-v1.9.5-free-sfx-windows.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/b9020e7cce7837a1dc65414ff1f388d9acdea681/downloads/shanhai-v1.9.5-free-sfx-source.zip) · [独立音效与离线试听](https://github.com/huangzhoule24-sketch/-/raw/b9020e7cce7837a1dc65414ff1f388d9acdea681/downloads/shanhai-free-sfx-audio.zip)。

2026-10-27 文化新编：30位员工、25道菜品与6位来客的小传已重写，文化页支持中文/English完整正文与34处古文短引。阅读方法见[文化说明](docs/culture-guide.md)，全文见[中英读本](docs/culture-entries.md)。原美术、音频导入与旧档进度保留。

文化新编下载：[Windows](https://github.com/huangzhoule24-sketch/-/raw/cd098c7cbd76ca25d45fc269e22e491e6f2ddc53/downloads/shanhai-v1.9.5-culture-reading-windows.zip) · [中英读本](https://github.com/huangzhoule24-sketch/-/raw/cd098c7cbd76ca25d45fc269e22e491e6f2ddc53/downloads/shanhai-culture-reading-zh-en.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/cd098c7cbd76ca25d45fc269e22e491e6f2ddc53/downloads/shanhai-v1.9.5-culture-reading-source.zip)。

依据[最新策划案](docs/design-v1.9.5.txt)，从v1.9.1完整单机版更新为固定俯视箱庭地图，店内、庭院和街道同图，员工与顾客按Y排序、支持四方向动作。使用Godot4.6.3，保留30员工、23设计菜与2隐藏菜、61篇中英文化阅读和阶段0–4经营系统；已导入的完整美术与缺图回退并存。

删除销售员荐菜和个人溢价，服务员独立点单并可基础收银；销售员负责宣传、高效收银和客诉。顶部待办只承载阶段任务，教学独立显示。新增照片框、引导立绘、六类美术导入与完整动作方向接口，旧ID存档及旧资源路径兼容。

采用口径见[修订对照](docs/v1.9.5-delta.md)，实际检查与下载见[验证记录](docs/v1.9.5-validation.md)，美术接入见[资源清单](docs/山海食肆物语-美术资源清单.md)。交付沿用附件文件名v1.9.5，正文累积v2.1–v2.5修订。

## 座位遮挡修复

椅子先于人物绘制；同深度顺序固定，小数到达坐标不会切换图层。兼容现有存档，原美术资源仍可使用。详见[修复说明](docs/seat-layer-fix.md)。

## 本次美术整合

已接入30位员工水墨立绘、39套常规/觉醒员工像素小人、15套顾客、菜品道具、家具和独立餐椅、地面墙面庭院街道、像素UI及标题图。共274张最终PNG，1800组动画、14400个图集帧格。员工四方向10动作，顾客四方向4动作。像素稿与立绘共享发色、服装和妖怪特征；动态使用固定骨架烘焙，不把帧格数量当作独立手绘帧数量。

按用户补充保留侧面walk，身体最多上下1px、抬脚1–2px且脚不交叉。人物跟随实际路径/设备点，椅子按真实座位独立绘制，人物帧没有自带灶台和收银台。开发者可继续替换单帧PNG或整个图集，源图和重建工具随源码保留。

详见[整合说明](docs/art-complete-guide.md)与[实际验证范围](docs/art-complete-validation.md)。Windows及手机实机仍需后续试玩；不能承诺所有布局绝无视觉问题。

## 本版交互修正

白泽当前步骤达成后显示“✓ 已完成，点击继续”，由玩家确认推进；待确认时解除操作锁。引导采用主场景大卡与面板窄卡，固定高亮矩形，正文可完整滚动阅读。普通提示最长2.5秒。

阶段0底栏“装修”进入仅移动已有家具的简单布置；落点预览与确认共用具体拒绝原因，点击原位置取消。员工单框大头照168×184，按框内开窗裁切，点击显示无框完整原图。顶栏可选图片与按钮、设施别名支持热重载。新增风格要求和实际范围见[v1.9.5修订口径](docs/v1.9.5-delta.md)。

[下载完整美术工程与源图](https://github.com/huangzhoule24-sketch/-/raw/208e91d6c488d6132692360b3c7355bef7b511b0/downloads/shanhai-v1.9.5-art-seatfix-source.zip)。43组6912项检查及Chromium80次实际操作/42项检查通过，详见验证记录。

## 开始游玩

[下载当前 Windows 修订版](https://github.com/huangzhoule24-sketch/-/raw/c7af10bdcc974ac7458122feeffa8244c3a4af4f/downloads/shanhai-v1.9.5-clarity-fix-windows.zip) · 已实际下载并校验完整性。

1. 将 Windows ZIP **全部解压**，运行 `shanhai-v1.9.5-culture-literary.exe`，保留同目录的 `.pck`、`CustomAssets/`、`CustomAudio/` 和 `licenses/`。无需安装 Godot。
2. 欢迎页开始经营，依次完成六步引导：白泽说明、打开并关闭员工面板、花20元发传单、观察首单结账、收入说明、打开账单预览。开局不能跳过；无需等待午夜查看第一份账单。
3. 新局现金800元、债务1200元；前三日免租金水电、最低还本50元，利息仍按剩余本金计算。先留好采购和工资。
4. 经营升级需营业额与声望同时达标，并手动确认。研发从阶段1开放。阶段功能逐项教学，资源不足可选择稍后，待办保留。
5. 服务员走到餐桌点单，顾客可选全部已启用且有库存的菜单菜品，不要求销售员。库存不足仍会到店，制作失败会告知、改点或离店，影响口碑。

新局默认2×；顶部可暂停及切换1/2/3/4倍速，1×=每秒3游戏分钟。待办主按钮直达当前目标，旁边展开键查看全部待办。管理界面通常暂停经营；教学按提示观察自动服务。快进仍会实际处理订单、体力与日结，不产生离线收益。

## 主要入口

| 入口 | 功能 |
| --- | --- |
| 阶段0底栏：员工 / 装修 / 宣传 / 招聘；点击员工卡片 | 详情内排班、培训及付费解雇；招募单列；技能从阶段1开放 |
| 更多→经营目标、菜单定价；阶段1–2底栏研发/装修，阶段3起研发/装修移到更多 | 阶段成长、真实配方、装修与售价 |
| 更多→账单与资金流水（含贷款/采购页签） | 当日预览、历史账单、CSV、支出图、补货策略、贷款与救援 |
| 更多→顾客反馈、员工支线（含山海志）、相生相克 | 缺货与评价原因、独立好感、三段剧情、排班关系 |
| 阶段2起更多→会员计划/外卖；阶段3起底栏分店/中央厨房/探索；阶段4更多→大赛/觉醒/榜单 | 阶段2–4长期系统、中央厨房/调拨、觉醒及比赛 |
| 图鉴→员工/菜品→文化简介，特殊顾客并列页签 | 全部30员工与25菜品的核心简介和图片占位 |

白泽最初是引导NPC，不占员工位。整理其余25位真实结识员工的档案并完成支线后，才进入招聘池。文化简介始终可读，不会直接赠送员工、书页或配方。排行榜为动态单机NPC赛季榜。

## 财务与保存

销售实时入账；日结汇总收入，先自动采购，再结算利息、最低还本、工资、房租水电与贷款息。利润、库存、本金与现金流分别记录，避免重复入账。连续无力补足工资/租金或负现金触发首次一次性紧急救援：5000元、日息2%、20天，接受前确认代价；拒绝、救援失败或第二次破产强制结束。重开保留永久收藏与白泽支线。日结默认强制展示明细，确认后继续，可关闭未来自动弹出。常规贷款在现金负数或实际逾期时禁贷，初始未逾期原债不等于禁贷。

完整存档为 `user://campaign_savegame.json`，schema5支持旧版候选迁移；旧资金、员工培养、订单、随机序列与文化进度不重置，不补发新局300元差额。更多→系统与存档可手动存读，每日日结自动保存。安全存档为 `campaign_recovery.json`。

网页版需要解压后运行包内 `python serve.py`，通过HTTP访问。浏览器、站点地址与桌面程序分别保管各自进度。网页保存与图片导入异步写入浏览器数据区，保存后稍候再刷新；清除站点数据或无痕模式可能丢失进度。

## 后续美术接入

新目录为程序同级 `CustomAssets/{Portraits,Sprites,UI,Map,Items,FX}/`，内置素材使用 `assets/art/`。统一获取、导入与回退由 `scripts/services/asset_catalog.gd` 处理。旧 `Backgrounds/Characters/Dishes` 与原UI路径继续兼容，不必搬走已有图片。

- 员工/教学立绘：`Portraits/tao_tie.png`、`Portraits/tutorial_bai_ze.png`。
- 四方向动作：`Sprites/tao_tie/cook_up_0.png`；30员工9动作×4方向全量预留，帧号0–3。
- 箱庭与菜图：`Map/equip_stove.png`、`Map/floor_wood.png`、`Items/dish_noodles.png`。
- 照片框与特效：`UI/frame_portrait.png`、`FX/icon_warning.png`。
- 文化专图仍独立使用`Characters/<员工ID>_lore.png`与`Dishes/<菜品ID>_lore.png`；旧角色ID图片也可回退读取。

完整拼音ID和1447个新目标见[资源清单](docs/山海食肆物语-美术资源清单.md)与[CSV](docs/art-resource-list-v1.9.3.csv)，原82个兼容入口继续保留，另增3个顶栏可选图元。当前已接入本次生成美术，前期独立饕餮样例未混入。

网页通过「更多→系统与存档→开发者选项→美术资源」导入；桌面可直接放图。详细路径、帧序列和覆盖顺序见[美术说明](docs/art-pipeline.md)及[manifest](CustomAssets/manifest.json)。当前已接入人物、场景、菜品与UI美术；本轮未新增配音。

## 开发与构建

用 Godot 4.6.3 打开 `project.godot`。云环境的可写目录设置：

```sh
export XDG_DATA_HOME=/workspace/.tools/godot/data
export XDG_CONFIG_HOME=/workspace/.tools/godot/config
export XDG_CACHE_HOME=/workspace/.tools/godot/cache
godot --headless --path . --editor --import --quit
bash tools/run_checks.sh
godot --headless --path . --script res://tools/v193_campaign_audit.gd
```

顺序导出，再打包：

```sh
bash tools/export_web.sh
bash tools/export_windows.sh
python3 tools/package_release.py
```

生成 `build/山海食肆物语-v1.9.5-{Windows,Web,Source}.zip` 及 `v1.9.5-artifact-manifest.json`、`v1.9.5-SHA256SUMS.txt`。Source保留可编辑脚本、配置、场景、字体许可、资源模板、文档和测试，排除Git历史、导入缓存、旧构建及密钥。源码同样打包交付；历史公开源码下载见项目记忆。

真实浏览器检查使用 Chromium/Playwright：先运行 `python3 tools/serve_web.py --port 8002`，再执行 `SHANHAI_QA_URL=http://127.0.0.1:8002 node tools/verify_v193_browser.cjs build/v193-browser`。只读QA快照帮助定位控件，操作由真实鼠标、键盘及文件选择器完成。

Windows本机、手机实机、正式美术和课程传播效果另行验收。中文文化简介已实施；完整双语与三专业专门教学事件的状态仍按[项目记忆](docs/project-memory.md)记录。

阶段0的“简单布置”只能移动空闲的已有家具；正式购买装修在阶段1开放。布置期间暂停经营，完成后保存，未完成退出会确认，撤销同时恢复资金、布局和账目。气泡背景路径为`CustomAssets/UI/thought_bubble.png`，新导航图标见美术接入说明。


历史音频开发准备（2026-10-25）：新增35个声音槽位、音量保存、循环切换、音效限频及游戏内OGG/MP3/WAV导入与试听。当时尚未加入正式音乐与音效；10月27日音效整合已覆盖此状态。接入方法见[音频说明](docs/audio-pipeline.md)，制作分工见[声音清单](docs/audio-resource-list.csv)。

音频接入准备版下载：[Windows](https://github.com/huangzhoule24-sketch/-/raw/f53fb23add7103a98ad0db04c7310974af96f090/downloads/shanhai-v1.9.5-audio-prep-windows.zip) · [完整源码](https://github.com/huangzhoule24-sketch/-/raw/f53fb23add7103a98ad0db04c7310974af96f090/downloads/shanhai-v1.9.5-audio-prep-source.zip)。
