#!/usr/bin/env python3
"""Package the current bilingual player reading as a small independent download."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'build/shanhai-culture-literary-reading.zip'
def main():
 data=json.loads((ROOT/'config/culture.json').read_text())
 assert [len(data[k])for k in ['employees','dishes','guests']]==[30,25,6]
 book=(ROOT/'docs/culture-entries.md').read_text()
 assert book.count('### ')==61
 files={'山海文化读本-中英对照.txt':book.encode('utf-8-sig'),'阅读说明.txt':('山海食肆物语 · 山海小传\n修订：'+data['revised_on']+'\n30位员工、25道菜品、6位来客，含中文、English与34处古文短引及中英释意。\nTXT内保留简易Markdown标记，普通文本编辑器可直接阅读。\n此为独立读本；游戏中的特殊来客仍需遇见后阅读，游戏全部界面尚未英文化。\n').encode('utf-8-sig')}
 files['SHA256SUMS.txt']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n'for k,v in files.items()).encode()
 with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,content in files.items():z.writestr(name,content)
 with zipfile.ZipFile(OUT)as z:
  assert z.testzip()is None
  for name,content in files.items():assert z.read(name)==content
 print(json.dumps({'file':OUT.name,'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
