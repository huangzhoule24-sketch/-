# 山海食肆文化读本 · Chinese & English

修订：2026-10-29。30位员工、25道菜品、6位来客。中文与英文分别润写，原文节选配中文白话与英文释意。

来客小传在游戏中仍须遇见后阅读；完整游戏界面的语言尚未全部翻译。美术资源与后续替换通道保留。

## 山海伙伴

### 羬羊 · Qián yáng

羬羊从钱来山来，羊身后拖着马尾，如今守着小馆的汤灶。它话少，尝汤时却格外挑剔，连一粒浮盐也逃不过舌尖。

**松下有客**

《西山经》从钱来山起笔：山上多松，山下多石，松影里走出一只羊，身后竟是一条马尾。羬羊的奇处藏得安静，像山路转弯后才看见的风景。认得这条尾巴，也就认得了山海开篇的一位邻居。

**汤开以前**

它不爱旁人掀锅盖，添一瓢水也要问清缘由。可晚归的伙计若错过饭点，灶上总还温着一碗汤。有人说它小气，羬羊便把汤勺一放：“盐放重了，谁替这一锅水可惜？”

**一勺清鲜**

江南清汤、远方家乡的炖锅，都能把赶路的人留住。羬羊常请初来的客人先喝一小口，再找汤里的鲜。这个字在舌尖展开时，松林与炉火便有了同一种温度。

> 其狀如羊而馬尾
> ——《山海经》
> It has the shape of a sheep and the tail of a horse.

它像羊，身后却长着一条马尾。

**Qianyang, the Mountain Sheep**

Qianyang keeps the soup stove, its horse's tail betraying a visitor from Qianlai Mountain. Quiet in company, it is exacting with a tasting spoon.

**Under the pines**

The Western Mountains opens at Qianlai: pines above, stone below, and a sheep-shaped creature with a horse's tail among them. That unexpected tail gives the mountain a memorable inhabitant. It is a small, vivid doorway into the Classic of Mountains and Seas.

**Before the pot boils**

Qianyang dislikes anyone lifting its lids. Yet a bowl always stays warm for the worker who missed supper. Ask why it guards the seasoning so fiercely and the spoon comes down: every pot deserves better than a careless handful of salt.

**A spoonful of xian**

Guests bring memories of clear soups and slow stews from home. Qianyang asks them to sip, then follow xian: the savoury freshness opening beneath the steam. A Chinese word begins to acquire a flavour.

### 鸮 · Xiāo

鸮是夜市里的服务员。白天它总像没睡醒，灯一亮，那双圆眼便能从满堂人影里认出一只即将空掉的茶杯。

**梅树上的夜声**

《诗经》写“墓门有梅，有鸮萃止”，把鸮留在树影与暮色之间。夜鸟的声音曾让古人想到幽暗、孤寂，也让长夜有了可辨认的回声。它带来的，是中国诗歌里一双看惯黑暗的眼睛。

**灯亮才精神**

午后叫它三声，未必听见一声回答；夜里有人轻碰杯沿，它已经转过头来。鸮记桌位靠的是声音，最讨厌灌灌替它大声报号：“我听得见，隔壁街也听得见。”

**同一只鸟的两面**

有位远客说，故乡的猫头鹰常伴着雅典娜，意味着智慧。鸮听完，慢慢眨眼，把最后一盏灯拨亮。梅树、神殿与夜市沿着一声鸟鸣相逢，各自留下自己的夜色。

> 墓门有梅，有鸮萃止。
> ——《诗经》
> By the gateway stands a plum tree, where owls gather.

墓门旁生着梅树，鸮鸟聚在枝头。

**Xiao, the Night Owl**

Xiao works the night shift. Drowsy by daylight, this owl-eyed waiter wakes with the lanterns and hears an empty cup touch its saucer across the room.

**A voice by the plum tree**

The Book of Songs places owls in a plum tree beside a gateway. Chinese verse has heard solitude and darkness in their calls. Xiao arrives with those old associations: eyes at home where other creatures can barely see.

**Awake with the lamps**

Three afternoon summons may go unanswered. At night, one tap on a cup brings Xiao round immediately. It remembers tables by sound and grumbles when Guanguan shouts the numbers loudly enough for the next street.

**An owl abroad**

A traveller describes the owl beside Athena, a companion of wisdom. Xiao blinks and brightens the final lamp. A plum tree, a temple and a night market meet through the same bird, each retaining its own darkness and light.

### 耳鼠 · Ěr shǔ

耳鼠有松快的步子，也有一条能带它飞起来的尾巴。它负责端菜，最得意的本领是在满盘汤汁里保住最后一圈波纹。

**丹熏山的飞法**

丹熏山有树、有韭薤，水向西流；《北山经》还在那里安放了耳鼠。它形似鼠，带着兔首与大耳，偏偏“以其尾飞”。古人的笔让一条尾巴离开地面，也让这位小小异客有了自己的天空。

**借过，借过**

它走快路时信心十足，见到突然挪开的凳子又会猛地停住。托盘比自己的胆子大，耳鼠对此颇有怨言。谁若肯先替它收一下椅脚，下一杯热茶准会被悄悄添满。

**把尾巴念给你听**

远来的孩子指着它问，翅膀藏在哪里。耳鼠索性绕空托盘飞一圈，再落回桌边。一个动作讲完了古书最奇的一句话；名字里的“耳”与“鼠”，也随笑声变得好记。

> 以其尾飛
> ——《山海经》
> It flies by means of its tail.

它借着尾巴飞翔。

**Ershu, the Flying-Tailed Mouse**

Ershu carries dishes with quick feet and a flying tail. Its proudest achievement is delivering soup with the final ring of ripples still inside the bowl.

**A different way to fly**

On Danxun Mountain, the Northern Mountains describes a mouse-like creature with a rabbit's head and large ears. It flies by its tail. Familiar animals assemble into an unfamiliar life, with a patch of sky all its own.

**Coming through**

Ershu trusts its speed until somebody moves a stool. It insists its tray is larger than its courage. Clear a chair leg before it passes and an extra pour of tea may quietly appear at your table.

**A story in motion**

A visiting child asks where the wings are. Ershu circles an empty tray and lands. One movement explains the old text; er, ear, and shu, mouse, become words the child can remember.

### 灌灌 · Guàn guàn

灌灌负责招徕，嗓门比门前的铜铃还亮。它认定好菜值得整条街知道，连“今日售罄”也能喊出开张的气势。

**青丘先闻声**

青丘山除了九尾狐，还有形似鸠的灌灌。《南山经》说它的声音像人在呵呼，名字又像把鸣叫记了下来。山中有客未见其影，先闻其声；到了街头，它依旧是这一套出场办法。

**招牌要响亮**

它写招牌喜欢用大字，报菜名喜欢一口气，遇见梼杌还要争到底哪句更上口。若客人捂住耳朵，它会压低声音认真重说一遍，结果连悄声都透着一股开市的喜气。

**念一声灌灌**

Guàn guàn，两个音节落得短而亮。它教远客念名字，总先用筷子敲两下碗沿，让声调有了落脚处。中文里自呼其名的异鸟，就这样在另一种口音里又叫了一回。

> 其狀如鳩其音若呵
> ——《山海经》
> It resembles a dove, and its voice is like a person calling out.

它形似鸠鸟，叫声像人在呵呼。

**Guanguan, the Calling Bird**

Guanguan attracts guests with a voice brighter than the doorbell. It believes every good dish deserves an announcement loud enough for the whole street.

**Heard before seen**

Qingqiu has another neighbour besides the nine-tailed fox: a dove-like bird whose call resembles a human shout. The Southern Mountains names it Guanguan. Voice and name seem to answer each other across the hillside.

**Loud lettering**

Guanguan favours enormous signs and menu calls delivered in one breath. It argues with Taowu over the catchiest wording. When a guest covers their ears, it earnestly whispers the announcement again, somehow still sounding like opening day.

**Say it twice**

Guàn guàn: two bright, falling syllables. Guanguan taps a bowl twice while teaching travellers its name. An old bird's self-announcing call finds another home, this time inside somebody else's accent.

### 讹兽 · É shòu

讹兽有兔一样的身形、人一样的面孔，还有一张能把凉茶说热的嘴。它替小馆讲故事，掌柜替它记住客人真正点了什么。

**一张颠倒话的嘴**

《神异经》里的讹兽能言，偏爱把东西南北、真假好坏倒着说。旅人若只追着声音走，恐怕要在它的故事里多绕几座山。那张近人的面孔，也因此添上了格外狡黠的神气。

**菜单之外还有一篇**

它介绍酸梅汤，能从一缕梅香讲到月亮落山，偏偏记不住客人说的“少甜”。獬豸来核账时，它总先笑一笑：“这句我可没夸张。”桌上随即多了一张写得端正的小纸条。

**换一种语言的包袱**

有位远客听不懂双关，讹兽便画出一只酸得皱脸的梅子。笑声终于落下，它得意得耳朵都竖了起来。一个好故事有时靠口才，有时靠愿意重新讲一遍的耐心。

> 其状若菟，人面能言。
> ——《神异经》
> It is rabbit-like in form, with a human face, and can speak.

它有兔一样的身形、人一样的面孔，还会说话。

**Eshou, the Charming Storyteller**

Eshou has a rabbit's body, a human face and a tongue that could talk cold tea into boiling. It tells the inn's stories; the proprietor remembers the actual orders.

**A mouthful of reversals**

In the Classic of Divine Marvels, Eshou speaks and turns directions and meanings upside down. A traveller following its words might circle several mountains. Its almost-human face wears the additional mystery of a practised trickster.

**Beyond the menu**

Eshou can describe plum fragrance until moonset and still forget a request for less sugar. When Xiezhi checks the order, it smiles: that part, surely, was no exaggeration. A carefully written note soon joins the table.

**Carrying a joke across**

A visitor misses its pun. Eshou draws a plum with a spectacularly sour face. Laughter arrives at last, and its ears rise proudly. The storyteller has discovered another route between languages.

### 饕餮 · Tāo tiè

饕餮掌勺，也试味，尝过一遍还想再尝。它最怕有人用“已经很好吃”搪塞自己，一双眼睛总追着锅里尚未成形的香气。

**鼎上的目光**

古代青铜礼器常饰醒目的兽面，后来人们惯称饕餮纹。《吕氏春秋》又写鼎上饕餮有首无身，吞食的欲望把它留成一张巨口。宴饮、威仪与食欲，在这张脸上相互凝望。

**再试一口**

它的味碟总比别人的多，评语也来得直：“香到了，鲜还差一点。”若新菜终于合意，它会站在灶前笑得肩膀发抖。伙计们得赶紧盛盘，否则这位主厨又要以试味为名伸筷子。

**从兽面到餐桌**

“老饕”在中文里也能亲切地称呼懂吃的人。一位客人学会这个词，便拿来夸饕餮；它听得高兴，终于把最后一份留给全桌分尝。古鼎上的大口，在人声里添了一点烟火气。

> 周鼎着饕餮有首无身
> ——《吕氏春秋》
> On Zhou vessels appears Taotie, with a head and no body.

周代的鼎上刻着饕餮，只有头，没有身体。

**Taotie, the Great Appetite**

Taotie cooks and tastes, then tastes again. Praise alone never satisfies this chef: its eyes follow the fragrance of a dish still finding its shape.

**A face on bronze**

Powerful animal masks decorate ancient Chinese ritual bronzes and are commonly called taotie designs. The Lüshi Chunqiu describes a devouring creature, all head and no body. Appetite and ceremony look outward through the same immense mouth.

**One more taste**

Taotie keeps a crowd of tasting dishes. Fragrance right, savour still missing, it declares. When an experiment finally succeeds, its shoulders shake with delight. The others plate quickly before another supposedly essential sample disappears.

**An affectionate appetite**

Chinese also calls a devoted food lover a lao tao. A traveller learns the expression and tries it on the chef. Delighted, Taotie leaves the final helping for everyone to share. The bronze face has acquired a supper-table voice.

### 冉遗鱼 · Rǎn yí yú

冉遗鱼是照看汤锅的厨师，鱼身、蛇首，六只脚各有各的忙法。它说话缓慢，端碗却稳得连汤面上的葱花也懒得转身。

**白山与涴水**

英鞮山的鸟兽皆白，涴水从山中流出，冉遗之鱼游在其间。《西山经》给了它蛇首、鱼身与六足，也写下古人借它安眠的愿望。奇异的水中住客，背后藏着长夜得以安歇的盼头。

**水声要听完**

它熬汤时嫌人说话太急，总要等滚水从响亮转为细密，才肯添下一味。别人催菜，它便用三只脚端碗、三只脚护炉，慢条斯理地答：“急的已经替你盛好了。”

**把故乡说慢一点**

有人把家乡清汤的名字写给它，有人只能比画一条鱼。冉遗鱼都接过来，慢慢念，仿佛名字也是一味需要温着的食材。碗沿腾起的水汽，让不同口音暂时变得一样轻。

> 魚身蛇首六足
> ——《山海经》
> A fish’s body, a serpent’s head, and six feet.

它长着鱼身、蛇首和六只脚。

**Ranyiyu, the Six-Legged Fish**

Ranyiyu tends the soup pots: fish-bodied, serpent-headed and furnished with six busy feet. It speaks slowly and carries bowls so steadily that the garnish barely turns.

**White mountain, flowing water**

The Western Mountains places this strange fish in the Wanshui, below a mountain of white birds and beasts. Alongside its remarkable anatomy, the old account preserves a hope of peaceful sleep. A creature of water carries a very human wish through the night.

**Listen to the simmer**

Ranyiyu waits for loud boiling to settle before adding another ingredient. Urgent orders receive a leisurely reply: those bowls are already ready. Three feet carry them while the other three mind the stove.

**Names kept warm**

Guests write the names of soups from home or sketch a fish. Ranyiyu sounds them out as carefully as it seasons broth. Different accents become lighter together above the steaming bowls.

### 当康 · Dāng kāng

当康是报丰收的山海来客，在店里做服务员。它喜欢看米缸满起来，添饭时总多抖半勺，问就是：“这一勺自己滑下去的。”

**獠牙间的好消息**

《东山经》的当康形似有牙的猪，叫声像呼唤自己的名字，现身便预示天下“大穰”。两颗獠牙托着的，竟是谷物满仓的喜讯。年成的好坏，曾牵动无数人家灶上的炊烟。

**米缸旁的心事**

它热衷盘点新米，却不爱算有几人添了饭。掌柜一问，它就把大耳朵往米袋上一搭。等厨房忙完，当康一定再问一句谁还没吃；这时候，藏起来的那半勺才有了去处。

**丰年的声音**

秋收家宴、收获节的长桌，各有自己的祝词。远客问它怎样念“大穰”，当康先指米，再指满堂碗筷。人们还没把那个古字学会，已经听懂了这份热热闹闹的好年景。

> 見則天下大穰
> ——《山海经》
> When it appears, the world enjoys a plentiful harvest.

它出现时，预示天下将有丰收。

**Dangkang, Herald of the Harvest**

Dangkang announces a good harvest and serves the inn's tables. It loves a full rice bin and an overly generous scoop: that extra half, it insists, slipped in by itself.

**Good news between tusks**

The Eastern Mountains describes a tusked, pig-like creature calling its own name. Its arrival foretells da rang, an abundant harvest. Behind those two tusks lies the promise of grain for the households whose cooking fires depend on the season.

**Beside the rice bin**

Dangkang counts new sacks eagerly and second helpings reluctantly. Asked about portions, it drapes an ear over the ledger. Once service ends, however, it checks every worker has eaten. The missing half-scoops have found their destination.

**The sound of plenty**

Guests describe harvest feasts and autumn tables. Asked to explain da rang, Dangkang points first at rice, then at the filled bowls. The unfamiliar old word already has a welcoming sound.

### 天狗 · Tiān gǒu

天狗照看门前招牌，也守收银台。白头在灯下一晃，谁多付了一枚钱、谁落下一把伞，它都记得清清楚楚。

**阴山的白首**

《西山经》说阴山有兽，形似狸，头部白色，名为天狗，能御凶。后来的民间故事又让天狗追上月亮，把月食讲成一场吞食。山中的白首与天上的巨口，替同一个名字照出了两幅影子。

**门要留一线**

它数钱时不许插话，听到门响却总先抬头。最后一位客人离开，它还要望一眼街口，才把招牌翻过来。有时掌柜催它收工，天狗便指着雨棚：“伞的主人还没回来。”

**同名的远客**

有人从日本天狗的长鼻与鸟翼说起，天狗便侧过白头，让对方看看自己的模样。两种形象沿着同一组汉字碰面，像旅人交换各自画过的月亮，越看越有话可说。

> 有獸焉其狀如狸而白首
> ——《山海经》
> There is a creature shaped like a wildcat, with a white head.

有一种兽，形似狸，头部是白色的。

**Tiangou, the White-Headed Guardian**

Tiangou watches the sign and the till. Beneath its white head, a sharp memory keeps track of an extra coin, a missing umbrella and every opening of the door.

**Two shadows of a name**

The Western Mountains describes a white-headed, wildcat-like Tiangou warding off danger. Later Chinese tales send a heavenly dog after the moon. A mountain creature and an eclipse cast strikingly different shadows under one name.

**A door left ajar**

Tiangou dislikes interruptions while counting, yet looks up at every footstep. Long after closing, it waits beneath the awning for an umbrella's owner. The cash is settled; apparently the evening is not.

**A namesake arrives**

A guest describes Japanese tengu, their long noses and wings. Tiangou turns its white head for inspection. Shared written characters carry the conversation between distinct images, like travellers comparing the moons they have drawn.

### 蛊雕 · Gǔ diāo

蛊雕似雕而有角，开口却像婴儿啼哭。它在小馆做服务员，不善寒暄，摆碗时一只只排得笔直，连筷尖都朝着同一边。

**鹿吴山的回声**

《南山经》把蛊雕留在多金石的鹿吴山，记它有角、善发婴儿般的声音，又写它食人。那一声啼哭在古书里带着险意，像山林深处忽然亮起一盏令人犹疑的灯。

**今日先点头**

它初来时一声招呼惊动满堂，从此学会先点头，再递菜单。可谁若把餐盘胡乱堆在桌沿，它的角便绷得更直。忙完回头一看，险些摔落的碗早已安稳落在它手里。

**把陌生留给名字**

一位远客在纸上画出家乡传说里的怪鸟，蛊雕低头研究许久，补上自己的一对角。两幅画并排压在茶杯下面。它还没想好怎样开口，对方已经认出了这份郑重的回应。

> 其狀如雕而有角
> ——《山海经》
> It resembles a great bird of prey, but has horns.

它像雕一样，却生着角。

**Gudiao, the Antlered Bird**

Gujiao has a bird of prey's form, horns and an infant-like cry. This reserved waiter lines bowls up precisely, with every chopstick tip pointing the same way.

**An unsettling mountain call**

The Southern Mountains places Gujiao on Luwu Mountain and describes its horns, strange voice and appetite for humans. An infant's cry carries danger through the old landscape, drawing a traveller's ear toward something unfamiliar.

**A nod before speaking**

One greeting once startled the whole dining room. Gujiao now offers a nod and a menu first. Its horns stiffen at a carelessly stacked plate; a moment later, the endangered bowl rests safely in its hands.

**A drawing answers**

A visitor sketches a legendary bird from home. Gujiao studies it and adds its own horns on another sheet. Two pictures lie beneath their teacups. Before the waiter finds the right words, its careful reply has already been understood.

### 旋龟 · Xuán Guī

旋龟有龟身、鸟首与蛇尾，是小馆里最稳当的厨师。它动作慢，记性却细，别人的锅少了一瓢水，它往往先于主人发现。

**怪水的木声**

《南山经》写杻阳山的怪水里有旋龟，形似龟而鸟首虺尾，声音如判木。厚重龟壳里藏着清脆的回响，古人也把避疾求安的愿望寄在它身上。熟悉的轮廓，由此长出了几处奇峰。

**慢半拍的准头**

开火以前，它先把调料排好；关火以后，还要把台面擦净。穷奇常嫌它慢，回头却又来借它记下的火候。旋龟从不追问，只用蛇尾点一点案边早已摆好的小纸片。

**时间盛在壳里**

许多地方的龟故事都带着时间的分量，旋龟却还多着鸟首与木响般的声音。来客听它说话，常先愣一愣，再笑着放慢语速。一顿饭的工夫，竟也能学会另一种从容。

> 其狀如龜而鳥首虺尾
> ——《山海经》
> Turtle-shaped, with a bird’s head and a serpent’s tail.

它像龟一样，却长着鸟首与蛇尾。

**Xuangui, the Steady River Turtle**

Xuangui is turtle-bodied, bird-headed and serpent-tailed. Slow at the stove but exact in memory, it often notices another cook's pot needs water before they do.

**A wooden sound from the water**

The Southern Mountains gives Xuangui a call like splitting wood. Its familiar shell contains unexpected anatomy and a clear, startling voice. The old account also carries a wish for relief from illness, resting within this unusual water creature.

**Half a beat slower**

Before cooking, Xuangui arranges the seasonings. Afterwards, it cleans. Qiongqi complains about the pace and later borrows its timing notes. A serpent's tail quietly points toward the slip already waiting on the counter.

**Time in a shell**

Turtle stories in many places carry the weight of time. This one adds a bird's head and a wooden resonance. Guests pause at its voice, smile and slow their own speech, finding another tempo within a meal.

### 青蚨 · Qīng Fú

青蚨是灵巧的服务员，名字也曾被借来称钱。它眼尖，拾起一枚散落的零钱很快，记起那枚钱应当还给谁，却比什么都认真。

**母虫的归路**

《搜神记》讲青蚨形似蝉，母虫总会飞向被带走的幼子。相寻的力量又进入铜钱的故事，于是有了青蚨还钱的想象。后来诗文以青蚨代钱，冷硬金属的名字里便藏进了一段牵挂。

**哪一枚是你的**

它把失物分开放好，偏偏有人觉得零钱混在一起无妨。青蚨听完，立即翻出包得整齐的小纸包：这是饭钱，那是寄存，还有一枚是孩子攒来买饮料的，谁也替代不了谁。

**钱也会借一个名字**

贝壳、金属、颜色，都曾在不同语言里成为钱的别称。中文把一只小虫也收进其中。远客听完那条母子的归路，再把零钱放回口袋，指尖仿佛也多了一点温热的声响。

> 取其子，母即飞来，不以远近。
> ——《搜神记》
> Take away its young, and the mother flies to them, no matter the distance.

取走它的幼子，母虫便飞来寻找，不论距离多远。

**Qingfu, the Returning Coin**

Qingfu is a nimble waiter whose name also became a Chinese word for money. It spots a fallen coin quickly and takes even greater care remembering its owner.

**A mother's return**

In the Records of the Supernatural, a cicada-like qingfu mother flies to her separated young. Stories lend that returning power to coins. When poetry later borrows the insect's name for money, affection travels inside a word for metal.

**Which coin is yours?**

Qingfu keeps lost items separately. Suggest mixing the coins and neat paper packets appear: supper money, a deposit, a child's savings for a drink. Each sum has its own story and destination.

**Money borrowing names**

Shells, metals and colours have named money in different languages. Chinese adds this small insect. After hearing its story, a visitor pockets their change with a new association: a familiar sound now carries the idea of finding a way home.

### 九尾狐 · Jiǔ wěi hú

九尾狐从青丘来，九条尾巴各有各的心情。它是善于察言观色的服务员，笑起来让人放松，记性却好得叫熟客不敢随口许诺。

**九道尾影**

《南山经》的青丘之狐九尾、声如婴儿，带着危险而迷人的气息。后来，九尾白狐也走进祥瑞与婚姻的叙事。一片尾影能遮住山林，也能铺成好兆头，古人始终舍不得只给它一种面貌。

**它记得上次**

谁爱窗边，谁的茶要淡，谁说下回请全桌喝一杯，九尾狐都记得。它提醒人时从不提高嗓门，只把最后一条尾巴慢慢卷起来。客人便笑着投降，唤它把茶添满。

**尾巴越过海**

日本的狐、韩国的九尾狐与中国青丘故事，在东亚的书页和屏幕间留下许多回声。远客各讲一种，九尾狐便一条条数自己的尾巴，仿佛九条刚好够装下今晚还没说完的传闻。

> 其狀如狐而九尾
> ——《山海经》
> It has the form of a fox, with nine tails.

它形似狐狸，身后有九条尾巴。

**Jiuweihu, the Nine-Tailed Fox**

Jiuweihu comes from Qingqiu, with nine tails and nine shifting moods. This perceptive waiter puts guests at ease and remembers every promise a regular makes.

**Nine shadows**

The Southern Mountains gives Qingqiu's fox nine tails, an infant-like voice and a dangerous allure. Other old narratives make the white nine-tailed fox auspicious. Its many tails carry several histories at once, from unsettling hillside encounters to wedding blessings.

**Remember last time?**

Jiuweihu remembers the window seat, the weaker tea and the guest who offered to buy everyone's next round. It makes its reminder quietly, curling the final tail. The guest laughs, surrenders and orders more tea.

**Tails across the sea**

Japanese fox tales, Korean nine-tailed foxes and Chinese Qingqiu stories echo across East Asian books and screens. Visitors offer their versions. Jiuweihu counts its tails as though allocating room for all the stories still to come.

### 毕方 · Bì fāng

毕方一足、青羽、赤纹、白喙，是灶边最醒目的厨师。它擅长烤制，脾气也像炭火：外面收着，里面一直亮。

**火色落在羽上**

《西山经》写毕方形似鹤而独足，现身与火灾的征兆相连。青与赤、静羽与烈焰，被古人并在一只鸟的身上。它站着不动时，仍像有一线火光从羽纹里缓缓经过。

**翻面只有一次机会**

它烤东西不爱旁人指点，夹子落下之前，眼睛已经把火色看过几遍。饕餮若偷尝还没出炉的一块，必会挨一下白喙的冷眼。等炭火退到最合适的温度，它才肯说：“现在。”

**认火，也认风**

有客人谈起故乡会重生的火鸟，毕方只拨开炉灰，露出下面尚红的炭。每一团火都有自己的故事；它的这一团，教人记住风向、距离，以及焦香刚刚出现的那一瞬。

> 其狀如鶴一足赤文青質而白喙
> ——《山海经》
> Crane-like and one-legged, with red markings, blue plumage and a white beak.

它像鹤，只有一足，青色身上带着红纹，喙是白色的。

**Bifang, the One-Legged Firebird**

Bifang is unmistakable beside the grill: one leg, blue-green feathers, red markings and a white beak. Its temper resembles charcoal, quiet outside and bright within.

**Fire on a feather**

The Western Mountains associates this crane-like, one-legged bird with the warning of fire. Blue and red, stillness and flame share one body. Even at rest, Bifang seems to carry an ember slowly travelling beneath its plumage.

**The moment to turn**

It dislikes advice at the grill. Taotie earns a cold look for sampling anything unfinished. Bifang studies the coals, waits, then says now. The tongs move once; the crisp edge arrives exactly where it wanted.

**Reading wind and heat**

A guest describes a reborn firebird from home. Bifang brushes aside ash to reveal living red coals. Each fire has a story. This one teaches the distance of a hand, the direction of a draught and the instant fragrance begins.

### 貔貅 · Pí xiū

貔貅守着钱柜，算盘声能压住门外的雨。它喜欢进账，更喜欢账目合拢时那一下清脆的响，谁想糊弄一枚铜钱都不容易。

**猛兽走入钱袋**

《史记》的貔貅与熊罴等猛兽并列，带着早期传说的威势。后来，吉祥兽的形象进入摆件和佩饰，人们又把守护与聚财的愿望交给它。古老的利爪，渐渐握住了日常生活里的盼头。

**先把这笔说清**

它会为少收一文追到门口，也会把多付的钱原样送回。哪笔是饭钱，哪笔是预支，伙计们觉得差不多，它偏要分明。临近打烊，貔貅把算盘一推，终于肯为自己倒一杯凉茶。

**掌心的一只瑞兽**

客人拿出家乡的幸运小物，貔貅便把钱柜上的兽形转给对方看。金属、珠玉、磨旧的绳结，各自贴着一只掌心。那些想把明天过好的愿望，摸起来竟有相近的温度。

> 教熊罴貔貅貙虎
> ——《史记》
> He trained bears, pixiu and other fierce beasts.

训练熊、罴、貔貅、貙、虎这些猛兽。

**Pixiu, the Auspicious Guardian**

Pixiu keeps the till, its abacus audible above the rain. Income pleases it; a balanced account pleases it more. A single coin is difficult to explain away.

**From fierce beast to lucky charm**

The Records of the Grand Historian lists pixiu among formidable beasts. Later auspicious images entered ornaments and pendants, carrying wishes for protection and prosperity. The fierce creature acquired a place beside everyday hopes for a secure livelihood.

**Settle this entry first**

Pixiu follows a missing coin to the door and returns an overpayment just as promptly. Supper money and an advance require separate entries. Only when the accounts meet does it push the abacus aside and pour its own tea.

**A creature in the palm**

A guest produces a lucky object from home. Pixiu turns its little ornament toward them. Metal, jade and worn cord rest in their hands: different shapes, each warmed by somebody's hope for tomorrow.

### 英招 · Yīngsháo

英招有人面、马身、虎纹与鸟翼，是从园圃走向四海的神。它在小馆接待旅人，衣角仿佛还沾着各地草木的气味。

**槐江山的园丁**

《西山经》说英招照管天帝园圃，又巡行四海。虎纹与羽翼让它威仪不凡，园圃却把这份力量系在草木、雨水与时节上。它能飞向极远的地方，也记得一片新叶何时该舒展开来。

**桌边有风土**

它爱问客人的故乡有什么树，听到陌生菜名便找纸记下。忙时陆吾嫌它聊得太久，英招就把笔往耳后一别，先端菜，过会儿再从那棵没说完的树接着问。

**叶子夹在菜单里**

菜单里常夹着旅人送的小叶片，旁边写着几种语言的名字。有的香气与故乡相似，有的第一次闻见。英招把它们收在一起，翻页时，一张餐桌也能吹来许多个地方的风。

> 神英招司之
> ——《山海经》
> The god Yingzhao watches over it.

神英招照管着这里。

**Yingzhao, Keeper of the Celestial Garden**

Yingzhao has a human face, a horse's body, tiger markings and wings. A travelling garden-keeper now welcomes the inn's guests, bringing the scent of distant leaves.

**The garden on Huaijiang**

The Western Mountains makes Yingzhao guardian of the celestial gardens and a traveller across the seas. Its striking body belongs equally to flight and careful tending: a creature that can reach distant horizons and remember when a new leaf should open.

**A tree beside the table**

It asks visitors about trees at home and writes down unfamiliar dishes. Luwu complains the conversation takes too long. Yingzhao tucks its pencil behind an ear, delivers supper and returns to the unfinished tree.

**Leaves in the menu**

Small leaves offered by travellers rest between menu pages, labelled in several languages. Some fragrances recall home; others are entirely new. Turn a page and several different winds seem to cross the same table.

### 陆吾 · Lùwú

陆吾有人面、虎身与九尾，曾守昆仑帝苑，如今掌小馆的烤炉。它做事讲次序，连九条尾巴转身时都像各有差遣。

**昆仑有管事**

《西山经》称昆仑是天帝下都，陆吾掌管其间，又司天之九部与帝苑时节。神山的宏大落在一个“管”字里：风物有时，园囿有序，总得有谁把纷繁的事情一件件接住。

**先出这一盘**

午市里锅勺齐响，它只抬一下虎爪，就把先后排妥。毕方不服它插手火候，陆吾也不退让：“你管那一块熟得好，我管这一桌吃得齐。”两人争完，热盘倒总能同时出门。

**山顶的另一种高度**

远客说起故乡神山上的宫殿，陆吾先问那里由谁照看。话题从云上的神明落到开门、扫阶、候时的人。昆仑因此有了可走近的一面：高处，也有人认真过着每一日。

> 是神也司天之九部及帝之囿時
> ——《山海经》
> This god oversees the nine divisions of heaven and the seasons of the imperial gardens.

这位神掌管天上九部与天帝园苑的时节。

**Luwu, Steward of Kunlun**

Luwu once guarded Kunlun's divine gardens. Human-faced, tiger-bodied and nine-tailed, it now manages the grill with an impressive sense of order.

**Someone must keep Kunlun**

The Western Mountains calls Kunlun the celestial ruler's earthly capital. Luwu oversees its domains and the garden's seasons. A vast sacred landscape becomes imaginable through tending: somebody attends to each season, gate and changing task.

**This platter first**

During the lunch rush, one raised paw establishes the serving order. Bifang resents interference. You perfect that piece, Luwu replies; I make sure the table eats together. Their argument generally ends with several hot plates leaving at once.

**Another view of a sacred mountain**

A traveller describes palaces on a holy mountain at home. Luwu asks who looks after them. Talk descends from cloud-dwelling gods to doors, steps and seasons. Kunlun gains the intimacy of a place where somebody works each day.

### 精卫 · Jīngwèi

精卫是白喙赤足的小鸟，也是小馆里不肯留下一张脏桌的服务员。它动作轻快，收拾完一处，又会回头检查最后一道水痕。

**海留下的名字**

《北山经》说炎帝之女女娃游东海而溺，化作精卫，常衔西山木石去填东海。白喙、赤足、花纹的头，把一场失落留成了可以看见的身影；海浪来回，鸟仍一次次折返。

**还有最后一下**

它做事常说“就一下”，说完又多做一下。耳鼠替它把抹布藏起来，它便站在窗沿生气，直到一杯热水送到面前。喝水时精卫仍望着桌角，伙伴们只好先把那里擦净。

**木石的分量**

这则中国故事常被读成坚持，也容得下悲伤与不甘。远行的人在不同年纪听见它，会认出不同的海。小馆收工后的窗边留着一处空位，给终于肯停一停的那只鸟。

> 常銜西山之木石以堙于東海
> ——《山海经》
> It continually carries wood and stone from the western mountains to fill the eastern sea.

它常衔来西山的木石，要把东海填平。

**Jingwei, the Sea-Filling Bird**

Jingwei is a quick waiter with a white beak, red feet and a fierce objection to unfinished cleaning. Even an empty table receives one final inspection.

**The name the sea kept**

The Northern Mountains tells of Nüwa, daughter of the Flame Emperor, drowning in the Eastern Sea and becoming Jingwei. The bird carries wood and stone from the western mountains to fill the waters. Its repeated journeys give grief a visible shape.

**Just one more wipe**

Jingwei always promises one last task. Ershu hides the cloth; an indignant bird retreats to the window until somebody brings hot water. Its eyes remain on a damp corner, which the others quietly dry.

**The weight of a pebble**

Chinese readers have found perseverance in this tale, and sorrow too. At different ages, the same sea can mean something different. After closing, a place remains by the window for the bird that finally agrees to rest.

### 穷奇 · Qióngqí

穷奇掌麻辣锅，生着让人难忘的凶相，做菜也爱用重味。它下料果断，说话更直，客人若只夸“还行”，它能追问到门口。

**两条山路上的凶兽**

古书给穷奇留下不止一种模样：一处像牛而披刺毛，一处似虎而生翼；四凶的叙事又添上它助恶的名声。几条传说各有峻厉之处，合起来，才有这位令人不敢轻慢的山海来客。

**这口锅有脾气**

它认定一锅好汤要让人立刻记住，花椒入油时眼神都亮起来。遇见吃不了辣的客人，它先皱眉，再认真另调一碗。端上去还要问：“这回呢？香总该闻得出来吧？”

**尝过再回答**

它听得懂许多种夸奖，却最服有来有回的意见：麻停在哪里，辣从哪一口开始，汤里还缺什么。客人比画着说，它便比画着尝。火气很大的厨师，竟能为一句具体的评语等得很久。

**Qiongqi, the Untamed One**

Qiongqi runs the mala pot with a fearsome face and decisive seasoning. Its speech is equally direct. Call a dish merely fine and it may follow you to the door.

**Several fierce histories**

Old accounts describe an ox-like creature with stiff hair and a winged tiger-like form; the Four Perils tradition adds a troubling reputation. These different paths give Qiongqi a presence that demands attention before a single bowl is served.

**A pot with a temper**

Peppercorns entering hot oil light up its eyes. A guest who cannot take chilli receives a frown, followed by a carefully adjusted bowl. Qiongqi still needs an answer: surely the fragrance comes through this time?

**Taste, then reply**

It respects precise criticism: where the tingling settles, when the heat begins, what the broth still lacks. Guest and cook describe sensations with words and gestures. For one useful observation, this impatient chef can wait surprisingly long.

### 梼杌 · Táowù

梼杌负责宣传，招牌上的一个字也能与人争半日。它认定的事很难松口，偏又记得每一位曾认真听它说完的人。

**名字里的棱角**

《左传》借梼杌写顽固难教的性情，后来的异兽叙事添上虎形、长尾等模样。那一身棱角仿佛从名字里长出来，远远站着，也像有一场尚未结束的争论跟在身后。

**招牌重写三回**

灌灌嫌字不响亮，讹兽嫌话不够巧，梼杌却坚持写“肉烤到透，饭盛得足”。争到最后，它索性搬凳子坐在门口，逐位问客人看懂了没有。那张招牌因此留下了许多次擦改的痕迹。

**把一句话说准**

遇见不同语言的客人，它会把原句写得更慢，等对方找来自己的说法。每改一处，都像拔下一根刺；可当两人终于指着同一盘菜点头，它又要郑重把那个新词抄进本子里。

**Taowu, the Stubborn One**

Taowu handles publicity and can argue over a single signboard word all afternoon. It rarely yields, yet remembers everyone who has listened to its whole explanation.

**Edges in a name**

The Zuo Tradition associates Taowu with stubborn, unteachable character. Later creature tales add a tiger-like form and long tail. Its sharp outline seems to have grown from the name itself, with an unfinished argument following behind.

**The sign rewritten**

Guanguan wants louder words; Eshou wants cleverer ones. Taowu insists on meat cooked through and bowls filled properly. Eventually it sits outside and asks each guest what they understand. The board gathers a history of erasures.

**Getting a phrase right**

For a guest speaking another language, it writes slowly and waits for an answering phrase. Every alteration costs effort. When both finally point to the same dish, Taowu carefully copies the new word into its notebook.

### 混沌 · Hùndùn

混沌是爱试新味的厨师，案台常被它弄得一团热闹。它能对着一味陌生香料出神，也能把昨日失败的配方藏得谁都找不到。

**七日的寓言**

《庄子》写中央之帝浑沌待人甚厚，朋友想报答它，便替没有七窍的它每日凿一窍，七日后浑沌死了。寓言把一份热心放在令人心惊的结尾，让读者久久望着那个原本自在的生命。

**先留一处空**

试新菜时，它总空出一只碗，等最后想到的那点滋味。有时空碗等到打烊，谁问起，混沌便把头转向窗外；也有一夜忽然拍案，让全店都来尝一口尚未取名的汤。

**让陌生有自己的样子**

客人送来的香料，它先闻很久，再问原来怎样用。有人说留整粒，有人说先磨碎，案上便出现两只小碟。等香气各自升起，那份新奇也终于有了能被仔细聆听的声音。

> 日鑿一竅，七日而渾沌死。
> ——《庄子》
> They opened one aperture each day; on the seventh day Hundun died.

每天凿开一个孔窍，七天以后，浑沌死去了。

**Hundun, Before the World Took Shape**

Hundun experiments in a gloriously untidy kitchen. An unfamiliar spice can hold its attention for hours; yesterday's failed recipe vanishes just as mysteriously.

**Seven days**

Zhuangzi tells of Hundun, a generous host without the human body's seven openings. Grateful friends make one opening each day. On the seventh, Hundun dies. The abrupt ending leaves readers with a haunting image of a life once complete in its own form.

**An empty bowl**

Hundun always leaves one bowl empty for the flavour it has yet to discover. Sometimes it waits until closing. Sometimes a sudden shout summons everyone to taste a soup that still has no name.

**Listening to an ingredient**

A guest offers a spice. Hundun smells it, then asks how it is used at home. Whole, says one; ground, says another. Two dishes appear on the counter. Distinct fragrances rise, each given time to introduce itself.

### 獬豸 · Xièzhì

獬豸独角，善辨曲直，在小馆照看收银与客诉。它问话不急，等人把气发完，才把账单摊开：“从第一道菜说起。”

**把判断托给一只兽**

古人想象獬豸能辨争讼是非，独角抵向理曲的一方；獬豸冠也因此走入司法服饰。难以看见的公正，有了一种可以刻在冠上、立在门前的形貌，让人抬头便认得那份寄望。

**茶凉之前**

客人与伙计各说一套，它便把点单、送菜、结账的经过逐项问清。讹兽想插一句漂亮话，常被那根角轻轻一挡。等桌上只剩事实，獬豸才把茶续热，让双方自己把话接下去。

**角与天平**

远客在纸上画了一架天平，獬豸在旁边添上独角。两种形象，一种衡量，一种辨曲，陪人追问同一件难事：如何让受委屈的话有处落下，让作出的判断有人愿意相信。

> 獬豸知曲直獄訟平則至
> ——《宋书》
> Xiezhi knows right from wrong, and appears when judgements are fair.

獬豸懂得曲直，诉讼得到公正审理时，它便出现。

**Xiezhi, the One-Horned Judge**

Xiezhi is a one-horned judge of disputes and the inn's patient keeper of complaints. Once tempers settle, it unfolds the bill: begin with the first dish.

**A visible hope of justice**

Old accounts give Xiezhi the power to identify the party in the wrong. Its image entered judicial headwear. An elusive hope, fair judgment, acquired a horn and a recognisable shape that could stand above an official's brow.

**Before the tea cools**

Order, delivery, payment: Xiezhi asks about each in turn. An elegant interruption from Eshou meets a gently lowered horn. When the sequence is clear, fresh tea arrives and both sides can resume speaking.

**A horn beside a balance**

A visitor draws scales; Xiezhi adds its horn. Weighing and discerning take different visible forms. Together they open an old question across languages: where can a grievance be heard, and how does a judgment earn trust?

### 青耕 · Qīng Gēng

青耕青身白尾，像一只清爽的鹊，做服务时总把桌边的小事看在眼里。它嗓音轻，却敢在满堂喧闹里替久候的客人问一句。

**把平安唤出来**

《中山经》说堇理山有青耕，白喙、白目、白尾，鸣声如自呼其名，又能御疫。小小山鸟托住了很大的盼望；青白相间的羽色，也像山中忽然吹来一阵清风。

**还差几口锅**

它最不爱听人敷衍地说“马上就好”，一定要到后厨问清楚。若厨师不耐烦，青耕就站在传菜口等，白尾一动不动。等到准信，才回来给客人续茶，把话说得简短而确切。

**一声名字，一声问候**

它教远客念Qīnggēng时，先指青色的羽，再轻轻唱出鸣声。有人跟着唱歪了调，青耕便重新唱一回。平安的古老愿望，在这两声不太齐的问候里变得轻巧可闻。

> 青身白喙白目白尾名曰青耕
> ——《山海经》
> Blue-green in body, with white beak, eyes and tail: it is called Qinggeng.

它青身、白喙、白目、白尾，名叫青耕。

**Qinggeng, the Bird of Reassurance**

Qinggeng is blue-green with white markings, a magpie-like waiter attentive to overlooked tables. Its soft voice can still ask a firm question for somebody waiting.

**Calling for well-being**

The Central Mountains describes a bird with white beak, eyes and tail, calling its own name and warding off pestilence. A small mountain creature carries a large hope. Its clear colours resemble a breeze crossing the trees.

**How many pots ahead?**

Qinggeng dislikes a vague almost ready and goes to the kitchen for an answer. Impatient chefs find a motionless white tail at the hatch until they explain. The waiter returns with tea and a short, accurate reply.

**A name as a greeting**

Teaching Qīnggēng begins with a green feather and a sung call. A visitor follows in an uncertain tune; Qinggeng sings again. The old wish for well-being becomes audible in two imperfectly matching greetings.

### 天禄 · Tiān Lù

天禄是招徕与收银的伙伴，瑞兽般的身影总爱站在门前亮处。它喜欢好兆头，遇上第一位客人，更要把招牌擦得格外干净。

**珠玉间的一只兽**

天禄作为瑞兽走进古人的装饰，《后汉书》所记步摇六兽里，也有写作“天鹿”的名字。兽形与珠玉一起随步轻动，把福禄之愿佩在身上；一段古老祝福，也便有了可以看见的轮廓。

**今日会有好消息**

它把第一声夸奖转告厨房，顺手把歪掉的菜单摆正。可若下雨误了生意，天禄也会闷闷不乐。貔貅把账算完递给它，它才发现：原来今日照样有几件值得记住的好事。

**带在身边的愿望**

有人把门上的纹样画给它看，有人摘下腕间旧挂饰。天禄逐件欣赏，见到兽形更要细问名字。各地的祝福在灯下轻轻碰响，像步摇上那几枚随着人一起走远的珠玉。

**Tianlu, the Auspicious Companion**

Tianlu welcomes guests and works the till, an auspicious creature happiest in the bright doorway. For the first arrival, it gives the sign an especially careful polish.

**A creature among jewels**

The Book of the Later Han records a creature written Tianlu among figures on a moving headdress. Auspicious animal forms travelled through ornament, carrying wishes for fortune with every step. An old blessing acquired a shape that could be worn.

**Good news today**

Tianlu carries the first compliment to the kitchen and straightens the menu. Rain-soaked, quiet days dampen its spirits. Pixiu's finished accounts help: several small achievements have survived the weather and deserve remembering.

**Wishes worn abroad**

A guest sketches a pattern from a doorway; another removes an old pendant. Tianlu admires each and asks the creatures' names. Different blessings softly meet under the lamp, like jewels travelling with their wearer.

### 凤凰 · Fènghuáng

凤凰五彩而善歌舞，来到小馆后，灶边、桌旁都能见到它。它爱惜羽毛，也爱惜体面，最忙时仍要把衣襟上一点汤渍擦净。

**丹穴山的纹章**

《南山经》写丹穴山的凤凰，羽纹与德、义、礼、仁、信相联，自歌自舞，见则天下安宁。五彩在古人的笔下有了品格，百鸟之美也系着一份世间太平的愿望。

**把灯一盏盏点好**

它嫌伙伴们把欢迎词念得敷衍，常拉住灌灌重教一回。可午市忙乱起来，凤凰也会卷起衣袖替人收盘。末班收工，它把最后一盏灯拨正，才肯坐下理顺折起的羽翼。

**两种鸟，两个名字**

远客说起phoenix，带来灰烬里再生的火光；Fenghuang的歌里，则回荡着中国古老的安宁之愿。两种名字写在同一页，火与五彩相照，为一碗热羹添上各自不同的余韵。

> 自歌自舞見則天下安寧
> ——《山海经》
> It sings and dances of itself; when it appears, the world is at peace.

它自歌自舞，出现时天下安宁。

**Fenghuang, the Auspicious Bird**

Fenghuang brings five-coloured plumage and a fondness for ceremony to every job in the inn. Even during a rush, it notices a splash on its collar.

**Markings on Danxue Mountain**

The Southern Mountains connects Fenghuang's patterned body with virtues and its song and dance with peace. Beauty acquires a moral and social dimension: the magnificent bird carries a wish for the world to flourish in harmony.

**Straighten the final lamp**

Fenghuang makes Guanguan rehearse a careless welcome, then rolls up its own sleeves to clear the lunch dishes. At closing, it straightens the last lamp before sitting down to arrange its folded wings.

**Two names on a page**

A traveller's phoenix brings the fire of rebirth from ashes. Fenghuang's song carries an old Chinese promise of peace. Written together, the two names let flame and coloured feathers illuminate distinct hopes beside the same warm bowl.

### 白泽 · Báizé

白泽是小馆的导师，能说万物旧事，也肯陪新伙计重做一盘炒饭。它随身的本子页角卷起，空白处常留着后来补上的问题。

**给未知一个名字**

黄帝遇见能言白泽、向它问知万物的故事，使这位神兽与博识相连；《白泽图》的线索又把知识留在图像与名字之间。那些曾令旅人不安的异影，一旦可以辨认，也就有了相处的开端。

**把锅铲交回去**

新伙计炒坏了饭，白泽先让它尝，再问是米太湿还是火太急。讲完以后，锅铲仍交回对方手里。它记得每个伙伴学会第一道菜的样子，偏不肯在自己的本子上写“教完了”。

**还有一个问题**

来客带来异乡的动植物名字，白泽也会停笔请教。有人读得快，它便重问一遍，把音节记在页边。等客人告辞，那本看似什么都知道的书，又悄悄厚了一点。

> 得白澤神獸能言達於萬物之情
> ——《云笈七签》
> He encountered Baize, a speaking divine beast that understood the nature of all things.

遇见名叫白泽的神兽，它能说话，通晓万物的情状。

**Baize, Keeper of Many Stories**

Baize teaches the inn's staff and tells the histories of countless beings. Its notebook has curled corners and questions squeezed into the remaining margins.

**A name for the unknown**

Stories of the Yellow Emperor questioning a speaking Baize connect the creature with knowledge of the world. Traces of Baize illustrations join pictures to names. Something once frightening on a traveller's path becomes a being that can be recognised.

**Return the spatula**

A failed plate of rice begins a lesson in tasting: wet grains or hurried heat? After the explanation, Baize hands the spatula back. It remembers each learner's first successful dish, yet never marks the teaching finished.

**One more question**

Visitors bring unfamiliar plant and animal names. Baize asks them to repeat the sounds and writes them carefully. By departure, the supposedly all-knowing book has become a little thicker.

### 应龙 · Yìnglóng

应龙有翼，掌水与雨，如今在小馆烹调水产。它做菜惯于先听锅声，窗外若响起第一滴雨，翅膀便会不自觉地舒展开来。

**雨落以前**

《山海经》里的应龙参与黄帝与蚩尤的战争，也与蓄水、旱雨相连。久旱时，人们借应龙的形象盼雨。那双翅膀越过战场，也掠过田垄，最终停在人们仰望云层的目光里。

**锅里也有江河**

它下水产时手很轻，最怕别人把清鲜煮成一锅急躁。有人问雨何时停，应龙往窗外看一眼，只回答海鲜该何时起锅。天上的事太远，碗里的这一口，它倒愿意管到底。

**龙的另一条水路**

远客说家乡故事里的龙守着洞窟和宝藏，应龙便讲起求雨时的田野。话题顺着不同的传说走，落到同样干裂的泥土。原来一场及时雨，也足够让龙的故事在人心里长久盘旋。

> 旱而為應龍之狀乃得大雨
> ——《山海经》
> In drought they made the form of Yinglong, and abundant rain came.

天旱时，人们做出应龙的形象，随后得到了大雨。

**Yinglong, the Rain-Bearing Dragon**

Yinglong has wings and a history of water and rain. At the inn, this seafood chef listens to the pot and stretches unconsciously at the first drops outside.

**Before the rain**

In the Classic of Mountains and Seas, Yinglong joins the Yellow Emperor's battles and becomes associated with stored water, drought and rainmaking. Its wings pass over conflict and fields alike, arriving in the upward gaze of people waiting for clouds.

**Rivers in the pot**

Yinglong handles seafood gently and dislikes a delicate broth boiled into haste. Asked when the rain will stop, it answers when supper should leave the heat. The sky is vast; this particular bowl is its responsibility.

**Another dragon's waterway**

A visitor remembers treasure-guarding dragons. Yinglong describes rain awaited over farmland. Different tales lead their conversation toward the same cracked earth. Timely rain supplies another enduring reason to imagine a dragon.

### 烛龙 · Zhúlóng

烛龙人面蛇身，通体赤色，传说睁眼为昼、闭眼为夜。它在食肆掌勺，最爱夜市开灯时刻，却总嫌客人把面催得太急。

**钟山的一次呼吸**

《海外北经》写钟山之神烛阴，视为昼，瞑为夜；《大荒北经》又有烛龙的赤色长身。昼夜与季候借着一双眼、一息风变得可以看见，天地的运转也有了一位缓缓醒来的主人。

**面还没有熟**

它记时很准，收火却从不迁就催促。客人笑问能否眨眨眼把等待变短，烛龙便把锅盖揭给人看：“你看，它也得自己醒。”说完慢慢合盖，留一缕白汽向夜色里升去。

**把天空讲近些**

人们曾借太阳、车驾、神鸟或巨蛇讲述天光来去。烛龙的故事把日夜系在呼吸与睁眼之间。夜食的人听着听着，也会留意自己掌心的热碗，和窗外正在一点点变深的蓝。

> 視為晝暝為夜
> ——《山海经》
> Its looking makes day; its closing eyes make night.

它睁眼便是白昼，闭眼便是黑夜。

**Zhulong, Keeper of Day and Night**

Zhulong is red-bodied and serpent-shaped, with a human face. Its eyes govern day and night in old tales; its present concern is a noodle pot that guests keep rushing.

**A breath over Zhong Mountain**

The Classic describes Zhuyin making day by looking and night by closing its eyes, and elsewhere a red Zhulong. Changing light and seasons acquire a body, a gaze and a breath: the sky becomes something a listener can picture.

**The noodles are still asleep**

A guest asks whether one blink could shorten the wait. Zhulong lifts the lid: these must wake by themselves. Steam rises slowly into the evening as it closes the pot again.

**Bringing the sky closer**

Sun chariots, birds and great serpents carry daylight through different traditions. Zhulong ties it to breathing and sight. Listening over supper, a guest notices the warm bowl in their hands and the blue deepening outside.

### 帝江 · Dìjiāng

帝江形似赤色黄囊，六足四翼，浑敦无面目，却识得歌舞。它负责传菜，轻轻一转身，托盘就像踩上了旁人听不见的拍子。

**天山自有乐声**

《西山经》把帝江安放在天山，那里有金玉，也有向西南流去的水。六足、四翼与无面目的形体被写在一处，最后忽然落下“识歌舞”三字，仿佛古书自己也听见了节拍。

**这一拍请接稳**

它端菜时总等客人双手接好，才转入下一步。灌灌想替它配一声响亮的报菜，帝江却用六只脚敲出更细的节奏。连最心急的一桌，也会跟着那一下停顿，把碗稳稳放好。

**听见一个动作**

陌生语言尚未来得及译完，鞠躬、让路与递盘已经完成。帝江的欢迎没有眉眼，却有起落与回应。远客学着它的步子离开，门口响起一串略显笨拙、又十分认真的足音。

> 渾敦無面目是識歌舞
> ——《山海经》
> Without a distinct face, yet knowing song and dance.

它浑敦无面目，却识得歌舞。

**Dijiang, the Faceless Dancer**

Dijiang is red as flame, with six feet, four wings and no distinct face. It knows song and dance, and carries dishes to a rhythm only it seems to hear.

**Music on Tianshan**

The Western Mountains places Dijiang among Tianshan's gold, jade and flowing waters. Its startling anatomy concludes with an unexpected accomplishment: it understands music and dance. The old description seems to discover a beat of its own.

**Catch this beat**

Dijiang waits for a guest to receive the plate before turning. Guanguan offers a loud announcement; six feet answer with a finer rhythm. Even an impatient table pauses at the right moment and sets the bowl safely down.

**An action understood**

Before a translation is finished, the bow, the offered space and the dish have arrived. This welcome has timing instead of facial expression. Guests leave trying its steps, with earnest, slightly clumsy footfalls at the door.

### 九婴 · Jiǔyīng

九婴是多首的厨师，能同时照看几处灶火。忙起来每个脑袋都觉得自己最清醒，厨房里最热闹的争论，有时只来自它一个。

**凶水上的旧名**

《淮南子》记羿在凶水之上杀九婴，古注称它为水火之怪。后来流传的多首形象，把相反的水与火聚在同一个名字里。那些猛烈的力量，在旧故事里曾让人畏惧。

**几口锅，几种意见**

这一锅该添汤，那一锅要收汁，九婴能同时看顾，也能同时嫌别人手慢。等几只锅一齐沸起，它又得请伙伴接盘。最爱逞强的那颗头，这时候偏偏把声音放得最轻。

**多首的各自旧事**

别处也有多首怪物，有的守门，有的盘踞水泽。九婴的名字却沿着羿与凶水走来。初见相似的轮廓，旅人便问起它的故事；听到末尾，灶上又多了一口正等出菜的热锅。

> 殺九嬰於㐫水之上
> ——《淮南子（淮南鸿烈解）》
> He slew Jiuying upon the fierce waters.

在凶水之上，羿杀死了九婴。

**Jiuying, Many Heads at the Stove**

Jiuying watches several cooking stations at once. Each head considers itself the most alert; some of the kitchen's liveliest arguments involve only this one chef.

**A name at Fierce Water**

The Huainanzi records Yi slaying Jiuying, with old commentary calling it a creature of water and fire. Later many-headed imagery gathers opposing forces into one formidable being. Its name still carries the turbulence of that story.

**Several pots, several opinions**

One pot needs broth, another reduction. Jiuying handles both and complains about slow hands until everything boils at once. Then it needs help with the plates. The proudest head makes the quietest request.

**Each many-headed history**

Other traditions have many-headed creatures at gates and in waters. Jiuying's story follows Yi and Fierce Water. A traveller begins with a familiar silhouette and discovers a different tale while another pot reaches the serving point.

## 一桌山海

### 阳春面 · Yáng chūn miàn

清汤托着细面，葱香先于筷子升起。阳春面是有间小馆开门便有的一碗，几样寻常滋味，接住一天里最早的饥饿。

**清鲜的底子**

江南常见的阳春面，也叫光面，热汤、面条与调味便能成一餐。汤要清，滋味却要站得住；面要顺，入口仍留一点弹性。《随园食单》所说“清鲜”二字，恰好让这份简净有了分量。

**葱花浮起来**

羬羊尝过汤才肯落面，鸮端起碗便不再停步。葱花从碗边散开，第一筷面挑起来时，汤面还留着一圈轻轻晃动的油光。早到的客人常先不说话，只把热气慢慢吸进鼻尖。

**鲜字的第一课**

初尝中国汤面的旅人，往往先问配料在哪里。喝到碗底，才发现清汤也能留下长长的余味。Xian这个陌生音节，从一口鲜香开始，渐渐有了可以带回家讲给人听的形状。

> 味要清鲜，不可淡薄。
> ——《随园食单》
> Flavour should be fresh and clear, without being thin.

味道要清鲜，仍须留得住滋味。

**Yangchun Noodles**

Clear broth, fine noodles and spring onion introduce the day at Youjian. Yangchun noodles are available from opening, a familiar warmth for the first hungry guest.

**The weight of simplicity**

Often called plain noodles, this everyday Jiangnan bowl relies on broth, seasoning and texture. Clear soup needs depth; smooth strands keep a little spring. The Suiyuan Shidan's ideal of clear, fresh flavour gives this modest meal a demanding standard.

**When the garnish opens**

Qianyang tastes the broth before the noodles enter. Xiao carries the bowl directly to the table. Spring onion spreads across a faint sheen, and the first lifted strands release a breath of fragrant steam.

**Learning xian**

A traveller first looks for elaborate toppings. By the final spoonful, the broth has supplied its own lingering answer. Xian, savoury freshness, becomes a Chinese word with a flavour to take home.

### 蛋炒饭 · Dàn chǎo fàn

米粒在热锅里散开，鸡蛋裹上金黄，葱香随锅铲一翻而起。蛋炒饭是小馆最家常的主食，也最容易叫人认真谈起自己的家。

**粒粒之间**

熟米饭下锅，要松散，又要留着米香；鸡蛋与饭粒相遇，有人爱裹得均匀，有人偏爱见得着的嫩块。各家的手势不同，一盘炒饭便在火候、调味与习惯之间，生出许多亲近的版本。

**锅铲响三声**

忙时它出得利落，盛到盘里仍有热气钻出。伙计端饭经过门口，香气常能让正在看招牌的人转过头。赶路的客人坐下吃几口，肩上的行囊也跟着慢慢放低。

**你家的那一盘**

有人想起加豌豆的饭，有人想起昨日余下的菜，另一个人说故乡会添香料。谈话沿着米粒走远，又回到眼前的鸡蛋。大家各说各家的做法，筷子却都在同一阵锅香里停不下来。

**Egg Fried Rice**

Rice loosens in the hot wok, egg turns gold and spring onion rises with the spatula. The inn's egg fried rice has an easy way of starting conversations about home.

**Between the grains**

Cooked rice must separate while keeping its fragrance. Some cooks coat each grain with egg; others prefer tender pieces. Heat, seasoning and familiar gestures give a humble plate many recognisable versions, each remembered by somebody.

**Three turns of the spatula**

During a rush, the plate arrives promptly and still steaming. Its fragrance can turn a passer-by from the sign toward the doorway. A traveller eats, and the bag on their shoulder gradually settles beside the chair.

**Your family's version**

Peas, yesterday's vegetables, a favourite spice: memories cross the table. The conversation travels outward with the grains, then returns to the egg and wok fragrance in front of everyone.

### 酸梅汤 · Suān méi tāng

乌梅的酸香沉在杯底，甜味随后轻轻回转。酸梅汤是小馆常备的饮品，热菜吃到一半，端起它，舌尖便换了一阵清风。

**梅香有深浅**

酸梅汤常以乌梅调味，熏制的梅香带一点幽深，酸与甜在杯中彼此牵引。人家各有添减，有的偏酸，有的留甘。杯色深浅之外，更值得等的是咽下之后慢慢回来的那一缕滋味。

**杯沿留一口**

烤翅上桌后，它常跟着来到。有人大口喝，有人只在两筷之间抿一点；等到盘中只剩骨头，杯底往往还留一口，像把那阵清爽特意存到了最后。

**汤字走出饭碗**

Suān méi tāng，名字里有“汤”，手中却是一杯酸甜饮料。远客先尝梅香，再学着念这个词，才发现中文菜单里的一个字能走过不同器皿，装下不同温度的日常。

**Suanmeitang, Sour Plum Drink**

Smoked-plum fragrance deepens the cup, followed by a light return of sweetness. Suanmeitang refreshes the table between hot, savoury dishes.

**Depth in a plum**

This Chinese drink commonly takes its flavour from wumei, prepared plums with a distinctive smoky scent. Families balance sourness and sweetness differently. Beyond the dark colour, the pleasure lies in the flavour returning after a swallow, when the cup has already left the lips.

**A final sip**

It often follows the grilled wings to the table. Some guests drink freely; others sip between bites. When only bones remain, one mouthful may still wait at the bottom, saved for the end.

**Tang beyond a soup bowl**

Suān méi tāng includes tang, a word many learners know as soup. Here it names a sweet-and-sour drink. Tasting first gives the Chinese word room to travel between vessels, temperatures and everyday habits.

### 羬羊羊肉汤 · Qián yáng yáng ròu tāng

羬羊的招牌羊肉汤，肉香沉厚，热汤清润。几片软熟的羊肉、一勺耐心熬出的鲜，把钱来山的寒意留在了门外。

**厚味留清处**

中国各地的羊汤各有面目：浓白、清亮、重香料或重本味。有间这一碗顺着羬羊的性子慢熬，肉熟而汤仍利落。《随园食单》说浓厚不可油腻，那点分寸，要在一勺入口以后才知晓。

**钱来山的松风**

羬羊守锅时偶尔讲起山上的松树，讲得短，留白却多。肉片在汤里舒展，勺子拨开一线热汽，仿佛山路拐弯以后，忽然有人替旅人推开了一扇有灯的门。

**故乡汤的名字**

客人说这味道像故乡的一道炖汤，又说香气终究不同。羬羊便请人把名字写下，夹在自己的汤谱里。两碗汤隔着山海各有来处，落到手心时，却都使人舍不得放凉。

> 味要浓厚，不可油腻。
> ——《随园食单》
> Flavour should have depth without becoming greasy.

味道要浓厚，也要让人吃得清爽。

**Qianyang’s Mutton Soup**

Qianyang's signature mutton soup pairs tender slices with a broth of quiet depth. A long simmer keeps the mountain cold outside the inn's door.

**Richness with a clear edge**

Chinese mutton soups range from milky-white to clear, with varied seasoning traditions. This bowl follows Qianyang's patient temperament: softened meat and a clean finish. The Suiyuan Shidan's advice, depth without greasiness, becomes something to judge by the spoonful.

**Pine wind from Qianlai**

Occasionally the cook mentions the mountain's pines. The story is brief, with plenty of silence. A ladle parts the steam, like a lit door opening after a turn in a cold hillside path.

**A soup from elsewhere**

A traveller remembers a stew from home, similar and differently fragrant. Qianyang asks for its name and keeps it in the recipe notebook. Both bowls have distant origins; both deserve warm hands around them.

### 毕方烤翅 · Bì fāng kǎo chì

薄脆的翅皮收住肉汁，丹木果添一线果香。毕方烤翅刚离火时最动人，盘子才放稳，焦香已经替厨师说完了招呼。

**炙的手艺**

食物靠近火，表面渐渐变色，香气也从浅到深。古书中的“炙”把这种做法留成一个字；真正落到手上，还得辨火势、记翻面。毕方惯等明焰退去，让炭热慢慢把外皮烤出轻响。

**赤纹照着炉光**

它羽上的红纹在炉边格外醒目，夹子却落得极稳。丹木果的山海果香停在表皮，一口咬开，里面仍是柔软热肉。那只独足鸟守过的火候，就藏在这道脆与嫩的分界里。

**最后一只归谁**

烤物在许多餐桌上都伴着谈话，手指、筷子与分食的习惯各有不同。盘里剩最后一只时，大家忽然都客气起来；一段新的交情，常从那次推来让去的笑声里开始。

**Bifang’s Ember-Roasted Wings**

Crisp skin holds the juices while imagined Danmu fruit lends a fragrant edge. Bifang's wings announce themselves in the brief moment after leaving the fire.

**The craft of zhi**

The Chinese character zhi preserves an old association between food and direct heat. At the grill, it requires close attention to flame and turning. Bifang waits for open fire to subside, letting the coals bring a fine crackle to the skin.

**Red markings by the coals**

The chef's feather markings glow beside the stove; the tongs remain steady. Fruit fragrance meets crisp surface and tender meat. Bifang's patience sits at the boundary between those two textures.

**The final wing**

Grilled food accompanies conversation at many tables, with different utensils and sharing customs. At the last wing, everyone becomes suddenly generous. A new friendship sometimes begins in that laughing exchange of offers.

### 九尾仙奶 · Jiǔ wěi xiān nǎi

九尾狐的招牌乳饮，奶香轻柔，薲草添一点山海清气。杯面细润，尾影在灯下一晃，像青丘的夜色悄悄靠近了桌沿。

**一杯乳香的形状**

温柔的奶香先铺开，草木清气随后回转，甜味收得轻。薲草把山海植物的想象带入杯中，乳饮则留下熟悉的柔滑。九尾狐挑剔杯口的洁净，端出去以前，总要把每一滴余痕擦去。

**青丘有许多面貌**

古书里的九尾狐既能令人畏惧，也曾承载祥瑞之意。小馆这一杯借了它善变又轻盈的气息：灯下看是奶色，抬头看却有九道尾影。客人慢慢喝，故事也就有空多讲一折。

**仙字落在杯边**

Xiān能唤起仙人、山林与超出日常的轻灵。译成一个英文词，总还有些余味留在外面。远客把杯子转半圈，看奶色映着灯光，或许已经尝到了这个字想留下的那一点飘然。

**Nine-Tailed Fox’s Cloud Milk**

Jiuweihu's signature milk drink carries a gentle herbal note from imagined Pincao grass. Lamplight gathers on its smooth surface like evening at Qingqiu.

**A shape for milk fragrance**

Soft dairy flavour opens first, followed by a fresh green note and restrained sweetness. Pincao supplies a mountain-and-sea flourish to a familiar texture. The fox is exacting about the cup: every stray drop is wiped away before serving.

**Many faces of Qingqiu**

The nine-tailed fox carries both danger and auspicious associations through old tales. This drink borrows its shifting lightness. Milk glows in the cup while nine shadows pass above it, leaving time for another turn of the story.

**Xian at the rim**

Xian suggests immortals, secluded mountains and an air beyond the everyday. An English description catches some of that atmosphere. Slowly turning the cup beneath the lamp supplies another way to understand the word.

### 应龙海鲜锅 · Yìng lóng hǎi xiān guō

山海水产在热汤里舒展，鲜味随着小滚一点点释放。应龙海鲜锅端到桌上，锅沿有汽，窗外有雨，一顿饭便多了共同等待的工夫。

**围锅的水声**

火锅把烹调的一部分留在桌边。食材入汤，先后有别，刚熟的鲜嫩也要及时夹起。应龙偏爱把汤守得清亮，让水产的滋味彼此照面；越吃到后面，锅里越藏着前几轮留下的鲜。

**有翼之龙的雨**

应龙在山海故事中与水、旱雨相连，这口锅便把它的来处化成一阵阵白汽。雨天来客收好湿伞，坐近一些，听雨点与沸水互相应答，仿佛远方的江海也在桌边开了口。

**一双筷子的邀请**

初次围锅的人，常先看同桌怎样候熟、怎样分盛。有人递过一双公筷，有人让出刚好的那一片，吃法便在动作之间慢慢传开。等学会等候，谈话也比开席时热了起来。

**Yinglong’s Seafood Hot Pot**

Mountain-and-sea seafood releases its savour into a gently bubbling broth. Yinglong's hotpot gives the table warmth and the shared pleasure of waiting together.

**Water at the table**

Hotpot leaves part of the cooking beside the diners. Ingredients require different timings and reward attention. Yinglong keeps the broth clear enough for their flavours to emerge; later spoonfuls carry the accumulated savour of earlier rounds.

**Rain from a winged dragon**

Yinglong's old association with water and rain becomes steam above the pot. Guests fold wet umbrellas and sit closer. Drops outside answer the simmer within, bringing distant rivers into a small dining room.

**An invitation in chopsticks**

A newcomer watches the timing and serving gestures. Somebody offers communal chopsticks; somebody passes a perfectly cooked piece. The meal teaches its customs through movement, and conversation gradually warms with the soup.

### 饕餮自助套餐 · Tāo tiè zì zhù tào cān

热饭、烤物与时蔬铺开一桌，饕餮自助套餐把选择交给食客。先取哪一口、再添哪一样，每个人的盘子都能排出自己的次序。

**一桌丰盛**

自助的趣味在于亲自选择，米饭托住热菜，烤香与蔬味留出转身。小馆陆续补上新盘，让来得晚的客人也能遇见热气。饕餮站在出菜处，眼光比谁都忙，盯着哪一道最先见底。

**大胃口的得意**

谁说发现了新喜欢的菜，它便笑得大口一张，恨不得立刻再烹一盘。可若有人拿得太多，饕餮又会凑近看：“先吃这一口，后面的我替你守着。”说完自己也忍不住咽一咽。

**盘里的余地**

各地宴席对丰盛有各自的表达，小馆这一桌把余地留给胃口。客人少取几样、吃完再来，第二次便能带着自己的发现向同伴推荐。丰盛沿着盘子流动，最后化成一桌人说得出的好味道。

**Taotie’s Feast of Choices**

Rice, grilled dishes and vegetables spread across Taotie's buffet. Each guest gives their plate a different order: the first taste, the favourite return, the unexpected discovery.

**A table of choices**

Fresh dishes arrive gradually, keeping warmth available for later guests. Rice supports rich flavours; vegetables offer a change of pace. Taotie watches which platter empties first with the concentrated interest of a chef and a very hungry admirer.

**An appetite's delight**

Discover a new favourite and its enormous mouth opens in a grin. Overfill a plate and the chef leans closer: taste this first; I will guard the rest. It swallows longingly at its own promise.

**Room on the plate**

Feasts express abundance differently across cultures. Here, taking a little and returning creates room for discoveries. Guests come back to their companions with recommendations, giving the table a growing vocabulary of shared flavours.

### 凤凰涅槃羹 · Fèng huáng niè pán gēng

细碎食材在羹里相拥，稀有食材的鲜香缓缓舒开。凤凰涅槃羹盛在一只温碗里，五彩的祥瑞与新生的火光，都落成了勺中的微亮。

**一勺里的细工**

羹能把切得细小的食材与汤相合，入口绵润，滋味却有层次。凤凰煮这一盏时，最在意收火的时机：多一分显重，少一分又留不住香。勺背薄薄挂住的那点稠，恰够托起余味。

**五彩与火光**

《山海经》的凤凰自歌自舞，带来安宁；浴火新生的鸟又从别的故事飞来，在近现代的凤凰意象中留下火光。菜名把两束光收在一处，落到桌上时，先照见的是吃饭人的脸。

**涅槃一词的远行**

“涅槃”随佛教译语从梵语来到中文，含着烦恼止息的深意。后来诗与日常语言又借它讲新生。一勺热羹在唇边稍停，喧闹暂远，那个长途而来的词，也添上一层此刻的安静。

**Fenghuang's Renewal Broth**

Fenghuang's Renewal Broth gathers finely prepared ingredients into a smooth, savoury spoonful. Coloured feathers and the light of a fresh beginning seem to meet above the bowl.

**Fine work in a spoon**

Geng brings small ingredients together in a gently thickened soup. Fenghuang watches the finish closely: enough body to carry fragrance, enough lightness to leave the palate clear. A thin coating on the spoon holds the final flavour.

**Feathers and firelight**

The Classic's Fenghuang sings and heralds peace. Stories of another bird reborn in flame contribute a different light to modern phoenix imagery. The dish gathers these resonances beside the guest's quietly illuminated face.

**A travelling word**

Niepan entered Chinese through Buddhist translation from Sanskrit nirvana, carrying the profound idea of afflictions coming to rest. Later poetic usage also evokes renewal. A pause above the warm spoon gives that far-travelled word a moment of stillness.

### 祝余轻食 · Zhù yú qīng shí

祝余草的青意盛成一盘，清脆入口，调味轻轻收住。祝余轻食由白泽照看，把招摇山开篇的一株奇草，带到今日小馆的餐桌。

**青花开在书页上**

《南山经》开篇的招摇山，生着状如韭而开青花的祝余，古书说食之不饥。山海长卷还没走远，先递来一株可以饱腹的草，像替将要出发的人预备了一点粮食。

**盘中留清风**

白泽把草叶理得整齐，保留脆嫩，让一点清爽调味沿叶面展开。热菜吃久了，夹一口，舌尖便有了轻快的空隙。名字里的“轻”，在这里落到声音与口感上，像筷子碰过一片新叶。

**新菜单，旧山路**

“轻食”是当代菜单常见的说法，祝余却来自古人的想象。远客念完这两个字，抬眼再看盘里的青色，一次日常点菜也能沿着植物的名字，走回很久以前的中国山路。

> 其狀如韭而青花其名曰祝餘
> ——《山海经》
> It resembles chives, with blue flowers, and is called Zhuyu.

它像韭菜，开青色花，名叫祝余。

**Zhuyu Greens**

Zhuyu greens bring crispness and light seasoning to a plate watched over by Baize. A plant from the Classic's opening mountain finds a place on a contemporary menu.

**Blue flowers on a page**

The Southern Mountains begins with Zhaoyao, where chive-like Zhuyu bears blue flowers and is said to dispel hunger. Before the long journey through mountains has begun, the book offers a remarkable plant, like provisions left for a departing traveller.

**A fresh interval**

Baize arranges the tender leaves and lets a restrained dressing follow their surfaces. Between richer dishes, a crisp bite gives the palate room to turn. Lightness becomes a texture and a small, clear sound.

**A new menu, an old path**

Light dining belongs to today's menus; Zhuyu belongs to ancient imagination. Learning the plant's name lets an ordinary order lead back along a much older Chinese mountain path.

### 陆吾烤肉拼盘 · Lù wú kǎo ròu pīn pán

山猪肉切成几样适口的块片，烤香、肉汁与不同火候铺成一盘。陆吾烤肉拼盘出得整齐，连最后一块，也等在恰好的位置。

**热盘上的次序**

厚薄不同的肉，受火的工夫各有长短。先把焦香收住，再让熟度与口感彼此衬托，一盘才有起伏。陆吾要的丰盛带着次序，夹起哪一块，都能接得上前一口留下的滋味。

**昆仑管家的手势**

掌过帝苑时节的九尾神，连烤炉上的一小片刻也想安排妥当。它翻过这边，又看那边，尾巴在身后微微错开。等全盘终于出炉，陆吾才像把一场纷繁的午市收进了掌心。

**请尝这一块**

有人爱焦边，有人喜欢柔软些，拼盘把几种偏好留在一处。同桌递过自己最中意的一块，再用另一种语言寻味道的词。昆仑的旧名就在这样的推让之间，多了今日餐桌上的新声音。

**Luwu’s Roast Platter**

Luwu's platter arranges mountain pork in pieces with different textures and degrees of char. Even the final slice seems to wait in exactly the right place.

**Order on a hot plate**

Cuts of different thickness require different moments at the fire. Fragrant edges and tender centres answer one another across the platter. Luwu wants variety with a sequence, each bite finding a connection to the one before it.

**The garden-keeper's gesture**

A guardian once responsible for celestial seasons now attends to small intervals at the grill. It turns one piece, checks another and shifts its tails. The completed platter appears to gather an entire busy service into manageable order.

**Try this piece**

One guest loves crisp edges; another prefers softness. Passing favourites gives them a reason to search for flavour words in another language. Kunlun's ancient name gains a new, conversational life around the plate.

### 英招时蔬沙拉 · Yīng zhāo shí shū shā lā

迷榖芽与时蔬拌在一起，脆嫩之间带着山海草木的清气。英招时蔬沙拉像一小片会换颜色的园圃，把四时风物盛到眼前。

**叶色随时来**

时蔬的好处，是季节会替盘子改换颜色。叶要新鲜，芽要脆，清爽的拌味只把各自的香气轻轻牵到一起。英招挑菜时总问从哪里来，仿佛一片叶子也值得附上一张小小的地图。

**走不丢的绿意**

《南山经》的迷榖带着使人不迷的奇妙意味，英招则是照看天帝园圃的神。两段草木旧事在盘里碰面，芽叶被轻轻翻起时，像山路拐过一处，忽然看见了熟悉的方向。

**沙拉来到这里**

“沙拉”随饮食交流进入中文，吃法越过许多地方，又遇见本地时蔬。如今英招再添一笔山海的绿，借来的词与自己的故事便在叉尖、筷尖之间，长成一次新的相识。

**Yingzhao’s Garden Salad**

Migu shoots and seasonal vegetables make Yingzhao's salad a small garden of changing colours, crisp textures and imagined mountain fragrance.

**Leaves keeping the season**

Seasonal vegetables let the plate change with the weather. Tender leaves and crisp shoots meet a light dressing. Yingzhao asks where each ingredient grew, as though every leaf deserved a small map beside its name.

**Greenery that knows the way**

The Southern Mountains gives Migu a wondrous association with finding one's way; Yingzhao tends celestial gardens. Their separate botanical stories meet on this plate. Turning a leaf seems to reveal a familiar direction around a bend.

**Salad arriving here**

The word salad travelled into Chinese with food and found local vegetables waiting. Yingzhao adds a mountain-and-sea flourish. A borrowed word and an old story grow into a new encounter between fork and chopsticks.

### 精卫石锅拌饭 · Jīng wèi shí guō bàn fàn

热石锅托住丹粟米，配菜铺开颜色，拌下去时锅底还轻轻作响。精卫石锅拌饭把中国的小鸟故事，与韩国拌饭的一口热香放到了一起。

**先看，再拌**

韩国拌饭把米饭、配菜与酱味交给食客亲手拌合，石锅又添一层锅底的香脆。有间借来这份吃法，让红亮的丹粟米与几样配菜相映。第一眼各有颜色，第一勺便有了彼此。

**一小块木石**

精卫一次衔一块木石，这锅饭也从洗米、备菜、等锅热的一步步里积起香气。勺子刮到锅底那一下，细碎的脆响很像石子轻碰。小鸟忙了一日，终于肯在热气前稍稍停身。

**两条来路**

精卫沿中国古籍飞来，石锅拌饭沿韩国餐桌的吃法而来。一个名字、一种手势，在同一只锅里相遇。远客边拌边听故事，等最后一口锅巴入口，已经能把两段来路分别讲给同桌听。

**Jingwei’s Stone-Pot Bibimbap**

Dansu rice and colourful accompaniments meet in a hot stone pot. Jingwei's Stone-Pot Bibimbap brings a Chinese bird's story beside a Korean way of eating.

**Look, then mix**

Korean bibimbap invites the diner to combine rice, accompaniments and sauce. A stone pot adds a crisp lower layer. Here, imagined red-tinted Dansu rice joins the colours. Separate at first glance, the ingredients become one another's company with the spoon.

**One small stone**

Jingwei carries wood and stone piece by piece. Washing rice, preparing toppings and heating the pot build this meal through similarly small tasks. The spoon's scrape against the crisp base recalls pebbles touching. At last, the little bird pauses before the steam.

**Two journeys**

Jingwei arrives through Chinese literature; bibimbap through Korean tables. Story and gesture meet in one vessel. By the final crisp spoonful, a visitor can recount both journeys to their companions.

### 当康丰收炒饭 · Dāng kāng fēng shōu chǎo fàn

丹粟米与熟米粒在热锅里翻出香气，几样配料添上丰收的颜色。当康丰收炒饭盛得扎实，像把满仓的好消息先分一碗给眼前的人。

**谷物的亮处**

米饭要炒得松，丹粟米的山海色泽便藏在颗粒之间。锅铲翻起，香气短短升高，再被热盘接住。庄稼从田里到灶上要走很长的路，这一盘把路尽头那点饱足，做得清楚而热烈。

**听见大穰**

《东山经》说当康现身则天下大穰。报丰收的异兽在小馆最爱看人添饭，自己却总等最后一桌吃妥才坐下。盛饭的勺子搁稳以后，那两颗獠牙仿佛也终于松了一口气。

**丰年上桌**

有人讲故乡新米的香，有人记得收获节第一块面包。当康听得高兴，便把“穰”字写在纸上，旁边画满谷粒。各地的庆祝各有声色，这一盘热饭却让好年成先有了共同的香气。

> 見則天下大穰
> ——《山海经》
> Its appearance foretells a plentiful harvest for the world.

它的出现，预示天下丰收。

**Dangkang’s Harvest Fried Rice**

Dangkang's harvest fried rice turns grains and colourful accompaniments into a generous, fragrant plate. The good news of a full storehouse reaches the diner first.

**Grain in the light**

Loosened rice carries the imagined glow of Dansu grains. The spatula lifts their fragrance briefly before the hot plate catches it. Food has travelled from field to stove; this serving gives that long journey a vivid, satisfying destination.

**Hearing da rang**

The Eastern Mountains links Dangkang's appearance with abundant harvests. The creature enjoys second helpings but sits down only after the final table is served. Once the rice spoon rests, even its tusks seem relieved.

**A harvest at the table**

Guests recall new rice or the first bread of a harvest festival. Dangkang writes rang, abundance, beside a drawing crowded with grains. Different celebrations acquire a shared fragrance over this warm plate.

### 天狗天妇罗 · Tiān gǒu tiān fù luó

海鲜裹着薄衣入油，捞起时轻脆，咬开后仍留鲜嫩。天狗天妇罗是一盘日式炸物，送到桌边的时机，像白首店员守门一样认真。

**衣要轻，心要嫩**

天妇罗在日本饮食中以裹浆油炸见长，食材与外衣之间讲究轻薄的分寸。热油里的一段工夫很短，上桌后的脆也留不了太久。筷子碰开的那一下，最能听见厨师与送菜人的默契。

**阴山来客借一盘**

这道菜挂着中国山海天狗的招牌：白头、似狸，来自阴山。另一个熟悉日本天狗的客人，却先想到长鼻与鸟翼。天狗把刚炸好的盘子推近，两边的故事便顺着一口热脆聊开。

**名字跨海的时候**

Tiangou、tengu与tempura，在菜单上挨得很近，各自又领向不同的来路。先把薄衣咬开，再慢慢认名字，往往比急着把整页译完更有滋味。热气稍散，谈兴倒刚刚起来。

**Tiangou’s Tempura**

Seafood wears a thin, crisp coating with tenderness beneath. Tiangou's Tempura depends on careful frying and an equally attentive journey to the table.

**A light coat**

Japanese tempura gives batter-fried ingredients a delicate outer layer. The moment in oil is brief, and crispness has its own short life afterwards. The first crack beneath chopsticks records the cooperation between cook and server.

**A plate for a mountain visitor**

The dish bears the name of China's white-headed, wildcat-like Tiangou from Yin Mountain. A guest familiar with Japanese tengu first imagines a long nose and wings. The waiter offers the hot plate; their conversation opens with a crisp bite.

**Names across the sea**

Tiangou, tengu and tempura sit close on the menu while leading toward different histories. Tasting first gives each unfamiliar name a place to settle. As the steam thins, the conversation is only beginning.

### 冉遗鱼汤 · Rǎn yí yú tāng

山海水产在清汤里慢慢熟透，鲜香留得细，入口仍清亮。冉遗鱼的招牌鱼汤像一段不急着讲完的水声，越静下来，越能尝出深处。

**鲜味浮起以前**

一碗鱼汤可以浓白，也可以清澈。有间这一碗偏向后者，缓缓下料，及时收火，让水产的鲜自己浮出来。汤面少一点喧闹，咽下以后，舌尖反倒能听见更长的一段回声。

**六足护住热碗**

冉遗鱼照着锅，也护着刚温好的碗。古书里的涴水与英鞮山，被它讲得比汤声还轻；等蛇首转向传菜口，六只脚已经把热碗稳稳交到伙计手中，连一滴也没溅出。

**水边的人会认得**

有人想到家乡河鱼，有人想到海边清汤，名字不尽相同。厨师请客人把那条水的名字写下，放在碗旁。两处水声隔着语言远远相答，眼前的汤便添了一点可以谈论的乡音。

**Ranyiyu’s Clear Fish Soup**

Ranyiyu's signature fish soup keeps its seafood savour clear and delicate. Like a slowly told river story, it reveals more as the table grows quiet.

**Before the savour rises**

Fish soups may be milky or clear. This bowl favours clarity, with ingredients added gently and heat stopped in time. Less commotion at the surface leaves a longer impression after the swallow, a quiet depth beneath the first taste.

**Six feet around a bowl**

Ranyiyu minds both pot and warmed crockery. Its account of Wanshui and Yingtishan is softer than the simmer. By the time the serpent's head turns toward the hatch, six feet have delivered the bowl without a spill.

**Recognised by the water**

River fish and coastal soups come to guests' minds under different names. The chef asks them to write their home waterway beside the bowl. Distant places answer through language, adding another accent to the meal.

### 穷奇麻辣火锅 · Qióng qí má là huǒ guō

花椒先起香，辣椒随后把热意送上来。穷奇麻辣火锅汤色鲜明，越煮越有层次，像这位烈性厨师把一句直话说得又响又长。

**麻与辣分两路**

花椒的麻在舌面轻轻跳，辣椒的热又从另一处涌来。现代麻辣风味把两种感觉并在一起，锅底还得留住咸鲜与香气。穷奇尝汤时先闭眼，等麻、辣各自落妥，才肯招呼人下菜。

**锅里正起风**

食材入汤，翻上来又沉下去，围锅的人也渐渐红了脸。穷奇偏爱听一声痛快，遇见有人迟疑，便另盛一小勺让人先尝。它嘴上仍硬，勺子里的分量倒拿捏得很细。

**把málà分开念**

初来的客人常只会说“辣”，尝过这一锅，再把麻与辣分开，语言也跟着多出一种触感。有人比画针尖，有人说像轻响的电流，穷奇听完逐句点评，热气里便多了一场舌尖的谈话。

**Qiongqi’s Mala Hot Pot**

Sichuan pepper opens the fragrance; chilli brings the heat behind it. Qiongqi's Mala Hot Pot builds a bold broth with a temper as memorable as its chef.

**Two routes across the tongue**

Peppercorn tingling and chilli heat produce distinct sensations. Modern mala cooking brings them together while preserving savour and aroma. Qiongqi closes its eyes to taste, waiting for both sensations to settle before inviting the ingredients in.

**Wind in the pot**

Food rises and sinks in the simmer as faces grow warm around the table. Qiongqi loves an enthusiastic response. A hesitant guest receives a small tasting spoon: the words remain blunt, the portion surprisingly considered.

**Say ma, then la**

A newcomer who knows only hot discovers another sensation to describe. Pins, a faint electric rustle, a dancing tongue: comparisons gather above the steam. Qiongqi supplies detailed commentary, helping the Chinese word acquire a physical memory.

### 梼杌秘制烤肉 · Táo wù mì zhì kǎo ròu

山猪肉腌入滋味，慢慢烤出焦边，咬开仍有肉汁。梼杌秘制烤肉借了那位倔伙伴的名字，每一口都像认真坚持过的一件小事。

**秘字藏在哪里**

“秘制”让人先想配方，真正尝到的却还有火候与等候。肉片吃进调味，边缘被炙得微卷，油香刚刚释放就收火。掌勺的厨师把一串细小判断连起来，才有这盘留得住余味的烤肉。

**招牌是谁的**

梼杌能为招牌上一个字较真半日，自然也要来盯自己的这盘菜。焦边少一点，它摇头；上桌慢半步，它皱眉。厨房里的人嫌它挑剔，盘子回得干干净净时，又都忍不住朝它看一眼。

**各家的那一口**

House special让远客想到自家街角的小店，“秘制”则让人想到掌柜藏着的那点手艺。两种说法在烤香里相遇，客人终于找到了译法，梼杌却更想知道：你最记得的是哪一口？

**Taowu's House Barbecue**

Marinated mountain pork gains crisp edges and a juicy centre. Taowu's House Barbecue carries the stubborn creature's name and an exacting standard for every bite.

**Where the secret lives**

A secret recipe suggests seasoning, but time and heat matter too. The marinade enters, edges curl, fragrance opens and the cook stops the fire. Small judgments linked together create the lasting impression of a house speciality.

**Whose sign is it?**

Taowu argues over signboard wording and takes this namesake dish just as seriously. Too little char earns a headshake; delayed serving earns a frown. The kitchen grumbles until an entirely clean plate comes back, and everybody glances its way.

**A house's particular flavour**

House special recalls a visitor's favourite corner restaurant. Mizhi, privately prepared, suggests a cook's cherished technique. Words meet through the grilled fragrance; Taowu still wants to know which bite the guest remembers most.

### 混沌云吞 · Hùn dùn yún tūn

薄面皮收拢肉馅，云吞在热汤里微微舒展。混沌云吞把一团未明的天地包成一口鲜香，勺子轻碰碗沿，故事也跟着浮了上来。

**一张皮的几种乡音**

馄饨、云吞、抄手，都是包馅面食家族里常遇见的名字，皮馅、汤底与吃法又随地方改变。有间这一碗让薄皮贴着馅，滑而有韧，汤把咸鲜轻轻托住，吃完仍想再捧一会儿碗。

**天地合拢的时候**

混沌最爱看面皮在手心合起，仿佛给还未分明的世界藏好一点东西。它包的褶子未必齐整，煮开以后倒各自舒展。白泽看着笑，随手把其中一只画在尚未写满的书页上。

**一口双关**

混沌hùndùn与馄饨húntun，声音挨得很近；英文wonton又把粤语云吞的声音带去了远方。读一遍名字，再尝一口，几种口音便围着同一只勺子相逢，笑意也有了能传过去的路。

**Hundun’s Cloud Wontons**

Thin wrappers gather savoury filling, then loosen gently in broth. Hundun's Cloud Wontons fold an unfinished little world into a warm spoonful.

**A wrapper with several accents**

Huntun, yuntun and chaoshou belong to a family of filled-wrapper foods with regional variations in skins, fillings and serving styles. This bowl favours supple thin wrappers, tender filling and broth that carries the savour lightly.

**When a world folds shut**

Hundun enjoys watching a wrapper close, as though an unformed world had found somewhere for a secret. The pleats vary; boiling lets each open in its own way. Baize sketches one in an unfinished notebook.

**A mouthful of wordplay**

Hùndùn and húntun sit close in sound. English wonton carries a Cantonese name further abroad. Say the words, then taste: different accents gather around one spoon, giving the joke a route across languages.

### 獬豸正义套餐 · Xiè zhì zhèng yì tào cān

主食、热菜与一盏汤饮相配，獬豸正义套餐端得平实而周全。每一份搭配都有照应，像那位独角伙伴把一桌人的需要逐项记在心里。

**一餐怎样合拢**

套餐替人先安排好几样滋味，热菜有浓淡，主食接住咸鲜，汤饮留一点清润。配在一起，吃到后面仍愿意动筷，才算照顾妥当。小馆把这份组合的分寸，交给一个郑重的名字。

**账单从点菜时开始**

獬豸总要把价钱、份量与答应的事先说明白。遇见争执，它再把来回经过慢慢问清。一餐之中这些细碎约定，就像盘里彼此照应的几样菜，少了一处，整桌便容易失了平衡。

**分得一样，顾得不同**

同桌有人食量小，有人有忌口，也有人头回看这份菜单。怎样分盛、怎样解释，常有不同办法。獬豸把独角微微低下，先听完每一个人；一份“正义”，也便在这样的桌边有了可尝的温度。

**Xiezhi's Fair Table Set**

Rice, hot dishes and a soup or drink form Xiezhi's Fair Table Set. Its modest balance recalls the one-horned companion who takes each guest's needs seriously.

**How a meal comes together**

A set arranges several flavours in advance. Rich and gentle dishes balance one another, rice receives their savour and a lighter sip leaves room to continue. The inn gives this practical attention a deliberately weighty name.

**The bill begins with the order**

Xiezhi clarifies price, portions and promises before service. If disagreement follows, it reconstructs the sequence carefully. Small agreements support a meal as each component supports the plate; one missing detail can disturb the whole arrangement.

**Different needs at one table**

Appetites, dietary requirements and familiarity with the menu vary. Serving and explanation therefore need different forms of care. Xiezhi lowers its horn and hears each person, giving fairness a tangible warmth beside supper.

### 烛龙火焰拉面 · Zhú lóng huǒ yàn lā miàn

丹木果为汤添一线明亮香气，面条挑起时裹着热汤。烛龙火焰拉面借昼夜之神的赤色光影，把夜食煮成一碗小小的日出。

**面条走过的路**

“拉面”在不同地方会唤起不同记忆：手工拉伸的面条，日本ramen的汤碗，各有面形、汤底与配菜。有间让面与丹木果香相遇，热汤从筷尖落回碗中，带出这一处厨房自己的回声。

**把夜色推开一点**

烛龙开眼为昼、闭眼为夜的旧事，被这道菜借成碗沿的火光。厨师慢慢候面，等筋道恰好才盛。深夜的人低头吃一口，先暖起来的是指尖，随后才是被热汽照亮的眼睛。

**菜单上的音节**

客人说起ramen，另一个人念起lāmiàn，便会谈到面条在各地怎样变了模样。烛龙不催他们说完，只把汤添热。一碗面沿着名字伸出几条路，最后仍把人带回此刻的香气。

**Zhulong's Flame Noodles**

Zhulong's Flame Noodles carry a bright note of imagined Danmu fruit through hot broth. The dragon of day and night lends its red light to a small midnight sunrise.

**Routes travelled by noodles**

Lamian may evoke hand-pulled strands; Japanese ramen calls up another range of broths and toppings. At Youjian, noodles meet Danmu fragrance. Drops fall from the lifted chopsticks, returning this kitchen's particular flavour to the bowl.

**Pushing night aside**

Zhulong's opening and closing eyes govern daylight in the old tale. Here, that light gathers at the rim. The chef waits for the strands to reach the right texture; a late guest's fingers warm before their eyes lift through the steam.

**Syllables on a menu**

Ramen and lāmiàn begin a conversation about changing forms of noodles. Zhulong quietly keeps the soup warm. Several paths extend from the names, then lead back to the fragrance at this table.

### 帝江无面饺子 · Dì jiāng wú miàn jiǎo zi

柔软面皮包住肉馅，圆润饺子挨在盘中，像一群刚停下舞步的小客。帝江无面饺子借无面目之神的名字，让寻常面食也带一点会动的趣味。

**案板旁的相聚**

饺子可以煮、蒸、煎，各地皮馅和形状又有许多做法。有间这一盘收成圆润的样子，肉馅鲜香，面皮仍留咬劲。包起一只再递给旁人，热饭往往在下锅以前，就已经开始把人聚拢。

**六只脚的节拍**

帝江无面目，却识歌舞；它把盘子端起时，六足各有轻轻的停顿。饺子沿盘摆出起落，仿佛下一拍便会跟着转身。客人还没拿稳筷子，先忍不住在桌下试着打了一回拍子。

**面字的小转身**

“面”在中文里可以牵出脸，也能牵出面粉与面食。“无面”给造型开了个小玩笑，盘里热热的面皮肉馅却十分踏实。把名字念给远客听，再在纸上画一张脸，笑声便跟着包进了这一口。

> 是識歌舞實惟帝江也
> ——《山海经》
> It knows song and dance: this is Dijiang.

识得歌舞的这位神，正是帝江。

**Dijiang’s Faceless Dumplings**

Soft wrappers hold savoury meat in rounded dumplings, arranged like little visitors resting between dance steps. Dijiang's Faceless Dumplings give a familiar meal a playful rhythm.

**Company around the board**

Dumplings may be boiled, steamed or fried, with many regional shapes and fillings. This plate favours round forms, tender meat and a little bite in the wrapper. Passing a newly folded dumpling already starts gathering people before the cooking begins.

**Six feet keeping time**

Faceless Dijiang knows song and dance. Its serving steps pause delicately, and the dumplings seem arranged to turn on the next beat. A guest tries the rhythm under the table before picking up the chopsticks.

**Mian turning a corner**

Chinese mian can suggest a face, or flour and flour-based foods. The name borrows the facial meaning; warm wrappers make the wordplay pleasantly tangible. A spoken name and a quickly drawn face help the joke reach another language.

### 九婴九味拼盘 · Jiǔ yīng jiǔ wèi pīn pán

炙烤的焦香、软嫩的热肉与几样清爽配菜铺在一盘。九婴九味拼盘让不同火候各显身手，夹起一口，下一口又有新的起伏。

**九字把桌子撑大**

“九”在中文里常带丰盛、长久的意味，一入菜名，就像先替餐桌多请了几位客人。盘中浓淡、软脆与冷热的衬托，才是让人不断伸筷的缘由；丰富的滋味，也得彼此留出一点说话的地方。

**几口灶同时醒来**

九婴顾这边的火，又试那边的汤，几个脑袋争过一轮才肯定下次序。传菜口有人接应，盘里才终于拼出一场热闹。那份多首水火之怪的旧名，到灶边成了一种忙得分不开身的本领。

**你先挑一口**

同桌爱吃的各不相同，拼盘便适合用来交换推荐。有人指脆的，有人挑软的，有人把刚学会的中文味觉词再念一遍。九婴在旁听着，几个脑袋竟也各自赞成了不同的答案。

**Jiuying’s Nine-Flavour Platter**

Roasted fragrance, tender meat and fresh accompaniments fill Jiuying's Nine-Flavour Platter. Different textures answer one another, leaving each next bite something new to say.

**Nine enlarges the table**

In Chinese, nine can suggest abundance and endurance. In this dish's name, it seems to invite extra company. Richness and freshness, softness and crispness provide the actual pleasure, each given space beside the others.

**Several stoves awake**

Jiuying checks one flame and tastes another pot. Its heads argue before agreeing on the serving order. Help at the hatch turns the old water-and-fire creature's many-headed force into a recognisably busy kitchen skill.

**Choose your first bite**

Preferences differ around the table, making the platter an invitation to recommend. Guests point to crisp or tender pieces and try newly learned Chinese flavour words. Jiuying listens, with different heads unexpectedly favouring different answers.

### 白泽万象宴 · Bái zé wàn xiàng yàn

祝余的清气与几样家常食材汇成一席，白泽万象宴藏在伙伴们共同走过的日子里。菜陆续上桌，每一道都像翻开一页有人落过笔的书。

**饮食之间有礼**

《礼记》说礼之初始诸饮食，待客、分食与让座，原来很早就在一席饭里相遇。白泽安排的万象宴循着这份心意：有清口的绿意，也有热食的饱足，先后相衬，留给人从容动筷的工夫。

**这一味是谁教的**

白泽报菜时会念伙伴的名字：有人试过火候，有人认得草木，有人把远来的做法带进厨房。它的博识在这一席里有了许多出处，平日写在页边的小问题，也渐渐煮成可以分享的答案。

**把你的故事也端来**

来客若认出故乡滋味，白泽便请人多说几句；遇到陌生名字，也留足问话的空隙。宴席像一本摊开的书，新来的人可以坐下，添上一段自己的山川，再与满桌烟火一起慢慢读完。

> 夫礼之初，始诸饮食。
> ——《礼记正义》
> At the beginning of ritual, there was food and drink.

礼最初的来处，便在饮食之间。

**Baize’s Banquet of Many Wonders**

Baize's hidden banquet gathers Zhuyu freshness and everyday ingredients into a sequence shaped by the companions' shared experience. Each arriving dish turns another remembered page.

**Ritual at supper**

The Book of Rites locates ritual's beginnings in food and drink. Welcoming, dividing portions and offering a seat have long met around meals. Baize arranges freshness and warmth with time between courses, leaving room for both appetite and conversation.

**Who taught this flavour?**

The mentor names the companions who tested the heat, recognised a plant or brought a distant method into the kitchen. Knowledge acquires many contributors. Questions once kept in notebook margins become answers that can be passed around.

**Bring your story too**

A familiar flavour invites a guest's memory; an unfamiliar name leaves space for a question. The banquet resembles an open book. New arrivals can sit down, add their own landscape and read on through the shared meal.

### 凤凰涅槃羹·真 · Fèng huáng niè pán gēng · zhēn

丹木果的香、山海鱼的鲜与稀有食材合进一盏细羹。凤凰涅槃羹·真沿着旧日招牌再添一层滋味，也记下一场终于等到的重逢。

**这一盏多出的余味**

果香先轻轻浮起，鱼鲜随后托住绵润，收火时再把余味留得悠长。同样一只勺子，今日盛起的滋味却比记忆更清楚。厨师尝完停了一会儿，才把最后一点汤沿擦净。

**灯还替你留着**

这碗羹与凤凰的安宁之愿相连，也收着小馆里重新振作的那点火光。久别的人推门，熟悉的座位还在；伙伴把热碗递来时，一句等候许久的话，忽然可以说得很轻。

**真字落到心上**

“真”既能讲真实，也能讲真心。远客问菜单里为何多了这一字，凤凰便把碗往灯下移近一点。吃过同一道菜的两个人，各自记得不同的日子，却可能在这一口里，终于找到彼此说话的开头。

**Fenghuang's Renewal Broth: A Shared Promise**

Danmu fragrance, mountain-and-sea fish and rare ingredients deepen a familiar bowl. Fenghuang's Renewal Broth: A Shared Promise marks a reunion finally welcomed home.

**The added aftertaste**

Fruit fragrance arrives lightly, followed by fish savour and a smooth finish. The same spoon now carries a more distinct memory. After tasting, the cook pauses before wiping the final trace from the rim.

**A lamp kept for you**

Fenghuang's old wish for peace meets the inn's renewed fire. Someone long absent opens the door; the familiar seat remains. Passing a warm bowl makes a sentence held for many days suddenly easy to say.

**The weight of zhen**

Zhen carries truth and sincerity. Asked about the added character, Fenghuang moves the bowl into the light. Two guests may remember different days through the same dish, yet find in this mouthful a beginning for their conversation.

## 来客小传

### 饕客·老饕 · Lǎo tāo

老饕是一位隐居的食评人，进门便点最贵的一道菜。衣襟朴素，问起火候却毫不含糊，第一筷落下以前，总先把整盘看一遍。

**饕字换了语气**

饕餮的名字带着食欲的锋芒，“老饕”却能在中文里亲切地称呼懂吃的人。饮食文章写这类食客，常把山珍与家常并列：见识过许多丰盛，仍愿意为眼前一口准确的滋味停住。

**最贵的一道**

他点高价菜时神色平常，吃过以后才问食材、做法与掌勺的人。赞也具体，嫌也具体。厨房最盼听见的，往往是他夹完第二筷以后那句低低的：“这一处，你们花过心思。”

**把滋味说给别人**

有人用香、鲜、醇回味一盘菜，有人说起故乡的另一种味道。老饕爱听这些各不相同的说法，偶尔把一个陌生词记在纸背。一份食评写到最后，桌上的几种声音也都跟着留下来。

**Laotao, the Seasoned Diner**

The Old Gourmand is a reclusive food critic who orders the most expensive dish. Simply dressed and exacting about heat, he studies the plate before taking a bite.

**An appetite changes tone**

The word lao tao turns a name associated with devouring into an affectionate Chinese expression for an experienced food lover. Food writing gives such diners room for both rare delicacies and familiar meals, each worth judging by its particular taste.

**The highest-priced dish**

His order arrives without ceremony. Afterwards come questions about ingredients, technique and the cook. Praise and criticism are equally specific. The kitchen especially values the quiet observation after a second bite: someone took care over this detail.

**Words for flavour**

Guests offer fragrance, savour and memories of other dishes. The Gourmand listens, occasionally noting an unfamiliar word on the back of a page. Several voices accompany the plate into its eventual review.

### 白泽的故人 · Báizé de gùrén

白泽的故人带着旧日风尘来，点一杯茶饮，坐下便问导师近来可好。几句寒暄，常能把无所不知的白泽问得忽然笑出声。

**一盏饮的工夫**

茶、汤饮与清水，在不同地方都能成为留客的开头。杯子落定，赶路的气息才渐渐缓下。故人推开案边的书，替自己留出一处杯位，像从前无数次来访那样熟悉。

**它也曾答不上来**

新伙伴眼里的白泽总有办法，故人偏记得它当年认错草木、追着人问名字的模样。白泽想拦，茶香已经带着旧事飘过半桌。听见导师也有过窘迫，伙计们反而更敢把问题拿出来。

**把旧话讲给新朋友**

说到只有两个人懂的称呼，故人会停一停，把来由讲给同桌听。另一个人也接着说起自己的老师。原本属于一段旧交的笑声，就沿着这杯饮，慢慢多出了几个新的名字。

**An Old Friend of Baize**

Baize's old friend arrives dusty from travel, orders a drink and asks after the mentor. A few familiar questions can make the all-knowing teacher suddenly laugh.

**Time measured by a cup**

Tea, broth and water begin hospitality in different places. Once a cup rests on the table, the pace of travel eases. The visitor moves a book aside with the practised familiarity of many earlier calls.

**A question once unanswered**

The staff imagine Baize always knowing what to do. This friend remembers mistaken plants and hurried questions about names. Baize tries to intervene; the story has already drifted across the table. The learners become braver about asking.

**Old words, new company**

At a private nickname, the friend pauses to explain. Another guest recalls a teacher of their own. Laughter belonging to an old friendship gradually gathers new names around the same drink.

### 小神兽 · Xiǎo shénshòu

小神兽独自摸进门，毛上还挂着外面的凉气，只敢点一份基础饭食。它努力坐得端正，眼睛却总往每一次开门的方向望去。

**名字还没问出来**

山海故事为许多异兽留下形貌与名字，眼前这个小小来客却暂时说不清自己是谁。耳、角与爪尖缩在桌边，像一幅尚未添题的画；先递到它面前的，是一碗冒着热气的饭。

**它吃得很认真**

第一口小，第二口仍小，等发现旁人没有催促，筷子才慢慢快起来。青耕添水，天狗留意门外，白泽把纸推近一些。幼崽终于肯在上面画一段弯弯的路，末尾是一处小小屋檐。

**画出来的归途**

旅人认路有地名，也有桥、树与灯火。几个人围着那幅图，各用自己的词指认，幼崽一边听一边点头。门外的街依旧陌生，桌上的那条路，却开始一点点接近它记忆中的家。

**The Lost Little Beast**

A small lost creature enters alone, carrying the chill of outside in its fur. It orders a basic meal and watches every opening of the door.

**A name still missing**

Mountain-and-sea stories name countless extraordinary beings. This young visitor cannot yet explain itself. Ears, horn and tiny claws fold beside the table like an untitled drawing. A steaming bowl reaches it before the first successful answer.

**Eating very carefully**

The first bites are small. With nobody hurrying it, the chopsticks gradually quicken. Qinggeng pours water, Tiangou watches the street and Baize offers paper. The cub finally draws a winding path ending beneath a little roof.

**A route drawn home**

People recognise routes through names, bridges, trees and lights. Several guests offer words for the picture; the cub listens and nods. The street remains unfamiliar, but the path on the table begins to resemble a remembered home.

### 挑剔的美食家 · Tiāoti de měishíjiā

这位美食博主会连尝三道菜，笔记比筷子动得还勤。称赞时不肯只写“好吃”，挑错时也要把究竟差在哪里问个明白。

**把一口写成几行**

食评要把舌尖的事讲给没来过的人：脆落在哪里，香何时升起，等候又怎样改变第一口心情。古代饮食随笔到今日屏幕上的文章，都曾面对这道难题，写得越具体，读者越能循着字来到桌边。

**第三道再下结论**

第一盘吃完，常把刚写的一句划去，等第二、第三道来回答。厨师看见笔尖就紧张，白泽却愿意把做法讲完。两人讨论到末尾，一份评价有时会留下两种暂未合拢的意见。

**让本味留下名字**

《随园食单》说物有本性，做菜要认得它原来的性情。写给远方读者，也得把地方风味与自己的口味说清。博主记下陌生菜名，旁边补一句怎样吃；读者隔着屏幕，终于能想象那一口。

> 物有本性，不可穿凿为之。
> ——《随园食单》
> Things have their own nature; do not force them into something else.

食材各有自己的性情，烹调要顺着它的本味。

**The Exacting Food Writer**

This demanding food blogger tastes three dishes and writes almost as quickly as they eat. Praise needs detail; criticism needs an identifiable reason.

**Turning taste into lines**

A review must carry crispness, rising fragrance and the effect of waiting toward readers absent from the meal. Chinese food essays and contemporary screens share that task. Concrete words give those readers a route to the table, one imagined sensation at a time.

**Wait for the third dish**

After the first plate, they often cross out a sentence and let the next two answer it. Cooks grow nervous at the pen; Baize explains the method. A review can end with two thoughtful opinions still short of agreement.

**Keeping a flavour's name**

The Suiyuan Shidan asks cooks to attend to an ingredient's nature. Writing across cultures likewise requires care with local flavour and personal preference. The blogger records an unfamiliar dish name and how to eat it, giving distant readers something precise to imagine.

### 报恩的妖怪 · Bào’ēn de yāoguài

报恩的妖怪又坐回了旧日来过的桌旁，神色比从前轻松许多。它点菜时多问几句伙伴的近况，临走却总把谢礼留得悄无声息。

**民间故事的回声**

受过帮助的鸟兽回来报恩，是中国民间叙事里亲切的一条线。人与异类的相遇，因为记得而变得绵长。礼物有时珍奇，有时寻常，故事真正舍不得略去的，是多年以后仍有人认得那份好意。

**这一桌还在**

它记得从前递水的人，也记得自己第一次推门时的窘迫。如今轮到它把话说得自在，问厨房忙不忙，问掌柜有没有歇过。等盘子收净，桌上多了一份心意，人却已经走到街角。

**道谢的几种模样**

有人当面鞠躬，有人写信，有人隔很久带着礼物回来。旅人讲起故乡相似的报恩故事，桌边便添出不同动物与不同山林。那位妖怪留下的座位，忽然像许多地方都曾有过的一处旧识。

**The Grateful Visitor**

The Grateful Monster returns to its former table, noticeably more at ease. It asks after the staff and leaves its gift so quietly that the street nearly takes it away first.

**An answering kindness**

Chinese folk narratives often bring a helped bird or animal back in gratitude. Remembering lengthens an encounter between human and otherworldly lives. Gifts may be rare or ordinary; the story lingers over somebody still recognising a kindness after time has passed.

**The table remains**

The visitor remembers who poured water and its own awkward first arrival. Now questions come easily: is the kitchen busy, has the proprietor rested? After the dishes are cleared, a token remains and the guest has reached the corner.

**Ways of saying thanks**

A bow, a letter, a gift brought much later: travellers recognise several forms. Similar tales from home introduce other animals and forests. The empty seat begins to resemble an old acquaintance in many places.

### 昆仑集团密探 · Kūnlún jítuán mìtàn

昆仑集团的密探扮作食客进门，问起供货与经营时比问菜味更仔细。杯中茶已经凉了，那双眼睛还在记门口来往的人。

**古老山名的新招牌**

昆仑在中国神话里是天帝下都，也是引人向往的高远山岳。故事里的集团借来这份气势，把旧山名挂到现代商号上。云中的神圣与街上的竞争并在一起，让一个熟悉的名字忽然多了锋利的边。

**多问的那一句**

普通客人看菜单，它却留意谁送货、谁记账，连传菜口的忙闲也要问清。獬豸把账单递过去，顺势问一句缘由。密探接杯的手慢了半拍，茶面那点细小的晃动，竟比回答更早露了声色。

**名字之后，看见一个人**

听出对方来自哪里还不够，伙计们要把那些不寻常的问话一一对上经过。餐桌仍照常招待，重要的约定也照常守住。一个外来的名字在灯下展开，真正要读懂的，终究是坐在名字后面的人。

**The Visitor from Kunlun Group**

Kunlun's spy enters disguised as a diner, asking more carefully about deliveries than about flavour. The tea cools while the visitor continues watching the door.

**An old mountain on a new sign**

Kunlun is a lofty sacred place and the celestial ruler's earthly capital in Chinese mythology. The fictional corporation borrows that imposing name for modern commerce. Clouded heights and street-level competition give familiar characters an unexpectedly sharp edge.

**The extra question**

Other diners study the menu. This guest studies suppliers, accounts and the rhythm at the serving hatch. Xiezhi offers the bill and asks why. The hand receiving the cup hesitates; a slight movement of tea answers before the words.

**A person behind the name**

The staff compare unusual questions with what has actually happened. Hospitality continues, alongside attention to important agreements. Beneath the lamp, the borrowed mountain name opens into another story, whose meaning rests in the person sitting behind it.
