@echo off
cd /d "%~dp0"
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 prepare-site.py --launch
  goto done
)
python --version >nul 2>&1
if not errorlevel 1 (
  python prepare-site.py --launch
  goto done
)
echo Python 3 is required for this local web server.
:done
pause
