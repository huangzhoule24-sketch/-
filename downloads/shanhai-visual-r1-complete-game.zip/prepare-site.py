#!/usr/bin/env python3
"""Restore all bundled static resources, or back up and update an existing site."""
import argparse
import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def _atomic(source,destination):
    destination.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.shanhai-',dir=destination.parent);os.close(fd)
    try:shutil.copyfile(source,name);os.replace(name,destination)
    finally:Path(name).unlink(missing_ok=True)

def _json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def materialize(package):
    metadata=json.loads((package/'PACKAGE.json').read_text())
    for name,e in metadata['files'].items():
        path=package/name
        if not path.is_file()or path.stat().st_size!=e['bytes']or digest(path)!=e['sha256']:raise ValueError('Package integrity failed: '+name)
    site=package/'site';mapping=json.loads((site/'game/resource-map.json').read_text())
    for resource in mapping['resources'].values():
        encoded=b''.join((site/'game'/p['path']).read_bytes()for p in resource['gzip'])
        decoded=gzip.decompress(encoded)
        if len(decoded)!=resource['bytes']or hashlib.sha256(decoded).hexdigest()!=resource['sha256']:raise ValueError('Bundled resource reconstruction failed')
        offset=0
        for part in resource['raw']:
            data=decoded[offset:offset+part['bytes']];offset+=part['bytes']
            if hashlib.sha256(data).hexdigest()!=part['sha256']:raise ValueError('Reconstructed part hash differs: '+part['path'])
            target=site/'game'/part['path'];target.parent.mkdir(parents=True,exist_ok=True)
            if not target.is_file()or digest(target)!=part['sha256']:target.write_bytes(data)
        if offset!=len(decoded):raise ValueError('Raw part sizes do not cover the resource')
    verify_game(site/'game')
    return site,metadata

def verify_game(game):
    mapping=json.loads((game/'resource-map.json').read_text())
    for resource in mapping['resources'].values():
        for encoding in['raw','gzip']:
            for part in resource[encoding]:
                path=game/part['path']
                if not path.is_file()or path.stat().st_size!=part['bytes']or digest(path)!=part['sha256']:raise ValueError('Game part differs: '+part['path'])

def apply(package,root,backup):
    site,metadata=materialize(package)
    root=root.resolve();backup=backup.resolve()
    if root==backup or root in backup.parents:raise ValueError('Put the backup outside the public website directory')
    combined=(root/'portrait/game/export-receipt.json').is_file()
    bases=[root,root/'portrait']if combined else[root]
    for base in bases:
        receipt=base/'game/export-receipt.json'
        if not receipt.is_file()or json.loads(receipt.read_text()).get('game_source',{}).get('sha256')not in metadata['accepted_sources']:raise ValueError('Unrecognised game build: preserve this project and inspect its version first')
    plan={};remove=[]
    for base in bases:
        prefix=base.relative_to(root)
        for p in(site/'game').rglob('*'):
            if p.is_file():plan[(prefix/'game'/p.relative_to(site/'game')).as_posix()]=p
        if combined:
            variant='mobile'if base!=root else'desktop'
            plan[(prefix/'game/index.html').as_posix()]=package/'routing'/(variant+'-game.html')
        expected={p.name for p in(site/'game/parts').glob('*.bin')}
        for p in(base/'game/parts').glob('*.bin'):
            if re.fullmatch(r'index\.(wasm|pck)\.(raw|gzip)\.\d+\.bin',p.name)and p.name not in expected:remove.append(p.relative_to(root).as_posix())
    # Update known stock entry pages; preserve WorkBuddy custom introductions.
    for name,e in metadata.get('entry_updates',{}).items():
        if not combined and name.startswith('portrait/'):continue
        if not combined and name=='device-router.js':continue
        target=root/name
        if not target.exists()or digest(target)in e['known_hashes']:plan[name]=(package/e['source'])if combined else(site/name)
    for base in bases:
        plan[(base.relative_to(root)/'site-receipt.json').as_posix()]=site/'site-receipt.json'
    touched=set(plan)|set(remove)
    backup.mkdir(parents=True,exist_ok=False)
    existed=set()
    for name in touched:
        path=root/name
        if path.is_file():
            existed.add(name);p=backup/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,p)
    try:
        for name,p in plan.items():_atomic(p,root/name)
        for name in remove:(root/name).unlink()
        for base in bases:
            verify_game(base/'game')
            receipt_path=base/'game/export-receipt.json';receipt=json.loads(receipt_path.read_text());entry=base/'game/index.html'
            receipt['files']['index.html']={'bytes':entry.stat().st_size,'sha256':digest(entry)}
            if combined:receipt['entry_router']={'version':metadata['revision'],'variant':'desktop'if base==root else'mobile'}
            _json(receipt_path,receipt)
            manifest=json.loads((site/'site-receipt.json').read_text())
            for name in list(manifest['files']):
                actual=base/name
                if actual.is_file():manifest['files'][name]={'bytes':actual.stat().st_size,'sha256':digest(actual)}
                else:del manifest['files'][name]
            _json(base/'site-receipt.json',manifest)
    except Exception:
        for name in touched:
            target=root/name
            if name in existed:_atomic(backup/name,target)
            else:target.unlink(missing_ok=True)
        raise
    report={'version':metadata['version'],'layout':'combined'if combined else'standalone','files_written':len(plan),'obsolete_parts_removed':len(remove),'backup':str(backup),'all_resource_parts_verified':True,'published':False}
    _json(backup/'UPDATE-REPORT.json',report)
    return report

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--site-root',type=Path,help='Existing website to back up and update')
    parser.add_argument('--backup-dir',type=Path)
    parser.add_argument('--launch',action='store_true',help='Prepare the bundled site and start its local web server')
    args=parser.parse_args();package=Path(__file__).resolve().parent
    if args.site_root:
        root=args.site_root.resolve();backup=args.backup_dir or root.parent/('shanhai-before-international-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
        print(json.dumps(apply(package,root,backup),ensure_ascii=False,indent=2));return
    site,meta=materialize(package);print('Ready: '+str(site)+' · '+meta['version'])
    if args.launch:subprocess.run([sys.executable,str(site/'serve.py'),'--directory',str(site),'--open-browser'],check=True)

if __name__=='__main__':main()
