extends RefCounted
## An uncommitted, paused layout transaction. No clock/RNG/scheduler rollback.
const Space = preload("res://scripts/services/restaurant_space.gd")
var model
var builder_id = ""
var last_error = ""
var active = false
var original: Dictionary = {}
var history: Array[Dictionary] = []
func _init(game_model) -> void: model = game_model
func begin() -> void:
	if active: return
	active = true
	original = model.state.duplicate(true)
	history.clear()
	model.set_paused(true)
func can_move(index: int,x: int,y: int) -> bool:
	var layout: Array = model.state.get("layout",[])
	if index < 0 or index >= layout.size(): return false
	var item: Dictionary = layout[index]
	if bool(item.get("building",false)): return false
	if model.state.has("revision191") and model.full_rules.dollhouse.locked(model.full_rules.dollhouse.identity(item)):return false
	var dims = Space.grid_dimensions(model)
	var proposed = Rect2i(x,y,int(item.w),int(item.h))
	if x < 0 or y < 0 or proposed.end.x > dims.x or proposed.end.y > dims.y: return false
	for other in range(layout.size()):
		if other == index: continue
		var entry: Dictionary = layout[other]
		if proposed.intersects(Rect2i(entry.x,entry.y,entry.w,entry.h)): return false
	var cursor = 0
	for entry in layout:
		var capacity = 0 if bool(entry.get("building",false)) else 4 if str(entry.id) == "table_four" else 2 if str(entry.id) == "table_two" else 0
		if entry == item:
			for guest in model.customers:
				if int(guest.seat) >= cursor and int(guest.seat) < cursor+capacity: return false
		cursor += capacity
	var candidate = layout.duplicate(true)
	candidate[index].x = x
	candidate[index].y = y
	return Space.layout_is_safe(model,candidate)
func move_item(index: int,x: int,y: int) -> bool:
	if not active or not can_move(index,x,y): return false
	if int(model.state.layout[index].x) == x and int(model.state.layout[index].y) == y: return false
	history.append(model.state.duplicate(true))
	model.state.layout[index].x = x
	model.state.layout[index].y = y
	model.changed.emit()
	return true
func purchase(id: String,x: int,y: int) -> bool:
	if not active or (str(model.state.mode) == "full" and int(model.state.stage) < 1): return false
	var before = model.state.duplicate(true)
	if str(model.state.mode)=="full":
		var result: Dictionary=model.full_rules.revision.book_build(id,x,y,builder_id)
		last_error=str(result.get("reason",""))
		if not result.ok:return false
	else:
		if not model.buy_decoration(id,x,y): return false
	history.append(before)
	return true
func undo() -> bool:
	if not active or history.is_empty(): return false
	model.state = history.pop_back().duplicate(true)
	model.changed.emit()
	return true
func finish(keep: bool) -> bool:
	if not active: return false
	var purchased = keep and int(model.state.get("decorations_purchased",0)) > int(original.get("decorations_purchased",0))
	if str(model.state.mode)=="full": purchased=keep and model.state.revision171.builds.size()>original.revision171.builds.size()
	if not keep: model.state = original.duplicate(true)
	elif str(model.state.mode)=="full": model.full_rules.revision.activate_builds()
	active = false
	history.clear()
	original.clear()
	model.changed.emit()
	return purchased
