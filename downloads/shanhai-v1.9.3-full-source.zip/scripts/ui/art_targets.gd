extends RefCounted
const EMPLOYEE_ACTIONS=["walk","idle","order","cook","serve","clean","cashier","promote","rest"]
const DIRECTIONS=["down","up","left","right"]
const GUEST_IDS={"old_gourmand":"lao_tao","baize_friend":"bai_ze_gu_ren","lost_cub":"xiao_shen_shou","picky_blogger":"tiao_ti_mei_shi_jia","grateful_monster":"bao_en_yao_guai","kunlun_spy":"mi_tan"}
static func slots(model) -> Array:
	var result: Array=[]
	for employee in model.catalog:
		result.append({"name":"立绘 · "+str(employee.name),"path":"Portraits/"+str(employee.id)+".png"})
		result.append({"name":"引导立绘 · "+str(employee.name),"path":"Portraits/tutorial_"+str(employee.id)+".png"})
		for action in EMPLOYEE_ACTIONS:
			for direction in DIRECTIONS:result.append({"name":"小人 · %s · %s · %s" % [employee.name,action,direction],"path":"Sprites/%s/%s_%s_0.png" % [employee.id,action,direction]})
	var dishes=model.dishes.duplicate()
	var hidden=[model.full_rules.management.config.get("hidden_recipe",{})]+model.full_rules.sidequests.config.get("hidden_recipes",[])
	for entry in hidden:
		if not entry.is_empty() and not dishes.any(func(d):return str(d.id)==str(entry.id)):dishes.append(entry)
	for entry in dishes:result.append({"name":"菜品图标 · "+str(entry.name),"path":"Items/dish_"+str(entry.id)+".png"})
	for entry in model.decorations:
		result.append({"name":"俯视设施 · "+str(entry.name),"path":"Map/"+("equip_" if str(entry.get("device_type","")) in ["stove","pass","cashier","table","upgrade"] else "decor_")+str(entry.id)+".png"})
	for entry in [["木地板","Map/floor_wood.png"],["店墙","Map/wall_shop.png"],["庭院","Map/floor_yard.png"],["店招","Map/decor_sign.png"],["绿植","Map/decor_plant.png"],["员工面板","UI/panel_employee.png"],["照片框","UI/frame_portrait.png"],["状态警示","FX/icon_warning.png"]]:result.append({"name":str(entry[0]),"path":str(entry[1])})
	for type in ["human","demon","beastkin"]:
		for number in range(1,4):
			var appearance="%s_%02d" % [type,number]
			for action in ["walk","idle","sit","eat"]:
				for direction in DIRECTIONS:result.append({"name":"顾客 · %s · %s · %s" % [appearance,action,direction],"path":"Sprites/customer/%s/%s/%s_%s_%s_0.png" % [type,appearance,appearance,action,direction]})
	for guest_id in GUEST_IDS:
		var id=str(GUEST_IDS[guest_id]);result.append({"name":"特殊来客立绘 · "+id,"path":"Portraits/"+id+".png"})
		for action in ["walk","idle","sit","eat"]:
			for direction in DIRECTIONS:result.append({"name":"特殊来客 · %s · %s · %s" % [id,action,direction],"path":"Sprites/customer/%s/%s_%s_%s_0.png" % [id,id,action,direction]})
	for id in ["special_guest","training","construction","rest","fatigue","working"]:result.append({"name":"状态图标 · "+id,"path":"FX/icon_"+id+".png"})
	for item in ["skill_book","generic","tea","spice","fruit","rice","qingqiu_milk","yushan_water","danshu_rice","spirit_herb"]:result.append({"name":"道具 · "+item,"path":"Items/item_"+item+".png"})
	return result
