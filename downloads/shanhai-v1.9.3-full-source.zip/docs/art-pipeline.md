当前规范：v1.9.3新增六类资源、四方向小人、员工立绘和教学立绘；旧四目录兼容保留。新素材优先参考[美术资源清单](山海食肆物语-美术资源清单.md)和[逐项CSV](art-resource-list-v1.9.3.csv)。下文旧ID示例作为兼容约定，不要求重命名已有图片。

# 美术接入与替换说明

这套工程继续使用 Godot 4.6.3。策划 v1.3 的 Unity Animator / Resources.Load 等名称在本工程中分别对应员工动作状态、帧序列绘制和统一 `AssetCatalog` 服务，不需要迁移到 Unity。没有正式图片时使用现有程序绘制的餐厅、角色与图标，服务本身也提供中性占位纹理。

## 一、目录与加载顺序

| 用途 | 路径 | 生效方式 |
| --- | --- | --- |
| 随游戏发布的内置图片 | `res://assets/art/`，源码目录 `assets/art/` | 放入图片后通过 Godot 导入，重新导出游戏 |
| 编辑器 / 开发运行时覆盖 | `res://CustomAssets/`，源码目录 `CustomAssets/` | 启动时读取；开发者模式支持热重载 |
| 桌面导出版覆盖 | 可执行文件同级 `CustomAssets/` | 无需修改 PCK；放入图片后重新载入或开启热重载 |
| 网页版运行时覆盖 | `user://CustomAssets/` | 使用浏览器文件选择导入；不能直接扫描玩家电脑目录 |
| 默认稀有度视觉配置 | `config/rarity.json` | 修改后调用 `RarityDisplay.reload_config()` 或重启 |
| 动作与属性参数 | `config/animation.json` | 由场景与模型读取，不需要烘焙到图片中 |

同一资源 ID 的顺序是：**有效的自定义图片 → 有效的内置图片 → 中性占位纹理**。覆盖图片损坏时继续尝试内置图片。餐厅场景在没有真实图片时保留矢量绘制，因此暂时不导入美术仍能运行。

桌面导出时，应将 `CustomAssets/` 模板复制到可执行文件旁；它不需要打入 PCK。工程中 `CustomAssets/.gdignore` 阻止 Godot 将用户覆盖文件当作内置美术导入，模板目录允许为空。内置图片放在 `assets/art/`，不要把正式内置图片放进被 `.gdignore` 忽略的模板目录。导出配置应包含 `assets/art/manifest.json` 和 `config/*.json`。

## 二、资源 ID 和文件名

统一资源 ID 是 `分类/名称`，不带扩展名。仅接受以下四个分类；目录大小写必须一致。文件名使用英文字母、数字、下划线或短横线，推荐全部小写。不得使用空格、中文文件名、子目录、绝对路径或 `..`。

| 图片用途 | 调用 ID | 文件示例 |
| --- | --- | --- |
| 通用餐厅背景 | `Backgrounds/restaurant` | `Backgrounds/restaurant.png` |
| 阶段背景（优先于通用背景） | `Backgrounds/restaurant_stage_1` | `Backgrounds/restaurant_stage_1.png` |
| 羬羊待机单图 | `Characters/qianyang_idle` | `Characters/qianyang_idle.png` |
| 羬羊待机第 0 帧 | `Characters/qianyang_idle_0` | `Characters/qianyang_idle_0.png` |
| 羬羊做菜第 1 帧 | `Characters/qianyang_cook_1` | `Characters/qianyang_cook_1.png` |
| 阳春面菜品图标 | `Dishes/noodles` | `Dishes/noodles.png` |
| 员工导航图标 | `UI/btn_employee` | `UI/btn_employee.png` |
| 双人桌 | `UI/decor_table_two` | `UI/decor_table_two.png` |
| 收银台 | `UI/decor_cashier` | `UI/decor_cashier.png` |
| SSR 徽章图标 | `UI/rarity_ssr` | `UI/rarity_ssr.png` |

员工 ID 以 `config/employees.json` 的 `id` 为准，例如 `qianyang`（羬羊）、`owl`（鸮）、`earmouse`（耳鼠）、`bifang`（毕方）、`nine_tailed_fox`（九尾狐）。不能用显示名称或另编的神兽 ID 替代。菜品 ID 以 `config/dishes.json` 为准，例如 `noodles`、`fried_rice`、`plum_juice`。装饰 ID 以 `config/decorations.json` 为准，场景调用时增加 `UI/decor_` 前缀。

导航图标约定使用 `UI/btn_employee`、`UI/btn_encyclopedia`、`UI/btn_system`、`UI/btn_decoration`、`UI/btn_research`、`UI/btn_more`；新界面需要增加图标时采用同样方式向 `AssetCatalog` 取图。正式资源交付时应逐一确认调用点，加入图片文件本身不会创建新按钮或新玩法。

建议背景 1920 × 1080；角色单帧 64 × 64 或 128 × 128，所有帧画布大小和脚底锚点一致；UI 图标至少 64 × 64。PNG 支持透明；JPG/JPEG 适合不透明背景。导入接口单文件上限 32 MiB、边长上限 8192、总像素上限 32 × 1024 × 1024。GIF、SVG、Godot `.tres`、`.res`、`.gd` 等文件不会作为外置美术加载。

## 三、动画帧与覆盖

员工动画命名：`角色ID_状态_帧号.png`。状态支持 `idle`、`move`、`cook`、`serve`、`clean`、`cashier`、`promote`，休息扩展使用 `rest`。服务接口接受大写开头的状态，会统一转为小写。帧号为不补零的十进制非负整数：`0`、`1`、`2`、`10`，按数字排序。

示例：先在内置目录放入 `qianyang_idle_0.png`、`qianyang_idle_1.png`、`qianyang_idle_2.png`，再在自定义目录只放 `qianyang_idle_1.png`。运行时第 1 帧采用自定义图片，第 0、2 帧保留内置图片。自定义 `qianyang_idle.png` 只替换第 0 帧；如果同时存在自定义 `_0.png`，编号第 0 帧优先。没有内置动画而只有一张自定义图时，返回一帧，移动和工作反馈仍由程序完成。

在图片上不要画死稀有度徽章、角色名字和动作进度。朝向由渲染层翻转，移动与工作速度由属性及 `config/animation.json` 控制。这样后续训练、岗位变化和数值调整不需要重做图片。

## 四、统一服务 API

实现位置：`scripts/services/asset_catalog.gd`，类型为 `RefCounted`。业务和 UI 不直接从外置目录 `ResourceLoader.load()` 图片，更不能加载外置脚本。外置 PNG/JPG 被读取为字节并解码为像素。

```gdscript
const AssetService = preload("res://scripts/services/asset_catalog.gd")
var assets = AssetService.new()

# 所有缺图调用均有安全回退，get_texture 不返回 null。
var picture: Texture2D = assets.get_texture("Dishes/noodles")
var frames: Array[Texture2D] = assets.get_frames("qianyang", "Cook")

# 保留程序绘图时，先判断是否存在真正可用的图像。
if assets.has_frames("qianyang", "Cook"):
    frames = assets.get_frames("qianyang", "Cook")
if assets.has_image("Backgrounds/restaurant"):
    picture = assets.get_texture("Backgrounds/restaurant")

# UI 将返回的图片赋给 TextureRect.texture，或在场景中 draw_texture_rect。
# changed 信号后刷新已经显示的 TextureRect / 重画场景。
assets.changed.connect(queue_redraw)
assets.developer_mode = true

func _process(delta: float) -> void:
    assets.poll(delta)
```

| 方法 / 属性 | 返回或用途 |
| --- | --- |
| `get_texture(resource_id: String)` | `Texture2D`，可为占位纹理 |
| `culture_resource_id(kind: String, entry_id: String)` | 文化专图固定资源 ID；支持 `employees` / `dishes`（兼容单数）；无效类别或 ID 返回空字符串 |
| `culture_texture(kind: String, entry_id: String)` | 简介专图 → 已有肖像/菜图 → 中性占位，返回 `Texture2D` |
| `get_frames(character_id: String, state: String)` | `Array[Texture2D]`，至少一帧 |
| `has_image(resource_id: String)` | 是否有实际有效图片；占位不算有效图片 |
| `has_frames(character_id: String, state: String)` | 任意单帧或编号帧有效则为 `true` |
| `is_placeholder(texture: Texture2D)` | 判断是否为本服务的占位纹理或 `null` |
| `get_resource_info(resource_id: String)` | 已解析 ID、可用状态、内置/自定义路径，供开发检查 |
| `reload()` | 重新扫描、清理缓存并发出 `changed` |
| `poll(delta: float)` | 开发者模式下按 `poll_interval` 检查图片和清单变化 |
| `developer_mode` | 默认 `false`，开启才自动监测修改 |
| `poll_interval` | 默认 1 秒，最低 0.1 秒 |
| `last_errors` | 损坏图片或清单的开发检查信息 |
| `import_image(bytes, relative_path)` | 校验并保存图片，返回 `{ok, error, id, path}`；失败返回 `{ok:false,error}` |

监测使用修改时间、大小和内容摘要，避免同一秒内保存同尺寸图片未被发现。仅在开发者模式扫描；图片多时可提高 `poll_interval`。`reload()` 始终允许手动刷新。`RarityDisplay.reload_config()` 是稀有度配置的单独刷新方法。

测试可以用 `AssetService.new(builtin_directory, custom_directory)` 指定临时根目录，不会写入正式素材。一般运行不传参数，服务自行选择当前平台正确的外置根目录。

## 五、资源别名清单

内置 `assets/art/manifest.json` 与外置 `CustomAssets/manifest.json` 都可配置别名。外置清单中的同名别名优先：

```json
{
  "version": 1,
  "aliases": {
    "restaurant": "Backgrounds/restaurant",
    "noodles": "Dishes/noodles",
    "qianyang_idle": "Characters/qianyang_idle"
  }
}
```

这样 `get_texture("noodles")` 等同于 `get_texture("Dishes/noodles")`。完整 ID 最明确，推荐业务代码直接使用完整 ID。没有别名时，服务也会接受四个目录中唯一的同名资源；若不同分类同时存在同名资源，则要求完整 ID 或明确别名，避免静默取错图。清单只描述别名，不执行代码，也不能指向资源目录之外。

## 六、运行时图片导入与网页文件选择

桌面 `FileDialog` 选择图片后，由界面读取文件字节，然后调用：

```gdscript
var bytes := FileAccess.get_file_as_bytes(selected_path)
var result: Dictionary = assets.import_image(bytes, "Characters/qianyang_idle_0.png")
if not result.ok:
    show_import_error(result.error)
```

`relative_path` 是用户选择的目标槽位，不是原文件的绝对路径。导入只允许四个目录的一层文件名，并拒绝目录跳转和符号链接。保存完成会立即重新载入。

浏览器的 `FileDialog` 无法直接访问用户磁盘路径，应使用 HTML `<input type="file" accept="image/png,image/jpeg">` 或 Godot `JavaScriptBridge` 触发文件选择。取得 `File.arrayBuffer()` 后，将其转成 `PackedByteArray` 传给同一个 `import_image()`。目标位置自动为 `user://CustomAssets/`。不应尝试扫描 `C:\\...` 或把网页上传界面设计成任意代码导入。网页保存是否跨会话保留依赖同源浏览器存储；无痕浏览、清理站点数据或更换站点地址会影响保留。

## 七、统一稀有度组件

`scripts/ui/rarity_display.gd` 提供静态 `color_for()`、`label_for()`、`stars_for()`、`icon_for()`、`scene_marker_for()`、`create_badge()` 和 `apply_border()`。`create_badge("SSR", false, assets)` 返回 `PanelContainer`，可以直接加到姓名旁。`apply_border(card, rarity)` 让员工卡片使用同色边框。

所有默认颜色、中文标签、星数和可选图标 ID 位于 `config/rarity.json`：N 灰 `#9E9E9E` / 普通 / 0 星，R 蓝 `#2196F3` / 稀有 / 1 星，SR 紫 `#9C27B0` / 超稀有 / 2 星，SSR 金 `#FFD700` / 传说 / 3 星。场景默认只有 SSR 显示金色星标。没有徽章图片时用文字和星号，仍可识别稀有度。

稀有度是收集与视觉分类；岗位匹配、工资和培养效果由游戏机制决定，不应在美术或文化说明中将员工的价值简化为稀有度。

## 八、验证

```bash
XDG_DATA_HOME=/workspace/.tools/godot/data \
XDG_CONFIG_HOME=/workspace/.tools/godot/config \
XDG_CACHE_HOME=/workspace/.tools/godot/cache \
godot --headless --path /workspace/- --script res://tests/asset_tests.gd
```

测试在临时 `user://` 目录生成色块图片并清理，覆盖自定义优先、损坏回退、动画数字排序、单帧合并、无编号首帧、manifest 别名、PNG/JPG 导入、非法路径/脚本/符号链接拒绝、热重载和稀有度统一配置。手动接图时还应确认：透明边缘、锚点、不同分辨率、动画朝向、网页刷新后图片是否保留，以及每处显示是否走统一服务。

## 九、导出与交付

先完成代码修改，再顺序运行以下命令，避免多个 Godot 编辑器同时导入一个工程：

```bash
bash tools/export_web.sh
bash tools/export_windows.sh
python3 tools/package_release.py
python3 tools/serve_web.py --port 8000
```

产物目录为 `build/full-web/`、`build/full-windows/`；ZIP 为 `build/山海食肆物语-v1.3-Web.zip`、`build/山海食肆物语-v1.3-Windows.zip`、`build/山海食肆物语-v1.3-Source.zip`。源码包保留可编辑的 GDScript、配置、场景、图片路径模板、开发文档、测试和工具，排除 Git 历史、Godot 缓存、旧下载构建与常见密钥文件。

每次导出记录游戏源文件 SHA-256 指纹；打包会检查两个平台对应同一份源码并校验导出文件，拒绝把旧 PCK 与新源码混为同一版。`build/v1.3-artifact-manifest.json` 记录源指纹、大小与各 ZIP 校验值；`build/v1.3-SHA256SUMS.txt` 可用于下载后核对。文档和测试更新只需重新打包；游戏脚本、配置、内置素材或导出配置更新后需要重导出。结构检查与 Linux 上读取 PCK 不等于 Windows 本机试玩，交付验证应分别记录。


## 十、文化简介专图与全部固定槽位

文化简介为每位员工、每道菜保留独立展示图片，不要求替换游戏中的动作帧或菜单缩略图。共51个槽位：26位员工、23道标准菜及2道原创隐藏菜。路径表与 `CustomAssets/manifest.json` 的 `culture_slots` 数组一致；加入图片无需修改文化正文，也不会影响战斗、经营或员工数值。

调用方式：

```gdscript
var resource_id: String = assets.culture_resource_id("employees", "qianyang")
# Characters/qianyang_lore
var picture: Texture2D = assets.culture_texture("employees", "qianyang")
var has_picture: bool = not assets.is_placeholder(picture)
var dish_picture: Texture2D = assets.culture_texture("dishes", "baize_hidden_banquet")
```

加载顺序为：**有效自定义专图 → 有效内置专图 → 现有角色待机图/肖像或普通菜图 → 中性占位**。角色待机图支持 `get_frames()` 已有编号规则，缺少专图时选首张可用待机帧，再尝试旧版 `Characters/<员工ID>` 肖像。专图与动作帧、菜图互不覆盖；可以只交付部分图片，其余简介仍能阅读。专图不要以 `<员工ID>_idle` 命名，以免改动餐厅里的角色。

下表路径均相对于桌面 `CustomAssets/` 或内置 `assets/art/`。内置图片需重新导出；外置图片可热重载；网页通过原图片导入入口保存到 `user://CustomAssets/`。表中 PNG 可改为 JPG/JPEG，透明插图推荐 PNG。建议简介图使用清楚主体、留白合适的方形或横幅画布，例如960×720；界面按比例完整显示，不应把正文或来源信息画死在图片里。

后续补入图片时另行记录作品来源、作者与使用许可；文化文字中的典籍出处不自动授予现代插画的使用权。本轮未抓取或生成正式美术。

| 类型 | 名称 | 固定专图路径 |
| --- | --- | --- |
| 员工 | 羬羊 | `Characters/qianyang_lore.png` |
| 员工 | 鸮 | `Characters/owl_lore.png` |
| 员工 | 耳鼠 | `Characters/earmouse_lore.png` |
| 员工 | 灌灌 | `Characters/guanguan_lore.png` |
| 员工 | 讹兽 | `Characters/eshou_lore.png` |
| 员工 | 饕餮 | `Characters/taotie_lore.png` |
| 员工 | 冉遗鱼 | `Characters/ranyiyu_lore.png` |
| 员工 | 当康 | `Characters/dangkang_lore.png` |
| 员工 | 天狗 | `Characters/tiangou_lore.png` |
| 员工 | 蛊雕 | `Characters/gudiao_lore.png` |
| 员工 | 九尾狐 | `Characters/nine_tailed_fox_lore.png` |
| 员工 | 毕方 | `Characters/bifang_lore.png` |
| 员工 | 貔貅 | `Characters/pixiu_lore.png` |
| 员工 | 英招 | `Characters/yingzhao_lore.png` |
| 员工 | 陆吾 | `Characters/luwu_lore.png` |
| 员工 | 精卫 | `Characters/jingwei_lore.png` |
| 员工 | 穷奇 | `Characters/qiongqi_lore.png` |
| 员工 | 梼杌 | `Characters/taowu_lore.png` |
| 员工 | 混沌 | `Characters/hundun_lore.png` |
| 员工 | 獬豸 | `Characters/xiezhi_lore.png` |
| 员工 | 凤凰 | `Characters/phoenix_lore.png` |
| 员工 | 白泽 | `Characters/baize_lore.png` |
| 员工 | 应龙 | `Characters/yinglong_lore.png` |
| 员工 | 烛龙 | `Characters/zhulong_lore.png` |
| 员工 | 帝江 | `Characters/dijiang_lore.png` |
| 员工 | 九婴 | `Characters/jiuying_lore.png` |
| 菜品 | 阳春面 | `Dishes/noodles_lore.png` |
| 菜品 | 蛋炒饭 | `Dishes/fried_rice_lore.png` |
| 菜品 | 酸梅汤 | `Dishes/plum_juice_lore.png` |
| 菜品 | 羬羊羊肉汤 | `Dishes/qianyang_soup_lore.png` |
| 菜品 | 毕方烤翅 | `Dishes/bifang_wings_lore.png` |
| 菜品 | 九尾仙奶 | `Dishes/fox_milk_lore.png` |
| 菜品 | 应龙海鲜锅 | `Dishes/yinglong_hotpot_lore.png` |
| 菜品 | 饕餮自助套餐 | `Dishes/taotie_buffet_lore.png` |
| 菜品 | 凤凰涅槃羹 | `Dishes/phoenix_soup_lore.png` |
| 菜品 | 祝余轻食 | `Dishes/zhuyu_salad_lore.png` |
| 菜品 | 陆吾烤肉拼盘 | `Dishes/luwu_platter_lore.png` |
| 菜品 | 英招时蔬沙拉 | `Dishes/yingzhao_salad_lore.png` |
| 菜品 | 精卫石锅拌饭 | `Dishes/jingwei_bibimbap_lore.png` |
| 菜品 | 当康丰收炒饭 | `Dishes/dangkang_rice_lore.png` |
| 菜品 | 天狗天妇罗 | `Dishes/tiangou_tempura_lore.png` |
| 菜品 | 冉遗鱼汤 | `Dishes/ranyiyu_soup_lore.png` |
| 菜品 | 穷奇麻辣火锅 | `Dishes/qiongqi_hotpot_lore.png` |
| 菜品 | 梼杌秘制烤肉 | `Dishes/taowu_barbecue_lore.png` |
| 菜品 | 混沌云吞 | `Dishes/hundun_wonton_lore.png` |
| 菜品 | 獬豸正义套餐 | `Dishes/xiezhi_set_lore.png` |
| 菜品 | 烛龙火焰拉面 | `Dishes/zhulong_ramen_lore.png` |
| 菜品 | 帝江无面饺子 | `Dishes/dijiang_dumplings_lore.png` |
| 菜品 | 九婴九味拼盘 | `Dishes/jiuying_platter_lore.png` |
| 菜品 | 白泽万象宴 | `Dishes/baize_hidden_banquet_lore.png` |
| 菜品 | 凤凰涅槃羹·真 | `Dishes/phoenix_true_soup_lore.png` |

2026-10-18 v1.5新增支线隐藏菜的菜单缩略图可放`CustomAssets/Dishes/phoenix_true_soup.png`，文化专图可放`CustomAssets/Dishes/phoenix_true_soup_lore.png`；内置路径分别为`assets/art/Dishes/`下同名文件。两者独立，均支持缺图回退，不需要先补正式美术才能经营或阅读。

## v1.5 支线觉醒外观

完成对应专属支线后，员工显示采用 `appearance` ID。可在 `CustomAssets/Characters/<员工ID>_awakened_idle.png`（或内置 `assets/art/Characters/`）插入外观，其余动作沿用 `_move_0.png`、`_cook_0.png`、`_serve_0.png` 等原帧序列命名。固定槽位见 manifest 的 `appearance_slots`。缺少某动作时回退同员工原动作，再回退程序占位；文化专图 `<员工ID>_lore.png` 独立保留。当前没有正式觉醒图片。

## v1.6 新增界面槽位与角色表现

- 气泡背景：`CustomAssets/UI/thought_bubble.png`（内置路径`assets/art/UI/thought_bubble.png`）。PNG透明边缘、四边至少10像素留白，按九宫格缩放；缺图用程序圆角框。文字始终由游戏绘制，不要将固定文字烘焙进图片。
- 新导航图标：`UI/btn_promotion.png`、`btn_recruit.png`、`btn_branch.png`、`btn_central.png`、`btn_exploration.png`。宣传和营销共用推广图标，显示入口随阶段切换。
- 所有上述槽位都走既有AssetCatalog和桌面外置/网页导入机制，无需改经营脚本。正式角色动作与觉醒帧命名契约不变；状态气泡不会替代51个文化专图槽位。
- 文本与表现参数在`config/experience.json`：26位员工有独立内心短句，通用工作/训练/休息/缺货等状态另列。文案为游戏原创，不作为山海经引文。默认气泡3.5真实秒、每人12真实秒冷却、同时最多2个；暂停时冻结。候位间距68世界像素、预留体间距44、显示偏移上限64。修改配置后重新启动/导出；当前气泡不提供独立配音。

## v1.7.1 特殊顾客专图

继续使用Characters目录：guest_<ID>_lore.png用于图鉴，guest_<ID>_idle.png用于场景。六个ID：old_gourmand、baize_friend、lost_cub、picky_blogger、grateful_monster、kunlun_spy。桌面位于CustomAssets/Characters/；内置assets/art/Characters/；网页开发者导入支持对应12槽。原有51文化槽、四类目录、觉醒帧与统一缺图回退不变。

## v1.8 新槽位

继续用占位资源。两位新员工ID为`xuangui`（旋龟）、`qinggeng`（青耕）：独立简介图`Characters/<ID>_lore.png`，站立图`Characters/<ID>_idle.png`；Walk/Cook/Serve/Rest等动作仍按既有`<ID>_<小写动作>_0.png`序列接入，觉醒命名沿用原接口。它们随同28员工、25菜共53个文化专图槽写入两份manifest。

掉落图为`UI/pickup_cash.png`和`UI/pickup_gem.png`，建议64×64带透明通道。没有图时显示可点的44像素占位按钮，灵石有程序光点和短提示音。图片不影响寻路占位和拾取金额。网页“美术资源”的目标选择器已列出新增图像，也可手填四类目录下的路径；导入及热重载继续共用AssetCatalog。

## v1.9 新员工与紧凑表现

新增青蚨`qingfu`、天禄`tianlu`。可放置`CustomAssets/Characters/qingfu_idle.png`、`tianlu_idle.png`及既有动作命名的帧序列；独立文化图为`Characters/qingfu_lore.png`、`Characters/tianlu_lore.png`。内置路径仍为`assets/art/Characters/`，网页经同一开发者导入入口保存。两份manifest已加入新文化槽，总计30员工+25菜=55；含12来客、2拾取和手填入口，目标选择器合计70项。缺图回退占位。

`UI/thought_bubble.png`继续用于紧凑单行气泡；背景不要嵌入文字。v1.9提示默认1.5秒、气泡2秒，长文字逐组延时至最多4秒；提示、资金浮字与角色/顾客气泡合计最多3个。此节覆盖上文v1.6旧表现默认值。引导箭头和边框由程序绘制，不需要正式素材才可使用。

## v1.9.1 横截面场景与设备

固定四类目录和AssetCatalog不变。新增独立背景`Backgrounds/dollhouse.png`，阶段背景为`Backgrounds/dollhouse_stage_0.png`至`dollhouse_stage_4.png`。建议横幅1440×360，正面剖面构图；绘制后墙和基础，给动态设备及人物留空，避免把初始家具烘焙进背景。缺图继续使用程序娃娃屋。

新增设备正面图：`UI/decor_stove.png`、`UI/decor_serving_counter.png`、`UI/decor_promotion_board.png`、`UI/decor_staff_corner.png`；初始基础设施为`UI/decor_basic_pass.png`、`UI/decor_basic_cashier.png`。建议透明PNG、正面视角、主体底部落在地面。既有`UI/decor_cashier.png`、`decor_kitchen.png`、`decor_table_two.png`等继续支持。6背景+6设备已写入两份manifest的dollhouse_slots，并加入开发者下拉；与55文化、12来客、2拾取及手填合计82项。

角色新动作可使用`Characters/<员工ID>_recommend_0.png`、`_rest_0.png`、`_build_0.png`等连续帧；原`idle/move/cook/serve/clean/cashier/promote`命名继续有效。面向后方设备的专用帧可用`_cook_back_0.png`、`_cashier_back_0.png`、`_build_back_0.png`，缺少时回退原动作或程序占位，觉醒appearance ID仍走同一接口。

独立动作、设备图、背景和文化专图互不替代；图像不改变碰撞、设备容量、到达时间或财务结果。网页经原导入入口保存至浏览器存储，桌面位于程序同级CustomAssets，内置使用assets/art后重新导出。本轮未加入正式美术。

## v1.9.3接口扩展

统一AssetCatalog新增get_sprite(resource_id)、get_frame(char_id,action,direction,frame)、get_portrait(char_id,tutorial=false)；get_frames同时支持可选direction。扫描支持Sprites下的角色及顾客子目录，仍校验图片尺寸/字节数与路径。完整清单见上方链接。员工照片不会放大场景小人回退；文化专图保持独立。
