extends SceneTree
const Tutorial = preload("res://scripts/ui/tutorial_overlay.gd")
const Guide = preload("res://scripts/core/tutorial_progress.gd")
var checks = 0
var failures = 0
class FakeModel extends RefCounted:
	signal autosave_requested
	var state = {"mode":"full","stage":0,"served":0,"total_minutes":360,"stats":{},"unlocked_dishes":["noodles","fried_rice","plum_juice"]}
	var employees: Array = [{"id":"chef"},{"id":"waiter"}]
class FakeHost extends Control:
	var model = FakeModel.new()
	var panel_name = ""
	var _qa_buttons: Array[Button] = []
	var debt_label: Label
	var money_label: Label
	var map_view: Control
func _init() -> void: call_deferred("run")
func expect(value: bool,message: String) -> void:
	checks += 1
	if not value: failures += 1;push_error(message)
func run() -> void:
	var host = FakeHost.new()
	root.add_child(host)
	var overlay = Tutorial.new()
	host.add_child(overlay)
	overlay.setup(host)
	expect(overlay.steps.size() == 6,"V1.5 has exactly six mandatory onboarding steps")
	expect(overlay.current_step().id == "welcome","New game explains debt first")
	expect(not overlay.current_step().has("stage"),"Onboarding has no stage1 free research")
	expect(not Guide.allows_panel(host.model,"研发"),"Research cannot bypass welcome operation lock")
	expect(Guide.allows_panel(host.model,"文化简介"),"Culture remains readable during guidance")
	overlay.skip_tutorial()
	expect(overlay.current_step().id == "welcome" and not host.model.state.tutorial.skipped,"Mandatory introduction cannot be skipped through old API")
	overlay.observe("panel:员工")
	expect(not "staff" in host.model.state.tutorial.completed_steps,"Opening staff alone is insufficient; closing is required")
	overlay.acknowledge()
	expect(overlay.current_step().id == "staff","Acknowledging welcome reaches real staff operation")
	overlay.observe("closed:员工")
	expect(overlay.current_step().id == "promotion","Closing roster completes staff teaching")
	expect(Guide.allows_panel(host.model,"宣传营销") and not Guide.allows_panel(host.model,"装修"),"Promotion operation enables its route and locks unrelated purchase")
	overlay.observe("marketing",{"kind":"flyer"})
	expect(overlay.current_step().id == "first_order","Successful marketing starts observation step")
	overlay.observe("served_order")
	expect(overlay.current_step().id == "first_order","A string event cannot fake a paid order")
	host.model.state.served = 1
	overlay.poll(0)
	expect(overlay.current_step().id == "income","Actual paid-order fact advances guidance")
	overlay.acknowledge()
	expect(overlay.current_step().id == "bill","Income acknowledgment routes to transparent bills")
	overlay.observe("panel:账单")
	expect(overlay.current_step().is_empty() and host.model.state.tutorial.finished,"Viewing a real current-day preview completes sixth step")
	expect(Guide.validate_state(host.model.state.tutorial,0),"New tutorial progress obeys strict persistence contract")
	var saved = host.model.state.tutorial.duplicate(true)
	overlay.poll(1)
	expect(saved == host.model.state.tutorial,"Polling completed tutorial does not mutate saved progress")
	host.model.state.stage = 1
	overlay.poll(0)
	expect(overlay.current_step().id == "stage1_research","Stage1 starts genuine research guidance")
	overlay.observe("research")
	expect(overlay.current_step().id == "stage1_research","Starting research is not completing research")
	host.model.state.stats.research_success = 1
	overlay.poll(0)
	expect(overlay.current_step().id == "stage1_price","A completed research advances to pricing")
	overlay.defer_current()
	expect(overlay.current_step().id == "stage1_skill","Only one stage feature is taught at a time")
	expect("stage1_price" in host.model.state.tutorial.deferred and not "stage1_price" in host.model.state.tutorial.stage_completed,"Deferral retains unresolved feature")
	overlay.observe("upgrade_skill")
	expect(overlay.current_step().id == "stage1_decoration","Actual skill action advances stage teaching")
	overlay.observe("buy_decoration")
	expect(overlay.current_step().is_empty(),"All other taught features leave only deferred pricing")
	Guide.resume(host.model,"stage1_price")
	expect(overlay.current_step().id == "stage1_price","Deferred feature can be resumed")
	overlay.observe("set_price")
	expect(overlay.current_step().is_empty(),"Actual pricing resolves the last pending stage feature")
	host.model.state.stage = 4
	overlay.poll(0)
	expect(Guide.pending_stage(host.model).size() == 11,"Stages2–4 supply eleven separate feature guides")
	expect(Guide.config().stage_steps.size() == 15,"All fifteen newly unlocked features have individual guides")
	var invalid = host.model.state.tutorial.duplicate(true)
	invalid.skipped = true
	expect(not Guide.validate_state(invalid,4),"New save cannot claim skipped mandatory onboarding")
	host.queue_free()
	await process_frame
	print("Tutorial checks: %d; failures: %d" % [checks,failures])
	quit(1 if failures else 0)
