extends SceneTree
## New-game acceptance uses real controls, real costs and a naturally paid order.
## Late-stage screen fixtures below are isolated UI checks, never campaign proof.
const Guide = preload("res://scripts/core/tutorial_progress.gd")
var checks = 0
var failures = 0
class Harness extends "res://scripts/ui/main.gd":
	func _ready() -> void:
		var test_theme = Theme.new()
		test_theme.default_font = FONT
		test_theme.default_font_size = 16
		theme = test_theme
		model = GameModel.new(20261018)
		model.start_full()
		assets = AssetCatalog.new()
		model.set_paused(true)
		build_interface()
		full_panels = FullPanels.new(self)
		tutorial_overlay = TutorialOverlay.new()
		add_child(tutorial_overlay)
		tutorial_overlay.setup(self)
		model.changed.connect(refresh)
		model.notice.connect(show_notice)
		set_process(false)
		refresh()
func _init() -> void: call_deferred("run")
func expect(value: bool,message: String) -> void:
	checks += 1
	if not value: failures += 1;push_error(message)
func find(node: Node,id: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.get_meta("qa_id","")) == id: return node
	for child in node.get_children():
		var found = find(child,id)
		if found != null: return found
	return null
func labels(node: Node) -> String:
	var value = node.text if node is Label or node is RichTextLabel else ""
	for child in node.get_children():
		if not child.is_queued_for_deletion(): value += "\n" + labels(child)
	return value
func chart_rows(node: Node) -> Array:
	var result: Array = []
	if node.is_queued_for_deletion(): return result
	if node is HFlowContainer and node.get_child_count() == 2 and node.get_child(0).get_script() == preload("res://scripts/ui/stat_pie.gd"):
		result.append(node)
	for child in node.get_children(): result.append_array(chart_rows(child))
	return result
func verify_chart(ui,context: String) -> void:
	for frame in range(6): await process_frame
	var charts = chart_rows(ui.modal_body)
	expect(charts.size() == 1,context + ": actual chart exists")
	for chart in charts:
		var legend = chart.get_child(1)
		for entry in legend.get_children():
			expect(entry.get_line_count() == 1 and entry.size.x >= entry.get_minimum_size().x,context + ": full legend and amount stay on one line")
			expect(entry.get_global_rect().end.x <= chart.get_global_rect().end.x + 1,context + ": legend fits within chart")
func click(ui,id: String) -> void:
	var button = find(ui,id)
	expect(button != null,"Actual control exists: " + id)
	if button == null: return
	expect(not button.disabled,"Actual control enabled: " + id)
	if button.disabled: return
	button.pressed.emit()
	await process_frame
	ui.tutorial_overlay.poll(0)
func run() -> void:
	root.size = Vector2i(1440,900)
	var ui = Harness.new()
	root.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	await process_frame
	ui.open_panel("欢迎")
	await click(ui,"start:full")
	expect(ui.tutorial_overlay.current_step().id == "welcome","Started fresh game retains mandatory debt explanation")
	ui.open_panel("研发")
	expect(ui.panel_name.is_empty(),"Direct UI route cannot bypass initial operation lock")
	ui.tutorial_overlay.skip_tutorial()
	expect(ui.tutorial_overlay.current_step().id == "welcome","Old skip method cannot bypass mandatory guide")
	await click(ui,"tutorial:ack")
	await click(ui,"nav:员工")
	expect(ui.tutorial_overlay.current_step().id == "staff","Opening roster does not finish close-required step")
	await click(ui,"panel:close")
	expect(ui.tutorial_overlay.current_step().id == "promotion","Roster close is actually observed")
	await click(ui,"tutorial:destination")
	expect(ui.panel_name == "宣传营销","Guide leads directly to the actual marketing screen")
	var before_cash = float(ui.model.state.cash)
	await click(ui,"full:marketing:flyer")
	expect(is_equal_approx(before_cash - float(ui.model.state.cash),20),"Mandatory flyer spends the specified real20 yuan")
	expect(ui.tutorial_overlay.current_step().id == "first_order","Flyer success advances to real service observation")
	for minute in range(900):
		if int(ui.model.state.served) > 0: break
		ui.model.advance_minutes(1)
	ui.tutorial_overlay.poll(0)
	expect(int(ui.model.state.served) > 0,"Original new game naturally completes and pays its first order")
	expect(ui.tutorial_overlay.current_step().id == "income","Actual paid order teaches income and reputation")
	await click(ui,"tutorial:ack")
	await click(ui,"tutorial:destination")
	expect(ui.panel_name == "账单","System bill entry opens actual finance screen")
	expect(labels(ui.modal_body).contains("结算前预览") and labels(ui.modal_body).contains("预计员工工资"),"Day1 bill explains real accrual and expected fixed fees")
	expect(ui.tutorial_overlay.current_step().is_empty() and bool(ui.model.state.tutorial.finished),"All six mandatory operations finish without resource injection or skipping")
	expect(Guide.validate_state(ui.model.state.tutorial,0),"Real-control guide progress is strictly serializable")
	await verify_chart(ui,"Desktop bill")
	expect(labels(ui.modal_body).contains("宣传营销  20.00") and not labels(ui.modal_body).contains("marketing"),"Bill legend translates the real marketing transaction")
	ui.open_panel("研发")
	expect(find(ui,"full:tutorial_research") == null,"Stage0 has no free research back door")
	ui.open_panel("顾客反馈")
	expect(labels(ui.modal_body).contains("今日顾客反馈") and labels(ui.modal_body).contains("差评原因分布"),"Customer feedback exposes live metrics and reason chart")
	ui.open_panel("待办汇总")
	expect(labels(ui.modal_body).contains("前往") or ui.modal_body.get_child_count() > 1,"Top-level todo aggregates actionable reminders")
	ui.open_panel("采购设置")
	expect(find(ui,"full:set_procurement_strategy:pause") != null,"Procurement pause is a real model action")
	# Bankruptcy fixture validates the forced UI guard, not economic balance.
	ui.model.state.finance.rescue.pending = true
	ui.open_panel("破产救援")
	ui.close_panel()
	expect(ui.panel_name == "破产救援","Rescue cannot be dismissed with the standard close path")
	expect(find(ui,"rescue:accept") != null and find(ui,"revision:rescue_decline:") != null,"Rescue exposes independent once-per-run loan and forced failure if declined")
	expect(labels(ui.modal_body).contains("紧急贷款"),"Rescue explains the third path and daily interest")
	ui.model.state.finance.rescue.pending = false
	ui.close_panel(false)
	# Isolated stage fixture: required steps can defer, never complete by opening.
	ui.model.state.stage = 1
	ui.tutorial_overlay.poll(0)
	expect(ui.tutorial_overlay.current_step().id == "stage1_research","Stage upgrade requires real research guidance")
	ui.open_panel("研发")
	expect(ui.tutorial_overlay.current_step().id == "stage1_research","Opening research cannot resolve its strong guide")
	ui.tutorial_overlay.defer_current()
	expect("stage1_research" in ui.model.state.tutorial.deferred and not "stage1_research" in ui.model.state.tutorial.stage_completed,"Later guidance defers without falsely completing")
	ui.action_notifications.update()
	expect(ui.action_notifications.entries("guides").is_empty() and Guide.pending_stage(ui.model).any(func(step):return str(step.id)=="stage1_research"),"Deferred guide remains independently resumable and does not enter stage todo")
	ui.open_panel("图鉴")
	ui.open_culture("employees","bai_ze")
	expect(ui.panel_name == "文化简介" and labels(ui.modal_body).contains("白泽"),"Culture stays readable before recruitment and during stage teaching")
	ui.return_from_culture()
	root.size = Vector2i(844,390)
	ui.queue_ui_layout()
	await process_frame
	await process_frame
	ui.update_ui_layout()
	ui.open_panel("菜单定价")
	ui.tutorial_overlay.poll(0)
	await process_frame
	expect(ui.compact_layout,"Landscape phone uses compact logical layout")
	expect(ui.navigation_buttons["员工"].size.y >= 44 and ui.navigation_buttons["更多"].size.y >= 44,"Core mobile controls retain44px hit targets")
	expect(ui.modal_window.get_global_rect().end.x <= ui.tutorial_overlay.tutorial_card.get_global_rect().position.x,"Compact guide and current operation panel do not cover each other")
	ui.open_panel("账单")
	await verify_chart(ui,"Compact bill")
	ui.open_panel("顾客反馈")
	await verify_chart(ui,"Compact feedback")
	# Isolated layout fixture covers long amounts and wrapping the whole legend.
	ui.clear(ui.modal_body)
	ui.v15_panels.chart(ui.modal_body,"布局回归",[{"type":"liability_settlement","amount":123456789.12},{"type":"marketing","amount":20}])
	await verify_chart(ui,"Long-amount legend")
	var chart = chart_rows(ui.modal_body)[0]
	chart.get_parent().remove_child(chart)
	var narrow = Control.new()
	ui.add_child(narrow)
	narrow.add_child(chart)
	chart.size = Vector2(260,400)
	for frame in range(6): await process_frame
	var legend = chart.get_child(1)
	expect(legend.position.y >= chart.get_child(0).get_rect().end.y,"260px chart moves its whole legend below the pie")
	for entry in legend.get_children():
		expect(entry.get_line_count() == 1 and entry.get_global_rect().end.x <= chart.get_global_rect().end.x + 1,"260px chart keeps the entire name and amount horizontal and visible")
	ui.queue_free()
	await process_frame
	print("V1.5 UI checks: %d; failures: %d" % [checks,failures])
	quit(1 if failures else 0)
