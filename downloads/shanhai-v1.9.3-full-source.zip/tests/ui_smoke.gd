extends SceneTree

## Instantiate the actual campaign controls without loading or writing player saves.
## Late-stage fixtures are explicit test setup, not a claimed natural playthrough.
const Policy=preload("res://scripts/ui/interface_policy.gd")
const FullPanels = preload("res://scripts/ui/full_panels.gd")
const AssetCatalog = preload("res://scripts/services/asset_catalog.gd")
var checks := 0
var failures := 0
var rendered_panels := 0
var clicked_actions: Array[String] = []
var ui

class Harness extends "res://scripts/ui/main.gd":
	func _ready() -> void:
		var test_theme = Theme.new()
		test_theme.default_font = FONT
		test_theme.default_font_size = 16
		theme = test_theme
		model = GameModel.new(20261016)
		model.start_full()
		# Broad panel fixtures defer stage teaching; mandatory guidance has its own real-operation suite.
		model.state.tutorial = {"version":2,"completed_steps":["welcome","staff","promotion","first_order","income","bill"],"deferred":Guide.config().stage_steps.map(func(step): return step.id),"actions":[],"stage_completed":[],"panel_opened":[],"panel_closed":[],"finished":true,"skipped":false,"seen_stage":0}
		assets = AssetCatalog.new()
		model.set_paused(true)
		build_interface()
		full_panels = FullPanels.new(self)
		tutorial_overlay = TutorialOverlay.new()
		add_child(tutorial_overlay)
		tutorial_overlay.setup(self)
		model.changed.connect(refresh)
		model.notice.connect(show_notice)
		set_process(false)
		refresh()

func _init() -> void:
	call_deferred("run")

func check(value: bool, description: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(description)

func buttons(node: Node) -> Array[Button]:
	var result: Array[Button] = []
	if node is Button and not node.is_queued_for_deletion(): result.append(node)
	for child in node.get_children():
		if not child.is_queued_for_deletion(): result.append_array(buttons(child))
	return result

func find_button(id: String) -> Button:
	for button in buttons(ui):
		if str(button.get_meta("qa_id", "")) == id: return button
	return null

func click(id: String) -> void:
	var button = find_button(id)
	check(button != null, "button exists: " + id)
	if button == null: return
	check(not button.disabled, "button is enabled: " + id + " / " + button.tooltip_text)
	if button.disabled: return
	clicked_actions.append(id)
	button.pressed.emit()
	await process_frame

func open(name: String) -> void:
	if ui.decoration_active(): ui.finish_decoration(false)
	if Policy.minimum_stage(name)>int(ui.model.state.stage):
		var prior=ui.panel_name
		ui.open_panel(name)
		check(ui.panel_name==prior and is_instance_valid(ui._requirement_dialog),"Locked route retains screen and explains threshold: "+name)
		if is_instance_valid(ui._requirement_dialog):ui._requirement_dialog.queue_free();await process_frame
		return
	ui.open_panel(name)
	await process_frame
	check(str(ui.panel_name) == name and ui.modal_body.get_child_count() > 0, "panel renders: " + name)
	rendered_panels += 1

func run() -> void:
	ui = Harness.new()
	root.add_child(ui)
	await process_frame
	check(FullPanels.ATTRIBUTES.size() == 7 and FullPanels.ATTRIBUTES.calculation == "算力", "all seven v1.3 attribute labels")
	check(ui.full_panels._role_name("tutor") == "培训/研发" and ui.full_panels._role_name("Tutor") == "培训/研发", "Tutor role is readable")
	check(FullPanels.rarity_color("N") != FullPanels.rarity_color("R") and FullPanels.rarity_color("SR") != FullPanels.rarity_color("SSR"), "rarities retain distinct gray/blue/purple/gold colors")
	ui.model.events.clear()
	ui.model.balance["customer.base_flow"] = 0.0 # Keep asynchronous UI projects deterministic.
	ui.model.state.cash = 1000000.0
	ui.model.state.gems = 10000
	ui.model.state.reputation = 10000
	ui.model.state.total_revenue = 500000.0
	var names = ["更多", "员工", "招聘", "员工培养", "研发", "菜单", "库存供应", "经营升级", "宣传营销", "会员外卖", "连锁经营", "山海探索", "三界集团", "图鉴", "事件图鉴", "羁绊图鉴", "系统", "装修"]
	for stage in range(5):
		ui.model.state.stage = stage
		for name in names: await open(str(name))
		await open("招聘")
		check(find_button("hire:contract").disabled, "empty contract is disabled at stage %d" % stage)
		check(not find_button("hire:normal").disabled and not find_button("hire:advanced").disabled, "funded hires enabled at stage %d" % stage)
	ui.model.state.stage = 0
	ui.close_panel(false)
	ui.model.set_paused(false)
	await open("研发")
	check(not ui.model.paused, "locked research route retains previous running state")
	check(find_button("full:tutorial_research") == null,"v1.5 stage0 never offers the removed free-research loophole")
	check(not ui.model.state.unlocked_dishes.has("qianyang_soup"),"research remains locked until the actual stage1 process")
	ui.close_panel(false)
	ui.model.set_paused(true)
	await open("招聘")
	ui.close_panel()
	check(ui.model.paused, "explicit player pause survives panel close")
	ui.model.state.contracts.append("bi_fang")
	await open("招聘")
	check(not find_button("hire:contract").disabled, "earned contract enables recruitment")
	await click("hire:contract")
	check(not ui.find_employee("bi_fang").is_empty() and ui.model.state.contracts.is_empty(), "contract hires its designated employee")
	await open("招聘")
	await click("hire:normal")
	check(int(ui.model.state.hire_counts.normal) == 1, "normal hire reaches model")
	await open("招聘")
	await click("hire:advanced")
	check(int(ui.model.state.hire_counts.advanced) == 1, "advanced hire reaches model")
	ui.model.state.cash = 0.0
	ui.model.state.gems = 0
	await open("招聘")
	check(find_button("hire:normal").disabled and find_button("hire:advanced").disabled, "unfunded hire controls explain and disable")
	check(not find_button("hire:normal").tooltip_text.is_empty() and not find_button("hire:advanced").tooltip_text.is_empty(), "disabled hires have readable reasons")
	ui.model.state.cash = 1000000.0
	ui.model.state.gems = 10000
	ui.model.state.stage = 4
	await open("库存供应")
	await click("full:purchase:generic:5")
	await click("full:unlock_supplier:shanhai")
	check("shanhai" in ui.model.state.management.suppliers, "supplier button reaches model")
	await open("菜单")
	await click("full:set_price:noodles")
	await click("full:set_menu:plum_juice:false")
	check(not "plum_juice" in ui.model.state.menu_enabled, "menu button reaches model")
	await open("员工培养")
	await click("full:train_attribute:xian_yang")
	check(int(ui.model._employee("xian_yang").management_until) > int(ui.model.state.total_minutes), "training selector starts a real project")
	ui.model.advance_minutes(200)
	await open("员工培养")
	await click("full:raise_wage:xian_yang")
	check(int(ui.model._employee("xian_yang").wage_extra) == 10, "wage button reaches model")
	await click("full:comfort:xian_yang")
	ui.revision_ui.employee_id="xian_yang"
	await open("员工详情")
	await click("revision:set_shift:xian_yang")
	check(bool(ui.model._employee("xian_yang").shift_enabled), "shift controls reach model")
	await open("宣传营销")
	await click("full:marketing:flyer")
	check(int(ui.model.state.promotion_until) > int(ui.model.state.total_minutes), "marketing button starts timed campaign")
	await open("会员外卖")
	await click("full:membership_enable")
	await click("full:delivery_toggle:true")
	check(bool(ui.model.state.expansion.membership.enabled) and bool(ui.model.state.expansion.delivery_enabled), "membership and delivery controls reach model")
	await open("连锁经营")
	await click("full:central_unlock")
	check(bool(ui.model.state.expansion.central.enabled), "central kitchen control reaches model")
	await click("full:central_cook:noodles:5")
	check(ui.model.state.expansion.central.jobs.size() == 1, "batch cooking starts through UI")
	ui.model.advance_minutes(20)
	await open("连锁经营")
	await click("full:branch_open:human_east")
	check(bool(ui.model.state.expansion.branches.human_east.open), "branch opening reaches model")
	await click("full:branch_assign:human_east")
	check(ui.model.employees.any(func(employee): return str(employee.get("branch_id", "")) == "human_east"), "employee dropdown dispatches to branch")
	await click("full:supply_send:human_east:noodles:5")
	check(ui.model.state.expansion.central.shipments.size() == 1, "UI dispatches actual prepared dishes")
	ui.model.advance_minutes(25)
	await open("山海探索")
	await click("full:explore:")
	check(ui.model.state.expansion.explorations.size() == 1, "exploration selector starts real expedition")
	ui.model.advance_minutes(125)
	check(ui.model.state.expansion.explorations.is_empty() and not ui.model.state.expansion.exploration_history.is_empty(), "expedition completes with real rewards")
	# Ensure a free chef for the contest; dispatch and exploration fixtures may use qianyang.
	for employee in ui.model.employees:
		if str(employee.get("branch_id", "")) != "":
			await open("连锁经营")
			await click("full:branch_return:" + str(employee.id))
	ui.model.state.fragments.xian_yang = 10
	await open("三界集团")
	await click("full:awaken:xian_yang")
	check(bool(ui.model._employee("xian_yang").awakened), "awakening control uses configured fragments")
	await click("full:compete")
	check(not ui.model.state.expansion.competition.active.is_empty(), "contest selectors enter real competition")
	ui.model.advance_minutes(100)
	check(int(ui.model.state.expansion.competition.attempts) == 1 and ui.model.state.expansion.competition.active.is_empty(), "contest completes and records result")
	ui.revision_ui.employee_id=""
	for id in ["bai_ze", "feng_huang"]:
		if ui.model._employee(id).is_empty(): ui.model.employees.append(ui.model._create_employee(ui.model._employee_config(id)))
	ui.model.full_rules.ensure_state_defaults()
	await open("员工培养")
	await click("full:train_secondary:bai_ze:chef")
	ui.model.advance_minutes(200)
	await open("员工培养")
	await click("full:switch_role:bai_ze:chef")
	check(str(ui.model._employee("bai_ze").role) == "chef", "Tutor can take its learned secondary role")
	await click("full:switch_role:bai_ze:tutor")
	check(str(ui.model._employee("bai_ze").role) == "tutor", "Tutor can return to training/research after switching")
	await click("full:switch_role:feng_huang:waiter")
	check(str(ui.model._employee("feng_huang").role) == "waiter", "All-role employee can select an ordinary role without secondary training")
	await click("full:switch_role:feng_huang:all")
	check(str(ui.model._employee("feng_huang").role) == "all", "All-role employee can restore universal role")
	await test_portrait_import()
	ui.queue_free()
	await process_frame
	var report = {"version":"1.3", "checks":checks, "failures":failures, "panels_rendered":rendered_panels, "buttons_clicked":clicked_actions.size(), "actions":clicked_actions, "scope":"Real UI signals and model rules with explicit late-stage fixtures; no player save loaded or written."}
	var output = FileAccess.open("res://build/v1.3-ui-smoke.json", FileAccess.WRITE)
	if output != null: output.store_string(JSON.stringify(report, "  "))
	print("v1.3 UI checks: %d; failures: %d; panels: %d; clicked buttons: %d" % [checks, failures, rendered_panels, clicked_actions.size()])
	quit(1 if failures else 0)

func test_portrait_import() -> void:
	var temporary_root = "user://ui-smoke-custom-assets"
	var asset_catalog = AssetCatalog.new("res://assets/art", temporary_root)
	var image = Image.create(8, 8, false, Image.FORMAT_RGBA8)
	image.fill(Color("d34183"))
	var imported: Dictionary = asset_catalog.import_image(image.save_png_to_buffer(), "Characters/xian_yang_idle.png")
	check(bool(imported.get("ok", false)), "developer Idle portrait fixture imports")
	ui.assets = asset_catalog
	var texture: Texture2D = ui.full_panels._portrait_texture("xian_yang")
	check(texture != null and texture.get_image().get_pixel(0, 0).is_equal_approx(Color("d34183")), "full UI portrait uses developer Characters/id_idle path")
	DirAccess.remove_absolute(ProjectSettings.globalize_path(temporary_root + "/Characters/xian_yang_idle.png"))
