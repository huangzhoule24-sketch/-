@echo off
setlocal
cd /d "%~dp0"
if not exist "%LOCALAPPDATA%\ShanhaiFreePlay" mkdir "%LOCALAPPDATA%\ShanhaiFreePlay"
if not exist "%~dp0Shanhai-FreePlay.exe" goto missing
if not exist "%~dp0Shanhai-FreePlay.pck" goto missing
start "Shanhai Inn - Offline Free Play" /D "%~dp0" "%~dp0Shanhai-FreePlay.exe" --rendering-driver opengl3_angle --max-fps 30 --log-file "%LOCALAPPDATA%\ShanhaiFreePlay\low-power.log"
exit /b 0
:missing
echo Extract the ENTIRE ZIP first. Keep the EXE and PCK together.
pause
exit /b 1
