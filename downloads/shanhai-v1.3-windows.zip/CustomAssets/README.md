# 自定义图片目录模板

把本目录放在桌面版游戏可执行文件旁。开发版直接使用项目中的本目录。

这里仅提供目录约定和清单示例，没有正式美术或额外角色。请使用项目已有员工、菜品 ID 命名：

```
CustomAssets/
  manifest.json
  Backgrounds/restaurant.png
  Characters/qianyang_idle_0.png
  Characters/qianyang_idle_1.png
  Characters/qianyang_cook_0.png
  UI/btn_employee.png
  Dishes/noodles.png
```

只提供一张角色图时，可以命名为 `Characters/qianyang_idle.png`。这只替换待机动画的第 0 帧，其余内置帧继续保留；编号图 `_0.png` 优先于无编号图。

支持 PNG、JPG/JPEG；不加载 GIF、SVG、脚本或 Godot 资源文件。缺图或损坏图片会回退内置资源，再回退中性占位。开发者模式每秒检查修改时间和文件大小；手动点“重新载入”可立即更新。网页版本请通过游戏的图片导入入口写入浏览器保存区，不能直接扫描电脑目录。

完整命名、路径、接口、稀有度配置与导出注意事项见项目 `docs/art-pipeline.md`。
