/* Real UI input; observe decoder positions and actual WebAudio output, never mutate game state. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8048').replace(/\/$/,''),out=process.argv[2]||'build/web-r8/music-browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const context=await browser.newContext({viewport:{width:1440,height:900}}),page=await context.newPage(),checks=[],actions=[],errors=[],samples=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(/SCRIPT ERROR|Parse Error/.test(m.text()))errors.push(m.text())});
 await page.addInitScript(()=>{
  window.musicTaps=[];window.longMusicSources=[];
  const connect=AudioNode.prototype.connect;
  AudioNode.prototype.connect=function(destination,...args){const result=connect.call(this,destination,...args);if(destination instanceof AudioDestinationNode){const a=this.context.createAnalyser();a.fftSize=2048;connect.call(this,a);window.musicTaps.push(a)}return result};
  const start=AudioBufferSourceNode.prototype.start;
  AudioBufferSourceNode.prototype.start=function(...args){if(this.buffer?.duration>60)window.longMusicSources.push({offset:args[1]||0,time:this.context.currentTime,duration:this.buffer.duration});return start.apply(this,args)};
 });
 const state=()=>page.evaluate(()=>window.shanhaiQAState);
 function check(ok,label){checks.push({label,ok:!!ok});if(!ok)throw Error(label)}
 async function sync(){for(let i=0;i<2;i++){const old=await page.evaluateHandle(()=>window.shanhaiQAState);try{await page.waitForFunction(x=>window.shanhaiQAState!==x,old,{timeout:15000})}finally{await old.dispose()}}}
 async function point(r){return page.evaluate(r=>{const t=window.shanhaiQAState.screen_transform,c=document.querySelector('canvas'),v=c.getBoundingClientRect();return{x:v.x+(t.a*(r.x+r.w/2)+t.c*(r.y+r.h/2)+t.tx)*v.width/c.width,y:v.y+(t.b*(r.x+r.w/2)+t.d*(r.y+r.h/2)+t.ty)*v.height/c.height}},r)}
 async function click(id){let b;for(let i=0;i<35;i++){b=(await state()).buttons.find(b=>b.qa_id===id&&!b.disabled);if(b)break;const s=await state(),p=await point({x:s.viewport.w*.6,y:s.viewport.h*.6,w:0,h:0});await page.mouse.move(p.x,p.y);await page.mouse.wheel(0,110);await sync()}if(!b)throw Error('Missing visible control '+id);const p=await point(b.rect);await page.mouse.click(p.x,p.y);await sync();actions.push(id);fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({last:id,panel:(await state()).panel,checks:checks.length}))}
 async function shot(name){await page.screenshot({path:path.join(out,name+'.png')})}
 const distance=(a,b)=>(b-a+87.2727)%87.2727;
 async function amplitude(label){await page.waitForTimeout(650);const result=await page.evaluate(async()=>{let peak=0,sum=0,n=0;for(let i=0;i<8;i++){for(const a of window.musicTaps){const data=new Float32Array(a.fftSize);a.getFloatTimeDomainData(data);for(const v of data){peak=Math.max(peak,Math.abs(v));sum+=v*v;n++}}await new Promise(r=>setTimeout(r,25))}return{taps:window.musicTaps.length,peak,rms:n?Math.sqrt(sum/n):0}});samples.push({label,...result});return result}
 async function frozen(label){await page.waitForTimeout(200);await sync();const before=(await state()).audio;await page.waitForTimeout(700);await sync();const after=(await state()).audio;check(after.music_paused&&Math.abs(after.music_position-before.music_position)<.08,label);return after}
 let receipt,starts;
 try{
  receipt=await(await page.request.get(root+'/game/export-receipt.json')).json();await page.goto(root+'/game/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});
  await click('locale:en');await frozen('Welcome and language selection keep paused music silent at the held cursor');
  check((await amplitude('Welcome paused')).peak<.00001,'Actual WebAudio is silent on the paused welcome screen');
  await click('start:full');await page.waitForFunction(()=>shanhaiQAState.buttons.some(b=>b.qa_id==='tutorial:ack'),null,{timeout:15000});await click('tutorial:ack');
  await page.waitForFunction(()=>!shanhaiQAState.paused&&!shanhaiQAState.audio.music_paused&&shanhaiQAState.audio.music_position>.5,null,{timeout:15000});await sync();let s=await state();starts=s.audio.music_starts;
  check(!s.paused&&!s.audio.music_paused&&s.audio.music_position>.5,'Real game start advances background music');
  check(s.audio.music_playback_type===1,'Long music uses the stream playback backend');
  check((await amplitude('Running game')).peak>.0001,'Actual running output contains music');
  await shot('01-running');
  for(let i=0;i<2;i++){
   const prior=(await state()).audio.music_position;await click('nav:员工');const hold=await frozen('Staff operation '+i+' pauses without rewinding');
   check(distance(prior,hold.music_position)<3,'Entering management preserves accumulated playback '+i);
   if(i===0)check((await amplitude('Paused staff')).peak<.00001,'Actual WebAudio becomes silent during management pause');
   await click('panel:close');await page.waitForTimeout(600);await sync();s=await state();check(!s.audio.music_paused&&distance(hold.music_position,s.audio.music_position)>.2&&distance(hold.music_position,s.audio.music_position)<3&&s.audio.music_starts===starts,'Closing management resumes the same recording '+i);
  }
  let prior=(await state()).audio.music_position;await click('time:pause');await frozen('Manual Pause freezes the decoder');check((await amplitude('Manual pause')).peak<.00001,'Manual Pause silences actual music output');await shot('02-paused');
  const hold=(await state()).audio.music_position;await click('time:pause');await page.waitForTimeout(600);await sync();check(distance(hold,(await state()).audio.music_position)>.2&&(await state()).audio.music_starts===starts,'Manual Continue resumes rather than restarts');
  await click('tutorial:ack');await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');if((await state()).panel)await click('panel:close');
  await page.waitForFunction(()=>shanhaiQAState.state.served>=1,null,{timeout:120000});
  if(!(await state()).state.tutorial.completed_steps.includes('first_order')){await page.waitForFunction(()=>shanhaiQAState.state.tutorial.ready_to_ack.includes('first_order'),null,{timeout:15000});await click('tutorial:ack')}
  if(!(await state()).state.tutorial.completed_steps.includes('income'))await click('tutorial:ack');
  if(!(await state()).state.tutorial.completed_steps.includes('bill')){await click('tutorial:destination');await click('tutorial:ack')}if((await state()).panel)await click('panel:close');
  check((await state()).state.served>=1,'Normal tutorial and an actual paid order still work');
  for(const id of ['time:1','time:2','time:3','time:4']){prior=(await state()).audio.music_position;await click(id);await page.waitForTimeout(400);await sync();s=await state();const after=s.audio;check(s.speed===Number(id.split(':')[1])&&after.music_starts===starts&&distance(prior,after.music_position)>.2&&distance(prior,after.music_position)<3,'Speed operation preserves continuous music: '+id)}
  check((await page.evaluate(()=>window.longMusicSources)).length===0,'No browser sample source repeatedly restarts the long background track');
  if(!(await state()).paused)await click('time:pause');
  await click('nav:更多');await click('full:open:系统');await frozen('System settings preserve the manually paused game and music');
  let position=(await state()).audio.music_position;await click('system:audio:music');check(!(await state()).audio.enabled.music,'Music switch remains independent');await click('system:audio:sfx');await click('system:audio:music');s=await state();
  check(s.audio.enabled.music&&!s.audio.enabled.sfx&&s.audio.music_paused&&s.audio.music_starts===starts&&Math.abs(s.audio.music_position-position)<.08,'Re-enabling music while paused preserves position and stays silent');
  await click('locale:zh');await click('system:audio');await frozen('Detailed audio page and language changes cannot unpause or reset music');
  const slider=(await state()).audio_panel.sliders.music,p=await point({x:slider.x+slider.w*.4,y:slider.y,w:0,h:slider.h});await page.mouse.click(p.x,p.y);await sync();check((await state()).audio.levels.music>0&&(await state()).audio.levels.music<.7,'Volume slider remains functional');
  await click('audio:enabled:sfx');await click('panel:back');await click('panel:close');
  check((await state()).paused&&(await state()).audio.music_paused,'Closing settings cannot override an explicit manual pause');
  await click('time:pause');await page.waitForTimeout(500);await sync();check(!(await state()).audio.music_paused&&(await state()).audio.music_starts===starts,'Continuing after settings resumes the existing stream');
  await shot('03-resumed');
 }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())||null,null,2))}
 const report={game_source:receipt?.game_source,checks,actions,samples,long_music_sources:await page.evaluate(()=>window.longMusicSources).catch(()=>[]),final:await state(),errors,real_audio_device_tested:false};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({checks,actions:actions.length,samples,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
