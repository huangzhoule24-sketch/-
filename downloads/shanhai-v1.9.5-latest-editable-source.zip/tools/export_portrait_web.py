#!/usr/bin/env python3
"""Export current Web PCK and reuse the verified matching 4.6.3 engine binaries."""
import json,re,shutil,subprocess
from pathlib import Path
from package_release import ROOT,sha256,begin,stamp,write_json

def main():
 source=ROOT/'build/source-baseline-20261031/web';out=ROOT/'build/full-web'
 # Official, previously shipped non-threaded 4.6.3 engine. PCK is freshly exported.
 expected='26b61ce95247012ab3dca3ff51e96d1cdbff44ee91a8c20a83e150afca83f1b6'
 assert sha256(source/'index.wasm')==expected
 begin('web')
 with (ROOT/'build/portrait-pack-export.log').open('w')as log:
  subprocess.run(['godot','--headless','--path',str(ROOT),'--export-pack','Web',str(out/'index.pck')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 for p in source.glob('index.*'):
  if p.name!='index.pck':shutil.copy2(p,out/p.name)
 p=out/'index.html';s=p.read_text();m=re.search(r'const GODOT_CONFIG = (\{.*?\});',s);cfg=json.loads(m[1])
 for n in ['index.pck','index.wasm']:cfg['fileSizes'][n]=(out/n).stat().st_size
 s=s[:m.start(1)]+json.dumps(cfg,separators=(',',':'))+s[m.end(1):];p.write_text(s)
 stamp('web');write_json(ROOT/'build/portrait-engine-provenance.json',{'godot':'4.6.3.stable','engine_wasm_sha256':expected,'engine_unchanged_from_verified_r8':True,'pck_fresh_export':True,'reason':'Web engine templates absent in this environment; same verified engine reused with a fresh platform Web PCK export.'})
if __name__=='__main__':main()
