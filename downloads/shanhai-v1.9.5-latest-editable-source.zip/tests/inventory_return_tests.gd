extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures.append(message);push_error(message)
func settle():
	for i in range(12):await process_frame
func control(ui,id: String):
	for node in ui._qa_buttons:
		if is_instance_valid(node)and not node.is_queued_for_deletion()and node.is_visible_in_tree()and str(node.get_meta("qa_id",""))==id:return node
	return null
func headers(ui):
	for node in [ui.clock_label,ui.debt_label,ui.training_status,ui.building_status,ui.bottom_ui.summary_button]:expect(node.is_visible_in_tree(),"Header remains visible: "+node.name)
func run():
	root.size=Vector2i(390,844)
	var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	ui.model.set_paused(false);ui.bottom_ui.toggle_inventory();await settle()
	expect(ui.panel_name=="物品栏","Phone items opens a dedicated panel")
	headers(ui)
	if ui.panel_name!="物品栏":
		print("Inventory return: "+JSON.stringify({"checks":checks,"failures":failures}));ui.queue_free();await process_frame;quit(1);return
	expect(not ui.bottom_ui.inventory_open and not ui.bottom_ui.inventory_box.visible,"Old inline inventory stays closed in portrait")
	expect(ui.model.paused,"Inventory uses normal management pause")
	for dimensions in [Vector2i(360,640),Vector2i(390,844),Vector2i(430,932)]:
		root.size=dimensions;ui.update_ui_layout();await settle()
		var back=control(ui,"inventory:return")
		expect(back!=null,"Return to restaurant remains visible")
		if back!=null:
			var r=back.get_global_rect();expect(r.position.x>=0 and r.end.x<=dimensions.x+1 and r.end.y<=dimensions.y+1,"Return control fits phone")
		expect(ui.modal_body.get_combined_minimum_size().x<=dimensions.x-20,"Inventory contents fit phone width")
	var back=control(ui,"inventory:return");back.pressed.emit();await settle()
	expect(ui.panel_name.is_empty()and not ui.overlay.visible,"Return closes inventory completely")
	expect(not ui.model.paused,"Return restores running preference")
	headers(ui)
	ui.model.set_paused(true)
	for i in range(3):
		ui.bottom_ui.toggle_inventory();await settle();ui.close_panel();await settle()
		expect(ui.panel_name.is_empty()and ui.model.paused,"Repeated close keeps an explicit pause")
		headers(ui)
	ui.bottom_ui.toggle_inventory();await settle()
	var cash=control(ui,"inventory:cash");expect(cash!=null,"Inventory retains actual resource links")
	if cash!=null:cash.pressed.emit();await settle()
	expect(ui.panel_name=="账单","Cash opens its existing account panel")
	ui.return_to_parent_panel();await settle();expect(ui.panel_name=="物品栏","Child panel returns to inventory")
	root.size=Vector2i(844,390);ui.update_ui_layout();await settle()
	root.size=Vector2i(390,844);ui.update_ui_layout();await settle()
	expect(control(ui,"inventory:return")!=null,"Return survives a round trip through landscape")
	ui.close_panel();await settle();headers(ui)
	print("Inventory return: "+JSON.stringify({"checks":checks,"failures":failures}))
	ui.queue_free();await process_frame;quit(0 if failures.is_empty()else 1)
