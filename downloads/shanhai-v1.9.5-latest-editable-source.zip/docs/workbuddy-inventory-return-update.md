# 物品栏返回修复与WorkBuddy原应用更新

更新补丁（约46 MB）：https://raw.githubusercontent.com/huangzhoule24-sketch/-/e01165dd063bd437cefdd19c1c38940a7c07f8c0/downloads/shanhai-inventory-return-workbuddy-update.zip

可直接复制的WorkBuddy指令：https://raw.githubusercontent.com/huangzhoule24-sketch/-/e01165dd063bd437cefdd19c1c38940a7c07f8c0/instructions/workbuddy-update.txt

新版为SH-WEB-R9-INVENTORY-R1。手机版“物品”打开独立、可滚动的物品栏，顶部有“关闭”，底部有固定“返回餐厅”。物品详情可返回物品栏，反复开关及旋转后时钟、负债、培训、施工与状态控件仍然保留。返回时维持原先的运行或手动暂停选择，音乐沿用当前进度。

旧问题已复现：物品开关调用桌面横向layout，把五个状态控件移进竖屏下隐藏的narrow_row，Phone.apply没有在此路径再次恢复这些控件。修复将手机物品页与桌面展开路径分开，手机布局继续拥有这些控件；经营数值、角色、美术音频、存档格式与电脑运行包保持原样。

## 在WorkBuddy中更新

1. 打开此前部署餐厅链接的同一个WorkBuddy项目。
2. 上传补丁ZIP，并发送包内“给WorkBuddy的更新指令.txt”的内容。
3. 让WorkBuddy先备份再应用文件更新，检查后重新部署当前应用，选择沿用现有应用与域名。
4. 发布后刷新原游戏链接，检查“物品→返回餐厅→再开物品→顶部关闭”，再检查物品详情返回和横竖屏切换。

可直接发送简短指令：

> 请在当前项目应用这个物品栏补丁，先备份，再对实际网站根目录运行apply-update.py --site-root <根目录>。它会识别组合包或独立手机版并检查资源。保留我的介绍页、电脑版、自动识别入口和浏览器存档，验证物品栏返回、重复开关和横竖屏切换后，重新部署当前应用，继续使用原网址。

脚本会识别组合包的portrait/game，或独立手机版的game；核对旧手机版来源、备份必要文件、覆盖补丁、验证全部原始及压缩资源分片。自定义介绍页会保留；出现资源错误会恢复本次覆盖的旧文件。它只改本地文件，不自行操作WorkBuddy或发布网站。

不能运行Python时，包内完整指令也给出手工覆盖方法。组合包把site/内部内容覆盖原网站根目录；独立手机版使用site/portrait/game内部文件与alternatives/game-index-standalone.html。两种目录不要混用，不能把补丁的site/作为额外网站路径套上去。

更新后仍见旧画面，可给原游戏页面地址加?v=inventory-r1重新打开；原地址已有查询参数时用&v=inventory-r1。不要清除网站存储，以免删除存档。WorkBuddy界面按钮名称可能随版本变化，目标是在已有应用重新发布，而非创建新应用。

## 验证与交付

修复前的原生检查复现6项失败（物品页未打开、五个状态控件隐藏）；修复后51项库存返回检查、56项竖屏、53项触摸、73项UI与11项音乐检查通过。浏览器48项检查、65次真实触摸操作通过，包含六步教学、实际订单、库存返回、英文、家具摆放、保存刷新及旋转，无脚本错误。两种补丁布局与测试运行包逐文件一致，另测试重复更新保留自定义介绍页及拒绝无关运行包。

补丁匿名HTTP 200、完整SHA/CRC以及真实Chromium点击下载通过；长度45970508字节，SHA256为0c022ea661b1ad41266e3b0c33390e6a6df1003cc4c802fba4e87dbbe5920cae。Range请求返回206并核对真实区间字节，可供支持断点续传的下载器恢复。实际速度取决于用户网络，没有声称大陆网络或实体Safari已验收。

我们的GitHub站点更新为171dc41f719b4bd83abfdc589bb017f4d3c9c9a9，仅变更portrait/下11个文件；电脑及自动入口未动。WorkBuddy原项目仍需用户在该平台执行上面的更新和重新部署，不能把GitHub发布当成已替用户更新WorkBuddy。

源码e5333a5044cde2936c34aad86d0ea0f6e531efb7081b31a51e8ba819519fe737（842项）。证据docs/validation-artifacts/inventory-return-r1；工具build_inventory_fix_site.py、package_inventory_workbuddy_update.py、apply_inventory_site_update.py、verify_inventory_update.py和publish_inventory_fix.py。

此前fc676980的162 MB整包及c132a9的两份81 MB直链包均为修复前版本。后续重新交付完整资源包应以当前修复站点为基准，不能把旧包称为已修复版。
