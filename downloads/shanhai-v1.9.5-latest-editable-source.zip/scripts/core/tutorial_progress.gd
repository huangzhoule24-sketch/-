extends RefCounted
## Persistent facts for v1.5 guidance. Rendering and operation locks stay in the UI.
static var _config: Dictionary = {}

static func config() -> Dictionary:
	if _config.is_empty():
		var data = JSON.parse_string(FileAccess.get_file_as_string("res://config/tutorial.json"))
		_config = data if data is Dictionary else {}
	return _config

static func ensure(model) -> Dictionary:
	if not model.state.get("tutorial") is Dictionary: model.state["tutorial"] = {}
	var p: Dictionary = model.state.tutorial
	var legacy_finished = not p.is_empty() and int(p.get("version", 0)) < 2 and bool(p.get("finished", false))
	for key in ["completed_steps", "actions", "deferred", "stage_completed", "panel_opened", "panel_closed", "ready_to_ack"]:
		if not p.get(key) is Array: p[key] = []
	if int(p.get("version",0)) < 2:
		var valid_ids = config().get("steps",[]).map(func(step): return str(step.id))
		p.completed_steps = p.completed_steps.filter(func(id): return id in valid_ids)
	p["version"] = 2
	p["skipped"] = false
	if legacy_finished or bool(model.state.get("migration_v15", {}).get("legacy_campaign", false)):
		for step in config().get("steps", []):
			if not step.id in p.completed_steps: p.completed_steps.append(step.id)
	if not p.has("finished"): p["finished"] = false
	if not p.has("seen_stage"): p["seen_stage"] = int(model.state.get("stage", 0))
	refresh(model, p)
	return p

static func refresh(model, p: Dictionary) -> void:
	var data = config()
	for step in data.get("steps", []):
		if not step.id in p.completed_steps and condition(model, str(step.get("complete_condition", "")), p):
			if str(p.get("active_id","")) == str(step.id) and not str(step.get("complete_condition","")) in ["welcome_ack","income_ack"]:
				_append(p.ready_to_ack,str(step.id))
			else: p.completed_steps.append(step.id)
	p["finished"] = p.completed_steps.size() >= data.get("steps", []).size()
	for step in data.get("stage_steps", []):
		if int(step.stage) > int(model.state.get("stage", 0)) or step.id in p.stage_completed: continue
		var done = str(step.action) in p.actions or _existing_operation(model,str(step.action))
		match str(step.get("condition", "")):
			"research_completed": done = int(model.state.get("stats", {}).get("research_success", 0)) > 0
		if step.action == "membership_enable": done = done or bool(model.state.get("expansion", {}).get("membership", {}).get("enabled", false))
		if step.action == "bond_active" and model.has_method("active_bonds"): done = not model.active_bonds().is_empty()
		if done:
			if str(p.get("active_id","")) == str(step.id): _append(p.ready_to_ack,str(step.id))
			else: p.stage_completed.append(step.id)
			p.deferred.erase(step.id)

static func condition(model, id: String, p: Dictionary) -> bool:
	match id:
		"welcome_ack", "income_ack", "bill_view": return id in p.actions
		"staff_closed": return "员工" in p.panel_opened and "员工" in p.panel_closed
		"promoted": return "marketing" in p.actions or "promotion" in p.actions or not str(model.state.get("last_promotion_kind", "")).is_empty()
		"served_order": return int(model.state.get("served", 0)) > 0
	return false

static func observe(model, action: String, args: Dictionary = {}) -> void:
	var p = ensure(model)
	if action.begins_with("panel:"):
		var name = action.substr(6)
		if not name in p.panel_opened: p.panel_opened.append(name)
		if name in ["账单", "日结账单"]: _append(p.actions, "bill_view")
		if name == "世界排行榜": _append(p.actions, "ranking_view")
	elif action.begins_with("closed:"):
		_append(p.panel_closed, action.substr(7))
	else:
		_append(p.actions, action)
	refresh(model, p)

static func _append(array: Array, value: String) -> void:
	if not value in array: array.append(value)

static func current(model) -> Dictionary:
	if model.sandbox!=null:return {}
	if str(model.state.get("mode", "")) != "full": return {}
	var p = ensure(model)
	for step in config().get("steps", []):
		if not step.id in p.completed_steps:
			p["active_id"] = str(step.id)
			return step
	for step in config().get("stage_steps", []):
		if int(step.stage) <= int(model.state.get("stage", 0)) and not step.id in p.stage_completed and not step.id in p.deferred:
			p["active_id"] = str(step.id)
			return step
	return {}

static func pending_stage(model) -> Array:
	var p = ensure(model)
	return config().get("stage_steps", []).filter(func(step): return int(step.stage) <= int(model.state.get("stage", 0)) and not step.id in p.stage_completed)

static func defer(model) -> void:
	var step = current(model)
	if step.has("stage"): _append(ensure(model).deferred, str(step.id))

static func resume(model, id: String) -> void:
	ensure(model).deferred.erase(id)

static func allows_panel(model, name: String) -> bool:
	if name in ["声音设置","菜牌核对"]: return true
	var step = current(model)
	if step.is_empty() or str(step.id) in ensure(model).ready_to_ack: return true
	if name in ["欢迎", "文化简介", "图鉴", "经营状态", "今日收支结算", "现金流预警", "经营失败", "事件结果", "员工详情", "待办汇总", "开发者选项", "美术资源", "数值面板", "说明", "破产救援", "贷款"]: return true
	if step.has("stage") and name in ["待办汇总", "系统", "库存供应", "采购设置", "账单", "资金流水"]: return true
	var destinations: Array = [str(step.get("destination", ""))]
	match str(step.id):
		"staff": destinations.append_array(["招聘", "员工培养"])
		"promotion", "first_order": destinations.append_array(["宣传营销", "宣传", "更多"])
		"bill": destinations.append_array(["系统", "账单", "资金流水", "日结账单"])
	if step.has("stage"): destinations.append_array(["更多", "员工", "招聘", "员工培养", "世界排行榜"])
	return name in destinations

static func allows_button(model, id: String) -> bool:
	if id == "system:audio" or id.begins_with("audio:"): return true
	if id.begins_with("scene:"):return true
	var step = current(model)
	if step.is_empty() or str(step.id) in ensure(model).ready_to_ack: return true
	if id.begins_with("daily:") or id.begins_with("failure:") or id.begins_with("requirement:") or id.begins_with("revision:warning_ack") or id.begins_with("revision:rescue_decline") or id.begins_with("event:result:") or (id.begins_with("event:") and model.full_rules.world.has_notice()):return true
	if id.begins_with("employee:") or id.begins_with("status:"):return str(step.id)=="staff" or step.has("stage")
	if id.begins_with("culture:") or id.begins_with("dev:") or id.begins_with("art:") or id.begins_with("source:") or id.begins_with("catalog:") or id.begins_with("start:") or id.begins_with("tutorial:") or id.begins_with("decor:"): return true
	if id in ["todo:summary", "todo:primary", "panel:close", "panel:back", "time:pause", "time:menu", "time:1", "time:2", "time:3", "time:4", "system:save", "system:developer"]: return true
	if id.begins_with("rescue:") or id.begins_with("finance:") or id.begins_with("bill:"): return true
	if id.begins_with("nav:"): return allows_panel(model,preload("res://scripts/ui/interface_policy.gd").destination(id.substr(4)))
	if id.begins_with("full:open:"): return allows_panel(model, id.substr(10))
	if step.has("stage"):
		if id.begins_with("full:"):
			var action = id.split(":")[1]
			return action in [str(step.action), "purchase", "central_unlock", "delivery_toggle", "branch_assign", "set_shift", "set_rest", "recruit", "synthesize", "set_auto_procure", "set_procurement_strategy", "set_procurement_quantity", "buy_skill_book"]
		if id.begins_with("place:") or id.begins_with("shift:"): return str(step.action) in ["buy_decoration", "bond_active"]
		return id in ["system:ledger", "system:procurement", "next:period", "next:day", "ranking:view"]
	match str(step.id):
		"welcome", "income": return false
		"staff": return false
		"promotion", "first_order": return id.begins_with("full:marketing:flyer") or id in ["promotion:flyer", "next:period"]
		"bill": return id in ["system:ledger", "system:bills", "bill:settle", "next:day"]
	return false

static func _existing_operation(model, action: String) -> bool:
	var state: Dictionary = model.state
	var management: Dictionary = state.get("management",{})
	var expansion: Dictionary = state.get("expansion",{})
	match action:
		"set_price": return not management.get("price_overrides",{}).is_empty()
		"upgrade_skill":
			for employee in model.employees:
				if int(employee.get("skill_level",1)) > 1: return true
		"buy_decoration": return int(state.get("decorations_purchased",0)) > 0
		"campaign": return not expansion.get("campaigns",[]).is_empty()
		"delivery_accept": return int(expansion.get("delivery_completed",0)) > 0 or not expansion.get("delivery_orders",[]).is_empty()
		"branch_open":
			for branch in expansion.get("branches",{}).values():
				if bool(branch.get("open",false)): return true
		"central_cook": return not expansion.get("central",{}).get("jobs",[]).is_empty() or not expansion.get("central",{}).get("stock",{}).is_empty()
		"supply_send": return not expansion.get("central",{}).get("shipments",[]).is_empty()
		"explore": return not expansion.get("explorations",[]).is_empty() or not expansion.get("exploration_history",[]).is_empty()
		"awaken":
			for employee in model.employees:
				if bool(employee.get("awakened",false)): return true
		"compete": return int(expansion.get("competition",{}).get("attempts",0)) > 0
	return false

static func validate_state(p: Dictionary, stage: int) -> bool:
	if not p.get("version") is int and not p.get("version") is float: return false
	if float(p.version) != 2: return false
	for key in ["completed_steps","actions","deferred","stage_completed","panel_opened","panel_closed","ready_to_ack"]:
		if key == "ready_to_ack" and not p.has(key): continue
		if not p.get(key) is Array or p[key].size() > 256: return false
		var unique: Array = []
		for value in p[key]:
			if not value is String or value.length() > 160 or value in unique: return false
			unique.append(value)
	for key in ["finished","skipped"]:
		if not p.get(key) is bool: return false
	if bool(p.skipped): return false
	if not (p.get("seen_stage") is int or p.get("seen_stage") is float) or float(p.seen_stage) < 0 or float(p.seen_stage) != floorf(float(p.seen_stage)) or int(p.seen_stage) > 4: return false
	var data = config()
	var base_ids: Array = data.get("steps",[]).map(func(step): return str(step.id))
	var stage_ids: Array = data.get("stage_steps",[]).map(func(step): return str(step.id))
	for id in p.get("ready_to_ack",[]):
		if not id in base_ids and not id in stage_ids: return false
		if id in p.completed_steps or id in p.stage_completed: return false
		for step in data.stage_steps:
			if step.id == id and int(step.stage) > stage: return false
	for id in p.completed_steps:
		if not id in base_ids: return false
	for id in p.deferred:
		if not id in stage_ids: return false
	for id in p.stage_completed:
		if not id in stage_ids: return false
		for step in data.stage_steps:
			if step.id == id and int(step.stage) > stage: return false
	if bool(p.finished) != (p.completed_steps.size() == base_ids.size()): return false
	return true

static func acknowledge(model) -> void:
	var step = current(model)
	if step.is_empty(): return
	var p = ensure(model)
	if not str(step.id) in p.ready_to_ack: return
	_append(p.stage_completed if step.has("stage") else p.completed_steps, str(step.id))
	p.ready_to_ack.erase(str(step.id))
	p["active_id"] = ""
	refresh(model,p)
