extends "res://scripts/core/demo_rules.gd"

# Full campaign adapter. Legacy demo saves remain readable without rewriting their rules.
var management
var world
var expansion
var effects
var story
var preferences
var finance
var customer_service
var synergies
var sidequests
var revision
var rescue
var visitors
var revision18
var revision19
var dollhouse
var culture_experience
var _validation_grid: Dictionary={}
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const FINANCE_ACTIONS = ["loan_apply", "loan_repay", "bankruptcy_settle", "bankruptcy_restart", "bankruptcy_load", "loan_collection_ack"]
const SIDEQUEST_ACTIONS = ["gift", "care", "sidequest_read", "sidequest_choice", "sidequest_finish", "baize_page", "lore_read"]
var config: Dictionary = {}
var _source_config: Dictionary = {}
const BalanceRegistry = preload("res://scripts/core/balance_registry.gd")
var _validating_full = false
const STORY_ACTIONS = ["story_claim","festival_invitation","seasonal_activity","monthly_story_claim"]
const MANAGEMENT_ACTIONS = ["train_attribute", "train_secondary", "switch_role", "upgrade_skill", "raise_wage", "comfort", "set_shift", "research", "set_price", "set_menu", "purchase", "unlock_supplier", "auto_procure", "set_auto_procure", "discard_stock", "set_procurement_strategy", "set_procurement_quantity"]

func _init(host: RefCounted) -> void:
	super(host)
	_source_config = host._read_json("res://config/full_game.json")
	config = _source_config.duplicate(true)
	refresh_balance()
	management = preload("res://scripts/core/management_rules.gd").new(host)
	world = preload("res://scripts/core/world_events.gd").new(host)
	expansion = preload("res://scripts/core/expansion_rules.gd").new(host)
	effects = preload("res://scripts/core/effect_resolver.gd").new(host)
	story = preload("res://scripts/core/story_rules.gd").new(host)
	preferences = preload("res://scripts/core/customer_preferences.gd").new(host)
	finance = preload("res://scripts/core/finance_rules.gd").new(host, self)
	customer_service = preload("res://scripts/core/customer_service.gd").new(host)
	synergies = preload("res://scripts/core/synergy_rules.gd").new(host)
	sidequests = preload("res://scripts/core/sidequest_rules.gd").new(host)
	revision = preload("res://scripts/core/revision171.gd").new(host)
	rescue = preload("res://scripts/core/rescue171.gd").new(host)
	visitors = preload("res://scripts/core/special_visitors.gd").new(host)
	revision18 = load("res://scripts/core/revision18.gd").new(host)
	revision19 = load("res://scripts/core/revision19.gd").new(host)
	dollhouse = preload("res://scripts/core/dollhouse_rules.gd").new(host)
	culture_experience = preload("res://scripts/core/cultural_experience.gd").new(host)
	expansion.cultural_adapter=culture_experience
	for definition in sidequests.additional_dishes():
		if host._dish(str(definition.id)).is_empty(): host.dishes.append(definition.duplicate(true))

func is_full() -> bool:
	return str(_m().state.get("mode", "normal")) == "full"

func setting(section: String, key: String, fallback: Variant) -> Variant:
	if section=="layout" and key in ["width","height"]:
		var d=_validation_grid if _validating_full else _m().state.get("revision191",{})
		if not d.is_empty():return d.get("grid_"+key,fallback)
	if (is_full() or _validating_full) and config.get(section, {}).has(key):
		return config[section][key]
	return super(section, key, fallback)

func ensure_state_defaults() -> void:
	super()
	if not is_full(): return
	var m = _m()
	var defaults = {"campaign_claimed": [], "stage_rewards": [], "tutorial_researched": false,
		"ledger": {"sales": 0.0, "cost_of_sales": 0.0, "expenses": 0.0, "procurement": 0.0, "financing": 0.0, "capital": 0.0, "records": []},
		"promotion_bonus": 0.0, "wage_arrears": 0.0, "rent_arrears": 0.0, "day_reports": [],
		"weekly_count": 0, "monthly_count": 0, "last_promotion_kind": "", "developer_mode": false}
	for key in defaults:
		if not m.state.has(key): m.state[key] = defaults[key].duplicate(true) if defaults[key] is Dictionary or defaults[key] is Array else defaults[key]
	management.ensure_state()
	world.ensure_state()
	expansion.ensure_state()
	effects.ensure_state()
	story.ensure_state()
	finance.ensure_state()
	customer_service.ensure_state()
	synergies.ensure_state()
	sidequests.ensure_state()
	revision.ensure_state()
	rescue.ensure_state()
	visitors.ensure_state()
	revision18.ensure_state()
	revision19.ensure_state()
	dollhouse.ensure_state()
	culture_experience.ensure_state()
	Guide.ensure(m)
	for employee in m.employees: m.initialize_employee_motion(employee)

func start_full() -> void:
	var m = _m()
	m.reset_game()
	m.state.mode = "full"
	m.speed = int(m._b("time.default_speed"))
	dollhouse.fresh_start=true
	ensure_state_defaults()
	m._next_spawn_minute = int(m.state.total_minutes) + m._spawn_interval()
	m._log("白泽：从有间小馆启程，先稳住现金、接待食客，再开创三界食肆。")
	m.changed.emit()

func active_limit() -> int:
	if _m().sandbox!=null:return maxi(30,_m().employees.size())
	if not is_full(): return super()
	return int(_m().balance.get("stage.%d.employee_limit" % int(_m().state.stage), 3))

func active(id: String) -> bool:
	var finishing=revision18!=null and revision18.draining(id)
	if not super(id) and not finishing: return false
	var m = _m()
	var e: Dictionary = m._employee(id)
	if e.is_empty() or bool(e.get("resting",false)) or int(e.get("v18_clean_until",0))>int(m.state.total_minutes):return false
	if revision != null and m.state.has("revision171") and revision.is_building(id): return false
	return int(e.get("management_until", 0)) <= int(m.state.total_minutes) and int(e.get("expansion_until", 0)) <= int(m.state.total_minutes) and str(e.get("branch_id", "")).is_empty()

func skills_enabled(id: String) -> bool:
	return not _m()._employee_config(id).is_empty() if is_full() else super(id)

func skill_scale(worker: Dictionary) -> float:
	return management.skill_multiplier(worker)

func bond_bonus(effect_type: String) -> float:
	return 0.0 if is_full() else super(effect_type)

func active_bonds() -> Array[Dictionary]:
	if is_full(): return world.active_bonds()
	return super()

func traffic_multiplier() -> float:
	var result: float = super()
	if not is_full(): return result
	var sources: Array = [result, 1.0 + expansion.traffic_bonus()]
	if active("ying_zhao") and synergies.bonus("yingzhao_traffic_cancel") > -1.0: sources.append(1.0 + _m()._b("coeff.traffic_bonus") * skill_scale(_m()._employee("ying_zhao")))
	var demand: float = effects.traffic_multiplier()
	if effects.has_method("rain_traffic_bonus"):
		sources.append(1.0 + effects.rain_traffic_bonus())
		demand = effects.menu_demand_multiplier()
	return maxf(0.05, resolve_effect("traffic", sources, {"weather":str(_m().state.world.get("weather", "clear"))}) * world.traffic_environment() * price_demand() * demand * customer_service.traffic_multiplier())

func resolve_effect(effect: String, values: Array, context: Dictionary = {}) -> float:
	var sources: Array = values.duplicate()
	sources.append_array(world.effect_multipliers(effect, str(context.get("category", "")), str(context.get("employee_id", ""))))
	for source in synergies.sources(context):
		if str(source.effect) == effect: sources.append(1.0 + float(source.value))
	return unique_multiplier(sources)

func unique_multiplier(values: Array) -> float:
	var positive: float = 0.0
	var negative: float = 0.0
	for value in values:
		positive = maxf(positive, float(value) - 1.0)
		negative = minf(negative, float(value) - 1.0)
	return maxf(0.01, 1.0 + positive + negative)

func price_demand() -> float:
	var m = _m()
	var total = 0.0
	var count = 0
	# Explicit player markups affect demand, without counting quality or species bonuses.
	var prices: Dictionary = m.state.get("management", {}).get("prices", {})
	for id in m.state.menu_enabled:
		if id in m.state.unlocked_dishes:
			var base: float = float(m.state.management.base_prices.get(str(id), m._dish(str(id)).get("price", 1)))
			total += float(prices.get(str(id), float(m._dish(str(id)).get("price", base)) / maxf(1, base)))
			count += 1
	return clampf(1.0 - ((total / count if count > 0 else 1.0) - 1.0) * m._b("dish.price_sensitivity"), 0.1, 2.0)

func price_multiplier() -> float:
	return super() # Dish-specific world/management modifiers apply at reservation.

func ingredient_multiplier(worker: Dictionary) -> float:
	var value: float = super(worker)
	if is_full(): value = resolve_effect("ingredient", [value * effects.ingredient_multiplier(worker)])
	return maxf(0.01, value)

func ingredient_for_dish(worker: Dictionary, dish: Dictionary) -> float:
	var own: float = 1.0
	if str(worker.get("id", "")) == "tao_tie" and active("tao_tie"): own += coefficient("taotie_ingredient_cost", "coeff.ingredient_cost_mult") * skill_scale(worker)
	return resolve_effect("ingredient", [own, float(management.modifiers(str(dish.id), worker).get("ingredient_mult", 1.0))])

func quality_multiplier(worker: Dictionary, dish: Dictionary) -> float:
	var value: float = super(worker, dish)
	if not is_full(): return value
	value = 1.0 + (value - 1.0) * skill_scale(worker)
	var sources: Array = [value, effects.quality_multiplier(worker,dish)]
	var modifiers: Dictionary = management.modifiers(str(dish.id), worker)
	if modifiers.get("quality_sources") is Dictionary:
		for bonus in modifiers.quality_sources.values(): sources.append(1.0 + float(bonus))
	else: sources.append(float(modifiers.get("quality_mult", 1)))
	return resolve_effect("quality", sources, {"category":str(dish.category),"employee_id":str(worker.id)})

func speed_multiplier(worker: Dictionary, task: String) -> float:
	var value: float = super(worker, task)
	if not is_full(): return value
	value = 1.0 + (value - 1.0) * skill_scale(worker)
	var kind = {"cooking": "cooking_speed", "serving": "serving_speed", "cleaning": "cleaning_speed"}.get(task, "")
	var sources: Array = [value]
	if kind != "": sources.append_array(world.effect_multipliers(kind, "", str(worker.id)))
	if task in ["ordering", "serving", "cleaning"] or (task == "paying" and str(worker.get("role","")) == "waiter"): sources.append(world.modifier("waiter_speed"))
	if task == "paying": sources.append(1.0 + float(_m().state.get("cashier_speed_bonus", 0)))
	return unique_multiplier(sources)

func checkout_multiplier(worker: Dictionary) -> float:
	if is_full() and not worker.is_empty() and not dollhouse.capable(worker,"salesman"):return 1.0
	var value: float = super(worker)
	return 1.0 + (value - 1.0) * skill_scale(worker) if is_full() else value

func tip_bonus(worker: Dictionary) -> float:
	var value: float = super(worker)
	return resolve_effect("tip", [1.0 + value * skill_scale(worker)]) - 1.0 if is_full() else value

func promote_kind(kind: String) -> Dictionary:
	var m = _m()
	var check = can_perform("marketing", {"kind": kind})
	if not check.ok: return check
	var prefix: String = {"flyer":"promotion", "social":"promotion.social", "blogger":"promotion.blogger", "influencer":"promotion.mythic"}[kind]
	var cost_key = prefix + ("_gems" if kind == "influencer" else "_cost")
	if kind == "flyer": cost_key = "promotion.cost"
	var cost: float = m._b(cost_key)
	if kind == "influencer": m.state.gems = int(m.state.gems) - int(cost)
	else: m.change_cash(-cost, "marketing", "宣传：" + kind)
	var bonus_key = "promotion.bonus" if kind == "flyer" else prefix + "_bonus"
	var duration_key = "promotion.duration" if kind == "flyer" else prefix + "_duration"
	var sales = 1.0
	var promoter: Dictionary = {}
	for e in m.employees:
		if active(str(e.id)) and dollhouse.capable(e,"salesman"):
			var attrs: Dictionary = e.attributes
			var factor: float = minf(m._b("promotion.sales_max_multiplier"), 1.0 + float(attrs.get("charm", 0)) * m._b("promotion.sales_charm_bonus") + float(attrs.get("eloquence", 0)) * m._b("promotion.sales_eloquence_bonus"))
			if factor >= sales: sales = factor; promoter = e
	if active("ying_zhao") and str(promoter.get("id", "")) != "ying_zhao": world.on_hook("promote", {"employee_id":"ying_zhao", "kind":kind})
	if not promoter.is_empty():
		var fx: Dictionary = management.employee_effects(promoter)
		sales *= float(fx.get("promotion_mult", 1.0))
	m.state.promotion_bonus = m._b(bonus_key) * sales * world.modifier("promotion") * effects.promotion_multiplier()
	m.state.promotion_until = int(m.state.total_minutes) + int(m._b(duration_key))
	m.state.last_promotion_kind = kind
	world.on_hook("promote", {"employee_id":str(promoter.get("id", "")), "kind":kind, "dish_id": "", "quality": average_quality()})
	m._next_spawn_minute = mini(m._next_spawn_minute, int(m.state.total_minutes) + m._spawn_interval())
	return {"ok":true, "message":"宣传已启动，持续 %d 分钟" % int(m._b(duration_key))}

func average_quality() -> float:
	var m = _m()
	var total = 0.0
	var count = 0
	for e in m.employees:
		if active(str(e.id)) and str(e.role) in ["chef", "all"]:
			total += m._b("prototype.base_quality") + float(e.attributes.get("cooking", 0)) * m._b("prototype.quality_per_cooking_point")
			count += 1
	return total / count if count > 0 else 0.0

func tick() -> void:
	if not is_full(): super(); return
	revision.tick()
	rescue.tick()
	management.tick_minute()
	world.tick_minute()
	expansion.tick_minute()
	effects.tick_minute()
	story.tick_minute()
	sidequests.on_counter_pairs(synergies.tick_minute())
	sidequests.tick_minute()
	Guide.ensure(_m())
	if bool(_m().state.expansion.competition.first_reward_claimed): _m().state.completed = true
	revision18.tick()
	revision19.tick()
	dollhouse.tick()
	culture_experience.tick()

func on_day() -> void:
	management.on_day()
	world.on_day()
	expansion.on_day()
	story.on_day()
	sidequests.on_day()
	var m = _m()
	var day: int = int(m.state.total_minutes) / int(m._b("day.minutes"))
	if day % maxi(1,int(m._b("time.days_per_week"))) == 0: m.state.weekly_count = int(m.state.weekly_count) + 1; m._log("白泽：本周经营总结已更新。")
	if day % maxi(1,int(m._b("time.days_per_month"))) == 0: m.state.monthly_count = int(m.state.monthly_count) + 1; m._log("月度全量存档已备份。")

func upgrade_restaurant() -> bool:
	if not is_full(): return super()
	var m = _m()
	var check = can_perform("upgrade")
	if not check.ok: m._notify(str(check.reason)); return false
	m.state.stage = int(m.state.stage) + 1
	var stage: int = int(m.state.stage)
	if not stage in m.state.stage_rewards:
		m.state.stage_rewards.append(stage)
		m.state.gems = int(m.state.gems) + int(config.stage.reward_gems[stage])
	m.state.last_stage_notice = stage
	world.on_hook("stage", {"stage":stage})
	m._notify("升级为%s！新经营系统已解锁。" % str(config.stage_names[stage]))
	m.changed.emit()
	m.autosave_requested.emit()
	return true

func quest_status() -> Array[Dictionary]:
	if not is_full(): return super()
	var m = _m()
	var result: Array[Dictionary] = []
	for definition in config.milestones:
		var progress = 0
		match str(definition.type):
			"served": progress = int(m.state.served)
			"purchases": progress = int(m.state.stats.purchases)
			"research_success": progress = int(m.state.stats.research_success)
			"debt_free": progress = 1 if float(m.state.debt) <= 0 else 0
			"collection": progress = m.employees.size()
			"recipes": progress = m.state.unlocked_dishes.size()
			"stage": progress = int(m.state.stage)
		var q: Dictionary = definition.duplicate(true)
		q.merge({"progress":progress, "complete":progress >= int(q.target), "claimed":str(q.id) in m.state.campaign_claimed, "unlocked":true, "description":"完成经营目标后领取一次奖励", "reward_summary":"钞票%d · 灵石%d" % [int(q.cash),int(q.gems)]})
		result.append(q)
	return result

func claim_quest(id: String) -> bool:
	if not is_full(): return super(id)
	var m = _m()
	for q in quest_status():
		if str(q.id) != id or not q.complete or q.claimed: continue
		m.state.campaign_claimed.append(id)
		m.change_cash(float(q.cash), "reward", "目标奖励：" + str(q.get("name", q.id)))
		m.state.gems = int(m.state.gems) + int(q.gems)
		if q.has("contract"):
			m.state.contracts.append(str(q.contract)); m.state.hire_tickets = m.state.contracts.size()
		m.changed.emit(); m.autosave_requested.emit()
		return true
	return false

func pending_event() -> Dictionary:
	return world.pending_event() if is_full() else super()

func choose_event(id: String, option_index: int) -> bool:
	if not is_full(): return super(id, option_index)
	var event: Dictionary = world.pending_event()
	if str(event.get("id", "")) != id: return false
	var options: Array = event.get("options", [])
	if option_index < 0 or option_index >= options.size(): return false
	var result: Dictionary = world.choose(str(options[option_index].get("id", str(option_index))))
	if result.ok: _m().changed.emit()
	return bool(result.ok)

func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	var m = _m()
	if action in culture_experience.ACTIONS: return culture_experience.can(action,args)
	if action in revision18.ACTIONS:return revision18.can(action,args)
	if action in ["daily_ack","daily_auto"]:return {"ok":true}
	if action=="guest_adopt":return {"ok":visitors.s().adoptions.any(func(a):return int(a.serial)==int(args.get("serial",0)) and not a.claimed)}
	if action == "dismiss_employee": return revision.dismissal_quote(str(args.get("id","")))
	if action in rescue.ACTIONS: return rescue.can(action,args)
	if action in FINANCE_ACTIONS: return finance.can_perform(action, args)
	if action in SIDEQUEST_ACTIONS: return sidequests.can_perform(action, args)
	if action == "feedback_ack": return customer_service.can(action, args)
	if action in ["festival_prepare", "kunlun_counter"]: return world.can_perform(action,args)
	if action == "settle_arrears":
		return {"ok":float(m.state.cash)>0 and float(m.state.interest_arrears)+float(m.state.wage_arrears)+float(m.state.rent_arrears)>0,"reason":"没有待清偿欠款或现金不足"}
	if action in STORY_ACTIONS: return story.can_perform(action,args)
	if action == "upgrade":
		var stage: int = int(m.state.stage) + 1
		if stage > 4: return {"ok":false,"reason":"已达到三界集团阶段"}
		if float(m.state.total_revenue) < m._b("stage.%d.revenue" % stage) or int(m.state.reputation) < m._b("stage.%d.reputation" % stage): return {"ok":false,"reason":"累计营业额与声望尚未同时达标"}
		return {"ok":true,"reason":""}
	if action == "marketing":
		var kind: String = str(args.get("kind", "flyer"))
		if not kind in ["flyer","social","blogger","influencer"]: return {"ok":false,"reason":"未知宣传类型"}
		if kind == "influencer" and int(m.state.stage) < int(m._b("promotion.mythic_stage")): return {"ok":false,"reason":"阶段2解锁异兽网红"}
		if kind == "blogger" and average_quality() < m._b("promotion.blogger_quality_threshold"): return {"ok":false,"reason":"当班菜品品质需要达到75"}
		var key: String = {"flyer":"promotion.cost","social":"promotion.social_cost","blogger":"promotion.blogger_cost","influencer":"promotion.mythic_gems"}[kind]
		if float(m.state.gems if kind == "influencer" else m.state.cash) < m._b(key): return {"ok":false,"reason":"宣传资源不足"}
		return {"ok":true,"reason":""}
	if action == "claim":
		for q in quest_status():
			if str(q.id) == str(args.get("id", "")): return {"ok":bool(q.complete) and not bool(q.claimed),"reason":"" if q.complete and not q.claimed else "目标未完成或奖励已领取"}
		return {"ok":false,"reason":"未知目标"}
	if action == "tutorial_research":
		return {"ok":false,"reason":"v1.5在阶段1解锁正常研发，初始引导无需试制"}
	if action == "recruit":
		var kind: String = str(args.get("kind", "normal"))
		if not kind in ["normal", "advanced", "contract"]: return {"ok":false,"reason":"未知招聘方式"}
		if kind == "contract": return {"ok":not m.state.contracts.is_empty(),"reason":"" if not m.state.contracts.is_empty() else "没有可使用的员工契约"}
		var cost: float = m._b("hire.ticket_cost_"+kind)
		var pixiu: Dictionary = m._employee("pi_xiu")
		if kind in ["normal","advanced"] and not pixiu.is_empty() and str(pixiu.get("branch_id","")) == "": cost = ceilf(cost*(1+coefficient("pixiu_hire_cost","coeff.hire_cost_mult")))
		var enough: bool = float(m.state.gems if kind == "advanced" else m.state.cash)>=cost
		return {"ok":enough,"reason":"" if enough else "招聘资源不足","cost":cost,"currency":"gems" if kind=="advanced" else "cash"}

	if action == "pay_fines": return {"ok":float(m.state.world.get("unpaid_fines",0)) > 0 and float(m.state.cash)>0,"reason":"没有可补缴罚款或现金不足"}
	if action == "zhulong_shift": return {"ok":active("zhu_long") and m.business_open(),"reason":"需要烛龙当班且处于营业时段"}
	if action in MANAGEMENT_ACTIONS and management.has_method("can_perform"): return management.can_perform(action,args)
	if expansion.has_method("can_perform"): return expansion.can_perform(action,args)
	return {"ok":true,"reason":""}

func perform(action: String, args: Dictionary = {}) -> Dictionary:
	if action == "auto_procure": action = "set_auto_procure"
	var m = _m()
	if not is_full(): return {"ok":false,"reason":"请先进入完整经营模式"}
	ensure_state_defaults()
	if bool(m.state.finance.rescue.pending) and not action in FINANCE_ACTIONS and not action in rescue.ACTIONS:
		return {"ok":false,"reason":"请先选择破产救援方式"}
	if action in culture_experience.ACTIONS: return culture_experience.perform(action,args)
	if action in revision18.ACTIONS:return revision18.perform(action,args)
	if action == "daily_ack":
		revision.s().daily_seen=int(m.state.finance.last_bill_day)
		revision.s().daily_pending=false
		m.state.finance.summary_pending=false
		m.changed.emit()
		return {"ok":true,"reason":"已确认日结收支"}
	if action == "daily_auto":
		if not args.get("enabled") is bool:return {"ok":false,"reason":"请选择是否自动弹出日报"}
		revision.s().daily_auto=bool(args.enabled)
		return {"ok":true,"reason":"日结展示设置已保存"}
	if action in rescue.ACTIONS: return rescue.perform(action,args)
	if action == "dismiss_employee":
		var departure: Dictionary = revision.dismiss(str(args.get("id","")))
		m.changed.emit()
		return departure
	if action == "guest_adopt":
		var adopted: Dictionary = visitors.adopt(int(args.get("serial",0)))
		m.changed.emit()
		return adopted
	if action in FINANCE_ACTIONS:
		var financial: Dictionary = finance.perform(action, args)
		if financial.get("request_restart", false): financial = m.restart_campaign_with_keepsakes()
		if financial.get("request_load", false): financial = m.load_recovery_save()
		m.changed.emit()
		return financial
	if action in SIDEQUEST_ACTIONS:
		var quest_result: Dictionary = sidequests.perform(action, args)
		if quest_result.get("ok", false): Guide.observe(m, action, args); m.changed.emit()
		return quest_result
	if action == "feedback_ack": return customer_service.perform(action, args)
	var employee_id: String = str(args.get("employee_id", args.get("id", "")))
	if employee_id != "" and not effects.instruction_allowed(m._employee(employee_id)):
		return {"ok":false,"reason":"梼杌暂时拒绝这次指令，没有扣除资源"}
	var before_cash: float = float(m.state.cash)
	var before_price: float = float(m._dish(str(args.get("dish_id", args.get("id", "")))).get("price", 0))
	var result: Dictionary
	match action:
		"marketing", "promote": result = promote_kind(str(args.get("kind", "flyer")))
		"upgrade": result = {"ok":upgrade_restaurant()}
		"claim": result = {"ok":claim_quest(str(args.get("id", "")))}
		"recruit":
			var employee = recruit(str(args.get("kind", "normal")))
			result = {"ok":not employee.is_empty(),"employee":employee}
		"tutorial_research": result = can_perform(action, args)
		"settle_arrears": result = m.settle_arrears()
		"zhulong_shift", "pay_fines", "festival_prepare", "kunlun_counter": result = world.perform(action,args)
		_:
			if action in STORY_ACTIONS:
				result = story.perform(action,args)
				if bool(result.get("ok",false)) and action=="story_claim":culture_experience.on_story_claim(str(args.get("id","")))
			else: result = management.perform(action,args) if action in MANAGEMENT_ACTIONS else expansion.perform(action,args)
	if result.get("ok", false):
		sidequests.on_action(action, args, result)
		if action != "set_price" or not is_equal_approx(before_price, float(m._dish(str(args.get("dish_id", args.get("id", "")))).get("price", 0))): Guide.observe(m, action, args)
		var delta_cash: float = float(m.state.cash) - before_cash
		if action in ["branch_open", "central_unlock"]: record("capital", -delta_cash, action)
		elif action == "purchase": record("procurement", -delta_cash, action)
		elif delta_cash < 0 and action not in ["pay_fines", "settle_arrears", "kunlun_counter", "festival_prepare"] and not action in STORY_ACTIONS: record("expenses", -delta_cash, action)
		elif delta_cash > 0 and action == "claim": record("financing", delta_cash, "目标奖励")
		m.changed.emit()
	else:
		result["reason"] = str(result.get("reason", result.get("message", result.get("error", "条件尚未满足"))))
		m._notify(str(result.reason))
	return result

func record(kind: String, amount: float, description: String) -> void:
	var m = _m()
	if not is_full() or amount == 0: return
	var ledger: Dictionary = m.state.ledger
	ledger[kind] = float(ledger.get(kind,0)) + amount
	ledger.records.append({"minute":int(m.state.total_minutes),"type":kind,"amount":m._money(amount),"description":description})
	while ledger.records.size() > int(config.economy.record_limit): ledger.records.pop_front()

func snapshot() -> Dictionary:
	return {"management":management.snapshot(),"world":world.snapshot(),"expansion":expansion.snapshot(),"milestones":quest_status(),"story":story.snapshot(),"stage_names":config.stage_names,"finance":finance.snapshot(),"customer_service":customer_service.snapshot(),"sidequests":sidequests.snapshot(),"synergies":synergies.snapshot(),"effects":effects.snapshot()}

func validate_state(saved: Dictionary, saved_employees: Array, saved_scheduler: Array) -> bool:
	if str(saved.get("mode", "")) != "full": return super(saved,saved_employees,saved_scheduler)
	# Reuse legacy structural validation after adapting the campaign-only metadata.
	var legacy = saved.duplicate(true)
	legacy.mode = "demo" if not legacy.research_projects.is_empty() else "normal"
	legacy.completed = false
	legacy.quests_claimed = []
	legacy.event_queue = []
	legacy.event_history = []
	var old_limits = _m().demo_config.get("stage", {}).get("active_limits", [3,5])
	var old_tables = _m().demo_config.get("stage", {}).get("table_limits", [4,8])
	_m().demo_config.stage.active_limits = config.stage.active_limits
	_m().demo_config.stage.table_limits = config.stage.table_limits
	var legacy_employees: Array = saved_employees.duplicate(true)
	for project in legacy.research_projects:
		if str(project.get("employee_id", "")) != "bai_ze": continue
		for employee in legacy_employees:
			if str(employee.get("id", "")) == "bai_ze" and str(employee.get("role", "")) == "tutor": employee.role = "all"
	_validating_full = true
	_validation_grid=saved.get("revision191",{"grid_width":8,"grid_height":5})
	var valid: bool = super(legacy,legacy_employees,saved_scheduler)
	_validating_full = false
	_validation_grid={}
	_m().demo_config.stage.active_limits = old_limits
	_m().demo_config.stage.table_limits = old_tables
	for key in ["management","world","expansion","ledger"]:
		if not saved.get(key) is Dictionary: return false
	for key in ["campaign_claimed", "stage_rewards", "day_reports"]:
		if not saved.get(key) is Array: return false
	if not valid: return false
	if not management.validate_state(saved.management, saved_employees, int(saved.total_minutes)): return false
	if not expansion.validate_state(saved, saved_employees): return false
	if not world.validate_state(saved.world, saved_employees, int(saved.total_minutes)): return false
	for key in ["finance", "customer_service", "sidequests", "synergies"]:
		if not saved.get(key) is Dictionary: return false
	if not revision.validate(saved,saved_employees) or not rescue.validate(saved) or not visitors.validate(saved) or not revision18.validate(saved,saved_employees) or not revision19.validate(saved): return false
	if not finance.validate_state(saved.finance, int(saved.total_minutes)): return false
	if not customer_service.validate_state(saved, saved_employees, saved_scheduler): return false
	if not synergies.validate_state(saved.synergies, saved_employees, int(saved.total_minutes)): return false
	if not sidequests.validate_state(saved.sidequests, saved_employees, int(saved.total_minutes)): return false
	var hidden_id: String = str(management.config.get("hidden_recipe", {}).get("id", ""))
	if hidden_id in saved.unlocked_dishes and not bool(saved.management.get("hidden_unlocked", false)): return false
	if saved.has("story"):
		if not saved.story is Dictionary or not story.validate_state(saved.story, saved_employees,int(saved.total_minutes)): return false
	if not culture_experience.validate(saved): return false
	if not _valid_ledger(saved.ledger): return false
	if not saved.get("effect_resolution") is Dictionary: return false
	if not effects.validate_state(saved.effect_resolution, saved_employees, int(saved.total_minutes)): return false
	var resolved: Dictionary = saved.effect_resolution
	if not resolved.get("first_reviews") is Dictionary or not _m()._number(resolved.get("extra_income_total")) or float(resolved.extra_income_total) < 0: return false
	if not _m()._integer(resolved.get("prevented_escapes")): return false
	for id in resolved.first_reviews:
		if _m()._dish(str(id)).is_empty() or not _m()._integer(resolved.first_reviews[id]): return false
	if not saved.get("tutorial", {}) is Dictionary: return false
	if not saved.get("balance_overrides", {}) is Dictionary: return false
	for key in saved.get("balance_overrides", {}):
		if not _m().balance.has(key) or not _m()._number(saved.balance_overrides[key]): return false
	var claims: Array = []
	for id in saved.campaign_claimed:
		if not id is String or id in claims: return false
		var known = false
		for q in config.milestones:
			if str(q.id) == id: known = true
		if not known: return false
		claims.append(id)
	var stages: Array = []
	for stage in saved.stage_rewards:
		if not _m()._integer(stage,1) or int(stage) > int(saved.stage) or int(stage) in stages: return false
		stages.append(int(stage))
	return true

func _valid_ledger(ledger: Dictionary) -> bool:
	if not ledger.get("records") is Array: return false
	for key in ledger:
		if key == "records": continue
		if not _m()._number(ledger[key]): return false
	for entry in ledger.records:
		if not entry is Dictionary or not _m()._integer(entry.get("minute")) or not _m()._number(entry.get("amount")) or not entry.get("type") is String or not entry.get("description") is String: return false
	return true


func can_place_decoration(id: String, x: int, y: int) -> bool:
	if is_full() and int(_m().state.stage) < int(decoration(id).get("min_stage",0)): return false
	if not super(id,x,y): return false
	if not is_full(): return true
	var candidate: Array = _m().state.layout.duplicate(true)
	var item = decoration(id)
	candidate.append({"id":id,"x":x,"y":y,"w":int(item.get("width",1)),"h":int(item.get("height",1))})
	return preload("res://scripts/services/restaurant_space.gd").layout_is_safe(_m(),candidate)

func buy_decoration(id: String, x: int, y: int) -> bool:
	if is_full():
		_m()._notify("请在装修页校验条件、指派当班空闲员工，再确认开工。")
		return false
	var before: float = float(_m().state.cash)
	var okay: bool = super(id,x,y)
	if okay and is_full():
		for effect in decoration(id).get("effects", []):
			if str(effect.type) in ["cashier_speed", "escape_reduction"]:
				var field = str(effect.type) + ("_bonus" if str(effect.type) == "cashier_speed" else "")
				_m().state[field] = minf(0.95, float(_m().state.get(field,0)) + _effect_value(effect))
		record("capital", before-float(_m().state.cash), str(decoration(id).name))
	return okay


func recruit(kind: String = "normal") -> Dictionary:
	var result: Dictionary = super(kind)
	if is_full() and not result.is_empty():
		management.ensure_state()
		revision.ensure_state()
		story.ensure_state()
		sidequests.ensure_state()
		if str(result.get("id", "")) == "bai_ze" and not bool(result.get("duplicate", false)) and sidequests.baize_unlocked():
			var baize: Dictionary = _m()._employee("bai_ze")
			baize.affinity = maxf(float(baize.get("affinity", 0)), minf(100, _m().state.sidequests.pages.size() * float(_m().balance.get("sidequests.baize_page_gain", 4))+float(revision.s().baize_bonus)))
	return result


func refresh_balance() -> void:
	config = BalanceRegistry.overlay(_source_config,"full",_m().balance)
	if story != null and story.has_method("refresh_balance"): story.refresh_balance()
	for stage in range(5):
		config.stage.active_limits[stage] = int(_m().balance.get("stage.%d.employee_limit" % stage,config.stage.active_limits[stage]))
		var table_limit: int = int(_m().balance.get("stage.%d.tables" % stage,0))
		if table_limit > 0: config.stage.table_limits[stage] = table_limit
