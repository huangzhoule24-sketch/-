extends Control
## V1.5: facts are saved; required operations cannot be dismissed by visiting a panel.
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const Policy = preload("res://scripts/ui/interface_policy.gd")
const ACCENT = Color("b58a43")
var host
var model
var config: Dictionary = {}
var steps: Array = []
var tutorial_card: PanelContainer
var portrait_frame
var message_label: Label
var count_label: Label
var acknowledge_button: Button
var destination_button: Button
var defer_button: Button
var stage_card: PanelContainer
var stage_label: Label
var stage_remaining: float = 0.0
var highlight_rect = Rect2()
var _shown_step = ""
var reminder_elapsed=0.0
var reminder_mode=0
var _last_progress: Dictionary = {}
var _last_lock = ""
var _layout_key = ""
var card_scroll: ScrollContainer
var card_body: VBoxContainer

func setup(ui) -> void:
	host = ui
	model = ui.model
	config = Guide.config()
	steps = config.get("steps", [])
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build()
	update_layout()
	poll(0)

func _build() -> void:
	tutorial_card = PanelContainer.new()
	tutorial_card.name = "TutorialCard"
	tutorial_card.mouse_filter = Control.MOUSE_FILTER_STOP
	tutorial_card.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	tutorial_card.add_theme_stylebox_override("panel", _style(Color("fff9e9")))
	add_child(tutorial_card)
	var frame=VBoxContainer.new()
	frame.add_theme_constant_override("separation",7)
	tutorial_card.add_child(frame)
	var body = VBoxContainer.new()
	body.add_theme_constant_override("separation", 7)
	card_body = body
	card_scroll = ScrollContainer.new()
	card_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	card_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	frame.add_child(card_scroll)
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	card_scroll.add_child(body)
	count_label = Label.new()
	count_label.add_theme_color_override("font_color", Color("977442"))
	count_label.add_theme_font_size_override("font_size", 13)
	count_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	body.add_child(count_label)
	var message_row=HBoxContainer.new();message_row.add_theme_constant_override("separation",8);body.add_child(message_row)
	portrait_frame=preload("res://scripts/ui/portrait_frame.gd").new();portrait_frame.assets=host.assets if "assets" in host else null;portrait_frame.tutorial=true;portrait_frame.mouse_filter=Control.MOUSE_FILTER_IGNORE;message_row.add_child(portrait_frame)
	message_label = Label.new()
	message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	message_label.add_theme_font_size_override("font_size", 14)
	message_label.add_theme_color_override("font_color", Color("30493f"))
	message_row.add_child(message_label)
	acknowledge_button = _guide_button("知道了", "tutorial:ack", acknowledge)
	frame.add_child(acknowledge_button)
	destination_button = _guide_button("前往操作", "tutorial:destination", func():
		var step = current_step()
		if not str(step.get("destination", "")).is_empty(): host.open_panel(str(step.destination)))
	frame.add_child(destination_button)
	defer_button = _guide_button("稍后引导", "tutorial:defer", defer_current)
	frame.add_child(defer_button)
	# Kept as a compatibility node; stage teaching uses the same single card.
	stage_card = PanelContainer.new()
	stage_card.name = "StageUnlockHint"
	stage_card.visible = false
	add_child(stage_card)
	stage_label = Label.new()
	stage_card.add_child(stage_label)

func _guide_button(text: String, id: String, callback: Callable) -> Button:
	var button = Button.new()
	button.text = text
	button.custom_minimum_size.y = 44
	button.set_meta("qa_id", id)
	button.pressed.connect(callback)
	if "_qa_buttons" in host: host._qa_buttons.append(button)
	return button

func update_layout() -> void:
	if tutorial_card == null: return
	if "portrait_layout" in host and host.portrait_layout:
		var width=maxf(200,host._layout_size.x-12)
		var height=portrait_height()
		var in_panel=not host.panel_name.is_empty()
		var bottom=host._layout_size.y-6 if in_panel else host._layout_controls.bottom.global_position.y-6
		tutorial_card.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
		tutorial_card.position=Vector2(6,maxf(6,bottom-height))
		portrait_frame.custom_minimum_size=Vector2(48,60)
		message_label.custom_minimum_size.x=maxf(100,width-90)
		message_label.add_theme_font_size_override("font_size",15)
		message_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		var actions_height=0.0
		for control in [acknowledge_button,destination_button,defer_button]:
			if control.visible:actions_height+=51
		card_scroll.custom_minimum_size=Vector2(width-28,maxf(48,height-actions_height-34))
		tutorial_card.size=Vector2(width,height)
		if host.phone_ui!=null:host.phone_ui.fit_modal()
		return
	tutorial_card.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	var compact: bool = "compact_layout" in host and host.compact_layout
	var panel_mode: bool = "panel_name" in host and not str(host.panel_name).is_empty()
	var width = (248 if compact else 344) if panel_mode else (360 if compact else 460)
	tutorial_card.offset_left = -width - 8
	tutorial_card.offset_right = -8
	tutorial_card.offset_top = (host._layout_controls.content.global_position.y+6) if "_layout_controls" in host and not host._layout_controls.is_empty() else 70
	portrait_frame.custom_minimum_size = (Vector2(48,60) if compact else Vector2(64,72)) if panel_mode else (Vector2(96,110) if compact else Vector2(132,150))
	message_label.custom_minimum_size.x = width - 36 - portrait_frame.custom_minimum_size.x
	message_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	message_label.add_theme_font_size_override("font_size", (13 if compact else 14) if panel_mode else (14 if compact else 16))
	message_label.add_theme_constant_override("line_spacing",3)
	message_label.max_lines_visible = -1
	message_label.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
	var limit = size.y * (.56 if panel_mode else .74)
	if compact and "_layout_controls" in host and not host._layout_controls.is_empty():
		limit=minf(limit,host._layout_controls.bottom.global_position.y-tutorial_card.offset_top-6)
	var actions_height=0.0
	for control in [acknowledge_button,destination_button,defer_button]:
		if control!=null and control.visible:actions_height+=51
	card_scroll.custom_minimum_size = Vector2(width-28,minf(maxf(50,card_body.get_combined_minimum_size().y),maxf(50,limit-20-actions_height)))
	tutorial_card.size = Vector2(width,0)
	_place_card()

func portrait_height() -> float:return minf(240,maxf(185,host._layout_size.y*.27))

func _place_card() -> void:
	if "portrait_layout" in host and host.portrait_layout:return
	if not tutorial_card.visible or not highlight_rect.has_area() or size.x<100:return
	# Management panels reserve a right column for the guide. In the scene,
	# choose a nearby free side and stay clear of both fixed rows and the target.
	if "panel_name" in host and not str(host.panel_name).is_empty():return
	var top=(host._layout_controls.content.global_position.y+6) if "_layout_controls" in host and not host._layout_controls.is_empty() else 70.0
	var bottom=(host._layout_controls.bottom.global_position.y-6) if "_layout_controls" in host and not host._layout_controls.is_empty() else size.y-80
	var extent=tutorial_card.size.max(tutorial_card.get_combined_minimum_size())
	var center=highlight_rect.get_center()
	var candidates=[Vector2(highlight_rect.end.x+18,center.y-extent.y/2),Vector2(highlight_rect.position.x-extent.x-18,center.y-extent.y/2),Vector2(center.x-extent.x/2,highlight_rect.position.y-extent.y-18),Vector2(center.x-extent.x/2,highlight_rect.end.y+18)]
	var best=Vector2(size.x-extent.x-8,top);var distance=INF
	for candidate in candidates:
		candidate=Vector2(clampf(candidate.x,8,maxf(8,size.x-extent.x-8)),clampf(candidate.y,top,maxf(top,bottom-extent.y)))
		if Rect2(candidate,extent).intersects(highlight_rect.grow(8)):continue
		var next=(candidate+extent/2).distance_squared_to(center)
		if next<distance:best=candidate;distance=next
	tutorial_card.position=best

func _style(color: Color) -> StyleBoxFlat:
	var result = StyleBoxFlat.new()
	result.bg_color = color
	result.border_color = Color("d9c49b")
	result.set_border_width_all(1)
	result.set_corner_radius_all(12)
	result.content_margin_left = 14
	result.content_margin_right = 14
	result.content_margin_top = 10
	result.content_margin_bottom = 10
	return result

func _ensure_progress() -> Dictionary:
	return Guide.ensure(model)

func observe(action: String, args: Dictionary = {}) -> void:
	if str(model.state.get("mode", "")) != "full": return
	Guide.observe(model, action, args)

func acknowledge() -> void:
	var step = current_step()
	if str(step.get("complete_condition", "")) in ["welcome_ack", "income_ack"]: observe(str(step.complete_condition))
	Guide.acknowledge(model)
	poll(0)

func skip_tutorial() -> void:
	# Existing integrations may call the old API; mandatory onboarding remains intact.
	if current_step().has("stage"): defer_current()
	elif host.has_method("show_notice"): host.show_notice("开局教学需要完成当前操作；完成后点击确认进入下一步。")

func restart_tutorial(id: String = "") -> void:
	if id.is_empty():
		model.state.erase("tutorial")
		# A deliberate replay also works on a migrated campaign.
		if model.state.get("migration_v15") is Dictionary: model.state.migration_v15["legacy_campaign"] = false
	else:
		var p = Guide.ensure(model)
		p.stage_completed.erase(id)
		p.ready_to_ack.erase(id)
		p["active_id"] = ""
		p.deferred.erase(id)
		for step in config.get("stage_steps", []):
			if step.id == id: p.actions.erase(str(step.action))
	_shown_step = ""
	poll(0)
	_save_progress()

func defer_current() -> void:
	Guide.defer(model)
	poll(0)
	_save_progress()

func current_step() -> Dictionary:
	return Guide.current(model)

func localized(text: String) -> String:
	return host.localization.translate(text) if "localization" in host and host.localization!=null else text

func poll(_delta: float) -> void:
	reminder_elapsed+=maxf(0,_delta)
	if model == null or tutorial_card == null: return
	if str(model.state.get("mode", "")) != "full":
		tutorial_card.visible = false
		return
	var progress = _ensure_progress()
	var step = current_step()
	var current_panel = str(host.panel_name) if "panel_name" in host else ""
	var portrait: bool = "landscape_required" in host and host.landscape_required
	tutorial_card.visible = not step.is_empty() and not current_panel in ["欢迎", "重新开始", "破产救援", "文化简介", "美术资源", "开发者选项", "数值面板"] and not portrait
	if tutorial_card.visible:
		portrait_frame.character_id=str(step.get("portraitCharId",""));portrait_frame.visible=not portrait_frame.character_id.is_empty();portrait_frame.queue_redraw()
		count_label.text = "白泽 · 阶段%d / %s" % [int(step.stage), str(step.get("label", "功能教学"))] if step.has("stage") else "白泽引导  %d / %d · 必修" % [steps.find(step) + 1, steps.size()]
		message_label.text = str(step.get("message", ""))
		count_label.text=localized(count_label.text)
		message_label.text=localized(message_label.text)
		message_label.tooltip_text = message_label.text
		var ready = str(step.id) in progress.ready_to_ack
		acknowledge_button.visible = ready or str(step.get("complete_condition", "")) in ["welcome_ack", "income_ack"]
		acknowledge_button.text = "✓ 已完成，点击继续" if ready else str(step.get("button", "知道了"))
		acknowledge_button.text=localized(acknowledge_button.text)
		destination_button.visible = not ready and not str(step.get("destination", "")).is_empty() and current_panel != str(step.get("destination", ""))
		destination_button.text = "前往 · " + str(step.get("destination", ""))
		destination_button.text=localized(destination_button.text)
		defer_button.visible = not ready and step.has("stage")
		var key = str([step.get("id",""),ready,current_panel,size,message_label.text])
		if key != _layout_key or not highlight_rect.has_area():
			_layout_key = key
			highlight_rect = _target_rect(str(step.get("highlight_target", "")))
			update_layout()
	else: highlight_rect = Rect2()
	var next_id = str(step.get("id", ""))
	if _shown_step != next_id:
		_shown_step = next_id
		reminder_elapsed=0
		reminder_mode=int(step.get("remindMode",0))
		if host.has_method("configure_panel_layout") and "modal_window" in host and host.modal_window != null: host.configure_panel_layout(current_panel)
	_apply_locks()
	if tutorial_card.visible:
		# Containers may finish shrinking their minimum width a frame after a
		# portrait/translation change. Fit again using that settled measurement.
		if "portrait_layout" in host and host.portrait_layout:update_layout()
		else:
			var compact=bool(host.compact_layout) if "compact_layout" in host else false
			var desired=(248 if compact else 344) if not current_panel.is_empty() else (360 if compact else 460)
			tutorial_card.size=Vector2(desired,tutorial_card.get_combined_minimum_size().y)
	queue_redraw()
	if progress != _last_progress:
		_last_progress = progress.duplicate(true)
		_save_progress()
		if host.has_method("refresh"): host.refresh()

func _apply_locks() -> void:
	if not "_qa_buttons" in host: return
	var exception_panel = str(host.panel_name) in ["欢迎", "文化简介", "美术资源", "开发者选项", "数值面板", "破产救援", "贷款", "今日收支结算", "现金流预警", "经营失败", "事件结果"]
	for control in host._qa_buttons:
		if not is_instance_valid(control): continue
		var id = str(control.get_meta("qa_id", ""))
		var locked = not exception_panel and not Guide.allows_button(model, id)
		if locked and not bool(control.get_meta("guide_locked", false)):
			control.set_meta("guide_original_disabled", control.disabled)
			control.set_meta("guide_original_tooltip", control.tooltip_text)
			control.disabled = true
			control.tooltip_text = "请先完成白泽当前教学；阶段功能可选择稍后引导。"
		elif not locked and bool(control.get_meta("guide_locked", false)):
			control.disabled = bool(control.get_meta("guide_original_disabled", false))
			control.tooltip_text = str(control.get_meta("guide_original_tooltip", ""))
		control.set_meta("guide_locked", locked)

func dismiss_stage_hint() -> void:
	defer_current()

func _target_rect(target: String) -> Rect2:
	# Replayed guidance must follow the entries visible at the current stage.
	var destination = Policy.destination(str(current_step().get("destination", "")))
	if target.begins_with("nav:") and not destination.is_empty():
		target = "nav:更多"
		for name in Policy.navigation(int(model.state.stage)):
			if Policy.destination(str(name)) == destination:
				target = "nav:" + str(name)
				break
	var node: Control = null
	match target:
		"debt":
			if "debt_label" in host: node = host.debt_label
		"cash":
			if "money_label" in host: node = host.money_label
		"first_guest":
			if "map_view" in host:
				node = host.map_view
				if node != null and node.has_method("first_customer_bounds"):
					var bounds: Rect2 = node.first_customer_bounds()
					bounds.position += node.global_position - global_position
					return bounds
		_:
			if "_qa_buttons" in host:
				for control in host._qa_buttons:
					if is_instance_valid(control) and str(control.get_meta("qa_id", "")) == target:
						node = control
						break
	if node == null or not node.is_visible_in_tree(): return Rect2()
	var result = node.get_global_rect()
	result.position -= global_position
	return result.grow(5)

func _draw() -> void:
	if not tutorial_card.visible: return
	if highlight_rect.has_area():
		draw_rect(highlight_rect, Color(ACCENT, 0.12), true)
		var glow=1.0
		if reminder_mode==1 and reminder_elapsed<1.5:glow=.35+.65*(.5+.5*sin(TAU*2*reminder_elapsed))
		draw_rect(highlight_rect,Color(ACCENT,glow),false,3,true)
		if reminder_mode==0:
			var card_rect=tutorial_card.get_global_rect();card_rect.position-=global_position
			var destination=highlight_rect.get_center()
			var origin=card_rect.get_center()
			var direction=(destination-origin).normalized()
			var edge=minf(card_rect.size.x/maxf(.01,absf(direction.x)),card_rect.size.y/maxf(.01,absf(direction.y)))*.5
			origin+=direction*(edge+5)
			var tip=destination-direction*(minf(highlight_rect.size.x,highlight_rect.size.y)*.5+8)
			var breath=1.0
			var normal=Vector2(-direction.y,direction.x)
			draw_line(origin,tip-direction*12,ACCENT,2,true)
			draw_colored_polygon(PackedVector2Array([tip,tip-direction*16*breath+normal*6*breath,tip-direction*16*breath-normal*6*breath]),ACCENT)
	# Mask non-current controls visually as well as disabling their operation.
	if "_qa_buttons" in host:
		for control in host._qa_buttons:
			if is_instance_valid(control) and bool(control.get_meta("guide_locked", false)) and control.is_visible_in_tree():
				var bounds: Rect2 = control.get_global_rect()
				bounds.position -= global_position
				draw_rect(bounds, Color(0.15, 0.22, 0.18, 0.14), true)

func _save_progress() -> void:
	if model.has_signal("autosave_requested"): model.autosave_requested.emit()

func reminder_snapshot() -> Dictionary:
	var rect=tutorial_card.get_global_rect()
	var scroll_rect=card_scroll.get_global_rect()
	return {"card_visible":tutorial_card.visible,"rect":{"x":rect.position.x,"y":rect.position.y,"w":rect.size.x,"h":rect.size.y},"scroll":{"x":scroll_rect.position.x,"y":scroll_rect.position.y,"w":scroll_rect.size.x,"h":scroll_rect.size.y},"scroll_value":card_scroll.scroll_vertical,"scroll_max":card_scroll.get_v_scroll_bar().max_value,"scroll_page":card_scroll.get_v_scroll_bar().page,"portrait_character":portrait_frame.character_id,"portrait_visible":portrait_frame.visible and tutorial_card.visible,"portrait_available":not portrait_frame.assets.is_placeholder(portrait_frame.assets.get_portrait(portrait_frame.character_id,true)) if portrait_frame.assets!=null else false,"mode":reminder_mode,"elapsed":reminder_elapsed,"flashes":mini(3,int(reminder_elapsed*2)) if reminder_mode==1 else 0,"visible":tutorial_card.visible and highlight_rect.has_area(),"arrow":reminder_mode==0 and tutorial_card.visible and highlight_rect.has_area()}
