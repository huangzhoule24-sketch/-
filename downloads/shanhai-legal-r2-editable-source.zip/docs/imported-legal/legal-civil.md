# 法务系统 · 民事板块

2026-10-29。法务系统按用户要求分为民事、行政、刑事三块，本轮只实现**民事**，行政与刑事保留入口位置与数据位。

## 一、时间线

| 项目 | 出现时间 | 说明 |
|---|---|---|
| 卫生检查（原有事件 `hygiene`） | 第 1 天起 | 沿用旧规则：认真应对花 50 元、通过率高；侥幸应付 0 成本、未通过罚 200 声望 -10 |
| 安全提示牌（装修件 `safety_sign`） | 阶段 1 起随时可买 | 装修体系通用门槛，与日期无关 |
| 保洁度数值 / 低保洁度状态 | 第 14 天起 | 第 14 天前不衰减、不累计检查失败 |
| 店内湿滑 `wet_floor` | 第 14 天起，且身上有「低保洁度」 | 顾客碰瓷 |
| 食品安全 `food_safety` | 第 14 天起，且身上有「低保洁度」 | 菜里异物索赔 |

`min_day` 与 `requires_state` 是本次为事件触发器新增的两个通用字段（`trigger.min_day` 按 1 起算的自然日，`trigger.requires_state` 读取 `revision18` 状态）。

## 二、保洁度

- 取值 0–100，新局 100。
- 第 14 天起每个新游戏日 -3（`legal.daily_decay`）。
- 卫生检查通过 +10，并把「连续未通过」计数清零。
- 卫生检查未通过 -15，计数 +1；第 14 天起累计到 2 次（`legal.failures_to_state`）即获得**低保洁度**，同时把保洁度压到 55（安全线 60 减 5）。
- 后厨清洁（原有的「安排清洁后厨」动作，20 元 / 15 分钟）完成后 +30，并清零计数。
- 保洁度 ≥ 70（`legal.recover_threshold`）时自动解除低保洁度；低保洁度本身也有 5 游戏日时限。

低保洁度**不带任何数值修正**，它的作用就是放行「店内湿滑」与「食品安全」两个事件，以及压低食品安全的胜诉门槛。这样不会在用户没要求的维度上偷偷改平衡。

## 三、两个事件

### 店内湿滑（顾客碰瓷）

- 赔一点小钱：付 30 元，不进公堂。
- 法庭对决：判据是**店里有没有已完工的安全提示牌**。
  - 未放置 → 败诉：赔 100 元、声望 -15、客流 -20% 持续 3 天。
  - 已放置 → 胜诉：不赔钱、不掉声望，但客流 -10% 持续 3 天；第 4–6 天客流 +15%。

### 食品安全

用户只指定了"会因为低保洁度触发"，未指定分支数值，本版按同构设计并给出判据：

- 赔一点小钱：赔 80 元、声望 -3。
- 法庭对决：判据是**当前保洁度是否 ≥ 60**。低保洁度刚触发时保洁度是 55，因此必须先清洁后厨才可能赢。
  - 胜诉：不赔钱，客流 -10% 持续 3 天（整改期）。
  - 败诉：赔 150 元、声望 -20、客流 -20% 持续 3 天。

食品安全不享受"第 4–6 天回升"，回升只属于店内湿滑胜诉。数值全部在 `config/global_balance.json` 的 `legal.*` 键里，可直接改。

## 四、安全提示牌

- 新增装修件 `safety_sign`，120 元、1×1、工期 30 分钟、需 1 名当班空闲员工。
- 走既有装修流程：购买 → 地图选位 → 指派负责人 → 完工生效；`building` 为 true 时不算"已放置"。
- 效果不加舒适度也不加客流，唯一作用是让店内湿滑的法庭对决胜诉。

## 五、界面

- 「更多 → 法务与合规 → 法务」：保洁度、低保洁度剩余时间、连续未通过次数、提示牌状态、胜败统计、最近 5 条民事案件、待付赔偿结清按钮。
- 「经营状态」页顶部新增一行保洁度摘要，并带「查看法务」按钮。
- 顶栏状态徽章新增「脏」，低保洁度激活时显示剩余小时。
- 图鉴 → 装修 会自动列出安全提示牌，无需额外配置。

## 六、代码落点

| 文件 | 改动 |
|---|---|
| `config/events.json` | 新增 `wet_floor`、`food_safety` |
| `config/decorations.json` | 新增 `safety_sign` |
| `config/revision18.json` | `states.low_cleanliness` |
| `config/global_balance.json` | `legal.*` 与 `decoration.safety_sign_cost` |
| `config/experience.json` | 更多菜单新增「法务与合规 / 法务」 |
| `scripts/core/world_events.gd` | 保洁度与法务状态、`_inspection` 计入失败、`court_duel` / `legal_pay` / `cleanliness` 三个新效果类型、`min_day` / `requires_state` 触发条件、`on_day` 日衰减、快照与存档校验 |
| `scripts/core/revision18.gd` | 清洁完成后回调保洁度；低保洁度不注册数值修正 |
| `scripts/ui/full_panels.gd` | `legal_panel()` |
| `scripts/ui/revision18_ui.gd` | 徽章文字表改为常量并加「脏」；经营状态页保洁度摘要 |
| `scripts/core/tutorial_progress.gd` | 教学期间允许打开法务页 |

## 七、验证

- `tests/legal_tests.gd`：57 项断言，覆盖第 14 天门槛、状态门槛、保洁度加减与日衰减、清洁恢复与解除状态、两种判据下的胜败分支、败诉三日客流、胜诉第 4–6 天回升、赔付不足转为待付、存档往返与快照字段。
- `tests/event_tests.gd`：事件总数断言由 38 改为 40；`context_for()` 补上 `min_day` / `requires_state` 的前置条件复现，使全事件可达性扫描能覆盖两个法务事件。
- `tests/campaign_tests.gd`：事件总数断言由 38/37 改为 40/39；`tests/v15_event_tests.gd` 决策类事件计数 15→17。
- `tests/v18_rules_tests.gd`：状态并发数 5→6（新增 `low_cleanliness`）。
- 两个法务事件必须带 `"type": "decision"`。缺这个字段时 `v15_event_tests` 的逐条分类循环会直接脚本报错中断，新增事件时不要漏。

### Windows 下的测试运行

`tools/run_checks.sh` 依赖 bash 与 `/tmp`，在本机（Git Bash + Windows）跑不全：

- 原测试里有 15 个套件把存档路径硬编码成 `/tmp/xxx.json`。Windows 上没有这个目录，写盘返回 null，脚本 error 后 `quit()` 没执行，进程挂住直到超时。现已统一改为 `OS.get_user_data_dir().path_join(...)`，跨平台可用。
- Godot 的 Windows 控制台版 exe 会把真正的引擎当子进程启动，`subprocess` 超时只杀掉外壳、引擎仍握着管道，所以看起来像"跑了几个小时"。用 `tools/run_suites.py <suite> ...` 跑，它会 `taskkill /F /T` 杀整棵进程树并给出干净结论。
- `tests/art_pack_tests.gd`、`culture_refresh_tests`、`free_sfx_tests` 原本直写 `res://build/...`，而 `build/` 是打包工具才生成的目录，干净检出下 `FileAccess.open` 返回 null，脚本 error 后 `quit()` 没执行，进程挂住变成"超时"。三处都已改为先 `make_dir_recursive_absolute`。
- 现在全量 49 个套件里只有 `v16_experience_tests` 的一条断言（`Completion footer fits inside the clipped drawer`）不过。这条在原始压缩包解出的干净副本上同样失败，属本机渲染/字体度量差异，与本改动无关。

## 八、尚未实现

- 行政板块：卫生监管处罚、限期整改、复查等。
- 刑事板块：刑事责任与更重的判决链。
- 法务页目前只有民事一张卡；三块并列时的分页留给后续两轮，数据位已按 `legal.*` 前缀预留。

## 九、版本与产物

本板块随 **v1.9.6-legal-civil** 发布（上一版为 `v1.9.5-culture-origins`）。

| 项目 | 值 |
|---|---|
| 产物名 | `山海食肆物语-v1.9.6-legal-civil-Windows.zip` |
| 包内可执行 | `shanhai-v1.9.6-legal-civil.exe` / `.pck` |
| exe 属性 | FileVersion `1.9.6.0`、FileDescription「山海食肆物语 v1.9.6」 |
| 引擎 | Godot 4.7.2.stable（全新完整包，与 4.6.3 旧包不通用） |
| 出包命令 | `python tools/export_windows_local.py` |

改版本号时**必须同步**这几处，否则会出现 exe 名、ZIP 名、manifest 三者不一致：

- `export_presets.cfg`：`export_path`、`application/file_version`、`application/product_version`、`application/file_description`
- `tools/package_release.py`：`ARCHIVES`、manifest 的 `version`、`v1.9.6-legal-civil-SHA256SUMS.txt`、说明书抬头
- `tools/export_windows_local.py`：`EXE_NAME`、`ARCHIVE_NAME`、manifest 的 `version`
- `tools/export_windows.sh`：导出目标路径

另有一处容易漏：`export_presets.cfg` 的 `application/modify_resources` 必须为 `true`，否则上面那些版本字段全部不生效，exe 属性会显示模板自带的 `4.7.2 / Godot`。这个选项只是配置位，不需要额外装 rcedit。
