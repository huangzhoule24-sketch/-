extends SceneTree
## Paused rendering/layout fixtures, not natural gameplay progress.
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var ui
func _init():call_deferred("run")
func settle():
	for n in range(20):await process_frame
func capture(name):
	await settle();await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://build/legal-r2/"+name+".png")
func run():
	root.size=Vector2i(1280,800);ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	await settle();ui.return_to_restaurant();await capture("officer-desktop")
	ui.map_view.house().zoom_at(1.6,ui.map_view._to_view(ui.map_view.officer_point()));await capture("officer-desktop-close")
	root.size=Vector2i(390,844);ui.update_ui_layout();ui.refresh();await settle();ui.map_view.house().fit_all();await capture("officer-phone-fit")
	ui.map_view.house().focus_room("yard");await capture("officer-phone-yard")
	ui.map_view.house().fit_all();ui.map_view.house().zoom_at(2.4,ui.map_view._to_view(ui.map_view.officer_point()));await capture("officer-phone-close")
	ui.queue_free();await settle();quit()
