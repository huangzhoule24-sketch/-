/* Ordinary browser actions; no save injection, resource grants or time jumps. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8073').replace(/\/$/,''),out=process.argv[2]||'build/legal-r2/browser-officer';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const checks=[],actions=[],errors=[];let receipt;
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader','--disable-background-timer-throttling']});
 const ua={desktop:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36',phone:'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36'};
 function check(ok,label){checks.push({ok:!!ok,label});if(!ok)throw Error(label)}
 for(const kind of['desktop','phone']){
  const mobile=kind==='phone',context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:800},deviceScaleFactor:1,userAgent:ua[kind],hasTouch:mobile,isMobile:mobile,locale:'zh-CN'}),page=await context.newPage(),cdp=await context.newCDPSession(page);
  page.on('pageerror',e=>errors.push(kind+': '+e.message));page.on('console',m=>{if(/SCRIPT ERROR|Parse Error|ERROR:/.test(m.text()))errors.push(kind+': '+m.text())});
  const state=()=>page.evaluate(()=>window.shanhaiQAState),sync=()=>page.waitForTimeout(550);
  async function point(rect){return page.evaluate(r=>{const c=document.querySelector('canvas').getBoundingClientRect(),s=shanhaiQAState;return{x:c.x+(r.x+r.w/2)*c.width/s.viewport.w,y:c.y+(r.y+r.h/2)*c.height/s.viewport.h}},rect)}
  async function swipe(reverse=false){
   const r=(await state()).responsive.scroll,a=await point({x:r.x+r.w/2,y:r.y+r.h*(reverse?.2:.8),w:0,h:0}),b=await point({x:r.x+r.w/2,y:r.y+r.h*(reverse?.8:.2),w:0,h:0});
   if(mobile){await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...a,id:0}]});for(let i=1;i<=8;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:a.x,y:a.y+(b.y-a.y)*i/8,id:0}]});await page.waitForTimeout(25)}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]})}
   else {await page.mouse.move(a.x,a.y);await page.mouse.wheel(0,reverse?-450:450)}await sync();
  }
  async function tap(id){let b;for(let i=0;i<20;i++){b=(await state())?.buttons.find(x=>x.qa_id===id&&!x.disabled);if(b)break;await swipe(i<3)}if(!b)throw Error(kind+': Missing enabled '+id);const p=await point(b.rect);if(mobile)await page.touchscreen.tap(p.x,p.y);else await page.mouse.click(p.x,p.y);await sync();actions.push(kind+':'+id)}
  async function shot(name){await page.waitForTimeout(400);await page.screenshot({path:path.join(out,kind+'-'+name+'.png')})}
  async function stored(){return page.evaluate(async()=>{const found=[];for(const info of await indexedDB.databases()){const db=await new Promise((res,rej)=>{const q=indexedDB.open(info.name);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});for(const name of db.objectStoreNames){const store=db.transaction(name,'readonly').objectStore(name),keys=await new Promise((res,rej)=>{const q=store.getAllKeys();q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});for(const key of keys){if(!String(key).endsWith('campaign_savegame.json'))continue;const value=await new Promise((res,rej)=>{const q=db.transaction(name,'readonly').objectStore(name).get(key);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});const save=JSON.parse(new TextDecoder().decode(value.contents));found.push({served:save.state.served,legal:save.state.world.legal,admin:save.state.world.admin})}}db.close()}return found})}
  try{
   receipt=await(await page.request.get(root+'/game/export-receipt.json')).json();await page.goto(root+'/game/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});await sync();
   await tap('start:full');if(!(await state()).paused)await tap('time:pause');await tap('tutorial:ack');await tap('nav:员工');await tap('panel:close');await tap('tutorial:ack');await tap('tutorial:destination');await tap('full:marketing:flyer');await tap('tutorial:ack');if((await state()).panel)await tap('panel:close');if((await state()).paused)await tap('time:pause');
   await page.waitForFunction(()=>shanhaiQAState.state.served>=1,null,{timeout:120000});
   for(const id of['first_order','income'])if(!(await state()).state.tutorial.completed_steps.includes(id)){if(id==='first_order')await page.waitForFunction(id=>shanhaiQAState.state.tutorial.ready_to_ack.includes(id),id,{timeout:20000});await tap('tutorial:ack')}
   if(!(await state()).state.tutorial.completed_steps.includes('bill')){await tap('tutorial:destination');await tap('tutorial:ack')}
   if((await state()).panel)await tap('panel:close');if(!(await state()).paused)await tap('time:pause');let s=await state();
   check(s.state.tutorial.finished,kind+' completes real opening guidance');
   check(s.state.finance.flows.some(f=>f.type==='tax'&&f.amount<0),kind+' actual main-eatery checkout records a separate tax payment');
   check(s.state.world.legal.cleanliness===100&&s.state.world.admin.risk===0,kind+' normal new campaign initializes main legal state');
   const starts=s.audio.music_starts;
   await tap('scene:fit');await page.waitForFunction(()=>shanhaiQAState.admin_npc?.image_available,null,{timeout:20000});s=await state();
   check(s.admin_npc.resource_id==='Characters/tax_officer_idle'&&s.admin_npc.image_available,kind+' loads an independent tax-officer sprite');
   check(s.admin_npc.rect.w>=44,kind+' tax officer has a finger-sized horizontal target');await shot('independent-officer');
   async function selectPart(part){const npc=(await state()).admin_npc.rect,p=await point({x:npc.x+npc.w/2,y:npc.y+(part==='head'?Math.min(12,npc.h*.2):npc.h*.6),w:0,h:0});if(mobile)await page.touchscreen.tap(p.x,p.y);else await page.mouse.click(p.x,p.y);actions.push(kind+':officer:'+part);await page.waitForFunction(()=>shanhaiQAState.panel==='行政',null,{timeout:15000});await sync()}
   await selectPart('head');check((await state()).panel==='行政',kind+' selecting the cap/head opens administration');await tap('panel:restaurant');
   if(mobile)await tap('scene:zone:yard');else await tap('scene:larger');await sync();await tap('scene:fit');
   await selectPart('body');check((await state()).panel==='行政',kind+' selecting the robe/ledger after camera change opens administration');await shot('officer-administration');await tap('panel:restaurant');
   check((await state()).audio.music_starts===starts,kind+' NPC selection preserves music continuity');
   await tap('nav:更多');await tap('full:open:系统');await tap('system:save');
   let saves=[];const deadline=Date.now()+20000;while(Date.now()<deadline){saves=await stored();if(saves.some(x=>x.served>=1&&x.legal?.cleanliness===100))break;await page.waitForTimeout(500)}
   check(saves.some(x=>x.served>=1&&x.legal?.cleanliness===100),kind+' saving preserves the existing main-shop progress');
   fs.writeFileSync(path.join(out,kind+'-save-proof.json'),JSON.stringify(saves,null,2));await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});s=await state();
   check(s.state.served>=1&&s.admin_npc.image_available,kind+' reload retains progress and the independent built-in sprite');
  }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,kind+'-failure-state.json'),JSON.stringify((await state())||null,null,2))}
  await context.close();if(errors.length)break;
 }
 const report={game_source:receipt?.game_source,checks,actions,errors,scope:'Normal new campaigns on Chromium desktop and Android touch emulation; no day-14 natural-play or physical-device claim.'};fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
