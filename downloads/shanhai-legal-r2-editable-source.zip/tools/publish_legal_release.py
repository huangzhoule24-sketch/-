#!/usr/bin/env python3
"""Publish the tested legal merge as a site and a history-free download snapshot."""
import json,urllib.request,zipfile
from package_release import ROOT,BUILD,sha256,game_source_fingerprint,write_json
import publish_web_site as publisher
def main():
 out=BUILD/'legal-r1';site=BUILD/'legal-site';source=game_source_fingerprint();build=json.loads((out/'site-build.json').read_text())
 assert source==build['game_source']
 for folder in['browser-clock-final','device-browser-clock-final','share-browser-clock-final']:
  report=json.loads((out/folder/'report.json').read_text());assert report['checks']and not report['errors']and all(x['ok']for x in report['checks'])
  if 'game_source'in report:assert report['game_source']==source
 native=json.loads((out/'native-regressions.json').read_text());assert native['game_source']==source and len(native['suites'])==66 and not native['failures']and all(r['ok']for r in native['suites'])
 for name in['http-desktop.json','http-mobile.json']:
  report=json.loads((out/name).read_text());assert report['game_source']==source and report['gzip_sha_and_roundtrip_verified']
 report=json.loads((out/'source-verification.json').read_text());assert report['game_source']==source and not report['failures']and report['source_fingerprint_after_import_matches']
 report=json.loads((out/'package-verification.json').read_text());assert report['game_source']==source and not report['errors']and all(x['ok']for x in report['checks'])
 for prefix in['','portrait/']:
  manifest=json.loads((site/prefix/'site-receipt.json').read_text());assert manifest['game_source']==source
  for name,e in manifest['files'].items():
   p=site/prefix/name;assert p.stat().st_size==e['bytes']and sha256(p)==e['sha256']
 artifacts=[json.loads((out/name).read_text())['artifact']for name in['package-build.json','source-package.json']]
 for a in artifacts:
  p=BUILD/a['file'];assert p.stat().st_size==a['bytes']and sha256(p)==a['sha256']
  with zipfile.ZipFile(p)as z:assert z.testzip()is None
 publisher.REVISION='legal-r1'
 website=publisher.publish('gh-pages',{p.relative_to(site).as_posix():p for p in site.rglob('*')if p.is_file()},'Merge main-eatery civil claims, administrative risk and tax without extending them to regional eateries',build['parent'])
 changed=publisher.git(['diff-tree','-z','--no-commit-id','--name-only','-r',build['parent'],website],raw=True).decode().rstrip('\0').split('\0')
 assert sorted(changed)==sorted(set(build['changes'])|set(build['removed']))
 print(json.dumps({'website_commit':website}),flush=True)
 entries={'downloads/'+a['file']:BUILD/a['file']for a in artifacts}
 entries['downloads/SHA256SUMS.txt']=''.join(a['sha256']+'  '+a['file']+'\n'for a in artifacts).encode()
 entries['instructions/workbuddy-update.txt']=ROOT/'docs/legal-merge-workbuddy.txt'
 for name in['legal-merge-r1.md','legal-merge-validation.md','legal-merge-provenance.json']:entries['docs/'+name]=ROOT/'docs'/name
 for name in['native-regressions.json','source-verification.json','package-verification.json','http-desktop.json','http-mobile.json']:entries['validation/'+name]=out/name
 for folder in['browser-clock-final','device-browser-clock-final','share-browser-clock-final']:entries['validation/'+folder+'/report.json']=out/folder/'report.json'
 for name in['main-officer-desktop','legal-desktop','legal-phone','legal-phone-en','admin-phone']:entries['layout-fixtures/'+name+'.png']=out/(name+'.png')
 commit=publisher.publish('legal-r1-final-20261108',entries,'Provide main-eatery legal merge, complete playable site and editable source without development history')
 downloads=[]
 for artifact in artifacts:
  url='https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/downloads/'+artifact['file'];target=out/('public-'+artifact['file'])
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shanhai-integrity-verifier'}),timeout=120)as r:
   status=r.status;length=int(r.headers.get('Content-Length','0'))
   with target.open('wb')as f:
    while block:=r.read(1048576):f.write(block)
  assert status==200 and length==artifact['bytes']==target.stat().st_size and sha256(target)==artifact['sha256']
  with zipfile.ZipFile(target)as z:assert z.testzip()is None
  start=1048576;size=64
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes={start}-{start+size-1}'}),timeout=45)as r:partial=r.read();rs=r.status;cr=r.headers.get('Content-Range')
  with(BUILD/artifact['file']).open('rb')as f:f.seek(start);expected=f.read(size)
  assert rs==206 and partial==expected and cr==f'bytes {start}-{start+size-1}/{length}'
  downloads.append({**artifact,'direct_url':url,'http_status':status,'sha256_verified':True,'zip_crc_valid':True,'range_status':rs,'range_verified':True})
 proof={'version':build['version'],'game_source':source,'static_site':{'commit':website,'parent':build['parent'],'pages_url':'https://huangzhoule24-sketch.github.io/-/','both_views_current':True,'live_http_verified':False},'commit':commit,'downloads':downloads,'workbuddy_project_deployed_by_assistant':False,'workbuddy_instructions_url':'https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/instructions/workbuddy-update.txt'}
 write_json(out/'publication.json',proof);print(json.dumps(proof,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
