#!/usr/bin/env python3
"""Build current desktop/phone shells around one freshly verified export."""
import json,shutil
from package_release import ROOT,BUILD,sha256,write_json,utc_now,game_source_fingerprint
from publish_web_site import git
REVISION='web-legal-r2';VERSION='SH-WEB-LEGAL-R2';BASELINE='4ed8f9adf4e9dffadf551da8f872e1804aa480d6'
def signature(path):return {'bytes':path.stat().st_size,'sha256':sha256(path)}
def main():
 fresh=BUILD/'legal2-release';site=BUILD/'legal2-site';source=json.loads((fresh/'site-receipt.json').read_text());assert source['game_source']==game_source_fingerprint()
 if site.exists():shutil.rmtree(site)
 names=git(['ls-tree','-rz','--name-only',BASELINE],raw=True).decode().rstrip('\0').split('\0');old={n:git(['show',BASELINE+':'+n],raw=True)for n in names}
 for n,b in old.items():
  if n.startswith(('game/','portrait/game/')):continue
  p=site/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for prefix,variant in[('','desktop'),('portrait/','mobile')]:
  base=site/prefix;shutil.copytree(fresh,base,dirs_exist_ok=True)
  for name,kind in[('index.html','home'),('share.html','share'),('game/index.html','game')]:
   p=base/name;s=p.read_text();depth=(1 if prefix else 0)+(1 if kind=='game'else 0);root='../'*depth if depth else'./'
   tag='<script src="'+root+'device-router.js?v='+REVISION+'" data-root="'+root+'" data-variant="'+variant+'" data-page="'+kind+'"></script>'
   s=s.replace('<head>','<head>\n'+tag,1)
   if kind=='game':s=s.replace('(function () {','(function () {\n\tif (window.shanhaiDeviceRoute && window.shanhaiDeviceRoute.redirecting) return;',1)
   else:s=s.replace('</head>','<link rel="stylesheet" href="'+root+'device-entry.css?v='+REVISION+'">\n</head>',1)
   p.write_text(s)
  p=base/'device-router.js';p.write_text(p.read_text().replace('web-ui-r1',REVISION).replace('web-international-r1',REVISION).replace('web-visual-r1',REVISION).replace('web-branch-r1',REVISION).replace('web-branch-r2',REVISION).replace('web-legal-r1',REVISION))
  shutil.copyfile(ROOT/'docs/officer-art-r2.md',base/'README.md')
  p=base/'game/export-receipt.json';r=json.loads(p.read_text());r['files']['index.html']=signature(base/'game/index.html');r['entry_router']={'version':REVISION,'variant':variant};write_json(p,r)
  r=json.loads((fresh/'site-receipt.json').read_text());r.update({'version':VERSION,'created_utc':utc_now(),'entry_router':{'version':REVISION,'variant':variant}})
  r['files']={p.relative_to(base).as_posix():signature(p)for p in base.rglob('*')if p.is_file()and not p.relative_to(base).as_posix().startswith('portrait/')and p.name!='site-receipt.json'};write_json(base/'site-receipt.json',r)
 changes={p.relative_to(site).as_posix():signature(p)for p in site.rglob('*')if p.is_file()and old.get(p.relative_to(site).as_posix())!=p.read_bytes()};removed=[n for n in old if not(site/n).is_file()]
 write_json(BUILD/'legal-r2/site-build.json',{'version':VERSION,'revision':REVISION,'parent':BASELINE,'game_source':source['game_source'],'changes':changes,'removed':removed,'both_views_current':True});print(json.dumps({'source':source['game_source'],'changed':len(changes),'removed':len(removed)},indent=2))
if __name__=='__main__':main()
