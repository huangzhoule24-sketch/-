extends RefCounted
## One replaceable NPC asset shared by both main-restaurant renderers.
static var _settings: Dictionary={}
static var _regions: Dictionary={}
static func settings() -> Dictionary:
	if _settings.is_empty():_settings=JSON.parse_string(FileAccess.get_file_as_string("res://config/npc_art.json")).tax_officer
	return _settings
static func texture(assets) -> Texture2D:
	if assets==null or not assets.has_image(str(settings().resource_id)):return null
	var raw=assets.get_texture(str(settings().resource_id))
	if assets.is_placeholder(raw):return null
	var key=raw.get_instance_id()
	if _regions.has(key):return _regions[key]
	var info=assets.get_resource_info(str(settings().resource_id))
	var full=Rect2(Vector2.ZERO,raw.get_size());var crop=full
	if str(info.get("custom_path","")).is_empty() and raw.get_size()==Vector2(settings().canvas[0],settings().canvas[1]):
		var c=settings().crop;crop=Rect2(c[0],c[1],c[2],c[3]).intersection(full)
	else:
		var image=raw.get_image()
		if image!=null and not image.is_empty():crop=Rect2(image.get_used_rect()).intersection(full)
	if not crop.has_area():return null
	var result=AtlasTexture.new();result.atlas=raw;result.region=crop;result.filter_clip=true
	_regions.clear()
	_regions[key]=result
	return result
static func bounds(assets,foot: Vector2) -> Rect2:
	var image=texture(assets);var h=float(settings().height)
	var w=h*image.get_width()/image.get_height() if image!=null else 42.0
	return Rect2(foot-Vector2(w*.5,h-float(settings().foot_inset)),Vector2(w,h))
static func draw(view,foot: Vector2) -> void:
	var image=texture(view.assets)
	if image!=null:
		view.draw_texture_rect(image,bounds(view.assets,foot),false)
	else:
		# A clerk-shaped fallback never borrows a customer or employee sprite.
		view.box(Rect2(foot-Vector2(14,39),Vector2(28,39)),Color("333553"),2)
		view.draw_circle(foot-Vector2(0,48),11,Color("e5b484"))
		view.box(Rect2(foot-Vector2(17,65),Vector2(34,11)),Color("292633"),1)
		view.box(Rect2(foot-Vector2(-6,38),Vector2(15,25)),Color("58734c"),1)
