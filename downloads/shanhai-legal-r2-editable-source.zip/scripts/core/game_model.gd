extends RefCounted





signal changed
signal notice(message: String)
signal autosave_requested

var sandbox = null
const SAVE_VERSION: = 5
const SaveMigration = preload("res://scripts/core/save_migration.gd")
const BalanceRegistry = preload("res://scripts/core/balance_registry.gd")
const FullRules = preload("res://scripts/core/full_rules.gd")
const AnimationRules = preload("res://scripts/ui/restaurant_view.gd")
const RestaurantSpace = preload("res://scripts/services/restaurant_space.gd")
const Navigation = preload("res://scripts/services/grid_navigation.gd")
const DemoRules = preload("res://scripts/core/demo_rules.gd")
const BALANCE_PATH: = "res://config/global_balance.json"
const EMPLOYEE_PATH: = "res://config/employees.json"
const DISH_PATH: = "res://config/dishes.json"
const DEFAULTS: = {
	"initial.cash": 800, "initial.debt": 1200, "initial.gems": 0,
	"initial.reputation": 20, "initial.ingredients": 20, "initial.freshness": 100, 
	"initial.comfort": 50, "initial.seats": 8, "initial.loyalty": 60, 
	"initial.mood": 100, "initial.stamina": 100, "time.start_minutes": 360, 
	"time.minutes_per_hour": 60, "day.minutes": 1440, "time.days_per_week":7, "time.days_per_month":10, "time.months_per_year":12, 
	"time.minutes_per_real_second":3.0,"time.default_speed":2,"time.maximum_speed":4,
	"economy.interest_rate": 0.005, "economy.minimum_repayment": 100, 
	"economy.rent": 60, "economy.utilities": 20, 
	"economy.overdue_reputation_penalty": 20, "economy.wage_loyalty_penalty": 10, 
	"economy.rent_reputation_penalty": 10, "economy.collection_overdue_days": 3, 
	"ingredient.unit_price": 3, "ingredient.daily_freshness_loss": 10, 
	"ingredient.autoprocure_multiplier": 1.2, "ingredient.history_days": 3, 
	"customer.base_flow": 6, "customer.reputation_bonus": 0.001, 
	"customer.max_reputation_bonus": 1, "customer.patience": 120, 
	"customer.full_loss_rep": 0, "customer.timeout_loss_rep": 2, 
	"customer.good_review_rep": 1, "customer.tip_chance": 0.05, 
	"customer.tip_fraction": 0.1, "customer.order_minutes": 2, 
	"customer.serve_minutes": 2, "customer.pay_minutes": 1, 
	"customer.clean_minutes": 2, "customer.type_weight_human": 0.7, 
	"customer.type_weight_monster": 0.2, "customer.type_weight_descendant": 0.08, 
	"customer.type_weight_special": 0.02, "customer.type_price_human": 1, 
	"customer.type_price_monster": 1.5, "customer.type_price_descendant": 3, 
	"customer.type_price_special": 5, 
	"traffic.closed": 0, "traffic.breakfast": 0.6, "traffic.rest": 0, 
	"traffic.lunch": 1, "traffic.tea": 0.5, "traffic.dinner": 1.2, 
	"traffic.night_market": 0.8, "promotion.cost": 20, 
	"promotion.bonus": 0.1, "promotion.duration": 120, 
	"employee.base_wage": 40, "employee.stamina_drain": 4, 
	"employee.rest_recovery": 12, "employee.max_stamina": 100, 
	"employee.max_mood": 100, "employee.fatigue_threshold": 20, 
	"employee.fatigue_efficiency": 0.7, "employee.daily_mood_decay": 1, 
	"employee.busy_stamina_multiplier": 1.2, 
	"employee.rarity_N": 0, "employee.rarity_R": 0.3, 
	"employee.rarity_SR": 0.8, "employee.rarity_SSR": 1.5, 
	"employee.role_waiter": 0, "employee.role_chef": 0.2, 
	"employee.role_salesman": 0.1, "employee.role_all": 0.4, "employee.role_tutor": 0.4, 
	"employee.loyalty_high_threshold": 80, "employee.loyalty_low_threshold": 30, 
	"employee.loyalty_high_mult": 0.9, "employee.loyalty_low_mult": 1.2, 
	"employee.training_base_cost": 50, "employee.training_minutes": 30, 
	"employee.training_success_base": 0.7, "employee.training_creativity_bonus": 0.02, 
	"employee.training_success_cap": 0.95, 
	"decoration.comfort_traffic_bonus": 0.001, 
	"prototype.base_quality": 75, "prototype.quality_per_cooking_point": 1, 
	"prototype.speed_attribute_factor": 0.03, "prototype.minimum_duration": 1, 
	"ingredient.freshness_quality_threshold": 50, "ingredient.freshness_quality_penalty": 0.1, 
	"dish.quality_poor_threshold": 60, "dish.quality_good_threshold": 80, 
	"dish.quality_excellent_threshold": 90, "dish.quality_max": 100, 
	"dish.quality_poor_price": 0.8, "dish.quality_normal_price": 1, 
	"dish.quality_good_price": 1.15, "dish.quality_excellent_price": 1.3, 
	"dish.quality_poor_reputation": -1, "customer.quality_good_review_rep": 2, 
	"hire.ticket_cost_normal": 200, "hire.ticket_cost_advanced": 5, 
	"hire.normal_pity_sr": 10, "hire.normal_pity_ssr": 50, 
	"hire.advanced_pity_sr": 10, "hire.advanced_pity_ssr": 30, 
	"hire.normal_probability_N": 0.6, "hire.normal_probability_R": 0.3, 
	"hire.normal_probability_SR": 0.09, "hire.normal_probability_SSR": 0.01, 
	"hire.advanced_probability_N": 0, "hire.advanced_probability_R": 0.4, 
	"hire.advanced_probability_SR": 0.5, "hire.advanced_probability_SSR": 0.1, 
	"hire.duplicate_fragments": 5, 
	"coeff.qianyang_soup_quality": 0.05, "coeff.owl_night_speed": 0.15, 
	"coeff.earmouse_serve_speed": 0.1, "coeff.bifang_bbq_quality": 0.3, 
	"coeff.pixiu_checkout_bonus": 0.15, "coeff.bond_ingredient_cost_mult": 0.05, 
	"coeff.tip_chance_bonus": 0.3, "coeff.cooking_speed_mult": 0.15, 
	"coeff.ingredient_cost_mult": 0.1, "coeff.hire_cost_mult": 0.05, 
}

var state: Dictionary = {}
var last_saved_minute: int = -1
var customers: Array[Dictionary] = []
var employees: Array[Dictionary] = []
var logs: Array = []
var balance: Dictionary = {}
var dishes: Array = []
var catalog: Array = []
var demo_config: Dictionary = {}
var events: Array = []
var decorations: Array = []
var bonds: Array = []
var quests_array: Array = []
var paused: = false
var speed: = 1
var scheduler: Array[Dictionary] = []
var _rng: = RandomNumberGenerator.new()
var _initial_seed: int
var _fraction: = 0.0
var _next_customer_id: = 1
var _next_spawn_minute: = 0
var _missing_keys: Dictionary = {}
var _rules: RefCounted
var full_rules: RefCounted
var _initial_dish_ids: Array = []


func _init(seed_value: int = 0) -> void :
	_initial_seed = seed_value
	_load_content()
	_rules = FullRules.new(self)
	full_rules = _rules
	reset_game()


func _load_content() -> void :
	var parsed = _read_json(BALANCE_PATH)
	if parsed is Dictionary and _validate_balance(parsed):
		balance = parsed
	else:
		push_warning("Balance configuration is unusable; loading documented foundation defaults.")
		balance = DEFAULTS.duplicate(true)
	var unified: Dictionary = BalanceRegistry.defaults()
	unified.merge(balance, true)
	if not unified.has("employee.role_tutor"): unified["employee.role_tutor"] = 0.4
	balance = unified
	parsed = _read_json(EMPLOYEE_PATH)
	catalog = parsed if parsed is Array else []
	parsed = _read_json(DISH_PATH)
	dishes = parsed if parsed is Array else []
	_initial_dish_ids.clear()
	for dish in dishes:
		if bool(dish.get("unlocked", false)): _initial_dish_ids.append(str(dish.id))
	parsed = _read_json("res://config/demo.json")
	demo_config = parsed if parsed is Dictionary else {}
	quests_array = demo_config.get("quests", [])
	parsed = _read_json("res://config/events.json")
	events = parsed if parsed is Array else []
	parsed = _read_json("res://config/decorations.json")
	decorations = parsed if parsed is Array else []
	parsed = _read_json("res://config/bonds.json")
	bonds = parsed if parsed is Array else []


func _read_json(path: String, report_errors: bool = true) -> Variant:
	if not FileAccess.file_exists(path):
		if report_errors: push_warning("Missing configuration: " + path)
		return null
	var file: = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return null
	var parser: = JSON.new()
	if parser.parse(file.get_as_text()) != OK:
		if report_errors: push_warning("Invalid JSON configuration: " + path)
		return null
	return parser.data


func _b(key: String) -> float:
	var value = balance.get(key)
	if value is int or value is float:
		return float(value)
	if not _missing_keys.has(key):
		_missing_keys[key] = true
		push_warning("Missing/invalid balance key '%s'; using documented foundation default." % key)
	return float(DEFAULTS.get(key, 0))


func reload_balance() -> bool:
	var parsed = _read_json(BALANCE_PATH)
	if not parsed is Dictionary or parsed.is_empty() or not _validate_balance(parsed):
		_notify("数值配置读取失败，继续使用当前配置")
		return false
	var unified: Dictionary = BalanceRegistry.defaults()
	unified.merge(parsed, true)
	balance = unified
	if _rules != null and _rules.has_method("refresh_balance"): _rules.refresh_balance()
	_missing_keys.clear()
	_notify("已重新载入数值配置")
	changed.emit()
	return true


func _config_value(candidate: Dictionary, key: String) -> float:
	return float(candidate.get(key, DEFAULTS.get(key, 0)))


func _validate_balance(candidate: Dictionary) -> bool:

	for key in candidate:
		if not key is String or not _number(candidate[key]): return false
	for key in ["day.minutes", "time.minutes_per_hour", "time.days_per_week", "time.days_per_month", "time.months_per_year", "ingredient.history_days", "initial.seats", "prototype.minimum_duration", "hire.normal_pity_sr", "hire.normal_pity_ssr", "hire.advanced_pity_sr", "hire.advanced_pity_ssr"]:
		if not _integer(_config_value(candidate, key), 1): return false
	if _config_value(candidate, "day.minutes") != 24 * _config_value(candidate, "time.minutes_per_hour"): return false
	for key in ["ingredient.unit_price", "employee.fatigue_efficiency", "dish.quality_max"]:
		if _config_value(candidate, key) <= 0: return false
	for key in ["prototype.speed_attribute_factor", "customer.base_flow", "customer.reputation_bonus", "customer.max_reputation_bonus", "employee.stamina_drain", "employee.rest_recovery", "ingredient.autoprocure_multiplier", "economy.interest_rate", "economy.minimum_repayment", "economy.rent", "economy.utilities", "promotion.cost", "promotion.duration", "promotion.bonus", "employee.training_base_cost", "employee.training_minutes"]:
		if _config_value(candidate, key) < 0: return false
	for key in ["initial.freshness", "initial.comfort", "initial.loyalty", "initial.mood", "initial.stamina", "ingredient.daily_freshness_loss"]:
		if _config_value(candidate, key) < 0 or _config_value(candidate, key) > 100: return false
	for key in ["customer.patience", "customer.order_minutes", "customer.serve_minutes", "customer.pay_minutes", "customer.clean_minutes"]:
		if _config_value(candidate, key) < 1: return false
	for key in ["customer.tip_chance", "customer.tip_fraction", "ingredient.freshness_quality_penalty", "employee.training_success_base", "employee.training_success_cap"]:
		if _config_value(candidate, key) < 0 or _config_value(candidate, key) > 1: return false
	var weight: = 0.0
	for customer_type in ["human", "monster", "descendant", "special"]:
		if _config_value(candidate, "customer.type_weight_" + customer_type) < 0 or _config_value(candidate, "customer.type_price_" + customer_type) <= 0: return false
		weight += _config_value(candidate, "customer.type_weight_" + customer_type)
	if not is_equal_approx(weight, 1): return false
	for kind in ["normal", "advanced"]:
		weight = 0
		for rarity in ["N", "R", "SR", "SSR"]:
			var probability: = _config_value(candidate, "hire." + kind + "_probability_" + rarity)
			if probability < 0 or probability > 1: return false
			weight += probability
		if not is_equal_approx(weight, 1): return false
		if _config_value(candidate, "hire.ticket_cost_" + kind) < 0: return false
	if _config_value(candidate, "hire.advanced_probability_N") != 0: return false
	for key in ["closed", "breakfast", "rest", "lunch", "tea", "dinner", "night_market"]:
		if _config_value(candidate, "traffic." + key) < 0: return false
	if _config_value(candidate, "dish.quality_poor_threshold") > _config_value(candidate, "dish.quality_good_threshold") or _config_value(candidate, "dish.quality_good_threshold") > _config_value(candidate, "dish.quality_excellent_threshold") or _config_value(candidate, "dish.quality_excellent_threshold") > _config_value(candidate, "dish.quality_max"): return false
	if not BalanceRegistry.validate(candidate): return false
	return true


func reset_game() -> void :
	if _initial_seed == 0:
		_rng.randomize()
	else:
		_rng.seed = _initial_seed
	state = {
		"total_minutes": int(_b("time.start_minutes")), "cash": _b("initial.cash"), 
		"debt": _b("initial.debt"), "gems": int(_b("initial.gems")), 
		"reputation": int(_b("initial.reputation")), "ingredients": _b("initial.ingredients"), 
		"freshness": _b("initial.freshness"), "comfort": _b("initial.comfort"), 
		"seats": int(_b("initial.seats")), "stage": 0, "daily_revenue": 0.0, 
		"total_revenue": 0.0, "served": 0, "lost": 0, "promotion_until": 0, 
		"last_report": {}, "overdue_count": 0, "interest_arrears": 0.0, 
		"daily_consumption": 0.0, "consumption_history": [], 
	}
	customers.clear()
	employees.clear()
	scheduler.clear()
	logs.clear()
	paused = false
	speed = 1
	_fraction = 0.0
	_next_customer_id = 1
	var waiters: Array = []
	var chefs: Array = []
	for entry in catalog:
		if str(entry.get("rarity", "")) == "N":
			if str(entry.get("role", "")) == "waiter":
				waiters.append(entry)
			elif str(entry.get("role", "")) == "chef":
				chefs.append(entry)
	if not waiters.is_empty():
		employees.append(_create_employee(waiters[_rng.randi_range(0, waiters.size() - 1)]))
	if not chefs.is_empty():
		employees.append(_create_employee(chefs[_rng.randi_range(0, chefs.size() - 1)]))
	_rules.ensure_state_defaults()
	_next_spawn_minute = int(state.total_minutes) + _spawn_interval()
	_log("白泽：有间小馆开张啦！先接待顾客，留意食材和员工体力。")
	changed.emit()


func _create_employee(entry: Dictionary) -> Dictionary:
	var result: = entry.duplicate(true)
	result.merge({"stamina": _b("initial.stamina"), "mood": _b("initial.mood"), 
		"loyalty": _b("initial.loyalty"), "resting": false, "training_until": 0, 
		"busy_until": 0, "busy_customer": 0, "fatigue_notified": false, "skill_level": 1, "wage_extra": 0, "management_until": 0, "expansion_until": 0, 
		"training_experience": 0, "research_until": 0}, true)
	result.attributes = entry.get("attributes", {}).duplicate(true)
	for attribute in ["cooking","speed","charm","endurance","eloquence","creativity","calculation"]:
		if not result.attributes.has(attribute): result.attributes[attribute] = 0
	if _full():
		result.level=1
		result.awakening_count=0
		initialize_employee_motion(result)
	return result


func period() -> String:
	var minute: = int(state.get("total_minutes", 0)) % int(_b("day.minutes"))
	var hour: = minute / int(_b("time.minutes_per_hour"))
	if hour < 6: return "closed"
	if hour < 10: return "breakfast"
	if hour < 11: return "rest"
	if hour < 14: return "lunch"
	if hour < 17: return "tea"
	if hour < 21: return "dinner"
	return "night_market"


func period_label() -> String:
	if _full() and full_rules.world.main_scene_active() and full_rules.world.main_shop_sealed(): return "主店查封中"
	return {"closed": "闭店休息", "breakfast": "早餐营业", "rest": "休息中（11:00 恢复营业）", 
		"lunch": "午餐营业", "tea": "下午茶营业", "dinner": "晚餐营业", "night_market": "夜市营业"}[period()]


func clock_label() -> String:
	var total: = int(state.total_minutes)
	var day_length: = int(_b("day.minutes"))
	var hour_length: = int(_b("time.minutes_per_hour"))
	var day: int = total / day_length
	var days_per_month: int = maxi(1,int(_b("time.days_per_month")))
	var months_per_year: int = maxi(1,int(_b("time.months_per_year")))
	var year_length: int = days_per_month * months_per_year
	return "%d年%d月%d日  %02d:%02d" % [day / year_length + 1, (day % year_length) / days_per_month + 1, day % days_per_month + 1, (total % day_length) / hour_length, total % hour_length]


func business_hours_open() -> bool:
	return period() != "closed" and period() != "rest"


func business_open() -> bool:
	return business_hours_open() and (not _full() or not full_rules.world.main_shop_sealed())


func set_speed(value: int) -> void :
	speed = clampi(value, 1, 128 if sandbox!=null else int(_b("time.maximum_speed")))
	changed.emit()


func set_paused(value: bool) -> void :
	if sandbox!=null:
		paused=value;changed.emit();return
	if not value and _full() and (full_rules.world.has_notice() or ((state.get("revision171",{}).get("daily_auto",false) or state.get("revision171",{}).get("daily_pending",false)) and int(state.finance.last_bill_day)>int(state.revision171.daily_seen))): return
	paused = value or _rescue_pending()
	changed.emit()


func real_time_rate() -> float:
	var factor = float(_rules.setting("time","time_factor",6)) if str(state.mode) == "demo" else (_b("time.minutes_per_real_second") if _full() else 1.0)
	return float(speed) * factor

func advance_real(delta: float) -> void :
	if _full() and state.has("revision18"):full_rules.revision18.advance_pickups(delta)
	if paused or delta <= 0 or not is_finite(delta):
		return
	_fraction += delta * real_time_rate()
	var count: = int(floor(_fraction))
	_fraction -= count
	if count > 0:
		for index in range(count):
			if paused: break
			_tick_minute()


			while not _full() and not business_open() and not paused: _tick_minute()
		changed.emit()


func advance_minutes(count: int) -> void :

	for index in range(maxi(0, count)):
		if _rescue_pending(): break
		_tick_minute()
	if count > 0:
		changed.emit()


func seal_shop_days(days: int) -> void:
	# Only the main eatery closes. Shared time and regional restaurants continue.
	var minutes = maxi(0, days) * maxi(1, int(_b("day.minutes")))
	if minutes <= 0: return
	full_rules.world.admin().sealed_until = int(state.total_minutes) + minutes
	for customer in customers.duplicate():
		_release_customer(customer)
		if bool(customer.get("ingredients_reserved", false)) and not bool(customer.get("paid", false)):
			full_rules.record("expenses", float(customer.get("ingredient_cost", 0)), "主店查封餐点报损")
		full_rules.visitors.finish(customer, true)
	customers.clear()
	# Keep training and other non-customer tasks in their existing scheduler.
	full_rules.culture_experience.tick()
	for employee in employees: _sync_worker(str(employee.id))
	_next_spawn_minute = int(state.total_minutes)
	changed.emit()


func skip_to_next_morning() -> void :
	var length: = int(_b("day.minutes"))
	var now: = int(state.total_minutes)
	var morning: = int(_b("time.start_minutes"))
	var target: = (now / length) * length + morning
	if target <= now:
		target += length
	advance_minutes(target - now)
	_notify("经营已暂停，请处理救援" if _rescue_pending() else "已完成日结，来到下一次清晨")


func _tick_minute() -> void :
	if sandbox!=null:sandbox.before_tick()
	if _rescue_pending(): return
	if _full() and (int(state.total_minutes) + 1) % int(_b("day.minutes")) == 0:
		save_game("user://campaign_recovery.json")
	state.total_minutes = int(state.total_minutes) + 1
	# Jobs and escrow payouts due exactly at midnight run before this day's
	# close. Give every movement in that atomic tick the same closing day.
	if _full() and int(state.total_minutes) % int(_b("day.minutes")) == 0:
		full_rules.finance.begin_day_close()
	if _full():full_rules.revision18.before_tick()
	_tick_employees()
	_tick_scheduler()
	_expire_customers()
	_assign_tasks()
	if business_open() and (not _full() or full_rules.revision18.accepting_guests()) and _b("customer.base_flow") > 0 and _b("traffic." + period()) > 0 and int(state.total_minutes) >= _next_spawn_minute:
		_spawn_customer()
		_next_spawn_minute = int(state.total_minutes) + _spawn_interval()
	_rules.tick()
	if int(state.total_minutes) % int(_b("day.minutes")) == 0:
		_settle_day()


func _spawn_interval() -> int:
	var reputation_bonus: = minf(_b("customer.max_reputation_bonus"), maxf(0, float(state.get("reputation", 0))) * _b("customer.reputation_bonus"))

	var comfort_bonus: = float(state.get("comfort", 0)) * _b("decoration.comfort_traffic_bonus")
	var promotion_bonus: = (float(state.get("promotion_bonus", 0)) if _full() else _b("promotion.bonus")) if int(state.get("promotion_until", 0)) > int(state.get("total_minutes", 0)) else 0.0
	var traffic: float = _b("customer.base_flow") * _b("traffic." + period()) * (1 + reputation_bonus) * (1 + comfort_bonus) * (1 + promotion_bonus) * _rules.traffic_multiplier()
	return maxi(1, int(floor(_b("time.minutes_per_hour") / traffic))) if traffic > 0 else int(_b("day.minutes"))


func _spawn_customer(forced_dish: String = "", batch: bool = true, booking_id: String = "") -> void :
	if _full() and (full_rules.world.main_shop_sealed() or not full_rules.revision18.accepting_guests()):return
	var seat: = -1
	for candidate in range(int(state.seats)):
		var occupied: = false
		for customer in customers:
			if int(customer.seat) == candidate:
				occupied = true
				break
		if not occupied:
			seat = candidate
			break
	if seat < 0:
		state.lost = int(state.lost) + 1
		state.reputation = maxi(0, int(state.reputation) - int(_b("customer.full_loss_rep")))
		return
	var menu: Array = []
	for dish in dishes:
		var id: = str(dish.id)
		if id in state.unlocked_dishes and id in state.menu_enabled and (str(state.mode) == "demo" or bool(dish.get("unlocked", false)) or not id in _initial_dish_ids):
			menu.append(dish)
	if menu.is_empty():
		if not _full(): return
		# Closed menus still receive visitors; service reports the unavailable order.
		for id in _initial_dish_ids:
			var fallback: Dictionary = _dish(str(id))
			if not fallback.is_empty(): menu.append(fallback)
		if menu.is_empty(): return
	var dish: Dictionary = menu[_rng.randi_range(0, menu.size() - 1)]
	var profile: Dictionary = full_rules.preferences.generate_profile() if _full() else {}
	if _full():
		# A legal placeholder is persisted until the actual service phase chooses
		# an order. Arrival generation never consults inventory or freshness.
		dish = _dish(str(_initial_dish_ids[0]))
	if forced_dish != "": dish = _dish(forced_dish)
	if dish.is_empty(): return
	var customer_type: String = "human" if not booking_id.is_empty() else _roll_customer_type()
	if _full() and booking_id.is_empty() and not full_rules.effects.allow_customer(customer_type):
		state.lost = int(state.lost) + 1
		return
	var price: = floorf(float(dish.price) * _b("customer.type_price_" + customer_type))
	customers.append({"id": _next_customer_id, "seat": seat, "stage": "ordering", 
		"dish_id": str(dish.id), "type": customer_type, "due_minute": -1, 
		"arrival_minute": int(state.total_minutes), "price": price, 
		"worker": "", "ingredients_reserved": false, "remaining_minutes": 0, 
		"paid": false, "quality": _b("prototype.base_quality"), "task_started_minute": int(state.total_minutes), "tip_bonus": 0.0})
	_next_customer_id += 1
	if _full():
		var created: Dictionary = customers.back()
		if full_rules.dollhouse.enabled():full_rules.dollhouse.begin_arrival(created)
		created.preference_profile = profile
		created.preference_reasons = full_rules.preferences.explain(dish,profile)
		created.order_decided = forced_dish != ""
		created.recommendation_done = forced_dish != ""
		full_rules.customer_service.prepare_customer(created)
		if booking_id.is_empty(): full_rules.visitors.prepare(created)
		else: created.culture_booking_id = booking_id
		if batch:
			# Party size belongs to arrivals, independently of the dish and stock.
			var size: int = 1
			if forced_dish == "jiuying_platter": size = maxi(1,int(_b("coeff.jiuying_batch")))
			var group_bonus: float = full_rules.world.modifier("group") - 1.0
			if group_bonus > 0 and _rng.randf() < minf(1.0, group_bonus): size = maxi(size, 3)
			var members: Array = [created]
			for index in range(maxi(0,size-1)):
				var before: int = customers.size()
				_spawn_customer(forced_dish, false)
				if customers.size() > before: members.append(customers.back())
			if members.size() > 1:
				for member in members:
					member.group_id = int(created.id)
					member.group_size = members.size()
					member.group_parallel = forced_dish == "jiuying_platter"


func _roll_customer_type() -> String:
	var extra: float = full_rules.effects.special_customer_bonus() if _full() else 0.0
	var roll: = _rng.randf() * (1.0 + extra)
	var cumulative: = 0.0
	for customer_type in ["human", "monster", "descendant", "special"]:
		cumulative += _b("customer.type_weight_" + customer_type) + (extra if customer_type == "special" else 0)
		if roll < cumulative: return customer_type
	return "human"


func _employee(id: String) -> Dictionary:
	for employee in employees:
		if str(employee.id) == id: return employee
	return {}


func _customer(id: int) -> Dictionary:
	for customer in customers:
		if int(customer.id) == id: return customer
	return {}


func _dish(id: String) -> Dictionary:
	for dish in dishes:
		if str(dish.id) == id: return dish
	if full_rules != null and full_rules.management != null:
		var hidden: Dictionary = full_rules.management.config.get("hidden_recipe", {})
		if str(hidden.get("id", "")) == id: return hidden
	return {}


func _worker_for(task: String, customer: Dictionary = {}) -> Dictionary:
	if _full() and full_rules.dollhouse.enabled():return full_rules.dollhouse.select_worker(task,customer)
	var roles: Array = ["chef", "all"] if task == "cooking" else (["salesman", "all"] if task == "recommending" else (["salesman", "all", "waiter"] if task == "paying" else ["waiter", "all"]))
	for role in roles:
		for employee in employees:
			if bool(employee.resting) or int(employee.training_until) > int(state.total_minutes) or int(employee.get("research_until", 0)) > int(state.total_minutes) or (float(employee.stamina) <= 0 and not (_full() and full_rules.revision18.draining(str(employee.id)))): continue
			if _full() and (int(employee.get("management_until", 0)) > int(state.total_minutes) or int(employee.get("expansion_until", 0)) > int(state.total_minutes) or str(employee.get("branch_id", "")) != ""): continue
			if _full() and not full_rules.active(str(employee.id)): continue
			if _full() and full_rules.effects.has_method("employee_handles_complaint") and full_rules.effects.employee_handles_complaint(str(employee.id)): continue
			if task == "recommending" and not full_rules.customer_service.can_recommend(employee, customer): continue
			var capacity = maxi(1,int(_b("coeff.jiuying_batch"))) if _full() and str(employee.id) == "jiu_ying" and task == "cooking" else 1
			if _full() and str(employee.id) == "jiu_ying" and task == "cooking": capacity = maxi(capacity,int(full_rules.sidequests.modifiers().get("jiuying_batch_capacity", capacity)))
			if task == "cooking" and bool(customer.get("group_parallel",false)):
				var same_group: bool = true
				for job in customers:
					if str(job.get("worker","")) == str(employee.id) and int(job.get("due_minute",-1)) >= 0 and int(job.get("group_id",-1)) != int(customer.get("group_id",-2)): same_group = false
				if same_group: capacity = maxi(capacity,int(customer.get("group_size",1)))
			if _worker_task_count(str(employee.id)) >= capacity: continue
			if str(employee.role) == role: return employee
	return {}

func _worker_task_count(id: String) -> int:
	var count = 0
	for customer in customers:
		if str(customer.get("worker", "")) == id and int(customer.get("due_minute", -1)) >= 0: count += 1
	return count

func _sync_worker(id: String) -> void:
	var employee = _employee(id)
	if employee.is_empty(): return
	employee.busy_customer = 0
	employee.busy_until = 0
	for customer in customers:
		if str(customer.get("worker", "")) == id and int(customer.get("due_minute", -1)) >= 0:
			employee.busy_customer = int(customer.id)
			employee.busy_until = int(customer.due_minute)
			if customer.get("task_motion") is Dictionary:
				employee.motion = customer.task_motion.duplicate(true)
			return
	if employee.get("motion") is Dictionary:
		var point: Dictionary = _point_data(motion_position(employee))
		employee.motion = {"origin":point,"target":point.duplicate(),"path":[],"started":int(state.total_minutes),"speed":0.0,"travel_minutes":0.0,"work_minutes":0.0,"action":"Idle","blocked":false}
		if _full(): initialize_employee_motion(employee,true)


func _motion_point(value: Variant) -> Vector2:
	if value is Dictionary: return Vector2(float(value.get("x", 0)), float(value.get("y", 0)))
	return Vector2.ZERO


func _point_data(point: Vector2) -> Dictionary:
	return {"x":point.x, "y":point.y}


func initialize_employee_motion(employee: Dictionary, refresh_idle: bool = false) -> void:
	if int(employee.get("busy_customer",0)) != 0: return
	var previous: Dictionary = employee.get("motion", {})
	if not previous.is_empty() and (not refresh_idle or not str(previous.get("action", "")) in ["Idle","Rest","Promote","Build"]): return
	# Cultivation may change an employee still walking to an idle station. Rebase
	# the remaining route at the current position so the new speed never jumps.
	var started: float = float(state.total_minutes) + _fraction if not previous.is_empty() else float(state.total_minutes)
	var origin: Vector2 = motion_position(employee, started) if not previous.is_empty() else RestaurantSpace.spawn_position(self,employee)
	var target: Vector2 = RestaurantSpace.employee_station(self,employee) if previous.is_empty() or refresh_idle else _motion_point(previous.target)
	var route: Dictionary = RestaurantSpace.find_route(self,origin,target)
	var speed: float = float(AnimationRules.animation_settings(balance).base_move_pixels_per_game_minute) * AnimationRules.animation_factor(employee,"Move",balance)
	var points: Array = []
	for point in route.points: points.append(_point_data(point))
	var travel: float = Navigation.remaining_length(origin,route.points,0)/maxf(0.001,speed) if not bool(route.blocked) else 0.0
	if bool(route.blocked): target=origin; points=[]
	employee.motion = {"origin":_point_data(origin),"target":_point_data(target),"path":points,"started":started if not previous.is_empty() else int(state.total_minutes),"speed":speed,"travel_minutes":travel,"work_minutes":0.0,"action":"Idle","blocked":bool(route.blocked)}


func motion_position(employee: Dictionary, at_minute: float = -1.0) -> Vector2:
	var motion: Dictionary = employee.get("motion", {})
	if motion.is_empty(): return Vector2(510, 512)
	var origin: Vector2 = _motion_point(motion.get("origin", {}))
	var points: Array[Vector2] = []
	for value in motion.get("path", []): points.append(_motion_point(value))
	var now: float = float(state.total_minutes) if at_minute < 0 else at_minute
	if bool(motion.get("teleport",false)):return _motion_point(motion.target)
	var distance: float = maxf(0, now - float(motion.get("started", now))) * float(motion.get("speed", 0))
	return Navigation.advance(origin, points, 0, distance).position


func _task_motion(worker: Dictionary, customer: Dictionary, work_minutes: float) -> Dictionary:
	var origin: Vector2 = motion_position(worker)
	var target: Vector2 = RestaurantSpace.task_target(self, worker, customer)
	var equipment_plan: Dictionary={}
	if _full() and full_rules.dollhouse.enabled():
		equipment_plan=full_rules.dollhouse.plan(worker,str(customer.stage),customer)
		if equipment_plan.is_empty():return {}
		target=equipment_plan.target
	var task: String = str(customer.stage)
	var dish: Dictionary = _dish(str(customer.dish_id))
	var ignores: bool = full_rules.effects.ignores_obstacles(worker, dish, task)
	var route: Dictionary = equipment_plan.route if not equipment_plan.is_empty() else RestaurantSpace.find_route(self, origin, target, ignores)
	if bool(route.get("blocked", false)): return {}
	var speed_factor: float = _rules.speed_multiplier(worker, task)
	if float(worker.stamina) <= _b("employee.fatigue_threshold"): speed_factor *= _b("employee.fatigue_efficiency")
	var move_speed: float = float(AnimationRules.animation_settings(balance).base_move_pixels_per_game_minute) * AnimationRules.animation_factor(worker, "Move", balance) * speed_factor
	var points: Array = []
	for point in route.points: points.append(_point_data(point))
	var length: float = float(route.length) if not equipment_plan.is_empty() else Navigation.remaining_length(origin,route.points,0)
	if not equipment_plan.is_empty():customer.device_uid=equipment_plan.device_uid
	var travel=length/maxf(.001,move_speed)
	if not equipment_plan.is_empty() and task=="paying":travel=maxf(travel,full_rules.dollhouse.prepare_checkout(customer,equipment_plan))
	return {"origin":_point_data(origin), "target":_point_data(target), "path":points,
		"started":int(state.total_minutes), "speed":move_speed, "travel_minutes":travel,
		"work_minutes":work_minutes, "blocked":false,
		"ignore_obstacles":ignores,"teleport":bool(equipment_plan.get("teleport",false)),
		"action":{"cooking":"Cook", "paying":"Cashier", "cleaning":"Clean", "ordering":"Order", "recommending":"Order"}.get(task,"Serve")}


func _valid_motion(value: Variant) -> bool:
	if not value is Dictionary: return false
	for key in ["origin", "target"]:
		if not value.get(key) is Dictionary: return false
		for axis in ["x", "y"]:
			if not _number(value[key].get(axis)) or absf(float(value[key][axis])) > 10000: return false
	if not value.get("path") is Array or value.path.size() > 512: return false
	for point in value.path:
		if not point is Dictionary or not _number(point.get("x")) or not _number(point.get("y")): return false
	for key in ["started", "speed", "travel_minutes", "work_minutes"]:
		if not _number(value.get(key)) or float(value[key]) < 0: return false
	return str(value.get("action", "")) in ["Idle", "Cook", "Serve", "Clean", "Cashier", "Promote","Order","Recommend","Rest","Build"] and value.get("blocked") is bool


func _assign_tasks() -> void :

	for task in ["serving", "paying", "cleaning", "ordering", "recommending", "queued", "cooking"]:
		for customer in customers.duplicate():
			if str(customer.stage) != task or int(customer.due_minute) >= 0:
				continue
			if _full() and full_rules.dollhouse.enabled() and int(customer.get("arrival_due",0))>int(state.total_minutes):continue
			var effective_task: String = "cooking" if task == "queued" else task
			if _full() and task == "ordering" and not bool(customer.get("order_decided", customer.get("recommendation_done", false))):
				var default_dish: Dictionary = full_rules.customer_service.choose_default_dish(customer)
				if not default_dish.is_empty(): full_rules.customer_service.apply_choice(customer, default_dish)
				customer.order_decided = true
				customer.recommendation_done = true
				full_rules.effects.prepare_customer(customer)
			if effective_task == "cooking" and bool(customer.get("group_parallel",false)):
				var ready_group: bool = true
				for member in customers:
					if int(member.get("group_id",-1)) == int(customer.get("group_id",-2)) and not str(member.stage) in ["queued","cooking","serving","eating","paying","cleaning"]: ready_group = false
				if not ready_group: continue
			var worker: = _worker_for(effective_task,customer)
			if worker.is_empty(): continue
			if _full() and full_rules.dollhouse.enabled():full_rules.dollhouse.release_aux(str(worker.id))
			var dish: = _dish(str(customer.dish_id))
			var duration: = 1.0
			var resuming: = int(customer.remaining_minutes) > 0
			if effective_task == "cooking":
				if int(state.kitchen_pause_until) > int(state.total_minutes): continue
				var units: float = float(dish.cost) / _b("ingredient.unit_price") * _rules.ingredient_multiplier(worker)
				if not bool(customer.ingredients_reserved):
					if _full():
						var consumed = full_rules.management.consume(str(dish.id), full_rules.ingredient_for_dish(worker, dish), false)
						if not consumed.get("ok", false):
							var missing: Dictionary = full_rules.customer_service.stockout(customer, dish)
							if missing.get("leave", false):
								full_rules.visitors.finish(customer,true)
								if full_rules.dollhouse.enabled():full_rules.dollhouse.begin_exit(customer)
								_release_customer(customer); customers.erase(customer); state.lost = int(state.lost) + 1
							else: customer.stage = "queued"
							continue
						customer.ingredient_cost = float(consumed.get("cost", dish.cost))
					else:
						if float(state.ingredients) + 1e-05 < units: continue
						state.ingredients = maxf(0, float(state.ingredients) - units)
						state.daily_consumption = float(state.daily_consumption) + units
					customer.ingredients_reserved = true


					var attrs: Dictionary = worker.get("attributes", {})
					var dish_quality: float = full_rules.management.dish_quality(str(dish.id)) if _full() else _b("prototype.base_quality")
					customer.quality = clampf((dish_quality + float(attrs.get("cooking", 0)) * _b("prototype.quality_per_cooking_point")) * _rules.quality_multiplier(worker, dish), 0, _b("dish.quality_max"))
					if not _full() and float(state.freshness) < _b("ingredient.freshness_quality_threshold"):
						customer.quality = float(customer.quality) * (1 - _b("ingredient.freshness_quality_penalty"))
					var raw_price: float = float(dish.price) * _b("customer.type_price_" + str(customer.type)) * _quality_price(float(customer.quality)) * _rules.price_multiplier()
					customer.price = raw_price if _full() else floorf(raw_price)
					if _full():
						var fx = full_rules.management.modifiers(str(dish.id), worker)
						customer.dish_effects = fx
						customer.chef_id = str(worker.id)
						full_rules.culture_experience.on_cooking_started(customer,worker)
						customer.quoted_dish_price = float(dish.price)
						customer.price_sources = full_rules.customer_service.collect_price_sources(dish, worker)
						customer.price_quote = full_rules.customer_service.price_quote(dish, float(customer.quality), customer, {}, customer.price_sources)
						customer.price = float(customer.price_quote.final)
						if not full_rules.dollhouse.enabled():full_rules.world.on_hook("cooking", {"employee_id":str(worker.id),"dish_id":str(dish.id),"customer_id":int(customer.id)})
						full_rules.revision18.on_cooking()
				customer.stage = "cooking"
				duration = float(customer.remaining_minutes) if resuming else float(dish.cook_minutes)
			elif effective_task == "recommending":
				duration = float(customer.remaining_minutes) if resuming else full_rules.customer_service.recommend_work_minutes()
			else:
				duration = float(customer.remaining_minutes) if resuming else _b("customer." + {"ordering": "order", "serving": "serve", "paying": "pay", "cleaning": "clean"}[effective_task] + "_minutes")
			var attributes: Dictionary = worker.get("attributes", {})
			if not resuming:
				if _full():
					duration /= AnimationRules.animation_factor(worker, effective_task, balance)
					duration *= full_rules.effects.work_multiplier(worker, effective_task, dish)
					duration *= full_rules.culture_experience.work_multiplier(worker,effective_task,dish)
					if full_rules.dollhouse.enabled():duration*=full_rules.dollhouse.work_multiplier(effective_task)
					if effective_task == "cooking": duration /= float(full_rules.management.modifiers(str(dish.id), worker).get("cook_speed", 1.0))
					if effective_task == "serving": duration *= float(full_rules.management.modifiers(str(dish.id), worker).get("serve_mult", 1.0))
				else:
					duration /= 1 + float(attributes.get("speed", 0)) * _b("prototype.speed_attribute_factor")
				duration /= _rules.speed_multiplier(worker, effective_task)
				if float(worker.stamina) <= _b("employee.fatigue_threshold"):
					duration /= _b("employee.fatigue_efficiency")
			var motion: Dictionary = {}
			if _full():
				if effective_task == "cooking" and not resuming and full_rules.effects.has_method("kitchen_chaos_delay"): duration += full_rules.effects.kitchen_chaos_delay(customer, worker)
				# The scheduler owns both actual route travel and the work interval.
				# Rendering reads this same timeline and cannot finish a blocked job.
				var work_minutes: float = maxf(0, duration)
				motion = _task_motion(worker, customer, work_minutes)
				if motion.is_empty(): continue
				customer.task_motion = motion
				duration = float(motion.travel_minutes) + work_minutes
				if _worker_task_count(str(worker.id)) == 0: worker.motion = motion.duplicate(true)
			customer.worker = str(worker.id)
			customer.device_hook_fired = false
			customer.task_started_minute = int(state.total_minutes)
			customer.due_minute = int(state.total_minutes) + maxi(int(_b("prototype.minimum_duration")), int(ceil(duration)))
			customer.remaining_minutes = 0
			worker.busy_customer = int(customer.id)
			worker.busy_until = int(customer.due_minute)
			scheduler.append({"type": "customer_step", "due": int(customer.due_minute), "customer_id": int(customer.id), "stage": str(customer.stage), "employee_id": str(worker.id)})

	if _full() and full_rules.dollhouse.enabled():full_rules.dollhouse.align_batches()

func _tick_scheduler() -> void :
	var ready: Array[Dictionary] = []
	for index in range(scheduler.size() - 1, -1, -1):
		if int(scheduler[index].due) <= int(state.total_minutes):
			ready.push_front(scheduler[index])
			scheduler.remove_at(index)
	for event in ready:
		if str(event.type) == "customer_step":
			_complete_customer_step(event)
		elif str(event.type) == "training_finish":
			_finish_training(str(event.employee_id))
		elif str(event.type) == "research_finish":
			_rules.finish_research(str(event.dish_id))


func _complete_customer_step(event: Dictionary) -> void :
	var customer: = _customer(int(event.customer_id))
	if customer.is_empty() or str(customer.stage) != str(event.stage) or int(customer.due_minute) != int(event.due): return
	var worker: = _employee(str(event.get("employee_id", "")))
	customer.worker = ""
	customer.erase("device_uid")
	customer.due_minute = -1
	if not worker.is_empty(): _sync_worker(str(worker.id))
	match str(customer.stage):
		"recommending":
			customer.recommendation_done = true
			customer.recommendation_premium = 0.0
			customer.order_decided = true
			full_rules.effects.prepare_customer(customer)
			customer.stage = "ordering"
		"ordering":
			customer.stage = "queued"
			if _full(): full_rules.customer_service.record_order(customer)
		"cooking": customer.stage = "serving"
		"serving":
			customer.served_minute = int(state.total_minutes)
			customer.tip_bonus = minf(1.0, _rules.tip_bonus(worker))
			if _full():
				customer.tip_bonus = minf(1.0, float(customer.tip_bonus) + float(customer.get("dish_effects", {}).get("tip_bonus", 0)) + float(worker.get("attributes", {}).get("charm", 0)) * float(balance.get("coeff.charm_tip", 0.005)))
				full_rules.visitors.interact(customer,worker,"serving")
				full_rules.effects.after_serving(customer, worker)
				full_rules.world.on_hook("serving", {"employee_id":str(worker.get("id", "")),"dish_id":str(customer.dish_id),"customer_id":int(customer.id)})
				full_rules.sidequests.on_hook("serving", {"employee_id":str(worker.get("id", "")),"dish_id":str(customer.dish_id),"customer_id":int(customer.id)})
			customer.stage = "eating"
			customer.due_minute = int(state.total_minutes) + maxi(1, int(ceil(float(_dish(str(customer.dish_id)).eat_minutes) * float(customer.get("dish_effects", {}).get("eat_mult", 1)))))
			scheduler.append({"type": "customer_step", "due": int(customer.due_minute), "customer_id": int(customer.id), "stage": "eating", "employee_id": ""})
		"eating": customer.stage = "paying"
		"paying":
			if not bool(customer.paid):
				var personal_price: float = 1.0
				if _full():
					var attrs: Dictionary = worker.get("attributes", {})
					personal_price += float(attrs.get("charm",0)) * float(balance.get("coeff.charm_price",0.01)) + float(attrs.get("eloquence",0)) * float(balance.get("coeff.eloquence_price",0.01))
				var amount: = floorf(float(customer.price) * _rules.checkout_multiplier(worker) * personal_price + 0.000001)
				var tip: float = 0.0
				if _full():
					var dish: Dictionary = _dish(str(customer.dish_id)).duplicate(true)
					dish.price = float(customer.get("quoted_dish_price", dish.price))
					var sources: Dictionary = customer.get("price_sources", full_rules.customer_service.collect_price_sources(dish, _employee(str(customer.get("chef_id", "")))))
					var checkout_sources: Dictionary = full_rules.customer_service.collect_price_sources(dish, {}, worker)
					for source in checkout_sources.skill:
						if str(source).begins_with("employee:" + str(worker.id) + ":checkout"): sources.skill[source] = checkout_sources.skill[source]
					var attributes: Dictionary = worker.get("attributes", {})
					var personal: Dictionary = {} # v1.9.3 removes all personal price premiums.
					var gender: String = str(customer.get("preference_profile", {}).get("gender", ""))
					sources.bond["synergy:female_price"] = full_rules.synergies.bonus("female_price", {"gender":gender})
					customer.price_quote = full_rules.customer_service.price_quote(dish, float(customer.quality), customer, personal, sources)
					amount = float(customer.price_quote.final)
				var cashier_tip=0.0
				if _full() and full_rules.dollhouse.capable(worker,"salesman"):cashier_tip=float(worker.get("attributes",{}).get("charm",0))*float(balance.get("coeff.charm_tip",0.005))
				if _rng.randf() < minf(1, _b("customer.tip_chance") + maxf(float(customer.get("tip_bonus", 0)),cashier_tip)):
					tip = floorf(amount * _b("customer.tip_fraction"))
					amount += tip
				if _full():
					amount = full_rules.effects.adjust_checkout(customer, worker, amount)
					var escape: float = float(balance.get("customer.escape_probability", full_rules.config.defaults.escape_probability))
					if amount > 0 and full_rules.effects.payment_escaped(customer, worker, escape): amount = 0; _log("食客逃单，收银台与天狗可以降低风险")
					amount = full_rules.expansion.checkout_adjustment(amount)
					amount = minf(amount, float(customer.price_quote.cap))
					tip = minf(tip, amount)
					var ingredient_cost: float = float(customer.get("ingredient_cost", 0))
					full_rules.management.recognize_cost(ingredient_cost)
					full_rules.record("cost_of_sales", ingredient_cost, str(_dish(str(customer.dish_id)).name))
					full_rules.record("sales", amount, str(_dish(str(customer.dish_id)).name))
				var outstanding: float = full_rules.culture_experience.collect_payment(customer,amount) if _full() else amount
				var received: float = full_rules.world.collect_sales_receipt(outstanding) if _full() else outstanding
				var cash_tip: float = minf(tip, received)
				change_cash(received - cash_tip, "sales", "菜品收入：" + str(_dish(str(customer.dish_id)).name))
				change_cash(cash_tip, "tips", "顾客小费")
				if _full(): full_rules.finance.record_sale(amount, tip)
				state.daily_revenue = _money(float(state.daily_revenue) + amount)
				state.total_revenue = _money(float(state.total_revenue) + amount)
				state.served = int(state.served) + 1
				var review: = _b("customer.good_review_rep")
				if float(customer.get("quality", _b("prototype.base_quality"))) < _b("dish.quality_poor_threshold"):
					review = _b("dish.quality_poor_reputation")
				elif float(customer.get("quality", _b("prototype.base_quality"))) >= _b("dish.quality_good_threshold"):
					review = _b("customer.quality_good_review_rep")
				if _full():
					review += float(customer.get("dish_effects", {}).get("review_bonus", 0))
					review = full_rules.effects.review_adjustment(customer, review)
					full_rules.world.on_hook("paying", {"employee_id":str(worker.get("id", "")),"dish_id":str(customer.dish_id),"customer_id":int(customer.id),"amount":amount})
				state.reputation = maxi(0, int(state.reputation) + int(review))
				customer.paid = true
				if _full():
					customer.settled_amount = amount
					full_rules.effects.after_payment(customer, worker)
					full_rules.customer_service.record_sale(customer, amount, review)
					full_rules.sidequests.on_customer_served(customer, worker)
					full_rules.visitors.paid(customer)
					full_rules.culture_experience.on_paid(customer,amount,received)
					full_rules.revision18.on_sale(customer,worker,amount,review)
				_log("顾客结账 +￥%s" % str(amount))
			if _full() and full_rules.dollhouse.enabled():full_rules.dollhouse.begin_exit(customer)
			customer.stage = "cleaning"
		"cleaning":
			var previous_position=full_rules.dollhouse.guest_position(customer) if _full() and full_rules.dollhouse.enabled() else Vector2(INF,INF)
			if _full() and full_rules.visitors.next_course(customer):
				if full_rules.dollhouse.enabled():full_rules.dollhouse.begin_arrival(customer,previous_position)
				return
			if _full():
				var context: Dictionary = {"employee_id":str(worker.get("id", "")),"dish_id":str(customer.dish_id),"customer_id":int(customer.id)}
				full_rules.world.on_hook("cleaning", context)
				full_rules.sidequests.on_hook("cleaning", context)
			var repeat: float = 0.0 if customer.has("visitor_id") else minf(1.0,float(customer.get("dish_effects", {}).get("repeat_chance", 0))+float(customer.get("return_chance_bonus",0)))
			if _full() and int(customer.get("repeat_count",0)) == 0 and _rng.randf() < repeat and business_open() and full_rules.management.can_make(str(customer.dish_id)):
				# The same guest orders one more portion, retaining identity and seat.
				var id: int = int(customer.id)
				var seat: int = int(customer.seat)
				var type: String = str(customer.type)
				var dish_id: String = str(customer.dish_id)
				var profile: Dictionary = customer.get("preference_profile",{}).duplicate(true)
				customer.clear()
				customer.merge({"id":id,"seat":seat,"type":type,"dish_id":dish_id,"stage":"ordering",
					"due_minute":-1,"arrival_minute":int(state.total_minutes),"price":float(_dish(dish_id).price),
					"worker":"","ingredients_reserved":false,"remaining_minutes":0,"paid":false,
					"quality":_b("prototype.base_quality"),"task_started_minute":int(state.total_minutes),"tip_bonus":0.0,"repeat_count":1})
				if not profile.is_empty(): customer.preference_profile = profile
				full_rules.effects.prepare_customer(customer)
				_log("同一位食客又点了一份%s" % str(_dish(dish_id).name))
				return
			customers.erase(customer)


func _expire_customers() -> void :
	for index in range(customers.size() - 1, -1, -1):
		var customer: = customers[index]
		if _full() and full_rules.world.modifier("no_wait") > 1.0: continue
		if str(customer.stage) in ["ordering", "recommending", "queued", "cooking", "serving"] and (int(state.total_minutes) - int(customer.arrival_minute)) * (float(balance.get("customer.patience_order_rate" if str(customer.stage) in ["ordering","recommending"] else "customer.patience_cooking_rate",1.5)) if _full() else 1.0) >= int(_b("customer.patience") * float(customer.get("dish_effects", {}).get("patience_mult", 1))):
			if _full() and full_rules.dollhouse.enabled():full_rules.dollhouse.begin_exit(customer)
			_release_customer(customer)
			if _full() and bool(customer.get("ingredients_reserved", false)):
				full_rules.record("expenses", float(customer.get("ingredient_cost", 0)), "超时订单食材报损")
			customers.remove_at(index)
			state.lost = int(state.lost) + 1
			var complained: bool = not _full() or _rng.randf() < full_rules.effects.complaint_probability(customer)
			if _full():
				full_rules.customer_service.record_timeout(customer, complained)
				full_rules.visitors.finish(customer,true)
			if complained:
				state.reputation = maxi(0, int(state.reputation) - int(_b("customer.timeout_loss_rep")))
				_log("顾客等待超时离店，声望下降")
				if _full(): full_rules.world.on_hook("complaint", {"dish_id":str(customer.dish_id),"customer_id":int(customer.id)})


func _release_customer(customer: Dictionary) -> void :
	customer.erase("device_uid")
	var worker_id = str(customer.worker)
	customer.worker = ""
	_sync_worker(worker_id)
	for index in range(scheduler.size() - 1, -1, -1):
		if str(scheduler[index].type) == "customer_step" and int(scheduler[index].customer_id) == int(customer.id):
			scheduler.remove_at(index)


func _tick_employees() -> void :
	var hour_length: = _b("time.minutes_per_hour")
	for employee in employees:
		var recovering: = bool(employee.resting) or int(employee.training_until) > int(state.total_minutes) or int(employee.get("research_until", 0)) > int(state.total_minutes) or period() == "closed" or (_full() and (int(employee.get("management_until", 0)) > int(state.total_minutes) or int(employee.get("expansion_until", 0)) > int(state.total_minutes)))
		if _full() and full_rules.revision18.draining(str(employee.id)):recovering=false
		if _full() and str(employee.get("branch_id", "")) != "":
			if float(employee.stamina) <= 0: employee.branch_recovering = true
			if bool(employee.get("branch_recovering", false)) and float(employee.stamina) >= _b("employee.max_stamina"): employee.branch_recovering = false
			var off_shift: bool = bool(employee.get("shift_enabled",false)) and not period() in employee.get("shift_periods",[])
			recovering = period() == "closed" or off_shift or bool(employee.get("branch_recovering", false))
		if recovering:
			var recovery: float = full_rules.effects.rest_recovery_factor(employee) if _full() else 1.0
			if _full() and full_rules.dollhouse.enabled():recovery*=full_rules.dollhouse.rest_multiplier(employee)
			employee.stamina = minf(_b("employee.max_stamina"), float(employee.stamina) + _b("employee.rest_recovery") * recovery / hour_length)
		else:
			var multiplier: = _b("employee.busy_stamina_multiplier") if period() in ["lunch", "dinner"] else 1.0
			if _full(): multiplier *= full_rules.world.modifier("stamina", "", str(employee.id)) * full_rules.effects.stamina_drain_factor(employee)
			if _full() and str(employee.id) == "jiu_ying": multiplier *= 1.0 + _b("coeff.stamina_cost_mult")
			employee.stamina = maxf(0, float(employee.stamina) - _b("employee.stamina_drain") * multiplier / hour_length)
			if _full() and float(employee.stamina) <= 0: full_rules.world.on_hook("fatigue", {"employee_id":str(employee.id)})
			if float(employee.stamina) <= 0:
				set_employee_rest(str(employee.id), true)
				if bool(employee.resting):_notify(str(employee.name) + "体力耗尽，已自动休息")
		if float(employee.stamina) <= _b("employee.fatigue_threshold") and not bool(employee.fatigue_notified):
			employee.fatigue_notified = true
			_notify(str(employee.name) + "感到疲惫，工作效率下降")
		elif float(employee.stamina) > _b("employee.fatigue_threshold"):
			employee.fatigue_notified = false


func set_employee_rest(id: String, resting: bool, check_instruction: bool = true) -> void :
	var employee: = _employee(id)
	if employee.is_empty(): return
	if _full() and full_rules.revision18.defer_rest(employee,resting):return
	if check_instruction and _full() and (int(employee.get("v18_clean_until",0))>int(state.total_minutes) or int(employee.get("management_until",0))>int(state.total_minutes) or full_rules.revision.is_building(id)):
		_notify("培训、研发或装修期间不能重新排班，请等待项目完成")
		return
	if not resting and float(employee.stamina) <= 0:
		_notify("体力耗尽，先休息再上班")
		return
	if not resting and not _rules.can_return_to_work(id):
		_notify("当前阶段最多安排 %d 位员工当班，先让其他员工休息" % _rules.active_limit())
		return
	if check_instruction and _full() and float(employee.stamina) > 0 and bool(employee.resting) != resting and not full_rules.effects.instruction_allowed(employee):
		_notify("梼杌暂时拒绝了排班指令")
		return
	employee.resting = resting
	if _full() and full_rules.dollhouse.enabled():full_rules.dollhouse.release_aux(id)
	if check_instruction and _full():employee.v18_auto_rest=false
	if resting:
		for customer in customers:
			if str(customer.get("worker", "")) != id: continue
			customer.remaining_minutes = maxi(1, int(customer.due_minute) - int(state.total_minutes))
			if customer.get("task_motion") is Dictionary:
				var motion: Dictionary = customer.task_motion
				var worked: float = maxf(0, float(state.total_minutes) - float(motion.started) - float(motion.travel_minutes))
				customer.remaining_minutes = maxi(1, int(ceil(maxf(0, float(motion.work_minutes) - worked))))
			_release_customer(customer)
			customer.due_minute = -1
		if _full() and employee.get("motion") is Dictionary:
			var point: Dictionary = _point_data(motion_position(employee))
			employee.motion = {"origin":point,"target":point.duplicate(),"path":[],"started":int(state.total_minutes),"speed":0.0,"travel_minutes":0.0,"work_minutes":0.0,"action":"Idle","blocked":false}
	if _full(): initialize_employee_motion(employee,true)
	changed.emit()


func train_employee(id: String) -> bool:
	if _full():
		var employee = _employee(id)
		return bool(full_rules.perform("train_attribute", {"employee_id":id,"attribute":"cooking" if str(employee.get("role", "")) == "chef" else "speed"}).get("ok",false))
	var employee: = _employee(id)
	if employee.is_empty() or int(employee.training_until) > int(state.total_minutes) or int(employee.get("research_until", 0)) > int(state.total_minutes): return false
	var attrs: Dictionary = employee.get("attributes", {})
	var target: = "cooking" if str(employee.role) == "chef" else "speed"
	var multiplier: = 1 + _b("employee.rarity_" + str(employee.rarity))
	var cost: = _b("employee.training_base_cost") * multiplier * maxf(1, float(attrs.get(target, 1)))
	if float(state.cash) < cost:
		_notify("训练需要 ￥%d，现金不足" % int(cost))
		return false
	state.cash = _money(float(state.cash) - cost)
	var was_resting: = bool(employee.resting)
	set_employee_rest(id, true)
	employee.resting = was_resting
	employee.training_attribute = target
	employee.training_until = int(state.total_minutes) + int(ceil(_b("employee.training_minutes") * multiplier))
	scheduler.append({"type": "training_finish", "due": int(employee.training_until), "employee_id": id})
	_notify(str(employee.name) + "开始训练，期间暂停工作")
	changed.emit()
	return true


func _finish_training(id: String) -> void :
	var employee: = _employee(id)
	if employee.is_empty(): return
	var attrs: Dictionary = employee.get("attributes", {})
	var chance: = minf(_b("employee.training_success_cap"), _b("employee.training_success_base") + float(attrs.get("creativity", 0)) * _b("employee.training_creativity_bonus"))
	if _rng.randf() < chance:
		var target: String = str(employee.get("training_attribute", "speed"))
		attrs[target] = float(attrs.get(target, 1)) + 1
		employee.attributes = attrs
		_notify(str(employee.name) + "训练成功，" + ("厨艺" if target == "cooking" else "速度") + "+1")
	else:
		employee.training_experience = int(employee.training_experience) + 1
		_notify(str(employee.name) + "训练未成功，积累了训练经验")
	employee.training_until = 0


func _quality_price(quality: float) -> float:
	if quality < _b("dish.quality_poor_threshold"): return _b("dish.quality_poor_price")
	if quality < _b("dish.quality_good_threshold"): return _b("dish.quality_normal_price")
	if quality < _b("dish.quality_excellent_threshold"): return _b("dish.quality_good_price")
	return _b("dish.quality_excellent_price")


func buy_ingredients(units: int) -> bool:
	if _full(): return bool(full_rules.perform("purchase", {"id":"generic","quantity":units}).get("ok",false))
	if units <= 0: return false
	var cost: float = units * _rules.stock_price()
	if float(state.cash) < cost:
		_notify("食材采购需要 ￥%d，现金不足" % int(cost))
		return false
	_add_stock(units, cost)
	state.stats.purchases = int(state.stats.purchases) + 1
	_notify("采购 %d 份食材，支出 ￥%d" % [units, int(cost)])
	changed.emit()
	return true


func _add_stock(units: float, cost: float) -> void :
	var old_stock: = float(state.ingredients)
	state.cash = _money(float(state.cash) - cost)
	state.ingredients = old_stock + units
	if float(state.ingredients) > 0:
		state.freshness = (old_stock * float(state.freshness) + units * _b("initial.freshness")) / float(state.ingredients)


func promote() -> bool:
	if _full(): return bool(full_rules.perform("marketing", {"kind":"flyer"}).get("ok",false))
	if float(state.cash) < _b("promotion.cost"):
		_notify("现金不足，暂时无法发传单")
		return false
	state.cash = _money(float(state.cash) - _b("promotion.cost"))
	state.promotion_until = int(state.total_minutes) + int(_b("promotion.duration"))
	_next_spawn_minute = mini(_next_spawn_minute, int(state.total_minutes) + _spawn_interval())
	_notify("已发传单，接下来两小时客流增加")
	changed.emit()
	return true


func repay_debt(amount: int) -> bool:
	var payment: = minf(amount, float(state.debt))
	if payment <= 0 or float(state.cash) < payment:
		_notify("现金不足或已经还清债务")
		return false
	change_cash(-payment, "debt_principal", "手动偿还原始债务本金")
	state.debt = _money(float(state.debt) - payment)
	if _full(): full_rules.record("financing", -payment, "偿还本金")
	_notify("归还本金 ￥%d，剩余债务 ￥%d" % [int(payment), int(state.debt)])
	changed.emit()
	return true


func employee_wage(employee: Dictionary) -> float:
	var multiplier: = 1.0
	if float(employee.loyalty) >= _b("employee.loyalty_high_threshold"):
		multiplier = _b("employee.loyalty_high_mult")
	elif float(employee.loyalty) < _b("employee.loyalty_low_threshold"):
		multiplier = _b("employee.loyalty_low_mult")
	return floorf(_b("employee.base_wage") * (1 + _b("employee.rarity_" + str(employee.rarity)) + _b("employee.role_" + str(employee.role))) * multiplier) + float(employee.get("wage_extra", 0))


func _pay_available(amount: float) -> float:
	var paid: = minf(maxf(0, float(state.cash)), amount)
	change_cash(-paid, "liability_settlement", "清偿经营欠款")
	return _money(paid)


func settle_arrears() -> Dictionary:
	if not _full(): return {"ok":false,"reason":"需要完整经营模式"}
	var total: float = float(state.interest_arrears) + float(state.wage_arrears) + float(state.rent_arrears)
	if total <= 0 or float(state.cash) <= 0: return {"ok":false,"reason":"没有待清偿欠款或现金不足"}
	var paid: float = 0.0
	for key in ["interest_arrears", "wage_arrears", "rent_arrears"]:
		var amount: float = _pay_available(float(state[key]))
		state[key] = _money(float(state[key]) - amount)
		paid += amount
	# These liabilities were already expenses on the day they accrued.
	full_rules.record("liability_settlement", paid, "清偿欠息、欠薪与欠租；不重复计费用")
	_notify("已清偿经营欠款 ￥%.2f" % paid)
	return {"ok":true,"paid":paid,"remaining":_money(total-paid)}


func _settle_day() -> void :
	if _full():
		full_rules.finance.begin_day_close()
		full_rules.management.prepare_day_procurement()
		var daily: Dictionary = full_rules.finance.settle_daily_charges()
		full_rules.on_day()
		full_rules.finance.finish_day(daily)
		full_rules.customer_service.daily_rollover()
		state.daily_revenue = 0.0
		state.daily_consumption = 0.0
		_log("第%d天日结：收入￥%.2f，净利润￥%.2f，现金￥%.2f" % [int(daily.day), float(daily.revenue), float(daily.net_profit), float(state.cash)])
		autosave_requested.emit()
		if int(state.total_minutes) % (int(_b("time.days_per_month")) * int(_b("day.minutes"))) == 0: save_game("user://campaign_monthly.json")
		return


	var report: = {"day": int(state.total_minutes) / int(_b("day.minutes")), 
		"revenue": float(state.daily_revenue), "interest": 0.0, "repayment": 0.0, 
		"wages": 0.0, "wages_due": 0.0, "rent_utilities": 0.0, 
		"procurement": 0.0, "procured_units": 0, "overdue": false}
	var interest_due: = _money(float(state.debt) * _b("economy.interest_rate"))
	report.interest = _pay_available(interest_due)
	state.interest_arrears = _money(float(state.interest_arrears) + interest_due - float(report.interest))
	var minimum: = minf(float(state.debt), _b("economy.minimum_repayment"))
	if float(state.cash) >= minimum:
		report.repayment = _pay_available(minimum)
		state.debt = _money(float(state.debt) - minimum)
		state.overdue_count = 0
	else:
		report.overdue = true
		state.overdue_count = int(state.overdue_count) + 1
		state.reputation = maxi(0, int(state.reputation) - int(_b("economy.overdue_reputation_penalty")))
		if int(state.overdue_count) >= int(_b("economy.collection_overdue_days")):
			_log("债务连续逾期，白泽提醒：优先采购、恢复经营并归还欠款。")
	for employee in employees:
		var wage: = employee_wage(employee)
		report.wages_due = float(report.wages_due) + wage
		var paid: = _pay_available(wage)
		report.wages = float(report.wages) + paid
		if paid < wage:
			employee.loyalty = maxf(0, float(employee.loyalty) - _b("economy.wage_loyalty_penalty"))
		employee.mood = maxf(0, float(employee.mood) - _b("employee.daily_mood_decay") * (full_rules.effects.daily_mood_cost(employee) if _full() else 1.0))
	var rent_base: = _b("economy.rent") if int(state.stage) == 0 else float(balance.get("stage.%d.rent" % int(state.stage), _b("economy.rent")))
	var rent_due: = rent_base + _b("economy.utilities")
	report.rent_utilities = _pay_available(rent_due)
	if float(report.rent_utilities) < rent_due:
		state.reputation = maxi(0, int(state.reputation) - int(_b("economy.rent_reputation_penalty")))
		report.overdue = true
	if _full():
		state.wage_arrears = _money(float(state.wage_arrears) + float(report.wages_due) - float(report.wages))
		state.rent_arrears = _money(float(state.rent_arrears) + rent_due - float(report.rent_utilities))
		full_rules.record("expenses", interest_due + float(report.wages_due) + rent_due, "每日利息、工资与房租水电")
		full_rules.record("financing", -float(report.repayment), "自动偿还本金")
		var cash_before: float = float(state.cash)
		full_rules.on_day()
		report.procurement = maxf(0, cash_before - float(state.cash))
		state.day_reports.append(report.duplicate(true))
		while state.day_reports.size() > int(full_rules.config.economy.daily_report_limit): state.day_reports.pop_front()
	else:
		state.freshness = maxf(0, float(state.freshness) - _b("ingredient.daily_freshness_loss"))
		var history: Array = state.consumption_history
		history.append(float(state.daily_consumption))
		while history.size() > int(_b("ingredient.history_days")): history.pop_front()
		var average: = 0.0
		for consumed in history: average += float(consumed)
		average /= maxf(1, history.size())
	
	
		var requested: = int(ceil(average * _b("ingredient.autoprocure_multiplier")))
		var purchased: = mini(requested, int(floor(float(state.cash) / _rules.stock_price())))
		if purchased > 0:
			report.procurement = _money(purchased * _rules.stock_price())
			report.procured_units = purchased
			_add_stock(purchased, float(report.procurement))
	state.last_report = report
	state.daily_revenue = 0.0
	state.daily_consumption = 0.0
	_log("第 %d 天日结：营业额 ￥%s，工资 ￥%s，房租水电 ￥%s" % [int(report.day), str(report.revenue), str(report.wages), str(report.rent_utilities)])
	autosave_requested.emit()
	if _full() and int(state.total_minutes) % (int(_b("time.days_per_month")) * int(_b("day.minutes"))) == 0: save_game("user://campaign_monthly.json")


func _tick_resignations() -> void:
	var resigning: Array[String] = []
	for employee in employees:
		if float(employee.mood) > _b("employee.quit_mood_threshold"): continue
		var probability: float = _b("employee.high_loyalty_quit_chance") if float(employee.loyalty) >= _b("employee.loyalty_high_threshold") else _b("employee.quit_chance")
		if _full() and float(employee.get("affinity", 0)) >= 80: probability *= 0.5
		if _rng.randf() < probability: resigning.append(str(employee.id))
	for id in resigning:
		set_employee_rest(id, true)
		var employee = _employee(id)
		if int(employee.get("management_until", 0)) > int(state.total_minutes) or int(employee.get("expansion_until", 0)) > int(state.total_minutes): continue
		employees.erase(employee)
		_notify("%s因长期低心情离职，请及时排班与沟通。" % str(employee.name))


func _money(amount: float) -> float:
	return roundf(amount * 100) / 100.0


func change_cash(delta: float, category: String = "other", description: String = "现金变动") -> float:
	if _full() and full_rules.finance != null: return full_rules.finance.cash_change(delta, category, description)
	var before: float = float(state.cash)
	state.cash = _money(before + delta)
	return _money(float(state.cash) - before)


func _rescue_pending() -> bool:
	if sandbox!=null and bool(sandbox.options().get("protect",true)):return false
	if _full() and (full_rules.world.has_notice() or ((state.get("revision171",{}).get("daily_auto",false) or state.get("revision171",{}).get("daily_pending",false)) and int(state.finance.last_bill_day)>int(state.revision171.daily_seen)) or (state.get("rescue171") is Dictionary and (bool(state.rescue171.ended) or bool(state.rescue171.warning_pending)))): return true
	return _full() and bool(state.get("finance", {}).get("rescue", {}).get("pending", false))


func restart_campaign_with_keepsakes() -> Dictionary:
	if sandbox!=null:
		sandbox.start();return {"ok":true,"message":"自由体验进度已重建"}
	var collection: Array = state.get("story", {}).get("collected_ids", []).duplicate(true)
	var lore: Array = state.get("sidequests", {}).get("lore_unlocked", []).duplicate(true)
	var archives: Dictionary = state.get("permanent_archives", {}).duplicate(true)
	for id in state.get("story", {}).get("completed", []): archives[str(id)] = true
	var visitor_records: Dictionary=state.get("special_visitors",{}).get("records",{}).duplicate(true)
	var visitor_history: Array=state.get("special_visitors",{}).get("history",[]).duplicate(true)
	var visitor_next: int=int(state.get("special_visitors",{}).get("next_visit",1))
	var baize_pages: Array=state.get("sidequests",{}).get("pages",[]).duplicate()
	var visitor_lore: Array=state.get("special_visitors",{}).get("lore",[]).duplicate()
	var baize_bonus: float=float(state.get("revision171",{}).get("baize_bonus",0))
	var baize_quest: Dictionary=state.get("sidequests",{}).get("quests",{}).get("baize_atlas",{}).duplicate(true)
	start_full()
	state.special_visitors.records=visitor_records
	state.special_visitors.history=visitor_history
	for entry in state.special_visitors.history: entry.minute=0 # Permanent archive belongs to a preceding run.
	state.special_visitors.next_visit=visitor_next
	state.sidequests.pages=baize_pages
	state.special_visitors.lore=visitor_lore
	state.special_visitors.achievement=visitor_records.size()==full_rules.visitors.definitions().size()
	state.revision171.baize_bonus=baize_bonus
	if not baize_quest.is_empty():
		if int(baize_quest.get("completed_minute",-1))>=0:baize_quest.completed_minute=0
		state.sidequests.quests["baize_atlas"]=baize_quest
	for id in collection:
		if not id in state.story.collected_ids: state.story.collected_ids.append(id)
	state.sidequests.lore_unlocked = lore
	state.permanent_archives = archives
	_notify("已重开本局；图鉴收藏、山海志与成就记录保留。")
	autosave_requested.emit()
	return {"ok":true,"message":"已重开本局并保留永久收集"}


func load_recovery_save(path: String = "user://campaign_recovery.json") -> Dictionary:
	if load_game(path):
		paused = true
		return {"ok":true,"message":"已读取最近的安全存档，当前暂停，可重新安排经营"}
	return {"ok":false,"reason":"没有可用的安全存档，当前进度已保留"}


func _log(message: String) -> void :
	logs.append(clock_label() + "  " + message)
	while logs.size() > 80: logs.pop_front()


func _notify(message: String) -> void :
	_log(message)
	notice.emit(message)


func save_game(path: String = "user://savegame.json") -> bool:
	if sandbox!=null:return sandbox.save()
	var payload: = {"version": SAVE_VERSION, "state": state, "customers": customers, 
		"employees": employees, "logs": logs, "scheduler": scheduler, "paused": paused, 
		"speed": speed, "fraction": _fraction, "next_customer_id": _next_customer_id, 
		"next_spawn_minute": _next_spawn_minute, "rng_state": str(_rng.state), 
		"rng_seed": str(_rng.seed), "initial_seed": str(_initial_seed)}
	var temporary: = path + ".tmp"
	var file: = FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		_notify("存档失败：无法写入文件")
		return false
	file.store_string(JSON.stringify(payload, "", true, true))
	file.flush()
	file.close()
	var error: = DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(path))
	if error != OK:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(temporary))
		_notify("存档失败：无法替换存档文件")
		return false
	last_saved_minute = int(state.total_minutes)
	if path == "user://campaign_savegame.json" and _full() and not _rescue_pending():
		save_game("user://campaign_recovery.json")
	return true


func load_game(path: String = "user://savegame.json", import_to_full: bool = false) -> bool:
	if sandbox!=null:return sandbox.load_save()
	var incoming=_read_json(path,false)
	if incoming is Dictionary and incoming.get("sandbox_format",0)!=0:return false
	var payload = SaveMigration.migrate(incoming, self, import_to_full)
	if not _valid_save(payload):
		_notify("没有可用存档或存档内容损坏，当前进度已保留")
		return false


	state = payload.state.duplicate(true)
	if int(payload.version) == 1:
		for key in DemoRules.CHAPTER_KEYS: state.erase(key)
	for key in ["total_minutes", "gems", "reputation", "seats", "stage", "served", "lost", "promotion_until", "overdue_count", "event_last_minute", "decorations_purchased", "hire_tickets", "discount_until", "kitchen_pause_until"]:
		if not state.has(key): continue
		state[key] = int(state[key])
	for key in ["day", "procured_units"]:
		if state.last_report.has(key): state.last_report[key] = int(state.last_report[key])
	customers.clear()
	for entry in payload.customers:
		var customer: Dictionary = entry.duplicate(true)
		for key in ["id", "seat", "due_minute", "arrival_minute", "remaining_minutes", "task_started_minute"]:
			if not customer.has(key): continue
			customer[key] = int(customer[key])
		customers.append(customer)
	employees.clear()
	for entry in payload.employees:
		var employee: Dictionary = entry.duplicate(true)
		if int(payload.version) == 1: employee.research_until = 0
		for key in ["training_until", "busy_until", "busy_customer", "training_experience", "research_until"]:
			if not employee.has(key): continue
			employee[key] = int(employee[key])
		employees.append(employee)
	scheduler.clear()
	for entry in payload.scheduler:
		var event: Dictionary = entry.duplicate(true)
		event.due = int(event.due)
		if event.has("customer_id"): event.customer_id = int(event.customer_id)
		scheduler.append(event)
	logs = payload.logs.duplicate(true)
	paused = bool(payload.paused)
	if _rescue_pending(): paused = true
	speed = int(payload.speed)
	_fraction = float(payload.fraction)
	_next_customer_id = int(payload.next_customer_id)
	_next_spawn_minute = int(payload.next_spawn_minute)
	_initial_seed = str(payload.initial_seed).to_int()
	_rng.seed = str(payload.rng_seed).to_int()
	_rng.state = str(payload.rng_state).to_int()
	if int(payload.version) == 1: _rules.discard_legacy_chapter_fields()
	_rules.ensure_state_defaults()
	_normalize_demo_state()
	if bool(state.get("developer_mode", false)) and state.get("balance_overrides", {}) is Dictionary:
		var candidate = balance.duplicate(true)
		candidate.merge(BalanceRegistry.normalize_overrides(state.get("balance_overrides", {})), true)
		if _validate_balance(candidate): balance = candidate
	if _rules != null and _rules.has_method("refresh_balance"): _rules.refresh_balance()
	changed.emit()
	return true


func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))


func _integer(value: Variant, minimum: int = 0) -> bool:
	return _number(value) and float(value) >= minimum and floorf(float(value)) == float(value)


func _valid_save(payload: Variant) -> bool:
	if not payload is Dictionary: return false
	if not _integer(payload.get("version", -1), 1) or not int(payload.version) in [1, 2, 3, 4, SAVE_VERSION]: return false
	for key in ["state", "customers", "employees", "logs", "scheduler", "paused", "speed", "fraction", "next_customer_id", "next_spawn_minute", "rng_state", "rng_seed", "initial_seed"]:
		if not payload.has(key): return false
	if not payload.state is Dictionary or not payload.customers is Array or not payload.employees is Array or not payload.scheduler is Array or not payload.logs is Array or not payload.paused is bool: return false
	if not _integer(payload.speed, 1) or int(payload.speed) > 4 or not _number(payload.fraction) or float(payload.fraction) < 0 or float(payload.fraction) >= 1: return false
	if not _integer(payload.next_customer_id, 1) or not _integer(payload.next_spawn_minute): return false
	for key in ["rng_state", "rng_seed", "initial_seed"]:
		if not payload[key] is String or not str(payload[key]).is_valid_int(): return false
	var saved: Dictionary = payload.state
	for key in ["total_minutes", "gems", "reputation", "seats", "stage", "served", "lost", "promotion_until", "overdue_count"]:
		if not saved.has(key) or not _integer(saved[key]): return false
	if int(saved.seats) < 1 or int(saved.seats) > 512 or int(saved.stage) > 4: return false
	for key in ["cash", "debt", "ingredients", "freshness", "comfort", "daily_revenue", "total_revenue", "interest_arrears", "daily_consumption"]:
		if not saved.has(key) or not _number(saved[key]): return false
		if float(saved[key]) < 0 and not (key == "cash" and str(saved.get("mode", "")) == "full" and bool(saved.get("finance", {}).get("rescue", {}).get("pending", false))): return false
	if float(saved.freshness) > 100 or float(saved.comfort) > 100 or not saved.get("last_report") is Dictionary or not saved.get("consumption_history") is Array: return false
	if not saved.last_report.is_empty():
		for key in ["revenue", "interest", "repayment", "wages", "wages_due", "rent_utilities", "procurement"]:
			if not _number(saved.last_report.get(key)) or float(saved.last_report[key]) < 0: return false
		if not _integer(saved.last_report.get("day"), 1) or not _integer(saved.last_report.get("procured_units")) or not saved.last_report.get("overdue") is bool: return false
	for consumed in saved.consumption_history:
		if not _number(consumed) or float(consumed) < 0: return false
	var employee_ids: Dictionary = {}
	for employee in payload.employees:
		if not employee is Dictionary: return false
		for key in ["id", "name", "role", "rarity", "stamina", "mood", "loyalty", "resting", "training_until", "busy_until", "busy_customer", "fatigue_notified", "training_experience", "attributes"]:
			if not employee.has(key): return false
		if not employee.id is String or employee_ids.has(employee.id) or _employee_config(str(employee.id)).is_empty() or not employee.name is String: return false
		employee_ids[employee.id] = employee
		if not str(employee.role) in ["waiter", "chef", "salesman", "all", "tutor"] or not str(employee.rarity) in ["N", "R", "SR", "SSR"]: return false
		for key in ["stamina", "mood", "loyalty"]:
			if not _number(employee[key]) or float(employee[key]) < 0 or float(employee[key]) > 100: return false
		for key in ["training_until", "busy_until", "busy_customer", "training_experience"]:
			if not _integer(employee[key]): return false
		if not employee.resting is bool or not employee.fatigue_notified is bool or not employee.attributes is Dictionary: return false
		if employee.has("motion") and not _valid_motion(employee.motion): return false
		if employee.has("branch_recovering") and not employee.branch_recovering is bool: return false
		for attr in employee.attributes:
			if not _number(employee.attributes[attr]) or float(employee.attributes[attr]) < 0: return false
	var ids: Dictionary = {}
	var seats: Dictionary = {}
	for customer in payload.customers:
		if not customer is Dictionary: return false
		for key in ["id", "seat", "stage", "dish_id", "type", "due_minute", "arrival_minute", "price", "worker", "ingredients_reserved", "remaining_minutes", "paid"]:
			if not customer.has(key): return false
		if not _integer(customer.id, 1) or ids.has(int(customer.id)) or int(customer.id) >= int(payload.next_customer_id): return false
		ids[int(customer.id)] = customer
		if not _integer(customer.seat) or int(customer.seat) >= int(saved.seats) or seats.has(int(customer.seat)): return false
		seats[int(customer.seat)] = true
		if not str(customer.stage) in ["ordering", "recommending", "queued", "cooking", "serving", "eating", "paying", "cleaning"] or _dish(str(customer.dish_id)).is_empty(): return false
		if not str(customer.type) in ["human", "monster", "descendant", "special"]: return false
		if not _integer(customer.due_minute, -1) or not _integer(customer.arrival_minute) or int(customer.arrival_minute) > int(saved.total_minutes) or not _integer(customer.remaining_minutes): return false
		if not _number(customer.price) or float(customer.price) < 0 or not customer.worker is String or not customer.paid is bool or not customer.ingredients_reserved is bool: return false
		if customer.has("task_motion") and not _valid_motion(customer.task_motion): return false
		for field in ["arrival_motion","checkout_motion"]:
			if customer.has(field) and not _valid_motion(customer[field]):return false
		if customer.has("arrival_due") and not _integer(customer.arrival_due):return false
		if customer.has("preference_profile") and not full_rules.preferences.validate_profile(customer.preference_profile): return false
		if customer.has("group_id"):
			if not _integer(customer.group_id,1) or not _integer(customer.get("group_size"),2) or int(customer.group_size)>512 or not customer.get("group_parallel") is bool: return false
		if customer.has("quality") and ( not _number(customer.quality) or float(customer.quality) < 0 or float(customer.quality) > 100): return false
		if customer.has("task_started_minute") and ( not _integer(customer.task_started_minute) or int(customer.task_started_minute) > int(saved.total_minutes)): return false
		if customer.has("tip_bonus") and ( not _number(customer.tip_bonus) or float(customer.tip_bonus) < 0 or float(customer.tip_bonus) > 1): return false
		if str(customer.worker) != "" and not employee_ids.has(customer.worker): return false
		if str(customer.stage) == "eating" and str(customer.worker) != "": return false
		if bool(customer.paid) != (str(customer.stage) == "cleaning"): return false
		if bool(customer.ingredients_reserved) != (str(customer.stage) in ["cooking", "serving", "eating", "paying", "cleaning"]): return false
		if int(customer.due_minute) < 0 and str(customer.worker) != "": return false
	for event in payload.scheduler:
		if not event is Dictionary or not event.has("type") or not _integer(event.get("due")) or int(event.due) < int(saved.total_minutes): return false
		if str(event.type) == "customer_step":
			if not _integer(event.get("customer_id"), 1) or not ids.has(int(event.customer_id)): return false
			var customer: Dictionary = ids[int(event.customer_id)]
			if str(event.get("stage", "")) != str(customer.stage) or int(event.due) != int(customer.due_minute) or str(event.get("employee_id", "")) != str(customer.worker): return false
		elif str(event.type) == "training_finish":
			if not employee_ids.has(str(event.get("employee_id", ""))): return false
			if int(employee_ids[str(event.employee_id)].training_until) != int(event.due): return false
		elif str(event.type) == "research_finish":
			if int(payload.version) < 2 or not event.get("dish_id") is String or not employee_ids.has(str(event.get("employee_id", ""))): return false
		else: return false
	for customer in payload.customers:
		if int(customer.due_minute) >= 0:
			var count: = 0
			for event in payload.scheduler:
				if str(event.type) == "customer_step" and int(event.customer_id) == int(customer.id): count += 1
			if count != 1: return false
	for employee in payload.employees:
		if int(employee.busy_customer) != 0:
			if not ids.has(int(employee.busy_customer)): return false
			var customer: Dictionary = ids[int(employee.busy_customer)]
			if str(customer.worker) != str(employee.id) or int(employee.busy_until) != int(customer.due_minute) or bool(employee.resting) or int(employee.training_until) > int(saved.total_minutes): return false
		elif int(employee.busy_until) != 0 and not (str(saved.get("mode", "")) == "full" and int(employee.get("expansion_until", 0)) > int(saved.total_minutes)): return false
		if int(employee.training_until) > 0:
			if not employee.get("training_attribute") in ["speed", "cooking"] or int(employee.training_until) <= int(saved.total_minutes): return false
			var count: = 0
			for event in payload.scheduler:
				if str(event.type) == "training_finish" and str(event.employee_id) == str(employee.id): count += 1
			if count != 1: return false
	for customer in payload.customers:
		if str(customer.worker) != "":
			var employee: Dictionary = employee_ids[str(customer.worker)]
			var shared_batch: bool = bool(customer.get("group_parallel",false)) and str(customer.stage) == "cooking"
			if int(employee.busy_customer) != int(customer.id) and not (str(saved.get("mode", "")) == "full" and str(customer.stage) == "cooking" and (str(employee.id) == "jiu_ying" or shared_batch)): return false
	for entry in payload.logs:
		if not entry is String: return false
	if str(saved.get("mode",""))=="full" and (not full_rules.visitors.validate(saved,payload.customers) or not full_rules.dollhouse.validate(saved,payload.employees,payload.customers) or not full_rules.culture_experience.validate_customers(saved,payload.customers)): return false
	if int(payload.version) >= 2 and not _rules.validate_state(saved, payload.employees, payload.scheduler): return false
	return true


func _normalize_demo_state() -> void :
	for dictionary in [state.hire_counts, state.fragments, state.research_experience, state.stats]:
		for key in dictionary: dictionary[key] = int(dictionary[key])
	for item in state.layout:
		for key in ["x", "y", "w", "h"]: item[key] = int(item[key])
	for project in state.research_projects: project.due = int(project.due)
	for queued in state.event_queue: queued.queued_minute = int(queued.queued_minute)
	for history in state.event_history:
		history.minute = int(history.minute)
		history.option = int(history.option)


func start_demo() -> void :
	_rules.start_demo()


func recruit(kind: String = "normal") -> Dictionary:
	return _rules.recruit(kind)


func quest_status() -> Array[Dictionary]:
	return _rules.quest_status()


func claim_quest(id: String) -> bool:
	return _rules.claim_quest(id)


func research_dish(id: String) -> bool:
	if _full(): return bool(full_rules.perform("research", {"dish_id":id}).get("ok",false))
	return _rules.research_dish(id)


func set_menu_enabled(id: String, enabled: bool) -> bool:
	if _full(): return bool(full_rules.perform("set_menu", {"dish_id":id,"enabled":enabled}).get("ok",false))
	return _rules.set_menu_enabled(id, enabled)


func active_bonds() -> Array[Dictionary]:
	return _rules.active_bonds()


func skills_enabled(id: String) -> bool:
	return _rules.skills_enabled(id)


func can_place_decoration(id: String, x: int, y: int) -> bool:
	return _rules.can_place_decoration(id, x, y)


func buy_decoration(id: String, x: int, y: int) -> bool:
	return _rules.buy_decoration(id, x, y)


func upgrade_restaurant() -> bool:
	return _rules.upgrade_restaurant()


func pending_event() -> Dictionary:
	return _rules.pending_event()


func choose_event(id: String, option_index: int) -> bool:
	return _rules.choose_event(id, option_index)


func advance_to_next_period() -> void :
	var current: = period()
	var previous: = int(state.total_minutes)
	_tick_minute()
	# A sealed main eatery does not suspend the shared clock or skip a week.
	# Mandatory notices, bills and rescue prompts may stop a tick; let the UI
	# handle them instead of spinning while time can no longer move.
	while int(state.total_minutes) > previous and (period() == current or not business_hours_open()):
		previous = int(state.total_minutes)
		_tick_minute()
	changed.emit()


func _employee_config(id: String) -> Dictionary:
	for entry in catalog:
		if str(entry.id) == id: return entry
	return {}


func _full() -> bool:
	return full_rules != null and full_rules.is_full()

func start_full() -> void:
	full_rules.start_full()


func apply_balance_override(key: String, value: float) -> bool:
	if not bool(state.get("developer_mode", false)) or not balance.has(key) or not is_finite(value): return false
	var candidate = balance.duplicate(true)
	var edits: Dictionary = BalanceRegistry.normalize_overrides({key:value})
	candidate.merge(edits, true)
	if not _validate_balance(candidate): return false
	balance = candidate
	if _rules != null and _rules.has_method("refresh_balance"): _rules.refresh_balance()
	if not state.get("balance_overrides", {}) is Dictionary: state.balance_overrides = {}
	if not state.has("balance_overrides"): state.balance_overrides = {}
	state.balance_overrides.merge(edits, true)
	changed.emit()
	return true
