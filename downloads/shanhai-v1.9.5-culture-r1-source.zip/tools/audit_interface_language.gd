extends SceneTree
const Harness=preload("res://tests/culture_ui_tests.gd").Harness
func _init():call_deferred("run")
func audit_text(value,localization):
	if value is Dictionary:
		for key in value:
			if key=="notes" or str(key).ends_with("_en"):continue
			audit_text(value[key],localization)
	elif value is Array:
		for item in value:audit_text(item,localization)
	elif value is String:localization.translate(value)
func run():
	var ui=Harness.new();root.add_child(ui);await process_frame
	ui.story_panel=ui.StoryPanel.new(ui)
	ui.revision_ui=ui.Revision171Panels.new(ui)
	ui.setup_audio()
	ui.localization=preload("res://scripts/services/localization.gd").new("user://locale-audit-only.cfg")
	ui.localization.language="en"
	ui.model.state.stage=4;ui.model.state.cash=100000.0;ui.model.state.reputation=20000
	var panels=["欢迎","员工","图鉴","菜单","装修","山海驿路","角色特征","菜牌说明","山海来信","系统","声音设置","经营状态","日结账单","分店管理","中央厨房","山海探索","神兽觉醒","厨神大赛","会员计划","会员外卖","菜单定价","资金流水","贷款","采购设置","顾客反馈","员工支线","相生相克","世界排行榜","宣传营销","库存供应","员工培养","招聘"]
	for entry in ui.Policy.more_entries(4):
		if not str(entry.panel) in panels:panels.append(str(entry.panel))
	var opened=[]
	for scenario in ["late_initial", "late_all_content", "late_no_cash", "opening"]:
		if scenario=="late_all_content":
			ui.model.employees.clear()
			for e in ui.model.catalog:ui.model.employees.append(ui.model._create_employee(e))
			ui.model.state.unlocked_dishes=ui.model.dishes.map(func(d):return str(d.id))
			ui.model.state.menu_enabled=ui.model.state.unlocked_dishes.duplicate()
			ui.model.full_rules.ensure_state_defaults()
		if scenario=="late_no_cash":ui.model.state.cash=0.0
		if scenario=="opening":ui.model.start_full()
		ui.tutorial_overlay.poll(0);ui.revision_ui.poll(0)
		for name in panels:
			if ui.decoration_active():
				ui.decoration_session.finish(false);ui.close_panel(false)
			ui.open_panel(name);await process_frame
			ui.localization.apply_tree(ui)
			opened.append({"scenario":scenario,"requested":name,"actual":ui.panel_name,"children":ui.modal_body.get_child_count()})
	# Use real day settlement to cover the compulsory report and populated accounts.
	ui.model.state.tutorial.finished=true
	ui.model.state.tutorial.completed_steps=ui.Guide.config().steps.map(func(step):return str(step.id))
	ui.model.state.tutorial.active_id=""
	ui.model.state.tutorial.ready_to_ack=[]
	ui.model.skip_to_next_morning()
	ui.open_panel("今日收支结算");await process_frame;ui.localization.apply_tree(ui)
	opened.append({"scenario":"real_settlement","requested":"今日收支结算","actual":ui.panel_name,"children":ui.modal_body.get_child_count()})
	assert(ui.model.full_rules.perform("daily_ack").ok,"The actual daily report can be acknowledged")
	ui.revision_ui.report_open=false
	var encounter=ui.model.full_rules.culture_experience
	if encounter.event("menu").status=="offered":
		for choice in ["accept","verify","refund"]:assert(encounter.perform("culture_choose",{"id":"menu","choice":choice}).ok)
	for name in ["账单","资金流水","顾客反馈"]:
		ui.open_panel(name);await process_frame;ui.localization.apply_tree(ui)
		assert(ui.panel_name==name,"Ledger audit must open the requested page")
		opened.append({"scenario":"real_settlement","requested":name,"actual":ui.panel_name,"children":ui.modal_body.get_child_count()})
	for config in [ui.Guide.config(),ui.model.full_rules.story.config,ui.model.full_rules.sidequests.config]:audit_text(config,ui.localization)
	var out=FileAccess.open("res://build/culture-r1-untranslated-ui.json",FileAccess.WRITE)
	out.store_string(JSON.stringify(ui.localization.untranslated,"\t"));out.close()
	FileAccess.open("res://build/culture-r1-language-panels.json",FileAccess.WRITE).store_string(JSON.stringify(opened,"\t"))
	print("Panel states audited: ",opened.size(),"; incomplete translations: ",ui.localization.untranslated.size())
	ui.queue_free();await process_frame;quit()
