extends RefCounted
## Global presentation preference, independent from campaign state and simulation RNG.
var language: String="zh"
var path: String
var data: Dictionary={}
var cache: Dictionary={}
var patterns: Array=[]
var untranslated: Dictionary={}
var chinese=RegEx.new()
func _init(preferences: String="user://interface_language.cfg") -> void:
	path=preferences
	var parsed=JSON.parse_string(FileAccess.get_file_as_string("res://config/localization.json"))
	if parsed is Dictionary: data=parsed
	chinese.compile("[\\x{3400}-\\x{9fff}]")
	var file=ConfigFile.new()
	if file.load(path)==OK: language=str(file.get_value("interface","language","zh"))
	else:
		var old=ConfigFile.new()
		if old.load("user://culture_preferences.cfg")==OK: language=str(old.get_value("reading","language","zh"))
	if not language in ["zh","en"]: language="zh"
	for item in data.get("patterns",[]):
		var regex=RegEx.new()
		if regex.compile(str(item.regex))==OK: patterns.append({"regex":regex,"en":str(item.en)})
func set_language(code: String) -> bool:
	if not code in ["zh","en"]: return false
	language=code
	var file=ConfigFile.new();file.set_value("interface","language",code)
	return file.save(path)==OK
func field(value: Variant) -> String:
	if value is Dictionary: return str(value.get(language,value.get("zh","")))
	return translate(str(value))
func translate(source: String) -> String:
	if language!="en" or source.is_empty() or source=="中文": return source
	if cache.has(source): return str(cache[source])
	if cache.size()>20000:cache.clear()
	var exact: Dictionary=data.get("strings",{})
	var translated=source
	if exact.has(source): translated=str(exact[source])
	else:
		for item in patterns:
			var found=item.regex.search(source)
			if found!=null:
				translated=item.en
				for i in range(found.get_group_count(),0,-1): translated=translated.replace("{"+str(i)+"}",translate(found.get_string(i)))
				break
		if translated==source and source.contains("\n"):
			var lines: Array[String]=[]
			for line in source.split("\n"): lines.append(translate(line))
			translated="\n".join(lines)
		if translated==source:
			for prefix in ["• ","● ","✓ ","◇ "]:
				if source.begins_with(prefix):translated=prefix+translate(source.trim_prefix(prefix));break
		if translated==source:
			for separator in [" · "," / ","：","、"]:
				if source.contains(separator):
					var pieces: Array[String]=[]
					# Preserve complete sentences after a speaker/label prefix. Splitting
					# every colon at once would break a later speaker inside that sentence.
					for piece in source.split(separator,true,1):pieces.append(translate(piece))
					translated=(": " if separator=="：" else ", " if separator=="、" else separator).join(pieces)
					if translated!=source:break
		if translated==source:
			for key in data.get("terms_order",[]): translated=translated.replace(str(key),str(data.terms[key]))
			translated=translated.replace("、",", ")
	if chinese.search(translated)!=null: untranslated[source]=translated
	cache[source]=translated
	return translated
func apply_tree(node: Node) -> void:
	if node.is_queued_for_deletion() or bool(node.get_meta("culture_body_text",false)): return
	if node is Label or node is RichTextLabel or node is Button:
		var current=str(node.text)
		if current!=str(node.get_meta("l10n_last",current)) or not node.has_meta("l10n_source"): node.set_meta("l10n_source",current)
		var translated=translate(str(node.get_meta("l10n_source",current)))
		if current!=translated: node.text=translated
		node.set_meta("l10n_last",translated)
	if node is Control and not node.tooltip_text.is_empty():
		var current=str(node.tooltip_text)
		if current!=str(node.get_meta("l10n_tooltip_last",current)) or not node.has_meta("l10n_tooltip_source"): node.set_meta("l10n_tooltip_source",current)
		node.tooltip_text=translate(str(node.get_meta("l10n_tooltip_source",current)))
		node.set_meta("l10n_tooltip_last",node.tooltip_text)
	if node is OptionButton:
		for i in range(node.item_count):
			var current=node.get_item_text(i);var key="l10n_option_"+str(i)
			if not node.has_meta(key): node.set_meta(key,current)
			node.set_item_text(i,translate(str(node.get_meta(key))))
	if node is AcceptDialog:
		if str(node.dialog_text)!=str(node.get_meta("l10n_dialog_last",node.dialog_text)) or not node.has_meta("l10n_dialog_source"): node.set_meta("l10n_dialog_source",node.dialog_text)
		node.dialog_text=translate(str(node.get_meta("l10n_dialog_source")))
		node.set_meta("l10n_dialog_last",node.dialog_text)
	for child in node.get_children(): apply_tree(child)
