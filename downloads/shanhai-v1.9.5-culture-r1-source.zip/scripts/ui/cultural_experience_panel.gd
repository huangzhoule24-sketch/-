extends RefCounted
## Production UI: actions submit to the model; a story page cannot complete an order.
var host
var model
var selected_staff="xian_yang"
var selected_dish="noodles"
const GREEN=Color("427b6c")
const MUTED=Color("718078")
const WARM=Color("9a673d")
func _init(ui): host=ui;model=ui.model
func rules(): return model.full_rules.culture_experience
func t(zh: String,en: String) -> String: return en if host.localization!=null and host.localization.language=="en" else zh
func field(value: Variant) -> String:
	if value is Dictionary:return str(value.get("en" if host.localization!=null and host.localization.language=="en" else "zh",""))
	return str(value)
func body(title: String,detail: String=""): return host.full_panels._body(title,detail)
func text(parent,value: String,color: Color=MUTED): host.full_panels._text(parent,value,color,16)
func link(parent,label: String,panel: String,id: String): parent.add_child(host.button(label,func():
		if panel.is_empty():host.close_panel()
		else:host.open_panel(panel),false,id))
func action(parent,label: String,kind: String,args: Dictionary,id: String):
	var check=rules().can(kind,args)
	var control=host.button(label,func():
		var result=model.full_rules.perform(kind,args)
		if not bool(result.get("ok",false)):
			host.show_requirement(str(result.get("reason_en",result.get("reason",""))) if host.localization!=null and host.localization.language=="en" else str(result.get("reason","")))
		else:host.open_panel(host.panel_name,false),false,id)
	control.disabled=not bool(check.get("ok",false))
	control.tooltip_text=str(check.get("reason_en",check.get("reason",""))) if host.localization!=null and host.localization.language=="en" else str(check.get("reason",""))
	parent.add_child(control)
	if control.disabled:text(parent,control.tooltip_text,WARM)
func render(name: String) -> bool:
	if not name in ["山海驿路","山海来信","菜牌说明","角色特征"]:return false
	rules().ensure_state()
	var tabs=host.full_panels._flow(host.modal_body)
	for item in [["山海驿路","The Shanhai Road"],["角色特征","Companions"],["菜牌说明","Menu Notes"],["山海来信","Letters"]]:
		link(tabs,t(item[0],item[1]),item[0],"culture:tab:"+str(item[1]))
	match name:
		"山海驿路":road()
		"角色特征":companions()
		"菜牌说明":menus()
		"山海来信":letters()
	return true
func road():
	text(host.modal_body,t("山川带来食材，伙伴带来本领，旅人留下下一次再见。先经营，再循着好奇去读一页古书。","Mountains bring ingredients, companions bring their gifts, and travellers leave a reason to meet again. Run the inn first; follow your curiosity into an old book when you wish."))
	for id in ["menu","bifang","harvest"]:encounter(id)
	var s=rules().snapshot()
	for region in rules().config.regions:
		var complete=str(region.id) in s.route_completed
		var current=rules().count(str(region.metric))
		var b=body(("✓ " if complete else "◇ ")+field(region.title),field(region.action))
		text(b,"%d / %d"%[mini(current,int(region.target)),int(region.target)],GREEN if complete else MUTED)
		if not region.requires.all(func(id):return id in s.route_completed):text(b,t("前一站的来信尚未抵达；这些见闻不会锁住原有经营进程。","A previous stop’s reply has not arrived. These encounters do not block the original business campaign."))
		b.add_child(host.button(t("读读这位伙伴的来处","Read this companion’s origins"),func():host.open_culture("employees",str(region.employee)),false,"culture:route:reading:"+str(region.id)))
	text(host.modal_body,t("此驿路是小馆选编的主题行程，山名来自典籍，访问顺序不是原书的地理路线。","This itinerary is the inn’s themed selection. The mountain names come from the old books; this visiting order is not their prescribed geography."))
	var b=body(t("一席饭怎样端齐","Bringing one meal to the table"),t("九婴的多炉本领仍需要真实炉灶；选择只改变同桌出餐方式。","Jiuying’s gift still needs real stoves. Choose how a shared table’s dishes finish."))
	for mode in [["legacy","原有出餐方案","Existing service plan"],["individual","各份完成即出餐","Serve each dish when ready"],["same_table","九婴 · 同席协调","Jiuying · coordinated table service"]]:
		action(b,("✓ " if str(s.batch_mode)==str(mode[0]) else "")+t(mode[1],mode[2]),"culture_batch_mode",{"mode":mode[0]},"culture:batch:"+str(mode[0]))
	var n: Dictionary=s.night
	b=body(t("烛龙 · 把夜色留给这一席","Zhulong · a little night for this table"),t("先上架烛龙拉面并备料、排班。每日神通仍只一次，借用夜市客流不改变真实时钟，也不绕过打烊。开席后在240游戏分钟内完成3笔由烛龙掌厨的拉面付款。","Enable Zhulong noodles, prepare ingredients and staff the inn. The skill remains once daily: borrowing night-market arrivals changes neither the clock nor closing. Complete 3 paid noodle orders cooked by Zhulong within 240 game minutes."))
	if bool(n.get("active",false)):text(b,t("已付款进度：","Paid orders: ")+"%d / 3"%int(n.progress),GREEN)
	else:action(b,t("约定夜席并使用今日神通","Plan the meal and use today’s skill"),"culture_night_meal",{},"culture:night:start")
	action(host.modal_body,t("减弱场景光效" if not s.reduce_fx else "恢复场景光效","Reduce scene lighting" if not s.reduce_fx else "Restore scene lighting"),"culture_reduce_fx",{"enabled":not s.reduce_fx},"culture:lighting")
	if int(model.state.stage)>=3:
		var branches=model.full_rules.expansion.snapshot().branches
		for id in branches:
			if not bool(branches[id].open):continue
			b=body(t("分店主题 · ","Branch theme · ")+str(branches[id].get("definition",{}).get("name",id)),t("主题只从已有成品库存里选择已解锁菜；没有可用主题菜时保留常规服务。中央厨房的实际生产与调拨不变。","A theme selects unlocked dishes from actual prepared stock. If no themed dish is available, regular service continues. Central-kitchen production and shipping remain real."))
			action(b,t("常规菜单","Regular menu"),"culture_branch_theme",{"branch_id":id,"theme":""},"culture:branch:"+str(id)+":regular")
			for region in rules().config.regions:action(b,field(region.title),"culture_branch_theme",{"branch_id":id,"theme":region.id},"culture:branch:"+str(id)+":"+str(region.id))
	link(host.modal_body,t("回到营业，等待真实服务","Return to service and observe the meal"),"","culture:resume")
func encounter(id: String):
	var e=rules().event(id);var status=str(e.status)
	var title=t({"menu":"名字之外，碗里是什么","bifang":"一足立在火边","harvest":"听见丰年之后"}[id],{"menu":"Beyond the name, what is in the bowl?","bifang":"One foot beside the fire","harvest":"After the harvest call"}[id])
	var b=body(title)
	if status=="unseen":
		text(b,t({"menu":"先完成开局引导与一笔真实服务，再听旅人的提问。","bifang":"阶段1后，让已招募的毕方当班、研发烤翅并装好炉灶，就能筹备这一席。","harvest":"当康当班的丰收折扣日会有来信，周期沿用当前采购规则。"}[id],{"menu":"Finish the opening guidance and a real service, then hear the traveller’s question.","bifang":"From stage 1, recruit and staff Bifang, research the wings and install a stove to plan the meal.","harvest":"A letter arrives on Dangkang’s on-duty harvest-discount day, using the current purchasing period."}[id]));return
	if status=="resolved":text(b,t("这一段相遇已写成来信，去信匣里再读。","This encounter has become a letter. Find it in the letter box."),GREEN);return
	if status=="followup":
		if id=="menu" and rules().s().booking.get("status","")=="refunded":
			text(b,t("本次预约已退款。若未能及时完成用餐，请先检查等候队列、备料与服务排班。次日可收到Lin的回信。","This booking has been refunded. If service could not finish in time, check the queue, ingredients and service staffing. Lin’s reply arrives after a day."),WARM)
		else:text(b,t("约定已完成。等到次日，旅人会把经历写回来。","The agreement is complete. After a day, the traveller will write back."),GREEN)
		return
	if status=="deferred":text(b,t("已约好晚些再谈。先照顾眼前的营业。","You agreed to talk later. Attend to service for now."));return
	if status=="waiting":
		if id=="bifang":text(b,t("用真实订单完成这席烤翅：","Complete this wing meal with real paid orders: ")+"%d / %d"%[int(e.progress),int(e.target)],GREEN)
		elif id=="menu":
			text(b,t("预约已安排。营业、有座位且酸梅汤备料充足时，Lin会进店；实际付款后才完成约定。","The booking is arranged. Lin will enter when service is open, a seat is free and the plum drink has ingredients. The agreement completes only after actual payment."))
			action(b,t("未开做的预约退款","Refund an unstarted booking"),"culture_cancel_booking",{},"culture:booking:cancel")
		return
	var node=str(e.node)
	if id=="bifang":
		text(b,t("毕方盯着炉口：‘别只把这一席写成看火的奇观。我想让他们记住味道。’你翻开排班：‘先约好几桌、几轮。’两种安排都需要真实备料、掌厨和付款。","Bifang watches the grill. ‘Please do not advertise only a spectacle of fire. I want them to remember the food.’ You check the roster. ‘Let us agree how many tables, how many rounds.’ Either plan needs real ingredients, cooking and payments."))
	elif id=="menu":
		if node=="start":text(b,t("旅行食谱收藏者Lin问：‘无面饺子，是说没有面粉吗？我想为下一次用餐预付20，但需要先知道碗里究竟是什么。’你把Lin带来的菜牌与订单簿放到一起。","Lin, a collector of travel recipes, asks: ‘Does Faceless Dumplings mean there is no flour? I would like to prepay 20 for my next visit, but first I need to know what is in the bowl.’ You put Lin’s menu beside the order book."))
		elif node=="check":text(b,t("Lin：‘我按自己的饮食计划避开小麦，不是严重过敏。请告诉我确切用料。’先听需求，再核对面皮与可提供的饮品。预收款尚未成为营业收入。","Lin says, ‘I avoid wheat as part of my own eating plan, not because of a severe allergy. Please tell me the ingredients.’ Listen first, then check the wrappers and available drink. The prepayment is not revenue yet."))
		else:text(b,t("无面饺子有面皮，名字来自帝江无面目的形貌。Lin愿意在了解酸梅汤的用料后自己确认换单；若无法满足需求，也可以退回预收款。复合用料与交叉接触尚未逐项核实，不作过敏安全承诺。","The dumplings have wrappers; their name refers to Dijiang’s lack of a distinct face. Lin can agree to the plum drink after hearing its ingredients, or receive a refund if the inn cannot meet the request. Composite ingredients and cross-contact have not been fully verified; no allergy-safe promise is made."))
	elif id=="harvest":
		text(b,t({"start":"当康的叫声把折扣粮商引到门前。可以用80买粮入库，也可以保留周转现金。丰收不会替你决定预算。","bought":"粮已入库。街坊问能否匀一点给共同的晚饭：赠出账面成本12的食材，或留作明日备料。买粮和赠粮是两笔不同的业务。","held":"当康看过明日预算，没有把谨慎叫成吝啬。你可以分享一条已核实的余粮消息，或约定下次再问。"}[node],{"start":"Dangkang’s call brings a grain trader to the door. Buy stock for 80 or keep working cash. A harvest does not decide your budget.","bought":"The grain is stored. A neighbour asks about a shared supper: give ingredients costing 12, or reserve them for tomorrow. Buying and giving are separate transactions.","held":"Dangkang reads tomorrow’s budget without calling caution stinginess. Share a checked lead on surplus grain, or agree to ask another day."}[node]))
	var labels={"small":["分两轮办小席 · 完成3份烤翅付款","A smaller meal in two rounds · 3 paid wing orders"],"training":["协作培训30，耗时60分钟 · 再完成5份","Team training: 30 and 60 minutes · then 5 paid orders"],"accept":["记录预约与预收20，先听清需求","Record the booking and 20 prepayment; listen first"],"verify":["询问需求，核对旧菜牌、面皮与用料","Ask, then check the old menu, wrapper and ingredients"],"switch":["经Lin确认改为酸梅汤，等待真实到店服务","With Lin’s agreement, serve a plum drink on the real visit"],"refund":["取消未履行预约，退回预收款","Cancel the unfulfilled booking and refund its prepayment"],"buy":["用80采购普通食材，先记存货","Purchase 80 of ordinary ingredients into inventory"],"hold":["暂留现金，不买这批粮","Keep the cash; pass on this batch"],"gift":["赠出成本12的真实食材","Share actual ingredients costing 12"],"reserve":["留作明日备料","Keep the stock for tomorrow"],"contact":["分享余粮联络消息","Share the surplus-grain contact"],"revisit":["约好下次再问","Agree to check another day"]}
	for choice in rules().choices(id,node):
		var words=labels[choice]
		action(b,t(words[0],words[1]),"culture_choose",{"id":id,"choice":choice},"culture:choose:"+id+":"+choice)
	action(b,t("稍后再谈","Talk later"),"culture_defer",{"id":id},"culture:defer:"+id)

func companions():
	var choices=host.full_panels._flow(host.modal_body)
	for item in rules().config.cast:
		var id=str(item.id)
		choices.add_child(host.button(str(item.name),func():selected_staff=id;host.open_panel("角色特征",false),id==selected_staff,"culture:companion:"+id))
	var e=rules().definition("cast",selected_staff)
	var b=body(str(e.name),t("先认出它，再看看为什么它会这样工作。","First notice the companion, then discover why they work this way."))
	var image=TextureRect.new();image.custom_minimum_size=Vector2(128,176);image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image.texture=host.assets.get_texture(str(e.portrait).trim_suffix(".png"));b.add_child(image)
	text(b,field(e.anchor));text(b,field(e.wish),GREEN);text(b,field(e.decision))
	text(b,t("尚未招募也可认识来处；阅读不会赠送员工或解锁神通。","You can read before recruitment. Reading does not grant staff or unlock a skill."))
	b.add_child(host.button(t("读完整小传与典籍","Read the full story and old texts"),func():host.open_culture("employees",selected_staff),false,"culture:companion:reading"))

func menus():
	var options=host.full_panels._flow(host.modal_body)
	for menu in rules().config.menus:
		var id=str(menu.id)
		options.add_child(host.button(str(menu.name),func():selected_dish=id;host.open_panel("菜牌说明",false),id==selected_dish,"culture:menu:"+id))
	var menu=rules().definition("menus",selected_dish)
	var b=body(str(menu.name),field(menu.ingredients))
	text(b,field(menu.flavour));text(b,field(menu.unknown_components),WARM)
	var dish=model._dish(selected_dish)
	if not dish.is_empty():text(b,t("当前基础售价：","Current base price: ")+"%.2f"%float(dish.price),GREEN)
	text(b,field(menu.encounter))
	b.add_child(host.button(t("读这道菜的故事","Read the dish’s story"),func():host.open_culture("dishes",selected_dish),false,"culture:menu:reading"))
	action(b,t("核对菜牌：名字、用料和未知项分开说明","Review the menu: separate names, ingredients and unknowns"),"culture_review_menu",{},"culture:menu:review")

func letters():
	var s=rules().snapshot()
	if s.letters.is_empty():text(host.modal_body,t("先把一份约定做完，再给旅人一点写信的时间。","Complete an agreement, then give the traveller time to write."))
	for letter in s.letters.duplicate().slice(0):
		var b=body(("" if bool(letter.read) else "● ")+field(letter.title),field(letter.body))
		if not bool(letter.read):action(b,t("收好这封信","Keep this letter"),"culture_read_letter",{"id":letter.id},"culture:letter:"+str(letter.id))
	var b=body(t("这几次相遇，账上怎样变化","What these encounters changed in the accounts"),t("下列为事件分录；完整营业收入与成本仍在原账单，只记一次。采购先变存货；预收款在履约前是负债。","These are event entries. Full operating revenue and costs remain in the original bill, recognized once. Purchases become inventory; prepayments are liabilities until service."))
	for tx in s.transactions:
		text(b,field(tx.description),GREEN)
		text(b,t("现金 %+.2f · 存货 %+.2f · 应收 %+.2f · 负债 %+.2f · 利润 %+.2f","Cash %+.2f · inventory %+.2f · receivable %+.2f · liability %+.2f · profit %+.2f")%[float(tx.cash),float(tx.inventory),float(tx.get("receivables",0)),float(tx.liabilities),float(tx.profit)])
	for evidence in s.evidence:text(b,field(evidence.text))
	for id in s.guest_memories:
		var memory=s.guest_memories[id]
		var d=rules().definition("guests",str(id))
		b=body(str(d.get("name",id)))
		text(b,t("已服务 %d 次 · 最近一次菜单：%s","Served %d times · latest dish: %s")%[int(memory.visits),str(model._dish(str(memory.last_dish)).get("name",memory.last_dish))])
