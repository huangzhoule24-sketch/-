> 历史审计：基线为2026-10-16开发包，保留当时发现的问题。后续修复状态以 `docs/full-reproduction-audit.md` 与 `docs/validation.md` 为准，不将此报告的未修条目直接当成当前状态。

# v1.3 动画 / 寻路 / 美术替换只读审计

审计日期：2026-10-16。已先读 `/workspace/-/AGENTS.md` 与 `docs/project-memory.md`。继续接受占位图标/程序绘图；不将未补正式美术、使用 Godot 而非 Unity、未 Windows 实机验收列为缺陷。没有修改游戏文件；以下探针和报告仅写入 `/tmp`。

## 已验证问题

### A1 / P1：模拟按到期时间完成工作，不等待实际到达和工作动画，受阻员工也能凭空上菜

- 需求原文：`docs/design-v1.3.txt:920–922`：“所有员工移动必须使用平滑移动”“工作动画必须与工作状态绑定，按时长播放，禁止瞬间完成”；`:952`：“到达目标后自动进入工作状态，工作动画播完才触发结果（如菜品完成、顾客收到菜）”。`:1094–1096` 又要求动画/移动影响真正的顾客等待时间。
- 代码证据：`scripts/core/game_model.gd:543–555` 仅按属性缩放基础工作时长，再对 ordering/serving/cleaning 加固定 `minimum_travel_minutes`，设置固定 `due_minute`；`:562–570` 仅比较时钟投递完成；`:577–595` 未检查位置、路线、可达性或动画进度即清除 worker，并令 serving→eating。`scripts/ui/restaurant_view.gd:541–542` 明示绘制仅为 observer；`:639–642` 路线受阻只把视觉 actor 改为 Idle/“通路受阻”，没有任何权威任务反馈。
- 实测：以真实 `GameModel.new(20261016); start_full()` 建立一张合法四人桌，把真实顾客设为第三座 serving 后调用原 `_assign_tasks()`。渲染器确认 blocked=true/action=Idle；推进视觉3分钟，员工原地不动。随后把模型时钟推进到它自己排定的 due 并执行原 `_tick_scheduler()`，顾客进入 eating，员工从未进入 Serve。
- 探针输出：`FOUR_TABLE seat=2 target=(185.0, 236.08) covered=true blocked=true action=Idle stage=serving due=364`；`AT_DEADLINE stage=eating visual_action=Idle position_unchanged=true served_without_Serve=true`。
- 影响：工作结果与动画脱节，家具阻挡只影响展示；厨房/收银等也没有权威 arrival→work→result 阶段。既有“到达后才播动作”单元测试并不能证明“动作完才出结果”。
- 建议：把可达性、实际行走时长和 arrival→work 生命周期放入与UI解耦的权威模拟，渲染读取其阶段；不能反向依赖某个视图 `_process()` 存在来推进经营。

### A2 / P1：四人桌第三座的上菜 / 清台目标落在桌子内部，员工永久“通路受阻”

- 需求原文：`docs/design-v1.3.txt:929` 移动方式要求寻路或平滑移动；`:950–952` 每帧前进、到达目标才工作。
- 代码证据：`config/decorations.json:71–83` 定义阶段1开放的1×1四人桌；`scripts/ui/restaurant_view.gd:130–135` 将其 chair==2 座放在桌中心上方 `min(cellHeight*0.3,38)`；`:580–585` 却给所有座位的服务/清台接近点统一加 `(0,34)`。`:669` 把桌中心周围一块矩形作为障碍。由此上座接近点走进桌面；`:603` 只对 Idle/Cook/Cashier/Promote 找附近空点，Serve/Clean不会修正目标。`scripts/services/grid_navigation.gd:35–36` 对被障碍覆盖的目标直接 blocked，`:639–642` 因而一直 Idle。
- 实测：真实 View 尺寸900×600、full模式8×5格、四人桌(1,1)；0/1/3座接近点 `point_is_clear=true`，第三座 target=(185,236.08)，`point_is_clear=false`。1.3默认桌面逻辑分辨率下同样存在这个几何关系：上座偏移-38加34仅为中心-4，仍在桌内。这是正常桌型与座位组合，不需要人工加入挡路障碍。
- 影响：每张四人桌的第三座在上菜/清台时员工无法就位；因A1仍能完成订单，玩家看到原地受阻而顾客凭空收到餐。
- 建议：按座位方向选取桌面外的服务接近点（左/右/上/下），并在合法布局/所有桌型所有座位上验证接近点可达。

### A3 / P2：为了赶任务截止时间强制超速，移动不再遵守统一属性公式

- 需求原文：`docs/design-v1.3.txt:945`、`:1084` 统一移动因子 `1+(速度−5)*0.08`，范围0.6~2.0；`:1101`：“移动速度使用 baseMoveSpeed * MoveSpeedFactor，其中 baseMoveSpeed 为统一常数”；`:1125` v1.3专门修复双系数以统一公式。
- 代码证据：`scripts/ui/restaurant_view.gd:622` 先计算正确基础移动速度；`:627–632` 随后使用 `maxf(speed, remaining/maxf(available,visual_delta*2))` 为赶 deadline 提速，直接覆盖属性决定的结果。距离和截止时刻因此成为未配置的新系数。
- 实测：同一真实 waiter 的 serving 到期前0.05游戏分钟、位置(800,500)、visual_delta=0.1，公式应最多移动19.7064px；实际一帧移动346.9846px，约17.6倍，仍标Move。虽然保留两帧没有直接赋目标，但已经大幅破坏行动快慢反馈。
- 建议：用实际路径和属性速度排任务完成时间，消除渲染层的截止追赶；长路应延长等待，不能让deadline反向改变速度。

## 覆盖验证与未发现问题项

- 环境：Godot `4.6.3.stable.official.7d41c59c4`，Linux headless；独立 XDG 路径位于 `/tmp`，未覆盖正常存档。
- 定向探针：`/tmp/shanhai-audit-animation-probe.gd`，执行 `godot --headless --path /workspace/- --script /tmp/shanhai-audit-animation-probe.gd` 可复现三项；探针使用真实模型和实际导航/视图代码，只有座位、阶段、模型时钟和当前视觉位置为受控输入。
- 原测试本轮执行结果：`tests/animation_tests.gd` 32 passed / 0 failed；`tests/navigation_tests.gd` 34 passed / 0 failed；`tests/asset_tests.gd` 51 checks / 0 failures。三组全过仍未覆盖上述问题：navigation测试覆盖了二人桌seat0与模拟blocked视觉，没覆盖四人桌上座，也没有同时推进真实任务结果。
- 美术服务已实际具备外置优先/内置回退（asset_catalog.gd:238–245）、PNG/JPG/JPEG、编号排序和单帧保留内置剩余帧（:108–144）、开发模式内容变化热载（:60–68、:292–306）、可执行文件同级CustomAssets（:37–42）、网页user路径及统一图片接口。本次在第18章范围未确认新的实质缺陷。
- `config/animation.json` 与 `restaurant_view.gd:517–531` 已正确使用v1.3移动0.08、厨艺0.06、魅力0.05、缺省属性0；高心情按表中明确公式最多+2%。策划第1088行文字“额外+5%”与同一行公式的+0~2%存在原文矛盾，不把代码按明确公式实现擅列为缺陷。

## 后续授权整改（以上为修复前快照）

root 在只读审计完成后明确授权整改，并分配本代理负责 `scripts/services/restaurant_space.gd`、`scripts/ui/restaurant_view.gd`、animation/navigation测试；GameModel由root负责。现已新增共享1020×560逻辑空间，桌/座/服务接近点与障碍几何由模拟和视图共用；四人桌按座位方向选桌外点。视图根据模型motion_position采样真实路程与工作阶段，删除deadline强制超速，缩放只影响绘制与输入映射，兼容未含motion的旧fixture。根代理同时为模型实现真实路程+工作时长与不可达不分配逻辑。

本代理最近执行：animation新增真实模型/渲染联动回归共42检查全部通过；navigation共40检查全部通过。验证了第三座可达、resize不改变模拟坐标、fraction位置一致、到位再工作、工作进度排除路程、完整工作到期才给餐、受阻不生成完成deadline。美术服务未改。root另需完成/确认新开局空闲员工motion初始化，避免首个任务时legacy空闲展示位置与模型入口origin不一致；该项已直接报告root。根和UI代理继续处理全套回归、QA网格和教程高亮的屏幕坐标适配。
