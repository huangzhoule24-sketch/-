> 历史审计：基线为2026-10-16开发包，保留当时发现的问题。后续修复状态以 `docs/full-reproduction-audit.md` 与 `docs/validation.md` 为准，不将此报告的未修条目直接当成当前状态。

# 26 员工神通与七属性独立审计

审计范围：`/workspace/-` 的 `docs/design-v1.3.txt` 4.2、4.3，并追踪相应 `game_model.gd`、`demo_rules.gd`、`full_rules.gd`、`effect_resolver.gd`、`world_events.gd`、`management_rules.gd` 和配置。已先读 AGENTS.md 与 docs/project-memory.md。仅在 `/tmp` 保存本报告和独立内存探针，未改游戏或文档。**以下为修复前读取到的代码证据；父代理已开始修复，最终报告需以合并后代码重新确认。**

## 确认的问题

### E1 / P2：帝江把所有菜的上菜工作时间也清零，混用了其招牌菜的特效

- 需求：设计 `:98`「无面：传菜时无视路径障碍，且顾客好感提升」。另 `:137` 的帝江无面饺子才是「传菜速度极快，无等待时间」。
- 实现：`scripts/core/management_rules.gd:622` 将帝江的员工效果定义为 `serve_mult: 0.0`；`:663` 乘入任何菜的服务倍率；`scripts/core/game_model.gd:546` 把整个服务任务时长乘零，`:555` 最后钳到最小调度单位1分钟。`effect_resolver.gd:90-91` 已独立处理帝江无视障碍，`:158` 已提高满意度，故这里的清零是额外行为。
- 可见结果：帝江送阳春面、凤凰羹等全部菜都成为1分钟服务，基础服务时间、速度属性和其他服务加速丧失作用。只去掉旅行时间已能实现员工条目。
- 独立探针实证：基础 `customer.serve_minutes=40`，帝江送 `noodles`，实际排程1分钟。
- 现有测试 `tests/skill_coverage_tests.gd:136-139` 断言所有菜都1分钟，测试在固化偏差，不能代替策划验收。

### E2 / P2：策划指定的全局神通系数有名无效，实际使用其他键

- 需求：设计 `:525`、`:730-732` 要求带百分比效果统一引用12.11系数；`:745` 指定讹兽 `false_ad_prob=10%`，`:746` 及 `:611` 指定梼杌 `refuse_order_prob=10%`。
- 讹兽：`config/global_balance.json:188` 有 `coeff.false_ad_prob`，但真实事件 `config/events.json:69` 用 `events.false_ad_probability`；`world_events.gd:25-27,208-211` 只解析事件给出的键。`coeff.false_ad_prob` 无脚本读取。
- 梼杌：`config/global_balance.json:189` 有 `coeff.refuse_order_prob`；`effect_resolver.gd:259-261` 实际用 `taowu_refusal_chance`，对应 `global_balance.json:472`。canonical键无脚本读取。
- 独立探针：canonical拒绝率设1、实际别名设0，100次指令全部允许；canonical虚假宣传率设1、实际事件别名设0，宣传不入事件队列。默认值相同掩盖了接线错误。

### E3 / P2：另有三个员工调参入口无法控制它们标示的真实行为

1. **英招**：`management_rules.gd:614` 的 `employee_effects()` 消费 `coeff.yingzhao_flow` 并返回 `traffic_bonus`，但 `full_rules.gd:87` 实际客流另读 `coeff.traffic_bonus`，不消费这个字段。默认均0.1，日常测试不暴露。探针把 flow设1、canonical traffic设0，效果字典显示 `traffic_bonus:1.0`，实际客流倍率仍1.0。配置位置 `global_balance.json:184,408`。实际应保留设计 `:741` 的canonical `traffic_bonus`，移除/对齐误导入口。
2. **九婴**：`management_rules.gd:623,662` 将 `coeff.jiuying_batch` 写成员工 `batch_size`，配置 `global_balance.json:405` 可调；真实容量 `game_model.gd:474` 却硬编码3。探针改为1，真实仍同时烹饪3单。默认3符合设计 `:99`，这是调参接线问题，不能说九婴三道菜没有实现。
3. **当康**：`global_balance.json:327` 的 `events.dangkang_period_days=10` 没有读取方；真实触发 `events.json:386` 写死 `day_multiple:10`，由 `world_events.gd:174`直接读这个值。探针把参数改5，第5天仍无折扣事件。默认每10天符合设计 `:81`，问题是公开调参入口失效。

### E4 / P2：梼杌设置排班可能连续掷两次拒绝，实际概率超出10%

- 需求：设计 `:91`、`:611`、`:746` 拒绝指令概率+10%。
- 调用链：`full_rules.gd:306-308` 对带employee_id的操作先判一次；`management_rules.gd:392-395` 的set_shift立即 `_apply_shift()`；`:467-472` 再调用 `game_model.gd:698-700` 的 `set_employee_rest()`，后者再判一次。
- 当新排班要求立即改变在岗/休息状态，首次完成状态转换的概率0.9×0.9=0.81；第二次拒绝也仍由管理操作返回ok=true，排班配置已改变，工作状态暂时未改变。随后每分钟可能继续尝试。此项已通知父代理，建议用一个指令只抽一次并准确返回结果。
- 动态实证：外置 `/tmp/shanhai_taowu_shift_probe.gd` 对真实 `full_rules.perform('set_shift')` 执行10000次（两处拒绝率均显式0.1），986次API拒绝、908次API返回ok但没有休息、8106次成功休息，符合双抽样的81%执行率。探针启动恰逢并行修复读到配置不可用而fallback；拒绝率由探针显式覆写，因此该统计不依赖默认配置是否加载成功。

## 规格冲突与边界（不要直接算成确定程序缺失）

- **白泽隐藏菜**：4.3 `:95` 写「研发必解锁隐藏菜」，7.4 `:182` 写「参与必成功，小概率解锁隐藏菜品」，互相冲突。`management_rules.gd:444-449,504,513-515,524-528` 采用后者：必成功，基础10%+主持人创意×1%隐藏概率。实现不能同时满足两处；应在验收结论中明说采用7.4，勿宣称逐字满足4.3。
- **速度/厨艺方向**：4.2 `:60-61`说厨艺影响研发、速度影响收银做菜；当前 `management_rules.gd:500` 研发成功只看创意，`game_model.gd:543`→`ui/restaurant_view.gd:521-526` 的做菜时长看厨艺、收银看魅力，速度对这两类没有路径。但20.2 `:1084-1086`及20.3 `:1095-1096`明确规定烹饪看厨艺、收银看魅力。应记录跨章节矛盾，勿随意叠加属性更改数值。
- **凤凰士气**：4.3 `:94`写全体士气+10%；实现 `events.json:178-190` 是所有人心情+10点，读 `events.phoenix_morale`，不是 `coeff.phoenix_morale`（后者在 management/global配置存在但无读取）。游戏没有单独士气属性。百分比是否按上限折成点、还是乘当前心情，设计未澄清，宜作为明确简化而不是直接宣称完全一致。
- **穷奇辣味范围**：`management_rules.gd:660`仅对 `qiongqi_hotpot` 提价20%，不是通用辣味tag判定；现有菜表只有这一道明确麻辣菜，因此当前内容可生效，后续新增辣菜不会自动受益。不要据此说当前穷奇正向神通完全缺失。
- **升级范围**：4.4 `:106`只说提升神通等级，没有规定所有正负效果每级如何变动。`management_rules.gd:601-602`提供倍率，并有多个技能消费；部分特性不缩放是实现选择，不据此判缺失。

## 七属性逐项追踪

| 属性/状态 | 真实消费路径 | 结论 |
|---|---|---|
| 七属性缺省0 | `game_model.gd:277-279`、`management_rules.gd:74-79` | 配置全部显式列七属性，缺省0也有回退 |
| 厨艺 | `game_model.gd:525-526`菜品品质；`:543`→`restaurant_view.gd:521-526`烹饪速度 | 有效；研发影响与4.2/20章矛盾见上 |
| 速度 | `restaurant_view.gd:520,523-526`默认move用于ordering/serving/cleaning；`game_model.gd:547`旅行 | 有效；收银/做菜方向矛盾见上 |
| 魅力 | `full_rules.gd:155-164`宣传；`game_model.gd:590`小费、`:601-603`收银价格；animation现金任务 | 有效 |
| 耐力 | `effect_resolver.gd:131-136`消耗/恢复因子；`game_model.gd:671-677`真实应用 | 有效 |
| 口才 | `full_rules.gd:158`宣传；`effect_resolver.gd:206-220`投诉；`game_model.gd:602`也加价格 | 有效 |
| 创意 | `management_rules.gd:486`培训、`:500`研发、`:524-528`隐藏概率 | 有效；隐藏概率只在白泽参与的研发中调用，符合7.4路径 |
| 算力 | `effect_resolver.gd:127-128,181-187`；`game_model.gd:544,608-609`排程/逃单 | 有效 |
| 忠诚/心情 | `management_rules.gd:583-592`离职；`game_model.gd:808-813`工资、`:850`衰减；`world_events.gd:184-186`低心情事件 | 有效 |

## 26神通逐项路径（不以目录/计数作为实现证据）

| 设计行 | 员工 | 实际消费与结论 |
|---|---|---|
|74|羬羊|`demo_rules.gd:143-149`招牌汤+5%，`effect_resolver.gd:94-98`补其余汤；`full_rules.gd:118-122`汇入预留品质，`game_model.gd:526`结算。有效。|
|75|鸮|`demo_rules.gd:155-156`夜市+15%，`full_rules.gd:124-131`→`game_model.gd:550`真实时长。有效。|
|76|耳鼠|`demo_rules.gd:157-158`上菜+10%；`effect_resolver.gd:160-162`蛊雕/灌灌上菜时5%受惊扣2心情。正负效果有真实状态变化，受惊细则为补充选择。|
|77|灌灌|`management_rules.gd:609,624`宣传+5%；`full_rules.gd:155-164`选宣传员后应用；`effect_resolver.gd:147-148`宣传期间顾客满意度-1。有效。|
|78|讹兽|`management_rules.gd:610,624`→`full_rules.gd:162-164`宣传+20%；`events.json:58-109`虚假宣传事件实际钩子。默认有效；canonical系数失联见E2。|
|79|饕餮|`demo_rules.gd:138-139,161-162`+10%耗用/+15%速度；`effect_resolver.gd:101-105`技能等级修正耗用；`game_model.gd:515,550`库存/排程。有效。|
|80|冉遗鱼|`management_rules.gd:611`概率10%与收入20%系数；`effect_resolver.gd:170-178`按真实chef_id、汤品在付款时判定；`game_model.gd:607`进现金。有效。|
|81|当康|`events.json:378-406`第10天折扣、`world_events.gd:516-520`每日钩子，`management_rules.gd:179-190`实际采购价。有效；调参入口见E3。|
|82|天狗|`effect_resolver.gd:181-203`真实天狗收银时降低逃单25%，与算力叠加；`game_model.gd:608-609`真实结账。有效。|
|83|蛊雕|`effect_resolver.gd:81-87`特殊客权重+5%、普通人吓退2%；`game_model.gd:437-444`及生成路径消费。有效。|
|84|九尾狐|`demo_rules.gd:170-171`+30%；`game_model.gd:588-590`记录在该订单，`:604-605`付款兑现。有效。|
|85|毕方|`demo_rules.gd:147-148`烧烤品质+30%；`events.json:112-157`3%火灾，`game_model.gd:535`实际cooking hook；默认有效。|
|86|貔貅|`demo_rules.gd:166-167`收银+15%，`game_model.gd:603`现金；招聘 `demo_rules.gd:194-196`与`full_rules.gd:290-291`只普通招聘+5%。高招未加、且休息不加，与12.6:611「在店时招聘成本+5%」不完全一致；取整/高级灵石口径需定。|
|87|英招|`full_rules.gd:87`客流+10%；`effect_resolver.gd:157`实际服务后满意度+2。默认有效；重复无效flow入口见E3。|
|88|陆吾|`management_rules.gd:615,659`+0.2后，`effect_resolver.gd:117-121`恢复为实际时间×0.8；`game_model.gd:544-545`消费。有效。|
|89|精卫|`effect_resolver.gd:112`清台时长÷1.3；`:264-265`心情衰减×1.2，`game_model.gd:850`日结。有效。|
|90|穷奇|`management_rules.gd:617,660`仅招牌辣锅价+20%；`events.json:593-653`投诉时打架，`effect_resolver.gd:163-167`与`game_model.gd:651-654`发投诉hook。当前可到达，范围边界见上。|
|91|梼杌|`management_rules.gd:618,624`宣传+15%；`effect_resolver.gd:259-261`拒绝真实指令，`full_rules.gd:307`/`game_model.gd:698`消费。E2/E4需修。|
|92|混沌|`management_rules.gd:442-443`研发时间×1.2，`:501`成功率+0.2；`:504`进入实际成功判定。有效。|
|93|獬豸|`effect_resolver.gd:219`投诉概率×0.7、`game_model.gd:651`消费；断案事件 `events.json:723-756`加声望/回头客。顾客信任以这些状态代理，无独立trust属性。|
|94|凤凰|`game_model.gd:678`体力0时fatigue hook；`events.json:160-192`自动复活、所有人心情+10；`world_events.gd:193,363-368`当日标记。有效，士气百分比口径见上。|
|95|白泽|`management_rules.gd:371`训练时长÷1.5，`:444-449`研发保证成功，`:513-528`概率隐藏。与7.4一致，与4.3冲突见上。|
|96|应龙|`management_rules.gd:621,661`水产品质+40%；`effect_resolver.gd:66-70`雨天客流+20%。有效。|
|97|烛龙|`world_events.gd:533-541`每日一次选择营业时段系数，`:121-123`替换真实客流系数；`full_rules.gd:86`→`game_model.gd:379`实际生成。有效。另随机睁眼事件也占用同一每日标记。|
|98|帝江|`effect_resolver.gd:90-91`免旅行、`:158`满意度；额外serve_mult=0为E1。|
|99|九婴|`game_model.gd:474-475`容量3、`:479-483`真实任务计数，`:676`体力×1.3。默认实现正确，batch参数失联见E3。|

## 验证方式和结果

- 无修改游戏的独立探针：`/tmp/shanhai_employee_probe.gd`，使用 Godot 4.6.3；设置 `XDG_DATA_HOME=/tmp/shanhai-employee-audit-data` 和 `XDG_CACHE_HOME=/tmp/shanhai-employee-audit-cache`，防止写玩家目录。
- 命令：`XDG_DATA_HOME=/tmp/shanhai-employee-audit-data XDG_CACHE_HOME=/tmp/shanhai-employee-audit-cache godot --headless --path /workspace/- --script /tmp/shanhai_employee_probe.gd`。
- 结果：帝江40分钟上菜被压成1分钟；梼杌canonical拒绝率100%但实际允许100/100；讹兽canonical虚假宣传100%但队列为空；英招flow100%字典值为1但实际客流1.0；九婴batch=1仍并行3；当康周期设5第5天无事件。探针退出0。
- 第一次未设置XDG目录启动因无权限创建用户数据目录导致Godot崩溃；改为上述/tmp隔离目录后正常，不作为游戏逻辑故障。

## 结论

26名员工均有正向行为或明确事件/状态消费路径，没有发现仅靠26条配置冒充26个全部空技能的情况。主要确定缺口是帝江员工与菜品特效混用、多个系数未接到真实消费、梼杌排班双抽样。对白泽和4.2/20章的互相矛盾要求应明示取舍，不能用已有回归通过数宣称逐字完整。
