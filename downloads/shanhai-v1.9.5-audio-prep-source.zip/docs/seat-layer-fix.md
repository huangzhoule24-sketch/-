# 座位遮挡修复

2026-10-24，基于美术整合版修复用户反馈：坐下或经过座位时，人物偶尔被座位整体盖住。

椅子原先与人物、餐桌共用仅按浮点纵坐标比较的排序；同坐标顺序未固定，临近入座的小数坐标也可能切换前后顺序。

现在椅子由独立背景通道绘制，始终先于人物；缺图的程序椅子也走同一通道。餐桌与人物继续按脚底所在的整像素深度排序；同层固定先设施、后人物，再按稳定序号排序。这样人物不会被椅子覆盖，同一深度附近的小数移动也不会把人物突然压到桌面之下。餐桌前后的正常遮挡保留。

不改变美术、经营数值、角色动作或存档格式。源码中保留原插图接口，独立美术包可继续使用此前版本。

验证：seat_layer_tests覆盖双人/四人桌的12个座位、6种顾客状态，以及座位前/同坐标/后的偏移；并检查等深度排序、微小到达偏移、餐桌自然深度、离店角色和状态/RNG不变。实际结果及浏览器观察见validation-artifacts/seat-layer-fix/。

实际结果：专项438项、界面31项、规则41项、压力4项，共514项通过。浏览器17次实际操作、3项检查、46次实时绘制顺序观察通过；自然观察到ordering/cooking/serving/eating/paying，并完成首单。相机平移不改变暂停后的世界排序，手机横屏复验通过。

最终指纹`1cc209cfb38273b063841287fe2f9aad212a95832b55e2734cebd20510cd2902`，Windows/Web PCK相同；全部274张成品PNG与上一美术版字节一致。现有测试覆盖范围内通过，Windows/手机实机另验。

发布分支`art-seatfix-v1.9.5-20261024`，提交`208e91d6c488d6132692360b3c7355bef7b511b0`。Windows与源码均已无登录下载HTTP200、CRC及SHA256一致；Windows包内回执逐文件校验通过。

- [windows下载](https://github.com/huangzhoule24-sketch/-/raw/208e91d6c488d6132692360b3c7355bef7b511b0/downloads/shanhai-v1.9.5-art-seatfix-windows.zip)：62042525字节，SHA256 `b9a71abfcfc7974feb5d4e2eea01e1c9501262cdcf83ad08e60a4fd5417836d6`。

- [source下载](https://github.com/huangzhoule24-sketch/-/raw/208e91d6c488d6132692360b3c7355bef7b511b0/downloads/shanhai-v1.9.5-art-seatfix-source.zip)：89292263字节，SHA256 `bef05c1917f04236fefe62987867c8f64924431d1107b16ccf2476341aadf8f3`。
