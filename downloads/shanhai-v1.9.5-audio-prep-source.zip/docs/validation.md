> 2026-10-18 当前 v1.5 的测试与发布证据见 [v1.5-validation.md](v1.5-validation.md)。下文为 v1.3 历史记录，不用于宣称新规则已经通关。

# v1.3 完整经营基线验证记录

本页对应文化更新之前的经营基线，游戏源指纹为`433d498e3805caaa84a0dd8d825c52ef2721142aabe8a12fe4b6a5f38560dc0a`。最新文化更新的功能、全量回归与浏览器证据见[culture-validation.md](culture-validation.md)；不以旧源码报告冒充新版本运行。

验证日期：2026-10-17。引擎：Godot 4.6.3 stable。环境：Linux云环境与Chromium。历史开发包不代表本次最终源码；实现与裁决见[完整复现核对](full-reproduction-audit.md)及[覆盖清单](spec-v1.3-coverage.md)。

## 自动回归

`bash tools/run_checks.sh`：19组、**3,090项通过，0失败**。独立执行各组；超时、非零退出、脚本错误、引擎ERROR或无效配置均判失败。摘要：[v1.3-full-checks.json](validation-artifacts/v1.3-full-checks.json)；完整日志生成在`build/check-results/`。

| tests/脚本 | 通过 | 主要核验 |
| --- | ---: | --- |
| run_tests.gd | 67 | 初值、七时段、订单全链、日结、坏档保护 |
| campaign_tests.gd | 192 | 阶段0–4、奖励、真实成本/收款、跨模块存档 |
| management_tests.gd | 164 | 库存、配方、研发主持/厨艺、培养、副职、排班 |
| v13_management_tests.gd | 159 | 七属性、Tutor、培训0.67、品质、离职交接 |
| expansion_tests.gd | 128 | 分店体力/调回、中央厨房/在途、探索、觉醒、大赛、NPC联赛 |
| event_tests.gd | 371 | 原30事件加催收、11羁绊、延期、全天貔貅应收 |
| skill_coverage_tests.gd | 168 | 26员工/23菜的真实效果、收入和库存 |
| animation_tests.gd | 84 | 属性公式、真实培养后派单/工作/画面联动、空闲觉醒无跳点 |
| asset_tests.gd | 51 | PNG/JPG、覆盖、帧序列、缺图坏图、热载、路径边界 |
| tutorial_tests.gd | 22 | 六步、跳过、提前完成、存读 |
| ui_smoke.gd | 216 | 110面板场景、29次真实按钮信号、滚动/边界 |
| save_migration_tests.gd | 62 | 版本1–4、显式导入、RNG/任务、坏档拒绝 |
| balance_tests.gd | 1049 | 873全局数值键、参数消费、候选域及原子拒绝 |
| navigation_tests.gd | 40 | 实际桌面/座位、任务时间、限定传菜穿越 |
| story_tests.gd | 95 | 六主线、12里程碑/26成就、节日/美食节/封锁 |
| world_completion_tests.gd | 73 | 实际美食节、封锁三应对、当天边界、全天收款 |
| ui_requirements_tests.gd | 73 | 六页图鉴、红点、装修侧抽屉、真实动作、紧凑布局 |
| core_completion_tests.gd | 29 | 路程、一次floor、清欠、招募费用、真实采购、三人同批订单 |
| customer_preference_tests.gd | 47 | 独立偏好先于选菜、季节需求、同客复购、保存 |

后期夹具会直接准备阶段、人员和资源，用于核验规则，不能作自然解锁证据。训练会暂停当前任务，觉醒要求员工空闲；不声称培养追溯改写已完成工作。

## 正常新档完整经营

`godot --headless --path . --script res://tools/full_campaign_audit.gd -- --seed=20261015 --days=120`从原始500现金/1200债务、两名员工、阶段0开始，只经玩家可用操作经营并逐分钟推进，没有直接赋予现金、库存、员工、阶段或时间。[最终报告](validation-artifacts/v1.3-full-campaign.json)包含动作、每日快照与源码指纹。

- 第31日22:45完成六条主线及独立26神兽成就并领取奖励，26位员工仍在职，23道原案菜加1道原创隐藏菜。
- 阶段4，大赛8胜，5家分店，4次探索、12次觉醒，经历首个30日NPC赛季。
- 现金756,659.09，营业额1,111,943.53，声望22,713；债务、欠薪与欠租为0。
- 分店成交5,446单、收入628,518.53；中央厨房281批生产、556次调拨完成。
- 审计开始/结束与当前规则、UI、服务和配置逐文件SHA-256一致。

这证明所记录策略能达成完整主线和收集，不证明所有随机种子、任意策略或长期经济均平衡。该策略第2日还债，和原案“约10–20天”的估算存在节奏差异；初值及正式双门槛没有因此改为Demo值。工资正文与算例冲突的裁决另有说明。

保存后新建模型读取：状态、员工、顾客/调度及后续RNG语义一致，0项实质差异。逐项比较键、结构、数组顺序及非数字类型；数值相同的int/float允许互换，整数数值须一致，仅两边均为浮点时容许`max(1,abs(before),abs(after)) × 4 × machine_epsilon`的表示差异。报告列出23处末位差异，最大约2.91×10^-11；金额0.01/10^-7、时间、库存、缺键、顺序、布尔/数字改变有拒绝自检。没有跳过财务字段或采用宽泛近似。

10月16日的五日开局、回归和浏览器摘要保留为历史；本次使用文件名含`full`的新报告。

## 实际浏览器操作

[最终浏览器报告](validation-artifacts/v1.3-full-browser.json)记录38次操作、17项断言通过，来自`tools/verify_browser.cjs`的真实鼠标、键盘、文件选择器操作。只读`?qa=1`快照用于定位控件；没有资源注入、改阶段或改时钟的测试命令。

流程覆盖新档、免费研发、宣传、实际首单、侧栏采购扣钱/加库存、六页图鉴、装修侧抽屉、暂停、手动保存与精确分钟重载。实际导入角色/导航PNG，确认热更新和重载保留。测试图片仅留在测试浏览器存储，未加入正式美术；普通玩家页面没有QA快照。

1440×900桌面、844×390横屏与390×844竖屏分别截图。横屏Canvas铺满视口，主控件保持44 CSS像素，装修抽屉可操作，欢迎页继续按钮固定可达；修复了同步resize重入留下旧渲染区域的问题。竖屏提示旋转。截图在`build/browser-validation-v13-final/`。桌面Chromium调整视口不等于手机触控实机测试。

站点存储异步写入；最终流程保存后等6.5秒再重载并严格核对分钟。此等待不是所有设备的时限保证，不能称为返回即已同步落盘。

## 导出与交付边界

Windows/Web各自`export-receipt.json`绑定同一份73文件游戏源码。打包器核对源码、WASM、Windows PE、PCK、ZIP CRC、许可证、外置美术模板和可编辑源码，生成`build/v1.3-artifact-manifest.json`及SHA-256表。Windows PCK另以Linux Godot加载，不代替Windows EXE本机运行。

Windows运行包发布分支为`game-v1.3-20261017`，链接见[README](../README.md)。发布后回读公开地址并核对字节数与SHA-256，记录于`build/v1.3-published-windows.json`；分支只存运行包和说明。可编辑Source ZIP保留在工作区，不默认公开源码。

- Windows原生机器和手机实机未验收；未交付Android/iOS原生安装包。
- 世界榜为12家NPC企业的逐日经营、30日赛季与历史，没有真人联网排名服务。
- 按用户要求继续暂缓正式美术；四类接图路径、统一服务及缺图回退保留。支持PNG/JPG及帧序列，不承诺外置GIF/SVG。
- 双语文化卡、文化来源核验、三专业教学情境和传播效果评估仍按[项目记忆](project-memory.md)记录，不由一般经营机制推断达成。
