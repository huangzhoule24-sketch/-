# 菜品文化资料核验记录

核验日期：2026-10-17。范围：`config/dishes.json` 的23道设计菜，加 `config/management.json` 的原创隐藏菜 `baize_hidden_banquet`（白泽万象宴），共24条。仅增文化资料，不改价格、配方、解锁、顾客偏好等经营数值。

## 方法与来源层次

实际联网搜索公开古籍仓库并读取全文；每个最终来源URL都以固定提交再次获取并得到HTTP 200。典籍使用Kanripo电子转录，注意正文、郭璞/高诱注和现代释义的层次；机构词典内容使用g0v开放镜像，并明确其不是机构主站；当代社区食谱仅用来说明通行食物形式，不用它证明古代年代、唯一发源地或健康功效。

主流搜索引擎、维基文库、ctext、日本旅游机构等域名在本环境被域名代理拒绝，未把这些未成功读取的页面列成“已核验来源”。韩国/朝鲜半岛拌饭只采用当代形式的保守说明，没有补写宫廷发明、确切起源年代或官方认证。

各卡为重新撰写的简介，现代词典不作大段复制；引语仅限已核验的短古文。原典的异体字尽可能保留，标点为阅读便利所加。Kanripo页码标记、换行及注释可使整句与连续原文不完全相邻，核验时按正文/注释分别阅读。

## 关键事实与创作边界

| 内容 | 实读文本及定位 | 写入简介的处理 |
| --- | --- | --- |
| 祝余 | 南山经·招摇山，`其名曰祝餘`、`食之不飢`，中间有异文小注 | 原典草名；“轻食”和白泽研发组合为原创，不宣称减重。 |
| 迷榖 | 南山经·招摇山，此版本作`迷穀`，`佩之不迷` | 原典是佩戴意象，不证明芽可食；“迷榖芽沙拉”是游戏化食材。 |
| 丹木 | 西山经·峚山，`員葉而赤莖黄華而赤實`、`其味如飴` | 原典树木与果实意象；烤翅、火焰拉面组合为原创。 |
| 薲草 | 西山经·昆仑之丘，`其狀如葵其味如葱食之已勞` | 原典植物叙事；不证明可现实识别野草，更不说奶饮抗疲劳。 |
| 丹粟 | 南山经·柜山，`多丹粟(細丹砂如粟也)` | **丹粟不是已证实的粮食。游戏“丹粟米”明确为虚构谷物，与矿物丹砂无现实食用关系。** |
| 凤凰与涅槃 | 南山经丹穴山五彩凤凰；词典“涅槃”有佛教语境 | 同名菜为后世与现代融合，不把浴火重生说成《山海经》原典固有记载。 |
| 中国天狗与天妇罗 | 西山经阴山天狗如狸、白首；词典天妇罗/甜不辣列日式食品 | 两种文化主动拼接；不把中国天狗、日本天狗和日式菜式混成一条古方。 |
| 精卫与石锅拌饭 | 北山经发鸠山衔木石；当代韩式拌饭社区实例 | 保留韩国/朝鲜半岛饮食称呼，借“石”相连；未考证唯一发源地。 |
| 混沌与云吞 | 庄子应帝王用`渾沌`；词典云吞=馄饨的命名联系 | 近音创作，未证明馄饨由此寓言发明；保留地域做法可变。 |
| 九婴 | 淮南子本经训及高诱注`九嬰水火之怪` | 实读段落未写头数；“九味”和并行烹饪不倒推为原典事实。 |
| 白泽万象宴 | 云笈七签卷100轩辕本纪；南山经祝余 | 明标本作原创隐藏菜，不混入23道标准设计菜，不归称山海经菜谱。 |

通用约定：配方文字中的员工名按招牌主题、主持或解锁关联理解，不要求食用员工身体；每道卡片各自介绍饮食形式、命名灵感和游戏取意，避免整批套用同一段文字。古代神异食效只属于文化叙事，不能作为现实营养、医疗或野生动植物识别证据。

## 实际获取文件与可复核指纹

下列缓存路径用于同一云工作区复核；`/tmp`并非永久交付目录。固定URL与SHA-256可在缓存清理后重新获取比对。两个词典来源ID共享同一个下载文件。

### d_shanhai_01

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_001.txt
- 状态：HTTP 200；字节：11056。
- 缓存：`/tmp/d-culture/verified/d_shanhai_01.txt`
- SHA-256：`40f085dcb1e8be163aa53c3f91ebca79e953fd4b7fbaba63482799d3043074cd`

### d_shanhai_02

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_002.txt
- 状态：HTTP 200；字节：29102。
- 缓存：`/tmp/d-culture/verified/d_shanhai_02.txt`
- SHA-256：`03a3aa2a202252829fe5c097ba436fed1ad7b5e2477eaddf2387ef795b29cbc9`

### d_shanhai_03

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_003.txt
- 状态：HTTP 200；字节：20407。
- 缓存：`/tmp/d-culture/verified/d_shanhai_03.txt`
- SHA-256：`a5612eff37e1acb804c7316527f67cf00f5404a9e5df778ac6e63bf37298678c`

### d_shanhai_04

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_004.txt
- 状态：HTTP 200；字节：9252。
- 缓存：`/tmp/d-culture/verified/d_shanhai_04.txt`
- SHA-256：`077f8490e6930a8d9aa468292fb65761f63d75d1c9295f534a4b834476c9fd51`

### d_shanhai_08

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_008.txt
- 状态：HTTP 200；字节：4275。
- 缓存：`/tmp/d-culture/verified/d_shanhai_08.txt`
- SHA-256：`3ef0bfddf23528dda64040bb8a7cf9d553d9c9a1b5e9b12b36c02b6553d43535`

### d_shanhai_14

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_014.txt
- 状态：HTTP 200；字节：6469。
- 缓存：`/tmp/d-culture/verified/d_shanhai_14.txt`
- SHA-256：`210cf7d700ec57c5f8ae673e13a07b26eca0524e1f4c33c8df2a330e797b98c6`

### d_shanhai_17

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3l0090/87c7f2ab528145f0cd1628fc40a567cc6a5caa34/KR3l0090_017.txt
- 状态：HTTP 200；字节：6871。
- 缓存：`/tmp/d-culture/verified/d_shanhai_17.txt`
- SHA-256：`51d535728feda8c10cffc06b4b931253f7fc61614c8a2cb8d35b3f8c020f03fc`

### d_moe_food, d_moe_myth

- 固定URL：https://raw.githubusercontent.com/g0v/moedict-data/a6dc997417507eb510fc29822bc514de2c92728c/dict-revised.json.xz
- 状态：HTTP 200；字节：14739512。
- 缓存：`/tmp/d-culture/verified/d_moe_food.xz`
- SHA-256：`5cc4ec0efd7e549621edf9b46d261989230c1729d9dc2c8e2056f4b21c8a93da`

### d_community_fried_rice

- 固定URL：https://raw.githubusercontent.com/Anduin2017/HowToCook/743d7f46b7644c43673e0b2e255c745f6fa8ca5e/dishes/staple/%E8%9B%8B%E7%82%92%E9%A5%AD.md
- 状态：HTTP 200；字节：2704。
- 缓存：`/tmp/d-culture/verified/d_community_fried_rice.txt`
- SHA-256：`4b061d24b4e8c6a3dd3791f84de5303b3ff38ab41f8560c5226d76a3e56554e1`

### d_community_bibimbap

- 固定URL：https://raw.githubusercontent.com/Anduin2017/HowToCook/743d7f46b7644c43673e0b2e255c745f6fa8ca5e/dishes/staple/%E9%9F%A9%E5%BC%8F%E6%8B%8C%E9%A5%AD/%E9%9F%A9%E5%BC%8F%E6%8B%8C%E9%A5%AD.md
- 状态：HTTP 200；字节：1819。
- 缓存：`/tmp/d-culture/verified/d_community_bibimbap.txt`
- SHA-256：`5aab8b71de5f31652b4bfaea571316cc6a3b6c0e0cbca8ab1bfa0c0f4484188b`

### d_huainan_08

- 固定URL：https://raw.githubusercontent.com/kanripo/KR3j0010/9b26e5e829bb4b84097ca429178ff79db908aeb7/KR3j0010_008.txt
- 状态：HTTP 200；字节：23622。
- 缓存：`/tmp/d-culture/verified/d_huainan_08.txt`
- SHA-256：`1bef302e1e23a0a591712715a1e85826a9d34bc04934b1cc44f48f1a8d3dd66b`

### d_zhuangzi_07

- 固定URL：https://raw.githubusercontent.com/kanripo/KR5c0126/abb9cd323dfd9520894b56b3b8ba2ec0ea50554f/KR5c0126_007.txt
- 状态：HTTP 200；字节：8122。
- 缓存：`/tmp/d-culture/verified/d_zhuangzi_07.txt`
- SHA-256：`7f7f287748422dd6f8536d479e22cc44ad5be2a02a7f09ea142c2170faf24c12`

### d_zuozhuan_wen18

- 固定URL：https://raw.githubusercontent.com/kanripo/KR1e0001/dc3dc18e0039e05679d98bc650c2f980f8dcabac/KR1e0001_006.txt
- 状态：HTTP 200；字节：100285。
- 缓存：`/tmp/d-culture/verified/d_zuozhuan_wen18.txt`
- SHA-256：`e7685043ac1dbcb67f712c378c5803f088c968f8491b07cd2576981746218736`

### d_songshu_28

- 固定URL：https://raw.githubusercontent.com/kanripo/KR2a0016/e80c057667e3c8684f11d5088251e10244d5a264/KR2a0016_028.txt
- 状态：HTTP 200；字节：32592。
- 缓存：`/tmp/d-culture/verified/d_songshu_28.txt`
- SHA-256：`d06c4f2cc4ffa62ea1d8c95f973a599b4a642418e4cea9255d188a2db7e7ccd3`

### d_yunji_100

- 固定URL：https://raw.githubusercontent.com/kanripo/KR5d0055/c61562292f12f58412019c3e1f34f446b93cebab/KR5d0055_100.txt
- 状态：HTTP 200；字节：36419。
- 缓存：`/tmp/d-culture/verified/d_yunji_100.txt`
- SHA-256：`fc346bfaf857483605b34d6ee559825c345227a2bf8de121aa72ba6abaa417a8`

## 逐条覆盖

| 游戏ID | 菜名 | 归类 | 关联员工 |
| --- | --- | --- | --- |
| noodles | 阳春面 | 传统饮食 |  |
| fried_rice | 蛋炒饭 | 传统饮食 |  |
| plum_juice | 酸梅汤 | 传统饮食 |  |
| qianyang_soup | 羬羊羊肉汤 | 神话主题原创 | qianyang |
| bifang_wings | 毕方烤翅 | 神话主题原创 | bifang |
| fox_milk | 九尾仙奶 | 神话主题原创 | nine_tailed_fox |
| yinglong_hotpot | 应龙海鲜锅 | 神话主题原创 | yinglong |
| taotie_buffet | 饕餮自助套餐 | 神话主题原创 | taotie |
| phoenix_soup | 凤凰涅槃羹 | 神话主题原创 | phoenix |
| zhuyu_salad | 祝余轻食 | 神话主题原创 | baize |
| luwu_platter | 陆吾烤肉拼盘 | 神话主题原创 | luwu |
| yingzhao_salad | 英招时蔬沙拉 | 跨文化创意 | yingzhao |
| jingwei_bibimbap | 精卫石锅拌饭 | 跨文化创意 | jingwei |
| dangkang_rice | 当康丰收炒饭 | 神话主题原创 | dangkang |
| tiangou_tempura | 天狗天妇罗 | 跨文化创意 | tiangou |
| ranyiyu_soup | 冉遗鱼汤 | 神话主题原创 | ranyiyu |
| qiongqi_hotpot | 穷奇麻辣火锅 | 神话主题原创 | qiongqi |
| taowu_barbecue | 梼杌秘制烤肉 | 神话主题原创 | taowu |
| hundun_wonton | 混沌云吞 | 神话主题原创 | hundun |
| xiezhi_set | 獬豸正义套餐 | 神话主题原创 | xiezhi |
| zhulong_ramen | 烛龙火焰拉面 | 神话主题原创 | zhulong |
| dijiang_dumplings | 帝江无面饺子 | 神话主题原创 | dijiang |
| jiuying_platter | 九婴九味拼盘 | 神话主题原创 | jiuying |
| baize_hidden_banquet | 白泽万象宴 | 神话主题原创 | baize |

最终自检：24个ID与实际游戏配置精确对应；姓名一致；每条有独立摘要、3个段落及分段来源ID；摘要60–110字、段落60–150字；16个来源ID全部解析；15个唯一网络文件已实抓为HTTP 200；无正式图片下载或生成。
