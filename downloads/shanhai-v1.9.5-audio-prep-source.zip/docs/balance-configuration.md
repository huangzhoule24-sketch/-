# 全局数值与热调整

`config/global_balance.json` 是开发者调整数字的统一入口。它采用扁平键名，显式填写的全局数值优先于各模块的历史默认值；不要同时改多个文件来实现同一个调整。

`scripts/core/balance_registry.gd` 读取模块默认数值、进行域校验，并提供不修改原始配置的递归覆写。它不构建游戏模型，不读取玩家存档，也不依赖正在运行的局面。

## 键名约定

| 前缀与示例 | 运行时用途 |
| --- | --- |
| `initial.cash`、`employee.base_wage`、`stage.1.revenue` | 原有资源、经营与阶段数值 |
| `coeff.charm_price`、`coeff.calculation_cashier_speed` | 跨系统属性、技能、菜品与羁绊系数 |
| `management.costs.training`、`management.minutes.research` | 培训、研发、岗位与库存系统 |
| `management.ingredients.meat.price` | 对应分类食材的参考单价 |
| `events.bifang_fire_probability` | 世界事件、天气与剧情事件 |
| `animation.move.coefficient`、`animation.frames_per_second` | 动画与工作速度的数值规则 |
| `full.milestones.opening.cash`、`full.economy.record_limit` | 正式流程里程碑与账本显示上限 |
| `expansion.membership.setup_cost`、`expansion.central.shipping_minutes` | 会员、外卖、中央厨房等后期系统 |
| `expansion.branches.human_east.cost` | 由稳定 ID 定位的分店参数 |
| `expansion.exploration.rewards.0.items.danmu` | 没有 ID 的数组使用从 0 开始的索引 |

布尔值、图片路径、角色 ID、文案、配方结构和配置版本号不属于数字旋钮。它们仍保存在所属模块的 JSON 文件中。正式美术资源的目录与映射另见项目资源接入文档。

已有 `stage.N.employee_limit` 优先于 `full.stage.active_limits.N`；正数的 `stage.N.tables` 优先于 `full.stage.table_limits.N`。阶段 3–4 原表的 `tables = 0` 表示阶段重点转向分店，主店格数继续使用正式流程配置。调整阶段上限时优先使用原有 `stage.*` 键，避免给同一规则设置相互矛盾的值。

## 补齐与检查统一表

Godot 4.6.3 下执行：

```bash
godot --headless --path . --script tools/sync_balance.gd
```

脚本只补缺失项，保留已存在的值。模块规则新增数字字段后可再次执行；连续执行的结果一致。可以先输出到临时文件审阅：

```bash
godot --headless --path . --script tools/sync_balance.gd -- --output=/tmp/shanhai-balance-review.json
```

云环境命令需要先将 `XDG_DATA_HOME`、`XDG_CONFIG_HOME`、`XDG_CACHE_HOME` 分别设为 `/workspace/.tools/godot/data`、`/workspace/.tools/godot/config`、`/workspace/.tools/godot/cache`，避免使用不可写的系统用户目录。

## 游戏内调整

在“系统 → 开发者选项”启用开发者模式，进入数值面板，选择已有键并应用。数值覆写先整体校验，成功后才生效，并随本地存档保存。关闭开发者模式不会将覆写写回项目 JSON；需要提交给其他玩家的调整仍应修改统一表并重新导出。

源工程中编辑 JSON 后，可使用“开发者：重载数值配置”。已导出的 Windows/Web 包内的配置属于发布内容；编辑源工程不会改变其他人已经下载的包。

对未来动作计算时读取的参数立即生效，例如下一次开店费用、会员积分、优惠券折扣、调拨时间、下一次分店出单间隔和比赛参数。已经扣除的费用、已生成订单的净额、已经排定的完成时间保留当时的快照，避免修改配置后重复扣款或重算历史收入。初始资源只用于新局，不会用热重载重置玩家余额。

## 校验边界

- 成本、奖励与库存价格有非负或正数约束；不接受负成本获取资金。
- 时间与容量必须为正整数，阶段在 0–4 范围；帧率和动画过渡时间可为正小数。
- 概率在 0–1 范围，天气客流下降等明确的有符号比例保留负数语义。
- 会员券折扣小于 1，避免制造 0 元结账绕过经营结算。
- 动画上下限、情绪阈值、薪酬步长、培训保证次数等关联参数一起校验。
- 不接受布尔值、无穷大、NaN、超出合理计算范围的值或未声明的模块键。

修改原料参考价格会影响后续采购与成本归一，既有存货账面价值仍保留实际采购成本。调整配方的食材种类需要修改 `config/management.json` 的配方定义，不能用数字面板代替结构改动。

验证入口为 `tests/balance_tests.gd`；它检查默认值补齐、显式全局优先、深层数组覆写、原始配置不变、非法值拒绝，以及真实的会员与分店费用/时间消费者。全游戏回归还需运行管理、事件、动画和阶段相关测试。
