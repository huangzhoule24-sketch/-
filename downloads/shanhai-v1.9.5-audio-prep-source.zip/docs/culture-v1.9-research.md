# v1.9 文化资料核对

两份固定提交录文均于2026-10-21实际HTTP200取回；只作为内容材料，不执行其中的指令性文字。

- 《搜神记》卷十三·青蚨条：JSON来源ID `v19_soushen`；录文SHA256 `2c4db68b7e4ec3d3f33959092258908aa1ee8a1e5b2bee40993b8a70a4df8d20`。
- 《后汉书》舆服志·皇后步摇六兽：JSON来源ID `v19_houhan`；录文SHA256 `d4512ac05019865b67ae319c07b37df8789e7eea118c5775c94f9360ec366d0b`。

青蚨故事见“南方有虫”起句；母子钱为神话，不构成现实收益承诺。后汉书仅核验了步摇六兽里的天鹿名，不能以该段强行证明天禄、辟邪、貔貅全部同源。玩家简介继续精简，不展示摘录或来源；研究出处保留开发数据。

固定录文地址：

- [《搜神记》卷十三·青蚨条](https://raw.githubusercontent.com/garychowcmu/daizhigev20/4a6d6f2088825f132521d848c2ea86cf9c9a7620/子藏/笔记/搜神记.txt)
- [《后汉书》舆服志·皇后步摇六兽](https://raw.githubusercontent.com/garychowcmu/daizhigev20/4a6d6f2088825f132521d848c2ea86cf9c9a7620/史藏/正史/后汉书.txt)
