extends SceneTree

const Model = preload("res://scripts/core/game_model.gd")
var checks: int = 0
var failures: Array[String] = []

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures.append(label)
		printerr("FAIL: ", label)

func near(a: float, b: float) -> bool:
	return absf(a - b) < 0.00001

func fresh(seed_value: int = 13017):
	var m = Model.new(seed_value)
	m.start_full()
	m.events.clear()
	m.balance["customer.base_flow"] = 0.0
	m.state.cash = 10000.0
	m.state.stage = 1
	return m

func add_employee(m, id: String) -> Dictionary:
	var employee: Dictionary = m._create_employee(m._employee_config(id))
	m.employees.append(employee)
	m.full_rules.ensure_state_defaults()
	return employee

func finish_projects(m) -> void:
	var due: int = int(m.state.total_minutes)
	for project in m.state.management.projects: due = maxi(due, int(project.due))
	m.advance_minutes(due - int(m.state.total_minutes))

func _init() -> void:
	call_deferred("run")

func run() -> void:
	tutor_tests()
	missing_attribute_tests()
	hidden_recipe_tests()
	audit_research_tests()
	quality_and_retention_tests()
	balance_validation_tests()
	if failures.is_empty():
		print("v13_management_tests: %d checks passed" % checks)
		quit(0)
	else:
		printerr("v13_management_tests: %d failures / %d checks" % [failures.size(), checks])
		quit(1)

func tutor_tests() -> void:
	var m = fresh()
	var rules = m.full_rules.management
	var baize: Dictionary = add_employee(m, "bai_ze")
	check(str(m._employee_config("bai_ze").role) == "tutor", "v1.3 Baize catalog occupation is Tutor")
	check(str(baize.role) == "tutor" and str(baize.primary_role) == "tutor", "Baize starts in actual Tutor occupation")
	check("tutor" in rules.snapshot().roles, "staff configuration exposes Tutor for primary and secondary careers")
	var phoenix: Dictionary = m._create_employee(m._employee_config("feng_huang"))
	check(near(m.employee_wage(baize), m.employee_wage(phoenix)) and m.employee_wage(baize) > 0, "Tutor has explicit nonzero wage coefficient matching former All role")
	for employee in m.employees:
		if str(employee.id) != "bai_ze": employee.resting = true
	for task in ["cooking", "ordering", "serving", "paying", "cleaning"]:
		check(m._worker_for(task).is_empty(), "Tutor cannot be assigned restaurant task " + task)
	var coaching: Dictionary = rules.perform("train_attribute", {"id":"xian_yang", "attribute":"cooking"})
	check(coaching.ok and int(coaching.get("due", 0)) - int(m.state.total_minutes) == 21, "on-duty Baize applies literal 0.67 duration with ceiling: 30 minutes becomes 21")
	finish_projects(m)
	check(not rules.perform("switch_role", {"id":"bai_ze", "role":"chef"}).ok, "Tutor cannot become chef before completing secondary career")
	var research: Dictionary = rules.perform("research", {"id":"qianyang_soup", "employee_id":"bai_ze"})
	check(research.ok and str(research.get("employee_id", "")) == "bai_ze", "Tutor directly hosts real research without an on-duty chef")
	check(int(baize.management_until) > int(m.state.total_minutes), "research occupies Tutor until project completion")
	check(not rules.perform("train_attribute", {"id":"bai_ze", "attribute":"creativity"}).ok, "Tutor cannot train concurrently with research")
	var invalid_employees: Array = m.employees.duplicate(true)
	for employee in invalid_employees:
		if str(employee.id) == "bai_ze":
			employee.role = "waiter"
			employee.primary_role = "waiter"
	check(not rules.validate_state(m.state.management, invalid_employees, int(m.state.total_minutes)), "saved research rejects a non-research occupation even when its primary-role fields agree")
	var path: String = "user://v13-tutor-research.json"
	check(m.save_game(path), "Tutor research save succeeds")
	var copy = Model.new(13018)
	var loaded: bool = copy.load_game(path)
	check(loaded, "Tutor occupation and active project load through actual model validation")
	if loaded:
		copy.events.clear()
		copy.balance["customer.base_flow"] = 0.0
		check(str(copy._employee("bai_ze").role) == "tutor" and copy.state.management.projects.size() == 1, "loaded Tutor retains exact occupation and project")
		finish_projects(copy)
		check("qianyang_soup" in copy.state.unlocked_dishes and copy.state.management.projects.is_empty(), "loaded Tutor completes recipe exactly once")
	finish_projects(m)
	check("qianyang_soup" in m.state.unlocked_dishes, "Tutor-hosted guaranteed paid research produces an actual recipe")
	var before: float = float(m.state.cash)
	var career: Dictionary = rules.perform("train_secondary", {"id":"bai_ze", "role":"chef"})
	check(career.ok and float(m.state.cash) < before, "Tutor can purchase normal secondary-career training")
	finish_projects(m)
	check(str(baize.secondary_role) == "chef" and rules.perform("switch_role", {"id":"bai_ze", "role":"chef"}).ok, "completed training permits explicit Tutor-to-chef switch")
	check(str(m._worker_for("cooking").get("id", "")) == "bai_ze", "trained secondary chef performs chef work only after explicit switch")
	check(rules.perform("switch_role", {"id":"bai_ze", "role":"tutor"}).ok and m._worker_for("cooking").is_empty(), "returning to Tutor removes restaurant chef capability")
	check(rules.validate_state(m.state.management, m.employees, int(m.state.total_minutes)), "Tutor primary and trained secondary validate without All-role loophole")
	m = fresh()
	rules = m.full_rules.management
	check(rules.perform("train_secondary", {"id":"xian_yang", "role":"tutor"}).ok, "ordinary employee can train Tutor secondary career")
	finish_projects(m)
	check(rules.perform("switch_role", {"id":"xian_yang", "role":"tutor"}).ok, "trained Tutor secondary maps to actual Tutor occupation")
	check(rules.perform("research", {"id":"qianyang_soup", "employee_id":"xian_yang"}).ok, "secondary Tutor can host recipe research")
	finish_projects(m)
	check(rules.perform("switch_role", {"id":"xian_yang", "role":"chef"}).ok, "employee can return to original primary career")

func audit_research_tests() -> void:
	var low = fresh(13101)
	var high = fresh(13101)
	for m in [low, high]:
		m.state.stage = 1
		m._employee("xian_yang").attributes.creativity = 0
	high._employee("xian_yang").attributes.cooking = 20
	var low_chance: float = low.full_rules.management.research_chance(low._employee("xian_yang"))
	var high_chance: float = high.full_rules.management.research_chance(high._employee("xian_yang"))
	check(high_chance > low_chance, "cooking improves research at fixed creativity as required by section 4.2")
	var selected_seed: int = 0
	for candidate in range(1, 1000):
		low._rng.seed = candidate
		var roll: float = low._rng.randf()
		if roll >= low_chance and roll < high_chance:
			selected_seed = candidate
			break
	check(selected_seed > 0, "research comparison has a deterministic roll between the two chances")
	for m in [low, high]:
		var job: Dictionary = m.full_rules.management.perform("research", {"id": "qianyang_soup", "employee_id": "xian_yang"})
		check(job.ok, "selected chef can start a real research project")
		m.state.total_minutes = int(job.due)
		m._rng.seed = selected_seed
		m.full_rules.management.tick_minute()
	check(not "qianyang_soup" in low.state.unlocked_dishes and "qianyang_soup" in high.state.unlocked_dishes, "cooking changes the outcome of a completed project with identical creativity and random roll")
	var m = fresh(13102)
	var snapshot: Dictionary = m.full_rules.management.snapshot()
	check(snapshot.researchers.size() == 1 and str(snapshot.researchers[0].id) == "xian_yang", "research UI candidates include the actual on-duty chef")
	m._employee("xian_yang").resting = true
	check(m.full_rules.management.snapshot().researchers.is_empty(), "off-duty chef is excluded from research selection")
	m = fresh(13103)
	m.balance["coeff.hidden_choice_price"] = 0.35
	m.balance["coeff.hidden_choice_speed"] = 0.25
	m.balance["coeff.hidden_quality"] = 0.1
	m.state.management.hidden_effects.hundun_wonton = "price_mult"
	check(near(float(m.full_rules.management.modifiers("hundun_wonton").price_mult), 1.35), "hidden price outcome reads its own configured coefficient")
	m.state.management.hidden_effects.hundun_wonton = "cook_speed"
	check(near(float(m.full_rules.management.modifiers("hundun_wonton").cook_speed), 1.25), "hidden speed outcome reads its own configured coefficient")
	m = fresh(13104)
	m.full_rules.management.add_item("meat", 100)
	m.state.unlocked_dishes.append("qianyang_soup")
	m.state.menu_enabled = ["qianyang_soup"]
	m.state.world.season = "spring"
	m.state.total_minutes = 360
	var spring_flow: float = m.full_rules.effects.traffic_multiplier()
	m.state.world.season = "winter"
	m.state.total_minutes = 90 * 1440 + 360
	check(near(m.full_rules.effects.traffic_multiplier(), 2), "winter soup demand doubles actual traffic even with a one-dish menu")
	m.state.world.season = "spring"
	m.state.total_minutes = 360
	m.state.menu_enabled = ["noodles", "qianyang_soup"]
	var ordinary_flow: float = m.full_rules.effects.traffic_multiplier()
	m.state.world.season = "winter"
	m.state.total_minutes = 90 * 1440 + 360
	check(near(m.full_rules.effects.traffic_multiplier(), 1.5), "mixed menu demand changes total arrivals without doubling unaffected dishes")
	m.balance["coeff.refuse_order_prob"] = 1
	check(not m.full_rules.effects.instruction_allowed({"id": "tao_wu"}), "canonical refusal coefficient controls the actual instruction check")
	m.state.balance_overrides = {"coeff.taowu_refusal_chance": 0}
	check(m.full_rules.effects.instruction_allowed({"id": "tao_wu"}), "old saved refusal override remains usable")
	m.state.balance_overrides["coeff.refuse_order_prob"] = 1
	check(not m.full_rules.effects.instruction_allowed({"id": "tao_wu"}), "new canonical saved refusal override takes priority")
	m = fresh(13105)
	var taowu: Dictionary = add_employee(m, "tao_wu")
	m.balance["coeff.refuse_order_prob"] = 1
	var before_raise: int = int(taowu.wage_extra)
	check(not m.full_rules.perform("raise_wage", {"id": "tao_wu"}).ok and int(taowu.wage_extra) == before_raise, "id-based UI instruction respects canonical refusal without changing wages")
	m.balance["coeff.refuse_order_prob"] = 0.1
	var honest_results: bool = true
	var accepted_shifts: int = 0
	for candidate in range(1, 101):
		taowu.resting = false
		taowu.shift_enabled = false
		m._rng.seed = candidate
		var result: Dictionary = m.full_rules.perform("set_shift", {"id": "tao_wu", "periods": [], "enabled": true})
		if bool(result.ok): accepted_shifts += 1
		if bool(result.ok) != bool(taowu.resting): honest_results = false
	check(accepted_shifts > 0 and accepted_shifts < 100 and honest_results, "each real shift instruction rolls refusal once and accepted instructions always change the work state")

func quality_and_retention_tests() -> void:
	var m = fresh(13201)
	var rules = m.full_rules.management
	for dish in m.dishes:
		var expected: float = 85 if str(dish.id) == "phoenix_true_soup" else 75
		check(near(float(dish.get("quality", -1)), expected) and near(rules.dish_quality(str(dish.id)), expected), str(dish.id) + " retains its configured quality baseline")
	m.state.developer_mode = true
	check(m.apply_balance_override("dish.noodles.quality", 40), "developer tool accepts a real per-dish quality baseline")
	check(near(rules.dish_quality("noodles"), 40) and near(rules.dish_quality("fried_rice"), 75), "per-dish global override has priority and leaves other dishes independent")
	check(not m.apply_balance_override("dish.noodles.quality", 101), "developer tool rejects quality outside the documented 0–100 scale")
	check(not rules.validate_balance({"dish.missing_recipe.quality":50}), "unknown per-dish quality cannot create a phantom menu entry")
	check(not rules.validate_balance({"coeff.training_time_mult":0}) and not rules.validate_balance({"coeff.training_time_mult":1.01}), "Tutor duration multiplier preserves positive bounded time")
	var baize: Dictionary = add_employee(m, "bai_ze")
	check(m.apply_balance_override("coeff.training_time_mult", 0.8), "Tutor literal duration multiplier is hot adjustable")
	var trained: Dictionary = rules.perform("train_attribute", {"id":"xian_yang", "attribute":"speed"})
	check(trained.ok and int(trained.due) - int(m.state.total_minutes) == 24, "adjusted Tutor multiplier controls real project due time")
	finish_projects(m)
	baize.resting = true
	trained = rules.perform("train_attribute", {"id":"xian_yang", "attribute":"speed"})
	check(trained.ok and int(trained.due) - int(m.state.total_minutes) == 30, "resting Tutor gives no training-time bonus")
	var worker: Dictionary = m._employee("xian_yang")
	worker.mood = 5
	m.balance["coeff.quit_chance"] = 1
	rules.on_day()
	check(not m._employee("xian_yang").is_empty() and worker.pending_resignation and m.state.management.projects.size() == 1, "busy low-morale staff roll daily resignation and retain a referenced project for handover")
	check(not rules.perform("train_attribute", {"id":"xian_yang", "attribute":"charm"}).ok, "staff awaiting resignation cannot begin another project")
	var path: String = "user://v13-pending-resignation.json"
	check(m.save_game(path), "pending resignation project can be saved with intact references")
	var copy = Model.new(13202)
	check(copy.load_game(path), "pending resignation reloads through real validation")
	if not copy._employee("xian_yang").is_empty():
		check(copy._employee("xian_yang").pending_resignation, "loaded staff retain handover decision instead of rerolling")
		finish_projects(copy)
		check(copy._employee("xian_yang").is_empty() and copy.state.management.projects.is_empty(), "handover finishes project then removes employee and references immediately")
		check(copy.save_game(path), "post-handover state has no dangling project and saves")
	var invalid: Array = m.employees.duplicate(true)
	for employee in invalid:
		if str(employee.id) == "xian_yang": employee.pending_resignation = "true"
	check(not rules.validate_state(m.state.management, invalid, int(m.state.total_minutes)), "nonboolean resignation flags fail candidate validation")
	finish_projects(m)
	check(m._employee("xian_yang").is_empty() and m.state.management.projects.is_empty(), "original handover finishes once without abandoning development cost")
	m = fresh(13203)
	rules = m.full_rules.management
	m._employee("xian_yang").branch_id = "human_east"
	m.state.expansion.branches.human_east.open = true
	m._employee("xian_yang").mood = 5
	m.balance["coeff.quit_chance"] = 1
	rules.on_day()
	check(m._employee("xian_yang").is_empty(), "branch assignment grants no immunity to real daily resignation")
	check(m.save_game(path), "branch departure has no dangling staffing reference and saves")
	check(copy.load_game(path) and copy._employee("xian_yang").is_empty(), "branch departure reload preserves staff removal")
	m = fresh(13204)
	rules = m.full_rules.management
	m.state.stage = 3
	m.state.gems = 100
	var expansion = m.full_rules.expansion
	check(expansion.perform("explore", {"employee_id":"xian_yang"}).ok, "real exploration starts before daily retention check")
	var payload: Dictionary = m.state.expansion.explorations[0].duplicate(true)
	m._employee("xian_yang").mood = 5
	m.balance["coeff.quit_chance"] = 1
	rules.on_day()
	check(m._employee("xian_yang").pending_resignation and m.state.expansion.explorations.size() == 1, "expedition staff receive the daily roll and keep the saved exploration for handover")
	check(m.save_game(path) and copy.load_game(path), "exploration handover saves and reloads with all job references")
	m.state.total_minutes = int(payload.due)
	expansion.tick_minute()
	check(m._employee("xian_yang").is_empty() and m.state.expansion.explorations.is_empty(), "expansion release finishes pending resignation in the same completion call")
	check(m.state.expansion.exploration_history.size() == 1, "handover preserves actual exploration rewards and one completion record")
	check(m.save_game(path) and copy.load_game(path), "completed exploration departure leaves no dangling employee reference")

func missing_attribute_tests() -> void:
	var m = fresh()
	var rules = m.full_rules.management
	check(int(m._employee_config("bai_ze").attributes.creativity) == 10 and int(m._employee_config("bai_ze").attributes.cooking) == 6 and int(m._employee_config("bai_ze").attributes.speed) == 0, "Baize retains the two specified stats and zeroes unspecified catalog stats")
	check(int(m._employee_config("xian_yang").attributes.speed) == 1 and int(m._employee_config("er_shu").attributes.charm) == 1, "catalog preserves explicitly specified level-one attributes")
	check(int(m._employee_config("xiao").attributes.creativity) == 0 and int(m._employee_config("pi_xiu").attributes.calculation) == 8, "ordinary and specialist catalog attributes follow v1.3 table")
	check(m._employee_config("feng_huang").attributes.values().all(func(value): return int(value) == 8), "Phoenix uses v1.5 seven attributes at eight")
	var entry: Dictionary = m._employee_config("xian_yang").duplicate(true)
	entry.attributes = {"cooking":2}
	var employee: Dictionary = m._create_employee(entry)
	for attribute in ["speed", "charm", "endurance", "creativity", "eloquence", "calculation"]:
		check(near(float(employee.attributes.get(attribute, -1)), 0), "model creation defaults missing " + attribute + " to zero")
	m.employees.clear()
	m.employees.append(employee)
	rules.ensure_state()
	check(near(float(employee.attributes.cooking), 2), "explicit attribute value survives schema completion")
	employee.attributes.erase("eloquence")
	rules.ensure_state()
	check(near(float(employee.attributes.eloquence), 0), "management also repairs missing saved attribute with zero")
	check(near(rules.training_cost(employee, "eloquence"), 0), "zero-level training follows current-level cost formula")
	employee.training_experience_by_attribute.eloquence = int(rules.config.guarantees.training_failures)
	var before: float = float(m.state.cash)
	var project: Dictionary = rules.perform("train_attribute", {"id":"xian_yang", "attribute":"eloquence"})
	check(project.ok and int(project.due) > int(m.state.total_minutes), "zero-level attribute training still consumes actual time")
	finish_projects(m)
	check(near(float(employee.attributes.eloquence), 1), "first successful training raises zero to one rather than two")
	check(near(float(m.state.cash), before), "zero-level training charges exactly formula cost")
	check(near(rules.training_cost(employee, "eloquence"), 50), "next training correctly uses new level one")

func hidden_recipe_tests() -> void:
	for creativity in [0, 10]:
		var m = fresh(13019)
		var rules = m.full_rules.management
		var baize: Dictionary = add_employee(m, "bai_ze")
		baize.attributes.creativity = creativity
		m.balance["coeff.hidden_chance"] = 0.0
		m.balance["coeff.hidden_creativity"] = 0.1
		check(near(rules.hidden_recipe_chance(baize), float(creativity) / 10), "hidden chance responds to real creativity value " + str(creativity))
		check(rules.perform("research", {"id":"qianyang_soup", "employee_id":"bai_ze"}).ok, "creativity boundary fixture starts actual research")
		finish_projects(m)
		check(bool(m.state.management.get("hidden_unlocked", false)) == (creativity == 10), "actual completed research uses creativity-dependent hidden roll")
		if creativity == 10:
			check("baize_hidden_banquet" in m.state.menu_enabled and not m._dish("baize_hidden_banquet").is_empty(), "hidden discovery unlocks a sellable recipe and menu entry")
			check(near(float(m._dish("baize_hidden_banquet").cost), 16), "hidden recipe retains explicit independent food cost")
	var m = fresh()
	var rules = m.full_rules.management
	var chef: Dictionary = m._employee("xian_yang")
	m.balance["coeff.hidden_chance"] = 1.0
	m.balance["coeff.hidden_creativity"] = 0.0
	check(rules.perform("research", {"id":"qianyang_soup", "employee_id":"xian_yang"}).ok, "research without Baize can succeed normally")
	finish_projects(m)
	check(not bool(m.state.management.get("hidden_unlocked", false)), "hidden recipe retains the Baize-participation gate")
	chef.attributes.creativity = 100
	m.balance["coeff.hidden_creativity"] = 1.0
	check(near(rules.hidden_recipe_chance(chef), 1), "hidden probability clamps to one even after high attribute scaling")

func balance_validation_tests() -> void:
	var m = fresh()
	var rules = m.full_rules.management
	var defaults: Dictionary = rules.balance_defaults()
	check(defaults.has("coeff.hidden_creativity") and near(float(defaults["coeff.hidden_creativity"]), 0.01), "new hidden-creativity coefficient is exposed with documented default")
	check(defaults.has("management.ingredients.rare.price") and defaults.has("management.minutes.research"), "ingredient and project duration knobs are exposed")
	check(not defaults.has("management.hidden_recipe.price"), "static recipe fields are not advertised as unsupported hot overrides")
	check(rules.validate_balance(defaults), "complete documented management defaults pass domain validation")
	check(rules.validate_balance({"unrelated.global.key":42}), "management validator composes with other modules")
	var cases: Array = [
		["management.costs.training", -1], ["management.costs.raise_step", 0],
		["management.minutes.training", 0], ["management.minutes.research", 1.5],
		["management.minutes.day", 0], ["management.minutes.minutes_per_hour", 30],
		["management.guarantees.training_failures", -1], ["management.guarantees.research_failures", 0.5],
		["management.ingredients.generic.price", 0], ["management.ingredients.meat.price", INF],
		["management.limits.price_min", 0], ["management.limits.price_max", 0.1],
		["management.limits.history_days", 0], ["management.limits.skill_level", 33],
		["management.limits.wage_extra", 95], ["management.thresholds.research_stage", 5],
		["management.thresholds.freshness", 101], ["management.rarity_multipliers.SSR", 0],
		["management.initial.skill_books", -1], ["coeff.hidden_chance", 1.1],
		["coeff.hidden_creativity", -0.01], ["coeff.research_cap", NAN],
		["coeff.training_success", 2], ["coeff.buffet_turnover", 0],
		["coeff.jiuying_batch", 2.5], ["management.unknown.unused", 1]
	]
	var original_state: String = JSON.stringify(m.state)
	var original_balance: String = JSON.stringify(m.balance)
	for case in cases:
		var candidate: Dictionary = {}
		candidate[str(case[0])] = case[1]
		check(not rules.validate_balance(candidate), "reject unsafe management override " + str(case[0]))
	check(rules.validate_balance({"management.costs.training":0, "management.guarantees.training_failures":0, "coeff.hidden_chance":0, "coeff.guanguan_mood":-2}), "legitimate zero costs, probability boundaries and signed mood remain configurable")
	check(JSON.stringify(m.state) == original_state and JSON.stringify(m.balance) == original_balance, "all candidate validations leave live state and balance untouched")
	m.state.developer_mode = true
	check(m.apply_balance_override("management.costs.training", 25), "actual developer tool can apply a valid management override")
	check(near(rules.training_cost(m._employee("xian_yang"), "cooking"), 50), "accepted developer override changes real cost immediately")
	check(not m.apply_balance_override("management.costs.training", -1), "actual developer tool rejects invalid management domain")
	check(near(rules.training_cost(m._employee("xian_yang"), "cooking"), 50), "rejected developer override preserves previous valid cost")
