extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func settle():
	for i in range(8):await process_frame
func find(node: Node,id: String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var found=find(child,id)
		if found!=null:return found
	return null
func labels(node: Node) -> String:
	var result=str(node.text) if node is Label or node is Button else ""
	for child in node.get_children():result+="\n"+labels(child)
	return result
func run():
	root.size=Vector2i(1440,900);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	for dimensions in [Vector2i(1440,900),Vector2i(844,390)]:
		root.size=dimensions;ui.update_ui_layout();await settle()
		var bar=ui.bottom_ui.first
		expect(not ui._layout_controls.header.visible and bar.get_global_rect().end.y<=ui.map_view.global_position.y,"Top HUD precedes map "+str(dimensions))
		expect(bar.get_global_rect().end.x<=ui.size.x+1,"Resources and controls fit horizontal viewport "+str(dimensions))
		if ui.compact_layout:ui.bottom_ui.show_speeds()
		else:ui.bottom_ui.speed_popup.hide()
		for button in [ui.pause_button]+ui.speed_buttons:
			expect(button.size.x>=44 and button.size.y>=44,"44px visible time control "+button.text+str(dimensions))
		ui.bottom_ui.speed_popup.hide()
		var map_height=ui.map_view.size.y
		find(ui,"inventory:toggle").pressed.emit();await settle()
		expect(ui._layout_controls.bottom.get_global_rect().end.y<=ui.size.y,"Expanded inventory keeps all fixed bottom rows on screen "+str(dimensions))
		expect(ui.bottom_ui.inventory_box.visible and ui.map_view.size.y<map_height,"Inventory expands inline and reduces map height "+str(dimensions))
		expect(find(ui,"inventory:cash")!=null and find(ui,"inventory:books")!=null,"Inventory reads actual usable resources")
		find(ui,"inventory:toggle").pressed.emit();await settle()
		expect(not ui.bottom_ui.inventory_box.visible and ui.map_view.size.y>=map_height,"Collapse restores map space")
		ui.open_panel("经营状态");await settle()
		expect(ui.modal_window.get_global_rect().position.y>=bar.get_global_rect().end.y,"Open panel leaves top status unobscured")
		find(ui,"panel:close").pressed.emit();await settle()
	root.size=Vector2i(1440,900);ui.update_ui_layout();await settle()
	ui.model.full_rules.revision18.apply_state("rush_hour");ui.refresh();await settle()
	expect(find(ui,"state:rush_hour").visible and find(ui,"state:rush_hour").tooltip_text.contains("120分钟"),"State badge has actual remaining duration")
	ui.open_panel("经营状态");await settle()
	find(ui,"kitchen:clean").pressed.emit();await settle();expect(is_instance_valid(ui._requirement_dialog),"Missing cleaning assignment prompts user")
	ui._requirement_dialog.hide();ui.open_panel("经营状态");await settle();var selector=find(ui,"kitchen:employee");selector.select(1)
	find(ui,"kitchen:clean").pressed.emit();await settle()
	expect(not ui.model.state.revision18.cleaning.is_empty() and labels(ui.modal_body).contains("正在清洁"),"UI starts actual assigned cleaning job")
	ui.close_panel();ui.model.events.clear();ui.model.state.total_minutes=1439;ui.model.advance_minutes(1);ui.revision_ui.poll(0);await settle()
	var text=labels(ui.modal_body);expect(text.contains("经营收入") and not text.contains("菜品￥"),"Daily summary defaults to a single operating income row")
	find(ui,"bill:details:1").pressed.emit();await settle();expect(labels(ui.modal_body).contains("菜品￥"),"Daily income details can be expanded")
	find(ui,"daily:ack").pressed.emit();await settle()
	for id in ["xuan_gui","qing_geng"]:
		ui.open_culture("employees",id);await settle();expect(ui.panel_name=="文化简介" and ui.culture_panel.entry_id==id,"New employee cultural introduction is viewable "+id)
	ui.open_panel("美术资源");await settle();expect(ui._art_culture_slots.item_count>=82,"55 culture images,12 guest images,2 pickup icons and manual path")
	ui.close_panel();ui.model.state.revision18.pickups=[{"id":1,"kind":"cash","amount":10,"x":500.0,"y":500.0,"remaining":15.0}];await settle()
	var cash=ui.model.state.cash;var pickup=find(ui,"pickup:1");expect(pickup!=null and pickup.size.x>=44,"Scene has real clickable pickup")
	pickup.pressed.emit();await settle();expect(ui.model.state.cash==cash+10 and ui.model.state.revision18.pickups.is_empty(),"Scene pickup click uses authoritative cash action")
	ui.queue_free();await settle();print("V1.8 UI: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
