extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Finance=preload("res://scripts/core/finance_rules.gd")
var checks: int=0
var failures: int=0
func check(value: bool,message: String) -> void:
	checks+=1
	if not value: failures+=1; push_error(message)
func near(a: float,b: float) -> bool: return absf(a-b)<0.001
func fresh() -> Dictionary:
	var model=Model.new(15102026)
	model.start_full()
	var finance=Finance.new(model,model.full_rules)
	finance.ensure_state()
	return {"m":model,"f":finance}
func close_day(pair: Dictionary,day: int) -> Dictionary:
	pair.m.state.total_minutes=day*1440
	pair.f.begin_day_close()
	var report: Dictionary=pair.f.settle_daily_charges()
	pair.f.finish_day(report)
	return report
func _init() -> void: call_deferred("run")
func run() -> void:
	var pair: Dictionary=fresh()
	var m=pair.m
	var f=pair.f
	m.state.cash=800
	m.state.finance.opening_cash=800
	check(near(float(f.preview_bill().wages_due),88),"v1.5 N waiter40 and chef48 salaries total88")
	check(near(float(f.preview_bill().minimum_due),50),"protection period minimum payment50")
	check(near(float(f.preview_bill().rent_due),0) and near(float(f.preview_bill().utilities_due),0),"protection exempts both rent and utilities")
	check(near(float(m.state.cash),800),"bill preview never charges cash")
	var report: Dictionary=close_day(pair,1)
	check(near(float(report.interest_due),6),"remaining principal1200 simple daily interest6")
	check(near(float(report.repayment),50) and near(float(m.state.debt),1150),"day1 pays protection principal50")
	check(near(float(report.wages),88),"actual employee wage debit88")
	check(near(float(report.rent_utilities),0) and near(float(m.state.cash),656),"day1 cash out144 including interest, not just fixed138")
	check(bool(report.cash_reconciled),"day1 cash bill matches every real cash flow")
	check(near(float(report.net_profit),-94),"profit excludes principal repayment")
	check(near(float(m.state.ledger.financing),-50) and near(float(m.state.ledger.expenses),94),"principal and accrued expense remain separate ledger kinds")
	check(f.validate_state(m.state.finance,int(m.state.total_minutes)),"real settled finance state passes strict save validation")
	var cash: float=float(m.state.cash)
	check(bool(f.settle_daily_charges().duplicate) and near(float(m.state.cash),cash),"duplicate day close does not double-charge")
	f.finish_day({"day":1,"duplicate":true})
	check(m.state.finance.bills.size()==1,"duplicate close does not duplicate bill")
	report=close_day(pair,2)
	check(near(float(report.interest_due),5.75),"day2 interest uses1150 remaining principal")
	report=close_day(pair,3)
	check(near(float(report.interest_due),5.5) and near(float(report.rent_utilities),0),"third game day remains protected")
	report=close_day(pair,4)
	check(not report.protected and near(float(report.minimum_due),100),"day4 restores normal100 principal minimum")
	check(near(float(report.rent),60) and near(float(report.utilities),20),"day4 debits rent60 and utilities20 separately")
	check(f.flows_by_day(4).any(func(flow):return str(flow.type)=="rent"),"real rent charge has reason and timestamp")
	check(f.recent_expense_composition().any(func(row):return str(row.type)=="debt_principal"),"7day cash spending includes principal cashout without confusing profit")
	check(f.export_csv(4).contains("房租") and not f.export_csv(4).contains("员工工资：\""),"CSV exports readable category labels")
	check(f.validate_state(m.state.finance,int(m.state.total_minutes)),"four-day billing finance remains save-valid")
	pair=fresh();m=pair.m;f=pair.f
	m.state.cash=0;m.state.finance.opening_cash=0
	report=close_day(pair,1)
	check(not report.overdue and int(m.state.overdue_count)==0,"protection shortage does not create debt overdue")
	check(not report.bankruptcy and not bool(m.state.finance.rescue.pending),"one unpaid day warns without premature bankruptcy")
	check(near(float(m.state.wage_arrears),88) and near(float(m.state.interest_arrears),6),"unpaid liabilities remain payable, not forgiven")
	report=close_day(pair,2)
	check(bool(report.bankruptcy) and m.paused,"second consecutive unresolved wage day forces paused rescue")
	check(not f.can_perform("loan_apply",{"amount":1000}).ok,"ordinary loan cannot bypass a forced rescue")
	var pending_liabilities=float(m.state.wage_arrears)+float(m.state.rent_arrears)+float(m.state.interest_arrears)
	var borrowed: Dictionary=m.full_rules.perform("emergency_accept",{"confirmed":true})
	check(borrowed.ok and near(float(m.state.cash),5000-pending_liabilities),"independent emergency loan supplies5000")
	check(not bool(m.state.finance.rescue.pending) and not m.paused,"emergency rescue clears pending and resumes operation")
	check(near(float(m.state.rescue171.loan.principal),5000) and int(m.state.rescue171.loan.due_day)==23,"emergency term20 days begins real borrowed day3")
	check(near(float(m.state.ledger.financing),5000),"rescue income is financing and never sales")
	check(f.validate_state(m.state.finance,int(m.state.total_minutes)),"emergency rescue leaves save-valid cash records")
	m.state.stage=1
	var old_expenses: float=float(m.state.ledger.expenses)
	check(m.full_rules.perform("emergency_repay",{"amount":400}).ok,"emergency loan accepts affordable partial principal")
	check(near(float(m.state.rescue171.loan.principal),4600),"partial repayment reduces emergency principal immediately")
	check(near(float(m.state.ledger.expenses),old_expenses),"loan principal repayment does not add an expense")
	m.state.cash=10000;m.state.finance.opening_cash=float(m.state.cash)
	report=close_day(pair,3)
	check(near(float(report.emergency_interest_due),92),"remaining4600 emergency principal uses2percent")
	check(near(float(report.interest_due),6),"original debt interest remains separate0.5percent")
	pair=fresh();m=pair.m;f=pair.f
	check(not f.can_perform("loan_apply",{"amount":1000}).ok,"normal stage0 cannot proactively borrow")
	m.state.stage=1;m.state.reputation=1000
	check(f.perform("loan_apply",{"amount":5000}).ok,"high reputation stage1 can borrow5000")
	check(int(m.state.finance.loan.due_day)==31,"normal loan expires30 game days after openingday1")
	m.state.cash=10000;m.state.finance.opening_cash=10000
	var rep: int=int(m.state.reputation)
	report=close_day(pair,31)
	check(bool(m.state.finance.loan.penalty_applied) and bool(m.state.finance.loan.collection_pending),"expired loan has persistent collection event notice")
	check(near(float(report.loan_fine),200) and int(m.state.reputation)==rep-30,"expired loan applies real200fine and reputation30 penalty")
	var expenses: float=float(m.state.ledger.expenses)
	report=close_day(pair,32)
	check(near(float(report.loan_fine),0) and int(m.state.reputation)==rep-30,"same expired loan is not fined every subsequent day")
	check(float(m.state.ledger.expenses)>expenses,"expired principal still generates daily noncompound interest")
	check(f.perform("loan_collection_ack").ok and not bool(m.state.finance.loan.collection_pending),"acknowledging collection does not erase the actual debt")
	check(near(float(m.state.finance.loan.principal),5000),"collection acknowledgment retains borrowed principal")
	check(not f.can_perform("loan_repay",{"amount":-5}).ok,"negative repayment rejected")
	check(not f.can_perform("loan_repay",{"amount":true}).ok,"boolean repayment rejected")
	check(not f.can_perform("loan_apply",{"amount":"1000"}).ok,"string loan amount rejected")
	pair=fresh();m=pair.m;f=pair.f
	var before: float=float(m.state.cash)
	f.cash_change(20,"event_income","来自\"访客\"的礼物,第一行\n第二行")
	check(near(float(m.state.cash),before+20),"unified finance cash mutation applies actual change")
	var flow: Dictionary=m.state.finance.flows.back()
	check(near(float(flow.balance)-float(flow.balance_before),20) and int(flow.minute)==int(m.state.total_minutes),"flow records amount and exact before/after balances")
	var csv: String=f.export_csv()
	check(csv.contains('"来自""访客""的礼物,第一行\n第二行"'),"CSV quotes commas, quotes and embedded newline correctly")
	f.cash_change(1,"event_income","=WEBSERVICE(\"https://example.invalid\")")
	check(f.export_csv().contains("'=WEBSERVICE"),"CSV user-visible labels cannot turn into spreadsheet formulas")
	var changed: Dictionary=m.state.finance.duplicate(true)
	changed.flows[0].balance+=1
	check(not f.validate_state(changed,int(m.state.total_minutes)),"reject forged flow balance mismatch")
	changed=m.state.finance.duplicate(true);changed.flows[0].minute+=100
	check(not f.validate_state(changed,int(m.state.total_minutes)),"reject future-timestamp flow")
	changed=m.state.finance.duplicate(true);changed.loan.principal=-1
	check(not f.validate_state(changed,int(m.state.total_minutes)),"reject negative loan principal")
	changed=m.state.finance.duplicate(true);changed.rescue.pending=true
	check(not f.validate_state(changed,int(m.state.total_minutes)),"reject unexplained pending rescue state")
	check(f.perform("bankruptcy_settle").ok and m.paused,"manual bankruptcy settlement opens forced rescue")
	check(f.perform("bankruptcy_restart").get("request_restart",false),"restart explicitly requests root soft reset; does not silently erase save")
	check(f.perform("bankruptcy_load").get("request_load",false),"load explicitly requests root safe load")
	var candidate: Dictionary={"cash":321,"total_minutes":14400,"ledger":{"sales":900,"expenses":100}}
	var migrated: Dictionary=f.default_state_for(candidate)
	check(near(float(migrated.opening_cash),321) and near(float(migrated.opening_ledger.sales),900),"legacy migration uses candidate cash and ledger, never current game")
	check(int(migrated.last_settled_day)==10,"legacy migration does not retrocharge already played days")
	check(f.validate_balance(f.balance_defaults()),"all finance config defaults satisfy bounds")
	var invalid: Dictionary={"finance.protection.minimum_repayment_multiplier":1.1}
	check(not f.validate_balance(invalid),"repayment protection multiplier cannot exceed1")
	check(not f.validate_balance({"finance.loan.daily_interest_rate":-1}),"negative loan interest rejected")
	check(not f.validate_balance({"finance.loan.active_limit":2}),"only one simultaneous loan supported")
	check(not f.validate_balance({"finance.history.flow_limit":0}),"flow retention cannot erase every cash record")
	check(not f.validate_balance({"finance.loan.tiers.medium.amount":500}),"loan amount tiers cannot invert")
	check(not f.validate_balance({"finance.bankruptcy.unpaid_days":1.5}),"unpaid-day threshold requires whole day")
	check(not f.validate_balance({"finance.unknown":1}),"unknown finance settings rejected")
	pair=fresh();m=pair.m;f=pair.f
	m.state.cash=-1;m.state.finance.opening_cash=-1
	report=close_day(pair,1)
	check(bool(report.bankruptcy) and m.paused,"negative cash triggers rescue only at day close")
	check(f.validate_state(m.state.finance,int(m.state.total_minutes)),"negative-cash rescue finance state remains save-valid")
	pair=fresh();m=pair.m;f=pair.f
	m.state.cash=1000;m.state.finance.opening_cash=1000
	m.state.wage_arrears=40;m.state.rent_arrears=20
	report=close_day(pair,1)
	check(not report.bankruptcy and int(m.state.finance.unpaid_days)==0,"affordable liabilities do not force an unnecessary rescue loan")
	check(near(float(m.state.wage_arrears),40),"affordable but unselected arrears are not silently erased")
	m.state.finance.daily_tips=3;m.state.finance.daily_sales_recorded=10
	changed=m.state.finance.duplicate(true);changed.bills[0].net_profit+=10
	check(not f.validate_state(changed,int(m.state.total_minutes)),"reject forged daily profit inconsistent with bill")
	changed=m.state.finance.duplicate(true);changed.bills[0].tips=float(changed.bills[0].revenue)+1
	check(not f.validate_state(changed,int(m.state.total_minutes)),"reject tip total larger than gross revenue")
	var candidate2: Dictionary={"cash":321,"total_minutes":14400,"ledger":{"sales":900,"expenses":100}}
	check(f.validate_state(f.default_state_for(candidate2),14400),"candidate-default migrated finance state is strictly valid")
	print("V1.5 FINANCE CHECKS: %d passed, %d failed"%[checks-failures,failures])
	quit(1 if failures else 0)
