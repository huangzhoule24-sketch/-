extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Map=preload("res://scripts/ui/dollhouse_view.gd")
const Space=preload("res://scripts/services/restaurant_space.gd")
class View extends RefCounted:
	var model
	var _actors: Dictionary={}
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func signature(entities: Array) -> Array:
	return entities.map(func(e):return [str(e.type),int(e.serial)])
func run():
	var model=Model.new(20261024);model.start_full()
	# Rendering fixture adds a four-seat table to exercise its front/rear chairs as well.
	model.state.layout.append({"id":"table_four","x":8,"y":4,"w":2,"h":2})
	model.state.seats+=4
	var view=View.new();view.model=model;var renderer=Map.new(view)
	var before=JSON.stringify(model.state);var rng=model._rng.state
	var seats=[]
	for seat in range(int(model.state.seats)):seats.append(Space.seat_position(model,seat))
	expect(seats.size()>1,"Real starting layout supplies multiple chairs")
	for seat in range(seats.size()):
		for state in ["ordering","queued","cooking","serving","eating","paying"]:
			for offset in [-.25,0.0,.25]:
				model.customers.clear()
				model.customers.append({"id":1,"seat":seat,"stage":state})
				# Staff pass behind, exactly level with, and in front of the chair.
				for employee in model.employees:view._actors[str(employee.id)]={"position":seats[seat]+Vector2(0,offset),"display_position":seats[seat]+Vector2(0,offset)}
				var entities=renderer.draw_entities();var chairs=[];var people=[]
				for i in range(entities.size()):
					if entities[i].type=="chair":chairs.append(i)
					if entities[i].type in ["staff","guest","leaving"]:people.append(i)
				expect(not chairs.is_empty() and not people.is_empty() and chairs.max()<people.min(),"Chairs cannot cover seated/passing bodies: seat%d %s delta%.2f" % [seat,state,offset])
				expect(signature(entities)==signature(renderer.draw_entities()),"Repeated frames retain equal-depth order")
	# Regression for unstable equal-Y sorting and ordinary table depth.
	var samples=[{"type":"guest","point":Vector2(0,100),"serial":3},{"type":"fixture","point":Vector2(0,100),"serial":0},{"type":"staff","point":Vector2(0,100),"serial":2},{"type":"staff","point":Vector2(0,100),"serial":1},{"type":"chair","point":Vector2(0,101),"serial":4}]
	samples.sort_custom(Map._draws_before)
	expect(samples.map(func(e):return e.serial)==[4,0,1,2,3],"Chair back pass and equal-depth bodies have a strict deterministic order")
	var near=[{"type":"guest","point":Vector2(0,99.75),"serial":0},{"type":"fixture","point":Vector2(0,100),"serial":1},{"type":"guest","point":Vector2(0,100.25),"serial":2}]
	near.sort_custom(Map._draws_before)
	expect(near.map(func(e):return e.serial)==[1,0,2],"Subpixel arrival offsets cannot flip a body underneath the same-depth table")
	var depth=[{"type":"staff","point":Vector2(0,120),"serial":0},{"type":"fixture","point":Vector2(0,100),"serial":1},{"type":"guest","point":Vector2(0,80),"serial":2}]
	depth.sort_custom(Map._draws_before)
	expect(depth.map(func(e):return e.serial)==[2,1,0],"Rear body/table/front body retain natural depth occlusion")
	model.customers.clear();model.state.revision191.departures.append({"id":99,"seat":0,"stage":"paying"})
	var leaving=renderer.draw_entities();var last_chair=-1;var departure=-1
	for i in range(leaving.size()):
		if leaving[i].type=="chair":last_chair=i
		if leaving[i].type=="leaving":departure=i
	expect(departure>last_chair,"Departing bodies remain above chairs")
	model.state.revision191.departures.clear()
	expect(model._rng.state==rng and JSON.stringify(model.state)==before,"Rendering order leaves game state and RNG unchanged")
	var report={"checks":checks,"failures":failures,"seats":seats.size(),"states":6,"boundary_offsets":3}
	FileAccess.open("res://build/seat-layer-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Seat layer: ",JSON.stringify(report));quit(1 if failures else 0)
