extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func _init() -> void:call_deferred("run")
func expect(ok: bool,message: String) -> void:
	checks+=1
	if not ok:failures+=1;push_error(message)
func fresh():
	var m=Model.new(171);m.start_full();m.full_rules.perform("daily_auto",{"enabled":false});return m
func guest(m,id: String) -> Dictionary:
	var c={"id":100+checks,"type":"special","arrival_minute":int(m.state.total_minutes),"seat":0,"stage":"ordering","quality":90.0,"paid":false,"preference_profile":{}}
	m.full_rules.customer_service.prepare_customer(c);m.full_rules.visitors.prepare(c,id);return c
func run() -> void:
	var m=fresh();var v=m.full_rules.visitors
	var c=guest(m,"old_gourmand")
	expect(not c.has("visitor_id"),"Gourmand cannot bypass stage and average-quality gate")
	c=guest(m,"baize_friend");var affinity=m.full_rules.sidequests.affinity("bai_ze")
	c.paid=true;v.paid(c)
	expect(m.full_rules.sidequests.affinity("bai_ze")==affinity+10,"Guide NPC receives real10 affinity for completed beverage visit")
	v.paid(c);expect(m.full_rules.sidequests.affinity("bai_ze")==affinity+10,"Paid callback cannot duplicate friend affinity")
	c=guest(m,"lost_cub");c.paid=true;v.paid(c)
	var fragments=0
	for n in m.state.fragments.values():fragments+=int(n)
	expect(v.s().adoptions.size()==1,"Cub rewards are pending adoption rather than automatically granted")
	expect(m.full_rules.perform("guest_adopt",{"serial":c.visit_serial}).ok,"Adoption is an explicit public action")
	var after=0
	for n in m.state.fragments.values():after+=int(n)
	expect(after==fragments+1 and not v.adopt(c.visit_serial).ok,"Adoption awards exactly one fragment once")
	m.state.reputation=300;c=guest(m,"picky_blogger")
	var before=int(m.state.reputation);var arrivals=int(m.state.customer_service.today.arrivals)
	for course in range(3):
		c.paid=true;c.quality=90;v.paid(c)
		if course<2:
			expect(int(m.state.reputation)==before and not c.visitor_done,"Critic delays aggregate review until all3 paid courses")
			expect(v.next_course(c) and c.stage=="ordering" and not c.paid,"Critic really returns to ordering, no fabricated next course")
	expect(m.state.reputation==before+50 and c.visitor_scores.size()==3,"Three good paid courses award one50 reputation review")
	expect(m.state.customer_service.today.arrivals==arrivals,"Three courses remain one visitor arrival")
	expect(not v.next_course(c),"Critic cannot order fourth course")
	for kind in ["serving","recommendation","goodbye","greeting"]:v.interact(c,m.employees[1],kind)
	expect(c.interaction_bubbles<=2,"Four actual interaction kinds produce at most2 speech bubbles per visit")
	m.state.stage=2;m.employees[0].loyalty=90;c=guest(m,"kunlun_spy");c.paid=true;v.paid(c)
	expect(m.pending_event().id=="kunlun_trouble" and m.pending_event().options.any(func(o):return o.id=="spy_counter"),"Loyal staff exposes actionable spy evidence")
	before=m.state.reputation
	expect(m.full_rules.world.choose("spy_counter").ok and m.state.reputation==before+20,"Spy reward is granted by the actual counter event choice")
	m.state.sidequests.pages=["xian_yang"];m.state.special_visitors.history[0].minute=int(m.state.total_minutes)
	m.restart_campaign_with_keepsakes()
	expect(m.state.sidequests.pages==["xian_yang"] and m.state.special_visitors.records.size()==4,"New run preserves Baize pages and special visitor collection")
	var save="/tmp/shanhai-v171-guests.json";var loaded=fresh()
	expect(m.save_game(save) and loaded.load_game(save),"Permanent guest history and Baize pages remain a valid restart save")
	m=fresh();m.state.stage=1;m.state.cash=5000
	expect(m.full_rules.finance.can_perform("loan_apply",{"amount":1000}).ok,"Initial unexpired1200 debt does not ban normal lending")
	m.full_rules.finance._trigger_rescue("fixture",1);m.full_rules.perform("rescue_decline")
	expect(m.state.rescue171.ended,"Declining emergency rescue forces run end")
	m=fresh();m.state.wage_arrears=6000;m.full_rules.finance._trigger_rescue("fixture",1);m.full_rules.perform("emergency_accept",{"confirmed":true})
	expect(m.state.rescue171.ended,"5000 rescue insufficient to settle payables forces run end")
	# End-to-end critic visit: every course must traverse actual arrival, cooking and payment.
	m=fresh();m.state.stage=2;m.state.reputation=300;m.state.cash=10000;m.balance["customer.base_flow"]=0;m.events.clear()
	for worker in m.employees:
		worker.attributes.speed=20;worker.attributes.endurance=20;worker.attributes.cooking=20
	m._spawn_customer("noodles",false);c=m.customers[0];c.type="special";m.full_rules.visitors.prepare(c,"picky_blogger")
	var midway=false
	for minute in range(700):
		m.advance_minutes(1)
		if not midway and c.visitor_scores.size()==1 and not c.visitor_done:
			midway=m.save_game(save) and loaded.load_game(save)
		if c.get("visitor_done",false):break
	expect(midway,"Actual critic between courses survives strict save/load")
	expect(c.get("visitor_done",false) and c.visitor_scores.size()==3 and int(m.state.served)==3,"Three critic courses actually traverse the live scheduler and checkout")
	expect(m.state.special_visitors.history.size()==1 and m.state.customer_service.today.arrivals==1,"Three real bills create one visit record and one arrival")
	# The grateful guest did not appear in the bounded natural campaign: test both gift branches separately.
	var saw_cash=false;var saw_ingredients=false;var gifts_valid=true
	for seed_value in range(171,187):
		m=Model.new(seed_value);m.start_full();m.state.cash=10000
		expect(not m.full_rules.visitors.eligible("grateful_monster"),"Thankful visitor requires a preceding act of help") if seed_value==171 else null
		m.full_rules.world._enqueue("low_mood",{"employee_id":str(m.employees[0].id)})
		m.full_rules.world.choose("bonus")
		gifts_valid=gifts_valid and m.full_rules.visitors.eligible("grateful_monster")
		c=guest(m,"grateful_monster");c.paid=true
		var cash_before=float(m.state.cash);var quantity_before=float(m.state.ingredients)
		m.full_rules.visitors.paid(c)
		var cash_delta=float(m.state.cash)-cash_before;var quantity_delta=float(m.state.ingredients)-quantity_before
		saw_cash=saw_cash or cash_delta==500;saw_ingredients=saw_ingredients or is_equal_approx(quantity_delta,2)
		gifts_valid=gifts_valid and ((cash_delta==500 and is_zero_approx(quantity_delta)) or (is_zero_approx(cash_delta) and is_equal_approx(quantity_delta,2)))
		cash_before=float(m.state.cash);quantity_before=float(m.state.ingredients);m.full_rules.visitors.paid(c)
		gifts_valid=gifts_valid and m.state.cash==cash_before and m.state.ingredients==quantity_before
	expect(gifts_valid and saw_cash and saw_ingredients,"Actual comfort choice unlocks grateful guest; both gift variants grant exactly one reward")
	m=fresh();m.state.stage=1;m.employees[0].attributes.cooking=20
	c=guest(m,"old_gourmand")
	expect(c.has("visitor_id") and m._dish(str(c.dish_id)).price==10,"Gourmand picks highest actual price after its quality gate")
	before=int(m.state.reputation);c.paid=true;c.quality=90;m.full_rules.visitors.paid(c)
	expect(m.state.reputation==before+30 and "gourmand_clue" in m.state.special_visitors.lore,"Gourmand good review unlocks real hidden-recipe lore")
	c=guest(m,"old_gourmand");before=int(m.state.reputation);c.paid=true;c.quality=50;m.full_rules.visitors.paid(c)
	expect(m.state.reputation==maxi(0,before-20),"Gourmand poor quality applies specified reputation loss")
	DirAccess.remove_absolute(save)
	print("V1.7.1 guests and finance: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
