extends SceneTree
const Assets=preload("res://scripts/services/asset_catalog.gd")
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func run():
	var assets=Assets.new();var model=Model.new(20261024);model.start_full();var rng=model._rng.state
	var catalog=JSON.parse_string(FileAccess.get_file_as_string("res://assets/art/art_catalog.json"))
	expect(catalog.employees.size()==30 and catalog.guests.size()==15,"Every employee and customer appearance has a rig")
	var groups=0;var frames=0
	for employee in model.catalog:
		expect(not assets.is_placeholder(assets.get_portrait(employee.id)),"Ink portrait exists "+str(employee.id))
		for action in ["walk","idle","order","cook","serve","clean","cashier","promote","rest","build"]:
			for direction in ["down","up","left","right"]:
				var sequence=assets.get_frames(employee.id,action,direction)
				expect(sequence.size()==8 and not assets.is_placeholder(sequence[0]),"Complete animation "+str(employee.id)+" "+action+" "+direction)
				groups+=1;frames+=sequence.size()
				for image in sequence:expect(image.get_size()==Vector2(64,80),"Stable canvas")
		var walk=assets.get_frames(employee.id,"walk","down")
		# The source head anchor is never translated by more than one pixel in the loop.
		var heads=[]
		for frame in walk:
			var image=frame.get_image();var top=80
			for y in range(40):
				for x in range(12,52):
					if image.get_pixel(x,y).a>.5:top=mini(top,y)
			heads.append(top)
		expect(heads.max()-heads.min()<=1,"Walk head displacement <=1px "+str(employee.id))
	for appearance in catalog.awakened:
		for action in ["walk","idle","order","cook","serve","clean","cashier","promote","rest","build"]:
			for direction in ["down","up","left","right"]:
				var sequence=assets.get_frames(appearance.id,action,direction)
				expect(sequence.size()==8 and not assets.is_placeholder(sequence[0]),"Awakened animation "+str(appearance.id));groups+=1;frames+=sequence.size()
	for guest in catalog.guests:
		for action in ["walk","idle","sit","eat"]:
			for direction in ["down","up","left","right"]:
				var sequence=assets.get_customer_frames(guest.kind,guest.id,action,direction)
				expect(sequence.size()==8 and not assets.is_placeholder(sequence[0]),"Guest complete "+str(guest.id)+" "+action+" "+direction);groups+=1;frames+=sequence.size()
	for path in catalog.assets:expect(assets.has_image(str(path).trim_suffix(".png")),"Imported image "+str(path))
	expect(groups==1800 and frames==14400,"Atlas group/frame counts match all requested action slots")
	expect(model._rng.state==rng,"Art inspection consumes no business randomness")
	var override_root="/tmp/art-override-"+str(Time.get_ticks_usec())
	var custom=Assets.new("res://assets/art",override_root)
	var solid=Image.create(64,80,false,Image.FORMAT_RGBA8);solid.fill(Color.GREEN)
	expect(custom.import_image(solid.save_png_to_buffer(),"Sprites/xian_yang/walk_down_0.png").ok,"Per-frame developer override imports")
	var merged=custom.get_frames("xian_yang","walk","down")
	expect(merged.size()==8 and merged[0].get_image().get_pixel(0,0)==Color.GREEN and merged[1] is AtlasTexture,"Partial override retains remaining atlas frames")
	var report={"checks":checks,"failures":failures,"employees":30,"awakened":catalog.awakened.size(),"customers":15,"groups":groups,"frames":frames,"png_files":catalog.assets.size()}
	FileAccess.open("res://build/art-pack-test.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Art pack: ",JSON.stringify(report));quit(1 if failures else 0)
