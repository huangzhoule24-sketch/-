extends SceneTree
const Model = preload("res://scripts/core/game_model.gd")
const Space = preload("res://scripts/services/restaurant_space.gd")
const Session = preload("res://scripts/ui/decoration_session.gd")
const Harness = preload("res://tests/ui_requirements_tests.gd").Harness
const Policy = preload("res://scripts/ui/interface_policy.gd")
var checks = 0
var failures = 0
func _init() -> void: call_deferred("run")
func expect(value: bool,message: String) -> void:
	checks += 1
	if not value: failures += 1;push_error(message)
func settle() -> void:
	for frame in range(5): await process_frame
func find(node: Node,id: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.get_meta("qa_id","")) == id: return node
	for child in node.get_children():
		var result = find(child,id)
		if result != null: return result
	return null
func cell_for(model,id: String) -> Vector2i:
	var dims = Space.grid_dimensions(model)
	for y in range(dims.y):
		for x in range(dims.x):
			if model.can_place_decoration(id,x,y): return Vector2i(x,y)
	return Vector2i(-1,-1)
func run() -> void:
	var m = Model.new(20261019)
	m.start_full()
	expect(m.speed == 2 and m.real_time_rate() == 6,"Full new game defaults to2x and six game minutes per second")
	for speed in range(1,5):
		m = Model.new(20261019);m.start_full();m.set_speed(speed)
		var minute = int(m.state.total_minutes)
		m.advance_real(1)
		expect(int(m.state.total_minutes) == minute+speed*3,"Actual1 second clock mapping at %dx" % speed)
		m.set_paused(true);m.advance_real(100)
		expect(int(m.state.total_minutes) == minute+speed*3,"Pause freezes %dx clock" % speed)
	m = Model.new(20261019);m.start_full();m.set_speed(4)
	var direct = Model.new(20261019);direct.start_full()
	m.advance_real(2);direct.advance_minutes(24)
	expect(m.state == direct.state and m.customers == direct.customers and m._rng.state == direct._rng.state,"Faster real mapping matches the same24 simulated minutes exactly")
	var save = "/tmp/shanhai-v16-speed.json"
	expect(m.save_game(save),"Four-speed game saves")
	var loaded = Model.new(1)
	expect(loaded.load_game(save) and loaded.speed == 4,"Four-speed save reloads")
	m.set_speed(3);m.save_game(save)
	expect(loaded.load_game(save) and loaded.speed == 3 and loaded.state.cash == m.state.cash,"Existing three-speed save keeps its speed and resources")
	DirAccess.remove_absolute(save)
	for boundary in [599,1439]:
		m = Model.new(20261019);m.start_full();m.set_speed(1)
		m.full_rules.perform("daily_auto",{"enabled":false});m.state.total_minutes = boundary;m.advance_real(1)
		expect(int(m.state.total_minutes) == boundary+3,"Full clock never auto-skips rest or closed periods")
	m = Model.new(20261019);m.start_full();m.set_speed(1)
	m.full_rules.perform("daily_auto",{"enabled":false})
	var day_start = int(m.state.total_minutes)
	m.advance_real(480)
	expect(int(m.state.total_minutes) == day_start+1440,"A full unpaused day takes exactly480 real seconds at1x")
	# Actual layout transactions: account entries, inventory and cash undo together.
	m = Model.new(20261019);m.start_full();m.state.stage = 1
	var session = Session.new(m);session.begin();session.builder_id="xiao"
	var original = m.state.duplicate(true)
	var rng_before = m._rng.state
	var scheduler_before = m.scheduler.duplicate(true)
	var cell = cell_for(m,"wall_mural")
	expect(cell.x >= 0 and session.purchase("wall_mural",cell.x,cell.y),"Real furniture purchase enters paused transaction")
	expect(m.state.cash < original.cash and m.state.ledger.capital > original.ledger.capital,"Preview purchase records actual cash and capital once")
	expect(session.undo() and m.state == original,"Undo restores cash, furniture, capped comfort, ledger and cash-flow IDs together")
	expect(m._rng.state == rng_before and m.scheduler == scheduler_before,"Decoration undo never rewinds RNG or in-flight tasks")
	expect(session.purchase("wall_mural",cell.x,cell.y),"Purchase can be repeated after undo")
	var charged = m.state.cash
	expect(session.finish(true) and m.state.cash == charged,"Completing commits without a second charge")
	session.begin()
	var baseline = m.state.duplicate(true)
	var moved = false
	for y in range(5):
		for x in range(8):
			if not moved and session.can_move(0,x,y) and (x != int(m.state.layout[0].x) or y != int(m.state.layout[0].y)):
				moved = session.move_item(0,x,y)
	expect(moved and m.state.cash == baseline.cash,"Existing furniture moves without purchase costs")
	session.finish(false)
	expect(m.state == baseline,"Discard restores the whole uncommitted layout transaction")
	# Late roster fixture checks authoritative reservations, not cosmetic counters.
	m = Model.new(20261019);m.start_full();m.state.stage = 4
	for config in m.catalog:
		if m.employees.size() >= 20: break
		if m._employee(str(config.id)).is_empty(): m.employees.append(m._create_employee(config))
	m.full_rules.ensure_state_defaults()
	for i in range(m.employees.size()):
		var target = m._motion_point(m.employees[i].motion.target)
		expect(target.is_finite(),"Finite reserved station: " + str(m.employees[i].id))
		for j in range(i):
			expect(target.distance_to(m._motion_point(m.employees[j].motion.target)) >= 43.9,"Distinct reserved workstations for different staff")
	var view = preload("res://scripts/ui/restaurant_view.gd").new()
	view.model = m;view.font = preload("res://assets/fonts/NotoSansSC.otf");view.size = Vector2(900,500)
	root.add_child(view);view.set_process(false)
	view._update_employee_animation(0);view._resolve_actor_spacing(0.1)
	var thoughts = preload("res://scripts/ui/actor_thoughts.gd").new(view)
	rng_before = m._rng.state;var state_before = m.state.duplicate(true)
	thoughts.update(0.1)
	expect(thoughts.bubbles.size() <= 3 and thoughts.bubbles.size()>0,"At most three compact state bubbles appear")
	expect(m._rng.state == rng_before and m.state == state_before,"Speech and local spacing never alter gameplay state or RNG")
	m.set_paused(true);var remaining = thoughts.bubbles[0].left;thoughts.update(10)
	expect(thoughts.bubbles[0].left == remaining,"Pause freezes thought lifetimes")
	expect(view._visual_delta(1) == 0,"Pause freezes animation")
	m.set_paused(false);m.set_speed(4)
	expect(is_equal_approx(view._visual_delta(0.25),3),"Animation follows the same4x real-time mapping")
	view.queue_free();await settle()
	# UI stage fixtures: hide future features and split repeated entry controls.
	root.size = Vector2i(1440,900)
	var ui = Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	await settle()
	for stage in range(5):
		ui.model.state.stage = stage;ui.refresh();ui.open_panel("更多");await settle()
		var visible: Array = []
		for name in ui.navigation_buttons:
			if name != "更多" and ui.navigation_buttons[name].visible: visible.append(name)
		expect(visible.size() <= 4 and visible.size() == Policy.navigation(stage).size(),"Stage%d has only its3/4 primary entries" % stage)
		var seen: Array = []
		for entry in Policy.more_entries(stage):
			expect(find(ui.modal_body,"full:open:"+str(entry.panel)) != null,"Available secondary feature has its one entry")
			expect(not str(entry.panel) in seen and not str(entry.panel) in Policy.navigation(stage).map(func(name):return Policy.destination(name)),"No duplicate bottom/More entry")
			seen.append(str(entry.panel))
		for target in ["研发","菜单定价","装修","会员计划","外卖服务","羁绊图鉴","分店管理","中央厨房","供应链","山海探索","厨神大赛","神兽觉醒","世界排行榜"]:
			if Policy.minimum_stage(target) > stage: expect(find(ui.modal_body,"full:open:"+target) == null,"Future feature is absent: "+target)
	# Old stage lessons replay against today's navigation, including relocated entries.
	var guide = preload("res://scripts/core/tutorial_progress.gd")
	for stage in range(1,5):
		ui.model.state.stage = stage;ui.refresh();ui.close_panel();await settle()
		for step in guide.config().stage_steps:
			if int(step.stage) > stage: continue
			ui.model.state.tutorial.deferred = guide.config().stage_steps.map(func(item):return item.id).filter(func(id):return id != step.id)
			ui.tutorial_overlay.poll(0)
			var target = ui.tutorial_overlay.highlight_rect
			var expected = "更多"
			for name in Policy.navigation(stage):
				if Policy.destination(str(name)) == Policy.destination(str(step.destination)): expected = str(name)
			expect(target == ui.navigation_buttons[expected].get_global_rect().grow(5),"Replay %s highlights a visible and correct stage%d entry" % [step.id,stage])
	ui.model.state.tutorial.deferred = guide.config().stage_steps.map(func(step):return step.id)
	ui.model.state.stage = 0;ui.open_panel("员工");await settle()
	expect(find(ui.modal_body,"hire:normal") == null,"Staff roster contains no duplicate recruitment controls")
	ui.open_panel("招聘");await settle()
	expect(find(ui.modal_body,"hire:normal") != null and find(ui.modal_body,"culture:employees:xian_yang") == null,"Recruitment has hiring controls and no duplicate roster")
	ui.model.state.stage = 1;ui.open_panel("装修");await settle()
	expect(ui.decoration_active() and ui.decoration_footer.is_visible_in_tree() and ui.model.paused,"Decoration keeps persistent completion controls and pauses business")
	expect(ui.drawer_slot.get_global_rect().encloses(ui.decoration_footer.get_global_rect()),"Completion footer fits inside the clipped drawer, rather than below it")
	var cash_start = ui.model.state.cash
	ui.decoration_session.builder_id=str(ui.model.employees.filter(func(e):return ui.model.full_rules.revision.builder_available(e))[0].id)
	ui.begin_placement("wall_mural")
	var ui_cell = cell_for(ui.model,"wall_mural")
	var local_point = ui.map_view._to_view(Space.cell_rect(ui.model,ui_cell.x,ui_cell.y).get_center())
	var event = InputEventMouseButton.new()
	event.position = local_point+ui.map_view.global_position
	event.button_index = MOUSE_BUTTON_LEFT;event.pressed = true
	ui._input(event)
	expect(not is_instance_valid(ui._decoration_dialog),"Map placement never triggers an outside-click exit confirmation")
	ui.map_view._request_placement(local_point)
	await settle()
	expect(ui.model.state.cash < cash_start and ui.decoration_session.history.size() == 1,"Actual map placement signal purchases exactly one item inside the session")
	ui.undo_decoration();await settle()
	expect(ui.model.state.cash == cash_start,"Actual drawer undo restores the purchase cash")
	var start_minute = ui.model.state.total_minutes
	ui._process(0.2)
	expect(ui.model.state.total_minutes == start_minute,"UI clock stays frozen throughout decoration transaction")
	ui.close_panel();await settle()
	expect(is_instance_valid(ui._decoration_dialog) and ui.decoration_active(),"Exit opens a confirmation without losing the session")
	ui._decoration_dialog.canceled.emit();await settle()
	expect(ui.decoration_active() and ui.panel_name == "装修","Continue keeps the same layout session")
	ui.finish_decoration(false);await settle()
	expect(not ui.decoration_active() and ui.panel_name.is_empty(),"Explicit finish/discard leaves decoration normally")
	ui.queue_free();await process_frame
	print("V1.6 experience checks: %d; failures: %d" % [checks,failures])
	quit(1 if failures else 0)
