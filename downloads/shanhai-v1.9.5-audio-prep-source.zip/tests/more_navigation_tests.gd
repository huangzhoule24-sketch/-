extends SceneTree
## UI-only stage fixtures exercise actual controls, never campaign progression.
const Harness = preload("res://tests/ui_requirements_tests.gd").Harness
var checks = 0
var failures = 0

func _init() -> void: call_deferred("run")
func expect(value: bool,message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(message)
func find(node: Node,id: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.get_meta("qa_id","")) == id: return node
	for child in node.get_children():
		var result = find(child,id)
		if result != null: return result
	return null
func settle() -> void:
	for frame in range(6): await process_frame
func press(ui,id: String) -> void:
	var control = find(ui,id)
	expect(control != null and not control.disabled,"Enabled control: " + id)
	if control != null and not control.disabled: control.pressed.emit()
	await settle()
func run() -> void:
	var ui = Harness.new()
	root.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.story_panel = preload("res://scripts/ui/story_panel.gd").new(ui)
	await settle()
	for screen in [Vector2i(1440,900),Vector2i(844,390)]:
		root.size = screen
		ui.queue_ui_layout()
		ui.model.state.stage = 0 if screen.x == 1440 else 4
		await settle()
		ui.close_panel(false)
		ui.model.set_paused(false)
		ui.open_panel("更多")
		await settle()
		var branches = ui.Policy.more_entries(int(ui.model.state.stage)).map(func(entry):return str(entry.panel))
		var cash = ui.model.state.cash
		var minute = ui.model.state.total_minutes
		for name in branches:
			ui.modal_body.get_parent().scroll_vertical = 120
			await settle()
			var prior_scroll = ui.modal_body.get_parent().scroll_vertical
			await press(ui,"full:open:" + name)
			expect(ui.panel_name == name and ui._panel_back.is_visible_in_tree(),"Branch exposes its fixed header return: " + name)
			expect(ui._panel_back.size.y >= 44 and ui.modal_window.get_global_rect().encloses(ui._panel_back.get_global_rect()),"Return remains a visible44px target: " + name)
			if ui.decoration_active():
				await press(ui,"panel:back")
				ui._decoration_dialog.confirmed.emit()
				await settle()
			else:
				await press(ui,"panel:back")
			expect(ui.panel_name == "更多" and ui.modal_body.get_parent().scroll_vertical == prior_scroll,"Return restores More and its scroll: " + name)
			expect(ui.model.paused and ui.model.state.cash == cash and ui.model.state.total_minutes == minute,"Return preserves paused simulation and resources: " + name)
		ui.close_panel()
		expect(not ui.model.paused and ui._more_history.is_empty(),"Closing the route resumes its original running state")
	ui.open_panel("更多")
	await press(ui,"nav:分店")
	await press(ui,"full:open:山海探索")
	await press(ui,"panel:back")
	expect(ui.panel_name == "分店管理","Nested exploration returns to its actual parent")
	await press(ui,"panel:back")
	expect(ui.panel_name == "更多","Second return reaches More")
	await press(ui,"full:open:账单")
	await press(ui,"finance:tab:资金流水")
	var prior_depth = ui._more_history.size()
	ui.open_panel("资金流水")
	await settle()
	expect(ui._more_history.size() == prior_depth,"Refreshing a financial panel creates no extra back step")
	await press(ui,"finance:tab:账单")
	await press(ui,"panel:back")
	expect(ui.panel_name == "更多","Tab revisits unwind instead of creating a navigation loop")
	await press(ui,"full:open:员工培养")
	await press(ui,"culture:employees:xian_yang")
	expect(not ui._panel_back.visible and ui._culture_back.visible,"Culture retains its single original return button")
	await press(ui,"culture:back")
	expect(ui.panel_name == "员工培养","Culture returns to training within the More route")
	await press(ui,"panel:back")
	expect(ui.panel_name == "更多","Culture round trip preserves the More parent")
	await press(ui,"full:open:库存供应")
	ui.toggle_panel("更多")
	await settle()
	expect(ui._more_history.is_empty() and ui.panel_name == "更多","Bottom navigation clears the old submenu route")
	ui.close_panel(false)
	# Required-guide fixture must not acquire a new skip route.
	ui.model.start_full()
	ui.model.state.tutorial.completed_steps = ["welcome"]
	ui.tutorial_overlay.poll(0)
	ui.open_panel("招聘")
	await settle()
	expect(ui._panel_back.visible and ui._panel_back.disabled,"Required staff guide keeps the unavailable More return disabled")
	ui.return_to_parent_panel()
	expect(ui.panel_name == "招聘" and not ui.model.state.tutorial.finished,"Return cannot bypass mandatory teaching")
	ui.model.state.finance.rescue.pending = true
	ui.open_panel("更多")
	ui.return_to_parent_panel()
	expect(ui.panel_name == "破产救援" and not ui._panel_back.visible,"Forced rescue cannot be left through the new return route")
	ui.queue_free()
	await process_frame
	print("More navigation checks: %d; failures: %d" % [checks,failures])
	quit(1 if failures else 0)
