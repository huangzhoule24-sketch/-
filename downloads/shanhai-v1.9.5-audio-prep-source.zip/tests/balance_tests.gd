extends SceneTree
## Module defaults, invalid hot edits, and actual late-game cost/timing consumers.

const Registry = preload("res://scripts/core/balance_registry.gd")
const Expansion = preload("res://scripts/core/expansion_rules.gd")
var checks := 0
var failures := 0

class Host extends RefCounted:
	var balance: Dictionary = {}
	var state := {"total_minutes": 360, "cash": 10000.0, "gems": 30, "stage": 3, "served": 0}
	var employees: Array = []
	func _log(_message: String) -> void: pass
	func change_cash(delta: float, _category: String, _description: String) -> float:
		state.cash = float(state.cash) + delta
		return delta


func expect(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		printerr("FAIL: ", label)


func defaults_test() -> void:
	var values := Registry.defaults()
	var existing: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/global_balance.json"))
	for key in existing: expect(values.get(key) == existing[key], "explicit global value retained: " + key)
	var events: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/event_balance.json"))
	for key in events: expect(values.has(key), "event default exposed: " + key)
	expect(values == Registry.defaults(), "numeric registry is reproducible")
	expect(Registry.validate(values), "complete documented defaults validate")
	expect(values.has("coeff.calculation_cashier_speed"), "cross-system attribute coefficients included")
	expect(values.has("coeff.charm_price") and values.has("coeff.eloquence_price") and values.has("coeff.charm_tip"), "price and tip attribute coefficients included")
	expect(values.has("management.costs.training"), "management actual hot fields included")
	expect(not values.has("management.initial.auto_procure"), "boolean controls excluded from numeric table")
	expect(not values.has("animation.version"), "schema versions excluded")
	expect(float(values["initial.cash"]) == 800 and float(values["initial.gems"]) == 0, "v1.5 new-game economy is800 without extra gems")
	for key in ["finance.protection.days", "finance.loan.daily_interest_rate", "service.price.global_bonus_cap", "service.price.customer_multiplier_cap", "coeff.out_of_stock_mood_penalty", "coeff.bond_water_quality", "coeff.counter_dev_penalty", "sidequests.affinity_max"]:
		expect(values.has(key), "v1.5 registered default: " + key)
	expect(values["coeff.out_of_stock_mood_penalty"] == -10 and values["coeff.counter_dev_penalty"] == -0.15, "signed penalties remain signed and valid")
	var staff: Array = JSON.parse_string(FileAccess.get_file_as_string("res://config/employees.json"))
	for employee in staff:
		if employee.id == "feng_huang":
			for attribute in employee.attributes: expect(employee.attributes[attribute] == 8, "new Phoenix exact attribute: " + str(attribute))
	expect(values.has("animation.move.minimum") and values.has("expansion.branches.human_east.cost"), "nested numeric fields exposed")
	expect(values.has("full.milestones.opening.cash") and values.has("expansion.exploration.rewards.0.items.danmu"), "stable ID and indexed reward fields exposed")


func overlay_test() -> void:
	var source := {"title": "unchanged", "enabled": true, "cost": 10, "entries": [{"id": "first", "amount": 3}], "weights": [2, 4]}
	var before: Dictionary = source.duplicate(true)
	var values := {"test.cost": 12.5, "test.title": 99, "test.enabled": 0, "test.entries.first.amount": 8, "test.weights.1": 9}
	var result: Dictionary = Registry.overlay(source, "test", values)
	expect(result.cost == 12.5 and result.entries[0].amount == 8 and result.weights[1] == 9, "numeric overlay resolves dicts and arrays")
	expect(result.title == "unchanged" and result.enabled == true, "strings and booleans cannot be overwritten by numeric knobs")
	expect(source == before, "runtime overlay preserves source module config")
	result.entries[0].amount = 200
	expect(source.entries[0].amount == 3, "runtime overlay returns a deep copy")
	var flat := Registry.flatten(source, "test")
	expect(flat.has("test.entries.first.amount") and flat.has("test.weights.0"), "flattener matches runtime paths")
	expect(not flat.has("test.enabled") and not flat.has("test.title"), "flattener excludes nonnumeric values")


func validation_test() -> void:
	for edit in [
		{"expansion.branches.human_east.cost": -1},
		{"expansion.membership.setup_cost": -1},
		{"expansion.delivery.offer_interval": 0},
		{"events.random_interval": 0},
		{"events.bifang_fire_probability": 1.1},
		{"expansion.delivery.commission": 1.01},
		{"expansion.membership.voucher_discount": 1},
		{"expansion.delivery.capacity": 1.5},
		{"expansion.central.stage": 5},
		{"animation.move.minimum": 3, "animation.move.maximum": 2},
		{"animation.transition_seconds": 0},
		{"animation.mood.threshold": 101},
		{"management.costs.training": -1},
		{"expansion.no_such_field": 5},
		{"expansion.delivery.capacity": true},
		{"events.default_probability": INF},
		{"finance.protection.days": -1},
		{"finance.loan.daily_interest_rate": 1.1},
		{"finance.loan.term_days": 1.5},
		{"finance.loan.active_limit": 2},
		{"finance.loan.no_such_field": 1},
		{"recommend.cooldown_minutes": 1.5},
		{"recommend.base_chance": 0.9, "recommend.max_chance": 0.8},
		{"recommend.eloquence_bonus": 1.1},
		{"recommend.no_such_field": 1},
		{"service.feedback.history_limit": 1.5},
		{"service.feedback.stockout_daily_threshold": 2.5},
		{"service.feedback.stockout_traffic_decay": -1},
		{"service.price.global_bonus_cap": 1.1},
		{"service.price.customer_multiplier_cap": 8.1},
		{"service.price.quality_poor": 1.4},
		{"service.no_such_field": 1},
		{"sidequests.affinity_final": 101},
		{"sidequests.affinity_second": 95, "sidequests.affinity_final": 90},
		{"sidequests.no_such_field": 1},
		{"coeff.counter_dev_penalty": -1.1},
		{"events.inspection_prepared_base_pass": 1.1}
	]: expect(not Registry.validate(edit), "invalid edit rejected: " + str(edit))
	expect(Registry.validate({"events.weather_rain_traffic": -0.2, "expansion.membership.setup_cost": 0, "animation.frames_per_second": 12.5}), "signed weather, free cost and fractional FPS are valid")
	expect(Registry.validate({"expansion.delivery.commission": 0.3, "expansion.branches.human_east.cost": 25.5}), "valid financial tuning accepted")
	expect(Registry.validate({"events.taotie_saving":-0.05, "events.tiangou_panic":-0.2, "events.risk_probability_multiplier":2.0}), "signed v1.5 event effects and probability multipliers are distinct")
	expect(Registry.validate({"finance.protection.days":0, "service.feedback.stockout_traffic_decay":-0.1, "coeff.counter_dev_penalty":-0.25}), "valid v1.5 financial, recommendation and signed-effect tuning accepted")


func runtime_test() -> void:
	var host := Host.new()
	var rules := Expansion.new(host)
	rules.ensure_state()
	host.balance["expansion.membership.setup_cost"] = 77.5
	expect(bool(rules.perform("membership_enable").ok), "membership available with hot cost")
	expect(float(host.state.cash) == 9922.5, "membership charges the hot cost")
	host.balance["expansion.membership.points_per_order"] = 9
	host.state.served = 2
	rules._tick_membership()
	expect(int(host.state.expansion.membership.points) == 18, "membership points read hot value")
	host.balance["expansion.membership.voucher_discount"] = 0.2
	host.state.expansion.membership.voucher = true
	expect(rules.checkout_adjustment(100) == 80, "voucher changes actual checkout")
	host.balance["expansion.branches.human_east.cost"] = 33.5
	host.balance["expansion.branches.human_east.order_minutes"] = 7
	var cash := float(host.state.cash)
	expect(bool(rules.perform("branch_open", {"id": "human_east"}).ok), "branch opens from stable ID override")
	expect(float(host.state.cash) == cash - 33.5 and int(host.state.expansion.branches.human_east.next_order) == 367, "branch uses hot capital and timing")
	expect(float(rules.config.branches[0].cost) == 4000, "hot branch edit leaves source untouched")
	host.balance["expansion.exploration.rewards.0.items.danmu"] = 11
	expect(rules._section("exploration").rewards[0].items.danmu == 11, "nested exploration rewards resolve live")
	host.balance["expansion.central.stage"] = 4
	expect(not bool(rules.can_perform("central_unlock").ok), "configured stage gate changes actual availability")
	host.state.stage = 4
	host.balance["expansion.central.unlock_cost"] = 5
	expect(bool(rules.perform("central_unlock").ok), "hot central gate and cost apply without reload")


func _initialize() -> void:
	defaults_test()
	overlay_test()
	validation_test()
	alias_test()
	runtime_test()
	if failures == 0: print("balance_tests: %d checks passed" % checks)
	else: printerr("balance_tests: %d failures / %d checks" % [failures, checks])
	quit(0 if failures == 0 else 1)


func alias_test() -> void:
	var original={"service.feedback.out_of_stock_mood_penalty":-12,"unchanged":3}
	var edits=Registry.normalize_overrides(original)
	expect(edits.get("coeff.out_of_stock_mood_penalty")==-12,"signed stockout alias updates canonical coefficient")
	expect(not original.has("coeff.out_of_stock_mood_penalty") and edits.unchanged==3,"normalization preserves its input")
	expect(not Registry.validate({"recommend.base_chance":.5}),"retired recommendation tuning cannot become a live coefficient")
