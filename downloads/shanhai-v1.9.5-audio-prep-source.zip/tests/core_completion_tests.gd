extends SceneTree
const Model = preload("res://scripts/core/game_model.gd")
var checks: int = 0
var failures: int = 0
func check(value: bool, message: String) -> void:
 checks += 1
 if not value: failures += 1; push_error(message)
func near(a: float,b: float) -> bool: return absf(a-b)<0.001
func fresh():
 var m=Model.new(172026)
 m.start_full()
 m.balance["customer.base_flow"]=0
 m.balance["customer.tip_chance"]=0
 m.balance["coeff.charm_tip"]=0
 m.balance["customer.escape_probability"]=0
 m.events.clear()
 return m
func _init(): call_deferred("run")
func run():
 var m=fresh()
 check(m.employees.all(func(e):return e.has("motion")),"new campaign has authoritative initial motion")
 var e: Dictionary=m.employees[0]
 var p0: Vector2=m.motion_position(e)
 var p1: Vector2=m.motion_position(e,float(m.state.total_minutes)+0.1)
 check(p0.distance_to(p1)<=float(e.motion.speed)*0.1+0.01,"initial motion respects configured speed")
 check(m.save_game("user://complete-motion.json"),"save initial travel")
 var loaded=Model.new(8)
 check(loaded.load_game("user://complete-motion.json"),"load initial travel")
 check(loaded.motion_position(loaded.employees[0]).distance_to(p0)<0.001,"saved motion does not teleport")
 m=fresh();m.state.cash=0;m.state.total_minutes=5760;m._settle_day()
 var owed: float=float(m.state.interest_arrears)+float(m.state.wage_arrears)+float(m.state.rent_arrears)
 check(near(owed,174),"unpaid interest wages and rent create actual liabilities")
 var expense: float=float(m.state.ledger.expenses)
 var debt: float=float(m.state.debt)
 m.state.cash=100
 var paid: Dictionary=m.full_rules.perform("settle_arrears")
 check(paid.ok and near(float(paid.paid),100) and near(float(paid.remaining),74),"cash shortage partially settles liabilities in order")
 check(near(float(m.state.cash),0) and near(float(m.state.interest_arrears),0),"settlement does not create negative cash and clears interest first")
 m.state.cash=500
 paid=m.full_rules.perform("settle_arrears")
 check(paid.ok and near(float(paid.paid),74),"remaining arrears can be fully settled")
 check(near(float(m.state.ledger.expenses),expense) and near(float(m.state.debt),debt),"liability settlement never double-books expense or repays principal")
 check(not m.full_rules.perform("settle_arrears").ok,"cannot claim duplicate arrears payment")
 m=fresh();m.state.cash=5000;m.state.gems=20
 var pixiu: Dictionary=m._create_employee(m._employee_config("pi_xiu"));pixiu.resting=true;m.employees.append(pixiu)
 check(near(float(m.full_rules.can_perform("recruit",{"kind":"normal"}).cost),210),"resting Pixiu in store affects normal recruitment quote")
 check(near(float(m.full_rules.can_perform("recruit",{"kind":"advanced"}).cost),6),"Pixiu affects advanced gem recruitment quote")
 var gems: int=int(m.state.gems)
 check(m.full_rules.perform("recruit",{"kind":"advanced"}).ok and gems-int(m.state.gems)==6,"actual advanced recruitment charges quoted amount")
 var stock: float=float(m.full_rules.management.item("generic").quantity)
 check(m.buy_ingredients(10),"main sidebar ingredient purchase reaches actual purchase API")
 check(near(float(m.full_rules.management.item("generic").quantity),stock+10),"sidebar purchase changes real inventory")
 m=fresh();m.balance["dish.qiongqi_hotpot.quality"]=80;m.balance["prototype.quality_per_cooking_point"]=0
 m.state.price_bonus=0.2
 m.state.unlocked_dishes.append("qiongqi_hotpot");m.state.menu_enabled=["qiongqi_hotpot"]
 for id in m.full_rules.management.recipe("qiongqi_hotpot"):
  var record: Dictionary=m.full_rules.management.item(str(id))
  record.quantity=100;record.value=100*float(m.full_rules.management._ingredient(str(id)).price)
 m.full_rules.management._sync_totals()
 for employee in m.employees:
  if str(employee.role)=="waiter": employee.attributes.charm=5;employee.attributes.eloquence=0
 m._spawn_customer("qiongqi_hotpot",false)
 check(m.customers.size()==1,"controlled real order spawned")
 m.customers[0].type="human"
 var raw_seen: bool=false
 for minute in range(160):
  m.advance_minutes(1)
  if not m.customers.is_empty() and bool(m.customers[0].ingredients_reserved):
   raw_seen=raw_seen or near(float(m.customers[0].price),70)
  if int(m.state.served)>0:break
 check(raw_seen,"v1.5 provisional quote floors each stage before actual cashier attributes")
 check(int(m.state.served)==1 and near(float(m.state.total_revenue),70),"v1.9.3 real sale floors each remaining step:52→59 quality→70 global without personal premium")
 check(m.save_game("user://complete-price.json") and loaded.load_game("user://complete-price.json"),"v1.5 price breakdown roundtrips with actual order state")
 m=fresh();m.balance["coeff.jiuying_batch"]=4
 var jiuying: Dictionary=m._create_employee(m._employee_config("jiu_ying"));m.employees.append(jiuying)
 check(int(m.balance["coeff.jiuying_batch"])==4,"parallel capacity remains a configured value")
 check(not m.full_rules.effects.ignores_obstacles(jiuying,m._dish("noodles"),"cooking"),"unrelated cook does not inherit service obstacle immunity")
 var dijiang: Dictionary=m._create_employee(m._employee_config("di_jiang"))
 check(m.full_rules.effects.ignores_obstacles(dijiang,m._dish("noodles"),"serving"),"Dijiang ignores obstacles while serving")
 check(not m.full_rules.effects.ignores_obstacles(dijiang,m._dish("noodles"),"cooking"),"Dijiang does not apply service immunity to kitchen travel")
 check(not m.full_rules.effects.ignores_obstacles(dijiang,m._dish("noodles"),"ordering"),"Dijiang personal skill is scoped to dish serving")
 m=fresh();m.state.cash=5000
 m.state.layout.append({"id":"stove","x":13,"y":0,"w":1,"h":1})
 m.state.unlocked_dishes.append("jiuying_platter");m.state.menu_enabled=["jiuying_platter"]
 for id in m.full_rules.management.recipe("jiuying_platter"):
  var record: Dictionary=m.full_rules.management.item(str(id))
  record.quantity=100;record.value=100*float(m.full_rules.management._ingredient(str(id)).price)
 m.full_rules.management._sync_totals()
 m._spawn_customer("jiuying_platter")
 check(m.customers.size()==3,"platter creates a party with three actual portion orders")
 var party: int=int(m.customers[0].get("group_id",-1))
 check(m.customers.all(func(c):return int(c.get("group_id",-2))==party and int(c.group_size)==3 and bool(c.group_parallel)),"three portions belong to one explicit party")
 var simultaneous: bool=false
 for minute in range(120):
  m.advance_minutes(1)
  var cooking: Array=m.customers.filter(func(c):return str(c.stage)=="cooking" and int(c.due_minute)>0)
  if cooking.size()==3:
   simultaneous=cooking.all(func(c):return int(c.due_minute)==int(cooking[0].due_minute) and str(c.worker)==str(cooking[0].worker))
   check(m.save_game("user://complete-party.json") and loaded.load_game("user://complete-party.json"),"three simultaneous portions preserve valid worker references across save/load")
   break
 check(simultaneous,"platter portions cook in the same batch and finish together")
 print("CORE COMPLETION CHECKS: %d passed, %d failed"%[checks-failures,failures])
 quit(1 if failures else 0)
