extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Space=preload("res://scripts/services/restaurant_space.gd")
const Grid=preload("res://scripts/services/dollhouse_navigation.gd")
const Geometry=preload("res://scripts/services/grid_navigation.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,description: String):
	checks+=1
	if not ok:failures+=1;push_error(description)
func game(ids: Array=[]):
	var m=Model.new(20261021);m.start_full();m.events.clear();m.balance["customer.base_flow"]=0;m.state.stage=1;m.state.cash=10000
	if not ids.is_empty():
		m.employees.clear()
		for id in ids:m.employees.append(m._create_employee(m._employee_config(id)))
	m.full_rules.ensure_state_defaults()
	m.full_rules.management.purchase("generic",200)
	return m
func queue(m,count: int):
	for i in range(count):
		m._spawn_customer("noodles",false);var c=m.customers.back();c.stage="queued";c.arrival_due=0;c.order_decided=true;c.recommendation_done=true
func run():
	var m=game();var d=m.full_rules.dollhouse
	expect(d.fixtures("stove").size()==2 and d.fixtures("cashier").size()==1 and d.fixtures("pass").size()==1,"Initial real double stove, cashier and pass exist")
	expect(m.state.seats==8 and d.fixtures("table").size()==4,"Four initial table slots still mean eight seats")
	m=game(["xian_yang","bi_fang","tao_tie","xiao"]);d=m.full_rules.dollhouse;queue(m,3);m._assign_tasks()
	var cooking=m.customers.filter(func(c):return str(c.stage)=="cooking" and not str(c.worker).is_empty())
	expect(cooking.size()==2,"Three chefs cannot exceed two installed stoves")
	expect(cooking.size()==2 and cooking[0].device_uid!=cooking[1].device_uid,"Parallel cooks reserve different real equipment")
	expect(m.customers.any(func(c):return str(c.stage)=="queued" and c.worker==""),"A third order waits without consuming its ingredient reservation")
	expect(cooking.any(func(c):return str(c.worker)=="tao_tie"),"Dispatcher prioritises highest cooking attribute")
	for c in cooking:
		var motion=c.task_motion;expect(motion.travel_minutes>0 and motion.work_minutes>0,"Task includes actual travel then work")
		var worker=m._employee(str(c.worker));expect(m.motion_position(worker).distance_to(m._motion_point(motion.target))>1,"Normal chef has no arrival teleport")
	var path="/tmp/shanhai-v191-rules.json";var rng=m._rng.state
	expect(m.save_game(path),"Active equipment jobs save")
	var copy=game();expect(copy.load_game(path) and copy._rng.state==rng,"Active equipment jobs load with unchanged RNG")
	expect(copy.customers[0].get("device_uid")==m.customers[0].get("device_uid"),"Equipment reservation survives roundtrip")
	# A trained secondary profession participates without switching the role tag.
	m=game(["xiao"]);var employee=m.employees[0];employee.secondary_role="chef";employee.attributes.cooking=10;queue(m,1);m._assign_tasks()
	expect(str(m.customers[0].worker)=="xiao" and employee.role=="waiter","Secondary chef actually cooks while preserving primary role")
	# Jiuying requires three actual stoves for its three simultaneous jobs.
	m=game(["jiu_ying","xiao"]);queue(m,3);m._assign_tasks();expect(m._worker_task_count("jiu_ying")==2,"Jiuying cannot conjure a third stove")
	m=game(["jiu_ying","xiao"]);m.state.layout.append({"id":"stove","x":13,"y":0,"w":1,"h":1});queue(m,3);m._assign_tasks()
	expect(m._worker_task_count("jiu_ying")==3,"A third real stove enables Jiuying triple cooking")
	# Dijiang's serving-only exception teleports; other tasks still have routes.
	m=game(["di_jiang","xian_yang"]);queue(m,1);var c=m.customers[0];c.stage="serving";c.ingredients_reserved=true;c.quality=80;c.price=8
	m._assign_tasks();expect(c.task_motion.get("teleport",false) and c.task_motion.travel_minutes==0,"Dijiang serving skips only travel")
	expect(m.motion_position(m._employee("di_jiang")).is_equal_approx(m._motion_point(c.task_motion.target)),"Dijiang reaches serving station instantly by explicit ability")
	# New orthogonal navigation detours deterministically and uses its route cache.
	var walls: Array=[Rect2(80,40,40,130)];var route=Grid.find_path(Vector2(20,100),Vector2(180,100),walls,Rect2(0,0,220,220))
	expect(not route.blocked and route.points.size()>=3,"Grid route finds a real detour")
	var previous=Vector2(20,100)
	for point in route.points:expect(Geometry.segment_is_clear(previous,point,walls.map(func(w):return w.grow(4))),"Every grid segment avoids physical equipment");previous=point
	var searches=Grid.searches;Grid.find_path(Vector2(20,100),Vector2(180,100),walls,Rect2(0,0,220,220));expect(Grid.searches==searches,"Identical task route is cached rather than recomputed each frame")
	# Actual secondary training unlocks equipment without changing the main tag.
	m=game(["xiao","xian_yang"]);var opening_cash=m.state.cash
	expect(m.full_rules.perform("train_secondary",{"employee_id":"xiao","role":"chef"}).ok,"Secondary profession starts through the paid public action")
	m.advance_minutes(241)
	expect(m._employee("xiao").secondary_role=="chef" and m._employee("xiao").role=="waiter" and m.state.cash<opening_cash,"Training completes and preserves main profession")
	# Rest furniture occupies one real station and grants its specified gain only on arrival.
	m=game(["xiao","xian_yang"]);d=m.full_rules.dollhouse;m.state.layout.append({"id":"staff_corner","x":15,"y":3,"w":1,"h":1})
	m.set_employee_rest("xiao",true);m.advance_minutes(12);employee=m._employee("xiao");employee.stamina=40
	expect(d.s().aux_jobs.has("xiao") and employee.motion.action=="Rest","Resting employee walks to the actual resting corner")
	var expected=m._b("employee.rest_recovery")*m.full_rules.effects.rest_recovery_factor(employee)*1.1/60;m.advance_minutes(1)
	expect(is_equal_approx(float(employee.stamina)-40,expected),"Arrived rest equipment grants exactly ten percent extra recovery")
	expect(m.AnimationRules.animation_factor(employee,"Rest",m.balance)==1,"Rest animation duration stays fixed")
	expect(m.save_game(path) and copy.load_game(path),"Rest station and auxiliary job persist safely")
	# A resting employee sent away cannot keep a main-shop station or recovery bonus.
	m.state.stage=3;m.state.gems=20
	expect(m.full_rules.perform("explore",{"employee_id":"xiao"}).ok,"Resting employee can depart on a real exploration")
	expect(not d.s().aux_jobs.has("xiao") and d.rest_multiplier(employee)==1,"Departure immediately releases the resting station and its bonus")
	m.advance_minutes(1);expect(not d.s().aux_jobs.has("xiao"),"Away employee cannot reacquire shop equipment on the next tick")
	# A paid campaign gives idle sales staff real, preemptible poster work.
	m=game(["guan_guan","xian_yang"]);d=m.full_rules.dollhouse;m.state.layout.append({"id":"promotion_board","x":14,"y":3,"w":1,"h":1})
	m.full_rules.promote_kind("flyer");m.advance_minutes(35)
	expect(int(d.s().promotion_cycles)>0,"Actual poster travel and work complete during a paid campaign")
	m._spawn_customer("noodles",false);c=m.customers[0];c.stage="paying";c.arrival_due=0;c.ingredients_reserved=true;m._assign_tasks()
	expect(c.worker=="guan_guan" and not d.s().aux_jobs.has("guan_guan"),"Customer checkout preempts poster duty and frees the poster")
	# Portable actual v1.9 save preserves economy, roster, schedules and random sequence.
	var old_bytes=FileAccess.get_file_as_bytes("res://tests/fixtures/v19-day53-save.json.gz").decompress_dynamic(32*1024*1024,FileAccess.COMPRESSION_GZIP)
	var old=JSON.parse_string(old_bytes.get_string_from_utf8());var handle=FileAccess.open(path,FileAccess.WRITE);handle.store_buffer(old_bytes);handle.close();copy=Model.new(4);copy.start_full()
	expect(copy.load_game(path) and copy.state.revision191.legacy_import,"Actual v1.9 campaign imports into equipment rules")
	expect(copy.state.cash==old.state.cash and copy.state.gems==old.state.gems and copy.employees.size()==30 and str(copy._rng.state)==str(old.rng_state),"Import grants no money, employees or random reroll")
	expect(copy.scheduler.size()==old.scheduler.size() and copy.scheduler.all(func(e):return old.scheduler.any(func(o):return str(o.type)==str(e.type) and int(o.due)==int(e.due) and int(o.get("customer_id",-1))==int(e.get("customer_id",-1)))) and copy.customers.size()==old.customers.size(),"In-flight deadlines and customer count remain exact")
	var restored=Model.new(5);restored.start_full()
	expect(copy.save_game(path) and restored.load_game(path),"Migrated equipment reservations pass a second strict roundtrip")
	DirAccess.remove_absolute(path)
	print("V1.9.1 rules: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
