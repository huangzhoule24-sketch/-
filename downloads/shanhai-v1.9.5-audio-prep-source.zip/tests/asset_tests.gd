extends SceneTree

const Catalog = preload("res://scripts/services/asset_catalog.gd")
const Rarity = preload("res://scripts/ui/rarity_display.gd")
var failures: Array[String] = []
var checks := 0
var fixture_root := "user://asset_catalog_test"


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	_cleanup(fixture_root)
	var builtin := fixture_root.path_join("builtin")
	var custom := fixture_root.path_join("custom")
	_write_png(builtin.path_join("Characters/xian_yang_idle_0.png"), Color.RED, 8)
	_write_png(builtin.path_join("Characters/xian_yang_idle_1.png"), Color.GREEN, 8)
	_write_png(builtin.path_join("Characters/xian_yang_idle_10.png"), Color.BLUE, 8)
	_write_png(builtin.path_join("Characters/xian_yang_idle_2.png"), Color.YELLOW, 8)
	_write_png(builtin.path_join("Dishes/noodles.png"), Color.RED, 8)
	_write_png(builtin.path_join("UI/noodles.png"), Color.BLUE, 8)
	_write_text(builtin.path_join("manifest.json"), JSON.stringify({"aliases": {"meal": "Dishes/noodles"}}))
	var catalog := Catalog.new(builtin, custom)
	_check(catalog.get_texture("missing") != null, "缺图必须返回占位纹理")
	_check(catalog.get_texture("../../escape") != null, "不合法 ID 安全回退")
	_check(not catalog.has_image("../../escape"), "不能将路径跳转解析为资源 ID")
	_check(catalog.has_image("Dishes/noodles"), "内置图片可以读取")
	_check(catalog.has_image("meal"), "内置 manifest 别名可读取")
	_check(not catalog.has_image("noodles"), "跨目录同名资源不应随机解析")
	_check(catalog.get_frames("missing", "Idle").size() == 1, "缺失动画返回一帧占位")
	_check(not catalog.has_frames("missing", "Idle"), "无帧时 has_frames 返回 false")
	_check(catalog.has_frames("xian_yang", "Idle"), "有编号帧时 has_frames 返回 true")
	var frames: Array[Texture2D] = catalog.get_frames("xian_yang", "Idle")
	_check(frames.size() == 4, "内置动画帧数量")
	_check(_pixel(frames[0]).is_equal_approx(Color.RED), "动画第一帧是 0")
	_check(_pixel(frames[1]).is_equal_approx(Color.GREEN), "动画第二帧是 1")
	_check(_pixel(frames[2]).is_equal_approx(Color.YELLOW), "动画按数字排序，2 在 10 前")
	_check(_pixel(frames[3]).is_equal_approx(Color.BLUE), "动画第十帧排在 2 后")
	_write_png(custom.path_join("Characters/xian_yang_idle_1.png"), Color.MAGENTA, 8)
	_write_png(custom.path_join("Dishes/noodles.png"), Color.CYAN, 8)
	_write_text(custom.path_join("manifest.json"), JSON.stringify({"aliases": {"meal": "Characters/xian_yang_idle_1", "bad": "../escape"}}))
	catalog.reload()
	_check(_pixel(catalog.get_texture("Dishes/noodles")).is_equal_approx(Color.CYAN), "自定义图片覆盖内置")
	_check(_pixel(catalog.get_texture("meal")).is_equal_approx(Color.MAGENTA), "外部 manifest 别名覆盖内置")
	_check(not catalog.has_image("bad"), "忽略不合法 manifest 别名")
	frames = catalog.get_frames("xian_yang", "idle")
	_check(frames.size() == 4, "单帧覆盖保留其余内置帧")
	_check(_pixel(frames[0]).is_equal_approx(Color.RED), "未替换的第 0 帧保留")
	_check(_pixel(frames[1]).is_equal_approx(Color.MAGENTA), "自定义第 1 帧覆盖")
	_write_png(custom.path_join("Characters/xian_yang_idle.png"), Color.WHITE, 8)
	catalog.reload()
	frames = catalog.get_frames("xian_yang", "idle")
	_check(_pixel(frames[0]).is_equal_approx(Color.WHITE), "无编号单图只覆盖第 0 帧")
	_check(frames.size() == 4, "无编号单图不压缩原动画")
	_write_png(custom.path_join("Characters/xian_yang_idle_0.png"), Color.BLACK, 8)
	catalog.reload()
	_check(_pixel(catalog.get_frames("xian_yang", "idle")[0]).is_equal_approx(Color.BLACK), "编号 0 帧优先于无编号图")
	_write_text(custom.path_join("Dishes/noodles.png"), "This is not an image")
	catalog.reload()
	_check(_pixel(catalog.get_texture("Dishes/noodles")).is_equal_approx(Color.RED), "损坏外部图片回退内置")
	var image := Image.create(12, 12, false, Image.FORMAT_RGB8)
	image.fill(Color.GREEN)
	var png: PackedByteArray = image.save_png_to_buffer()
	var imported: Dictionary = catalog.import_image(png, "UI/btn_employee.png")
	_check(imported.get("ok", false), "运行时导入有效 PNG")
	_check(catalog.has_image("UI/btn_employee"), "导入后立即可读取")
	_check(catalog.get_texture("UI/btn_employee").get_width() == 12, "导入尺寸保留")
	_check(not catalog.import_image(png, "../escape.png").get("ok", false), "拒绝上层目录导入")
	_check(not catalog.import_image(png, "UI/../../escape.png").get("ok", false), "拒绝嵌套跳转导入")
	_check(not catalog.import_image(png, "/UI/escape.png").get("ok", false), "拒绝绝对路径导入")
	_check(not catalog.import_image(png, "UI\\escape.png").get("ok", false), "拒绝反斜线绕过")
	_check(not catalog.import_image(png, "UI/code.gd").get("ok", false), "拒绝脚本导入")
	_check(not catalog.import_image("bad".to_utf8_buffer(), "UI/bad.png").get("ok", false), "拒绝伪装成 PNG 的文本")
	var jpg: PackedByteArray = image.save_jpg_to_buffer()
	_check(catalog.import_image(jpg, "Backgrounds/restaurant.jpg").get("ok", false), "运行时导入 JPG 背景")
	_check(not catalog.import_image(jpg, "UI/not_png.png").get("ok", false), "拒绝内容与扩展名不符")
	_write_png(custom.path_join("Characters/xian_yang_cook_0.png"), Color.BLUE, 9)
	catalog.poll(2.0)
	_check(not catalog.has_image("Characters/xian_yang_cook_0"), "普通模式不会自动扫描")
	catalog.developer_mode = true
	catalog.poll(2.0)
	_check(catalog.has_image("Characters/xian_yang_cook_0"), "开发者模式能检测新增图片")
	DirAccess.remove_absolute(custom.path_join("Characters/xian_yang_cook_0.png"))
	catalog.poll(2.0)
	_check(not catalog.has_image("Characters/xian_yang_cook_0"), "开发者模式能检测删除图片")
	_write_png(custom.path_join("UI/changed.png"), Color.BLUE, 6)
	catalog.reload()
	_write_png(custom.path_join("UI/changed.png"), Color.RED, 30)
	catalog.poll(2.0)
	_check(catalog.get_texture("UI/changed").get_width() == 30, "修改图片后缓存刷新")
	var same_size_image := Image.create(30, 30, false, Image.FORMAT_RGBA8)
	same_size_image.fill(Color.BLUE)
	same_size_image.save_png(custom.path_join("UI/changed.png"))
	catalog.poll(2.0)
	_check(_pixel(catalog.get_texture("UI/changed")).is_equal_approx(Color.BLUE), "同一秒内同尺寸覆盖亦能刷新")
	_test_symlinks(catalog, custom, fixture_root.path_join("outside"), png)
	_test_culture_images(catalog, builtin, custom, png, jpg)
	Rarity.reload_config()
	_check(Rarity.color_for("N").is_equal_approx(Color("#9E9E9E")), "N 灰色")
	_check(Rarity.color_for("R").is_equal_approx(Color("#2196F3")), "R 蓝色")
	_check(Rarity.color_for("SR").is_equal_approx(Color("#9C27B0")), "SR 紫色")
	_check(Rarity.color_for("SSR").is_equal_approx(Color("#FFD700")), "SSR 金色")
	_check(Rarity.label_for("SSR") == "传说", "稀有度中文标签")
	_check(Rarity.stars_for("SSR") == 3 and Rarity.stars_for("N") == 0, "稀有度星数")
	_check(Rarity.scene_marker_for("SSR") == "★" and Rarity.scene_marker_for("SR").is_empty(), "仅 SSR 有场景星标")
	_check(Rarity.label_for("unknown") == "普通", "未知稀有度按 N 回退")
	var badge := Rarity.create_badge("SSR", false, catalog)
	_check(badge.get_child(0).get_child(0).text.begins_with("SSR"), "徽章显示稀有度代码")
	badge.free()
	_cleanup(fixture_root)
	for failure in failures:
		printerr("FAIL: " + failure)
	print("ASSET TESTS: %d checks, %d failures" % [checks, failures.size()])
	quit(0 if failures.is_empty() else 1)


func _test_culture_images(catalog: RefCounted, builtin: String, custom: String, png: PackedByteArray, jpg: PackedByteArray) -> void:
	_check(catalog.culture_resource_id("employees", "xian_yang") == "Characters/xian_yang_lore", "员工文化图使用独立专图槽位")
	_check(catalog.culture_resource_id("dishes", "noodles") == "Dishes/noodles_lore", "菜品文化图使用独立专图槽位")
	_check(catalog.culture_resource_id("employee", "xian_yang") == catalog.culture_resource_id("employees", "xian_yang"), "员工单复数种类兼容")
	_check(catalog.culture_resource_id("dish", "noodles") == catalog.culture_resource_id("dishes", "noodles"), "菜品单复数种类兼容")
	_check(catalog.culture_resource_id("employees", "../escape").is_empty(), "文化图拒绝路径跳转")
	_check(catalog.is_placeholder(catalog.culture_texture("unknown", "xian_yang")), "未知文化类别安全回退")
	_check(catalog.is_placeholder(catalog.culture_texture("employees", "missing")), "员工无专图与肖像时返回占位")
	_check(catalog.is_placeholder(catalog.culture_texture("dishes", "baize_hidden_banquet")), "隐藏菜无图时仍安全回退")
	_check(_pixel(catalog.culture_texture("employees", "xian_yang")).is_equal_approx(Color.BLACK), "无文化专图时采用现有真实 Idle 帧")
	_check(_pixel(catalog.culture_texture("dishes", "noodles")).is_equal_approx(Color.RED), "无文化专图时采用现有菜图")
	_write_png(builtin.path_join("Characters/xian_yang_lore.png"), Color.GREEN, 8)
	_write_png(builtin.path_join("Dishes/noodles_lore.png"), Color.YELLOW, 8)
	catalog.reload()
	_check(_pixel(catalog.culture_texture("employees", "xian_yang")).is_equal_approx(Color.GREEN), "内置员工专图优先于普通自定义动作图")
	_check(_pixel(catalog.culture_texture("dishes", "noodles")).is_equal_approx(Color.YELLOW), "内置菜品专图优先于普通菜图")
	_write_png(custom.path_join("Characters/xian_yang_lore.png"), Color.BLUE, 8)
	_write_png(custom.path_join("Dishes/noodles_lore.png"), Color.CYAN, 8)
	catalog.reload()
	_check(_pixel(catalog.culture_texture("employees", "xian_yang")).is_equal_approx(Color.BLUE), "自定义员工文化图覆盖内置专图")
	_check(_pixel(catalog.culture_texture("dishes", "noodles")).is_equal_approx(Color.CYAN), "自定义菜品文化图覆盖内置专图")
	_check(_pixel(catalog.get_frames("xian_yang", "idle")[0]).is_equal_approx(Color.BLACK), "文化图不覆盖游戏员工动作")
	_check(_pixel(catalog.get_texture("Dishes/noodles")).is_equal_approx(Color.RED), "文化图不覆盖普通菜单图")
	_write_png(custom.path_join("Characters/xian_yang_lore.png"), Color.MAGENTA, 8)
	catalog.poll(2.0)
	_check(_pixel(catalog.culture_texture("employees", "xian_yang")).is_equal_approx(Color.MAGENTA), "文化专图同尺寸覆盖可热重载")
	_write_text(custom.path_join("Characters/xian_yang_lore.png"), "not an image")
	catalog.reload()
	_check(_pixel(catalog.culture_texture("employees", "xian_yang")).is_equal_approx(Color.GREEN), "损坏自定义员工文化图回退内置专图")
	_check(catalog.import_image(png, "Characters/xiao_lore.png").get("ok", false), "网页共用导入入口接受员工文化图 PNG")
	_check(_pixel(catalog.culture_texture("employees", "xiao")).is_equal_approx(Color.GREEN), "导入员工专图立即显示")
	_check(catalog.import_image(jpg, "Dishes/baize_hidden_banquet_lore.jpg").get("ok", false), "隐藏菜文化图支持 JPG 导入")
	_check(not catalog.is_placeholder(catalog.culture_texture("dishes", "baize_hidden_banquet")), "隐藏菜 JPG 文化图可读取")
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://CustomAssets/manifest.json"))
	var slots: Array = manifest.get("culture_slots", [])
	_check(slots.size() == 55, "开发者清单为28员工与25菜品保留53专图槽位")
	var expected: Array[String] = []
	for employee in JSON.parse_string(FileAccess.get_file_as_string("res://config/employees.json")):
		expected.append("employees:" + str(employee.id))
	for dish in JSON.parse_string(FileAccess.get_file_as_string("res://config/dishes.json")):
		expected.append("dishes:" + str(dish.id))
	var management: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/management.json"))
	expected.append("dishes:" + str(management.hidden_recipe.id))
	var sidequests: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"))
	for recipe in sidequests.hidden_recipes: expected.append("dishes:" + str(recipe.id))
	_check(catalog.culture_resource_id("dishes", "phoenix_true_soup") == "Dishes/phoenix_true_soup_lore", "凤凰支线隐藏菜拥有独立文化图片接入槽")
	_check(catalog.import_image(png, "Dishes/phoenix_true_soup_lore.png").get("ok", false), "凤凰支线隐藏菜专图可经统一入口导入")
	_check(not catalog.is_placeholder(catalog.culture_texture("dishes", "phoenix_true_soup")), "新增隐藏菜专图导入后读取真实图片")
	var actual: Array[String] = []
	var correct_paths := true
	for slot in slots:
		actual.append(str(slot.kind) + ":" + str(slot.id))
		var resource_id: String = catalog.culture_resource_id(str(slot.kind), str(slot.id))
		correct_paths = correct_paths and slot.resource_id == resource_id and slot.path == resource_id + ".png"
	expected.sort()
	actual.sort()
	_check(actual == expected, "51槽位逐一匹配实际配置员工、标准菜及隐藏菜")
	_check(correct_paths, "文化清单专图路径与运行时API一致")


func _test_symlinks(catalog: RefCounted, custom: String, outside: String, png: PackedByteArray) -> void:
	if OS.get_name() != "Linux":
		return
	_write_png(outside.path_join("escape.png"), Color.RED, 8)
	var absolute_target := ProjectSettings.globalize_path(outside.path_join("escape.png"))
	var absolute_link := ProjectSettings.globalize_path(custom.path_join("UI/escape.png"))
	var result := OS.execute("ln", ["-s", absolute_target, absolute_link])
	if result != 0:
		return
	catalog.reload()
	_check(not catalog.has_image("UI/escape"), "扫描不跟随符号链接")
	_check(not catalog.import_image(png, "UI/escape.png").get("ok", false), "导入不能覆盖链接指向的文件")
	DirAccess.remove_absolute(absolute_link)


func _write_png(path: String, color: Color, size: int) -> void:
	DirAccess.make_dir_recursive_absolute(path.get_base_dir())
	var image := Image.create(size, size, false, Image.FORMAT_RGBA8)
	image.fill(color)
	image.save_png(path)


func _write_text(path: String, contents: String) -> void:
	DirAccess.make_dir_recursive_absolute(path.get_base_dir())
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_string(contents)
	file.close()


func _pixel(texture: Texture2D) -> Color:
	return texture.get_image().get_pixel(0, 0)


func _check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)


func _cleanup(path: String) -> void:
	var directory := DirAccess.open(path)
	if directory == null:
		return
	for filename in directory.get_files():
		DirAccess.remove_absolute(path.path_join(filename))
	for folder in directory.get_directories():
		if directory.is_link(folder):
			DirAccess.remove_absolute(path.path_join(folder))
		else:
			_cleanup(path.path_join(folder))
	DirAccess.remove_absolute(path)
