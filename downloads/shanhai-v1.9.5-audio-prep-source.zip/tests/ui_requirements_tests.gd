extends SceneTree

const Notifications = preload("res://scripts/ui/action_notifications.gd")
const Model = preload("res://scripts/core/game_model.gd")
const Rarity = preload("res://scripts/ui/rarity_display.gd")
var checks = 0
var failures = 0

class Harness extends "res://scripts/ui/main.gd":
	func _ready() -> void:
		var game_theme = Theme.new()
		game_theme.default_font = FONT
		game_theme.default_font_size = 16
		theme = game_theme
		model = GameModel.new(20261016)
		model.start_full()
		# Broad panel fixtures defer stage teaching; mandatory guidance has its own real-operation suite.
		model.state.tutorial = {"version":2,"completed_steps":["welcome","staff","promotion","first_order","income","bill"],"deferred":Guide.config().stage_steps.map(func(step): return step.id),"actions":[],"stage_completed":[],"panel_opened":[],"panel_closed":[],"finished":true,"skipped":false,"seen_stage":0}
		assets = AssetCatalog.new()
		model.set_paused(true)
		build_interface()
		full_panels = FullPanels.new(self)
		tutorial_overlay = TutorialOverlay.new()
		add_child(tutorial_overlay)
		tutorial_overlay.setup(self)
		model.changed.connect(refresh)
		model.notice.connect(show_notice)
		set_process(false)
		refresh()

func _init() -> void:
	call_deferred("run")

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(message)

func find(node: Node, id: String) -> Node:
	if str(node.get_meta("qa_id", "")) == id: return node
	for child in node.get_children():
		var found = find(child, id)
		if found != null: return found
	return null

func labels(node: Node) -> String:
	var result: String = node.text if node is Label else ""
	for child in node.get_children(): result += "\n" + labels(child)
	return result

func named_count(node: Node, expected: String) -> int:
	var result: int = 1 if str(node.name) == expected else 0
	for child in node.get_children(): result += named_count(child, expected)
	return result

func run() -> void:
	var model = Model.new(20261016)
	model.start_full()
	var notifications = Notifications.new(model)
	notifications.update()
	check(notifications.has_unread("staff"), "Affordable new recruitment raises an actionable notification")
	notifications.acknowledge("staff")
	check(notifications.has_unread("staff"),"Viewing staff does not clear required recruitment")
	model.state.cash += 20
	notifications.update()
	check(notifications.has_unread("staff"),"Cash fluctuation does not resolve recruitment")
	model.state.cash = 0
	notifications.update()
	model.state.cash = 800
	notifications.update()
	check(notifications.has_unread("staff"),"Available recruitment remains actionable")
	notifications.set_enabled(false)
	check(notifications.has_unread("staff"),"Global optional setting cannot hide strong notifications")
	notifications.set_enabled(true)
	var rebuilt = Notifications.new(model)
	rebuilt.update()
	check(rebuilt.has_unread("staff"),"Rebuilding retains unresolved required actions")
	var saved_path: String = "/tmp/shanhai-ui-notifications-%d.json" % OS.get_process_id()
	check(model.save_game(saved_path), "Notifications are accepted by real campaign saves")
	var restored = Model.new(1)
	check(restored.load_game(saved_path), "Campaign save with notification state reloads")
	var restored_notifications = Notifications.new(restored)
	restored_notifications.update()
	check(restored_notifications.has_unread("staff"),"Unresolved strong notifications survive actual save and reload")
	DirAccess.remove_absolute(saved_path)
	model.state.contracts.append("bi_fang")
	rebuilt.update()
	check(rebuilt.has_unread("staff"), "A newly obtained contract raises a fresh notification")
	model.state.total_revenue = 5000
	model.state.reputation = 100
	rebuilt.update()
	check(rebuilt.has_unread("growth"), "Meeting upgrade requirements raises notification")
	rebuilt.acknowledge("growth")
	rebuilt.update()
	check(rebuilt.has_unread("growth"),"Upgrade remains pending after viewing its panel")
	model.full_rules.world._enqueue("food_festival")
	rebuilt.update()
	check(rebuilt.has_unread("events"), "New queued event raises one notification")
	rebuilt.acknowledge("events")
	model.state.world.queue.clear()
	model.full_rules.world._enqueue("food_festival")
	rebuilt.update()
	check(rebuilt.has_unread("events"), "A distinct event serial rearms even in the same minute")
	root.size = Vector2i(1440, 900)
	var ui = Harness.new()
	root.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	await process_frame
	await process_frame
	ui.open_panel("员工")
	await process_frame
	check(ui.action_notifications.has_unread("staff"),"Actual staff navigation leaves recruitment pending")
	check(named_count(ui.modal_body, "RarityBadge") == ui.model.employees.size(), "All staff cards use the shared rarity badge")
	for rank in ["N", "R", "SR", "SSR"]:
		check(ui.full_panels.rarity_color(rank) == Rarity.color_for(rank), "Full UI uses configured " + rank + " color")
	ui.open_panel("图鉴")
	await process_frame
	for tab in ["员工", "菜品", "羁绊", "事件", "道具", "装修"]:
		check(find(ui.modal_body, "catalog:" + tab) != null, "Catalog exposes " + tab)
		ui.full_panels.catalog_tab = tab
		ui.open_panel("图鉴")
		await process_frame
		check(ui.modal_body.get_child_count() > 1, "Catalog tab renders content: " + tab)
	ui.model.state.stage = maxi(1,int(ui.model.state.stage))
	ui.open_panel("装修")
	await process_frame
	await process_frame
	check(ui.drawer_slot.visible and not ui.sidebar.visible and not ui.overlay.visible, "Decoration uses the reserved side drawer")
	check(not ui.modal_window.get_global_rect().intersects(ui.map_view.get_global_rect()), "Decoration drawer never covers the map")
	check(labels(ui.modal_body).contains("舒适度") and labels(ui.modal_body).contains("￥"), "Decoration renders placeholder thumbnails, cost and live effects")
	ui.finish_decoration(false)
	await process_frame
	check(not ui.sidebar.visible and not ui.drawer_slot.visible, "Closing drawer restores the full-width dollhouse scene")
	ui.open_panel("系统")
	await process_frame
	check(ui.modal_window.get_parent() == ui.overlay and ui.overlay.visible, "Ordinary modal remains separate from drawer")
	var toggle: Button = find(ui.modal_body, "system:notifications")
	check(toggle != null, "System exposes notification setting")
	toggle.pressed.emit()
	check(not ui.action_notifications.enabled(), "System notification toggle updates saved setting")
	ui.model.state.developer_mode = true
	check(ui.model.apply_balance_override("employee.base_wage", 4000), "Developer can inspect extreme economic configuration")
	ui.open_panel("数值面板")
	await process_frame
	check(labels(ui.modal_body).contains("8800.00") and labels(ui.modal_body).contains("8856.00"), "Opening economic diagnosis reflects current edited wages and cash expenses")
	check(not labels(ui.modal_body).contains("工资88元"), "Balance diagnosis cannot display the former hardcoded opening check")
	check(ui.rarity_marked_text("凤凰和羬羊正在工作").contains("[color=#ffd700]● 凤凰[/color]"), "Employee notices carry configured rarity dots")
	ui.model.state.interest_arrears = 10.0
	ui.model.state.wage_arrears = 20.0
	ui.model.state.rent_arrears = 30.0
	ui.model.state.cash = 100.0
	ui.open_panel("财务账本")
	await process_frame
	var settle: Button = find(ui.modal_body, "finance:settle_arrears")
	check(settle != null and not settle.disabled, "Ledger exposes actionable liability repayment")
	settle.pressed.emit()
	check(float(ui.model.state.cash) == 40 and float(ui.model.state.wage_arrears) == 0, "Ledger repayment actually settles liabilities")
	ui.model.state.stage = 1
	ui.open_panel("研发")
	await process_frame
	check(find(ui.modal_body, "research:researcher") != null, "Research exposes actual researcher choice")
	ui.model.employees.append(ui.model._create_employee(ui.model._employee_config("bai_ze")))
	ui.model.full_rules.ensure_state_defaults()
	ui.model.state.cash = 1000
	ui.open_panel("研发")
	var research_selector: OptionButton = find(ui.modal_body, "research:researcher")
	for index in range(research_selector.item_count):
		if research_selector.get_item_text(index).contains("白泽"):
			research_selector.item_selected.emit(index)
			break
	var research_start: Button = find(ui.modal_body, "full:research:qianyang_soup")
	check(research_start != null and not research_start.disabled, "An available chosen Tutor can host a real research project")
	if research_start != null and not research_start.disabled: research_start.pressed.emit()
	check(ui.model.state.management.projects.any(func(project): return str(project.get("type", "")) == "research" and str(project.get("employee_id", "")) == "bai_ze"), "Research button reserves the actual selected host")
	ui.revision_ui.employee_id="xian_yang"
	ui.open_panel("员工详情")
	await process_frame
	check(labels(ui.modal_body).contains("排班"), "Training and shift controls remain available")
	check(ui.full_panels.PERIODS.has("rest"), "Shift UI includes the automatic rest hour")
	var rest_shift: CheckBox = find(ui.modal_body, "shift:xian_yang:rest")
	rest_shift.button_pressed = false
	var save_shift: Button = find(ui.modal_body, "revision:set_shift:xian_yang")
	save_shift.pressed.emit()
	check(not "rest" in ui.model._employee("xian_yang").shift_periods, "Rest-hour checkbox is saved to the actual employee shift")
	ui.model.set_employee_rest("xian_yang", true)
	ui.open_panel("员工详情")
	var restore_shift: Button = find(ui.modal_body, "employee:restore_shift:xian_yang")
	restore_shift.pressed.emit()
	check(not ui.model._employee("xian_yang").resting and "rest" in ui.model._employee("xian_yang").shift_periods, "Restoring all shifts actually returns the employee to work")
	ui.model.state.cash = 1000
	ui.model.state.world.queue.clear()
	ui.model.full_rules.world._enqueue("food_festival")
	ui.open_panel("事件")
	await process_frame
	var prepare: Button = find(ui.modal_body, "full:festival_prepare")
	check(prepare != null, "Food festival event exposes preparation action")
	check(find(ui.modal_body, "festival:chef") != null and find(ui.modal_body, "festival:dish") != null, "Food festival exposes actual chef and dish selectors")
	prepare.pressed.emit()
	check(not str(ui.model.state.world.festival.employee_id).is_empty() and not str(ui.model.state.world.festival.dish_id).is_empty(), "Festival preparation records the selected actual participants")
	ui.model.state.management.items.generic.quantity = 0
	ui.open_panel("事件")
	prepare = find(ui.modal_body, "full:festival_prepare")
	check(prepare.disabled, "Festival cannot confirm a selection without its real recipe stock")
	ui.model.state.management.items.generic.quantity = 100
	ui.model.state.world.blockade.active = true
	ui.model.state.world.blockade.responses = 1
	ui.model.state.world.blockade.service_orders = 20
	ui.model.state.reputation = 1000
	ui.model.state.stage=3
	ui.open_panel("封锁对抗")
	await process_frame
	check(find(ui.modal_body, "full:kunlun_counter:supply") != null, "Blockade panel exposes the actual counteraction")
	for strategy in ["supply", "service", "community"]:
		var counter: Button = find(ui.modal_body, "full:kunlun_counter:" + strategy)
		check(counter != null and not counter.disabled, "Qualified blockade strategy is actionable: " + strategy)
		if counter != null and not counter.disabled: counter.pressed.emit()
	check(bool(ui.model.state.world.blockade.resolved), "All three actual UI strategies resolve the blockade")
	ui.model.state.stage = 0
	ui.model.state.debt = 0
	ui.open_panel("菜单")
	check(find(ui.modal_body, "full:reset_price:noodles").disabled, "Price reset observes the same stage gate as manual pricing")
	ui.open_panel("账单")
	check(find(ui.modal_body, "repay:all").disabled, "Full repayment is disabled when no principal remains")
	root.size = Vector2i(844, 390)
	ui.close_panel()
	await process_frame
	await process_frame
	check(ui.compact_layout and not ui.sidebar.visible, "Phone landscape uses an actual compact layout")
	check(root.content_scale_size == Vector2i(844, 390), "Phone controls use physical viewport pixels")
	check(root.content_scale_aspect == Window.CONTENT_SCALE_ASPECT_IGNORE, "Compact viewport fills its available screen aspect")
	check(ui.navigation_buttons["员工"].get_global_rect().end.x <= 844 and ui.pause_button.size.y >= 44, "Phone navigation fits and time controls retain touch size")
	ui._resumed = true
	ui.open_panel("欢迎")
	await process_frame
	await process_frame
	var resume_button: Button = find(ui.modal_window, "start:continue")
	check(resume_button != null and resume_button.is_visible_in_tree() and ui.modal_window.get_global_rect().encloses(resume_button.get_global_rect()), "Phone welcome has a fixed visible resume control outside the scrolling text")
	resume_button.pressed.emit()
	check(ui.panel_name.is_empty() and not ui.model.paused, "Fixed welcome control actually resumes the game")
	ui.model.state.stage=1
	ui.open_panel("研发")
	await process_frame
	await process_frame
	check(ui.modal_window.get_global_rect().position.y >= 8 and ui.modal_window.get_global_rect().position.y >= ui.bottom_ui.first.get_global_rect().end.y and ui.modal_window.get_global_rect().end.y<=ui._layout_controls.bottom.global_position.y, "Phone modal keeps bottom resources and navigation available")
	var researcher: OptionButton = find(ui.modal_body, "research:researcher")
	check(researcher != null and researcher.size.y >= 44, "Research selection remains a touch-sized control")
	ui.model.state.stage = maxi(1,int(ui.model.state.stage))
	ui.open_panel("装修")
	await process_frame
	await process_frame
	check(ui.drawer_slot.size.x == 340 and ui.map_view.size.x >= 160 and not ui.modal_window.get_global_rect().intersects(ui.map_view.get_global_rect()), "Compact decoration preserves both the 340px drawer and visible map")
	root.size = Vector2i(390, 844)
	ui.update_ui_layout()
	await process_frame
	check(ui.landscape_required and ui.get_node("LandscapeHint").visible, "Portrait phones show the landscape instruction")
	root.size = Vector2i(1440, 900)
	ui.update_ui_layout()
	ui.queue_free()
	await process_frame
	print("UI requirement checks: %d; failures: %d" % [checks, failures])
	quit(1 if failures else 0)
