extends SceneTree

const Model = preload("res://scripts/core/game_model.gd")
var checks := 0
var failures := 0

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition: failures += 1; push_error(label)

func approx(actual: float, expected: float, label: String) -> void:
	check(absf(actual - expected) < 0.001, "%s: %.4f vs %.4f" % [label, actual, expected])

func fresh(seed_value: int = 715):
	var m = Model.new(seed_value)
	m.start_full()
	m.balance["customer.base_flow"] = 0.0
	m.events.clear() # Deterministic fixtures suppress random events; event rules have their own suite.
	return m

func add_employee(m, id: String) -> Dictionary:
	var employee: Dictionary = m._create_employee(m._employee_config(id))
	m.employees.append(employee)
	m.full_rules.ensure_state_defaults()
	return employee

func roundtrip(m, name: String):
	var path := "user://campaign-%s.json" % name
	check(m.save_game(path), "save %s" % name)
	var copy = Model.new(991)
	check(copy.load_game(path), "load %s" % name)
	check(canonical(copy.state) == canonical(m.state), "state roundtrip %s" % name)
	check(canonical(copy.customers) == canonical(m.customers), "customers roundtrip %s" % name)
	check(canonical(copy.employees) == canonical(m.employees), "employees roundtrip %s" % name)
	check(canonical(copy.scheduler) == canonical(m.scheduler), "scheduler roundtrip %s" % name)
	check(str(copy._rng.state) == str(m._rng.state), "RNG roundtrip %s" % name)
	return copy

func canonical(value: Variant) -> String:
	return JSON.stringify(JSON.parse_string(JSON.stringify(value)))

func _init() -> void:
	call_deferred("run")

func run() -> void:
	var m = Model.new(715)
	m.start_full()
	check(str(m.state.mode) == "full", "campaign explicit mode")
	check(m.catalog.size() == 30, "all 30 employees")
	check(m.dishes.filter(func(d): return not str(d.id) in ["phoenix_true_soup", "baize_hidden_banquet"]).size() == 23, "all 23 designed dishes plus separately registered hidden recipes")
	check(m.events.size() == 38, "30 planned events plus documented debt collection event")
	check(m.events.filter(func(event): return str(event.id) != "debt_collection").size() == 37, "all original30 and7 added events remain")
	check(m.bonds.size() == 11, "all 11 bonds")
	for entry in m.catalog: check(m.skills_enabled(str(entry.id)), "skill enabled %s" % str(entry.id))
	check(int(m.full_rules.setting("layout", "width", 0)) == 16 and int(m.full_rules.setting("layout", "height", 0)) == 5, "campaign expanded grid")
	roundtrip(m, "initial")
	m = fresh()
	var management = m.full_rules.management
	var cash_before := float(m.state.cash)
	var stock_before := float(management.item("generic").quantity)
	var purchase: Dictionary = m.full_rules.perform("purchase", {"id":"generic", "quantity":5})
	check(bool(purchase.get("ok", false)), "buy actual inventory")
	var paid := cash_before - float(m.state.cash)
	check(paid > 0.0, "procurement spends cash")
	approx(float(management.item("generic").quantity), stock_before + 5.0, "procurement increases stock")
	approx(float(m.state.ledger.procurement), paid, "ledger records purchase as inventory cash flow")
	var cash_after_purchase := float(m.state.cash)
	var inventory_before := float(management.inventory_value())
	var consumed: Dictionary = management.consume("noodles")
	check(bool(consumed.get("ok", false)), "recipe consumes available stock")
	approx(float(m.state.cash), cash_after_purchase, "consuming stock does not pay supplier twice")
	approx(float(management.inventory_value()), inventory_before - float(consumed.get("cost", 0)), "stock value transfers to cost")
	approx(float(m.state.management.daily_cogs), float(consumed.get("cost", 0)), "consumption recognizes cost once")
	check(not bool(m.full_rules.perform("purchase", {"id":"generic","quantity":-1}).get("ok",false)), "negative purchase rejected")
	check(not bool(m.full_rules.perform("purchase", {"id":"rare","quantity":1}).get("ok",false)), "rare ingredient cannot be bought normally")
	m = fresh()
	m.state.cash = 100000.0
	check(not m.upgrade_restaurant(), "upgrade initially blocked")
	for stage in range(1, 5):
		m.state.total_revenue = m._b("stage.%d.revenue" % stage)
		m.state.reputation = int(m._b("stage.%d.reputation" % stage))
		check(int(m.state.stage) == stage - 1, "meeting targets does not auto-upgrade stage %d" % stage)
		var gems_before := int(m.state.gems)
		check(m.upgrade_restaurant(), "manual upgrade stage %d" % stage)
		check(int(m.state.stage) == stage, "stage %d entered" % stage)
		check(int(m.state.gems) - gems_before == int(m.full_rules.config.stage.reward_gems[stage]), "one stage reward %d" % stage)
		check(int(m.full_rules.active_limit()) == int(m.full_rules.config.stage.active_limits[stage]), "stage staffing limit %d" % stage)
	check(not m.upgrade_restaurant(), "stage 4 is final")
	roundtrip(m, "all-stages")
	m = fresh(816)
	m.state.stage = 3
	m.state.cash = 10000.0
	m.state.gems = 20
	var chef_id := "xian_yang"
	var waiter_id := ""
	for e in m.employees:
		if str(e.role) == "waiter": waiter_id = str(e.id)
	var explorer: Dictionary = add_employee(m, "guan_guan")
	add_employee(m, "bai_ze") # Boundary fixture: real stage-3 research with a tutor.
	var training: Dictionary = m.full_rules.perform("train_attribute", {"employee_id":waiter_id,"attribute":"speed"})
	var research: Dictionary = m.full_rules.perform("research", {"dish_id":"qianyang_soup","employee_id":chef_id})
	var explore: Dictionary = m.full_rules.perform("explore", {"employee_id":str(explorer.id)})
	check(bool(training.get("ok", false)), "attribute training starts")
	check(bool(research.get("ok", false)), "paid research starts")
	check(bool(explore.get("ok", false)), "exploration starts")
	check(m.state.management.projects.size() == 2, "two independent management projects")
	check(m.state.expansion.explorations.size() == 1, "independent expansion task")
	var loaded = roundtrip(m, "concurrent-projects")
	loaded.events.clear()
	loaded.balance["customer.base_flow"] = 0.0
	loaded.advance_minutes(121)
	check(loaded.state.management.projects.is_empty(), "training and research complete after load")
	check("qianyang_soup" in loaded.state.unlocked_dishes, "tutor-supported paid research survives load")
	check(loaded.state.expansion.explorations.is_empty(), "exploration completes after load")
	check(loaded.state.expansion.exploration_history.size() == 1, "exploration reward logged once")
	check(int(loaded._employee(waiter_id).management_until) == 0, "training employee released")
	check(int(loaded._employee(chef_id).management_until) == 0, "research employee released")
	check(int(loaded._employee("guan_guan").expansion_until) == 0, "exploration employee released")
	roundtrip(loaded, "completed-projects")
	var tamper: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("user://campaign-concurrent-projects.json"))
	tamper.state.management.projects[0].due = int(tamper.state.management.projects[0].due) + 1
	var bad_file := FileAccess.open("user://campaign-tamper-project.json", FileAccess.WRITE)
	bad_file.store_string(JSON.stringify(tamper)); bad_file.close()
	var original := JSON.stringify(loaded.state)
	check(not loaded.load_game("user://campaign-tamper-project.json"), "reject project and worker due mismatch")
	check(JSON.stringify(loaded.state) == original, "rejecting project tamper preserves campaign")
	tamper = JSON.parse_string(FileAccess.get_file_as_string("user://campaign-initial.json"))
	tamper.state.management.items.generic.quantity = -10
	bad_file = FileAccess.open("user://campaign-tamper-stock.json", FileAccess.WRITE)
	bad_file.store_string(JSON.stringify(tamper)); bad_file.close()
	check(not loaded.load_game("user://campaign-tamper-stock.json"), "reject negative inventory tampering")
	check(JSON.stringify(loaded.state) == original, "rejecting stock tamper preserves campaign")
	for case in ["world", "expansion", "ledger"]:
		tamper = JSON.parse_string(FileAccess.get_file_as_string("user://campaign-initial.json"))
		if case == "world": tamper.state.world.weather = "invalid-weather"
		elif case == "expansion": tamper.state.expansion.central.stock.noodles = -1
		else: tamper.state.ledger.sales = "invalid-amount"
		var path := "user://campaign-tamper-%s.json" % case
		bad_file = FileAccess.open(path, FileAccess.WRITE)
		bad_file.store_string(JSON.stringify(tamper)); bad_file.close()
		check(not loaded.load_game(path), "reject malformed %s subsystem" % case)
		check(JSON.stringify(loaded.state) == original, "rejecting %s tamper preserves state" % case)
	m = fresh(8170)
	m.balance["customer.tip_chance"] = 0.0
	m.full_rules.config.defaults.escape_probability = 0.0
	m.state.menu_enabled = ["noodles"]
	m._spawn_customer()
	var order_cash_before := float(m.state.cash)
	var order_stock_before := float(m.full_rules.management.inventory_value())
	var cogs_before := float(m.state.ledger.cost_of_sales)
	var checked_wip := false
	for minute in range(150):
		m.advance_minutes(1)
		if not m.customers.is_empty() and str(m.customers[0].stage) == "cooking" and not checked_wip:
			checked_wip = true
			approx(float(m.state.cash), order_cash_before, "cooking inventory has no second cash payment")
			approx(float(m.state.ledger.cost_of_sales), cogs_before, "unfinished dish is work in progress, not sales cost")
			check(float(m.full_rules.management.inventory_value()) < order_stock_before, "cooking transfers raw inventory to WIP")
		if m.customers.is_empty() and int(m.state.served) > 0: break
	check(checked_wip, "WIP transition observed in actual scheduler")
	check(int(m.state.served) == 1, "full campaign actually completes one order")
	approx(float(m.state.cash), order_cash_before + float(m.state.total_revenue), "full checkout credits cash once")
	approx(float(m.state.ledger.sales), float(m.state.total_revenue), "full sales ledger agrees with checkout")
	approx(float(m.state.ledger.cost_of_sales), float(m._dish("noodles").cost), "full checkout recognizes matching sales cost once")
	m = fresh(817)
	m.state.stage = 1
	m.employees.clear()
	add_employee(m, "jiu_ying")
	add_employee(m, "xiao")
	m.state.menu_enabled = ["noodles"]
	m.state.layout.append({"id":"stove","x":13,"y":0,"w":1,"h":1}) # Triple work now needs three actual stoves.
	for index in range(3):
		m._spawn_customer()
		m.customers[index].stage = "queued"
		m.customers[index].arrival_due=0
	m._assign_tasks()
	check(m._worker_task_count("jiu_ying") == 3, "nine-headed chef holds three real customer tasks")
	check(m.scheduler.filter(func(event): return str(event.get("employee_id","")) == "jiu_ying").size() == 3, "parallel tasks have distinct scheduler entries")
	var multi = roundtrip(m, "jiuying-parallel")
	multi.events.clear()
	multi.balance["customer.base_flow"] = 0.0
	multi.advance_minutes(30)
	check(multi._worker_task_count("jiu_ying") == 0, "parallel completion releases all chef references")
	check(int(multi._employee("jiu_ying").busy_customer) == 0, "parallel chef busy reference clears")
	# Source-routed coverage: base passive skills, management skill modifiers, and world-event skills.
	var coverage := {
		"xian_yang":"base_quality", "xiao":"base_night_speed", "er_shu":"base_serve", "tao_tie":"base_cook_and_stock",
		"jiu_wei_hu":"base_tips", "bi_fang":"base_bbq", "pi_xiu":"base_checkout",
		"guan_guan":"management", "e_shou":"management", "ran_yi_yu":"management", "tian_gou":"management", "gu_diao":"management",
		"ying_zhao":"management", "lu_wu":"management", "jing_wei":"management", "qiong_qi":"management", "tao_wu":"management",
		"hun_dun":"management", "xie_zhi":"management", "ying_long":"management", "di_jiang":"management", "jiu_ying":"management",
		"dang_kang":"world_day", "feng_huang":"world_stamina", "bai_ze":"research_training", "zhu_long":"world_shift", "xuan_gui":"stable_cook", "qing_geng":"mood_and_complaints", "qing_fu":"pickup_cash", "tian_lu":"pickup_probability"}
	check(coverage.size() == 30, "every employee assigned a skill implementation route")
	for entry in m.catalog:
		check(coverage.has(str(entry.id)), "skill routing covers %s" % str(entry.id))
		if coverage.get(str(entry.id)) == "management":
			var fixture: Dictionary = m._create_employee(entry)
			check(not m.full_rules.management.employee_effects(fixture).is_empty(), "nonempty skill modifier %s" % str(entry.id))
	m = fresh(818)
	m.state.stage = 4
	m.employees.clear()
	for id in ["xian_yang", "xiao", "er_shu", "tao_tie", "jiu_wei_hu", "bi_fang", "pi_xiu"]: add_employee(m, id)
	approx(float(m.full_rules.quality_multiplier(m._employee("xian_yang"), m._dish("qianyang_soup"))), 1.05, "qianyang actual soup quality bonus")
	m.state.total_minutes = 1260
	approx(float(m.full_rules.speed_multiplier(m._employee("xiao"), "serving")), 1.15, "owl actual night shift bonus")
	approx(float(m.full_rules.speed_multiplier(m._employee("er_shu"), "serving")), 1.10, "earmouse actual serving bonus")
	approx(float(m.full_rules.speed_multiplier(m._employee("tao_tie"), "cooking")), 1.15, "taotie actual cooking bonus")
	m._employee("pi_xiu").resting = true
	approx(float(m.full_rules.ingredient_multiplier(m._employee("tao_tie"))), 1.10, "taotie actual ingredient surcharge")
	m._employee("pi_xiu").resting = false
	approx(float(m.full_rules.tip_bonus(m._employee("jiu_wei_hu"))), 0.30, "fox actual tip probability bonus")
	approx(float(m.full_rules.quality_multiplier(m._employee("bi_fang"), m._dish("bifang_wings"))), 1.30, "bifang actual barbecue quality bonus")
	approx(float(m.full_rules.checkout_multiplier(m._employee("pi_xiu"))), 1.15, "pixiu actual checkout amount bonus")
	m = fresh(819)
	m.state.stage = 1
	m.state.cash = 1000.0
	add_employee(m, "bai_ze")
	var baize_training: Dictionary = m.full_rules.perform("train_attribute", {"employee_id":"xian_yang","attribute":"cooking"})
	check(bool(baize_training.get("ok", false)), "training with baize starts")
	check(int(baize_training.get("due", 0)) - int(m.state.total_minutes) == 21, "baize uses literal 0.67 duration multiplier with upward rounding")
	m.advance_minutes(21)
	var baize_research: Dictionary = m.full_rules.perform("research", {"dish_id":"qianyang_soup","employee_id":"xian_yang"})
	check(bool(baize_research.get("ok",false)), "research with baize starts")
	check(bool(m.state.management.projects[0].get("guaranteed",false)), "baize makes real research guaranteed")
	m.advance_minutes(31)
	check("qianyang_soup" in m.state.unlocked_dishes, "baize research produces recipe")
	m = fresh(820)
	add_employee(m, "zhu_long")
	var shift: Dictionary = m.full_rules.world.perform("zhulong_shift", {"period":"dinner"})
	check(bool(shift.get("ok",false)), "zhulong active shift changes traffic period")
	check(str(m.state.world.zhulong_period) == "dinner", "zhulong stores chosen traffic period")
	check(not bool(m.full_rules.world.perform("zhulong_shift", {"period":"lunch"}).get("ok",false)), "zhulong limited once per day")
	print("CAMPAIGN CHECKS: %d passed, %d failed" % [checks - failures, failures])
	quit(1 if failures > 0 else 0)
