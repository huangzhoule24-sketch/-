extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init() -> void:call_deferred("run")
func expect(ok: bool,message: String) -> void:
	checks+=1
	if not ok:failures+=1;push_error(message)
func find(node: Node,id: String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var result=find(child,id)
		if result!=null:return result
	return null
func click(ui,id: String) -> void:
	var control=find(ui,id)
	if control==null:
		for b in ui._qa_buttons:
			if is_instance_valid(b) and not b.is_queued_for_deletion() and str(b.get_meta("qa_id",""))==id:control=b;break
	expect(control!=null and not control.disabled,"Visible enabled control: "+id)
	if control!=null and not control.disabled:control.pressed.emit()
	await process_frame
func settle() -> void:
	for i in range(4):await process_frame
func run() -> void:
	root.size=Vector2i(1440,900)
	var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	ui.model.state.cash=10000
	ui.open_panel("员工");await settle()
	expect(ui.training_status.text=="培训×0" and ui.live_status.text.contains("食材"),"Top live numbers exist without opening a management screen")
	await click(ui,"employee:detail:xian_yang")
	expect(ui.panel_name=="员工详情" and find(ui,"shift:xian_yang:rest")!=null,"One employee click reaches direct schedule controls")
	await click(ui,"employee:training:xian_yang")
	expect(find(ui.modal_body,"full:train_attribute:xian_yang")!=null and find(ui.modal_body,"full:train_attribute:xiao")==null,"Second employee click trains only selected employee")
	ui.open_panel("员工");ui.open_panel("中央厨房");await settle()
	expect(ui.panel_name=="员工" and is_instance_valid(ui._requirement_dialog) and ui._requirement_dialog.dialog_text.contains("阶段3"),"Locked jump retains current screen and gives stage thresholds")
	await click(ui,"requirement:ack");await settle()
	ui.model.state.stage=1;ui.open_panel("装修");await settle()
	await click(ui,"place:table_two")
	expect(ui.map_view.placement_id=="table_two" and not is_instance_valid(ui._requirement_dialog),"Equipment can be previewed before assigning the builder")
	ui.cancel_placement();await settle()
	var selector=find(ui,"decor:builder");expect(selector!=null and selector.item_count>=3,"Construction lists actual eligible idle staff")
	selector.select(2);selector.item_selected.emit(2)
	await click(ui,"place:table_two")
	var point=Vector2i(-1,-1)
	for y in range(5):
		for x in range(8):
			if ui.model.can_place_decoration("table_two",x,y):point=Vector2i(x,y);break
	ui.place_decoration("table_two",point.x,point.y);await settle()
	expect(ui.model.state.revision171.builds.size()==1 and not ui.model.state.revision171.builds[0].active,"Placement previews a reserved construction site")
	ui.finish_decoration(true);await settle()
	expect(ui.model.state.revision171.builds[0].active and ui.building_status.text.contains("施工60分"),"Commit starts assigned construction and top live status")
	ui.model.employees.append(ui.model._create_employee(ui.model._employee_config("guan_guan")));ui.model.full_rules.ensure_state_defaults();ui.open_panel("员工");await settle()
	await click(ui,"employee:dismiss:guan_guan")
	expect(is_instance_valid(ui._action_dialog) and ui._action_dialog.dialog_text.contains("遣散费100"),"Dismissal presents exact compensation before charging")
	var before=float(ui.model.state.cash)
	await click(ui,"dismiss:confirm")
	expect(ui.model._employee("guan_guan").is_empty() and ui.model.state.cash<before,"Actual confirmation removes employee and charges compensation")
	ui.model.full_rules.world._enqueue("ranyiyu_vision",{})
	ui.revision_ui.poll(0);ui.close_panel();await settle()
	expect(ui.panel_name=="事件" and ui.model.paused,"Notice cannot be dismissed to resume time")
	var pending=ui.model.pending_event();await click(ui,"event:"+str(pending.id)+":0")
	expect(ui.panel_name=="事件结果" and not ui.revision_ui.feedback.is_empty(),"Notice confirmation displays actual changes")
	await click(ui,"event:result:ack")
	ui.model.events.clear();ui.model.state.total_minutes=1439;ui.model.advance_minutes(1);ui.revision_ui.poll(0);await settle()
	expect(ui.panel_name=="今日收支结算" and find(ui,"daily:ack")!=null,"Real close of day forces itemized cash report")
	ui.model.full_rules.perform("daily_auto",{"enabled":false})
	var stopped=int(ui.model.state.total_minutes)
	ui.model.set_paused(false);ui.model.advance_minutes(10)
	expect(ui.model.state.total_minutes==stopped,"Disabling future automatic reports cannot bypass current pending acknowledgment")
	ui.close_panel();expect(ui.panel_name=="今日收支结算","Daily report waits for explicit confirmation")
	await click(ui,"daily:ack")
	expect(ui.model.state.revision171.daily_seen==1 and ui.panel_name.is_empty(),"Report acknowledgment resumes gameplay without recurring popup")
	ui.open_panel("图鉴");await click(ui,"catalog:特殊顾客")
	expect(ui.full_panels.catalog_tab=="特殊顾客" and ui.modal_body.get_child_count()>=7,"Special guest collection is a tab alongside employees and dishes")
	ui.open_panel("美术资源");await settle()
	expect(ui._art_culture_slots.item_count>=82,"53 cultural slots plus12 guest slots and2 pickup slots and manual path remain importable")
	ui.queue_free();await settle()
	print("V1.7.1 actual UI: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
