extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Identity=preload("res://scripts/services/employee_identity.gd")
const Notifications=preload("res://scripts/ui/action_notifications.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func fresh():
	var model=Model.new(193021);model.start_full();model.events.clear();model.balance["customer.base_flow"]=0;return model
func run():
	var m=fresh();var names: Array=[];var ranks: Array=[];var rank={"N":0,"R":1,"SR":2,"SSR":3}
	for employee in m.catalog:
		names.append(str(employee.id));ranks.append(rank[str(employee.rarity)])
		expect(employee.id in ["xian_yang","xiao","er_shu","guan_guan","e_shou","tao_tie","ran_yi_yu","dang_kang","tian_gou","gu_diao","xuan_gui","qing_fu","jiu_wei_hu","bi_fang","pi_xiu","ying_zhao","lu_wu","jing_wei","qiong_qi","tao_wu","hun_dun","xie_zhi","qing_geng","tian_lu","feng_huang","bai_ze","ying_long","zhu_long","di_jiang","jiu_ying"],"Employee uses specified pinyin ID: "+str(employee.name))
	var ordered=ranks.duplicate();ordered.sort();expect(ordered==ranks and names.size()==30,"Encyclopedia catalogue orders all30 employees by N/R/SR/SSR")
	expect(m.full_rules.dollhouse.fixtures("stove").size()==2 and m.full_rules.dollhouse.fixtures("cashier").size()==1,"Starting equipment still supports two cooks and one real checkout")
	m.state.unlocked_dishes.append("qianyang_soup");m.state.menu_enabled=["qianyang_soup"]
	m.full_rules.management.purchase("generic",100);m.full_rules.management.add_item("qingqiu_milk",50)
	m.balance["customer.tip_chance"]=0;m.balance["coeff.charm_tip"]=0;m.balance["customer.escape_probability"]=0
	m._spawn_customer();var saw_order=false;var saw_pay=false;var retired=false
	for minute in range(260):
		m.advance_minutes(1)
		for c in m.customers:
			retired=retired or str(c.stage)=="recommending"
			if c.stage=="ordering" and int(c.due_minute)>0:saw_order=str(c.worker)=="er_shu" and c.task_motion.action=="Order"
			if c.stage=="paying" and int(c.due_minute)>0:saw_pay=str(c.worker)=="er_shu"
		if int(m.state.served)>0:break
	expect(saw_order and saw_pay and not retired,"Initial waiter independently performs Order and Cashier without a salesperson")
	expect(int(m.state.served)==1 and int(m.state.customer_service.today.recommend_attempts)==0,"Premium dish completes a real sale without recommendation work")
	var waiter=m._employee("er_shu");waiter.attributes.calculation=100
	expect(m.full_rules.effects.cashier_factor(waiter)==1,"Basic waiter checkout does not gain salesperson calculation bonus")
	var fast=Model.AnimationRules.animation_factor(waiter,"Cashier",m.balance);waiter.attributes.speed+=5
	expect(Model.AnimationRules.animation_factor(waiter,"Cashier",m.balance)>fast,"Basic checkout speed follows waiter speed")
	var salesperson=m._create_employee(m._employee_config("guan_guan"));salesperson.attributes.calculation=10
	expect(m.full_rules.effects.cashier_factor(salesperson)>1,"Salesperson retains efficient calculation-based checkout")
	var dish=m._dish("qianyang_soup");var a=m.full_rules.customer_service.price_quote(dish,90,{"type":"human"},{},{})
	var b=m.full_rules.customer_service.price_quote(dish,90,{"type":"human","recommendation_premium":10},{"charm":10,"eloquence":10},{})
	expect(a.final==b.final and b.per_customer_bonus==0,"Neither legacy recommendation nor personal charm/eloquence raises the dish price")
	m=fresh();var notes=Notifications.new(m);notes.update();var guide=preload("res://scripts/core/tutorial_progress.gd").current(m)
	expect(str(guide.id)=="welcome" and str(notes.primary().get("id","")).begins_with("stage_task:"),"Stage todo coexists with the separate welcome tutorial")
	expect(notes.entries("guides").is_empty(),"Teaching tasks do not enter todo notifications")
	m.state.sidequests.lore_unlocked.append("sample");notes.update()
	expect(not notes.entries().any(func(entry):return "lore" in str(entry.id)),"World lore does not create action dots or a stage todo")
	m=fresh();m.state.stage=1;m.state.cash=10000;var e=m._employee("er_shu");e.secondary_role="chef"
	var swap=m.full_rules.perform("switch_role",{"id":"er_shu","role":"chef"})
	expect(swap.ok and e.primary_role=="chef" and e.secondary_role=="waiter" and m.full_rules.dollhouse.capable(e,"waiter"),"Changing primary occupation preserves the trained secondary capability")
	# Actual prior release save, kept as immutable compressed bytes.
	var input=FileAccess.get_file_as_bytes("res://tests/fixtures/v191-day66-save.json.gz").decompress_dynamic(64*1024*1024,FileAccess.COMPRESSION_GZIP)
	var old: Dictionary=JSON.parse_string(input.get_string_from_utf8());var path="/tmp/shanhai-v193-legacy.json";var file=FileAccess.open(path,FileAccess.WRITE);file.store_buffer(input);file.close()
	m=Model.new(10);m.start_full();expect(m.load_game(path),"Actual v1.9.1 day66 campaign loads with canonical IDs")
	expect(m.state.cash==old.state.cash and m.state.total_revenue==old.state.total_revenue and m.employees.size()==old.employees.size(),"Migration preserves earned cash, revenue and roster size")
	expect(str(m._rng.state)==str(old.rng_state) and m.scheduler==Identity.migrate(old.scheduler),"Migration preserves RNG and every paid scheduler deadline")
	for entry in old.employees:
		var employee=m._employee(Identity.canonical(str(entry.id)))
		expect(not employee.is_empty() and employee.attributes==entry.attributes,"Earned attributes survive ID change for "+str(entry.name))
	expect(m.save_game(path),"Migrated full campaign saves again")
	var restored=Model.new(11);restored.start_full();expect(restored.load_game(path) and restored._rng.state==m._rng.state,"Canonical second roundtrip remains strict and stable")
	DirAccess.remove_absolute(path)
	legacy_recommendation()
	print("V1.9.3 rules: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)

func old_ids(value: Variant) -> Variant:
	if value is Dictionary:
		var out: Dictionary={}
		for key in value:out[old_ids(key)]=old_ids(value[key])
		return out
	if value is Array:
		var out: Array=[]
		for item in value:out.append(old_ids(item))
		return out
	if value is String:return Identity.legacy(value)
	return value
func write_payload(path: String,payload: Dictionary):
	var file=FileAccess.open(path,FileAccess.WRITE);file.store_string(JSON.stringify(payload));file.close()
func legacy_recommendation():
	var m=fresh();m.employees.append(m._create_employee(m._employee_config("guan_guan")));m.full_rules.ensure_state_defaults()
	m._spawn_customer("noodles");var c=m.customers[0];c.arrival_due=0;m._assign_tasks()
	var former=m._employee(str(c.worker));former.busy_customer=0;former.busy_until=0
	var sales=m._employee("guan_guan");sales.motion=c.task_motion.duplicate(true);sales.motion.action="Recommend";sales.busy_customer=int(c.id);sales.busy_until=int(c.due_minute)
	c.worker="guan_guan";c.stage="recommending";c.task_motion.action="Recommend"
	for event in m.scheduler:event.stage="recommending";event.employee_id="guan_guan"
	var path="/tmp/shanhai-v193-old-recommend.json";m.save_game(path);var payload=old_ids(JSON.parse_string(FileAccess.get_file_as_string(path)));write_payload(path,payload)
	var n=Model.new(8);n.start_full();expect(n.load_game(path),"Legacy active Recommend with original IDs still passes strict loading")
	expect(str(n._rng.state)==str(payload.rng_state) and int(n.customers[0].due_minute)==int(payload.customers[0].due_minute),"Active legacy work retains its RNG and paid deadline")
	n.events.clear();n.balance["customer.base_flow"]=0;n.advance_minutes(int(n.customers[0].due_minute)-int(n.state.total_minutes))
	expect(n.customers[0].stage!="recommending" and int(n.state.customer_service.today.recommend_attempts)==0,"Legacy recommendation ends once without a new recommendation result")
	# A formerly suspended recommendation must become an ordinary order, rather than wait forever.
	payload.customers[0].due_minute=-1;payload.customers[0].worker="";payload.customers[0].remaining_minutes=2;payload.customers[0].erase("device_uid");payload.scheduler=[]
	for employee in payload.employees:employee.busy_customer=0;employee.busy_until=0
	write_payload(path,payload);n=Model.new(9);n.start_full()
	expect(n.load_game(path) and n.customers[0].stage=="ordering" and int(n.customers[0].remaining_minutes)==0,"Suspended legacy recommendation migrates to the normal waiter order path")
	DirAccess.remove_absolute(path)
