extends SceneTree
## Isolated fixtures: no user:// files, no normal-save mutations.

const Expansion = preload("res://scripts/core/expansion_rules.gd")
var checks := 0
var failures := 0

class Inventory extends RefCounted:
	var quantities := {"generic": 1000.0}
	var recognized_cost := 0.0
	func dish_quality(_id: String) -> float: return 75.0
	func modifiers(_id: String, _employee: Dictionary = {}) -> Dictionary: return {"quality_mult":1.0}
	func skill_multiplier(_employee: Dictionary) -> float: return 1.0
	func can_make(_dish_id: String, multiplier: float = 1) -> bool:
		return float(quantities.generic) >= multiplier
	func consume(dish_id: String, multiplier: float = 1, recognize_cogs: bool = true) -> Dictionary:
		if not can_make(dish_id, multiplier): return {"ok": false}
		quantities.generic = float(quantities.generic) - multiplier
		if recognize_cogs: recognized_cost += multiplier * 2
		return {"ok": true, "cost": multiplier * 2, "items": {"generic": multiplier}}
	func recognize_cost(cost: float) -> bool:
		recognized_cost += cost
		return true
	func add_item(id: String, quantity: float, _cost: float = 0) -> bool:
		quantities[id] = float(quantities.get(id, 0)) + quantity
		return true

class WorldStub extends RefCounted:
	func active_bonds() -> Array: return []
class EffectsStub extends RefCounted:
	func dish_weight(_id: String) -> float: return 1.0
class FinanceStub extends RefCounted:
	var sales: float = 0.0
	func record_sale(gross: float, _tips: float = 0.0) -> void: sales += gross

class Rules extends RefCounted:
	var management := Inventory.new()
	var world := WorldStub.new()
	var effects := EffectsStub.new()
	var finance := FinanceStub.new()
	var customer_service: Variant
	var preferences: Variant
	func checkout_multiplier(_employee: Dictionary) -> float: return 1.0
	func tip_bonus(_employee: Dictionary) -> float: return 0.0
	func active(_id: String) -> bool: return true
	var records: Array = []
	func record(kind: String, amount: float, memo: String) -> void:
		records.append({"kind": kind, "amount": amount, "memo": memo})

class Host extends RefCounted:
	var balance: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://config/global_balance.json"))
	var state := {"total_minutes": 360, "cash": 100000.0, "gems": 100, "stage": 0, "served": 0, "daily_revenue": 0.0, "total_revenue": 0.0, "reputation": 2000, "fragments": {"xian_yang": 20}, "unlocked_dishes": ["noodles", "phoenix_soup"], "menu_enabled": ["noodles"]}
	var employees: Array = []
	var catalog := [{"id": "xian_yang"}, {"id": "xiao"}]
	var dishes := [{"id": "noodles", "price": 8, "cook_minutes": 8}, {"id": "phoenix_soup", "price": 88, "cook_minutes": 20}]
	var full_rules := Rules.new()
	var _rng := RandomNumberGenerator.new()
	func _init() -> void:
		_rng.seed = 211
		full_rules.preferences = load("res://scripts/core/customer_preferences.gd").new(self)
		full_rules.customer_service = load("res://scripts/core/customer_service.gd").new(self)
		full_rules.customer_service.ensure_state()
		balance["customer.tip_chance"] = 0.0
		for id in ["xian_yang", "xiao", "feng_huang"]:
			employees.append({"id": id, "name": id, "role": "waiter" if id == "xiao" else "chef", "attributes": {"cooking": 10 if id == "feng_huang" else 2, "creativity": 10 if id == "feng_huang" else 2, "speed": 3}, "stamina": 100.0, "mood": 100.0, "training_until": 0, "research_until": 0, "busy_customer": 0, "resting": false})
	func _b(key: String) -> float: return float(balance.get(key,0))
	func _money(amount: float) -> float: return snappedf(amount,0.01)
	func change_cash(delta: float, _category: String, _description: String) -> float:
		var before: float = float(state.cash)
		state.cash = _money(before+delta)
		return float(state.cash)-before
	func _roll_customer_type() -> String: return "human"
	func _employee(id: String) -> Dictionary:
		for employee in employees:
			if str(employee.id) == id: return employee
		return {}
	func _dish(id: String) -> Dictionary:
		for dish in dishes:
			if str(dish.id) == id: return dish
		return {}
	func _log(_message: String) -> void: pass
	func business_open() -> bool:
		return int(state.total_minutes) % 1440 >= 360
	func period() -> String:
		return "closed" if not business_open() else "normal"


func _expect(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + label)


func _step(host: Host, rules: RefCounted, minutes: int) -> void:
	for _minute in minutes:
		host.state.total_minutes = int(host.state.total_minutes) + 1
		rules.tick_minute()


func _actual_integration() -> void:
	var model_script: Script = load("res://scripts/core/game_model.gd")
	var game: Variant = model_script.new(941)
	game.start_full()
	game.paused = true
	game.state.stage = 3
	game.state.cash = 50000
	game.state.gems = 30
	var expansion: RefCounted = game.full_rules.expansion
	_expect(bool(game.full_rules.management.purchase("generic", 200).ok), "real inventory procurement interface")
	_expect(bool(expansion.perform("central_unlock").ok), "real central construction integration")
	_expect(bool(expansion.perform("branch_open", {"id": "human_east"}).ok), "real branch construction integration")
	_expect(bool(expansion.perform("central_cook", {"dish_id": "noodles", "quantity": 10, "employee_id": "xian_yang"}).ok), "real inventory to central WIP")
	_expect(expansion.validate_state(game.state, game.employees), "real WIP validates")
	var path := "/tmp/shanhai-expansion-test-%d.json" % get_instance_id()
	_expect(game.save_game(path), "real WIP saves to isolated test path")
	_expect(game.load_game(path), "real WIP reloads with full validator")
	for _minute in 30:
		game.state.total_minutes = int(game.state.total_minutes) + 1
		expansion.tick_minute()
	_expect(int(expansion.snapshot().central.stock.get("noodles", 0)) == 10, "real WIP becomes prepared stock after reload")
	_expect(bool(expansion.perform("supply_send", {"id": "human_east", "dish_id": "noodles", "quantity": 10}).ok), "real prepared shipment dispatch")
	_expect(game.save_game(path), "real in-transit shipment saves")
	_expect(game.load_game(path), "real in-transit shipment reloads")
	_expect(bool(expansion.perform("branch_assign", {"id": "human_east", "employee_id": "xian_yang"}).ok), "real chef assigned to branch")
	var front_id := ""
	for employee in game.employees:
		if str(employee.role) == "waiter": front_id = str(employee.id)
	_expect(bool(expansion.perform("branch_assign", {"id": "human_east", "employee_id": front_id}).ok), "real front staff assigned to branch")
	var chef: Dictionary = game._employee("xian_yang")
	chef.stamina = 0.0
	for _minute in 505:
		game.state.total_minutes = int(game.state.total_minutes) + 1
		game._tick_employees()
		expansion.tick_minute()
	_expect(not bool(chef.get("branch_recovering", false)), "exhausted branch chef finishes automatic recovery")
	_expect(float(chef.stamina) < 100 and float(chef.stamina) > 95, "recovered branch chef resumes work instead of infinite recovery")
	var before_work := float(chef.stamina)
	for _minute in 30:
		game.state.total_minutes = int(game.state.total_minutes) + 1
		game._tick_employees()
		expansion.tick_minute()
	_expect(float(chef.stamina) < before_work, "assigned branch staff accumulate real work fatigue")
	_expect(int(expansion.snapshot().branches.human_east.served) > 0, "real branch serves after recovering chef returns")
	game.employees.erase(chef)
	game.state.expansion.branches.human_east.next_order = int(game.state.total_minutes)
	expansion.tick_minute()
	_expect(int(expansion._branch_staff("human_east").chefs) == 0, "departed branch staff leave no phantom capacity")
	_expect(expansion.validate_state(game.state, game.employees), "departed branch staff leave no stale save references")
	_expect(game.save_game(path) and game.load_game(path), "branch after staff departure saves and reloads")
	DirAccess.remove_absolute(path)


func _league_integration() -> void:
	var host := Host.new()
	var rules := Expansion.new(host)
	rules.ensure_state()
	var initial: Array = rules.leaderboard()
	_expect(initial.size() == 13, "world competition includes twelve independent NPC companies")
	var baseline: Dictionary = host.state.expansion.league.duplicate(true)
	host.state.total_revenue += 10000
	host.state.reputation += 100
	host.state.expansion.competition.wins = 1
	var player_row: Dictionary = rules.leaderboard().filter(func(row: Dictionary) -> bool: return bool(row.player))[0]
	_expect(float(player_row.score) == 2200, "player season score uses actual revenue reputation and one championship bonus")
	host.state.total_minutes = 1440
	rules.on_day()
	var league: Dictionary = host.state.expansion.league
	_expect(float(league.companies.kunlun.revenue) > 0 and float(league.companies.kunlun.costs) > 0, "NPC companies settle real simulated daily sales and expenses")
	_expect(float(league.companies.kunlun.daily_profit) != 0 and int(league.companies.kunlun.reputation) > 0, "NPC operating result changes cash and reputation")
	var after_day: Dictionary = league.duplicate(true)
	rules.on_day()
	_expect(league == after_day, "repeated daily settlement cannot duplicate NPC operations")
	var first_daily_revenue := float(league.companies.kunlun.daily_revenue)
	host.state.total_minutes = 2880
	rules.on_day()
	_expect(float(league.companies.kunlun.daily_revenue) != first_daily_revenue, "NPC daily performance responds to market and company growth")
	# Resume the same saved season in another host; no simulation randomness is rerolled.
	var resumed_host := Host.new()
	resumed_host.state = JSON.parse_string(JSON.stringify(host.state))
	resumed_host.employees = JSON.parse_string(JSON.stringify(host.employees))
	var resumed := Expansion.new(resumed_host)
	resumed.ensure_state()
	_expect(JSON.stringify(resumed.leaderboard()) == JSON.stringify(rules.leaderboard()), "league save roundtrip preserves scores")
	for day in range(3, 31):
		host.state.total_minutes = day * 1440
		rules.on_day()
		resumed_host.state.total_minutes = day * 1440
		resumed.on_day()
	_expect(league == resumed_host.state.expansion.league, "resumed NPC company simulation remains deterministic")
	_expect(int(league.season) == 2 and league.history.size() == 1, "thirty game days close and archive one season")
	_expect(int(league.history[0].player_rank) >= 1 and league.history[0].rows.size() == 13, "season history preserves complete player ranking")
	_expect(float(league.companies.kunlun.revenue) == 0 and int(league.companies.kunlun.branches) > int(baseline.companies.kunlun.branches), "season revenue resets while earned NPC expansion persists")
	player_row = rules.leaderboard().filter(func(row: Dictionary) -> bool: return bool(row.player))[0]
	_expect(float(player_row.score) == 0, "new season excludes prior revenue reputation and crown bonus")
	_expect(rules.validate_state(host.state, host.employees), "archived league passes save validation")
	var corrupt: Dictionary = host.state.duplicate(true)
	corrupt.expansion.league.companies.kunlun.cash = -1
	_expect(not rules.validate_state(corrupt, host.employees), "negative NPC company cash is rejected before load")
	corrupt = host.state.duplicate(true)
	corrupt.expansion.league.history[0].player_rank = 0
	_expect(not rules.validate_state(corrupt, host.employees), "corrupt archived ranking is rejected before load")
	corrupt = host.state.duplicate(true)
	corrupt.expansion.erase("league")
	_expect(rules.validate_state(corrupt, host.employees), "older saves without fabricated NPC history remain loadable")
	var rng_host := Host.new()
	rng_host.state = host.state.duplicate(true)
	var rng_rules := Expansion.new(rng_host)
	var rng_state := rng_host._rng.state
	rng_host.state.total_minutes = 31 * 1440
	rng_rules.on_day()
	_expect(rng_host._rng.state == rng_state, "NPC company operations preserve the player recruitment random sequence")


func _actual_return_capacity() -> void:
	var model_script: Script = load("res://scripts/core/game_model.gd")
	var game: Variant = model_script.new(432)
	game.start_full()
	game.state.stage = 3
	game.state.cash = 50000
	game.employees.clear()
	for definition in game.catalog.slice(0, 13): game.employees.append(game._create_employee(definition))
	game.full_rules.ensure_state_defaults()
	var expansion: RefCounted = game.full_rules.expansion
	_expect(bool(expansion.perform("branch_open", {"id": "human_east"}).ok), "capacity test branch opens through real API")
	var id := str(game.employees[0].id)
	_expect(bool(expansion.perform("branch_assign", {"id": "human_east", "employee_id": id}).ok), "capacity test assigns active employee through real API")
	_expect(game.full_rules.staffed_count() == game.full_rules.active_limit(), "main shop is exactly at its twelve employee stage limit")
	var result: Dictionary = expansion.perform("branch_return", {"employee_id": id})
	_expect(bool(result.ok) and str(game._employee(id).branch_id).is_empty(), "branch employee may return while main roster is full")
	_expect(bool(game._employee(id).resting) and game.full_rules.staffed_count() == game.full_rules.active_limit(), "branch return preserves full main shop capacity by resting")
	_expect(str(result.message).contains("当班容量已满"), "branch return explains why returned employee is resting")
	game.set_employee_rest(str(game.employees[1].id), true)
	game.set_employee_rest(id, false)
	_expect(not bool(game._employee(id).resting) and game.full_rules.staffed_count() == game.full_rules.active_limit(), "returned employee can work after the player frees one real slot")


func _initialize() -> void:
	var host := Host.new()
	var rules := Expansion.new(host)
	rules.ensure_state()
	_expect(not bool(rules.perform("membership_enable").ok), "membership stage gate")
	_expect(not bool(rules.perform("branch_open", {"id": "human_east"}).ok), "branch stage gate")
	host.state.stage = 2
	var cash := float(host.state.cash)
	_expect(bool(rules.perform("membership_enable").ok), "membership enable")
	_expect(float(host.state.cash) == cash - 120, "membership real setup cost")
	_expect(not bool(rules.perform("membership_enable").ok), "duplicate membership cannot charge")
	host.state.served = 12
	rules.tick_minute()
	_expect(int(host.state.expansion.membership.members) == 4, "membership needs actual paid orders")
	_expect(int(host.state.expansion.membership.points) == 60, "points earned from real service")
	rules.tick_minute()
	_expect(int(host.state.expansion.membership.points) == 60, "observed service cannot award twice")
	_expect(bool(rules.perform("member_redeem").ok), "redeem points")
	_expect(not bool(rules.perform("member_redeem").ok), "outstanding voucher prevents stacking")
	_expect(rules.checkout_adjustment(100) == 90, "voucher reduces actual checkout")
	_expect(rules.checkout_adjustment(100) == 100, "voucher is single use")
	_expect(bool(rules.perform("campaign", {"id": "food_festival"}).ok), "marketing campaign")
	_expect(rules.traffic_bonus() > 0.3, "membership and campaign affect traffic")
	_expect(not bool(rules.perform("campaign", {"id": "food_festival"}).ok), "campaign non stacking")
	_expect(bool(rules.perform("delivery_toggle", {"enabled": true}).ok), "delivery enabled")
	rules.tick_minute()
	var offer: Dictionary = host.state.expansion.delivery_offer.duplicate(true)
	_expect(not offer.is_empty(), "real delivery offer")
	var ingredients := float(host.full_rules.management.quantities.generic)
	cash = float(host.state.cash)
	_expect(bool(rules.perform("delivery_accept", {"offer_id": str(offer.id), "employee_id": "xian_yang"}).ok), "accept delivery")
	_expect(float(host.full_rules.management.quantities.generic) == ingredients - 1, "delivery consumes ingredients")
	_expect(float(host.state.cash) == cash - 2, "delivery charges courier before payment")
	_expect(float(host.full_rules.management.recognized_cost) == 0, "unfulfilled delivery holds cost as inventory")
	_expect(int(host._employee("xian_yang").expansion_until) > int(host.state.total_minutes), "delivery occupies chef")
	_expect(not bool(rules.perform("delivery_accept", {"offer_id": str(offer.id)}).ok), "cannot accept same delivery twice")
	_step(host, rules, 27)
	_expect(float(host.state.cash) == cash - 2, "no delivery payment before arrival")
	_step(host, rules, 1)
	_expect(is_equal_approx(float(host.state.cash), cash - 2 + 7.04), "delivery net commission arrival")
	_expect(int(host.state.expansion.delivery_completed) == 1, "delivery completed once")
	_expect(float(host.full_rules.management.recognized_cost) == 2, "fulfilled delivery recognizes COGS once")
	_expect(float(host.state.total_revenue) == 8, "delivery commission is expense rather than hidden sales reduction")
	_expect(host.full_rules.records.any(func(record: Dictionary) -> bool: return record.kind == "cost_of_sales" and float(record.amount) == 2), "delivery transfers inventory cost to cost of sales")
	rules.tick_minute()
	_expect(int(host.state.expansion.delivery_completed) == 1, "delivery reward not repeatable")
	_expect(int(host._employee("xian_yang").expansion_until) == 0, "chef returns from delivery")
	host.state.stage = 3
	_expect(bool(rules.perform("branch_open", {"id": "human_east"}).ok), "open human branch")
	_expect(not bool(rules.perform("branch_open", {"id": "human_east"}).ok), "duplicate branch investment blocked")
	_expect(not bool(rules.perform("branch_open", {"id": "demon"}).ok), "realm stage gate")
	cash = float(host.state.cash)
	_step(host, rules, 30)
	_expect(float(host.state.cash) == cash, "branch without workers and stock earns nothing")
	_expect(bool(rules.perform("branch_assign", {"id": "human_east", "employee_id": "xian_yang"}).ok), "assign branch chef")
	_expect(bool(host._employee("xian_yang").resting), "branch employee excluded from main shop")
	_expect(not bool(rules.perform("branch_assign", {"id": "human_east", "employee_id": "xian_yang"}).ok), "employee cannot work two branches")
	_expect(bool(rules.perform("branch_assign", {"id": "human_east", "employee_id": "xiao"}).ok), "assign front staff")
	var front: Dictionary = host._employee("xiao")
	front.branch_recovering = true
	_expect(not "xiao" in rules._branch_staff("human_east").staff, "recovering branch staff are excluded from sales fatigue")
	front.branch_recovering = false
	front.shift_enabled = true
	front.shift_periods = ["lunch"]
	_expect(not "xiao" in rules._branch_staff("human_east").staff, "off shift branch staff are excluded from sales fatigue")
	front.shift_enabled = false
	_expect(bool(rules.perform("central_unlock").ok), "central construction")
	ingredients = float(host.full_rules.management.quantities.generic)
	_expect(bool(rules.perform("central_cook", {"dish_id": "noodles", "quantity": 10, "employee_id": "feng_huang"}).ok), "central batch cooking")
	_expect(float(host.full_rules.management.quantities.generic) == ingredients - 10, "central kitchen consumes batch raw ingredients")
	_expect(int(host.state.expansion.central.stock.get("noodles", 0)) == 0, "central WIP not available early")
	_expect(rules.prepared_inventory_value() == 20, "central WIP remains an inventory asset")
	_expect(float(host.full_rules.management.recognized_cost) == 2, "central WIP does not prematurely recognize COGS")
	_step(host, rules, 30)
	_expect(int(host.state.expansion.central.stock.noodles) == 10, "central completion adds exact count")
	_expect(bool(rules.perform("supply_send", {"id": "human_east", "dish_id": "noodles", "quantity": 8}).ok), "supply shipment dispatch")
	_expect(int(host.state.expansion.central.stock.noodles) == 2, "shipment removes central stock immediately")
	_expect(rules.prepared_inventory_value() == 20, "internal transfer preserves total inventory value")
	_expect(int(host.state.expansion.branches.human_east.stock.get("noodles", 0)) == 0, "shipment not teleport stock")
	cash = float(host.state.cash)
	_step(host, rules, 20)
	_expect(int(host.state.expansion.branches.human_east.stock.noodles) > 0, "shipment arrives")
	_step(host, rules, 30)
	_expect(float(host.state.cash) > cash, "staffed branch sells supplied dishes")
	_expect(int(host.state.expansion.branches.human_east.stock.noodles) < 8, "branch sales consume finite stock")
	_expect(rules.prepared_inventory_value() < 20, "branch sale releases stock book value")
	_expect(not bool(rules.perform("supply_send", {"id": "human_east", "dish_id": "noodles", "quantity": 10}).ok), "cannot over ship central stock")
	_expect(bool(rules.perform("branch_return", {"employee_id": "xian_yang"}).ok), "return branch staff")
	_expect(str(host._employee("xian_yang").branch_id).is_empty(), "branch return resets assignment")
	var gems := int(host.state.gems)
	_expect(bool(rules.perform("explore", {"employee_id": "xian_yang"}).ok), "exploration dispatch")
	_expect(int(host.state.gems) == gems - 2, "exploration spends scarce gems")
	var payload: Dictionary = host.state.expansion.explorations[0].duplicate(true)
	_expect(rules.validate_state(host.state, host.employees), "pending operations validate before reload")
	var corrupt: Dictionary = host.state.duplicate(true)
	corrupt.expansion.explorations[0].due = -2
	_expect(not rules.validate_state(corrupt, host.employees), "malformed delayed operation rejected")
	var bad_employees: Array = host.employees.duplicate(true)
	bad_employees[0].expansion_job_id = "missing_job"
	_expect(not rules.validate_state(host.state, bad_employees), "orphan employee assignment rejected")
	# Emulate JSON save/reload without touching the user's files.
	host.state = JSON.parse_string(JSON.stringify(host.state))
	host.employees = JSON.parse_string(JSON.stringify(host.employees))
	var reloaded := Expansion.new(host)
	reloaded.ensure_state()
	_step(host, reloaded, 120)
	_expect(host.state.expansion.explorations.is_empty(), "saved exploration completes after reload")
	_expect(host.state.expansion.exploration_history.size() == 1, "exploration history written once")
	for item in payload.reward.items:
		_expect(float(host.full_rules.management.quantities.get(item, 0)) >= float(payload.reward.items[item]), "exploration rewards match saved roll: " + str(item))
	var gems_after := int(host.state.gems)
	reloaded.tick_minute()
	_expect(int(host.state.gems) == gems_after, "exploration reward cannot duplicate")
	host.state.stage = 4
	var cooking := float(host._employee("xian_yang").attributes.cooking)
	_expect(bool(reloaded.perform("awaken", {"employee_id": "xian_yang"}).ok), "awakening")
	_expect(float(host._employee("xian_yang").attributes.cooking) == cooking + 2, "awakening affects true worker attributes")
	_expect(str(host._employee("xian_yang").appearance_state) == "awakened", "awakening leaves art state hook")
	_expect(bool(reloaded.perform("awaken", {"employee_id": "xian_yang"}).ok), "another paid awakening raises the level cap again")
	_expect(bool(reloaded.perform("compete", {"employee_id": "feng_huang", "dish_id": "phoenix_soup"}).ok), "competition entry")
	_expect(not bool(reloaded.perform("compete", {"employee_id": "feng_huang", "dish_id": "phoenix_soup"}).ok), "competition cannot overlap")
	_step(host, reloaded, 90)
	_expect(bool(host.state.expansion.competition.last_result.won), "attributes and dish produce winning score")
	_expect(bool(host.state.expansion.competition.first_reward_claimed), "first win recorded")
	_expect(reloaded.validate_state(host.state, host.employees), "completed state validates")
	cash = float(host.state.cash)
	reloaded.tick_minute()
	_expect(float(host.state.cash) == cash, "competition prize cannot repeat")
	_expect(not bool(reloaded.perform("compete", {"employee_id": "feng_huang", "dish_id": "phoenix_soup"}).ok), "competition cooldown")
	_expect(str(reloaded.snapshot().leaderboard_label).contains("模拟"), "leaderboard explicitly labels simulated opponents")
	var branch: Dictionary = host.state.expansion.branches.human_east
	var minute_before := int(host.state.total_minutes)
	host.state.total_minutes = 1440
	cash = float(host.state.cash)
	reloaded.on_day()
	_expect(float(host.state.cash) == cash - 100, "daily branch rent")
	reloaded.on_day()
	_expect(float(host.state.cash) == cash - 100, "branch rent cannot settle twice")
	host.state.total_minutes = minute_before
	var snapshot: Dictionary = reloaded.snapshot()
	snapshot.membership.points = 999999
	_expect(int(host.state.expansion.membership.points) != 999999, "snapshot cannot mutate persistent state")
	_actual_integration()
	_league_integration()
	_actual_return_capacity()
	print("Expansion tests: %d checks, %d failures" % [checks, failures])
	quit(0 if failures == 0 else 1)
