extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,label: String):
	checks+=1
	if not ok:failures+=1;push_error(label)
func fresh():
	var m=Model.new(20261021);m.start_full();m.events.clear();m.balance["customer.base_flow"]=0;return m
func add(m,id: String):
	m.employees.append(m._create_employee(m._employee_config(id)));m.full_rules.ensure_state_defaults()
func run():
	var m=fresh();var v=m.full_rules.revision18;var r=m.full_rules.revision19
	expect(m.catalog.size()==30 and m.events.is_empty(),"30 employees in current catalog")
	var rarities={"N":.82,"R":.89,"SR":.97,"SSR":1.07}
	for rarity in rarities:
		var employee=m.employees[0].duplicate(true);employee.rarity=rarity;employee.attributes.speed=10;employee.mood=50
		expect(is_equal_approx(m.AnimationRules.animation_factor(employee,"Move",m.balance),1.4*rarities[rarity]),"New rarity factors multiply real movement: "+rarity)
		for action in ["Cook","Serve","Cashier","Clean"]:
			var no_level=employee.duplicate(true);no_level.erase("level")
			expect(is_equal_approx(m.AnimationRules.animation_factor(employee,action,m.balance),m.AnimationRules.animation_factor(no_level,action,m.balance)*rarities[rarity]),"Every interaction gets new rarity baseline: "+rarity+action)
	expect(is_equal_approx(r.drop_chance({}),.30),"Base30 percent drop trigger")
	m.state.stage=1;add(m,"tian_lu");expect(is_equal_approx(r.drop_chance({}),.35),"On-duty Tianlu adds5 percentage points")
	m.state.cashier_speed_bonus=.2;v.apply_state("zhaocai_day")
	expect(is_equal_approx(r.drop_chance({"id":"pi_xiu"}),.55),"Independent base,desk,Tianlu,state andPixiu bonuses total55 percent")
	m._employee("tian_lu").resting=true;expect(is_equal_approx(r.drop_chance({}),.45),"Resting Tianlu gives no bonus")
	v.remove_state("zhaocai_day");m.state.cashier_speed_bonus=0
	# Exercise the real roll and weight table with a fixed RNG, without rewards or resource injection.
	m=fresh();r=m.full_rules.revision19;v=m.full_rules.revision18;var distribution={"5":0,"10":0,"20":0,"gems":0};var dropped=0
	for i in range(6000):
		var before=int(v.s().next_pickup);v.on_sale({"id":i},{},10,1)
		if int(v.s().next_pickup)>before:
			dropped+=1;var pickup=v.s().pickups.back();distribution["gems" if pickup.kind=="gems" else str(pickup.amount)]+=1
	expect(dropped>1650 and dropped<1950,"Seeded6000 actual checkouts approximate30 percent drop probability")
	for key in distribution:
		var target={"5":.42,"10":.35,"20":.20,"gems":.03}[key]
		expect(absf(float(distribution[key])/dropped-target)<.035,"Real conditional weight "+key)
	# Cash bonuses are applied once, with the best overlapping source, and never to gems.
	m=fresh();m.state.stage=1;add(m,"qing_fu");v=m.full_rules.revision18;r=m.full_rules.revision19
	var cash=m.state.cash;var turnover=m.state.total_revenue
	r.spawn("cash",5);var id=int(v.s().pickups[0].id)
	expect(m.full_rules.perform("pickup_collect",{"id":id}).ok and m.state.cash==cash+6,"Qingfu manual pickup grants20 percent cash bonus")
	expect(m.state.total_revenue==turnover,"Pickup bonuses never inflate stage turnover")
	expect(not m.full_rules.perform("pickup_collect",{"id":id}).ok and m.state.cash==cash+6,"Double click cannot award twice")
	v.apply_state("zhaocai_day");r.spawn("cash",5)
	expect(r.reward(v.s().pickups[0])==6,"Qingfu20 and state10 use best source")
	m._employee("qing_fu").resting=true;expect(r.reward(v.s().pickups[0])==5.5,"State10 persists with this dropped cash")
	v.remove_state("zhaocai_day");expect(r.reward(v.s().pickups[0])==5.5,"Drop-time cash state does not change after expiry")
	cash=m.state.cash;m.full_rules.perform("pickup_collect",{"id":int(v.s().pickups[0].id)});expect(m.state.cash==cash+5.5,"Fractional bonus actually enters cash ledger")
	var gems=m.state.gems;r.spawn("gems",1);m.full_rules.perform("pickup_collect",{"id":int(v.s().pickups[0].id)});expect(m.state.gems==gems+1,"Cash bonuses never multiply gems")
	# Attraction is explicit, timed, persistent and uses the same accounting path.
	r.spawn("cash",10);cash=m.state.cash;r.start_auto()
	expect(v.s().pickups.is_empty() and m.state.cash==cash+10,"Accepting attraction collects existing floor items exactly once")
	r.spawn("cash",20);expect(v.s().pickups.is_empty() and m.state.cash==cash+30,"New attracted cash enters automatically")
	r.spawn("gems",1);expect(m.state.gems==gems+2,"Attraction also collects gems once")
	var file="/tmp/shanhai-v19-rules.json";var copy=fresh();var random=m._rng.state
	expect(m.save_game(file) and copy.load_game(file),"Bonus history and attraction survive strict save/load")
	expect(copy.full_rules.revision19.auto_active() and copy._rng.state==random,"Load preserves automation deadline and RNG")
	m.state.total_minutes+=120;r.tick();r.spawn("cash",5);expect(not r.auto_active() and v.s().pickups.size()==1,"At120 game minutes future drops require manual collection")
	m.paused=false;v.advance_pickups(15);expect(v.s().pickups.is_empty(),"Ordinary15-real-second expiration resumes")
	# Decision and notice effects happen only after their proper player confirmation.
	m=Model.new(9);m.start_full();m.state.stage=1;add(m,"qing_fu");var w=m.full_rules.world;r=m.full_rules.revision19;v=m.full_rules.revision18
	expect(w._eligible(w._definition("sancai_tongzi"),"random",{}),"Sancai becomes eligible with a named employee in shop")
	w._enqueue("sancai_tongzi");expect(not r.auto_active(),"Decision has no effects before choice")
	expect(w.choose("decline").ok and not r.auto_active(),"Decline leaves manual pickup rules intact")
	w._enqueue("sancai_tongzi");expect(w.choose("welcome").ok and r.auto_active(),"Accept starts real120-minute attraction")
	r.s().auto_until=0;gems=m.state.gems;w._enqueue("unexpected_windfall")
	expect(v.s().pickups.is_empty() and m.state.gems==gems and m.paused,"Windfall notice pauses before any reward exists")
	expect(w.choose("confirm").ok and v.s().pickups.size()==1 and v.s().pickups[0].kind=="gems" and m.state.gems==gems,"Confirm spawns one gem on ground instead of direct credit")
	expect(not w.choose("confirm").ok and v.s().pickups.size()==1,"Windfall notice cannot duplicate gem")
	m.full_rules.perform("pickup_collect",{"id":int(v.s().pickups[0].id)});expect(m.state.gems==gems+1,"Windfall still requires explicit manual click")
	# Portable actual v1.8 day51 save preserves the already-earned28-person achievement.
	var bytes=FileAccess.get_file_as_bytes("res://tests/fixtures/v18-day51-save.json.gz").decompress_dynamic(16*1024*1024,FileAccess.COMPRESSION_GZIP)
	var f=FileAccess.open(file,FileAccess.WRITE);f.store_buffer(bytes);f.close();copy=Model.new(1);copy.start_full()
	expect(copy.load_game(file),"Actual v1.8 campaign save migrates")
	expect("all_beasts" in copy.state.story.completed and copy.state.story.v19_legacy_collection,"Earned28-person achievement is grandfathered")
	expect(copy.full_rules.sidequests.snapshot().pages.size()==25,"Unchanged Baize quest still has only original25 pages")
	DirAccess.remove_absolute(file)
	print("V1.9 rules: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
