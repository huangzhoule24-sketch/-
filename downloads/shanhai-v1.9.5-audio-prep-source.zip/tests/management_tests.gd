extends SceneTree

const Management = preload("res://scripts/core/management_rules.gd")
var checks: int = 0
var failures: Array[String] = []

class Fixture extends RefCounted:
	signal changed
	var balance: Dictionary = {}
	var catalog: Array = []
	var dishes: Array = []
	var employees: Array = []
	var customers: Array = []
	var scheduler: Array = []
	var messages: Array = []
	var full_rules: Variant = null
	var _rng: RandomNumberGenerator = RandomNumberGenerator.new()
	var state: Dictionary = {"mode":"full", "cash": 10000.0, "ingredients": 20.0, "freshness": 100.0, "total_minutes": 360, "stage": 0, "fragments": {}, "unlocked_dishes": ["noodles", "fried_rice", "plum_juice"], "menu_enabled": ["noodles", "fried_rice", "plum_juice"], "research_experience": {}, "stats": {"purchases": 0, "research_success": 0}}
	func _init() -> void:
		_rng.seed = 42
		balance = JSON.parse_string(FileAccess.get_file_as_string("res://config/global_balance.json"))
		catalog = JSON.parse_string(FileAccess.get_file_as_string("res://config/employees.json"))
		dishes = JSON.parse_string(FileAccess.get_file_as_string("res://config/dishes.json"))
		add_employee("xian_yang")
		add_employee("er_shu")
	func add_employee(id: String) -> Dictionary:
		var employee: Dictionary = _employee_config(id).duplicate(true)
		employee.merge({"stamina": 100.0, "mood": 100.0, "loyalty": 60.0, "resting": false, "training_until": 0, "research_until": 0, "busy_customer": 0, "busy_until": 0, "training_experience": 0}, true)
		employees.append(employee)
		return employee
	func _b(key: String) -> float: return float(balance.get(key, 0))
	func _money(number: float) -> float: return roundf(number * 100) / 100
	func change_cash(delta: float, _category: String, _description: String) -> float:
		var before: float = float(state.cash)
		state.cash = _money(before + delta)
		return float(state.cash) - before
	func _notify(message: String) -> void: messages.append(message)
	func _employee(id: String) -> Dictionary:
		for employee in employees:
			if str(employee.id) == id: return employee
		return {}
	func _employee_config(id: String) -> Dictionary:
		for employee in catalog:
			if str(employee.id) == id: return employee
		return {}
	func _dish(id: String) -> Dictionary:
		for dish in dishes:
			if str(dish.id) == id: return dish
		return {}
	func _customer(id: int) -> Dictionary:
		for customer in customers:
			if int(customer.id) == id: return customer
		return {}
	func _release_customer(customer: Dictionary) -> void:
		var employee: Dictionary = _employee(str(customer.get("worker", "")))
		if not employee.is_empty():
			employee.busy_customer = 0
			employee.busy_until = 0
		for index in range(scheduler.size() - 1, -1, -1):
			if int(scheduler[index].get("customer_id", 0)) == int(customer.id): scheduler.remove_at(index)
	func set_employee_rest(id: String, resting: bool, _check_instruction: bool = true) -> void: _employee(id).resting = resting
	func period() -> String:
		var minute: int = int(state.total_minutes) % 1440
		if minute < 360: return "closed"
		if minute < 600: return "breakfast"
		if minute < 660: return "rest"
		if minute < 840: return "lunch"
		if minute < 1020: return "tea"
		if minute < 1260: return "dinner"
		return "night_market"

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures.append(label)
		printerr("FAIL: ", label)

func near(a: float, b: float) -> bool: return absf(a - b) < 0.00001

func fresh() -> Array:
	var host: Fixture = Fixture.new()
	var management: RefCounted = Management.new(host)
	management.ensure_state()
	return [host, management]

func finish(host: Fixture, management: RefCounted) -> void:
	var last: int = int(host.state.total_minutes)
	for project in host.state.management.projects: last = maxi(last, int(project.due))
	host.state.total_minutes = last
	management.tick_minute()

func _init() -> void:
	inventory_tests()
	staff_tests()
	research_tests()
	retention_and_shift_tests()
	validation_tests()
	hot_adjust_tests()
	if failures.is_empty():
		print("management_tests: %d checks passed" % checks)
		quit(0)
	else:
		printerr("management_tests: %d failures / %d checks" % [failures.size(), checks])
		quit(1)

func inventory_tests() -> void:
	var pair: Array = fresh()
	var host: Fixture = pair[0]
	var rules: RefCounted = pair[1]
	check(near(rules.item("generic").quantity, 20), "old 20 ingredient opening inventory migrates once")
	check(near(rules.inventory_value(), 60), "opening inventory valued at 60")
	rules.ensure_state()
	check(near(rules.item("generic").quantity, 20), "ensure_state is idempotent")
	check(host.dishes.size() == 23, "all 23 original dishes retained")
	for dish in host.dishes:
		var cost: float = 0
		for id in rules.recipe(str(dish.id)): cost += rules.recipe(str(dish.id))[id] * float(rules._ingredient(id).price)
		check(near(cost, float(dish.cost)), str(dish.id) + " recipe matches explicit cost")
	var before: float = host.state.cash
	check(rules.consume("noodles").ok, "base dish consumes actual generic inventory")
	check(near(host.state.cash, before), "consumption does not charge cash twice")
	check(near(rules.item("generic").quantity, 20 - 2.0/3), "fractional ingredient conversion exact")
	check(not rules.can_make("bifang_wings"), "missing category blocks production")
	var stock: Dictionary = host.state.management.items.duplicate(true)
	check(not rules.consume("bifang_wings").ok and host.state.management.items == stock, "failed multi-item consume is atomic")
	check(not rules.purchase("rare", 1).ok, "rare food cannot be purchased")
	check(not rules.purchase("shan_hai_fish", 1).ok, "rare aquatic food cannot be purchased")
	check(not rules.purchase("danmu", 1).ok, "supplier gate enforced")
	check(not rules.perform("unlock_supplier", {"id":"shanhai"}).ok, "supplier stage gate enforced")
	host.state.stage = 1
	check(rules.perform("unlock_supplier", {"id":"shanhai"}).ok, "supplier unlock paid at stage one")
	check(rules.purchase("danmu", 1).ok, "unlocked supplier sells matching food")
	check(rules.can_make("bifang_wings"), "shanhai recipe unlocks after real purchase")
	check(not rules.add_item("unknown", 1) and not rules.add_item("generic", -1) and not rules.add_item("generic", INF), "invalid additions rejected")
	check(not rules.purchase("generic", NAN).ok and not rules.can_make("noodles", -1), "invalid quantity cannot mutate stock")
	host.state.discount_until = int(host.state.total_minutes) + 5
	host.state.procurement_discount = 0.8
	host.state.world = {"effects": [{"stat":"procurement_discount", "value":0.8, "until":int(host.state.total_minutes)+5}]}
	check(near(rules.stock_price("generic"), 2.4), "same kind discounts take best rather than multiply")
	host.state.total_minutes += 6
	check(near(rules.stock_price("generic"), 3), "expired discounts do not persist")
	pair = fresh(); host = pair[0]; rules = pair[1]
	rules.item("generic").freshness = 20
	rules.add_item("generic", 20, 60)
	check(near(rules.item("generic").freshness, 60), "freshness blended by actual batch quantity")
	check(near(rules.quality_freshness("noodles"), 60), "dish reads own ingredients freshness")
	rules.item("generic").freshness = 40
	check(near(rules.modifiers("noodles").quality_mult, 0.9), "stale ingredients reduce quality once")
	rules.consume("fried_rice", 2)
	rules.add_item("danmu", 2)
	rules.add_item("rare", 2)
	var generic_before: float = rules.item("generic").quantity
	rules.prepare_day_procurement(1)
	rules.on_day()
	check(near(rules.item("generic").quantity, generic_before + 3), "auto procurement uses real category consumption x1.2 rounded up")
	check(near(rules.item("danmu").freshness, 95) and near(rules.item("rare").freshness, 98), "freshness decline follows category")
	check(near(rules.item("danmu").quantity, 2) and near(rules.item("rare").quantity, 2), "shanhai and rare inventory are not automatically bought")
	check(near(host.state.management.last_day.cogs, 6), "COGS records purchase cost separately from cash flow")
	check(rules.stock_snapshot().size() == 14, "all 14 ingredient categories exposed")
	var cogs_before: float = host.state.management.total_cogs
	var prepared: Dictionary = rules.consume("noodles", 1, false)
	check(prepared.ok and near(host.state.management.total_cogs, cogs_before), "preparation into work-in-process does not recognize COGS")
	check(rules.recognize_cost(float(prepared.cost)) and near(host.state.management.total_cogs, cogs_before + float(prepared.cost)), "delivered prepared meal recognizes cost exactly once")
	check(not rules.recognize_cost(-1) and not rules.recognize_cost(INF), "invalid COGS recognition rejected")

func staff_tests() -> void:
	var pair: Array = fresh()
	var host: Fixture = pair[0]
	var rules: RefCounted = pair[1]
	var employee: Dictionary = host._employee("er_shu")
	check(not rules.perform("switch_role", {"id":"er_shu","role":"chef"}).ok, "secondary role cannot be assigned before training")
	check(rules.perform("train_secondary", {"id":"er_shu","role":"chef"}).ok, "secondary occupation training starts")
	check(not rules.perform("train_attribute", {"id":"er_shu","attribute":"creativity"}).ok, "parallel training rejected")
	check(not rules.perform("switch_role", {"id":"er_shu","role":"waiter"}).ok, "working occupation cannot change while training")
	finish(host,rules)
	check(employee.secondary_role == "chef" and rules.perform("switch_role", {"id":"er_shu","role":"chef"}).ok, "completed secondary training allows real role switch")
	check(employee.primary_role == "chef" and employee.secondary_role == "waiter", "new primary keeps the previously learned waiter capability")
	employee.expansion_until = int(host.state.total_minutes)+10
	check(not rules.perform("train_attribute", {"id":"er_shu","attribute":"creativity"}).ok, "training respects expedition occupation")
	employee.expansion_until = 0; employee.branch_id = "branch_test"
	check(not rules.perform("train_attribute", {"id":"er_shu","attribute":"creativity"}).ok, "branch employee cannot train at main restaurant")
	employee.branch_id = ""
	var chance: float = rules.coefficient("training_success")
	host.balance["coeff.training_success"] = -2
	var creativity: float = employee.attributes.creativity
	check(rules.perform("train_attribute", {"id":"er_shu","attribute":"creativity"}).ok, "all defined attributes can train")
	finish(host,rules)
	check(employee.training_experience_by_attribute.creativity == 1 and employee.attributes.creativity == creativity, "failure gains experience without attribute reward")
	employee.training_experience_by_attribute.creativity = int(rules.config.guarantees.training_failures)
	check(rules.perform("train_attribute", {"id":"er_shu","attribute":"creativity"}).ok, "experienced training retry starts")
	finish(host,rules)
	check(employee.attributes.creativity == creativity+1, "experience guarantee prevents endless failed training")
	host.balance["coeff.training_success"] = chance
	employee.attributes.calculation = rules.config.limits.attribute
	check(not rules.perform("train_attribute", {"id":"er_shu","attribute":"calculation"}).ok, "attribute cap prevents charges")
	check(not rules.perform("upgrade_skill", {"id":"er_shu"}).ok, "skill upgrade unavailable before stage one")
	host.state.stage = 1
	check(not rules.perform("upgrade_skill", {"id":"er_shu"}).ok, "insufficient fragments block skill upgrade")
	host.state.fragments.er_shu = 100
	var fragments: int = host.state.fragments.er_shu
	check(rules.perform("upgrade_skill", {"id":"er_shu"}).ok and employee.skill_level == 2 and host.state.fragments.er_shu == fragments-1, "skill upgrade consumes configured fragments")
	rules.add_skill_books(3)
	for index in range(3): check(rules.perform("upgrade_skill", {"id":"er_shu","method":"book"}).ok, "skill books can progress to level five")
	check(employee.skill_level == 5 and not rules.perform("upgrade_skill", {"id":"er_shu"}).ok, "level five cap enforced")
	for index in range(10): rules.perform("raise_wage", {"id":"er_shu"})
	check(employee.wage_extra == 100 and not rules.perform("raise_wage", {"id":"er_shu"}).ok, "wage supplements capped per day")
	employee.mood = 20
	check(rules.perform("comfort", {"id":"er_shu"}).ok and employee.mood == 30, "comfort actually restores morale")
	# Training a cook with a live customer must preserve the reserved order and cancel only its scheduler task.
	var chef: Dictionary = host._employee("xian_yang")
	host.customers.append({"id":1,"worker":"xian_yang","due_minute":int(host.state.total_minutes)+8,"stage":"cooking","ingredient_reserved":true})
	host.scheduler.append({"type":"customer_step","customer_id":1})
	chef.busy_customer = 1; chef.busy_until = int(host.state.total_minutes)+8
	check(rules.perform("train_attribute", {"id":"xian_yang","attribute":"cooking"}).ok, "busy cook can suspend order to train")
	check(host.customers[0].remaining_minutes == 8 and host.customers[0].due_minute == -1 and host.scheduler.is_empty(), "suspended order preserves remainder without dangling task")
	pair = fresh(); host = pair[0]; rules = pair[1]
	chef = host.add_employee("jiu_ying"); rules.ensure_state()
	for index in range(3):
		host.customers.append({"id":index+1,"worker":"jiu_ying","due_minute":int(host.state.total_minutes)+8+index,"stage":"cooking","ingredients_reserved":true})
		host.scheduler.append({"type":"customer_step","customer_id":index+1})
	chef.busy_customer = 1; chef.busy_until = int(host.state.total_minutes)+8
	check(rules.perform("train_attribute", {"id":"jiu_ying","attribute":"creativity"}).ok, "parallel cook can enter training")
	check(host.scheduler.is_empty(), "parallel suspension cancels all three task events")
	for index in range(3):
		check(host.customers[index].worker == "" and host.customers[index].remaining_minutes == 8+index and host.customers[index].ingredients_reserved, "parallel suspended order retains own time and ingredients")


func research_tests() -> void:
	var pair: Array = fresh()
	var host: Fixture = pair[0]
	var rules: RefCounted = pair[1]
	var before: float = host.state.cash
	check(not rules.perform("research", {"id":"qianyang_soup"}).ok, "normal research has stage-one gate")
	check(not rules.perform("research", {"dish_id":"qianyang_soup","tutorial":true}).ok, "full v1.5 has no stage-zero free research bypass")
	check(near(host.state.cash,before) and near(rules.item("generic").quantity,20), "rejected research leaves cash and inventory unchanged")
	host.state.stage = 1
	host.state.research_experience.qianyang_soup = int(rules.config.guarantees.research_failures)
	check(rules.perform("research", {"dish_id":"qianyang_soup"}).ok, "stage-one paid research starts")
	check(near(host.state.cash,before-float(rules.config.costs.research_cash)) and near(rules.item("generic").quantity,20-float(rules.config.costs.research_generic)), "research charges actual cash and ingredients")
	check(not rules.perform("research", {"id":"qianyang_soup"}).ok, "parallel research rejected")
	finish(host,rules)
	check("qianyang_soup" in host.state.unlocked_dishes, "completed guaranteed paid project unlocks recipe")
	check(not rules.perform("research", {"id":"qianyang_soup"}).ok, "unlocked recipe cannot be researched twice")
	check(not rules.perform("research", {"id":"fox_milk"}).ok, "associated employee must be owned")
	host.add_employee("jiu_wei_hu"); rules.ensure_state()
	check(rules.perform("research", {"id":"fox_milk"}).ok, "waiter-associated milk researched by available chef")
	finish(host,rules)
	# Every original specialty can actually enter a project with its employee, not just seven demo recipes.
	for definition in host.catalog:
		if host._employee(str(definition.id)).is_empty(): host.add_employee(str(definition.id))
	rules.ensure_state()
	rules.add_item("generic", 100, 300)
	var baize: Dictionary = host._employee("bai_ze")
	var amount: int = 0
	for dish in host.dishes.duplicate():
		if str(dish.id) in host.state.unlocked_dishes: continue
		var result: Dictionary = rules.perform("research", {"id":str(dish.id),"employee_id":"bai_ze"})
		check(result.ok, "full research available for " + str(dish.id))
		finish(host,rules)
		check(str(dish.id) in host.state.unlocked_dishes, "Baize guarantees " + str(dish.id))
		amount += 1
	check(amount >= 18, "all original specialty recipes supported")
	check(host.state.management.hidden_effects.has("hundun_wonton"), "Hundun recipe rolls and persists an actual hidden effect")
	host.balance["coeff.hidden_chance"] = 1
	# Unlock hidden dish by completing a Baize-assisted project in an independent save.
	pair = fresh(); host = pair[0]; rules = pair[1]
	host.state.stage = 1; host.add_employee("bai_ze"); rules.ensure_state()
	host.balance["coeff.hidden_chance"] = 1
	check(rules.perform("research", {"id":"qianyang_soup","employee_id":"bai_ze"}).ok, "Baize-assisted project begins")
	finish(host,rules)
	check(host.state.management.hidden_unlocked and not host._dish("baize_hidden_banquet").is_empty(), "hidden recipe creates real sellable dish")
	check(rules.recipe("baize_hidden_banquet").size() == 2, "hidden dish uses multiple real ingredient categories")
	check(rules.perform("set_price", {"id":"noodles","price":12}).ok and host._dish("noodles").price == 12, "pricing changes actual menu definition")
	check(not rules.perform("set_price", {"id":"noodles","price":0}).ok, "zero selling price rejected")
	rules.ensure_state()
	check(near(host.state.management.base_prices.noodles,8), "default prices preserved across idempotent restore")
	check(rules.perform("set_menu", {"id":"noodles","enabled":false}).ok and not "noodles" in host.state.menu_enabled, "manual menu removal persists")
	var snap: Dictionary = rules.snapshot()
	check(snap.stock.size() == 14 and snap.research.size() == 24 and snap.employees.size() == 3, "UI exposes all categories and hidden recipe")
	host.state.erase("management")
	host.state.unlocked_dishes = ["noodles", "fried_rice", "plum_juice"]
	host.state.menu_enabled = host.state.unlocked_dishes.duplicate()
	rules.ensure_state()
	check(host._dish("noodles").price == 8 and host.dishes.size() == 23, "new game clears price changes and previously unlocked hidden recipe")

func retention_and_shift_tests() -> void:
	var pair: Array = fresh()
	var host: Fixture = pair[0]
	var rules: RefCounted = pair[1]
	check(rules.perform("set_shift", {"id":"er_shu","periods":["dinner"],"enabled":true}).ok and host._employee("er_shu").resting, "off-shift employee rests")
	host.state.total_minutes = 17*60
	rules.tick_minute()
	check(not host._employee("er_shu").resting, "scheduled dinner employee returns at correct time")
	check(not rules.perform("set_shift", {"id":"er_shu","periods":["unknown"]}).ok, "unknown shift label rejected")
	host._employee("er_shu").mood = 5
	host.balance["coeff.quit_chance"] = 1
	rules.on_day()
	check(host._employee("er_shu").is_empty() and host.state.management.departed.size() == 1, "daily low-morale resignation removes employee once")
	pair = fresh()
	host = pair[0]
	rules = pair[1]
	host.balance["coeff.quit_chance"] = 1
	host._employee("er_shu").branch_id = "human_east"
	host._employee("er_shu").mood = 5
	host._employee("xian_yang").mood = 5
	host._employee("xian_yang").training_until = int(host.state.total_minutes) + 30
	rules.on_day()
	check(host._employee("er_shu").is_empty(), "a branch assignment does not grant permanent immunity to low-morale resignation")
	check(not host._employee("xian_yang").is_empty() and host._employee("xian_yang").pending_resignation, "daily resignation roll records handover for an employee with an unfinished project")
	host.state.total_minutes = int(host._employee("xian_yang").training_until)
	host._employee("xian_yang").training_until = 0
	rules.settle_pending_departures()
	check(host._employee("xian_yang").is_empty(), "unfinished-project handover leaves promptly after occupation clears")

func validation_tests() -> void:
	var pair: Array = fresh()
	var host: Fixture = pair[0]
	var rules: RefCounted = pair[1]
	check(rules.validate_state(host.state.management, host.employees, int(host.state.total_minutes)), "valid initial management payload accepted")
	var bad: Dictionary = host.state.management.duplicate(true)
	bad.items.generic.quantity = -1
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "negative stored inventory rejected")
	bad = host.state.management.duplicate(true); bad.items.generic.value = INF
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "nonfinite stored inventory value rejected")
	bad = host.state.management.duplicate(true); bad.items.generic.history = [0,0,0,0]
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "oversized consumption history rejected")
	bad = host.state.management.duplicate(true); bad.items.generic.freshness = 101
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "invalid stored freshness rejected")
	bad = host.state.management.duplicate(true); bad.suppliers = ["shanhai","shanhai"]
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "duplicate supplier unlock rejected")
	bad = host.state.management.duplicate(true); bad.price_overrides.noodles = 17
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "out-of-range saved price rejected")
	var employees: Array = host.employees.duplicate(true); employees[0].skill_level = 6
	check(not rules.validate_state(host.state.management, employees, int(host.state.total_minutes)), "overcap saved skill rejected")
	employees = host.employees.duplicate(true); employees[0].management_until = int(host.state.total_minutes)+1
	check(not rules.validate_state(host.state.management, employees, int(host.state.total_minutes)), "orphan employee occupation rejected")
	host.state.stage = 1
	check(rules.perform("research", {"dish_id":"qianyang_soup"}).ok, "validation fixture starts real paid project")
	check(rules.validate_state(host.state.management, host.employees, int(host.state.total_minutes)), "valid in-progress research payload accepted")
	bad = host.state.management.duplicate(true); bad.projects[0].due = int(host.state.total_minutes)
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "expired occupation due rejected")
	bad = host.state.management.duplicate(true); bad.projects.append(bad.projects[0].duplicate())
	check(not rules.validate_state(bad, host.employees, int(host.state.total_minutes)), "duplicate project worker rejected")
	var before: Dictionary = host.state.management.duplicate(true)
	rules.validate_state(bad, host.employees, int(host.state.total_minutes))
	check(host.state.management == before, "failed candidate validation leaves live inventory untouched")

func hot_adjust_tests() -> void:
	var pair: Array = fresh()
	var host: Fixture = pair[0]
	var rules: RefCounted = pair[1]
	var base: float = rules.training_cost(host._employee("xian_yang"), "cooking")
	host.balance["management.costs.training"] = 25
	check(near(rules.training_cost(host._employee("xian_yang"), "cooking"), base/2), "flat balance overrides training cash cost immediately")
	host.balance["management.ingredients.meat.price"] = 10
	check(near(rules.stock_price("meat"), 10), "flat balance overrides actual supplier price immediately")
	check(near(rules.recipe("qianyang_soup").meat, 0.6), "hot ingredient price preserves explicit recipe cost conversion")
	host.balance["management.minutes.training"] = 12
	var job: Dictionary = rules.perform("train_attribute", {"id":"xian_yang","attribute":"cooking"})
	check(job.ok and int(job.due)-int(host.state.total_minutes) == 12, "flat balance overrides actual training duration")
	check(rules.balance_defaults().has("management.costs.training") and rules.balance_defaults().has("management.ingredients.rare.price") and rules.balance_defaults().has("coeff.research_success"), "all numeric defaults available to global balance merger")
