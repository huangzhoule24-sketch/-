extends SceneTree

const Navigation = preload("res://scripts/services/grid_navigation.gd")
const View = preload("res://scripts/ui/restaurant_view.gd")
const Model = preload("res://scripts/core/game_model.gd")
const Space = preload("res://scripts/services/restaurant_space.gd")
var checks := 0
var failures := 0

class FakeModel extends RefCounted:
	var paused := false
	var speed := 1
	var _fraction := 0.0
	var balance: Dictionary = {}
	var demo_config: Dictionary = {"layout": {"width": 6, "height": 4}}
	var state: Dictionary = {"total_minutes": 400, "mode": "normal", "promotion_until": 0, "layout": []}
	var employees: Array[Dictionary] = []
	var customers: Array[Dictionary] = []
	func business_open() -> bool: return true

class TestView extends "res://scripts/ui/restaurant_view.gd":
	var extra_obstacles: Array[Rect2] = []
	func _navigation_obstacles() -> Array[Rect2]:
		var result: Array[Rect2] = super._navigation_obstacles()
		result.append_array(extra_obstacles)
		return result

func _init() -> void:
	call_deferred("run")

func check(value: bool, description: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(description)

func make_model(id: String = "waiter", due: int = 404) -> FakeModel:
	var fake := FakeModel.new()
	fake.employees.append({"id": id, "name": id, "role": "waiter", "mood": 80, "rarity": "N", "resting": false, "busy_customer": 7, "attributes": {"speed": 5, "cooking": 5, "charm": 5}})
	fake.customers.append({"id": 7, "seat": 0, "worker": id, "stage": "serving", "task_started_minute": 400, "due_minute": due})
	return fake

func make_view(fake):
	var view = TestView.new()
	view.model = fake
	view.font = ThemeDB.fallback_font
	view.size = Vector2(900, 600)
	root.add_child(view)
	view.set_process(false)
	view._update_employee_animation(0.0)
	return view

func set_position(view, id: String, position: Vector2) -> void:
	view._actors[id].position = position
	view._actors[id].erase("navigation_layout")
	view._update_employee_animation(0.0)

func run() -> void:
	var bounds := Rect2(0, 0, 200, 160)
	var desk := Rect2(80, 30, 40, 100)
	var start := Vector2(20, 80)
	var goal := Vector2(180, 80)
	var direct := Navigation.find_path(start, goal, [], bounds)
	check(not direct.blocked and direct.points.size() == 1 and is_equal_approx(float(direct.length), 160), "clear space produces the direct shortest route")
	var route := Navigation.find_path(start, goal, [desk], bounds)
	check(not route.blocked and route.points.size() >= 3 and float(route.length) > 160, "ordinary route walks around a physical desk")
	var previous := start
	var all_segments_clear := true
	for point in route.points:
		all_segments_clear = all_segments_clear and Navigation.segment_is_clear(previous, point, [desk.grow(4)])
		previous = point
	check(all_segments_clear and previous == goal, "every planned segment clears furniture plus its margin")
	var wall := Rect2(95, -10, 10, 180)
	check(bool(Navigation.find_path(start, goal, [wall], bounds).blocked), "a wall closing the entire walkable rectangle is impassable")
	check(bool(Navigation.find_path(desk.get_center(), goal, [desk], bounds).blocked), "a start covered by new furniture cannot teleport out")
	check(bool(Navigation.find_path(start, desk.get_center(), [desk], bounds).blocked), "a covered work target cannot be entered")
	var corridor := Navigation.find_path(Vector2(100, 20), Vector2(100, 140), [Rect2(20, 40, 60, 80), Rect2(120, 40, 60, 80)], bounds)
	check(not corridor.blocked and corridor.points.size() == 1, "the gap between actual furniture remains walkable")
	var position := start
	var waypoint := 0
	var movement_safe := true
	var last_remaining := float(route.length)
	for frame in range(120):
		var moved := Navigation.advance(position, route.points, waypoint, 3.0)
		movement_safe = movement_safe and position.distance_to(moved.position) <= 3.001 and not desk.has_point(moved.position)
		position = moved.position
		waypoint = int(moved.waypoint)
		var remaining := Navigation.remaining_length(position, route.points, waypoint)
		movement_safe = movement_safe and remaining <= last_remaining + 0.001
		last_remaining = remaining
	check(movement_safe and position.is_equal_approx(goal), "following corners has bounded movement and reaches the goal without crossing the desk")
	check(Navigation.advance(start, route.points, 0, 0).position == start, "zero visual time leaves navigation unchanged")
	var fake := make_model()
	var view = make_view(fake)
	var table: Rect2 = view._navigation_obstacles()[0]
	set_position(view, "waiter", table.get_center() + Vector2(120, 0))
	var actor: Dictionary = view.employee_animation_state("waiter")
	check(actor.navigation_path.size() > 1 and not actor.navigation_ignore, "restaurant furniture creates a visible detour for ordinary staff")
	var walked_clear := true
	var work_only_after_arrival := true
	for frame in range(100):
		var before: Vector2 = view.employee_animation_state("waiter").position
		view._update_employee_animation(0.02)
		actor = view.employee_animation_state("waiter")
		walked_clear = walked_clear and not table.has_point(actor.position) and before.distance_to(actor.position) <= 4.201
		if str(actor.action) == "Serve": work_only_after_arrival = work_only_after_arrival and actor.position.distance_to(actor.target) <= 0.01
	check(walked_clear and str(actor.action) == "Serve", "real restaurant actor walks around its tabletop and finishes the approach")
	check(work_only_after_arrival, "service animation starts only at its actual destination")
	var before_block: Vector2 = actor.position
	view.extra_obstacles.append(Rect2(actor.target - Vector2(10, 10), Vector2(20, 20)))
	set_position(view, "waiter", before_block + Vector2(120, 0))
	var stopped_at: Vector2 = view.employee_animation_state("waiter").position
	view._update_employee_animation(0.5)
	actor = view.employee_animation_state("waiter")
	check(actor.navigation_blocked and actor.position == stopped_at and str(actor.action) == "Idle", "blocked destination holds the current position instead of jumping")
	check(str(actor.rest_label) == "通路受阻", "blocked actors expose a human-readable visual status")
	view.extra_obstacles.clear()
	view._update_employee_animation(0.1)
	actor = view.employee_animation_state("waiter")
	check(not actor.navigation_blocked and actor.position != stopped_at, "changing the layout rebuilds a route and resumes smooth movement")
	var quick := make_model("di_jiang", 401)
	var quick_view = make_view(quick)
	set_position(quick_view, "di_jiang", table.get_center() + Vector2(120, 0))
	var first: Dictionary = quick_view.employee_animation_state("di_jiang")
	check(first.navigation_ignore and first.navigation_path.size() == 1, "Dijiang selects its permitted straight route through furniture")
	quick_view._update_employee_animation(0.05)
	var next: Dictionary = quick_view.employee_animation_state("di_jiang")
	check(next.position != first.position and next.position != next.target and str(next.action) == "Move", "mythical travel still moves smoothly instead of teleporting")
	var crossed_table := table.has_point(next.position)
	for frame in range(1, 18):
		quick._fraction = frame * 0.05
		quick_view._update_employee_animation(0.05)
		next = quick_view.employee_animation_state("di_jiang")
		crossed_table = crossed_table or table.has_point(next.position)
	check(crossed_table and str(next.action) == "Serve", "Dijiang visibly crosses the obstacle and arrives within a one-minute task")
	quick._fraction = 0.95
	set_position(quick_view, "di_jiang", Vector2(800, 500))
	var late_start: Vector2 = quick_view.employee_animation_state("di_jiang").position
	quick_view._update_employee_animation(0.1)
	var late: Dictionary = quick_view.employee_animation_state("di_jiang")
	check(late.position != late_start and late.position != late.target and late.position.distance_to(late_start) < late.target.distance_to(late_start), "late observed instant service preserves visible travel instead of snapping to meet the deadline")
	var slow := make_model("slow", 402)
	slow.employees[0].attributes.speed = 0
	var slow_view = make_view(slow)
	set_position(slow_view, "slow", Vector2(800, 500))
	var deadline_safe := true
	var bounded_speed := true
	for frame in range(39):
		var elapsed := frame * 0.05
		slow.state.total_minutes = 400 + int(floor(elapsed))
		slow._fraction = fmod(elapsed, 1.0)
		var previous_slow: Vector2 = slow_view.employee_animation_state("slow").position
		slow_view._update_employee_animation(0.05)
		var state: Dictionary = slow_view.employee_animation_state("slow")
		bounded_speed = bounded_speed and previous_slow.distance_to(state.position) <= 6.301
		if str(state.action) == "Serve": deadline_safe = deadline_safe and state.position.distance_to(state.target) <= 0.01
	var timely: Dictionary = slow_view.employee_animation_state("slow")
	check(str(timely.action) == "Move" and bounded_speed and deadline_safe, "a distant deadline never overrides the slow worker attribute movement speed")
	var four := FakeModel.new()
	four.state.layout = [{"id":"table_four", "x":1, "y":1, "w":1, "h":1}]
	var four_view = make_view(four)
	for seat in range(4):
		var approach := Space.service_point(four, seat)
		var route_to_seat := Space.find_route(four, Space.entry_position(), approach)
		check(Navigation.point_is_clear(approach, Space.obstacles(four)) and not bool(route_to_seat.blocked), "four-person table seat %d has a reachable approach outside the tabletop" % seat)
	var same_seat := Space.service_point(four, 2)
	four_view.size = Vector2(1440, 900)
	check(Space.service_point(four, 2) == same_seat, "resizing the view cannot change the simulation geometry")
	check(four_view.cell_at(four_view._to_view(Space.cell_rect(four, 1, 1).get_center())) == Vector2i(1, 1), "scaled placement input selects its canonical cell")
	four_view.queue_free()
	var real = Model.new(20261016)
	real.start_full()
	real.state.world.modifiers.append({"key":"ignore_obstacles", "value":1.0, "until":int(real.state.total_minutes) + 10})
	var real_view = make_view(real)
	var real_waiter: Dictionary = real.employees.filter(func(e):return str(e.role)=="waiter")[0]
	check(real_view._navigation_ignores_obstacles(real_waiter, [{"stage":"serving"}]) and not real_view._navigation_ignores_obstacles(real_waiter, []), "world shortcut applies to actual serving and not idle travel")
	var origin: Dictionary = {"x":300.0,"y":120.0}
	real_waiter.motion={"origin":origin,"target":origin.duplicate(),"path":[],"started":int(real.state.total_minutes),"speed":0.0,"travel_minutes":0.0,"work_minutes":0.0,"action":"Idle","blocked":false}
	real.customers.append({"id":7, "seat":0, "worker":"", "stage":"serving", "dish_id":"noodles", "remaining_minutes":0, "task_started_minute":int(real.state.total_minutes), "due_minute":-1})
	real._assign_tasks()
	real_view._update_employee_animation(0.0)
	check(real_view.employee_animation_state(str(real_waiter.id)).navigation_path.size() == 2, "world shortcut uses direct segments while still visiting the real pass")
	real.state.world.modifiers.clear()
	check(not real_view._navigation_ignores_obstacles(real_waiter, [{"stage":"serving"}]), "expired world shortcut restores ordinary navigation")
	var before_expiry: Vector2 = real_view.employee_animation_state(str(real_waiter.id)).position
	real.set_employee_rest(str(real_waiter.id),true,false)
	real.set_employee_rest(str(real_waiter.id),false,false)
	real._assign_tasks()
	real_view._update_employee_animation(0.0)
	var after_expiry: Dictionary = real_view.employee_animation_state(str(real_waiter.id))
	check(not after_expiry.navigation_ignore and after_expiry.navigation_path.size() > 1 and after_expiry.position == before_expiry, "world shortcut expiry rebuilds the detour without moving or teleporting the actor")
	check(real_view._navigation_ignores_obstacles(real_waiter, [{"dish_id":"dijiang_dumplings", "stage":"serving"}]), "Dijiang dumplings apply their serving shortcut through the shared rule")
	check(not real_view._navigation_ignores_obstacles(real_waiter, [{"dish_id":"dijiang_dumplings", "stage":"cleaning"}]), "dish shortcut is restricted to its specified serving stage")
	for role in ["chef", "salesman", "waiter"]:
		var crowded = Model.new(20261016)
		crowded.start_full()
		crowded.state.stage = 4
		crowded.state.layout = []
		for x in [1, 3, 6, 7]:
			for y in [0, 2, 4]: crowded.state.layout.append({"id":"table_two", "x":x, "y":y, "w":1, "h":1})
		crowded.employees.clear()
		for index in range(20):
			crowded.employees.append({"id":"crowded_%s_%d" % [role, index], "name":"同岗员工", "role":role, "mood":80, "rarity":"N", "resting":false, "busy_customer":0, "attributes":{"speed":5, "cooking":5, "charm":5}})
		var crowded_view = make_view(crowded)
		var clear_targets := true
		var shifted_station := false
		for index in range(20):
			var id := "crowded_%s_%d" % [role, index]
			var state: Dictionary = crowded_view.employee_animation_state(id)
			clear_targets = clear_targets and not bool(state.navigation_blocked) and Navigation.point_is_clear(state.target, crowded_view._navigation_obstacles())
			var horizontal := 0.2 if role == "chef" else (0.8 if role == "salesman" else 0.5)
			var raw_anchor := Vector2(Space.WORLD_SIZE.x * horizontal - 25 + (index % 3) * 48, 102 + (index / 3) * 58)
			shifted_station = shifted_station or state.target != raw_anchor
		check(clear_targets, "all twenty %s have reachable clear station targets with twelve tables" % role)
		if role in ["chef", "salesman"]: check(shifted_station, "crowded %s station anchors move to neighbouring clear spots" % role)
		for frame in range(100): crowded_view._update_employee_animation(0.05)
		var everyone_arrived := true
		for index in range(20):
			var state: Dictionary = crowded_view.employee_animation_state("crowded_%s_%d" % [role, index])
			everyone_arrived = everyone_arrived and str(state.action) == "Idle" and state.position.distance_to(state.target) <= 0.01
		check(everyone_arrived, "all twenty %s visibly reach their resolved stations without permanent blockage" % role)
		crowded_view.queue_free()
	for node in [view, quick_view, slow_view, real_view]: node.queue_free()
	await process_frame
	print("NAVIGATION CHECKS: %d passed, %d failed" % [checks - failures, failures])
	quit(1 if failures else 0)
