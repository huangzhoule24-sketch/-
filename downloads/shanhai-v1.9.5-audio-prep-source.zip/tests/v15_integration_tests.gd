extends SceneTree
## Natural opening plus explicit boundary fixtures. No player save file is used.
const Model = preload("res://scripts/core/game_model.gd")
var checks := 0
var failures := 0

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition: failures += 1; push_error("V15 INTEGRATION: " + label)

func near(a: float, b: float) -> bool: return absf(a - b) < 0.011

func saved_equal(a: Variant, b: Variant) -> bool:
	if (a is int or a is float) and (b is int or b is float):
		return a == b or (a is float and b is float and absf(a - b) <= maxf(1, maxf(absf(a), absf(b))) * 4 * 2.220446049250313e-16)
	if typeof(a) != typeof(b): return false
	if a is Dictionary:
		if a.size() != b.size(): return false
		for key in a:
			if not b.has(key) or not saved_equal(a[key], b[key]): return false
		return true
	if a is Array:
		if a.size() != b.size(): return false
		for index in a.size():
			if not saved_equal(a[index], b[index]): return false
		return true
	return a == b

func fresh(seed_value: int = 151018):
	var m = Model.new(seed_value)
	m.start_full()
	return m

func _init() -> void: call_deferred("run")

func run() -> void:
	# Natural opening: use only public actions and the normal minute scheduler.
	var m = fresh()
	check(near(float(m.state.cash), 800) and near(float(m.state.debt), 1200), "new campaign starts at the revised real balances")
	check(m.full_rules.perform("marketing", {"kind":"flyer"}).ok, "twenty-yuan flyer is a real player action")
	m.advance_minutes(180)
	check(int(m.state.served) > 0 and float(m.state.total_revenue) > 0, "natural opening completes paid customer orders")
	check(m.state.finance.flows.any(func(flow): return flow.type == "sales" and float(flow.amount) > 0), "actual checkout records positive sales cash flows")
	var total: float = 0
	for flow in m.state.finance.flows: total += float(flow.amount)
	check(near(800 + total, float(m.state.cash)), "natural opening cash is fully explained by real movements")
	check(near(float(m.state.customer_service.today.sales), float(m.state.total_revenue)), "natural service statistics agree with receipts")
	var safe_path := "/tmp/shanhai-v15-integration-safe.json"
	check(m.save_game(safe_path), "natural order state writes a recovery candidate")
	var loaded = Model.new(12)
	check(loaded.load_game(safe_path), "actual new-module save reloads strictly")
	check(loaded._rng.state == m._rng.state and saved_equal(loaded.customers, m.customers) and saved_equal(loaded.scheduler, m.scheduler), "reload preserves in-flight orders, jobs and RNG (four-epsilon JSON float tolerance)")

	# Boundary: empty stock changes service, never the arrival schedule.
	m = fresh()
	m.events.clear()
	var interval: int = m._spawn_interval()
	for item in m.state.management.items.values(): item.quantity = 0; item.value = 0
	m.full_rules.management._sync_totals()
	check(m._spawn_interval() == interval, "zero stock does not change the arrival interval")
	var before: float = float(m.state.cash)
	m.advance_minutes(90)
	check(int(m.state.customer_service.today.arrivals) > 0 and int(m.state.customer_service.today.stockouts) > 0, "actual arrivals proceed into stockout feedback")
	check(int(m.state.served) == 0 and near(float(m.state.cash), before), "failed stockout orders never generate sales or consume cash")
	check(near(float(m.state.ingredients), 0), "stockout path never creates negative inventory")

	# Boundary: controlled procurement/day-close isolates the four charge regimes.
	m = fresh()
	m.events.clear()
	m.balance["customer.base_flow"] = 0
	check(m.full_rules.perform("set_procurement_strategy", {"strategy":"fixed"}).ok, "fixed procurement is an actual setting")
	check(m.full_rules.perform("set_procurement_quantity", {"id":"generic","quantity":1}).ok, "fixed quantity is stored through the real action")
	m.change_cash(5000, "fixture", "Explicit day-close boundary funding")
	for day in range(1, 5):
		m.full_rules.perform("daily_ack")
		m.advance_minutes(day * 1440 - int(m.state.total_minutes))
		var bill: Dictionary = m.state.last_report
		check(int(bill.day) == day and bool(bill.cash_reconciled), "day %d has a reconciled cash bill" % day)
		check(near(float(bill.minimum_due), 50 if day <= 3 else 100), "day %d uses the correct protected principal minimum" % day)
		check(near(float(bill.rent_utilities), 0 if day <= 3 else 80), "day %d uses the correct rent/utilities protection" % day)
		var flows: Array = m.full_rules.finance.flows_by_day(day)
		var procurement_index: int = -1
		var charge_index: int = -1
		for index in flows.size():
			if str(flows[index].type) == "procurement" and procurement_index < 0: procurement_index = index
			if str(flows[index].type) == "debt_interest" and charge_index < 0: charge_index = index
		check(procurement_index >= 0 and charge_index > procurement_index, "day %d buys stock before charging debt interest" % day)
		check(int(bill.procured_units) == 1 and float(bill.revenue) == 0, "day %d records real purchase units and never credits sales twice" % day)
	check(int(m.state.overdue_count) == 0, "properly paid days do not manufacture debt delinquency")

	# Midnight callbacks execute before day-close; their cash must share the
	# closing bill's date, including sales and Pixiu's receivable settlement.
	m = fresh()
	m.events.clear()
	m.balance["customer.base_flow"] = 0
	m.balance["customer.tip_chance"] = 0
	m.balance["customer.escape_probability"] = 0
	m.state.total_minutes = 1370
	m._spawn_customer("noodles", false)
	m.state.total_minutes = 1439
	var guest: Dictionary = m.customers.back()
	var waiter: Dictionary = m.employees.filter(func(employee): return str(employee.role) == "waiter")[0]
	guest.stage = "paying"
	guest.ingredients_reserved = true
	guest.worker = str(waiter.id)
	guest.due_minute = 1440
	waiter.busy_customer = int(guest.id)
	waiter.busy_until = 1440
	m.scheduler.append({"type":"customer_step","customer_id":int(guest.id),"employee_id":str(waiter.id),"stage":"paying","due":1440})
	m.advance_minutes(1)
	check(bool(m.state.last_report.cash_reconciled) and float(m.state.last_report.revenue) > 0, "scheduled midnight checkout reconciles in its actual closing bill")
	check(m.full_rules.finance.flows_by_day(1).any(func(flow): return str(flow.type) == "sales" and float(flow.amount) > 0), "midnight checkout is not silently shifted to tomorrow's cash flows")
	m = fresh()
	var pixiu: Dictionary = m._create_employee(m._employee_config("pi_xiu"))
	m.employees.append(pixiu)
	m.full_rules.ensure_state_defaults()
	m.balance["customer.base_flow"] = 0
	m.full_rules.expansion._income(100)
	m.full_rules.world._enqueue("pixiu_withholds", {"employee_id":"pi_xiu","amount":100})
	m.full_rules.world.choose(str(m.pending_event().options[0].id))
	check(float(m.state.world.outstanding_receipts) == 100, "boundary escrow uses the actual receipt-deferral event")
	m.events.clear()
	m.state.total_minutes = 1439
	m.advance_minutes(1)
	check(bool(m.state.last_report.cash_reconciled) and float(m.state.world.outstanding_receipts) == 0, "midnight escrow principal and bonus reconcile once before fees")

	# Boundary: all three rescue exits preserve a concrete, readable campaign.
	m = fresh()
	var collected: Array = m.state.story.collected_ids.duplicate()
	check(m.save_game(safe_path), "healthy campaign save exists before rescue")
	check(m.full_rules.perform("bankruptcy_settle").ok and m.paused, "manual insolvency opens the mandatory paused rescue")
	var stopped: int = int(m.state.total_minutes)
	m.set_paused(false)
	m.advance_real(20)
	m.advance_minutes(20)
	check(m.paused and int(m.state.total_minutes) == stopped, "rescue cannot be bypassed by speed or minute advancement")
	check(not m.full_rules.perform("marketing", {"kind":"flyer"}).ok, "rescue prevents unrelated spending")
	check(m.full_rules.perform("emergency_accept", {"confirmed":true}).ok, "rescue can apply the real emergency loan")
	check(near(float(m.state.cash), 5800) and near(float(m.state.rescue171.loan.principal), 5000) and not m._rescue_pending(), "loan grants principal once and restores operation")
	check(m.load_recovery_save(safe_path).ok and near(float(m.state.cash), 800) and near(float(m.state.finance.loan.principal), 0), "safe recovery restores the actual saved finances")
	m.state.permanent_archives = {"debt":true} # Explicit permanent-record boundary.
	m.state.sidequests.lore_unlocked = ["moon_memory"]
	m.full_rules.perform("bankruptcy_settle")
	check(m.full_rules.perform("bankruptcy_restart").ok, "restart is the third real rescue exit")
	check(near(float(m.state.cash), 800) and m.state.story.collected_ids == collected and "moon_memory" in m.state.sidequests.lore_unlocked and m.state.permanent_archives.has("debt"), "restart retains collection, lore and achievement history while resetting this campaign")
	check(m.save_game(safe_path) and loaded.load_game(safe_path), "restarted permanent collection remains strictly loadable")
	DirAccess.remove_absolute(safe_path)
	print("V15 INTEGRATION CHECKS: %d passed, %d failed" % [checks - failures, failures])
	quit(1 if failures else 0)
