extends SceneTree
## Targeted mechanics checks, not evidence of an unassisted campaign clear.
const Model = preload("res://scripts/core/game_model.gd")
var failures := 0
var checks := 0

func _initialize() -> void:
	_coefficients_and_current_ad()
	_scored_festival()
	_real_blockade_orders()
	_day_boundary_and_forced_queue()
	_all_day_receipts()
	_receipt_advances_and_save()
	_luwu_current_dish()
	print("World completion checks passed: %d, failed: %d" % [checks - failures, failures])
	quit(1 if failures else 0)

func check(value: bool, description: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(description)

func fresh():
	var m = Model.new(91026)
	m.start_full()
	m.state.stage = 2
	m.state.cash = 10000.0
	m.state.reputation = 700
	m.state.total_minutes = 660
	m.balance["customer.base_flow"] = 0
	m.balance["events.weather_probability"] = 0
	# Isolate old world mechanics from new optional notices that pause player time.
	for key in ["events.zhaocai_probability","events.sancai_probability","events.windfall_probability"]:m.balance[key]=0
	return m

func _coefficients_and_current_ad() -> void:
	var m = fresh()
	var world = m.full_rules.world
	m.balance["coeff.repair_cost"] = 17
	world._enqueue("bifang_fire")
	var cash := float(m.state.cash)
	check(world.choose("repair").ok and is_equal_approx(float(m.state.cash), cash - 17), "canonical repair coefficient controls actual charge")
	m.employees.clear()
	m.employees.append(m._create_employee(m._employee_config("tao_wu")))
	m.balance["events.default_probability"] = 0
	check(m.full_rules.promote_kind("flyer").ok, "Taowu starts a real paid advertisement")
	var before := float(m.state.promotion_bonus)
	m.balance["events.default_probability"] = 1
	world.on_hook("promote", {"employee_id":"tao_wu", "kind":"flyer"})
	check(world.pending_event().is_empty() and str(m.state.world.history.back().id) == "taowu_stubborn", "v1.5 Taowu broadcast resolves without a forced choice")
	check(is_equal_approx(float(m.state.promotion_bonus), before * 1.2), "broadcast improves the current advertisement rather than only a future purchase")

func _scored_festival() -> void:
	var m = fresh()
	var world = m.full_rules.world
	var chef: Dictionary = {}
	for employee in m.employees:
		if str(employee.role) == "chef": chef = employee
	check(world.perform("festival_prepare", {"employee_id": str(chef.id), "dish_id": "noodles"}).ok, "player selects real festival employee and dish")
	world._enqueue("food_festival")
	var stock := float(m.full_rules.management.item("generic").quantity)
	check(world.choose("enter").ok, "festival consumes a real entry")
	check(float(m.full_rules.management.item("generic").quantity) < stock, "festival recipe reduces actual stock")
	check(not bool(m.state.world.festival.last_result.won), "untrained chef loses against the configured chain-brand score")
	var prior_quality := float(m.state.world.festival.last_result.quality)
	var prior_base: Variant = m.balance.get("dish.noodles.quality")
	m.balance["dish.noodles.quality"] = 30
	world._enqueue("food_festival")
	check(world.choose("enter").ok, "festival can judge the same dish after a live base-quality adjustment")
	check(float(m.state.world.festival.last_result.quality) < prior_quality, "festival score consumes the selected dish's configured quality rather than one prototype constant")
	if prior_base == null: m.balance.erase("dish.noodles.quality")
	else: m.balance["dish.noodles.quality"] = prior_base
	chef.attributes.cooking = 20
	chef.attributes.creativity = 20
	world._enqueue("food_festival")
	check(world.choose("enter").ok, "improved chef can enter again")
	check(bool(m.state.world.festival.last_result.won) and int(m.state.world.festival_wins) == 1, "trained chef and selected recipe produce a scored victory")
	check(float(m.state.world.festival.last_result.score) >= float(m.state.world.festival.last_result.opponent_score), "saved score explains victory")
	world._enqueue("food_festival")
	chef.resting = true
	var cash := float(m.state.cash)
	var queue: Array = m.state.world.queue.duplicate(true)
	check(not world.choose("enter").ok, "resting selected chef blocks festival entry")
	check(float(m.state.cash) == cash and m.state.world.queue == queue, "invalid entry retains cash and invitation atomically")

func _real_blockade_orders() -> void:
	var m = fresh()
	var world = m.full_rules.world
	for employee in m.employees:
		employee.attributes.speed = 20
		employee.attributes.endurance = 20
		if str(employee.role) == "chef": employee.attributes.cooking = 20
	m.full_rules.management.purchase("generic", 100)
	check(world._enqueue("kunlun_trouble"), "actual disturbance begins a persistent blockade")
	check(bool(m.state.world.blockade.active), "blockade has an active state")
	var under_pressure: float = world.modifier("traffic")
	check(world.choose("pr").ok, "original public-relations choice still has its configured cost")
	check(not bool(m.state.world.blockade.resolved), "one random-event response does not resolve the campaign conflict")
	check(not world.perform("kunlun_counter", {"strategy":"service"}).ok, "service response requires completed orders")
	check(world.perform("kunlun_counter", {"strategy":"supply"}).ok, "independent supply agreement is actionable")
	check(not world.perform("kunlun_counter", {"strategy":"supply"}).ok, "supply agreement cannot repeatedly charge or award progress")
	check(world.perform("kunlun_counter", {"strategy":"community"}).ok, "community cooperation is actionable")
	for index in range(20):
		if int(m.state.world.blockade.service_orders)>=12:break
		m._spawn_customer("noodles")
		m.advance_minutes(30)
	check(int(m.state.served) >= 12, "twelve customers actually order, cook, eat and check out")
	check(int(m.state.world.blockade.service_orders) >= 12, "only real paid quality orders advance blockade service evidence")
	check(world.perform("kunlun_counter", {"strategy":"service"}).ok, "earned order evidence permits service response")
	check(bool(m.state.world.blockade.resolved) and not bool(m.state.world.blockade.active), "all three actions permanently lift the blockade")
	check(world.modifier("traffic") > under_pressure, "lifting blockade restores suppressed customer flow")
	var path := "/tmp/shanhai-world-completion-save.json"
	check(m.save_game(path), "resolved blockade and festival state save")
	var copy = Model.new(9)
	check(copy.load_game(path), "new world state round-trips through strict save validation")
	check(bool(copy.state.world.blockade.resolved), "breakthrough survives reload")
	var legacy: Dictionary = m.state.world.duplicate(true)
	legacy.erase("blockade")
	legacy.erase("festival")
	check(world.validate_state(legacy, m.employees, int(m.state.total_minutes)), "previous world save schema remains readable")
	var malformed: Dictionary = m.state.world.duplicate(true)
	malformed.blockade.service_orders = -1
	check(not world.validate_state(malformed, m.employees, int(m.state.total_minutes)), "malformed campaign counters are rejected")

func _day_boundary_and_forced_queue() -> void:
	var m = fresh()
	var world = m.full_rules.world
	m.state.total_minutes = 23 * 60
	world._enqueue("zhulong_eyes")
	world.choose("open")
	check(world.modifier("traffic") > 1, "Zhulong event changes same-day flow")
	m.state.total_minutes = 1440 + 360
	check(is_equal_approx(world.modifier("traffic"), 1), "today-only Zhulong bonus expires at the calendar boundary")
	for event in m.events:
		if m.state.world.queue.size() >= 8: break
		if not bool(event.get("auto", false)) and str(event.id) != "debt_collection": world._enqueue(str(event.id))
	m.state.overdue_count = 3
	world.on_hook("day")
	check(str(world.pending_event().get("id", "")) == "debt_collection", "forced collection takes priority even with eight ordinary events queued")

func _all_day_receipts() -> void:
	var m = fresh()
	var world = m.full_rules.world
	m.events=m.events.filter(func(e):return str(e.id)=="pixiu_withholds") # Isolate the actual deferral from unrelated decisions.
	m.balance["events.pixiu_delay_probability"] = 1
	for employee in m.employees:
		employee.attributes.speed = 20
		employee.attributes.endurance = 20
	var opening_cash := float(m.state.cash)
	m._spawn_customer("noodles")
	m.advance_minutes(35)
	for minute in range(90):
		if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
		if m.customers.is_empty() or m.customers.all(func(c):return bool(c.get("paid",false))):break
		m.advance_minutes(1)
	check(int(m.state.served) == 1 and float(m.state.daily_revenue) > 0, "pre-event customer really pays before Pixiu joins the till")
	var pixiu: Dictionary = m._create_employee(m._employee_config("pi_xiu"))
	pixiu.attributes.speed = 20
	pixiu.attributes.endurance = 20
	m.employees.append(pixiu)
	m.full_rules.ensure_state_defaults()
	m._spawn_customer("noodles")
	m.advance_minutes(35)
	for minute in range(90):
		if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
		if m.customers.is_empty() or m.customers.all(func(c):return bool(c.get("paid",false))):break
		m.advance_minutes(1)
	check(int(m.state.served) == 2 and int(m.state.world.pixiu_receipts.day) == 0, "actual Pixiu checkout triggers the calendar-day deferral")
	check(is_equal_approx(float(m.state.world.pixiu_receipts.turnover), float(m.state.daily_revenue)), "event captures earlier sales as well as the triggering bill")
	check(is_equal_approx(float(m.state.cash), opening_cash), "trigger reclaims the day's receipts without reclaiming extra opening cash")
	pixiu.resting = true
	m._spawn_customer("noodles")
	m.advance_minutes(35)
	for minute in range(90):
		if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
		if m.customers.is_empty() or m.customers.all(func(c):return bool(c.get("paid",false))):break
		m.advance_minutes(1)
	check(int(m.state.served) == 3, "another employee completes a real checkout after Pixiu rests")
	check(is_equal_approx(float(m.state.cash), opening_cash), "all subsequent cashiers continue to defer the day's receipts")
	check(is_equal_approx(float(m.state.world.outstanding_receipts), float(m.state.daily_revenue)), "every real checkout grows the day-wide receivable")
	var turnover := float(m.state.daily_revenue)
	var sales := float(m.state.ledger.sales)
	var served := int(m.state.served)
	m.state.total_minutes = 1440
	world.tick_minute()
	check(is_equal_approx(float(m.state.cash), opening_cash + m._money(turnover * 1.05)), "calendar boundary pays all deferred sales plus five percent of all-day turnover")
	check(is_zero_approx(float(m.state.world.outstanding_receipts)) and is_zero_approx(float(m.state.ledger.receivables)), "settlement clears the actual receivable and its ledger balance")
	check(float(m.state.ledger.sales) == sales and float(m.state.total_revenue) == turnover and int(m.state.served) == served, "settlement creates neither another sale nor another served customer")
	var settled_cash := float(m.state.cash)
	world.tick_minute()
	check(float(m.state.cash) == settled_cash, "repeated minute processing cannot pay the same day twice")
	check(world.collect_sales_receipt(7) == 7, "next-day sales return to immediate cash collection")
	check(world.validate_state(m.state.world, m.employees, int(m.state.total_minutes)), "settled receipt record remains valid for save")
	pixiu.resting = false
	m.state.total_minutes = 1440 + 360
	var definition: Dictionary = world._definition("pixiu_withholds")
	check(world._eligible(definition, "paying", {"employee_id":"pi_xiu", "amount":7}), "prior day's rolling cooldown does not suppress a new day's Pixiu event")
	check(not world._eligible(definition, "paying", {"employee_id":"pi_xiu", "amount":0}), "an escaped or zero-value bill cannot activate Pixiu's day bonus")

func _receipt_advances_and_save() -> void:
	var m = fresh()
	var world = m.full_rules.world
	# Targeted prior-spending fixture: gross sales 100, only 25 cash remains.
	m.state.cash = 25.0
	m.state.daily_revenue = 100.0
	m.state.total_revenue = 100.0
	m.full_rules.record("sales", 100, "触发前已确认销售")
	world._enqueue("pixiu_withholds", {"employee_id":"pi_xiu", "amount":50.0})
	if not world.pending_event().is_empty():world.choose(str(world.pending_event().options[0].id))
	check(float(m.state.cash) == 0 and float(m.state.world.outstanding_receipts) == 25, "spent earlier sales never force cash below zero")
	check(float(m.state.world.pixiu_receipts.advanced) == 75, "spent turnover is explicitly tracked as already advanced")
	var before: Dictionary = m.state.world.pixiu_receipts.duplicate(true)
	world._enqueue("pixiu_withholds", {"employee_id":"pi_xiu", "amount":50.0})
	if not world.pending_event().is_empty():world.choose(str(world.pending_event().options[0].id))
	check(m.state.world.pixiu_receipts == before, "duplicate event dispatch cannot reclaim or schedule the day's funds twice")
	m.full_rules.expansion._income(80, 100)
	check(float(m.state.cash) == 0 and float(m.state.world.outstanding_receipts) == 105, "external sales defer only actual net receipts after platform fees")
	check(float(m.state.world.pixiu_receipts.turnover) == 200 and float(m.state.world.pixiu_receipts.advanced) == 95, "gross turnover equals pending principal plus amounts already spent or deducted")
	check(float(m.state.ledger.sales) == 200 and float(m.state.ledger.expenses) == 20, "platform fee and gross sales keep their existing accounting treatment")
	var path := "/tmp/shanhai-pixiu-midday-save.json"
	check(m.save_game(path), "active all-day receivable saves through the actual model")
	var copy = Model.new(991)
	check(copy.load_game(path), "active all-day receivable reloads through strict model validation")
	var copied_world = copy.full_rules.world
	check(JSON.stringify(JSON.parse_string(JSON.stringify(copy.state.world.pixiu_receipts))) == JSON.stringify(JSON.parse_string(JSON.stringify(m.state.world.pixiu_receipts))), "all-day turnover, outstanding principal and prior advances survive reload")
	copy.state.total_minutes = 1440
	copied_world.tick_minute()
	check(float(copy.state.cash) == 115, "settlement pays 105 real principal plus 10 bonus, never reissues the spent 95")
	check(float(copy.state.ledger.other_income) == 10 and float(copy.state.ledger.sales) == 200, "only the five-percent gain is new income at settlement")
	var cash := float(copy.state.cash)
	copied_world.tick_minute()
	check(float(copy.state.cash) == cash, "reloaded return remains exactly once")
	var bad: Dictionary = m.state.world.duplicate(true)
	bad.pixiu_receipts.principal += 1
	check(not world.validate_state(bad, m.employees, int(m.state.total_minutes)), "save rejects a principal that disagrees with total turnover")
	bad = m.state.world.duplicate(true)
	bad.outstanding_receipts += 1
	check(not world.validate_state(bad, m.employees, int(m.state.total_minutes)), "save rejects unsupported receivable assets")
	var legacy: Dictionary = m.state.world.duplicate(true)
	legacy.erase("pixiu_receipts")
	legacy.outstanding_receipts = 50.0
	legacy.delayed.append({"due":1440,"effects":[{"type":"receipt_return","amount":52.5,"principal":50.0}],"context":{},"probability":1.0})
	check(world.validate_state(legacy, m.employees, int(m.state.total_minutes)), "older one-bill receivables remain readable without inventing another principal")

func _luwu_current_dish() -> void:
	var m = fresh()
	var world = m.full_rules.world
	m.events = [world._definition("luwu_fire").duplicate(true)]
	m.balance["events.default_probability"] = 1
	for employee in m.employees:
		if str(employee.role) in ["chef", "all"]: employee.resting = true
		employee.attributes.speed = 20
	var luwu: Dictionary = m._create_employee(m._employee_config("lu_wu"))
	luwu.attributes.speed = 20
	m.employees.append(luwu)
	m.state.unlocked_dishes.append("taowu_barbecue")
	m.full_rules.management.add_item("mountain_pork", 10)
	m._spawn_customer("taowu_barbecue")
	for minute in range(20):
		m.advance_minutes(1)
		if not m.state.world.history.is_empty(): break
	check(world.pending_event().is_empty() and str(m.state.world.history.back().id) == "luwu_fire", "actual Luwu barbecue cooking broadcasts fire control without forced choice")
	var customer: Dictionary = m.customers[0]
	var feedback: Dictionary = m.state.world.feedback
	check(str(feedback.type) == "broadcast" and not feedback.details.is_empty(), "fire control has visible resolved numeric effect feedback")
	check(is_equal_approx(float(customer.quality), minf(100, (75 + float(luwu.attributes.cooking)) * 1.1)), "fire control improves the triggering dish rather than only a future barbecue")
	check(int(m.state.world.modifiers[0].until) == int(m.state.total_minutes) + 120, "Luwu v1.5 effect lasts exactly two hours")
	var improved := float(customer.quality)
	check(not world.choose("finish").ok and float(customer.quality) == improved, "broadcast presents no claimable duplicate action")
	customer.paid = true
	world._enqueue("luwu_fire", {"employee_id":"lu_wu", "dish_id":"taowu_barbecue", "customer_id":int(customer.id)})
	check(float(customer.quality) == improved, "late event resolution never rewrites an already paid dish")
