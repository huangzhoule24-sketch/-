extends SceneTree

const Model = preload("res://scripts/core/game_model.gd")
var checks := 0
var failures := 0

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition: failures += 1; push_error(label)

func approx(actual: float, expected: float, label: String) -> void:
	check(absf(actual - expected) < 0.001, "%s: %.4f vs %.4f" % [label, actual, expected])

func _init() -> void:
	call_deferred("run")

func run() -> void:
	var m = Model.new(4291)
	approx(float(m.state.cash), 800.0, "v1.5 initial cash")
	approx(float(m.state.debt), 1200.0, "initial debt")
	check(m.employees.size() == 2, "initial two employees")
	check(m.state.layout.size() == 4 and int(m.state.seats) == 8, "initial four two-seat tables")
	check(m.employees.filter(func(e): return str(e.role) == "chef").size() == 1, "initial chef")
	check(m.employees.filter(func(e): return str(e.role) == "waiter").size() == 1, "initial waiter")
	var times := {0:"closed", 359:"closed", 360:"breakfast", 599:"breakfast", 600:"rest", 659:"rest", 660:"lunch", 839:"lunch", 840:"tea", 1019:"tea", 1020:"dinner", 1259:"dinner", 1260:"night_market", 1439:"night_market", 1440:"closed"}
	for minute in times:
		m.state.total_minutes = minute
		check(m.period() == times[minute], "period boundary %d" % minute)
	m = Model.new(4291)
	var minute_before := int(m.state.total_minutes)
	m.set_paused(true)
	m.advance_real(10.0)
	check(int(m.state.total_minutes) == minute_before, "pause stops real clock")
	m.set_paused(false)
	m.set_speed(3)
	m.advance_real(1.0)
	check(int(m.state.total_minutes) == minute_before + 3, "3x real clock")
	m.set_speed(9)
	check(m.speed == 4, "speed upper clamp")
	m.set_speed(0)
	check(m.speed == 1, "speed lower clamp")
	m.advance_real(-1.0)
	m.advance_real(INF)
	check(int(m.state.total_minutes) == minute_before + 3, "invalid real delta ignored")
	m.state.total_minutes = 599
	m.balance["customer.base_flow"] = 0.0
	m.advance_real(1.0)
	check(int(m.state.total_minutes) == 660, "rest skip reaches lunch through minute ticks")
	m.state.total_minutes = 1439
	m.advance_real(1.0)
	check(int(m.state.total_minutes) == 1800, "night skip reaches next morning")
	check(int(m.state.last_report.get("day", 0)) == 1, "closed skip still performs day settlement")
	m = Model.new(4291)
	m.balance["customer.base_flow"] = 0.0
	m.balance["customer.tip_chance"] = 0.0
	m._spawn_customer()
	check(m.customers.size() == 1, "customer created with actual available seat")
	var initial_cash := float(m.state.cash)
	var initial_ingredients := float(m.state.ingredients)
	var stages: Dictionary = {}
	var reserved_cost := 0.0
	var saved_pay_event: Dictionary = {}
	for minute in range(160):
		if not m.customers.is_empty():
			var guest: Dictionary = m.customers[0]
			stages[str(guest.stage)] = true
			if bool(guest.ingredients_reserved): reserved_cost = float(m._dish(str(guest.dish_id)).cost) / float(m.balance["ingredient.unit_price"])
			if str(guest.stage) == "paying" and int(guest.due_minute) > int(m.state.total_minutes):
				for event in m.scheduler:
					if str(event.type) == "customer_step" and str(event.stage) == "paying": saved_pay_event = event.duplicate(true)
		m.advance_minutes(1)
		if m.customers.is_empty() and int(m.state.served) > 0: break
	for stage in ["ordering", "cooking", "serving", "eating", "paying", "cleaning"]:
		check(stages.has(stage), "order traverses %s" % stage)
	check(int(m.state.served) == 1 and m.customers.is_empty(), "one completed customer frees table")
	approx(float(m.state.cash), initial_cash + float(m.state.total_revenue), "income credited exactly at checkout")
	approx(float(m.state.ingredients), initial_ingredients - reserved_cost, "ingredients reserved once")
	var after_checkout := float(m.state.cash)
	if not saved_pay_event.is_empty(): m._complete_customer_step(saved_pay_event)
	approx(float(m.state.cash), after_checkout, "stale checkout cannot duplicate income")
	m = Model.new(4291)
	m.balance["customer.base_flow"] = 0.0
	m.state.total_minutes = 1440
	m.state.cash = 500.0
	m._settle_day()
	approx(float(m.state.last_report.interest), 6.0, "first daily interest")
	approx(float(m.state.last_report.repayment), 100.0, "minimum principal repayment")
	approx(float(m.state.last_report.wages_due), 88.0, "initial daily wages")
	approx(float(m.state.last_report.rent_utilities), 80.0, "rent and utilities")
	approx(float(m.state.cash), 226.0, "daily outflow does not add revenue twice")
	approx(float(m.state.debt), 1100.0, "principal reduces liability")
	m = Model.new(4291)
	m.state.total_minutes = 1440
	m.state.cash = 110.0
	m._settle_day()
	approx(float(m.state.last_report.interest), 6.0, "interest paid first under cash shortage")
	approx(float(m.state.last_report.repayment), 100.0, "principal paid before wages")
	approx(float(m.state.last_report.wages), 4.0, "wages use remaining cash")
	approx(float(m.state.last_report.rent_utilities), 0.0, "rent follows wages")
	var wage_employee: Dictionary = m._create_employee(m._employee_config("zhu_long"))
	wage_employee.role = "all"
	wage_employee.loyalty = 60
	approx(m.employee_wage(wage_employee), 116.0, "SSR all-role additive wage")
	wage_employee.loyalty = 80
	approx(m.employee_wage(wage_employee), 104.0, "high-loyalty wage multiplier")
	wage_employee.loyalty = 20
	approx(m.employee_wage(wage_employee), 139.0, "low-loyalty wage multiplier")
	m = Model.new(4291)
	m.state.cash = 20000.0
	m.state.gems = 100
	m.state.hire_counts.normal = 9
	var normal: Dictionary = m.recruit("normal")
	check(str(normal.get("rarity", "")) in ["SR", "SSR"], "normal tenth draw pity")
	check(int(m.state.hire_counts.advanced) == 0, "ordinary pity leaves advanced counter unchanged")
	m.state.hire_counts.advanced = 29
	var advanced: Dictionary = m.recruit("advanced")
	check(str(advanced.get("rarity", "")) == "SSR", "advanced thirtieth draw prioritizes SSR pity")
	check(int(m.state.hire_counts.normal) == 10, "advanced pity leaves ordinary counter unchanged")
	m.state.hire_counts.normal = 49
	check(str(m.recruit("normal").get("rarity", "")) == "SSR", "normal fiftieth draw SSR pity")
	var same_id := str(m.employees[0].id)
	var owned_before: int = m.employees.size()
	m.state.contracts = [same_id]
	m.state.hire_tickets = 1
	var duplicate: Dictionary = m.recruit("contract")
	check(bool(duplicate.get("duplicate", false)), "duplicate contract recognizes owned employee")
	check(m.employees.size() == owned_before, "duplicate does not add employee")
	check(int(m.state.fragments.get(same_id, 0)) == int(m.balance["hire.duplicate_fragments"]), "duplicate gives configured fragments")
	m = Model.new(4291)
	m.advance_real(0.37)
	var save_path := "user://foundation-regression.json"
	check(m.save_game(save_path), "save foundation")
	var original_state := JSON.stringify(m.state)
	var loaded = Model.new(8877)
	check(loaded.load_game(save_path), "load foundation")
	check(JSON.stringify(loaded.state) == original_state, "save preserves all foundation state")
	approx(float(loaded._fraction), 0.37, "fractional time preserved")
	var corrupted: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(save_path))
	corrupted.state.cash = -1
	var file := FileAccess.open("user://foundation-invalid.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(corrupted)); file.close()
	var before_invalid := JSON.stringify(loaded.state)
	check(not loaded.load_game("user://foundation-invalid.json"), "reject negative-money tampering")
	check(JSON.stringify(loaded.state) == before_invalid, "failed load preserves current state")
	print("FOUNDATION CHECKS: %d passed, %d failed" % [checks - failures, failures])
	quit(1 if failures > 0 else 0)
