extends SceneTree
## Actual in-memory game fixtures; never uses the player's save path.
const Model = preload("res://scripts/core/game_model.gd")
const Resolver = preload("res://scripts/core/effect_resolver.gd")
var checks := 0
var failures := 0
var covered_employees := {}
var covered_dishes := {}


func expect(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + label)


func near(actual: float, expected: float, label: String) -> void:
	expect(is_equal_approx(actual, expected), "%s (%.4f vs %.4f)" % [label, actual, expected])


func fixture(ids: Array = []) -> Variant:
	var game = Model.new(4817)
	game.start_full()
	game.state.stage = 4
	game.state.cash = 500000
	game.state.gems = 200
	game.paused = true
	game.employees.clear()
	for id in ids:
		for definition in game.catalog:
			if str(definition.id) == str(id): game.employees.append(game._create_employee(definition))
	game.full_rules.ensure_state_defaults()
	for ingredient in game.full_rules.management.ingredients:
		game.full_rules.management.add_item(str(ingredient.id), 10000, 10000 * float(ingredient.price))
	for dish in game.dishes:
		if not str(dish.id) in game.state.unlocked_dishes: game.state.unlocked_dishes.append(str(dish.id))
	game.balance["customer.tip_chance"] = 0
	# Species-effect fixtures isolate attribute-derived price/tip changes. The
	# attribute regressions below explicitly enable these three coefficients.
	game.balance["coeff.charm_price"] = 0
	game.balance["coeff.eloquence_price"] = 0
	game.balance["coeff.charm_tip"] = 0
	game.full_rules.config.defaults.escape_probability = 0
	return game


func resolver(game: Variant) -> RefCounted:
	return Resolver.new(game)


func customer(game: Variant, dish_id: String, stage: String = "paying", employee_id: String = "", chef_id: String = "") -> Dictionary:
	var entry := {"id": game._next_customer_id, "seat": game._next_customer_id - 1, "stage": stage, "dish_id": dish_id, "type": "human", "due_minute": int(game.state.total_minutes), "arrival_minute": int(game.state.total_minutes), "price": 100.0, "worker": employee_id, "chef_id": chef_id, "ingredients_reserved": false, "remaining_minutes": 0, "paid": false, "quality": 75.0, "task_started_minute": int(game.state.total_minutes), "tip_bonus": 0.0, "ingredient_cost": 0.0, "dish_effects": game.full_rules.management.modifiers(dish_id)}
	game._next_customer_id += 1
	game.customers.append(entry)
	return entry


func complete(game: Variant, entry: Dictionary) -> void:
	game._complete_customer_step({"type": "customer_step", "due": int(entry.due_minute), "stage": str(entry.stage), "customer_id": int(entry.id), "employee_id": str(entry.worker)})


func force_event(game: Variant, id: String) -> void:
	for event in game.events:
		if str(event.id) == id:
			event.erase("probability_key")
			event.probability = 1.0


func assign(game: Variant, dish_id: String, stage: String = "queued") -> Dictionary:
	var entry := customer(game, dish_id, stage)
	entry.due_minute = -1
	game._assign_tasks()
	expect(int(entry.due_minute) > int(game.state.total_minutes), "%s %s is assigned to a real worker" % [dish_id, stage])
	return entry


func paired_tasks(id: String, dish_id: String, stage: String) -> Array:
	var skilled = fixture([id])
	var baseline = fixture([id])
	baseline.employees[0].id = "control"
	for game in [skilled, baseline]:
		game.employees[0].role = "all"
		for key in ["serve", "clean", "pay", "order"]: game.balance["customer.%s_minutes" % key] = 40
	return [skilled, baseline, assign(skilled, dish_id, stage), assign(baseline, dish_id, stage)]


func duration(game: Variant, entry: Dictionary) -> int:
	return int(entry.due_minute) - int(game.state.total_minutes)


func sample_menu(game: Variant, ids: Array, count: int) -> Dictionary:
	game.state.menu_enabled = ids.duplicate()
	var counts := {}
	for id in ids: counts[id] = 0
	for _index in count:
		# Arrival has no dish choice in v1.5. Isolate the weighted ordering
		# sampler; eligibility/recommendation is covered by v15_customer_tests.
		var selected: Dictionary = game.full_rules.customer_service._weighted_dish(game.full_rules.customer_service.menu_dishes(true), {})
		if not selected.is_empty(): counts[str(selected.id)] += 1
	return counts


func integrated_checks() -> void:
	# Compare scheduled tasks with an identical employee whose species skill is
	# absent. This catches a correct modifier dictionary left out of the model.
	var pair := paired_tasks("xian_yang", "ranyiyu_soup", "queued")
	expect(float(pair[2].quality) > float(pair[3].quality), "qianyang improves actual reserved soup quality")
	pair = paired_tasks("xiao", "noodles", "serving")
	# Owls only receive the night bonus; reschedule both fixtures at 21:00.
	for game in [pair[0], pair[1]]:
		game.customers.clear()
		game.scheduler.clear()
		game.state.total_minutes = 1260
	var night := assign(pair[0], "noodles", "serving")
	var night_base := assign(pair[1], "noodles", "serving")
	expect(duration(pair[0], night) < duration(pair[1], night_base), "owl night skill shortens actual scheduled service")
	pair = paired_tasks("er_shu", "noodles", "serving")
	expect(duration(pair[0], pair[2]) < duration(pair[1], pair[3]), "earmouse skill shortens actual scheduled service")
	pair = paired_tasks("tao_tie", "taotie_buffet", "queued")
	expect(float(pair[2].ingredient_cost) > float(pair[3].ingredient_cost), "taotie actually consumes additional valued stock")
	expect(duration(pair[0], pair[2]) < duration(pair[1], pair[3]), "taotie actually cooks faster")
	pair = paired_tasks("bi_fang", "bifang_wings", "queued")
	expect(float(pair[2].quality) > float(pair[3].quality), "bifang increases actual barbecue quality")
	pair = paired_tasks("lu_wu", "bifang_wings", "queued")
	near(float(pair[2].task_motion.work_minutes), float(pair[3].task_motion.work_minutes) * 0.8, "luwu applies exact time reduction to scheduled cooking work")
	pair = paired_tasks("jing_wei", "noodles", "cleaning")
	expect(duration(pair[0], pair[2]) < duration(pair[1], pair[3]), "jingwei cleans an occupied table faster")
	for game in [pair[0], pair[1]]:
		game.employees[0].mood = 70
		game._settle_day()
	expect(float(pair[0].employees[0].mood) < float(pair[1].employees[0].mood), "jingwei drawback enters actual daily morale settlement")
	pair = paired_tasks("qiong_qi", "qiongqi_hotpot", "queued")
	expect(float(pair[2].price) > float(pair[3].price), "qiongqi spicy price enters actual order price")
	pair = paired_tasks("ying_long", "yinglong_hotpot", "queued")
	expect(float(pair[2].quality) > float(pair[3].quality), "yinglong aquatic quality enters real order")
	pair = paired_tasks("di_jiang", "noodles", "serving")
	expect(float(pair[2].task_motion.work_minutes) > 1 and float(pair[2].task_motion.travel_minutes) <= float(pair[3].task_motion.travel_minutes), "dijiang skips travel obstacles while preserving actual serving work")
	complete(pair[0], pair[2])
	expect(float(pair[2].satisfaction) > 50, "dijiang increases actual diner satisfaction")
	var game = fixture(["pi_xiu"])
	var entry := customer(game, "noodles", "paying", "pi_xiu")
	var before := float(game.state.cash)
	complete(game, entry)
	near(float(game.state.cash) - before, 9, "pixiu checkout bonus uses the actual 8-yuan dish and stage flooring")
	game = fixture(["jiu_wei_hu"])
	game.balance["coeff.tip_chance"] = 1
	game.balance["customer.tip_chance"] = 1
	entry = customer(game, "fried_rice", "serving", "jiu_wei_hu")
	complete(game, entry)
	expect(float(entry.tip_bonus) > 0, "fox tips survive actual service stage")
	entry.stage = "paying"
	entry.worker = "jiu_wei_hu"
	entry.due_minute = int(game.state.total_minutes)
	before = float(game.state.cash)
	complete(game, entry)
	expect(float(game.state.cash) - before == 11, "fox served rice order pays the actual one-yuan tip")
	game = fixture(["guan_guan"])
	game.state.promotion_until = int(game.state.total_minutes) + 60
	entry = customer(game, "noodles", "serving", "guan_guan")
	complete(game, entry)
	expect(float(entry.satisfaction) < 52, "guanguan noisy promotion actually lowers diner mood")
	game = fixture(["er_shu", "gu_diao"])
	game.balance["coeff.earmouse_startle_chance"] = 1
	before = float(game._employee("er_shu").mood)
	entry = customer(game, "noodles", "serving", "gu_diao")
	complete(game, entry)
	expect(float(game._employee("er_shu").mood) < before, "earmouse really startles when loud bird serves")
	game = fixture(["gu_diao"])
	game.balance["coeff.gudiao_human_loss"] = 1
	game.balance["customer.type_weight_human"] = 1
	for kind in ["monster", "descendant", "special"]: game.balance["customer.type_weight_" + kind] = 0
	game.balance["coeff.gudiao_special"] = 0
	game._spawn_customer()
	expect(game.customers.is_empty() and int(game.state.lost) == 1, "gudiao loss happens in actual arrival path")
	game.balance["coeff.gudiao_special"] = 100
	var special := 0
	for _index in 100:
		if game._roll_customer_type() == "special": special += 1
	expect(special > 90, "gudiao alters actual generated customer types")
	game = fixture(["tao_wu"])
	game.balance["coeff.refuse_order_prob"] = 1
	game.set_employee_rest("tao_wu", true)
	expect(not bool(game._employee("tao_wu").resting), "taowu refuses a real rest instruction")
	game = fixture(["xie_zhi"])
	game.balance["coeff.xiezhi_complaint_success"] = 1
	entry = customer(game, "noodles", "queued")
	entry.arrival_minute = int(game.state.total_minutes) - 200
	before = float(game.state.reputation)
	game._expire_customers()
	expect(game.customers.is_empty() and float(game.state.reputation) == before, "xiezhi resolves a real expired customer's complaint")
	game = fixture(["ying_zhao"])
	var fast_flow: int = game._spawn_interval()
	game._employee("ying_zhao").resting = true
	expect(game._spawn_interval() > fast_flow, "yingzhao changes real next-arrival interval")
	game = fixture(["ying_long"])
	game.state.world.weather = "rain"
	fast_flow = game._spawn_interval()
	game._employee("ying_long").resting = true
	expect(game._spawn_interval() > fast_flow, "yinglong rain skill changes real arrival interval")
	game = fixture(["xian_yang"])
	entry = assign(game, "noodles")
	var noodles_duration := duration(game, entry)
	game.customers.clear()
	game.scheduler.clear()
	entry = assign(game, "fried_rice")
	expect(duration(game, entry) < noodles_duration, "fried rice prepares faster in actual scheduler")
	game.customers.clear()
	game.scheduler.clear()
	entry = assign(game, "luwu_platter")
	var platter_duration := duration(game, entry)
	game.customers.clear()
	game.scheduler.clear()
	game.balance["coeff.luwu_dish_time_reduction"] = 0
	entry = assign(game, "luwu_platter")
	expect(duration(game, entry) > platter_duration, "luwu dish's own time bonus enters scheduler")
	game = fixture(["xian_yang"])
	entry = assign(game, "dangkang_rice")
	var rice_cost := float(entry.ingredient_cost)
	game.customers.clear()
	game.scheduler.clear()
	game.balance["coeff.rice_cost"] = 0
	entry = assign(game, "dangkang_rice")
	expect(float(entry.ingredient_cost) > rice_cost, "dangkang rice genuinely conserves valued ingredients")
	game = fixture(["er_shu"])
	for id in ["phoenix_soup", "zhulong_ramen"]:
		entry = customer(game, id, "paying", "er_shu")
		entry.quality = 0
		before = float(game.state.reputation)
		complete(game, entry)
		expect(float(game.state.reputation) - before >= game._b("customer.quality_good_review_rep"), id + " actual checkout guarantees its first good review")
	game.state.world.regulars = 0
	game.state.menu_enabled = ["xiezhi_set"]
	game.balance["coeff.xiezhi_regulars"] = 1
	entry = customer(game, "xiezhi_set", "paying", "er_shu")
	complete(game, entry)
	expect(int(game.state.world.regulars) == 1, "paid justice meal truly creates a returning customer")
	var traffic_base: float = game.full_rules.traffic_multiplier()
	game.state.world.regulars = 100
	var each: float = game.full_rules.world._b("events.regular_traffic_each")
	var cap: float = game.full_rules.world._b("events.regular_traffic_cap")
	near(game.full_rules.traffic_multiplier() / traffic_base, (1 + minf(cap, 100 * each)) / (1 + minf(cap, each)), "regular customers modify traffic exactly once")
	game = fixture(["er_shu"])
	game.state.menu_enabled = ["noodles"]
	game.balance["coeff.fish_repeat"] = 1
	entry = customer(game, "ranyiyu_soup", "cleaning", "er_shu")
	var repeat_id: int = int(entry.id)
	var repeat_seat: int = int(entry.seat)
	complete(game, entry)
	expect(game.customers.size() == 1 and int(entry.id) == repeat_id and int(entry.seat) == repeat_seat and str(entry.dish_id) == "ranyiyu_soup" and str(entry.stage) == "ordering", "fish soup repeats one portion for the same actual guest and seat")
	game = fixture(["xian_yang"])
	game.state.total_minutes = 90 * 1440 + 360
	var sample := sample_menu(game, ["noodles", "qianyang_soup"], 1200)
	expect(int(sample.qianyang_soup) > int(sample.noodles) * 1.6, "winter soup double demand influences order-choice weighting")
	game.state.world.weather = "rain"
	sample = sample_menu(game, ["noodles", "yinglong_hotpot"], 1200)
	expect(int(sample.yinglong_hotpot) > int(sample.noodles) * 1.6, "rain hotpot double demand influences order-choice weighting")
	game.state.total_minutes = 1260
	sample = sample_menu(game, ["noodles", "tiangou_tempura"], 3000)
	expect(int(sample.tiangou_tempura) > int(sample.noodles) * 1.15, "tempura night demand influences order-choice weighting")
	game.state.world.weather = "clear"
	sample = sample_menu(game, ["noodles", "zhuyu_salad"], 3000)
	expect(int(sample.zhuyu_salad) > int(sample.noodles) * 1.05, "healthy salad changes order-choice weighting")
	game = fixture(["xian_yang"])
	game.state.menu_enabled = ["noodles"]
	game.full_rules.promote_kind("flyer")
	var promotion := float(game.state.promotion_bonus)
	game.state.menu_enabled = ["taowu_barbecue"]
	game.state.promotion_until = 0
	game.full_rules.promote_kind("flyer")
	near(float(game.state.promotion_bonus), promotion * 2, "taowu signature dish doubles real flyer effect")
	game = fixture(["xian_yang"])
	game.state.management.hidden_effects.hundun_wonton = "price_mult"
	entry = assign(game, "hundun_wonton")
	var hidden_price := float(entry.price)
	game.state.management.hidden_effects.clear()
	game.customers.clear()
	game.scheduler.clear()
	entry = assign(game, "hundun_wonton")
	expect(float(entry.price) < hidden_price, "hundun hidden outcome affects actual reserved price")
	game = fixture(["er_shu"])
	game.balance["coeff.salad_complaints"] = 1
	entry = customer(game, "yingzhao_salad", "queued")
	entry.arrival_minute = int(game.state.total_minutes) - 200
	before = float(game.state.reputation)
	game._expire_customers()
	expect(float(game.state.reputation) == before, "salad complaint reduction changes real timeout result")
	game = fixture(["er_shu"])
	game.balance["coeff.jingwei_dish_serving_reduction"] = 1
	entry = assign(game, "jingwei_bibimbap", "serving")
	expect(float(entry.get("task_motion",{}).get("work_minutes",INF)) <= 0.01, "jingwei dish reduces actual service work while retaining real pass-to-table travel")
	# Ordinary serving keeps the customer's actual waiter for complaint handling.
	game = fixture(["er_shu"])
	entry = customer(game, "noodles", "serving", "er_shu")
	complete(game, entry)
	expect(str(entry.serving_employee_id) == "er_shu", "customer retains actual serving employee for complaints")
	# v1.3's extended attributes must change real work and cash decisions.
	game = fixture(["pi_xiu"])
	game.balance["customer.pay_minutes"] = 40
	game._employee("pi_xiu").attributes.calculation = 0
	entry = assign(game, "noodles", "paying")
	var slow_cashier := duration(game, entry)
	game.customers.clear()
	game.scheduler.clear()
	game._employee("pi_xiu").attributes.calculation = 20
	entry = assign(game, "noodles", "paying")
	expect(duration(game, entry) < slow_cashier, "calculation attribute shortens real cashier queue")
	game = fixture(["pi_xiu"])
	game.full_rules.config.defaults.escape_probability = 1
	game.balance["coeff.calculation_escape_reduction"] = 1
	game.balance["coeff.calculation_escape_cap"] = 1
	entry = customer(game, "noodles", "paying", "pi_xiu")
	before = float(game.state.cash)
	complete(game, entry)
	expect(float(game.state.cash) - before == 9, "calculation prevention preserves the actual nine-yuan payment")
	expect(int(game.state.effect_resolution.prevented_escapes) == 1, "prevented escape counter reflects an actual cashier decision")
	game = fixture(["guan_guan"])
	game.balance["coeff.eloquence_complaint_reduction"] = 1
	game.balance["coeff.eloquence_complaint_cap"] = 1
	entry = customer(game, "noodles", "queued")
	entry.arrival_minute = int(game.state.total_minutes) - 200
	before = float(game.state.reputation)
	game._expire_customers()
	expect(float(game.state.reputation) == before, "eloquence resolves real timeout complaint")
	game = fixture(["xian_yang"])
	game._employee("xian_yang").attributes.endurance = 0
	game._employee("xian_yang").stamina = 80
	game._tick_employees()
	var low_endurance := 80 - float(game._employee("xian_yang").stamina)
	game._employee("xian_yang").attributes.endurance = 20
	game._employee("xian_yang").stamina = 80
	game._tick_employees()
	expect(80 - float(game._employee("xian_yang").stamina) < low_endurance, "endurance reduces real work fatigue")
	game._employee("xian_yang").resting = true
	game._employee("xian_yang").stamina = 40
	game._tick_employees()
	var recovered := float(game._employee("xian_yang").stamina) - 40
	game._employee("xian_yang").attributes.endurance = 0
	game._employee("xian_yang").stamina = 40
	game._tick_employees()
	expect(float(game._employee("xian_yang").stamina) - 40 < recovered, "endurance accelerates actual rest recovery")
	game = fixture(["ran_yi_yu"])
	game.balance["coeff.ranyiyu_income_chance"] = 1
	game.full_rules.config.defaults.escape_probability = 1
	entry = customer(game, "ranyiyu_soup", "paying", "ran_yi_yu", "ran_yi_yu")
	before = float(game.state.cash)
	complete(game, entry)
	near(float(game.state.cash), before, "escaped order never credits fish extra income to wallet")
	near(float(game.state.effect_resolution.extra_income_total), 0, "escaped order never records unrealized fish income")
	game = fixture(["tian_gou"])
	game.full_rules.config.defaults.escape_probability = 1
	game.balance["coeff.tiangou_prevent_escape"] = 1
	entry = customer(game, "noodles", "paying", "tian_gou")
	entry.quoted_dish_price = 0 # Explicit zero-quote boundary; raw customer.price is no longer authoritative.
	complete(game, entry)
	expect(int(game.state.effect_resolution.prevented_escapes) == 0, "free order never invents a prevented escape")
	game = fixture(["xian_yang"])
	game.full_rules.config.defaults.escape_probability = 1
	game.state.escape_reduction = 1
	entry = customer(game, "noodles", "paying", "xian_yang")
	before = float(game.state.cash)
	complete(game, entry)
	near(float(game.state.cash) - before, 8, "cashier desk protection preserves actual eight-yuan payment")
	expect(int(game.state.effect_resolution.prevented_escapes) == 1, "cashier desk prevention is counted once")
	game.full_rules.effects.after_payment(entry, game._employee("xian_yang"))
	expect(int(game.state.effect_resolution.prevented_escapes) == 1, "post-payment retry cannot duplicate escape prevention count")
	near(game.full_rules.effects.cashier_factor({}), 1, "missing calculation defaults to zero")
	near(game.full_rules.effects.stamina_drain_factor({}), 1, "missing endurance supplies no fatigue reduction")
	near(game.full_rules.effects.rest_recovery_factor({}), 1, "missing endurance supplies no recovery bonus")
	game = fixture()
	entry = customer(game, "noodles")
	near(game.full_rules.effects.complaint_probability(entry), 1, "missing eloquence supplies no complaint bonus")
	game = fixture(["guan_guan"])
	game.balance["coeff.charm_price"] = 0.01
	game.balance["coeff.eloquence_price"] = 0.01
	game._employee("guan_guan").attributes.charm = 10
	game._employee("guan_guan").attributes.eloquence = 10
	entry = customer(game, "noodles", "paying", "guan_guan")
	before = float(game.state.cash)
	complete(game, entry)
	near(float(game.state.cash) - before, 8, "cashier charm and eloquence no longer add a personal price premium")
	game = fixture(["er_shu"])
	game.balance["coeff.charm_tip"] = 0.005
	game._employee("er_shu").attributes.charm = 10
	entry = customer(game, "noodles", "serving", "er_shu")
	complete(game, entry)
	near(float(entry.tip_bonus), 0.05, "actual serving employee charm raises order tip probability")


func employee_checks() -> void:
	var game = fixture(["xian_yang"])
	near(game.full_rules.quality_multiplier(game._employee("xian_yang"), game._dish("qianyang_soup")), 1.05, "qianyang signature soup quality")
	near(game.full_rules.quality_multiplier(game._employee("xian_yang"), game._dish("ranyiyu_soup")), 1.05, "qianyang skill applies to all soups")
	covered_employees.xian_yang = true
	game = fixture(["xiao"])
	game.state.total_minutes = 1260
	near(game.full_rules.speed_multiplier(game._employee("xiao"), "serving"), 1.15, "owl night speed")
	game.state.total_minutes = 1440
	near(game.full_rules.speed_multiplier(game._employee("xiao"), "serving"), 1.0, "owl night bonus stops at midnight")
	covered_employees.xiao = true
	game = fixture(["er_shu"])
	near(game.full_rules.speed_multiplier(game._employee("er_shu"), "serving"), 1.1, "earmouse serving speed")
	covered_employees.er_shu = true
	for id in ["guan_guan", "e_shou", "tao_wu"]:
		game = fixture([id])
		var worker: Dictionary = game._employee(id)
		var base: float = 1.0 + float(worker.attributes.get("charm", 0)) * game._b("promotion.sales_charm_bonus") + float(worker.attributes.get("eloquence", 0)) * game._b("promotion.sales_eloquence_bonus")
		var bonus := {"guan_guan":0.05, "e_shou":0.2, "tao_wu":0.15}
		expect(game.full_rules.promote_kind("flyer").ok, id + " can promote")
		near(float(game.state.promotion_bonus), 0.1 * base * (1.0 + float(bonus[id])), id + " skill changes actual promotion")
		covered_employees[id] = true
	game = fixture(["tao_tie"])
	near(game.full_rules.speed_multiplier(game._employee("tao_tie"), "cooking"), 1.15, "taotie cook speed")
	near(game.full_rules.ingredient_multiplier(game._employee("tao_tie")), 1.1, "taotie ingredient drawback")
	game._employee("tao_tie").skill_level = 3
	expect(game.full_rules.ingredient_multiplier(game._employee("tao_tie")) > 1.1, "taotie skill growth also scales ingredient drawback")
	covered_employees.tao_tie = true
	game = fixture(["ran_yi_yu"])
	game.balance["coeff.ranyiyu_income_chance"] = 1
	var entry := customer(game, "ranyiyu_soup", "paying", "ran_yi_yu", "ran_yi_yu")
	var cash := float(game.state.cash)
	complete(game, entry)
	near(float(game.state.cash) - cash, 24, "ranyiyu soup extra income enters actual cash on the twenty-yuan recipe")
	covered_employees.ran_yi_yu = true
	game = fixture(["dang_kang"])
	force_event(game, "dangkang_harvest")
	game.state.total_minutes = 14400
	game.full_rules.world.on_day()
	expect(str(game.full_rules.world.pending_event().get("type",""))=="notice", "dangkang discount waits for its one confirmation")
	game.full_rules.world.choose(str(game.full_rules.world.pending_event().options[0].id))
	near(game.full_rules.management.stock_price("generic"), 2.4, "dangkang discount affects procurement")
	covered_employees.dang_kang = true
	game = fixture(["tian_gou"])
	game.balance["coeff.tiangou_prevent_escape"] = 1
	game.full_rules.config.defaults.escape_probability = 1
	entry = customer(game, "noodles", "paying", "tian_gou")
	cash = float(game.state.cash)
	complete(game, entry)
	near(float(game.state.cash) - cash, 8, "tiangou actual eight-yuan checkout obeys prevention coefficient")
	covered_employees.tian_gou = true
	game = fixture(["gu_diao"])
	game.balance["coeff.gudiao_human_loss"] = 1
	expect(not resolver(game).allow_customer("human"), "gudiao can frighten ordinary customer")
	expect(resolver(game).special_customer_bonus() > 0, "gudiao increases special arrival probability")
	covered_employees.gu_diao = true
	game = fixture(["jiu_wei_hu"])
	near(game.full_rules.tip_bonus(game._employee("jiu_wei_hu")), 0.3, "fox tips probability")
	covered_employees.jiu_wei_hu = true
	game = fixture(["bi_fang"])
	near(game.full_rules.quality_multiplier(game._employee("bi_fang"), game._dish("bifang_wings")), 1.3, "bifang barbecue quality")
	near(game.full_rules.quality_multiplier(game._employee("bi_fang"), game._dish("noodles")), 1.0, "bifang category guard")
	covered_employees.bi_fang = true
	game = fixture(["pi_xiu"])
	near(game.full_rules.checkout_multiplier(game._employee("pi_xiu")), 1.15, "pixiu checkout bonus")
	cash = float(game.state.cash)
	game.recruit("normal")
	near(cash - float(game.state.cash), 210, "pixiu recruiting surcharge")
	covered_employees.pi_xiu = true
	game = fixture(["ying_zhao"])
	near(game.full_rules.traffic_multiplier(), 1.1, "yingzhao actual traffic")
	entry = customer(game, "noodles", "serving", "ying_zhao")
	complete(game, entry)
	expect(float(entry.get("satisfaction", 50)) > 50, "yingzhao actual customer mood")
	covered_employees.ying_zhao = true
	game = fixture(["lu_wu"])
	var fx: Dictionary = game.full_rules.management.modifiers("bifang_wings", game._employee("lu_wu"))
	near(resolver(game).work_multiplier(game._employee("lu_wu"), "cooking", game._dish("bifang_wings")) / float(fx.cook_speed), 0.8, "luwu exact 20 percent time reduction")
	covered_employees.lu_wu = true
	game = fixture(["jing_wei"])
	near(resolver(game).work_multiplier(game._employee("jing_wei"), "cleaning"), 1.0 / 1.3, "jingwei cleaning speed")
	expect(resolver(game).daily_mood_cost(game._employee("jing_wei")) > 1, "jingwei mood drawback")
	covered_employees.jing_wei = true
	game = fixture(["qiong_qi"])
	near(float(game.full_rules.management.modifiers("qiongqi_hotpot", game._employee("qiong_qi")).price_mult), 1.2, "qiongqi spicy price")
	covered_employees.qiong_qi = true
	game = fixture(["tao_wu"])
	game.balance["coeff.refuse_order_prob"] = 1
	expect(not resolver(game).instruction_allowed(game._employee("tao_wu")), "taowu refuses commands at configured probability")
	game = fixture(["hun_dun"])
	expect(game.full_rules.management.employee_effects(game._employee("hun_dun")).research_bonus > 0, "hundun research bonus exposed")
	game.state.unlocked_dishes.erase("hundun_wonton")
	var research: Dictionary = game.full_rules.management.perform("research", {"dish_id":"hundun_wonton", "employee_id":"hun_dun"})
	expect(research.ok, "hundun research starts")
	if research.ok: expect(int(game.state.management.projects[0].due) - int(game.state.total_minutes) > 30, "hundun slower research drawback")
	covered_employees.hun_dun = true
	game = fixture(["xie_zhi"])
	entry = customer(game, "noodles")
	near(resolver(game).complaint_probability(entry), 0.7 * (1 - 6 * 0.03), "xiezhi complaint success stacks with eloquence")
	covered_employees.xie_zhi = true
	game = fixture(["feng_huang", "xiao"])
	force_event(game, "phoenix_rebirth")
	game._employee("feng_huang").stamina = 0.01
	game._employee("xiao").mood = 80
	game._tick_employees()
	game.full_rules.world.choose(str(game.full_rules.world.pending_event().options[0].id))
	expect(float(game._employee("feng_huang").stamina) > 90, "phoenix revives at exhaustion")
	expect(float(game._employee("xiao").mood) > 80, "phoenix boosts team morale")
	covered_employees.feng_huang = true
	game = fixture(["bai_ze", "xian_yang"])
	var training: Dictionary = game.full_rules.management.perform("train_attribute", {"employee_id":"xian_yang", "attribute":"cooking"})
	expect(training.ok and int(training.due) - int(game.state.total_minutes) == 21, "baize applies literal 0.67 training time rounded upward")
	covered_employees.bai_ze = true
	game = fixture(["ying_long"])
	near(game.full_rules.quality_multiplier(game._employee("ying_long"), game._dish("yinglong_hotpot")), 1.4, "yinglong aquatic quality")
	game.state.world.weather = "rain"
	near(resolver(game).traffic_multiplier(), 1.2, "yinglong rain traffic")
	covered_employees.ying_long = true
	game = fixture(["zhu_long"])
	expect(game.full_rules.world.perform("zhulong_shift", {"period":"dinner"}).ok, "zhulong changes period flow")
	expect(not game.full_rules.world.perform("zhulong_shift", {"period":"dinner"}).ok, "zhulong once per day")
	game.state.total_minutes = 1440
	near(game.full_rules.world.modifier("traffic"), 1.0, "zhulong cannot open midnight business")
	covered_employees.zhu_long = true
	game = fixture(["di_jiang"])
	expect(resolver(game).ignores_obstacles(game._employee("di_jiang")), "dijiang ignores obstacles")
	near(float(game.full_rules.management.modifiers("noodles", game._employee("di_jiang")).serve_mult), 1, "dijiang obstacle skill preserves serving work")
	covered_employees.di_jiang = true
	game = fixture(["jiu_ying"])
	game.state.layout.append({"id":"stove","x":13,"y":0,"w":1,"h":1})
	for _index in 4:
		entry = customer(game, "noodles", "queued")
		entry.due_minute = -1
	game._assign_tasks()
	expect(game._worker_task_count("jiu_ying") == 3, "jiuying truly cooks three independent customer orders")
	expect(game.customers.filter(func(c: Dictionary) -> bool: return str(c.stage) == "queued").size() == 1, "jiuying fourth dish waits for capacity")
	covered_employees.jiu_ying = true


func dish_checks() -> void:
	var game = fixture(["xian_yang", "er_shu"])
	expect(int(game._dish("fried_rice").cook_minutes) < int(game._dish("noodles").cook_minutes), "fried rice shorter base preparation")
	covered_dishes.noodles = true
	covered_dishes.fried_rice = true
	var entry := customer(game, "plum_juice", "serving", "er_shu")
	complete(game, entry)
	expect(float(entry.get("satisfaction", 50)) > 50, "plum juice improves actual customer satisfaction")
	covered_dishes.plum_juice = true
	game.state.total_minutes = 90 * 1440 + 360
	near(resolver(game).dish_weight("qianyang_soup"), 2, "winter soup double demand from calendar")
	entry = customer(game, "qianyang_soup", "serving", "er_shu")
	complete(game, entry)
	expect(float(entry.get("satisfaction", 50)) >= 55, "winter soup warmth improves actual customer satisfaction")
	covered_dishes.qianyang_soup = true
	expect(float(game._dish("bifang_wings").price) > float(game._dish("noodles").price), "barbecue high ticket value")
	covered_dishes.bifang_wings = true
	entry = customer(game, "fox_milk", "serving", "er_shu")
	complete(game, entry)
	near(float(entry.tip_bonus), 0.05, "fox milk changes real tip probability")
	covered_dishes.fox_milk = true
	game.state.world.weather = "rain"
	near(resolver(game).dish_weight("yinglong_hotpot"), 2, "rain hotpot double demand without duplicate generic-weather stacking")
	covered_dishes.yinglong_hotpot = true
	entry = customer(game, "taotie_buffet", "serving", "er_shu")
	complete(game, entry)
	expect(int(entry.due_minute) - int(game.state.total_minutes) == 24, "buffet changes actual dining duration")
	covered_dishes.taotie_buffet = true
	entry = customer(game, "phoenix_soup")
	expect(resolver(game).review_adjustment(entry, -1) >= 2, "phoenix soup guarantees good review")
	covered_dishes.phoenix_soup = true
	expect(resolver(game).dish_weight("zhuyu_salad") > 1, "zhuyu healthy food demand")
	covered_dishes.zhuyu_salad = true
	expect(resolver(game).work_multiplier(game._employee("xian_yang"), "cooking", game._dish("luwu_platter")) < 1, "luwu platter reduces real preparation time")
	covered_dishes.luwu_platter = true
	entry = customer(game, "yingzhao_salad")
	near(resolver(game).complaint_probability(entry), 0.8, "yingzhao salad reduces complaint risk")
	expect(resolver(game).dish_weight("yingzhao_salad") > 1, "yingzhao salad attracts healthy food customers")
	covered_dishes.yingzhao_salad = true
	entry = customer(game, "jingwei_bibimbap", "queued")
	entry.due_minute = -1
	entry.arrival_minute = int(game.state.total_minutes) - 90
	var id := int(entry.id)
	game._expire_customers()
	expect(not game._customer(id).is_empty(), "jingwei rice actual patience exceeds v1.8 standard80 elapsed min")
	covered_dishes.jingwei_bibimbap = true
	near(float(game.full_rules.management.modifiers("dangkang_rice").ingredient_mult), 0.9, "dangkang rice actual ingredient quantity multiplier")
	covered_dishes.dangkang_rice = true
	game.state.world.weather = "clear"
	game.state.total_minutes = 1260
	near(resolver(game).dish_weight("tiangou_tempura"), 1.3, "tempura night market demand")
	game.state.total_minutes = 1440
	near(resolver(game).dish_weight("tiangou_tempura"), 1, "tempura bonus ends at midnight")
	covered_dishes.tiangou_tempura = true
	near(float(game.full_rules.management.modifiers("ranyiyu_soup").repeat_chance), 0.2, "fish soup repeat order chance")
	covered_dishes.ranyiyu_soup = true
	entry = customer(game, "qiongqi_hotpot", "serving", "er_shu")
	entry.dish_effects.conflict_chance = 1
	var reputation := int(game.state.reputation)
	complete(game, entry)
	expect(int(game.state.reputation) < reputation, "spicy hotpot conflict affects actual reputation")
	covered_dishes.qiongqi_hotpot = true
	game.state.menu_enabled = ["taowu_barbecue"]
	near(resolver(game).promotion_multiplier(), 2, "taowu barbecue doubles menu promotion")
	covered_dishes.taowu_barbecue = true
	game.state.management.hidden_effects.hundun_wonton = "price_mult"
	expect(float(game.full_rules.management.modifiers("hundun_wonton").price_mult) > 1, "hundun wonton persisted random hidden price effect")
	covered_dishes.hundun_wonton = true
	entry = customer(game, "xiezhi_set", "paying", "er_shu")
	entry.dish_effects.regular_bonus = 1
	complete(game, entry)
	expect(int(game.state.world.regulars) > 0, "justice set actual customer becomes regular")
	covered_dishes.xiezhi_set = true
	entry = customer(game, "zhulong_ramen")
	near(resolver(game).review_adjustment(entry, -1), 2, "zhulong ramen first daily purchaser review")
	entry = customer(game, "zhulong_ramen")
	near(resolver(game).review_adjustment(entry, -1), -1, "zhulong ramen later purchaser not automatically positive")
	covered_dishes.zhulong_ramen = true
	game = fixture(["xian_yang", "er_shu"])
	entry = customer(game, "dijiang_dumplings", "serving", "er_shu")
	entry.due_minute = -1
	game._assign_tasks()
	expect(float(entry.task_motion.work_minutes) == 0 and int(entry.due_minute) - int(game.state.total_minutes) == maxi(1,int(ceil(float(entry.task_motion.travel_minutes)))), "dijiang dumplings skip serving work but still travel to the table")
	covered_dishes.dijiang_dumplings = true
	game = fixture(["xian_yang", "er_shu"])
	game.state.menu_enabled = ["jiuying_platter"]
	game._spawn_customer("jiuying_platter") # Forced party fixture, never inferred from inventory or the advertised menu.
	expect(game.customers.size() == 3, "explicit three-person party produces three real platter orders")
	covered_dishes.jiuying_platter = true


func _initialize() -> void:
	employee_checks()
	dish_checks()
	integrated_checks()
	expect(covered_employees.size() == 26, "all 26 employee IDs have explicit mechanic checks")
	expect(covered_dishes.size() == 23, "all 23 dish IDs have explicit mechanic checks")
	print("Skill and dish coverage: %d checks, %d failures; %d employees / %d dishes" % [checks, failures, covered_employees.size(), covered_dishes.size()])
	quit(0 if failures == 0 else 1)
