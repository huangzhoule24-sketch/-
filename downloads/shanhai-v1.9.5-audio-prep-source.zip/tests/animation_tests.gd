extends SceneTree

const View = preload("res://scripts/ui/restaurant_view.gd")
const Model = preload("res://scripts/core/game_model.gd")
const Space = preload("res://scripts/services/restaurant_space.gd")
var checks := 0
var failures := 0

class FakeModel extends RefCounted:
	var paused := false
	var speed := 1
	var demo_config: Dictionary = {"time": {"time_factor": 6}, "layout": {"width": 6, "height": 4}}
	var balance: Dictionary = {}
	var dishes: Array = []
	var state: Dictionary = {"total_minutes": 400, "mode": "normal", "promotion_until": 0, "layout": []}
	var employees: Array[Dictionary] = []
	var customers: Array[Dictionary] = []
	func business_open() -> bool: return true

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(label)

func approx(actual: float, expected: float, label: String) -> void:
	check(absf(actual - expected) < 0.00003, "%s: %f vs %f" % [label, actual, expected])

func employee(id: String, role: String = "waiter", speed_value: float = 5.0) -> Dictionary:
	return {"id": id, "name": id, "role": role, "mood": 80, "rarity": "N", "resting": false,
		"busy_customer": 0, "attributes": {"speed": speed_value, "cooking": 5.0, "charm": 5.0}}

func create_view(fake: FakeModel):
	var view = View.new()
	view.model = fake
	view.font = ThemeDB.fallback_font
	view.size = Vector2(900, 600)
	root.add_child(view)
	view.set_process(false)
	return view

func sample_motion(model, view, minute: float) -> void:
	model.state.total_minutes = int(floor(minute))
	model._fraction = minute - floor(minute)
	view._update_employee_animation(0.05)

func _init() -> void:
	call_deferred("run")

func cultivation_model(id: String):
	var model = Model.new(20261017)
	model.start_full()
	# Resource/stage fixtures isolate the real cultivation action. No attribute,
	# task duration or animation multiplier is assigned by the test.
	model.state.stage = 4
	model.state.cash = 10000.0
	model.state.gems = 100
	model.state.fragments[id] = 20
	model.balance["customer.base_flow"] = 0.0
	model.events.clear()
	model.employees.clear()
	model.employees.append(model._create_employee(model._employee_config(id)))
	model.full_rules.ensure_state_defaults()
	return model

func cultivation_task(model, stage: String) -> Dictionary:
	model._spawn_customer("noodles", false)
	var customer: Dictionary = model.customers[0]
	customer.stage = stage
	customer.arrival_due=0
	model._assign_tasks()
	return customer

func cultivation_tests() -> void:
	# All three chapter-20 bindings pass through both actual cultivation actions
	# and the actual scheduler, then through the rendering observer.
	for method in ["train_attribute", "awaken"]:
		for binding in [["xiao", "speed", "serving", "Serve"], ["xian_yang", "cooking", "queued", "Cook"], ["guan_guan", "charm", "paying", "Cashier"]]:
			var id: String = binding[0]
			var label: String = method + ":" + str(binding[1])
			var model = cultivation_model(id)
			var person: Dictionary = model._employee(id)
			var attribute_before: float = float(person.attributes[binding[1]])
			var old_job: Dictionary = cultivation_task(model, binding[2])
			check(str(old_job.worker) == id and old_job.get("task_motion") is Dictionary, label + " baseline is a real assigned task")
			var old_motion: Dictionary = old_job.task_motion.duplicate(true)
			model._release_customer(old_job)
			model.customers.clear()
			model.scheduler.clear()
			var cultivated := true
			if method == "train_attribute":
				# Exercise the configured failure/experience guarantee instead of
				# injecting an attribute increase or a successful project result.
				for attempt in range(int(model.full_rules.management.config.guarantees.training_failures) + 1):
					var result: Dictionary = model.full_rules.perform(method, {"id":id, "attribute":binding[1]})
					cultivated = cultivated and bool(result.ok)
					if not result.ok: break
					model.advance_minutes(int(result.due) - int(model.state.total_minutes))
					if float(person.attributes[binding[1]]) > attribute_before: break
			else:
				cultivated = bool(model.full_rules.perform(method, {"employee_id":id}).ok)
			check(cultivated and float(person.attributes[binding[1]]) > attribute_before, label + " changes the real employee through the player action")
			var job: Dictionary = cultivation_task(model, binding[2])
			var motion: Dictionary = job.get("task_motion", {})
			check(str(job.worker) == id and not motion.is_empty() and float(motion.work_minutes) < float(old_motion.work_minutes), label + " shortens the next real work interval")
			if binding[1] == "speed" or method == "awaken":
				check(float(motion.speed) > float(old_motion.speed) and float(motion.travel_minutes) < float(old_motion.travel_minutes), label + " moves along the same route faster")
			var view = View.new()
			view.model = model
			view.font = ThemeDB.fallback_font
			view.size = Vector2(900, 600)
			root.add_child(view)
			view.set_process(false)
			sample_motion(model, view, float(motion.started) + float(motion.travel_minutes) + float(motion.work_minutes) * 0.5)
			var actor: Dictionary = view.employee_animation_state(id)
			check(str(actor.action) == str(binding[3]) and is_equal_approx(float(actor.progress), 0.5), label + " renders the actual faster work timeline")
			var phase_before: float = float(actor.phase)
			view._update_employee_animation(0.1)
			approx(float(view.employee_animation_state(id).phase) - phase_before, 0.1 * View.animation_factor(person, binding[3], model.balance), label + " frame rate reads the cultivated attribute immediately")
			view.queue_free()
	# Awakening is allowed while idle en route to a station. Include a fractional
	# render frame: rebasing at the previous integer minute would visibly jump.
	var idle_model = cultivation_model("xiao")
	var idle_worker: Dictionary = idle_model._employee("xiao")
	idle_model._fraction = 0.5
	var moment: float = float(idle_model.state.total_minutes) + idle_model._fraction
	var before_position: Vector2 = idle_model.motion_position(idle_worker, moment)
	var before_speed: float = float(idle_worker.motion.speed)
	var before_target: Dictionary = idle_worker.motion.target.duplicate(true)
	check(bool(idle_model.full_rules.perform("awaken", {"employee_id":"xiao"}).ok), "idle in-flight awakening succeeds without a customer job")
	check(idle_model.motion_position(idle_worker, moment).is_equal_approx(before_position), "idle awakening preserves the current fractional position")
	check(idle_worker.motion.target == before_target and float(idle_worker.motion.speed) > before_speed, "idle awakening retains its station and immediately uses the new speed")
	var later: Vector2 = idle_model.motion_position(idle_worker, moment + 0.05)
	approx(later.distance_to(before_position), float(idle_worker.motion.speed) * 0.05, "idle movement advances continuously at the awakened speed")

func run() -> void:
	var worker := employee("test")
	approx(View.animation_factor(worker, "Move"), 1.0, "move baseline")
	worker.attributes.speed = 10.0
	approx(View.animation_factor(worker, "Serve"), 1.4, "speed 10 uses chapter 20 coefficient")
	worker.attributes.speed = 1.0
	approx(View.animation_factor(worker, "cleaning"), 0.68, "speed 1 movement factor")
	worker.attributes.speed = -100.0
	approx(View.animation_factor(worker, "Move"), 0.6, "movement lower clamp")
	worker.attributes.speed = 100.0
	approx(View.animation_factor(worker, "Move"), 2.0, "movement upper clamp")
	worker.attributes.cooking = -100.0
	approx(View.animation_factor(worker, "Cook"), 0.7, "cooking lower clamp")
	worker.attributes.cooking = 100.0
	approx(View.animation_factor(worker, "cooking"), 1.8, "cooking upper clamp")
	worker.role="salesman"
	worker.attributes.charm = -100.0
	approx(View.animation_factor(worker, "Cashier"), 0.8, "charm lower clamp")
	worker.attributes.charm = 100.0
	approx(View.animation_factor(worker, "Promote"), 1.5, "charm upper clamp")
	worker = employee("mood")
	worker.mood = 100
	approx(View.animation_factor(worker, "Move"), 1.02, "mood formula gives 2 percent maximum")
	worker.mood = 0
	approx(View.animation_factor(worker, "Move"), 1.0, "low mood does not impose invented animation penalty")
	var fake := FakeModel.new()
	fake.employees.append(employee("waiter"))
	fake.employees[0].busy_customer = 7
	fake.customers.append({"id": 7, "seat": 0, "worker": "waiter", "stage": "serving", "task_started_minute": 399, "due_minute": 404})
	var original := JSON.stringify({"customers": fake.customers, "employees": fake.employees, "state": fake.state})
	var view = create_view(fake)
	view._update_employee_animation(0.0)
	var initial: Dictionary = view.employee_animation_state("waiter")
	check(initial.action == "Move", "service begins with actual travel")
	view._update_employee_animation(0.1)
	var advanced: Dictionary = view.employee_animation_state("waiter")
	var distance: float = initial.position.distance_to(advanced.position)
	check(distance > 0.0 and distance <= 21.001, "employee movement is bounded by speed times delta")
	check(advanced.position != advanced.target, "first frame never teleports to task target")
	check(advanced.progress < 1.0, "unfinished authoritative task cannot display complete")
	fake.paused = true
	var phase_before := float(advanced.phase)
	view._update_employee_animation(view._visual_delta(0.1))
	var paused: Dictionary = view.employee_animation_state("waiter")
	check(paused.position == advanced.position, "pause freezes movement")
	approx(float(paused.phase), phase_before, "pause freezes animation frames")
	approx(view._visual_delta(0.1), 0.0, "paused visual clock")
	fake.paused = false
	fake.speed = 3
	approx(view._visual_delta(0.1), 0.3, "three-times clock")
	fake.state.mode = "demo"
	approx(view._visual_delta(0.1), 1.8, "demo clock includes six-times pacing")
	fake.state.mode = "normal"
	fake.speed = 1
	for step in range(50): view._update_employee_animation(0.1)
	var arrived: Dictionary = view.employee_animation_state("waiter")
	check(arrived.position.distance_to(arrived.target) <= 0.01, "worker reaches target without oscillating")
	check(arrived.action == "Serve", "work starts only after arrival")
	check(JSON.stringify({"customers": fake.customers, "employees": fake.employees, "state": fake.state}) == original, "presentation never completes task or mutates model state")
	fake.customers[0].seat = 7
	fake.customers[0].stage = "cleaning"
	view._update_employee_animation(0.1)
	var changed: Dictionary = view.employee_animation_state("waiter")
	check(changed.position.distance_to(arrived.position) <= 21.001, "new assignment preserves actual position")
	check(changed.action == "Move", "cleaning target change returns to movement")
	for step in range(70): view._update_employee_animation(0.1)
	check(view.employee_animation_state("waiter").action == "Clean", "clean animation state")
	fake.customers[0].stage = "paying"
	for step in range(70): view._update_employee_animation(0.1)
	check(view.employee_animation_state("waiter").action == "Cashier", "cashier animation state")
	fake.employees[0].role = "salesman"
	fake.employees[0].busy_customer = 0
	fake.customers.clear()
	fake.state.promotion_until = 500
	for step in range(70): view._update_employee_animation(0.1)
	check(view.employee_animation_state("waiter").action == "Promote", "promotion animation state")
	var cook_model := FakeModel.new()
	cook_model.employees.append(employee("jiu_ying", "chef"))
	cook_model.customers.append({"id": 1, "seat": 0, "stage": "cooking", "worker": "jiu_ying", "task_started_minute": 399, "due_minute": 410})
	cook_model.customers.append({"id": 2, "seat": 1, "stage": "cooking", "worker": "jiu_ying", "task_started_minute": 399, "due_minute": 410})
	var cook_view = create_view(cook_model)
	for step in range(50): cook_view._update_employee_animation(0.1)
	check(cook_view.employee_animation_state("jiu_ying").task_count == 2, "parallel cooking reports both tasks")
	check(cook_view.employee_animation_state("jiu_ying").action == "Cook", "cook animation state")
	check(cook_view.first_customer_bounds().has_area(), "tutorial can locate first customer")
	check(not cook_view.customer_bounds(-1).has_area(), "missing customer gives empty highlight")
	var opening = Model.new(20261016)
	opening.start_full()
	var opening_view = View.new()
	opening_view.model = opening
	opening_view.font = ThemeDB.fallback_font
	opening_view.size = Vector2(900, 600)
	root.add_child(opening_view)
	opening_view.set_process(false)
	var opening_minute := float(opening.state.total_minutes)
	var initial_motion_ready := true
	for person in opening.employees:
		initial_motion_ready = initial_motion_ready and person.get("motion") is Dictionary and str(person.motion.action) == "Idle"
	check(initial_motion_ready, "new-game idle employees begin on authoritative movement paths")
	sample_motion(opening, opening_view, opening_minute + 0.95)
	var fractional_positions: Dictionary = {}
	var fractional_matches := true
	for person in opening.employees:
		var drawn: Vector2 = opening_view.employee_animation_state(str(person.id)).position
		fractional_positions[str(person.id)] = drawn
		fractional_matches = fractional_matches and drawn.is_equal_approx(opening.motion_position(person, opening_minute + 0.95))
	check(fractional_matches, "new-game fractional frames share the model idle positions")
	sample_motion(opening, opening_view, opening_minute + 1.0)
	var before_assignment: Dictionary = {}
	var opening_continuous := true
	for person in opening.employees:
		var drawn: Vector2 = opening_view.employee_animation_state(str(person.id)).position
		before_assignment[str(person.id)] = drawn
		opening_continuous = opening_continuous and drawn.distance_to(fractional_positions[str(person.id)]) <= float(person.motion.speed) * 0.05 + 0.001
	check(opening_continuous, "fractional idle movement remains bounded across the first integer minute")
	opening._spawn_customer()
	opening.customers[0].arrival_due=int(opening.state.total_minutes) # Isolate employee continuity after guest arrival.
	opening._assign_tasks()
	var first_worker: Dictionary = opening._employee(str(opening.customers[0].worker))
	opening_view._update_employee_animation(0.0)
	check(not first_worker.is_empty() and opening_view.employee_animation_state(str(first_worker.id)).position.is_equal_approx(before_assignment[str(first_worker.id)]), "the first real task begins at the visible idle position without jumping back to the entrance")
	opening_view.queue_free()
	var real = Model.new(20261016)
	real.start_full()
	real.state.stage = 1
	real.state.layout = [{"id":"table_four", "x":1, "y":1, "w":1, "h":1},{"id":"basic_pass","x":10,"y":0,"w":1,"h":1}]
	real.state.seats = 4
	real.customers.clear()
	real.scheduler.clear()
	real._spawn_customer()
	var guest: Dictionary = real.customers[0]
	guest.seat = 2
	guest.arrival_due=0
	guest.stage = "serving"
	guest.due_minute = -1
	guest.worker = ""
	real._assign_tasks()
	check(not str(guest.worker).is_empty() and guest.get("task_motion") is Dictionary, "real serving task owns an authoritative route and work interval")
	var assigned: Dictionary = real._employee(str(guest.worker))
	var motion: Dictionary = guest.task_motion
	var began := float(motion.started)
	var travel := float(motion.travel_minutes)
	var work := float(motion.work_minutes)
	check(travel > 0.0 and work > 0.0 and int(guest.due_minute) >= int(ceil(began + travel + work)), "completion deadline includes the entire actual trip and work interval")
	var real_view = View.new()
	real_view.model = real
	real_view.font = ThemeDB.fallback_font
	real_view.size = Vector2(900, 600)
	root.add_child(real_view)
	real_view.set_process(false)
	sample_motion(real, real_view, began + travel * 0.5)
	var travelling: Dictionary = real_view.employee_animation_state(str(assigned.id))
	check(str(travelling.action) == "Move" and travelling.position.is_equal_approx(real.motion_position(assigned, began + travel * 0.5)), "renderer samples the same fractional travel position as simulation")
	var position_before_resize: Vector2 = travelling.position
	real_view.size = Vector2(1440, 900)
	real_view._update_employee_animation(0.0)
	check(real_view.employee_animation_state(str(assigned.id)).position == position_before_resize, "resizing changes only drawing scale and never moves an employee")
	sample_motion(real, real_view, began + travel + work * 0.5)
	var working: Dictionary = real_view.employee_animation_state(str(assigned.id))
	check(str(working.action) == "Serve" and working.position.distance_to(Space.service_point(real, 2)) < 0.01, "four-person table upper seat plays service only after arriving outside the table")
	approx(float(working.progress), 0.5, "work progress excludes the travel interval")
	real.state.total_minutes = int(guest.due_minute) - 1
	real._tick_scheduler()
	check(str(guest.stage) == "serving", "the customer cannot receive a dish before the complete trip and work deadline")
	real.state.total_minutes = int(guest.due_minute)
	real._fraction = 0.0
	real._tick_scheduler()
	check(str(guest.stage) == "eating", "the real simulation delivers after its route and work finish without relying on a running view")
	real_view._update_employee_animation(0.0)
	check(str(real_view.employee_animation_state(str(assigned.id)).action) in ["Idle","Move"], "completed tasks stop working and may walk back to their reserved station")
	# Placing furniture over a staff member must block new task assignment,
	# rather than let an idle actor produce a dish remotely.
	guest.stage = "serving"
	guest.due_minute = -1
	guest.worker = ""
	real.scheduler.clear()
	var inside: Vector2 = Space.cell_rect(real, 1, 1).get_center()
	assigned.motion = {"origin":{"x":inside.x,"y":inside.y}, "target":{"x":inside.x,"y":inside.y}, "path":[], "started":int(real.state.total_minutes), "speed":0.0, "travel_minutes":0.0, "work_minutes":0.0, "action":"Idle", "blocked":false}
	real._assign_tasks()
	check(str(guest.worker).is_empty() and int(guest.due_minute) == -1 and real.scheduler.is_empty(), "an unreachable worker gets no service deadline and cannot complete remotely")
	real_view.queue_free()
	view.queue_free()
	cook_view.queue_free()
	cultivation_tests()
	print("ANIMATION CHECKS: %d passed, %d failed" % [checks - failures, failures])
	quit(1 if failures > 0 else 0)
