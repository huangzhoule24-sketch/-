extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Guide=preload("res://scripts/core/tutorial_progress.gd")
const Assets=preload("res://scripts/services/asset_catalog.gd")
const Session=preload("res://scripts/ui/decoration_session.gd")
const Frame=preload("res://scripts/ui/portrait_frame.gd")
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init(): call_deferred("run")
func check(ok: bool,message: String):
	checks+=1
	if not ok: failures+=1;push_error(message)
func settle():
	for i in range(10): await process_frame
func run():
	var model=Model.new(195);model.start_full()
	check(Guide.current(model).id=="welcome","Welcome is manual")
	Guide.observe(model,"welcome_ack");check(Guide.current(model).id=="staff","Welcome needs one click")
	Guide.observe(model,"panel:员工");Guide.observe(model,"closed:员工")
	check(Guide.current(model).id=="staff" and "staff" in model.state.tutorial.ready_to_ack,"Staff operation waits")
	check(Guide.allows_panel(model,"系统") and Guide.allows_button(model,"full:marketing:flyer"),"Ready confirmation releases operation locks")
	var saved=model.state.tutorial.duplicate(true)
	check(model.save_game("user://v195-ready-roundtrip.json"),"Ready progress saves")
	var restored=Model.new(2)
	check(restored.load_game("user://v195-ready-roundtrip.json") and "staff" in restored.state.tutorial.ready_to_ack,"Ready state survives real save/load")
	check(Guide.validate_state(saved,0),"Ready progress validates")
	for i in range(10): Guide.current(model)
	check(Guide.current(model).id=="staff","Polling never confirms for player")
	Guide.acknowledge(model);check(Guide.current(model).id=="promotion","Acknowledgment progresses exactly one step")
	Guide.observe(model,"marketing");Guide.acknowledge(model);check(Guide.current(model).id=="first_order","Promotion confirmation")
	model.state.served=1;Guide.current(model);check("first_order" in model.state.tutorial.ready_to_ack,"Real sale waits")
	Guide.acknowledge(model);check(Guide.current(model).id=="income","Sale confirmed")
	Guide.observe(model,"income_ack");Guide.current(model);Guide.observe(model,"panel:账单")
	check(not model.state.tutorial.finished,"Viewing bill requires confirmation")
	Guide.acknowledge(model);check(model.state.tutorial.finished,"All six steps completed manually")
	var legacy=saved.duplicate(true);legacy.erase("ready_to_ack");check(Guide.validate_state(legacy,0),"Old saves lacking field remain valid")
	var directory="/tmp/shanhai195-"+str(Time.get_ticks_usec());var assets=Assets.new("res://assets/art",directory)
	var image=Image.create(16,16,false,Image.FORMAT_RGBA8);image.fill(Color.RED);var png=image.save_png_to_buffer()
	for pair in [["UI/btn_decorate","UI/btn_decoration"],["UI/btn_promote","UI/btn_promotion"],["UI/decor_stove","Map/equip_stove"],["Map/decor_table","UI/decor_table"],["UI/equip_cashier","Map/equip_cashier"]]:
		check(assets.import_image(png,pair[0]+".png").ok and assets.has_image(pair[1]),"Alias maps "+str(pair))
	var frame=Frame.new();var transparent=Image.create(256,512,false,Image.FORMAT_RGBA8);transparent.fill(Color.TRANSPARENT)
	transparent.fill_rect(Rect2i(90,80,75,300),Color.RED)
	var texture=ImageTexture.create_from_image(transparent);var crop=frame.head_crop(texture,1.58)
	check(crop.position.y<=85 and crop.end.y>100 and crop.end.y<400,"Crop includes head and excludes lower body")
	check(absf(crop.size.x/crop.size.y-1.58)<.01,"Crop follows actual window aspect")
	var opaque=Image.create(256,512,false,Image.FORMAT_RGB8);opaque.fill(Color.WHITE);opaque.fill_rect(Rect2i(90,0,75,400),Color.BLUE)
	check(frame.head_crop(ImageTexture.create_from_image(opaque),1.58).position.y==0,"Opaque images anchor top without alpha assumptions")
	frame.free()
	root.size=Vector2i(844,390);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui.update_ui_layout();await settle()
	check(preload("res://scripts/ui/interface_policy.gd").navigation(0)==["员工","装修","宣传","招聘"],"Four stage0 entries")
	ui.open_panel("装修");await settle();check(ui.panel_name=="简单布置","Stage0 routes around formal unlock gate")
	var session=ui.decoration_session;var item=ui.model.state.layout[0]
	check(session.can_move(0,int(item.x),int(item.y)),"Original cell previews cancellation")
	check(session.move_reason(0,-99,-99).contains("范围"),"Boundary reason is specific")
	var other=ui.model.state.layout[1];check(session.move_reason(0,int(other.x),int(other.y)).contains("占用"),"Overlap reason is specific")
	ui.finish_decoration(false);ui.open_panel("员工");await settle()
	var count=0
	for button in ui._qa_buttons:
		if is_instance_valid(button) and button.is_inside_tree() and str(button.get_meta("qa_id","")).begins_with("employee:portrait:"):count+=1
	check(count==ui.model.employees.size(),"Exactly one portrait per employee")
	check(ui.notice_duration("很长的提示文字".repeat(30))==2.5,"Toast upper limit")
	ui.close_panel(false);ui.tutorial_overlay.restart_tutorial();await settle()
	var guide=ui.tutorial_overlay
	check(guide.message_label.max_lines_visible==-1,"Guide has no text truncation")
	var rect=guide.highlight_rect;guide.poll(.1);check(rect==guide.highlight_rect,"Target rectangle stays frozen")
	check(guide.tutorial_card.size.x<=360.5 and guide.tutorial_card.size.y<=390*.74+1,"Compact scene guide bounds")
	ui.queue_free();await settle()
	print("V1.9.5 interactions: %d checks, %d failures" % [checks,failures]);quit(1 if failures else 0)
