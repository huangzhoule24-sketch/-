extends SceneTree
## Direct, bounded event scenarios complement the natural campaign audit.
const Model = preload("res://scripts/core/game_model.gd")
var checks := 0
var failures := 0

func _initialize() -> void:
	_classification()
	_feedback_and_passive()
	_risk_chains()
	_actual_choices()
	_effect_uniqueness()
	_persistence_and_rejection()
	print("v1.5 event checks passed: %d, failed: %d" % [checks - failures, failures])
	quit(1 if failures else 0)

func check(value: bool, description: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(description)

func fresh():
	var m = Model.new(19505)
	m.start_full()
	m.state.total_minutes = 14400 + 720
	m.state.stage = 4
	m.state.cash = 10000.0
	m.state.gems = 100
	m.state.reputation = 1000
	m.employees.clear()
	for definition in m.catalog:
		var employee = m._create_employee(definition)
		employee.mood = 50.0
		employee.loyalty = 60.0
		employee.stamina = 80.0
		m.employees.append(employee)
	m.state.world.clear()
	m.full_rules.world.ensure_state()
	for definition in m.events:
		var key = str(definition.get("probability_key", ""))
		m.balance[str(m.full_rules.world.COEFFICIENT_ALIASES.get(key, key))] = 0.0
	m.full_rules.ensure_state_defaults()
	return m

func _classification() -> void:
	var m = fresh()
	var decision := 0
	var broadcast := 0
	var notice := 0
	var states := 0
	for definition in m.events:
		if str(definition.id) == "debt_collection": continue
		if str(definition.type)=="state":
			states+=1
			check(definition.auto and definition.options.size()==1,"State auto-applies without a decision")
		elif str(definition.type)=="notice":
			notice+=1
			check(definition.options.size()==1 and not definition.auto,"Notice has exactly one confirmation")
		elif bool(definition.auto):
			broadcast += 1
			check(str(definition.type) == "broadcast" and definition.options.size() == 1, "broadcast is explicitly passive: " + str(definition.id))
		else:
			decision += 1
			check(str(definition.type) == "decision" and definition.options.size() >= 2, "decision has at least two alternatives: " + str(definition.id))
	check(decision == 15 and broadcast == 11 and notice == 6 and states == 5, "follow all 30 per-row types; five named former broadcasts are now notices")

func _feedback_and_passive() -> void:
	var m = fresh()
	var w = m.full_rules.world
	w._enqueue("taotie_steals", {"employee_id":"tao_tie"})
	var result: Dictionary = w.choose("fine")
	check(result.ok and float(m.state.cash) == 10020, "fine credits actual cash")
	check(float(m._employee("tao_tie").loyalty) == 59, "fine changes actual loyalty")
	check(is_equal_approx(w.modifier("ingredient"), 1.0), "one five-percent saving and one five-percent consumption cost both survive")
	check(result.feedback.changes.size() >= 2 and result.feedback.before.cash == 10000 and result.feedback.after.cash == 10020, "feedback retains actual before and after metrics")
	var saw_cash := false
	var saw_loyalty := false
	for change in result.feedback.changes:
		if str(change.key) == "cash": saw_cash = float(change.delta) == 20
		if str(change.key) == "employee.tao_tie.loyalty": saw_loyalty = float(change.delta) == -1
	check(saw_cash and saw_loyalty, "feedback deltas are genuine state changes")
	check(not w.choose("fine").ok, "decision cannot be settled twice")
	var event: Dictionary = w._definition("taotie_steals")
	check(not w._eligible(event, "cooking", {"employee_id":"tao_tie"}), "one event per calendar day")
	m.state.total_minutes = 11 * 1440 + 720
	m._employee("tao_tie").motion={"action":"Cook","started":int(m.state.total_minutes),"travel_minutes":0}
	check(w._eligible(event, "cooking", {"employee_id":"tao_tie"}), "next calendar day allows the next event")
	w._enqueue("phoenix_rebirth", {"employee_id":"feng_huang"})
	check(not w.pending_event().is_empty() and float(m._employee("feng_huang").stamina)==80,"Notice has no effect before confirmation")
	w.choose(str(w.pending_event().options[0].id))
	check(w.pending_event().is_empty() and float(m._employee("feng_huang").stamina) == 100, "Phoenix broadcasts and refills without a forced option")
	check(str(m.state.world.feedback.type) == "notice" and not m.state.world.feedback.changes.is_empty(), "broadcast has numerical feedback and a retrievable log")
	w._enqueue("yinglong_rain", {"employee_id":"ying_long"})
	w.choose(str(w.pending_event().options[0].id))
	check(w.pending_event().is_empty() and str(m.state.world.weather) == "rain", "rain applies immediately")
	check(int(m.state.world.weather_until) == 12 * 1440 and is_equal_approx(w.dish_demand("水产"), 1.5), "rain demand lasts until calendar day end")
	w._enqueue("dangkang_harvest", {"employee_id":"dang_kang"})
	w.choose(str(w.pending_event().options[0].id))
	check(is_equal_approx(w.procurement_multiplier("ordinary"), 0.8), "harvest actually discounts procurement without claiming")
	check(not m.state.world.feedback.details.is_empty(), "noncash discount has explicit duration feedback")

func _risk_chains() -> void:
	var m = fresh()
	var w = m.full_rules.world
	w._enqueue("bifang_fire", {"employee_id":"bi_fang"})
	w.choose("continue")
	check(not w.has_flag("fire_risk") and m.state.world.flags.size() == 1, "fire risk is visible today but begins next day")
	m.balance["events.bifang_fire_probability"] = 0.03
	var fire: Dictionary = w._definition("bifang_fire")
	check(is_equal_approx(w.event_probability(fire), 0.03), "risk does not double today's fire chance")
	m.state.total_minutes = 11 * 1440 + 720
	m._employee("tao_tie").motion={"action":"Cook","started":int(m.state.total_minutes),"travel_minutes":0}
	check(w.has_flag("fire_risk") and is_equal_approx(w.event_probability(fire), 0.06), "risk really doubles next-day fire probability")
	w._enqueue("bifang_fire", {"employee_id":"bi_fang"})
	w.choose("repair")
	check(not w.has_flag("fire_risk") and int(m._employee("bi_fang").leave_until) == int(m.state.total_minutes) + 1440, "repair clears risk and rests Bifang exactly one day")
	check(int(m.state.kitchen_pause_until) <= int(m.state.total_minutes), "repair does not close the entire kitchen")
	m = fresh()
	w = m.full_rules.world
	m.state.promotion_bonus = 0.75
	m.state.promotion_until = int(m.state.total_minutes) + 300
	w._enqueue("false_ad", {"employee_id":"e_shou"})
	w.choose("admit")
	check(float(m.state.promotion_bonus) == 0 and int(m.state.promotion_until) == int(m.state.total_minutes), "admission really clears the current advertisement")
	w._enqueue("false_ad", {"employee_id":"e_shou"})
	w.choose("conceal")
	check(w.has_flag("reputation_risk") and m.state.world.delayed.size() == 1, "conceal leaves visible risk and a persisted delayed consequence")
	m.state.world.delayed[0].probability = 1.0
	m.state.total_minutes = int(m.state.world.delayed[0].due)
	w.tick_minute()
	check(int(m.state.reputation) == 980 and str(m.state.world.feedback.title) == "虚假宣传曝光", "exposure chain has real -30 and a named log")
	check(not w.has_flag("reputation_risk") and m.state.world.delayed.is_empty(), "exposure consumes its pending consequence once")
	w._enqueue("qiongqi_fight", {"employee_id":"qiong_qi"})
	w.choose("ignore")
	check(w.has_flag("legal_risk") and m.state.world.delayed.size() == 1, "customer injury creates an actual legal-investigation chain")
	w._enqueue("kunlun_trouble")
	w.choose("respond")
	m.balance["events.kunlun_probability"] = 0.25
	check(w.has_flag("kunlun_hostility") and is_equal_approx(w.event_probability(w._definition("kunlun_trouble")), 0.5), "hard response really increases future Kunlun event probability")

func _actual_choices() -> void:
	var m = fresh()
	var w = m.full_rules.world
	var quote: Dictionary = w._supplier_quote(true)
	var stock := float(m.full_rules.management.item("generic").quantity)
	w._enqueue("supplier_discount")
	m.state.cash = float(quote.cost) - 1
	var queue: Array = m.state.world.queue.duplicate(true)
	check(not w.choose("discount").ok and m.state.world.queue == queue, "bulk purchase checks the full actual cost atomically")
	m.state.cash = 10000.0
	check(w.choose("discount").ok, "affordable bulk purchase settles")
	check(is_equal_approx(float(m.state.cash), 10000 - float(quote.cost)) and is_equal_approx(float(m.full_rules.management.item("generic").quantity), stock + float(quote.quantity)), "bulk choice really spends cash and stocks three batches")
	check(float(m.state.ledger.procurement) == float(quote.cost), "purchase is recorded as inventory acquisition rather than a duplicate expense")
	w._enqueue("tiangou_moon", {"employee_id":"tian_gou"})
	w.choose("reassure")
	check(m.state.world.easter_eggs.size() == 1 and str(m.state.world.easter_eggs[0].id) == "tiangou_past", "reassurance unlocks the promised Shanhai journal anecdote")
	w._enqueue("fox_charm", {"employee_id":"nine_tail"})
	var old_cases := int(m.state.world.legal_cases)
	check(w.choose("discreet").ok and int(m.state.world.legal_cases) == old_cases, "discreet fox alternative has no dispute roll")
	check(is_equal_approx(w.probability_bonus("tip"), 0.1), "discreet fox option gives exactly ten percent bonus")
	w._enqueue("baize_forecast", {"employee_id":"bai_ze"})
	var mood := float(m._employee("bai_ze").mood)
	w.choose("believe")
	check(float(m._employee("bai_ze").mood) == mood + 2, "believing Baize increases actual mood")
	w._enqueue("gudiao_call", {"employee_id":"gu_diao"})
	mood = float(m._employee("gu_diao").mood)
	w.choose("stop")
	check(float(m._employee("gu_diao").mood) == mood - 3, "stopping Gudiao is a real no-reward mood tradeoff")

func _effect_uniqueness() -> void:
	var m = fresh()
	var w = m.full_rules.world
	m.bonds = []
	w._add_modifier({"key":"quality","value":0.1,"duration":120})
	w._add_modifier({"key":"quality","value":0.35,"duration":120,"category":"水产"})
	w._add_modifier({"key":"quality","value":0.2,"duration":120,"employee_id":"xiao"})
	check(is_equal_approx(w.modifier("quality","水产","xiao"),1.35), "duplicate quality benefits choose the strongest eligible source")
	w._add_modifier({"key":"traffic","value":0.15,"duration":120})
	w._add_modifier({"key":"traffic","value":0.3,"duration":120,"category":"水产"})
	w._add_modifier({"key":"traffic","value":-0.2,"duration":120,"category":"水产","value_key":"events.tiangou_panic"})
	check(is_equal_approx(w.modifier("traffic","水产"),1.1), "one strongest traffic gain and one strongest loss preserve both strategy effects")
	w._add_modifier({"key":"quality","value":-0.2,"duration":120,"category":"水产"})
	check(is_equal_approx(m.full_rules.resolve_effect("quality", [1.4], {"category":"水产"}),1.2), "a stronger employee benefit cannot erase the independent negative event source")

func _persistence_and_rejection() -> void:
	var m = fresh()
	# This event fixture owns all 26 beasts, but a valid stage-4 save still
	# respects the real on-duty limit. The rest remain in the collection.
	for index in range(m.full_rules.active_limit(), m.employees.size()): m.employees[index].resting = true
	var w = m.full_rules.world
	w._enqueue("false_ad", {"employee_id":"e_shou"})
	w.choose("conceal")
	w._enqueue("tiangou_moon", {"employee_id":"tian_gou"})
	w.choose("reassure")
	check(w.validate_state(m.state.world, m.employees, int(m.state.total_minutes)), "new feedback, risk, anecdote and chain validate together")
	var path := "/tmp/shanhai-v15-event-save.json"
	check(m.save_game(path), "real model writes updated event data")
	var copy = Model.new(90)
	check(copy.load_game(path), "strict model reloads updated event data")
	if copy.state.has("world"):
		check(copy.state.world.flags.size() == m.state.world.flags.size() and JSON.stringify(JSON.parse_string(JSON.stringify(copy.state.world.easter_eggs))) == JSON.stringify(JSON.parse_string(JSON.stringify(m.state.world.easter_eggs))), "flags and anecdotes survive actual save/load, including integer-valued JSON minutes")
		check(copy.state.world.feedback.changes == m.state.world.feedback.changes, "numeric feedback survives actual save/load")
	var bad: Dictionary = m.state.world.duplicate(true)
	bad.flags[0].until = -1
	check(not w.validate_state(bad, m.employees, int(m.state.total_minutes)), "negative risk deadline is rejected")
	bad = m.state.world.duplicate(true)
	bad.feedback.changes[0].delta = 99999
	check(not w.validate_state(bad, m.employees, int(m.state.total_minutes)), "invented feedback delta is rejected")
	bad = m.state.world.duplicate(true)
	bad.event_days.false_ad = 999999
	check(not w.validate_state(bad, m.employees, int(m.state.total_minutes)), "future event dedup marker is rejected")
