extends SceneTree
const Model = preload("res://scripts/core/game_model.gd")
const Service = preload("res://scripts/core/customer_service.gd")
var checks: int = 0
var failures: int = 0
func check(value: bool, message: String) -> void:
	checks += 1
	if not value: failures += 1; push_error(message)
func near(a: float, b: float) -> bool: return absf(a-b) < 0.00001
func fresh() -> Dictionary:
	var model = Model.new(20261018)
	model.start_full()
	model.balance["customer.base_flow"] = 0
	var service = Service.new(model)
	service.ensure_state()
	return {"m":model, "s":service}
func guest(id: int = 1) -> Dictionary:
	return {"id":id, "dish_id":"noodles", "type":"human", "arrival_minute":360, "satisfaction":50.0,
		"preference_profile":{"age_group":"adult", "age":30, "gender":"unspecified", "tastes":["homestyle"], "needs":["ordinary"]}}
func stocked(model, id: String) -> void:
	if not id in model.state.unlocked_dishes: model.state.unlocked_dishes.append(id)
	if not id in model.state.menu_enabled: model.state.menu_enabled.append(id)
	for key in model.full_rules.management.recipe(id):
		var item: Dictionary = model.full_rules.management.item(str(key))
		item.quantity = 1000
		item.value = 1000 * float(model.full_rules.management._ingredient(str(key)).price)
	model.full_rules.management._sync_totals()
func _init() -> void: call_deferred("run")
func run() -> void:
	var f: Dictionary = fresh(); var m = f.m; var s = f.s
	check(s.validate_state(m.state, m.employees), "new customer-service state is valid")
	check(not s.balance_defaults().has("recommend.base_chance") and s.balance_defaults().has("service.price.customer_multiplier_cap"),"retired recommendation defaults removed while bounded pricing remains")
	check(not s.validate_balance({"recommend.base_chance":.4}),"retired recommendation override rejected")
	for changes in [{"service.feedback.stockout_bad_review_chance":-0.1},{"service.feedback.stockout_traffic_decay":-1},{"service.feedback.history_limit":1.5},{"service.feedback.stockout_daily_threshold":1.5},{"service.price.global_bonus_cap":1.1},{"service.price.quality_medium":0},{"service.price.customer_multiplier_cap":9}]:check(not s.validate_balance(changes),"feedback and bounded-price validation retained")
	var c: Dictionary=guest();s.prepare_customer(c);s.prepare_customer(c)
	check(int(m.state.customer_service.today.arrivals)==1,"arrival measurement is idempotent")
	check(s.order_pool(c).size()==3,"initial enabled menu contains the three starting dishes")
	stocked(m,"qiongqi_hotpot");stocked(m,"bifang_wings");stocked(m,"jiuying_platter")
	check(s.order_pool(c).any(func(d):return str(d.id)=="qiongqi_hotpot"),"premium dish can be ordered with no salesperson")
	check(not s.order_pool(c).any(func(d):return str(d.id)=="jiuying_platter"),"solo guest cannot fabricate a three-person platter")
	c.group_size=3;check(s.order_pool(c).any(func(d):return str(d.id)=="jiuying_platter"),"real party can order its shared platter");c.erase("group_size")
	var sales=m._create_employee(m._employee_config("guan_guan"));m.employees.append(sales);sales.attributes.eloquence=100;sales.attributes.charm=100
	var rng=m._rng.state
	check(not s.can_recommend(sales,c) and not s.finish_recommendation(c,sales).ok,"high-attribute salesperson cannot create a retired recommendation")
	check(m._rng.state==rng and int(m.state.customer_service.today.recommend_attempts)==0,"retired entry point neither rolls RNG nor records fake work")
	var outcomes: Dictionary={}
	for attempt in range(100):outcomes[str(s.choose_default_dish(c).get("id",""))]=true
	check(outcomes.has("qiongqi_hotpot") and outcomes.has("noodles"),"preference-weighted full menu reaches both premium and basic dishes")
	c=guest(3);s.record_order(c);s.record_order(c)
	check(int(m.state.customer_service.today.orders)==1, "order-pattern measurement is idempotent")
	check(int(m.state.customer_service.today.preference_matches)==1 and bool(c.preference_matched), "actual order identifies independent taste preference match")
	check(near(float(c.satisfaction),53), "preference match contributes visible customer satisfaction")
	# Exact staged integer arithmetic differs intentionally from old final-only rounding.
	var d: Dictionary={"id":"noodles","price":52,"cost":2}
	m.state.management.base_prices.noodles=52
	var quote: Dictionary=s.price_quote(d,80,{"type":"human","recommendation_premium":0.0},{"charm":0.05},{"period":{"dinner":0.2}})
	check(near(float(quote.stages.quality),59), "quality step floors 52*1.15 to59")
	check(near(float(quote.stages.per_customer),59), "removed personal step leaves quality price59 unchanged")
	check(near(float(quote.final),70), "global step floors59*1.2 to70 with no personal premium")
	quote=s.price_quote(d,90,{"type":"special","recommendation_premium":0.1},{"charm":10},{"period":{"dinner":0.2},"bond":{"bondA":0.9,"bondB":0.8},"skill":{"pi_xiu":0.5}})
	check(near(float(quote.global_bonus),1), "combined period bond skill bonus caps at plus100percent")
	check(near(float(quote.global_sources.bond.value),0.9), "same price-effect bond sources select strongest rather than double count")
	check(near(float(quote.final),416) and bool(quote.capped), "extreme combination cannot exceed eight times original base")
	quote=s.price_quote(d,75,{"type":"human"},{},{"bond":{"positive":0.2,"weaker":0.1,"negative":-0.1,"weak_negative":-0.05}})
	check(near(float(quote.global_bonus),0.1), "strongest downside survives with strongest upside without duplicate sources")
	for q in [0,59,60,79,80,89,90,100]:
		var value: Dictionary=s.price_quote(d,float(q),{"type":"descendant"},{},{})
		check(float(value.final)<=416 and floorf(float(value.final))==float(value.final), "every quality band has integral bounded pricing")
	f=fresh();m=f.m;s=f.s
	m.state.stage=2;m.state.total_minutes=18*60
	for id in ["jiu_wei_hu","bi_fang","qiong_qi","tao_wu","pi_xiu"]: m.employees.append(m._create_employee(m._employee_config(id)))
	var cooking: Dictionary=m._employee("qiong_qi")
	var cashier: Dictionary=m._employee("pi_xiu")
	m.state.management.hidden_effects.qiongqi_hotpot="price_mult"
	m.state.price_bonus=0.07
	m.state.world.modifiers.append({"key":"price","value":0.11,"until":int(m.state.total_minutes)+20,"identity":"real_event_price"})
	m.state.world.modifiers.append({"key":"price","value":0.9,"until":int(m.state.total_minutes)-1,"identity":"expired_event"})
	m.state.world.modifiers.append({"key":"price","value":0.7,"until":int(m.state.total_minutes)+20,"identity":"wrong_category","category":"饮品"})
	var sources: Dictionary=s.collect_price_sources(m._dish("qiongqi_hotpot"),cooking,cashier)
	check(sources.bond.size()>=2, "source collection keeps both genuine active price-bond identities")
	check(near(float(sources.period.get("period:dinner",0)),0.2), "current dinner price example becomes explicit time source")
	check(sources.skill.has("event:real_event_price") and not sources.skill.has("event:expired_event") and not sources.skill.has("event:wrong_category"), "event source collection respects expiry and dish category")
	check(sources.skill.has("restaurant:permanent_price") and sources.skill.has("dish:qiongqi_hotpot:hidden_price"), "permanent and hidden dish sources remain independently inspectable")
	check(sources.skill.has("employee:qiong_qi:spicy_price") and sources.skill.has("employee:pi_xiu:checkout"), "actual cook and cashier price skills are resolved once with identities")
	var best_bond: float=0
	for id in sources.bond: best_bond=maxf(best_bond,float(sources.bond[id]))
	var best_skill: float=0
	for id in sources.skill: best_skill=maxf(best_skill,float(sources.skill[id]))
	quote=s.price_quote(m._dish("qiongqi_hotpot"),90,{"type":"descendant"},{},sources)
	check(near(float(quote.global_bonus),minf(1,0.2+best_bond+best_skill)), "real source collection adds only best bond and best skill, without aggregated world double count")
	var no_cashier: Dictionary=s.collect_price_sources(m._dish("qiongqi_hotpot"),cooking)
	check(not no_cashier.skill.has("employee:pi_xiu:checkout"), "merely owning Pixiu does not give every unrelated cashier its price skill")
	# A real reservation race: menu had stock, a preceding order then consumes it.
	f=fresh();m=f.m;s=f.s
	var before: float=float(m.full_rules.management.item("generic").quantity)
	check(before>0, "stockout fixture starts with actual inventory")
	m.full_rules.management.item("generic").quantity=0;m.full_rules.management._sync_totals()
	check(s.basic_dishes().is_empty() and s.snapshot().sold_out.size()==3, "depleted inventory greys menu rather than deleting arrival capability")
	m.balance["service.feedback.stockout_bad_review_chance"]=1.0;m.state.reputation=20
	c=guest(4);s.prepare_customer(c)
	var shortage: Dictionary=s.stockout(c,m._dish("noodles"))
	check(shortage.ok and shortage.leave and shortage.bad_review, "unfulfillable real order triggers shortage and leaves without fake food")
	check(int(m.state.reputation)==18 and near(float(c.satisfaction),40), "shortage applies specified mood minus10 and bad-review reputation minus2")
	check(int(m.state.customer_service.today.stockouts)==1 and int(m.state.customer_service.today.reasons.stockout)==1, "shortage reason appears in measured feedback")
	check(m.state.customer_service.notices.size()==1 and str(m.state.customer_service.notices[0].text).contains("售罄"), "shortage is retained as nonblocking visible notice")
	check(near(float(m.state.total_revenue),0) and int(m.state.served)==0, "failed order creates no sale or served count")
	s.stockout(c,m._dish("noodles"))
	check(int(m.state.customer_service.today.stockouts)==1 and int(m.state.reputation)==18, "repeated cook retries cannot farm duplicate penalties")
	for id in [5,6]:s.stockout(guest(id),m._dish("noodles"))
	check(bool(s.snapshot().reputation_damaged) and near(float(s.snapshot().next_day_traffic_multiplier),0.95), "third actual shortage marks next-day reputation demand decay")
	check(near(s.traffic_multiplier(),1), "same-day demand remains independent of current empty inventory")
	m.state.total_minutes=1440;s.daily_rollover()
	check(near(s.traffic_multiplier(),0.95) and int(m.state.customer_service.today.stockouts)==0, "next day applies five-percent reputation penalty and resets daily counts")
	s.daily_rollover()
	check(m.state.customer_service.history.size()==1, "daily rollover is idempotent")
	m.state.total_minutes=2880;s.daily_rollover()
	check(near(s.traffic_multiplier(),1), "stockout demand penalty expires after its one next-day interval")
	check(s.validate_state(m.state,m.employees), "feedback and history survive strict state validation")
	var bad: Dictionary=m.state.duplicate(true);bad.customer_service.today.reasons.stockout=4
	check(not s.validate_state(bad,m.employees), "inconsistent bad-review distribution rejected")
	bad=m.state.duplicate(true);bad.customer_service.traffic_multiplier=0
	check(not s.validate_state(bad,m.employees), "saved traffic multiplier cannot silently suppress all arrivals")
	bad=m.state.duplicate(true);bad.customer_service.today.satisfaction_sum=1000
	check(not s.validate_state(bad,m.employees), "impossible satisfaction aggregates rejected")
	f=fresh();m=f.m;s=f.s
	c=guest(7);c.served_minute=380;c.quality=90
	s.record_sale(c,20,2);s.record_sale(c,20,2)
	check(int(m.state.customer_service.today.completed)==1 and near(float(m.state.customer_service.today.sales),20), "sale feedback cannot double-credit completed metric")
	check(int(m.state.customer_service.today.good_reviews)==1 and near(float(m.state.customer_service.today.wait_minutes),20), "actual quality review and service wait enter feedback")
	c=guest(8);m.state.total_minutes=500;s.record_timeout(c,true);s.record_timeout(c,true)
	check(int(m.state.customer_service.today.timeouts)==1 and int(m.state.customer_service.today.reasons.timeout)==1, "timeout reason counts once for true customer timeout")
	check(s.can("feedback_ack").ok and s.perform("feedback_ack").ok and not s.can("invalid").ok, "feedback action has narrow non-cheating interface")
	# Actual GameModel dispatch must keep arrivals independent of stock and
	# route recommendation through real staff motion and saved scheduler events.
	f=fresh();m=f.m
	m.balance["customer.base_flow"]=6
	m.state.total_minutes=270*1440+18*60
	stocked(m,"qianyang_soup")
	m.state.menu_enabled=["qianyang_soup"]
	var interval_stocked: int=m._spawn_interval()
	for id in m.state.management.items:
		m.state.management.items[id].quantity=0
	m.full_rules.management._sync_totals()
	check(m._spawn_interval()==interval_stocked, "actual arrival interval is identical with full and empty winter soup inventory")
	m.balance["customer.base_flow"]=0
	m._spawn_customer()
	check(m.customers.size()==1 and int(m.state.customer_service.today.arrivals)==1, "zero ingredients still creates an actual seated visitor")
	m.balance["service.feedback.stockout_bad_review_chance"]=1
	for minute in range(100):
		m.advance_minutes(1)
		if m.customers.is_empty(): break
	check(m.customers.is_empty() and int(m.state.lost)==1, "actual impossible order is notified and released rather than staying forever")
	check(int(m.state.customer_service.today.stockouts)==1 and int(m.state.customer_service.today.bad_reviews)==1, "actual cooking failure records one visible shortage review")
	check(int(m.state.served)==0 and near(float(m.state.total_revenue),0), "actual missing ingredients never produce fake revenue")
	f=fresh();m=f.m
	m.state.menu_enabled=[]
	m._spawn_customer()
	check(m.customers.size()==1, "even a fully closed menu cannot turn the customer spawner off")
	f=fresh();m=f.m;stocked(m,"qiongqi_hotpot");m.state.menu_enabled=["qiongqi_hotpot"]
	m.balance["customer.tip_chance"]=0;m.balance["coeff.charm_tip"]=0;m.balance["customer.escape_probability"]=0
	m._spawn_customer()
	var saw_order=false;var saved_order=false;var saw_actual_bill=false;var saw_recommending=false
	for minute in range(250):
		m.advance_minutes(1)
		if m.customers.is_empty():break
		var actual: Dictionary=m.customers[0]
		if str(actual.stage)=="recommending":saw_recommending=true
		if str(actual.stage)=="ordering" and int(actual.due_minute)>=0:
			saw_order=str(actual.worker)=="er_shu" and actual.get("task_motion",{}).get("action")=="Order"
			if not saved_order:
				var reload=Model.new(9);saved_order=m.save_game("user://v193-order-motion.json") and reload.load_game("user://v193-order-motion.json") and reload.customers[0].stage=="ordering"
		if bool(actual.get("paid",false)):saw_actual_bill=actual.get("price_quote") is Dictionary and near(float(actual.settled_amount),float(actual.price_quote.final))
		if int(m.state.served)>0:break
	check(saw_order and not saw_recommending,"waiter walks to the table and performs Order without a recommendation stage")
	check(saved_order,"real mid-order motion, employee and scheduler pass save/load")
	check(int(m.state.served)==1 and int(m.state.customer_service.today.recommend_attempts)==0,"premium meal actually sells with the initial waiter and chef alone")
	check(saw_actual_bill,"actual collected bill matches the revised staged calculation")
	check(int(m.state.customer_service.today.completed)==1 and near(float(m.state.customer_service.today.sales),float(m.state.total_revenue)),"measured feedback reconciles against actual sales")
	print("V1.5 CUSTOMER CHECKS: %d passed, %d failed" % [checks-failures,failures])
	quit(1 if failures else 0)
