extends SceneTree
## Test fixtures use actual model actions and hooks; not a natural-run claim.
const Model = preload("res://scripts/core/game_model.gd")
const Sidequests = preload("res://scripts/core/sidequest_rules.gd")
const Synergies = preload("res://scripts/core/synergy_rules.gd")
var checks := 0
var failures := 0

func check(value: bool, title: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error("V15 STORY SYNERGY FAIL: " + title)

func fresh() -> Variant:
	var m = Model.new(151821)
	m.start_full()
	return m

func add_employee(m: Variant, id: String) -> Dictionary:
	var employee: Dictionary = m._employee(id)
	if employee.is_empty():
		employee = m._create_employee(m._employee_config(id))
		m.employees.append(employee)
	employee.resting = false
	employee.stamina = 100.0
	employee.shift_enabled = false
	m.full_rules.management.ensure_state()
	return employee

func _initialize() -> void:
	var m: Variant = fresh()
	var side: Variant = Sidequests.new(m)
	var synergies: Variant = Synergies.new(m)
	side.ensure_state()
	synergies.ensure_state()
	check(side.config.quests.size() == 10, "all six SSR and four SR stories have real config")
	var ssr: Array = []
	for definition in side.config.quests:
		check(definition.nodes.size() == 3 and definition.nodes[0].lines.size() >= 2 and definition.nodes[1].choices.size() == 2, "three stages with actual dialogue " + str(definition.id))
		if str(m._employee_config(str(definition.employee_id)).rarity) == "SSR": ssr.append(str(definition.employee_id))
	check(ssr.size() == 6, "all six SSR covered")
	check(side.validate_state(m.state.sidequests, m.employees, int(m.state.total_minutes)), "fresh sidequest state strictly validates")
	check(synergies.validate_state(m.state.synergies), "fresh synergy state validates")
	check(not side.baize_unlocked() and m._employee("bai_ze").is_empty(), "Baize begins guide not employee")
	check(not side.can_perform("baize_page", {"id":"bai_ze"}).ok, "no self page lock")
	check(not side.can_perform("baize_page", {"id":"feng_huang"}).ok, "public cultural reading does not give uncollected page")
	check(side.can_perform("baize_page", {"id":"xian_yang"}).ok, "actual starter recruit has page")
	check(side.perform("baize_page", {"id":"xian_yang"}).ok, "page claim real action")
	check(side.affinity("bai_ze") == 4 and m._employee("bai_ze").is_empty(), "page builds guide affinity without hired staff")
	check(not side.perform("baize_page", {"id":"xian_yang"}).ok, "page cannot duplicate")
	check(side.perform("sidequest_read", {"id":"baize_atlas"}).ok, "guide story starts without hiring")
	check(not side.perform("sidequest_choice", {"id":"baize_atlas","choice_id":"understand"}).ok, "second stage needs sixty affinity")
	for definition in m.catalog:
		if str(definition.id) == "bai_ze" or str(definition.id) == "xian_yang": continue
		add_employee(m, str(definition.id))
		side.perform("baize_page", {"id":str(definition.id)})
	check(m.state.sidequests.pages.size() == 25 and side.affinity("bai_ze") == 100, "25 actual staff yield all pages and NPC affinity")
	check(not side.baize_unlocked(), "all pages still require final story acknowledgement")
	check(side.perform("sidequest_choice", {"id":"baize_atlas","choice_id":"understand"}).ok, "atlas middle choice")
	check(side.perform("sidequest_finish", {"id":"baize_atlas"}).ok and side.baize_unlocked(), "atlas ending unlocks SSR recruitment")
	check(m._employee("bai_ze").is_empty(), "unlock is not free recruitment")
	check(not side.perform("sidequest_finish", {"id":"baize_atlas"}).ok, "atlas reward once")
	m.state.contracts = ["bai_ze"]
	m.state.hire_tickets = 1
	check(m.full_rules.perform("recruit", {"kind":"contract"}).ok and float(m._employee("bai_ze").affinity) == 100, "eligible actual Baize recruitment retains the relationship established with the NPC")
	check("atlas_complete" in m.state.sidequests.lore_unlocked, "atlas finale unlocks lore")
	var baize_ending := str(m.state.sidequests.quests.baize_atlas.ending)
	check(baize_ending.begins_with("知音之约"), "dialogue choice selects distinct preserved ending")
	check(side.validate_state(m.state.sidequests, m.employees, int(m.state.total_minutes)), "completed atlas validates")
	var corrupted: Dictionary = m.state.sidequests.duplicate(true)
	corrupted.pages.append("bai_ze")
	check(not side.validate_state(corrupted, m.employees, int(m.state.total_minutes)), "invalid self page rejected")
	corrupted = m.state.sidequests.duplicate(true)
	corrupted.quests.baize_atlas.ending = "fake"
	check(not side.validate_state(corrupted, m.employees, int(m.state.total_minutes)), "wrong ending rejected")
	corrupted = m.state.sidequests.duplicate(true)
	corrupted.quests.baize_atlas.reward_claimed = false
	check(not side.validate_state(corrupted, m.employees, int(m.state.total_minutes)), "unmatched reward state rejected")

	m = fresh()
	side = Sidequests.new(m)
	side.ensure_state()
	var first: Dictionary = m._employee("xian_yang")
	var mood := float(first.mood)
	var loyalty := float(first.loyalty)
	var cash := float(m.state.cash)
	var expense := float(m.state.ledger.expenses)
	var flows: int = m.state.finance.flows.size()
	check(side.perform("gift", {"employee_id":"xian_yang","kind":"book"}).ok, "actual gift action")
	check(m.state.finance.flows.size() == flows + 1 and float(m.state.finance.flows.back().amount) == -20, "gift real cash-flow record reconciles")
	check(float(first.affinity) == 8 and float(m.state.cash) == cash - 20 and float(m.state.ledger.expenses) == expense + 20, "gift pays and records once")
	check(float(first.mood) == mood and float(first.loyalty) == loyalty, "affinity independent from mood and loyalty")
	check(not side.perform("gift", {"employee_id":"xian_yang"}).ok, "gift daily limit")
	check(side.perform("care", {"employee_id":"xian_yang"}).ok and float(first.affinity) == 10, "free daily dialogue actual gain")
	check(not side.perform("care", {"employee_id":"xian_yang"}).ok, "dialogue daily limit")
	check(not side.perform("gift", {"employee_id":"bai_ze"}).ok, "unhired guide not gift target")
	m.balance["sidequests.stable_minutes"] = 2
	first.resting = false
	first.stamina = 100
	var t := int(m.state.total_minutes)
	side.tick_minute()
	m.state.total_minutes = t + 1
	side.tick_minute()
	check(float(first.affinity) == 11, "stable actual observed duty minutes give affinity")
	side.tick_minute()
	check(float(first.affinity) == 11, "duplicate minute cannot award again")
	first.resting = true
	m.state.total_minutes = t + 2
	side.tick_minute()
	check(float(first.affinity) == 11, "resting no duty affinity")
	m.state.total_minutes = 10 * 1440 + t
	side.on_day()
	check(float(first.affinity) == 9, "ten days unscheduled modest loss")
	side.on_day()
	check(float(first.affinity) == 9, "neglect loss once per ten days")
	m.state.sidequests.affinity_records.xian_yang.last_duty_day = int(m.state.total_minutes / 1440)
	m.state.total_minutes += 1440
	side.on_day()
	check(float(first.affinity) == 9, "no natural daily affinity decay")

	m = fresh()
	side = Sidequests.new(m)
	var phoenix := add_employee(m, "feng_huang")
	side.ensure_state()
	phoenix.affinity = 90
	check(side.perform("sidequest_read", {"id":"phoenix_return"}).ok, "hired phoenix opening")
	check(not side.can_perform("sidequest_choice", {"id":"phoenix_return","choice_id":"cooperate"}).ok, "affinity alone no corresponding event")
	side.on_event("phoenix_rebirth", "rebirth")
	var affinity_after_event := float(phoenix.affinity)
	side.on_event("phoenix_rebirth", "rebirth")
	check(float(phoenix.affinity) == affinity_after_event, "event source duplicate gains deduplicated")
	check(side.perform("sidequest_choice", {"id":"phoenix_return","choice_id":"cooperate"}).ok, "real event and high affinity opens second stage")
	check(not side.can_perform("sidequest_finish", {"id":"phoenix_return"}).ok, "no fabricated rare ingredients")
	for id in ["danmu", "shan_hai_fish", "rare"]: m.full_rules.management.add_item(id, 1, 12)
	var expense_before := float(m.state.ledger.expenses)
	var result: Dictionary = side.perform("sidequest_finish", {"id":"phoenix_return"})
	check(result.ok and str(result.reward.hidden_recipe) == "phoenix_true_soup", "real three kinds unlock hidden recipe reward")
	check(str(phoenix.get("appearance", "")) == "feng_huang_awakened" and side.appearance_for("feng_huang") == "feng_huang_awakened", "completed Phoenix quest activates the developer appearance slot")
	for id in ["danmu", "shan_hai_fish", "rare"]: check(float(m.full_rules.management.item(id).quantity) == 0, "quest actually consumes " + id)
	check(float(m.state.ledger.expenses) == expense_before + 36, "ritual ingredient value records once as expense")
	check(str(m.state.sidequests.quests.phoenix_return.ending).begins_with("同业之约"), "other dialogue creates different ending")
	check("phoenix_true_soup" in side.modifiers().hidden_recipes and side.additional_dishes()[0].quality == 85, "complete actual recipe schema")
	check(not side.perform("sidequest_finish", {"id":"phoenix_return"}).ok, "recipe and costs cannot repeat")
	var jiuying := add_employee(m, "jiu_ying")
	side.ensure_state()
	jiuying.affinity = 90
	side.perform("sidequest_read", {"id":"jiuying_unison"})
	for i in range(3):
		side.on_event("jiuying_multitask", "coordinate", {}, int(m.state.total_minutes) + i)
		side.on_event("strange_weather", "adapt", {}, int(m.state.total_minutes) + i)
	check(int(m.state.sidequests.counters.jiuying_sequence) == 3, "three consecutive own coordination events despite unrelated events")
	side.perform("sidequest_choice", {"id":"jiuying_unison","choice_id":"understand"})
	check(side.perform("sidequest_finish", {"id":"jiuying_unison"}).ok and side.modifiers().jiuying_batch_capacity == 4, "Jiuying actual task unlocks four-way capacity")
	side.on_event("tiangou_moon", "stop")
	check(not "moon_memory" in m.state.sidequests.lore_unlocked, "wrong moon choice no lore")
	cash = float(m.state.cash)
	var gems := int(m.state.gems)
	var rep := int(m.state.reputation)
	side.on_event("tiangou_moon", "reassure")
	check("moon_memory" in m.state.sidequests.lore_unlocked, "actual hidden reassurance choice reveals lore")
	check(side.perform("lore_read", {"id":"moon_memory"}).ok and "moon_memory" in m.state.sidequests.lore_read, "lore read persists")
	side.on_exploration("old_restaurant")
	check("ruins_origin" in m.state.sidequests.lore_unlocked, "specific real exploration place reveals lore")
	check(float(m.state.cash) == cash and int(m.state.gems) == gems and int(m.state.reputation) == rep, "world lore never creates numeric rewards")
	check(not side.perform("lore_read", {"id":"unknown"}).ok, "unknown lore rejected")

	m = fresh()
	side = Sidequests.new(m)
	side.ensure_state()
	var order: Dictionary = {"id":11,"dish_id":"yinglong_fish","chef_id":"ying_long","serving_employee_id":"di_jiang","paid":false,"settled_amount":50}
	side.on_customer_served(order, {"id":"xian_yang"})
	check(int(m.state.sidequests.counters.get("dijiang_served",0)) == 0, "unpaid order no completed task")
	order.paid = true
	order.settled_amount = 0
	side.on_customer_served(order, {"id":"xian_yang"})
	check(int(m.state.sidequests.counters.get("dijiang_served",0)) == 0, "escaped order no completed task")
	order.settled_amount = 50
	side.on_customer_served(order, {"id":"xian_yang"})
	check(int(m.state.sidequests.counters.get("dijiang_served",0)) == 1, "actual recorded server credited rather than cashier")
	side.on_customer_served(order, {"id":"xian_yang"})
	check(int(m.state.sidequests.counters.get("dijiang_served",0)) == 1, "same paid order cannot satisfy a task twice")
	var night_order: Dictionary = {"id":12,"dish_id":"noodles","chef_id":"zhu_long","paid":true,"settled_amount":10}
	m.state.total_minutes = 22 * 60
	side.on_customer_served(night_order)
	check(int(m.state.sidequests.counters.get("zhulong_night_served",0)) == 1, "actual night_market period contributes to Zhulong task")
	side.on_hook("cleaning", {"employee_id":"jing_wei"})
	check(int(m.state.sidequests.counters.get("jingwei_cleaned",0)) == 1, "actual cleaning hook increments task")
	m = fresh()
	synergies = Synergies.new(m)
	synergies.ensure_state()
	check(synergies.config.pairs.size() == 10, "exact five mutual and five counter pairs")
	var yinglong := add_employee(m, "ying_long")
	var nine := add_employee(m, "jiu_ying")
	check(synergies.active_pairs().size() == 1, "both actual duty activates water pair")
	check(is_equal_approx(synergies.bonus("quality", {"category":"水产"}), 0.15), "water quality exact")
	check(is_zero_approx(synergies.bonus("quality", {"category":"汤品"})), "non-water dish excluded")
	check(is_zero_approx(synergies.bonus("traffic", {"weather":"clear"})), "clear weather no rain bonus")
	check(is_equal_approx(synergies.bonus("traffic", {"weather":"rain"}), 0.10), "actual rain bonus")
	nine.resting = true
	check(synergies.active_pairs().is_empty(), "rest instantly cancels synergy")
	nine.resting = false
	nine.branch_id = "branch_1"
	check(synergies.active_pairs().is_empty(), "different branch not same duty")
	nine.branch_id = ""
	nine.management_until = int(m.state.total_minutes) + 30
	check(synergies.active_pairs().is_empty(), "training not simultaneous duty")
	nine.management_until = 0
	add_employee(m, "qiong_qi")
	add_employee(m, "xie_zhi")
	check(synergies.snapshot().conflicts.size() == 1, "red conflict preview separate from positive")
	check(is_equal_approx(synergies.bonus("conflict"), 0.20), "exact dispute risk")
	check(is_equal_approx(synergies.bonus("complaint_speed", {"employee_id":"xie_zhi"}), -0.20), "exact Xiezhi complaint reduction")
	check(is_zero_approx(synergies.bonus("complaint_speed", {"employee_id":"qiong_qi"})), "counter only named employee")
	var conflicts: Array = synergies.tick_minute()
	check(conflicts.size() == 1 and synergies.tick_minute().is_empty(), "conflict transition announced once")
	side = Sidequests.new(m)
	side.ensure_state()
	m._employee("qiong_qi").affinity = 50
	m._employee("xie_zhi").affinity = 50
	side.on_counter_pairs(conflicts)
	side.on_counter_pairs(conflicts)
	check(float(m._employee("qiong_qi").affinity) == 48 and float(m._employee("xie_zhi").affinity) == 48, "counter affinity modest daily cap")
	var merged: Array = synergies.sources({"category":"水产"})
	merged.append({"source":"bond:water_pair","effect":"quality","value":0.35})
	merged.append({"source":"bond:other_quality","effect":"quality","value":0.10})
	check(is_equal_approx(Synergies.unique_bonus("quality", merged), 0.35), "same quality source picks strongest rather than multiplicative stacking")
	merged.append({"source":"counter:quality","effect":"quality","value":-0.10})
	check(is_equal_approx(Synergies.unique_bonus("quality", merged), 0.25), "strongest penalty still applies alongside benefit")
	var override: Dictionary = synergies.balance_defaults()
	override["coeff.bond_water_quality"] = 0.25
	check(synergies.validate_balance(override), "valid global coefficients accepted")
	m.balance["coeff.bond_water_quality"] = 0.25
	check(is_equal_approx(synergies.bonus("quality", {"category":"水产"}), 0.25), "live global coefficient authority")
	override["coeff.bond_water_quality"] = INF
	check(not synergies.validate_balance(override), "nonfinite coefficient rejected")
	var source_free: Variant = Sidequests.new(RefCounted.new())
	check(not source_free.balance_defaults().is_empty() and source_free.validate_balance(source_free.balance_defaults()), "balance defaults inspect without model")
	print("V15 story/synergy: %d checks, %d failures" % [checks, failures])
	quit(1 if failures > 0 else 0)
