extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
func _init() -> void:call_deferred("run")
func expect(value: bool,message: String) -> void:
	checks+=1
	if not value:failures+=1;push_error(message)
func fresh():
	var m=Model.new(20261019);m.start_full();return m
func cell(m,id: String) -> Vector2i:
	for y in range(5):
		for x in range(8):
			if m.can_place_decoration(id,x,y):return Vector2i(x,y)
	return Vector2i(-1,-1)
func run() -> void:
	var m=fresh();var revision=m.full_rules.revision
	var employee=m._employee("xian_yang")
	expect(employee.level==1 and revision.level_cap(employee)==20,"New N employees start level1 with cap20")
	for rarity in ["N","R","SR","SSR"]:
		var e=employee.duplicate(true);e.rarity=rarity;e.attributes.speed=10;e.mood=50
		var factor=m.AnimationRules.animation_factor(e,"Move",m.balance)
		expect(is_equal_approx(factor,1.4*float(revision.config.rarity_speed_mult[rarity])),"Attribute and rarity movement factors multiply: "+rarity)
	var new_staff=m._create_employee(m._employee_config("er_shu"))
	expect(is_equal_approx(float(new_staff.motion.speed),float(m.AnimationRules.animation_settings(m.balance).base_move_pixels_per_game_minute)*m.AnimationRules.animation_factor(new_staff,"Move",m.balance)),"New recruit's initial walk uses rarity speed before first service task")
	var e=employee.duplicate(true);e.rarity="R";expect(revision.level_cap(e)==30,"R cap30")
	e.rarity="SR";expect(revision.level_cap(e)==40,"SR cap40")
	e.rarity="SSR";expect(revision.level_cap(e)==50,"SSR cap50")
	employee.level=20
	expect(not m.full_rules.can_perform("train_attribute",{"id":"xian_yang","attribute":"speed"}).ok,"Training cannot bypass the N level cap")
	employee.awakening_count=1;expect(revision.level_cap(employee)==30,"Each awakening raises cap by10")
	employee.level=1;employee.awakening_count=0
	# Notice: enqueue, saved queue and clock are all unchanged until confirmation.
	var before=int(m.state.reputation)
	m.employees.append(m._create_employee(m._employee_config("ran_yi_yu")));m.full_rules.ensure_state_defaults()
	m.full_rules.world._enqueue("ranyiyu_vision",{"employee_id":"ran_yi_yu"})
	expect(int(m.state.reputation)==before and m.pending_event().type=="notice","No-choice event has no effects before its one confirmation")
	var minute=int(m.state.total_minutes);m.advance_minutes(20)
	expect(int(m.state.total_minutes)==minute,"Unconfirmed notice stops manual fast-forward as well as real time")
	var save="/tmp/shanhai-v171-rules.json";var loaded=fresh()
	expect(m.save_game(save) and loaded.load_game(save),"A pending notice is a valid, reproducible save")
	expect(m.full_rules.world.choose("share").get("ok",false),"The single notice confirmation resolves its original effect")
	expect(int(m.state.reputation)>before and m.pending_event().is_empty(),"Confirm applies the numerical outcome once and removes its queue entry")
	# Booking and construction have separate phases; closed hours consume no work.
	m=fresh();m.state.stage=1;m.state.cash=5000;revision=m.full_rules.revision
	var point=cell(m,"table_two");var cash=float(m.state.cash);var seats=int(m.state.seats)
	expect(not revision.build_check("table_two","").ok,"Explicit builder assignment is required")
	expect(revision.book_build("table_two",point.x,point.y,"xiao").ok,"A real on-duty idle employee can book a table job")
	revision.activate_builds();expect(not m.full_rules.active("xiao") and m.state.seats==seats,"Assigned builder is occupied and unfinished table grants no seats")
	expect(float(m.state.cash)==cash-150,"Two-seat table uses the specified150 price")
	expect(m.save_game(save) and loaded.load_game(save),"Active construction keeps its employee, site and remaining work in saves")
	var remaining=int(revision.s().builds[0].remaining);m.state.total_minutes=60;m.advance_minutes(30)
	expect(int(revision.s().builds[0].remaining)==remaining,"Construction pauses during0–6 closed hours")
	m.state.total_minutes=360;m.advance_minutes(int(ceil(float(m._employee("xiao").motion.get("travel_minutes",0))))+59)
	expect(int(m.state.seats)==seats,"Table remains unavailable until the60th work minute")
	m.advance_minutes(1);expect(int(m.state.seats)==seats+2 and revision.s().builds.is_empty(),"Completion adds the seats and releases the assigned employee exactly once")
	# Exact compensation, protected Baize and minimum viable staff.
	m=fresh();m.state.cash=10000;revision=m.full_rules.revision
	expect(not revision.dismissal_quote("xian_yang").ok,"Last chef cannot be dismissed")
	m.employees.append(m._create_employee(m._employee_config("er_shu")));m.full_rules.ensure_state_defaults()
	var target=m._employee("er_shu");target.level=2;target.training_history={"speed":1};target.loyalty=80
	var quote=revision.dismissal_quote("er_shu")
	expect(quote.ok and float(quote.cost)==610,"Compensation equals level×50 + trained points×10 + loyalty×5 +100")
	var collection=m.state.story.collected_ids.duplicate();cash=float(m.state.cash)
	expect(m.full_rules.perform("dismiss_employee",{"id":"er_shu"}).ok and m._employee("er_shu").is_empty(),"Confirmed public dismissal really frees the employee slot")
	expect(float(m.state.cash)==cash-610 and m.state.story.collected_ids==collection,"Dismissal pays once and retains discoveries")
	expect(not m.full_rules.perform("dismiss_employee",{"id":"er_shu"}).ok,"A second dismissal cannot charge again")
	# Ordinary debt restrictions do not remove the independent emergency rescue.
	m=fresh();m.state.stage=1;m.state.cash=-1
	expect(not m.full_rules.finance.can_perform("loan_apply",{"amount":1000}).ok,"Negative cash bans ordinary financing")
	m.full_rules.finance._trigger_rescue("test",1)
	expect(not m.full_rules.rescue.can("emergency_accept").ok,"Emergency loan requires explicit cost acknowledgment")
	expect(m.full_rules.perform("emergency_accept",{"confirmed":true}).ok,"The first rescue can be accepted independently of ordinary debt restrictions")
	expect(float(m.state.cash)==4999 and m.state.rescue171.used and int(m.state.rescue171.loan.due_day)==21,"Rescue injects exactly5000 once with20-day maturity")
	var report={"day":1,"loan_interest":0.0,"loan_interest_due":0.0,"loan_fine":0.0}
	m.full_rules.rescue.charge_day(report)
	expect(float(report.emergency_interest_due)==100 and float(m.state.cash)==4899,"Emergency loan charges2% daily, independently of ordinary loans")
	expect(m.save_game(save) and loaded.load_game(save),"Rescue usage and emergency debt survive valid save/load")
	m.full_rules.finance._trigger_rescue("second bankruptcy",1)
	expect(m.state.rescue171.ended and not m.full_rules.rescue.can("emergency_accept",{"confirmed":true}).ok,"Second bankruptcy forcibly ends the run instead of offering infinite rescues")
	expect(m.save_game(save) and loaded.load_game(save),"Failure screen and final results persist")
	m.restart_campaign_with_keepsakes();expect(not m.state.rescue171.used and not m.state.rescue171.ended,"A genuine new run clears only per-run rescue usage")
	DirAccess.remove_absolute(save)
	print("V1.7.1 rules: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
