extends SceneTree
const Assets=preload("res://scripts/services/asset_catalog.gd")
const Model=preload("res://scripts/core/game_model.gd")
var checks=0
var failures=0
var base="/tmp/shanhai-v193-assets"
func _init():base+="-"+str(Time.get_ticks_usec());call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func png(color: Color) -> PackedByteArray:
	var image=Image.create(8,8,false,Image.FORMAT_RGBA8);image.fill(color);return image.save_png_to_buffer()
func write(root: String,path: String,color: Color):
	DirAccess.make_dir_recursive_absolute(root.path_join(path).get_base_dir());var file=FileAccess.open(root.path_join(path),FileAccess.WRITE);file.store_buffer(png(color));file.close()
func color(texture: Texture2D) -> Color:return texture.get_image().get_pixel(3,3)
func run():
	var builtin=base+"/builtin";var custom=base+"/custom"
	write(builtin,"Sprites/bi_fang/walk_up_0.png",Color.RED);write(builtin,"Sprites/bi_fang/walk_up_1.png",Color.GREEN)
	write(builtin,"Sprites/bi_fang/idle_down_0.png",Color.WHITE)
	var a=Assets.new(builtin,custom)
	expect(a.import_image(png(Color.BLUE),"Sprites/bi_fang/walk_up_0.png").ok,"Nested directional PNG imports through the same safe boundary")
	expect(color(a.get_frame("bi_fang","walk","up",0))==Color.BLUE and color(a.get_frame("bi_fang","walk","up",1))==Color.GREEN,"Partial custom override retains the other builtin directional frame")
	expect(color(a.get_frame("bi_fang","Move","up",2))==Color.BLUE,"Move maps to walk and cycles through the supplied sequence")
	expect(color(a.get_frame("bi_fang","cook","left"))==Color.WHITE,"Missing action/direction falls back to idle_down")
	expect(a.import_image(png(Color.YELLOW),"Sprites/bi_fang/cook_down_0.png").ok and color(a.get_frame("bi_fang","Cook","up"))==Color.YELLOW,"Missing cook up uses cook down before idle")
	expect(a.is_placeholder(a.get_portrait("bi_fang")),"Missing portrait never enlarges the gameplay sprite")
	expect(a.import_image(png(Color.MAGENTA),"Portraits/bi_fang.png").ok and color(a.get_portrait("bi_fang"))==Color.MAGENTA,"Employee portrait is independently replaceable")
	expect(color(a.get_portrait("bi_fang",true))==Color.MAGENTA,"Guide without a dedicated portrait uses normal portrait")
	expect(a.import_image(png(Color.CYAN),"Portraits/tutorial_bi_fang.png").ok and color(a.get_portrait("bi_fang",true))==Color.CYAN,"Guide portrait override is independent of employee photo")
	for path in ["UI/panel_employee.png","Map/equip_stove.png","Map/floor_wood.png","Items/dish_noodles.png","FX/icon_warning.png"]:expect(a.import_image(png(Color.RED),path).ok and a.has_image(path),"Six-type image slot is actually importable: "+path)
	expect(color(a.get_texture("Dishes/noodles"))==Color.RED,"New Items dish icon reaches existing menu and recipe callers")
	expect(a.import_image(png(Color.GREEN),"Sprites/customer/human/human_02/human_02_eat_left_0.png").ok,"Ordinary customer appearance has its own animation folder")
	expect(color(a.get_customer_frames("human","human_02","eat","left")[0])==Color.GREEN,"Customer gets the actual eat/left frame")
	expect(a.import_image(png(Color.BLUE),"Sprites/customer/lao_tao/lao_tao_walk_down_0.png").ok,"Named guest uses its specified pinyin folder")
	expect(color(a.get_customer_frames("special","lao_tao","walk","up")[0])==Color.BLUE,"Named guest direction fallback uses walk_down")
	for path in ["Sprites/bi_fang/../../escape.png","Portraits/../escape.png","Sprites/customer/./x.png","Other/x.png","Sprites/bi_fang/walk_up_0.gd"]:expect(not a.import_image(png(Color.RED),path).ok,"Unsafe or non-image nested path rejected: "+path)
	write(custom,"Characters/qianyang_idle_0.png",Color.YELLOW);a.reload()
	expect(color(a.get_frame("xian_yang","idle","down"))==Color.YELLOW,"Original Characters/qianyang path still serves the canonical employee")
	write(custom,"Sprites/feng_huang/idle_down_0.png",Color.GREEN);a.reload()
	var m=Model.new(193);m.start_full();var supported=0
	# Every required action and direction has a valid static fallback, without fabricating images.
	for action in ["walk","idle","order","cook","serve","clean","cashier","promote","rest"]:
		for direction in ["down","up","left","right"]:
			if color(a.get_frame("feng_huang",action,direction))==Color.GREEN:supported+=1
	expect(supported==36,"All9 actions×4 directions honor the documented single-idle degradation")
	var slots=preload("res://scripts/ui/art_targets.gd").slots(m);var unique: Dictionary={}
	for slot in slots:unique[str(slot.path)]=true
	expect(unique.size()==slots.size(),"New import targets have no duplicate paths")
	for e in m.catalog:
		for action in ["walk","idle","order","cook","serve","clean","cashier","promote","rest"]:
			for direction in ["down","up","left","right"]:expect(unique.has("Sprites/%s/%s_%s_0.png" % [e.id,action,direction]),"Required employee frame contract "+str(e.id)+" "+action+" "+direction)
	print("V1.9.3 assets: %d checks; %d failures; %d new import targets" % [checks,failures,slots.size()]);quit(1 if failures else 0)
