extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
	checks+=1
	if not ok:failures+=1;push_error(message)
func settle():
	for i in range(8):await process_frame
func find(node: Node,id: String):
	if node.is_queued_for_deletion():return null
	if str(node.get_meta("qa_id",""))==id:return node
	for child in node.get_children():
		var found=find(child,id)
		if found!=null:return found
	return null
func run():
	root.size=Vector2i(1440,900);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	for dimensions in [Vector2i(1440,900),Vector2i(844,390)]:
		root.size=dimensions;ui.update_ui_layout();ui.refresh();await settle()
		var bar=ui.bottom_ui.first
		expect(bar.get_global_rect().end.y<ui.map_view.global_position.y,"One live top row precedes restaurant "+str(dimensions))
		expect(bar.size.y<=52 and bar.get_global_rect().end.x<=ui.size.x+1,"Single row fits viewport "+str(dimensions))
		expect(ui._layout_controls.bottom.get_global_rect().end.y<=ui.size.y,"Bottom only navigation remains within screen")
		for resource in [ui.money_label,ui.gem_label,ui.reputation_label,ui.clock_label,ui.todo_button,ui.training_status,ui.building_status]:expect(bar.is_ancestor_of(resource),"Important number belongs to top row")
		var height=ui.map_view.size.y;ui.bottom_ui.toggle_inventory();await settle()
		expect(ui.bottom_ui.inventory_box.visible and ui.map_view.size.y<height and ui._layout_controls.bottom.get_global_rect().end.y<=ui.size.y,"Inventory expands inline without losing navigation")
		ui.bottom_ui.toggle_inventory();await settle()
		if ui.compact_layout:
			find(ui,"time:menu").pressed.emit();await settle();expect(ui.bottom_ui.speed_popup.visible,"Small screen exposes44px speed popup")
			ui.speed_buttons[3].pressed.emit();await settle();expect(ui.model.speed==4 and not ui.bottom_ui.speed_popup.visible,"Choosing4x really changes speed and closes menu")
		ui.open_panel("经营状态");await settle();expect(ui.modal_window.get_global_rect().position.y>=bar.get_global_rect().end.y and ui.modal_window.get_global_rect().end.y<=ui._layout_controls.bottom.global_position.y,"Panel leaves top live resources and bottom nav visible")
		ui.close_panel();await settle()
	# Short notices are compact, long notices stay readable and duplicate types throttle.
	ui.toast_timer=0;ui._notice_queue.clear();ui._notice_last.clear();ui.show_notice("收入+5元")
	expect(is_equal_approx(ui.toast_timer,1.5),"Short toast has1.5 real seconds")
	await settle();expect(ui.toast_label.size.y<=32,"Short notice fits one thin line")
	ui.show_notice("收入+10元");expect(ui._notice_queue.is_empty(),"Same notice type does not repeat inside1second")
	ui.show_notice("新事件到访");expect(ui._notice_queue.size()==1,"Different notices queue instead of stacking")
	expect(ui.notice_duration("长".repeat(13))==2 and ui.notice_duration("长".repeat(100))==2.5,"Long notices scale by6characters/.5sec with2.5second cap")
	ui.toast_timer=0;ui._cash_floats.clear();ui._notice_queue.clear()
	var rng=ui.model._rng.state;var view=ui.map_view
	view._update_employee_animation(0);view.thoughts.bubbles.clear()
	for e in ui.model.employees:view.thoughts.speak(e,true)
	for b in view.thoughts.bubbles:expect(b.left<=4 and b.node.autowrap_mode==TextServer.AUTOWRAP_OFF,"Focused speech remains one compact line and at most4seconds")
	ui.toast_timer=1;var floating=Label.new();ui.add_child(floating);ui._cash_floats.append({"node":weakref(floating),"left":1.0});view.thoughts.update(0)
	expect(view.thoughts.bubbles.size()<=1,"Combined toast,cash andspeech obey total3 limit")
	ui._cash_floats.clear();ui.toast_timer=0
	expect(ui.model._rng.state==rng,"Presentation never consumes经营RNG")
	# Guest expressions anchor to real customer seats too.
	for i in range(view.thoughts.bubbles.size()-1,-1,-1):view.thoughts._remove(i)
	ui.model.events.clear();ui.model._spawn_customer("fried_rice",false);view.thoughts.speak_waiting_guest()
	expect(view.thoughts.bubbles.any(func(b):return str(b.id).begins_with("guest:")),"Actual guest gets a seat-following expression")
	# A single target gets an arrow or a finite flash burst.
	var tutorial=ui.model.state.tutorial.duplicate(true);ui.tutorial_overlay.restart_tutorial();ui.tutorial_overlay.poll(.1);await settle()
	expect(ui.tutorial_overlay.reminder_snapshot().arrow,"Default guided button has directional arrow")
	expect(not ui.tutorial_overlay.tutorial_card.get_global_rect().intersects(ui.tutorial_overlay.highlight_rect),"Guide card stays clear of its target")
	ui.model.state.tutorial.completed_steps=["welcome","staff","promotion"];ui.tutorial_overlay.poll(0);ui.tutorial_overlay.poll(2)
	var reminder=ui.tutorial_overlay.reminder_snapshot();expect(reminder.mode==1 and reminder.flashes==3,"Scene highlight stops flashing after at most3 pulses")
	ui.model.state.tutorial=tutorial;ui.tutorial_overlay.poll(0)
	for id in ["qing_fu","tian_lu"]:
		ui.open_culture("employees",id);await settle();expect(ui.culture_panel.entry_id==id,"New staff culture entry viewable: "+id)
	ui.open_panel("美术资源");await settle();expect(ui._art_culture_slots.item_count>=82,"55 culture,12visitor,2pickup,12dollhouse andmanual art slots retained")
	ui.queue_free();await settle();print("V1.9 UI: %d checks; %d failures" % [checks,failures]);quit(1 if failures else 0)
