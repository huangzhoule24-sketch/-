extends SceneTree
## Real model fixtures in /tmp; no user saves and no claim of natural full playthrough.
const Model = preload("res://scripts/core/game_model.gd")
const Story = preload("res://scripts/core/story_rules.gd")
var checks = 0
var failures = 0

class StoryHarness extends "res://scripts/ui/main.gd":
	func _ready() -> void:
		var test_theme = Theme.new()
		test_theme.default_font = FONT
		theme = test_theme
		model = GameModel.new(3181)
		model.start_full()
		# Story panel fixture bypasses the separate mandatory-guide acceptance suite.
		model.state.tutorial = {"version":2,"completed_steps":["welcome","staff","promotion","first_order","income","bill"],"deferred":Guide.config().stage_steps.map(func(step): return step.id),"actions":[],"stage_completed":[],"panel_opened":[],"panel_closed":[],"finished":true,"skipped":false,"seen_stage":0}
		assets = AssetCatalog.new()
		model.set_paused(true)
		build_interface()
		full_panels = FullPanels.new(self)
		story_panel = StoryPanel.new(self)
		model.changed.connect(refresh)
		model.notice.connect(show_notice)
		set_process(false)
		refresh()

func check(value: bool, title: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error("STORY FAIL: " + title)

func fresh():
	var m = Model.new(3178)
	m.start_full()
	m.balance["customer.base_flow"] = 0
	return m

func add_beasts(m, count: int) -> void:
	for definition in m.catalog:
		if m.employees.size() >= count: break
		if not m._employee(str(definition.id)).is_empty(): continue
		var employee: Dictionary = m._create_employee(definition)
		employee.resting = true
		m.employees.append(employee)
	m.full_rules.management.ensure_state()

func _initialize() -> void:
	var m = fresh()
	var story = Story.new(m)
	story.ensure_state()
	check(story.snapshot().collection == 2, "initial two unique employees")
	check(not story.can_perform("story_claim", {"id":"debt"}).ok, "unpaid debt blocks story reward")
	check(not story.can_perform("story_claim", {"id":"unknown"}).ok, "unknown milestone rejected")
	check(story.validate_state(m.state.story, m.employees, int(m.state.total_minutes)), "fresh story validates")
	check(not story.validate_state({}, m.employees, int(m.state.total_minutes)), "present empty story is malformed")
	check(story.snapshot().calendar.id == "opening_day", "day one calendar appears")
	var before_cash = float(m.state.cash)
	var before_expenses = float(m.state.ledger.expenses)
	m._employee("xian_yang").mood = 60
	check(story.perform("seasonal_activity").ok, "self funded festival activity")
	check(is_equal_approx(float(m.state.cash), before_cash - 80), "festival activity really pays")
	check(is_equal_approx(float(m.state.ledger.expenses), before_expenses + 80), "festival cost records once")
	check(is_equal_approx(float(m._employee("xian_yang").mood), 63), "festival affects actual mood")
	check(int(m.state.reputation) == 28, "festival actual reputation effect")
	check(not story.perform("seasonal_activity").ok, "festival cannot repeat same day")
	var persisted: Dictionary = m.state.story.duplicate(true)
	m.state.story = persisted.duplicate(true)
	story = Story.new(m)
	story.ensure_state()
	check(not story.perform("seasonal_activity").ok, "festival stays claimed after rules reconstruction")
	m.state.cash = 0
	m.state.total_minutes = 14 * 1440 + 360
	story.on_day()
	check(story.snapshot().calendar.id == "moon_day", "day fifteen calendar")
	check(not story.perform("seasonal_activity").ok, "festival insufficient money blocked")
	m.state.cash = 1000
	m.state.total_minutes = 14 * 1440 + 120
	check(not story.perform("seasonal_activity").ok, "festival outside business blocked")
	m.state.total_minutes = 14 * 1440 + 360
	check(story.perform("seasonal_activity").ok, "new festival day is separately eligible")
	m.state.total_minutes = 15 * 1440 + 360
	story.on_day()
	check(story.snapshot().calendar.is_empty(), "ordinary day has no festival activity")
	check(not story.perform("seasonal_activity").ok, "ordinary day activity rejected")

	m = fresh()
	story = Story.new(m)
	story.ensure_state()
	check(not story.can_perform("festival_invitation").ok, "festival application reputation gate")
	m.state.reputation = 500
	m.state.total_minutes = 120
	check(not story.can_perform("festival_invitation").ok, "festival application business gate")
	m.state.total_minutes = 360
	m.state.cash = 2000
	before_cash = float(m.state.cash)
	check(story.perform("festival_invitation").ok, "player can request real festival event")
	check(float(m.state.cash) == before_cash and int(m.state.world.festival_wins) == 0, "invitation invents no winnings or cost")
	check(str(m.full_rules.world.pending_event().id) == "food_festival", "original festival event queued")
	check(not story.perform("festival_invitation").ok, "queued festival invitation blocks repeat")
	for employee in m.employees:
		if str(employee.role) == "chef":
			employee.attributes.cooking = 20
			employee.attributes.creativity = 20
	check(m.full_rules.world.choose("enter").ok, "original festival resolves paid entry")
	check(int(m.state.world.festival_wins) == 1, "festival outcome from original contest")
	check(not story.perform("festival_invitation").ok, "resolved invitation still on original cooldown")
	check(not story.perform("story_claim", {"id":"festival"}).ok, "story claim respects previous chapter order")
	m.state.debt = 0
	story.tick_minute()
	var books = int(m.state.management.skill_books)
	check(story.perform("story_claim", {"id":"debt"}).ok, "debt narrative claim")
	check(int(m.state.management.skill_books) == books + 1, "debt gives usable skill book")
	check(not story.perform("story_claim", {"id":"debt"}).ok, "debt claim is idempotent")
	check(story.perform("story_claim", {"id":"festival"}).ok, "festival narrative uses actual win")
	add_beasts(m, 12)
	story.tick_minute()
	check(int(story.snapshot().collection) == 12, "twelve unique beasts tracked")
	check(not "all_beasts" in m.state.story.completed, "twelve does not count as all twenty six")
	check(story.perform("story_claim", {"id":"twelve"}).ok, "twelve beast main milestone")
	check(bool(m.state.management.hidden_unlocked), "twelve reward unlocks management hidden recipe")
	check("baize_hidden_banquet" in m.state.unlocked_dishes, "hidden recipe actually playable")
	var dish_count = m.dishes.size()
	books = int(m.state.management.skill_books)
	check(not story.perform("story_claim", {"id":"twelve"}).ok, "hidden recipe award cannot repeat")
	check(dish_count == m.dishes.size() and books == int(m.state.management.skill_books), "repeat changes no books or dishes")
	var departed: Dictionary = m.employees.pop_back()
	m.state.management.departed.append({"id":str(departed.id),"day":0})
	story.tick_minute()
	check(int(story.snapshot().collection) == 12, "departure preserves collection history")
	m.state.stage = 2
	check(m.full_rules.world._eligible(m.full_rules.world._definition("kunlun_trouble"), "random", {}), "kunlun actual event eligible")
	check(m.full_rules.world._enqueue("kunlun_trouble"), "kunlun event enqueued")
	check(not bool(story.snapshot().entries[3].complete), "queued blockade is not resolved blockade")
	check(m.full_rules.world.choose("pr").ok, "kunlun actual costed response")
	story.tick_minute()
	check(not story.perform("story_claim", {"id":"kunlun"}).ok, "one response does not invent a defeated blockade")
	check(m.full_rules.world.perform("kunlun_counter", {"strategy":"supply"}).ok, "independent supply action costs real cash")
	check(m.full_rules.world.perform("kunlun_counter", {"strategy":"community"}).ok, "community action requires reputation and cash")
	# This story fixture isolates progression; world_completion_tests exercises
	# twelve actual customer checkouts before allowing the service action.
	m.state.world.blockade.service_orders = 12
	check(m.full_rules.world.perform("kunlun_counter", {"strategy":"service"}).ok, "all blockade conditions resolve actual state")
	story.tick_minute()
	m.state.world.history.clear()
	check(story.perform("story_claim", {"id":"kunlun"}).ok, "resolved blockade survives history pruning")
	m.state.stage = 4
	story.tick_minute()
	check(story.perform("story_claim", {"id":"group"}).ok, "stage four narrative reward")
	check(not story.perform("story_claim", {"id":"champion"}).ok, "group alone does not count as champion")
	var chef: Dictionary = m._employee("xian_yang")
	chef.attributes.cooking = 20
	chef.attributes.creativity = 20
	chef.resting = false
	m.state.gems = 10
	check(m.full_rules.expansion.perform("compete", {"employee_id":"xian_yang", "dish_id":"noodles"}).ok, "real competition starts with ingredients and fee")
	m.state.total_minutes = int(m.state.total_minutes) + 90
	m.full_rules.expansion.tick_minute()
	story.tick_minute()
	check(int(m.state.expansion.competition.wins) == 1, "actual scored competition wins")
	check(story.perform("story_claim", {"id":"champion"}).ok, "actual champion completes main story")
	check(bool(story.snapshot().complete), "narrative end supports continued operation")
	add_beasts(m, 30)
	story.tick_minute()
	check(int(story.snapshot().collection) == 30, "all beast collection distinct")
	check(story.perform("story_claim", {"id":"all_beasts"}).ok, "all twenty six separate achievement")
	check(story.validate_state(m.state.story, m.employees, int(m.state.total_minutes)), "completed story strict validation")
	var source: Dictionary = m.state.story.duplicate(true)
	for case in ["duplicate_id", "unknown_id", "future_time", "fake_claim", "reordered", "future_day"]:
		var invalid: Dictionary = source.duplicate(true)
		match case:
			"duplicate_id": invalid.collected_ids.append(invalid.collected_ids[0])
			"unknown_id": invalid.collected_ids.append("forged_beast")
			"future_time": invalid.completion_minutes.debt = int(m.state.total_minutes) + 1
			"fake_claim": invalid.claimed.append("forged")
			"reordered": invalid.claimed.erase("debt")
			"future_day": invalid.last_day = 200000
		check(not story.validate_state(invalid, m.employees, int(m.state.total_minutes)), "malformed story rejected " + case)
	check(m.state.story == source, "rejected validation does not mutate live state")

	m = fresh()
	story = Story.new(m)
	story.ensure_state()
	m.state.total_revenue = 600
	m.state.served = 40
	m.state.total_minutes = 7 * 1440
	story.on_day()
	check(int(story.snapshot().week.served) == 40 and float(story.snapshot().week.revenue) == 600, "weekly feedback uses actual business counters")
	m.state.total_revenue = 1200
	m.state.served = 60
	m.state.total_minutes = 10 * 1440
	story.on_day()
	check(story.snapshot().monthly_reports.size() == 1, "monthly report one record")
	check(bool(story.snapshot().monthly_reports[0].eligible), "monthly award requires earned revenue")
	books = int(m.state.management.skill_books)
	check(story.perform("monthly_story_claim", {"month":1}).ok, "qualifying month skill book claim")
	check(int(m.state.management.skill_books) == books + 1, "monthly book actually credited")
	check(not story.perform("monthly_story_claim", {"month":1}).ok, "monthly claim idempotent")
	story = Story.new(m)
	story.ensure_state()
	story.on_day()
	check(story.snapshot().monthly_reports.size() == 1 and not story.perform("monthly_story_claim", {"month":1}).ok, "reload cannot regenerate monthly award")
	m.state.total_minutes = 60 * 1440
	story.on_day()
	check(not story.perform("monthly_story_claim", {"month":2}).ok, "no earned revenue no monthly award")
	check(story.validate_state(m.state.story, m.employees, int(m.state.total_minutes)), "calendar reports validate")
	m = fresh()
	m.state.total_revenue = 50000
	m.state.total_minutes = 60 * 1440 + 360
	m.state.erase("story")
	story = Story.new(m)
	story.ensure_state()
	story.on_day()
	check(story.snapshot().monthly_reports.is_empty(), "legacy save does not retroactively grant monthly awards")
	m.balance["story.defaults.festival_cash_cost"] = 12
	m.balance["story.defaults.festival_reputation"] = 2
	before_cash = float(m.state.cash)
	check(story.perform("seasonal_activity").ok, "developer configurable festival activity")
	check(float(m.state.cash) == before_cash - 12, "festival override controls real debit")
	check(m.full_rules.can_perform("festival_invitation").has("ok"), "full rules routes story can action")
	var cash = float(m.state.cash)
	check(not m.full_rules.perform("seasonal_activity").ok, "full rules routes persisted same day activity")
	check(float(m.state.cash) == cash, "failed integrated action has no debit")
	var save_path = "/tmp/shanhai-story-tests-%d.json" % get_instance_id()
	check(m.save_game(save_path), "integrated story saves to isolated tmp path")
	var copy = fresh()
	check(copy.load_game(save_path), "integrated story load strict validator")
	check(not copy.full_rules.perform("seasonal_activity").ok, "loaded story cannot reclaim calendar action")
	check(not copy.full_rules.snapshot().story.is_empty(), "full snapshot exposes real story")
	DirAccess.remove_absolute(save_path)
	call_deferred("_ui_test")

func _find_button(node: Node, id: String) -> Button:
	if node is Button and str(node.get_meta("qa_id", "")) == id and not node.is_queued_for_deletion(): return node
	for child in node.get_children():
		if child.is_queued_for_deletion(): continue
		var found = _find_button(child, id)
		if found != null: return found
	return null

func _ui_test() -> void:
	var ui = StoryHarness.new()
	root.add_child(ui)
	await process_frame
	ui.open_panel("主线故事")
	await process_frame
	check(ui.modal_body.get_child_count() > 4, "actual story modal renders chapters, collection and calendar")
	var button = _find_button(ui, "story:opening")
	check(button != null, "opening recap button exists")
	if button != null: button.pressed.emit()
	await process_frame
	check(ui.story_panel._show_opening, "opening button toggles actual recap")
	ui.model.state.debt = 0
	ui.open_panel("主线故事")
	await process_frame
	button = _find_button(ui, "story:story_claim:debt")
	check(button != null and not button.disabled, "actual debt reward UI enables from live evidence")
	var books = int(ui.model.state.management.skill_books)
	if button != null and not button.disabled: button.pressed.emit()
	await process_frame
	check("debt" in ui.model.state.story.claimed and int(ui.model.state.management.skill_books) == books + 1, "real UI action grants once through full rules")
	button = _find_button(ui, "story:dialogue:debt")
	check(button != null, "claimed story exposes dialogue review")
	ui.model.state.cash = 500
	ui.open_panel("主线故事")
	await process_frame
	button = _find_button(ui, "story:seasonal_activity:")
	check(button != null and not button.disabled, "actual seasonal button enables")
	var expenses = float(ui.model.state.ledger.expenses)
	if button != null and not button.disabled: button.pressed.emit()
	await process_frame
	check(float(ui.model.state.cash) == 420 and float(ui.model.state.ledger.expenses) == expenses + 80, "actual seasonal UI records one expense")
	ui.model.state.reputation = 500
	ui.open_panel("主线故事")
	await process_frame
	button = _find_button(ui, "story:festival_invitation:")
	check(button != null and not button.disabled, "actual festival application button enables")
	if button != null and not button.disabled: button.pressed.emit()
	await process_frame
	check(str(ui.panel_name) == "事件" and str(ui.model.full_rules.world.pending_event().id) == "food_festival", "festival UI opens original paid event")
	ui.queue_free()
	await process_frame
	print("STORY CHECKS: %d passed, %d failed" % [checks - failures, failures])
	quit(1 if failures else 0)
