extends SceneTree

const Model = preload("res://scripts/core/game_model.gd")
var passed = 0
var failed = 0


func _init() -> void:
	call_deferred("_run")


func check(condition: bool, message: String) -> void:
	if condition: passed += 1
	else:
		failed += 1
		push_error(message)


func fixture() -> Variant:
	var m = Model.new(1926)
	m.full_rules.start_full()
	m.state.cash = 10000.0
	m.state.gems = 100
	m.state.reputation = 1000
	m.state.stage = 4
	m.state.total_minutes = 10 * 1440 + 720
	m.employees.clear()
	for definition in m.catalog:
		var employee: Dictionary = m._create_employee(definition)
		employee.resting = false
		m.employees.append(employee)
	m.state.world.clear()
	m.full_rules.world.ensure_state()
	return m


func context_for(m: Variant, event: Dictionary) -> Dictionary:
	var trigger: Dictionary = event.trigger
	var context = {"spy_detected":true,"employee_id":str(trigger.get("employee_id", "")), "amount":50.0, "kind":"influencer", "promotion_kind":"influencer"}
	if str(trigger.get("category", "")) != "":
		for dish in m.dishes:
			if str(dish.category) == str(trigger.category): context.dish_id = str(dish.id); break
		context.category = str(trigger.category)
	if trigger.has("periods"): m.state.total_minutes = 10 * 1440 + 22 * 60
	if bool(trigger.get("stamina_zero", false)): m._employee(str(trigger.employee_id)).stamina = 0
	if trigger.has("mood_below"): m.employees[0].mood = 20; context.employee_id = str(m.employees[0].id)
	if trigger.has("min_overdue"): m.state.overdue_count = 3
	if trigger.has("minimum_streak"):context.streak=int(trigger.minimum_streak)
	if trigger.has("minimum_usage"):context.usage=int(trigger.minimum_usage)
	if trigger.has("minimum_parallel"):
		m.customers.assign([{"stage":"cooking","worker":str(trigger.employee_id)}, {"stage":"cooking","worker":str(trigger.employee_id)}])
	if trigger.has("actions"):
		var worker=m._employee(str(trigger.employee_id));worker.motion={"action":str(trigger.actions[0]),"started":int(m.state.total_minutes),"travel_minutes":0}
	return context


func _run() -> void:
	var base = fixture()
	var definitions: Array = base.events.duplicate(true)
	check(definitions.size() == 38, "30 original events,4 state events and a collection event exist")
	check(base.bonds.size() == 11, "all eleven bonds exist")
	var unique = {}
	for event in definitions:
		check(not unique.has(str(event.id)), "event IDs must be unique: " + str(event.id))
		unique[str(event.id)] = true
		var m = fixture()
		m.events = [event.duplicate(true)]
		var world = m.full_rules.world
		var context = context_for(m, event)
		var hook = str(event.trigger.hooks[0])
		check(world._eligible(event, hook, world._context_for(event, context)), "real trigger is reachable: " + str(event.id))
		check(not world._eligible(event, "unrelated_action", context), "wrong hook rejected: " + str(event.id))
		if event.has("probability_key"):m.balance[str(world.COEFFICIENT_ALIASES.get(str(event.probability_key), str(event.probability_key)))] = 1.0
		world.on_hook(hook, context)
		if hook == "complaint":
			check(not m.state.effect_resolution.pending_complaints.is_empty(), "complaint enters actual worker queue: " + str(event.id))
			for minute in 7:
				m.state.total_minutes += 1
				m.full_rules.effects.tick_minute()
		var appeared = not world.pending_event().is_empty() or not world.snapshot().history.is_empty()
		check(appeared, "action hook dispatches actual event: " + str(event.id))
		if event.trigger.has("employee_id") and hook in ["cooking", "serving", "cleaning", "paying", "promote", "research", "fatigue"]:
			var other = context.duplicate(true)
			other.employee_id = "not_the_actor"
			m.state.world.cooldowns.clear()
			m.state.world.queue.clear()
			check(not world._eligible(event, hook, other), "wrong employee cannot trigger action: " + str(event.id))
		for option in event.options:
			var choice_model = fixture()
			choice_model.events = [event.duplicate(true)]
			var choice_world = choice_model.full_rules.world
			var choice_context = context_for(choice_model, event)
			choice_world._enqueue(str(event.id), choice_context)
			if not bool(event.get("auto", false)):
				var result: Dictionary = choice_world.choose(str(option.id))
				check(bool(result.get("ok", false)), "event choice can execute: " + str(event.id) + "/" + str(option.id))
			check(not choice_world.snapshot().history.is_empty(), "resolved event is recorded: " + str(event.id))
			check(float(choice_model.state.cash) >= 0 and int(choice_model.state.gems) >= 0, "choice keeps resources nonnegative: " + str(event.id))
			check(choice_world.validate_state(choice_model.state.world, choice_model.employees, int(choice_model.state.total_minutes)), "event state can be saved: " + str(event.id) + "/" + str(option.id))
	_test_atomic_choices()
	_test_delayed_outcomes()
	_test_real_conditions()
	_test_bonds()
	_test_saved_state()
	_test_model_roundtrip()
	print("World event checks passed: %d, failed: %d" % [passed, failed])
	quit(0 if failed == 0 else 1)


func _test_atomic_choices() -> void:
	var m = fixture()
	var world = m.full_rules.world
	world._enqueue("bifang_fire", {"employee_id":"bi_fang", "dish_id":"bifang_wings"})
	m.state.cash = 99.0
	var before = m.state.world.duplicate(true)
	check(not world.choose("repair").ok, "unaffordable repair rejected")
	check(float(m.state.cash) == 99 and m.state.world == before, "rejected repair has no partial charge or queue mutation")
	check(world.choose("continue").ok, "free alternative remains possible")
	check(not world.choose("continue").ok, "choice cannot be claimed twice")
	m = fixture()
	world = m.full_rules.world
	world._enqueue("bifang_fire", {"employee_id":"bi_fang", "dish_id":"bifang_wings"})
	check(world.choose("repair").ok, "affordable repair executes")
	check(int(m._employee("bi_fang").leave_until) == int(m.state.total_minutes) + 1440 and int(m.state.kitchen_pause_until) <= int(m.state.total_minutes), "v1.5 repair rests Bifang without closing all other cooking")
	var stock = float(m.full_rules.management.item("generic").quantity)
	var quote: Dictionary = world._supplier_quote(true)
	var cash = float(m.state.cash)
	world._enqueue("supplier_discount")
	world.choose("discount")
	check(is_equal_approx(float(m.state.cash), cash - float(quote.cost)) and is_equal_approx(float(m.full_rules.management.item("generic").quantity), stock + float(quote.quantity)), "v1.5 bulk choice actually buys three batches at 20 percent off")
	world._enqueue("dangkang_harvest", {"employee_id":"dang_kang"})
	if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
	check(is_equal_approx(world.procurement_multiplier("ordinary"), 0.8), "same-kind discounts do not stack")
	check(is_equal_approx(world.procurement_multiplier("rare"), 0.8), "harvest applies to all ingredient types")


func _test_delayed_outcomes() -> void:
	var m = fixture()
	var world = m.full_rules.world
	world._enqueue("false_ad", {"employee_id":"e_shou"})
	var reputation = int(m.state.reputation)
	world.choose("conceal")
	check(int(m.state.reputation) == reputation + 20, "conceal has immediate result")
	check(m.state.world.delayed.size() == 1, "conceal schedules persistent three-day consequence")
	var delayed: Dictionary = m.state.world.delayed[0]
	check(int(delayed.due) == int(m.state.total_minutes) + 4320, "conceal due time is three game days")
	delayed.probability = 1.0
	m.state.total_minutes = int(delayed.due)
	world.tick_minute()
	check(int(m.state.reputation) == reputation - 10, "delayed reputation loss actually executes")
	check(m.state.world.delayed.is_empty(), "delayed consequence executes once")
	m = fixture()
	world = m.full_rules.world
	var cash = float(m.state.cash)
	var sales = float(m.state.total_revenue)
	m.state.daily_revenue = 50.0 # the checkout hook follows revenue recognition
	world._enqueue("pixiu_withholds", {"employee_id":"pi_xiu", "amount":50.0})
	if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
	check(is_equal_approx(float(m.state.cash), cash - 50), "withheld checkout moves cash to receivables")
	check(is_equal_approx(float(m.state.world.outstanding_receipts), 50), "receivable principal is tracked")
	check(float(m.state.total_revenue) == sales, "withheld event does not create another sale")
	m.state.total_minutes = (int(floor(float(m.state.total_minutes) / 1440)) + 1) * 1440
	world.tick_minute()
	check(is_equal_approx(float(m.state.cash), cash + 2.5), "withheld receipt returns principal and five percent")
	check(is_zero_approx(float(m.state.world.outstanding_receipts)), "receivable clears after receipt")
	check(float(m.state.total_revenue) == sales, "returning receivable does not double-count revenue")


func _test_real_conditions() -> void:
	var m = fixture()
	var world = m.full_rules.world
	var fire: Dictionary = world._definition("bifang_fire")
	check(not world._eligible(fire, "cooking", {"employee_id":"bi_fang","category":"汤品"}), "Bifang soup cannot trigger barbecue fire")
	m._employee("bi_fang").resting = true
	check(not world._eligible(fire, "cooking", {"employee_id":"bi_fang","category":"烧烤"}), "resting Bifang cannot trigger cooking fire")
	m._employee("bi_fang").resting = false
	m.state.total_minutes = 10 * 1440 + 10 * 60
	check(not world._eligible(fire, "cooking", {"employee_id":"bi_fang","category":"烧烤"}), "rest hour suppresses business-only event")
	m.state.total_minutes = 10 * 1440 + 12 * 60
	m._employee("feng_huang").stamina = 0
	world.on_hook("fatigue", {"employee_id":"feng_huang"})
	if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
	check(float(m._employee("feng_huang").stamina) == 100, "Phoenix revives on actual fatigue hook")
	m._employee("feng_huang").stamina = 0
	world.on_hook("fatigue", {"employee_id":"feng_huang"})
	if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
	check(float(m._employee("feng_huang").stamina) == 0, "Phoenix cannot revive twice in one game day")
	var shift: Dictionary = world.perform("zhulong_shift", {"period":"dinner"})
	check(shift.ok, "active Zhulong can select a business traffic period")
	check(not world.perform("zhulong_shift", {"period":"breakfast"}).ok, "Zhulong limited to one shift per day")
	m.state.total_minutes = 10 * 1440 + 10 * 60
	check(is_equal_approx(world.modifier("traffic"), 1.0), "Zhulong never opens rest hour")


func _test_bonds() -> void:
	var m = fixture()
	var world = m.full_rules.world
	check(world.active_bonds().size() == 11, "all eleven qualified bonds activate")
	check(world.modifier("price", "主食") > 1, "flame charm changes real prices")
	check(world.modifier("price", "烧烤") > world.modifier("price", "主食"), "fierce bond only adds eligible category price")
	check(world.modifier("quality", "水产") > world.modifier("quality", "主食"), "aquatic bond only adds seafood quality")
	check(is_equal_approx(world.probability_bonus("research_success"), 0.3), "faceless bond adds the documented research probability")
	check(is_equal_approx(world.modifier("waiter_speed"), 1.2) and world.modifier("cleaning_speed") > 1, "diligent wings boosts all waiter work and separately boosts cleaning")
	for task in ["ordering", "serving", "cleaning", "paying"]:
		var active_speed: float = m.full_rules.speed_multiplier(m._employee("jing_wei"), task)
		m._employee("ying_zhao").resting = true
		var solo_speed: float = m.full_rules.speed_multiplier(m._employee("jing_wei"), task)
		m._employee("ying_zhao").resting = false
		var expected := 1.3 if task == "cleaning" else 1.2
		check(is_equal_approx(active_speed / solo_speed, expected), "diligent wings changes actual " + task + " duration")
	for task in ["ordering", "cooking", "serving", "paying", "cleaning"]:
		check(m.full_rules.effects.ignores_obstacles(m._employee("xian_yang"), {}, task) == (task == "serving"), "faceless bond ignores obstacles only for actual serving: " + task)
		check(m.full_rules.effects.ignores_obstacles(m._employee("di_jiang"), {}, task) == (task == "serving"), "Dijiang personal skill ignores obstacles only while serving: " + task)
	var count = world.active_bonds().size()
	m._employee("bi_fang").resting = true
	check(world.active_bonds().size() == count - 2, "resting participant disables both affected bonds")
	m._employee("bi_fang").resting = false
	m._employee("bi_fang").training_until = int(m.state.total_minutes) + 30
	check(world.active_bonds().size() == count - 2, "training participant does not count as on duty")
	m.state.stage = 1
	check(world.active_bonds().is_empty(), "full-mode bonds unlock at stage two")


func _test_saved_state() -> void:
	var m = fixture()
	var world = m.full_rules.world
	world._enqueue("supplier_discount")
	world._enqueue("hygiene")
	check(world.pending_event().id == "supplier_discount" and world.snapshot().queue_count == 2, "queue exposes only one pending event")
	check(world.validate_state(m.state.world, m.employees, int(m.state.total_minutes)), "normal queue validates")
	var bad = m.state.world.duplicate(true)
	bad.queue[0].id = "invented_event"
	check(not world.validate_state(bad, m.employees, int(m.state.total_minutes)), "unknown event rejected in save")
	bad = m.state.world.duplicate(true)
	bad.cooldowns.supplier_discount = -1
	check(not world.validate_state(bad, m.employees, int(m.state.total_minutes)), "negative cooldown rejected")
	bad = m.state.world.duplicate(true)
	bad.delayed.append({"due": -1, "effects":[], "context":{}, "probability":1})
	check(not world.validate_state(bad, m.employees, int(m.state.total_minutes)), "negative delayed time rejected")
	bad = m.state.world.duplicate(true)
	bad.delayed.append({"due": int(m.state.total_minutes) + 1, "effects":[{"type":"arbitrary_script"}], "context":{}, "probability":1})
	check(not world.validate_state(bad, m.employees, int(m.state.total_minutes)), "save cannot introduce arbitrary effect types")
	var before = m.state.world.duplicate(true)
	world.validate_state(bad, m.employees, int(m.state.total_minutes))
	check(m.state.world == before, "validation never mutates live state")


func _test_model_roundtrip() -> void:
	var m = Model.new(3434)
	m.start_full()
	m.state.cash = 1000.0
	var world = m.full_rules.world
	world._enqueue("dangkang_harvest", {"employee_id":"dang_kang"})
	if not world.pending_event().is_empty() and str(world.pending_event().get("type",""))=="notice":world.choose(str(world.pending_event().options[0].id))
	world._enqueue("false_ad", {"employee_id":"e_shou"})
	world.choose("conceal")
	world._enqueue("hygiene")
	var path = "user://world-event-roundtrip.json"
	check(m.save_game(path), "model saves actual queued, delayed and modifier state")
	var loaded = Model.new(9797)
	check(loaded.load_game(path), "fresh model loads actual event state")
	check(JSON.stringify(JSON.parse_string(JSON.stringify(loaded.state.world))) == JSON.stringify(JSON.parse_string(JSON.stringify(m.state.world))), "event queue, history, delay, discounts and seen records survive JSON roundtrip")
	check(loaded.pending_event().id == "hygiene", "loaded UI exposes same pending event")
	check(is_equal_approx(loaded.full_rules.world.procurement_multiplier("ordinary"), 0.8), "loaded discount retains actual effect")
	check(loaded.state.world.delayed.size() == 1, "delayed legal/reputation consequence remains scheduled after load")
