extends SceneTree

const Model = preload("res://scripts/core/game_model.gd")
const Preferences = preload("res://scripts/core/customer_preferences.gd")
var checks: int = 0
var failures: Array[String] = []

func check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures.append(label)
		printerr("FAIL: ", label)

func near(a: float, b: float) -> bool: return absf(a-b) < 0.00001

func fresh(seed_value: int = 13401):
	var m = Model.new(seed_value)
	m.start_full()
	m.events.clear()
	m.state.cash = 10000.0
	return m

func _init() -> void: call_deferred("run")

func run() -> void:
	profile_tests()
	choice_tests()
	actual_customer_tests()
	balance_tests()
	if failures.is_empty():
		print("customer_preference_tests: %d checks passed" % checks)
		quit(0)
	else:
		printerr("customer_preference_tests: %d failures / %d checks" % [failures.size(), checks])
		quit(1)

func profile_tests() -> void:
	var m = fresh()
	var service = Preferences.new(m)
	var cohorts: Dictionary = {}
	var all_valid: bool = true
	for index in range(2400):
		var profile: Dictionary = service.generate_profile()
		all_valid = all_valid and service.validate_profile(profile)
		var cohort: String = str(profile.age_group) + "/" + str(profile.gender)
		if not cohorts.has(cohort): cohorts[cohort] = {}
		cohorts[cohort][str(profile.tastes[0])] = true
	check(all_valid, "all sampled guest profiles have explicit valid age, gender, personal taste and meal need")
	check(cohorts.size() == 9, "independent demographic rolls represent all configured age/gender combinations")
	for cohort in cohorts:
		check(cohorts[cohort].size() >= 4, cohort + " retains diverse individual tastes")
	var original: Dictionary = service.generate_profile()
	var damaged: Dictionary = original.duplicate(true)
	damaged.age = -1
	check(not service.validate_profile(damaged), "invalid saved age is rejected")
	damaged = original.duplicate(true); damaged.tastes = ["unknown"]
	check(not service.validate_profile(damaged), "unknown saved taste is rejected")
	damaged = original.duplicate(true); damaged.needs = ["light_meal", "light_meal"]
	check(not service.validate_profile(damaged), "duplicate meal needs are rejected")
	check(not service.describe_profile(original).is_empty(), "guest needs have readable labels for service feedback")

func choice_tests() -> void:
	var m = fresh(13402)
	var service = Preferences.new(m)
	var wings: Dictionary = m._dish("bifang_wings")
	var milk: Dictionary = m._dish("fox_milk")
	var light: Dictionary = m._dish("zhuyu_salad")
	var profile: Dictionary = {"age_group":"adult", "age":35, "gender":"unspecified", "tastes":["homestyle"], "needs":["ordinary"]}
	var young: Dictionary = profile.duplicate(true); young.age_group = "young"; young.age = 22
	check(near(service.dish_weight(wings, young), service.dish_weight(wings, profile) * 1.25), "young wings preference is a configurable soft probability multiplier")
	check(near(service.dish_weight(milk, young), service.dish_weight(milk, profile)), "age does not mechanically assign unrelated tastes")
	var female: Dictionary = profile.duplicate(true); female.gender = "female"
	check(near(service.dish_weight(milk, female), service.dish_weight(milk, profile) * 1.2), "female milk preference is a small soft multiplier")
	var sweet: Dictionary = profile.duplicate(true); sweet.gender = "male"; sweet.tastes = ["sweet_drink"]
	check(service.dish_weight(milk, sweet) > service.dish_weight(milk, female), "individual sweet taste outweighs demographic tendency")
	var healthy: Dictionary = profile.duplicate(true); healthy.needs = ["health_focus"]
	var dieting: Dictionary = profile.duplicate(true); dieting.needs = ["light_meal"]
	check(service.dish_weight(light, healthy) > service.dish_weight(light, profile), "independent vegetable meal need increases matching salad choice")
	check(service.dish_weight(light, dieting) > service.dish_weight(light, profile), "light-meal need increases Zhuyu choice before food is chosen")
	check(service.dish_weight(m._dish("yingzhao_salad"), healthy) > service.dish_weight(m._dish("yingzhao_salad"), profile), "Yingzhao salad matches a genuine preexisting guest need")
	var all_selectable: bool = true
	for guest in [profile, young, female, sweet, healthy, dieting]:
		for dish in m.dishes: all_selectable = all_selectable and service.dish_weight(dish, guest) > 0
	check(all_selectable, "all menu dishes remain choices for every demographic and preference profile")
	check("个人口味" in " ".join(service.explain(milk, sweet)), "choice explains the guest's own taste")
	check("轻微概率倾向" in " ".join(service.explain(milk, female)), "demographic explanation explicitly describes a limited probability tendency")
	m.balance["guests.demographic_tendencies.young_wings.bonus"] = 0
	check(near(service.dish_weight(wings, young), service.dish_weight(wings, profile)), "demographic tendencies can be disabled without disabling the dish")
	m.balance["guests.choice.need_match_bonus"] = 4
	check(near(service.dish_weight(light, healthy), 5), "global guest choice coefficients override configuration at runtime")

func balance_tests() -> void:
	var m = fresh(13403)
	var service = Preferences.new(m)
	check(service.validate_balance(service.balance_defaults()), "complete guest defaults validate")
	for candidate in [{"guests.choice.base_weight":0}, {"guests.tastes.roasted.weight":-1}, {"guests.ages.young.maximum":17}, {"guests.ages.young.minimum":18.5}, {"guests.demographic_tendencies.female_milk.bonus":0.6}, {"guests.unknown.knob":1}]:
		check(not service.validate_balance(candidate), "invalid guest balance edit is rejected: " + str(candidate))
	var no_tastes: Dictionary = {}
	for taste in service.config.tastes: no_tastes["guests.tastes.%s.weight" % str(taste.id)] = 0
	check(not service.validate_balance(no_tastes), "zero total taste distribution is rejected")
	check(service.validate_balance({"guests.demographic_tendencies.female_milk.bonus":0}), "setting a demographic tendency to zero is supported")

func actual_customer_tests() -> void:
	var m = fresh(13404)
	var service = m.full_rules.preferences
	var salesperson: Dictionary = m._create_employee(m._employee_config("guan_guan"))
	m.employees.append(salesperson)
	# This statistical fixture fixes acceptance so it measures preferences within
	# the real recommendation pool. Scheduled travel/cooldown/payment are covered
	# separately by v15_customer_tests; arrivals themselves no longer pick dishes.
	m.balance["coeff.recommend_base_chance"] = 1
	m.balance["recommend.max_chance"] = 1
	for dish_id in ["bifang_wings", "fox_milk", "zhuyu_salad"]:
		if not dish_id in m.state.unlocked_dishes: m.state.unlocked_dishes.append(dish_id)
	m.state.menu_enabled = ["bifang_wings", "fox_milk", "zhuyu_salad"]
	for id in ["danmu", "pincao", "zhuyu"]: m.full_rules.management.add_item(id, 100)
	# Force independently chosen personal preferences through the public knobs,
	# then sample actual recommendation completion, not a copy of its algorithm.
	for section in ["ages", "genders", "tastes", "needs"]:
		for entry in service.config[section]: m.balance["guests.%s.%s.weight" % [section, entry.id]] = 0
	m.balance["guests.ages.adult.weight"] = 1
	m.balance["guests.genders.unspecified.weight"] = 1
	m.balance["guests.needs.ordinary.weight"] = 1
	var all_profiles_valid: bool = true
	for taste in ["roasted", "sweet_drink", "fresh_light"]:
		for entry in service.config.tastes: m.balance["guests.tastes.%s.weight" % entry.id] = 1 if str(entry.id) == taste else 0
		var selected: Dictionary = {"bifang_wings":0, "fox_milk":0, "zhuyu_salad":0}
		for index in range(600):
			m.customers.clear()
			m._spawn_customer("", false)
			if m.customers.is_empty():
				all_profiles_valid = false
				continue
			var guest: Dictionary = m.customers[0]
			all_profiles_valid = all_profiles_valid and service.validate_profile(guest.get("preference_profile")) and guest.preference_profile.tastes == [taste]
			if guest.has("visitor_id"):continue # Named guests have a specified order, independent of ordinary recommendation.
			var choice=m.full_rules.customer_service.choose_default_dish(guest)
			if not choice.is_empty():m.full_rules.customer_service.apply_choice(guest,choice)
			var recommendation: Dictionary={"success":not choice.is_empty()}
			all_profiles_valid = all_profiles_valid and bool(recommendation.get("success", false)) and selected.has(str(guest.dish_id))
			if selected.has(str(guest.dish_id)): selected[str(guest.dish_id)] += 1
		var expected: String = {"roasted":"bifang_wings", "sweet_drink":"fox_milk", "fresh_light":"zhuyu_salad"}[taste]
		check(int(selected[expected]) > 300, "real directly ordering guests with " + taste + " prefer their matching menu dish")
		check(selected.values().all(func(count): return int(count) > 0), "real " + taste + " guests still choose all available menu alternatives")
	check(all_profiles_valid, "real spawn retains independent personal preferences before actual preference-weighted ordering")
	var guest: Dictionary = m.customers[0]
	check(not guest.get("preference_reasons", []).is_empty(), "real customer retains an explainable reason for its selected dish")
	# A fresh model avoids persisting deliberate test-only direct balance edits.
	m = fresh(13405)
	m._spawn_customer("", false)
	guest = m.customers[0]
	var saved_profile: Dictionary = guest.preference_profile.duplicate(true)
	var path: String = "user://guest-preferences-roundtrip.json"
	check(m.save_game(path), "actual arriving customer's preference profile saves")
	var copy = Model.new(13406)
	check(copy.load_game(path), "actual guest profile passes strict save validation on reload")
	check(copy.customers.size() == 1 and copy.customers[0].preference_profile == JSON.parse_string(JSON.stringify(saved_profile)), "reload preserves individual preferences without rerolling")
