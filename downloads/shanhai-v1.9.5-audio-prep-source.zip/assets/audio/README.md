正式内置音频目录。当前未加入正式声音。接入方法见 docs/audio-pipeline.md，35个槽位见 config/audio.json。
