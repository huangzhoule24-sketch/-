extends SceneTree
## Deterministic game import: slices generated masters, normalizes anchors and bakes a bounded pixel rig.
const ROOT="res://assets/art/"
const ACTIONS=["walk","idle","order","cook","serve","clean","cashier","promote","rest","build"]
const DIRS=["down","up","left","right"]
const FLY=["xiao","guan_guan","gu_diao","qing_fu","bi_fang","ying_zhao","jing_wei","qiong_qi","qing_geng","feng_huang","ying_long","di_jiang"]
const CRAWL=["xuan_gui","zhu_long","ran_yi_yu"]
var inputs: Dictionary
var atlas_index: Dictionary={}
var catalog: Dictionary={"version":1,"frame_size":[64,80],"foot_anchor":[32,77],"seated_hip":[32,58],"walk_body_max":1,"foot_lift_max":2,"employees":[],"awakened":[],"guests":[],"assets":[]}
func _init():call_deferred("run")
func save(image: Image,path: String):
	DirAccess.make_dir_recursive_absolute((ROOT+path).get_base_dir());assert(image.save_png(ROOT+path)==OK);
	if not path in catalog.assets:catalog.assets.append(path)
func cell(path: String,cols: int,rows: int,x: int,y: int) -> Image:
	var source=Image.load_from_file(path);assert(source!=null,"Missing generated master "+path)
	var left=roundi(float(x)*source.get_width()/cols);var top=roundi(float(y)*source.get_height()/rows)
	return source.get_region(Rect2i(left,top,roundi(float(x+1)*source.get_width()/cols)-left,roundi(float(y+1)*source.get_height()/rows)-top))
func threshold(image: Image,alpha: float=.97):
	image.convert(Image.FORMAT_RGBA8)
	for y in range(image.get_height()):
		for x in range(image.get_width()):
			var c=image.get_pixel(x,y)
			if c.a<alpha:image.set_pixel(x,y,Color.TRANSPARENT)
			else:image.set_pixel(x,y,Color(roundf(c.r*31)/31,roundf(c.g*31)/31,roundf(c.b*31)/31,1))
func trimmed(image: Image,pixel: bool=true) -> Image:
	if pixel:threshold(image)
	var used=image.get_used_rect()
	return image.get_region(used) if used.has_area() else image
func character_foreground(image: Image) -> Image:
	threshold(image,.985)
	var w=image.get_width();var h=image.get_height();var visited=PackedByteArray();visited.resize(w*h)
	var best=PackedInt32Array();var best_score=-1.0
	for y in range(h):
		for x in range(w):
			var start=y*w+x
			if visited[start]==1 or image.get_pixel(x,y).a<.5:continue
			var queue=PackedInt32Array([start]);visited[start]=1;var cursor=0;var sum_x=0.0
			while cursor<queue.size():
				var n=queue[cursor];cursor+=1;sum_x+=n%w
				for adjacent in [n-1,n+1,n-w,n+w]:
					if adjacent<0 or adjacent>=w*h or visited[adjacent]==1 or absi(adjacent%w-n%w)>1:continue
					if image.get_pixel(adjacent%w,adjacent/w).a<.5:continue
					visited[adjacent]=1;queue.append(adjacent)
			var distance=absf(sum_x/maxi(1,queue.size())-w*.5)/w
			var score=queue.size()/(1+4*distance)
			if score>best_score:best_score=score;best=queue
	var clean=Image.create(w,h,false,Image.FORMAT_RGBA8);clean.fill(Color.TRANSPARENT)
	for n in best:clean.set_pixel(n%w,n/w,image.get_pixel(n%w,n/w))
	var rect=clean.get_used_rect();return clean.get_region(rect) if rect.has_area() else image
func foot_x(image: Image) -> float:
	var sum=0.0;var weight=0
	for y in range(maxi(0,image.get_height()-6),image.get_height()):
		for x in range(image.get_width()):
			if image.get_pixel(x,y).a>.5:sum+=x;weight+=1
	return sum/maxi(1,weight)
func prepare_bases(raw: Dictionary) -> Dictionary:
	var clean: Dictionary={};var common_height=72.0
	for direction in DIRS:
		var image=character_foreground(raw[direction]);clean[direction]=image
		var pivot=foot_x(image)
		common_height=minf(common_height,28.0*image.get_height()/maxf(pivot,image.get_width()-pivot))
	var result: Dictionary={}
	for direction in DIRS:
		var image: Image=clean[direction];var pivot=foot_x(image);var scale=common_height/image.get_height()
		image.resize(maxi(1,roundi(image.get_width()*scale)),maxi(1,roundi(common_height)),Image.INTERPOLATE_NEAREST)
		var frame=Image.create(64,80,false,Image.FORMAT_RGBA8);frame.fill(Color.TRANSPARENT)
		frame.blit_rect(image,Rect2i(Vector2i.ZERO,image.get_size()),Vector2i(32-roundi(pivot*scale),78-image.get_height()))
		result[direction]=frame
	return result
func fitted(image: Image,extent: Vector2i,ground: int=-1) -> Image:
	image=character_foreground(image) if ground>=0 else trimmed(image);var scale=minf(float(extent.x-8)/image.get_width(),float(extent.y-8)/image.get_height())
	image.resize(maxi(1,roundi(image.get_width()*scale)),maxi(1,roundi(image.get_height()*scale)),Image.INTERPOLATE_NEAREST)
	var result=Image.create(extent.x,extent.y,false,Image.FORMAT_RGBA8);result.fill(Color.TRANSPARENT)
	var point=Vector2i((extent.x-image.get_width())/2,(extent.y-image.get_height())/2 if ground<0 else ground-image.get_height()+1)
	result.blit_rect(image,Rect2i(Vector2i.ZERO,image.get_size()),point);return result
func icon(image: Image,path: String,size: int=64):save(fitted(image,Vector2i(size,size)),path)
func rectangle(image: Image,rect: Rect2i,color: Color):image.fill_rect(rect.intersection(Rect2i(Vector2i.ZERO,image.get_size())),color)
func stroke(image: Image,a: Vector2i,b: Vector2i,color: Color,width: int=1):
	var count=maxi(absi(b.x-a.x),absi(b.y-a.y))
	for i in range(count+1):
		var p=Vector2(a).lerp(Vector2(b),float(i)/maxi(1,count));rectangle(image,Rect2i(roundi(p.x),roundi(p.y),width,width),color)
func rig(base: Image,action: String,frame: int,gait: String,direction: String) -> Image:
	var out=base.duplicate();var wave=[0,1,2,1,0,0,0,0];var bob=[0,0,0,1,1,0,0,0]
	if action=="walk":
		if gait=="fly":
			out.fill(Color.TRANSPARENT);out.blit_rect(base,Rect2i(0,0,64,80),Vector2i(0,-bob[frame]))
			# Wing-tip deformation is local; ground motion remains authoritative.
			for side in [0,48]:
				out.fill_rect(Rect2i(side,24,16,36),Color.TRANSPARENT);out.blit_rect(base,Rect2i(side,24,16,36),Vector2i(side,24-bob[(frame+2)%8]))
		elif gait=="crawl":
			out.fill_rect(Rect2i(0,61,64,19),Color.TRANSPARENT);out.blit_rect(base,Rect2i(0,61,64,19),Vector2i(bob[frame],61))
		else:
			out.fill_rect(Rect2i(0,64,64,16),Color.TRANSPARENT)
			out.blit_rect(base,Rect2i(0,64,32,16),Vector2i(0,64-wave[frame]))
			out.blit_rect(base,Rect2i(32,64,32,16),Vector2i(32,64-wave[(frame+4)%8]))
			# x is invariant for both feet: they can never cross.
			if bob[frame]==1:
				out.fill_rect(Rect2i(0,0,64,43),Color.TRANSPARENT);out.blit_rect(base,Rect2i(0,0,64,43),Vector2i(0,-1))
	elif action in ["sit","eat"]:
		out.fill_rect(Rect2i(0,60,64,20),Color.TRANSPARENT)
		var legs=base.get_region(Rect2i(16,60,32,18));legs.resize(32,10,Image.INTERPOLATE_NEAREST);out.blit_rect(legs,Rect2i(0,0,32,10),Vector2i(16,60))
	elif action=="rest":
		out.fill_rect(Rect2i(0,65,64,15),Color.TRANSPARENT)
		var legs=base.get_region(Rect2i(10,65,44,13));legs.resize(44,9,Image.INTERPOLATE_NEAREST);out.blit_rect(legs,Rect2i(0,0,44,9),Vector2i(10,65))
	elif action=="idle":
		if bob[frame]==1:
			out.fill_rect(Rect2i(0,42,64,20),Color.TRANSPARENT);out.blit_rect(base,Rect2i(0,42,64,20),Vector2i(0,41))
	# Hands/props are small handheld objects only. Equipment exists exclusively in the map layer.
	var ink=Color("263e43");var gold=Color("d8b36a");var skin=Color("e8bc91");var t=bob[frame]
	if action in ["order","cook","serve","clean","cashier","promote","eat","build"]:
		var prop=Image.create(64,80,false,Image.FORMAT_RGBA8);prop.fill(Color.TRANSPARENT)
		var hand=Vector2i(43,51-t)
		rectangle(prop,Rect2i(hand,Vector2i(3,3)),skin)
		match action:
			"build":stroke(prop,hand,Vector2i(49,43-t),ink);rectangle(prop,Rect2i(46,40-t,8,3),Color("8b9c99"))
			"cook":stroke(prop,hand,Vector2i(50,43-t),ink);rectangle(prop,Rect2i(48,40-t,5,3),Color("aab7b4"))
			"serve":rectangle(prop,Rect2i(38,52,19,2),gold);rectangle(prop,Rect2i(43,48,9,4),Color("e8dfc3"))
			"clean":rectangle(prop,Rect2i(43+t,53,9,3),Color("7caeaa"))
			"cashier":rectangle(prop,Rect2i(43,48-t,8,5),gold) # receipt, never a register
			"promote":rectangle(prop,Rect2i(44,45-t,8,10),Color("f1e9d0"));rectangle(prop,Rect2i(46,47-t,4,2),Color("af6a50"))
			"order":rectangle(prop,Rect2i(43,47,9,11),Color("ecdfb5"));stroke(prop,Vector2i(44,51),Vector2i(49+t,48),ink)
			"eat":stroke(prop,Vector2i(40,52),Vector2i(35,42-wave[frame]),gold)
		if direction=="left":prop.flip_x()
		out.blend_rect(prop,Rect2i(0,0,64,80),Vector2i.ZERO)
	return out
func bake(id: String,bases: Dictionary,actions: Array,gait: String,guest: bool=false,kind: String=""):
	var total=actions.size()*4*8;var atlas=Image.create(1024,ceili(float(total)/16)*80,false,Image.FORMAT_RGBA8);atlas.fill(Color.TRANSPARENT)
	var index=0
	for action in actions:
		for direction in DIRS:
			var prefix="Sprites/"+id+"/"+action+"_"+direction
			if guest:
				prefix="Sprites/customer/"+(id if kind=="special" else kind+"/"+id)+"/"+id+"_"+action+"_"+direction
			atlas_index[prefix]={"texture":"Sprites/"+id+"/atlas","start":index,"count":8,"columns":16,"width":64,"height":80}
			for frame in range(8):
				var image=rig(bases[direction],action,frame,gait,direction)
				atlas.blit_rect(image,Rect2i(0,0,64,80),Vector2i((index%16)*64,(index/16)*80));index+=1
	save(atlas,"Sprites/"+id+"/atlas.png")
func run():
	inputs=JSON.parse_string(FileAccess.get_file_as_string("res://art-source/generation-inputs.json"))
	var employees=JSON.parse_string(FileAccess.get_file_as_string("res://config/employees.json"))
	for i in range(employees.size()):
		var employee=employees[i];var group=i/6;var column=i%6;var id=str(employee.id)
		var portrait=cell(inputs.portraits[group],3,2,column%3,column/3)
		# Portraits retain watercolor translucency and high resolution.
		save(portrait,"Portraits/"+id+".png")
		var bases: Dictionary={};var batch=i/3;var row=i%3
		for direction in range(4):bases[DIRS[direction]]=cell(inputs.rig_models[batch],4,3,direction,row)
		bases=prepare_bases(bases)
		var gait="fly" if id in FLY else "crawl" if id in CRAWL else "walk"
		bake(id,bases,ACTIONS,gait)
		catalog.employees.append({"id":id,"anchor":inputs.anchors[i],"gait":gait,"frames":320})
		var quests=JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"))
		for quest in quests.quests:
			if str(quest.employee_id)!=id or not quest.get("reward",{}).has("appearance"):continue
			var appearance=preload("res://scripts/services/employee_identity.gd").canonical(str(quest.reward.appearance))
			var awakened_bases: Dictionary={}
			for direction in DIRS:
				var body=bases[direction];var glow=body.duplicate()
				for y in range(1,79):
					for x in range(1,63):
						if body.get_pixel(x,y).a>.5:continue
						if body.get_pixel(x-1,y).a>.5 or body.get_pixel(x+1,y).a>.5 or body.get_pixel(x,y-1).a>.5 or body.get_pixel(x,y+1).a>.5:glow.set_pixel(x,y,Color("c9a74f"))
				awakened_bases[direction]=glow
			bake(appearance,awakened_bases,ACTIONS,gait);catalog.awakened.append({"id":appearance,"base":id,"frames":320})
		save(bases.down,"Characters/"+id+"_idle.png")
		var head=bases.down.get_region(Rect2i(8,3,48,42));save(head,"Characters/"+id+"_lore.png")
		print("Baked ",id)
	var guest_ids=["human_01","human_02","human_03","demon_01","demon_02","demon_03","beastkin_01","beastkin_02","beastkin_03","lao_tao","bai_ze_gu_ren","xiao_shen_shou","tiao_ti_mei_shi_jia","bao_en_yao_guai","mi_tan"]
	for i in range(15):
		var id=guest_ids[i];var bases: Dictionary={}
		bases.down=cell(inputs.customers,5,3,i%5,i/5)
		bases.up=cell(inputs.customer_up,5,3,i%5,i/5)
		bases.right=cell(inputs.customer_right,5,3,i%5,i/5)
		bases.left=bases.right.duplicate();bases.left.flip_x()
		bases=prepare_bases(bases)
		var kind="human" if i<3 else "demon" if i<6 else "beastkin" if i<9 else "special"
		var gait="fly" if id=="beastkin_03" else "walk"
		bake(id,bases,["walk","idle","sit","eat"],gait,true,kind)
		if i>=9:save(bases.down,"Portraits/"+id+".png")
		catalog.guests.append({"id":id,"kind":kind,"gait":gait,"frames":128})
	var map_names=["equip_table_two","equip_table_four","chair","equip_stove","equip_cashier","equip_serving_counter","decor_staff_corner","decor_promotion_board","decor_lantern","decor_wall_mural","decor_plant","decor_sign","floor_wood","floor_yard","wall_shop","floor_street"]
	for i in range(16):
		var image=cell(inputs.environment,4,4,i%4,i/4)
		if i>=12:
			image=trimmed(image);var inset=Vector2i(image.get_width()/12,image.get_height()/12);image=image.get_region(Rect2i(inset,image.get_size()-inset*2));image.resize(64,64,Image.INTERPOLATE_NEAREST);threshold(image,.1);save(image,"Map/"+map_names[i]+".png")
		else:icon(image,"Map/"+map_names[i]+".png",96)
	for pair in [["equip_basic_cashier","equip_cashier"],["equip_basic_pass","equip_serving_counter"],["equip_kitchen","equip_stove"]]:save(Image.load_from_file(ROOT+"Map/"+pair[1]+".png"),"Map/"+pair[0]+".png")
	var dishes=JSON.parse_string(FileAccess.get_file_as_string("res://config/dishes.json"))
	var item_names=[]
	for dish in dishes:item_names.append("dish_"+str(dish.id))
	var management=JSON.parse_string(FileAccess.get_file_as_string("res://config/management.json"));item_names.append("dish_"+str(management.hidden_recipe.id))
	var side=JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"));item_names.append("dish_"+str(side.hidden_recipes[0].id))
	item_names.append_array(["item_skill_book","item_generic","item_tea","item_spice","item_fruit","item_rice","item_qingqiu_milk","item_yushan_water","item_danshu_rice","item_spirit_herb","pickup_cash"])
	for i in range(36):
		icon(cell(inputs.items,6,6,i%6,i/6),"Items/"+str(item_names[i])+".png")
		if i<25:save(Image.load_from_file(ROOT+"Items/"+str(item_names[i])+".png"),"Dishes/"+str(item_names[i]).trim_prefix("dish_")+"_lore.png")
	var ui_names=["panel","button_primary","button_secondary","button_warning","frame_portrait","icon_money","icon_spirit","icon_reputation","logo","thought_bubble","icon_clock","star","check","arrow","tooltip","topbar"]
	for i in range(16):
		var image=trimmed(cell(inputs.ui,4,4,i%4,i/4));
		if i in [0,1,2,3,14,15]: image.resize(96,64,Image.INTERPOLATE_NEAREST)
		else: image.resize(64,64,Image.INTERPOLATE_NEAREST)
		save(image,"UI/"+ui_names[i]+".png")
	save(Image.load_from_file(ROOT+"UI/panel.png"),"UI/thought_bubble.png")
	for name in ["panel_employee","panel_dialog","panel_bill","panel_menu"]:save(Image.load_from_file(ROOT+"UI/panel.png"),"UI/"+name+".png")
	for tier in ["r","sr","ssr"]:
		var badge=Image.load_from_file(ROOT+"UI/star.png");var color=Color("4a8cdb") if tier=="r" else Color("a375c4") if tier=="sr" else Color("d8b36a")
		for y in range(badge.get_height()):
			for x in range(badge.get_width()):
				var c=badge.get_pixel(x,y)
				if c.a>.5:badge.set_pixel(x,y,Color(color.r*c.v,color.g*c.v,color.b*c.v,c.a))
		save(badge,"UI/rarity_"+tier+".png")
	var nav={"btn_employee":"Sprites/xian_yang/atlas","btn_decoration":"Map/chair","btn_research":"Items/item_skill_book","btn_promotion":"Map/decor_promotion_board","btn_recruit":"Sprites/human_01/atlas","btn_branch":"Map/decor_sign","btn_central":"Map/equip_stove","btn_exploration":"Map/floor_yard","btn_encyclopedia":"Items/item_skill_book","btn_system":"UI/icon_clock"}
	for name in nav:
		var image=Image.load_from_file(ROOT+str(nav[name])+".png")
		if image.get_width()>200:image=image.get_region(Rect2i(8,3,48,48))
		icon(image,"UI/"+name+".png",32)
	for name in ["warning","special_guest","training","construction","rest","fatigue","working"]:
		var from="star" if name=="special_guest" else "icon_clock" if name in ["training","construction","working"] else "check" if name=="rest" else "arrow"
		save(Image.load_from_file(ROOT+"UI/"+from+".png"),"FX/icon_"+name+".png")
	save(Image.load_from_file(ROOT+"Items/pickup_cash.png"),"UI/pickup_cash.png");save(Image.load_from_file(ROOT+"UI/icon_spirit.png"),"UI/pickup_gem.png")
	var shadow=Image.create(32,12,false,Image.FORMAT_RGBA8);shadow.fill(Color.TRANSPARENT)
	for y in range(12):
		for x in range(32):
			if pow((x-15.5)/15,2)+pow((y-5.5)/5,2)<=1:shadow.set_pixel(x,y,Color(0.12,.18,.17,.25))
	save(shadow,"FX/shadow.png")
	var title=Image.load_from_file(inputs.title);title.resize(768,512,Image.INTERPOLATE_NEAREST);save(title,"UI/title.png")
	FileAccess.open(ROOT+"animation_catalog.json",FileAccess.WRITE).store_string(JSON.stringify(atlas_index,"\t"))
	catalog["animation_groups"]=atlas_index.size();catalog["frame_count"]=30*320+15*128+catalog.awakened.size()*320
	FileAccess.open(ROOT+"art_catalog.json",FileAccess.WRITE).store_string(JSON.stringify(catalog,"\t"))
	print("ART PACK ",catalog.frame_count," frames, ",atlas_index.size()," groups, ",catalog.assets.size()," PNGs")
	quit()
