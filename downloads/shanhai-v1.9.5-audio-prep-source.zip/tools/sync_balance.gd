extends SceneTree
## Reproducibly fill missing global keys. Explicit designer edits always win.

const Registry = preload("res://scripts/core/balance_registry.gd")

func _initialize() -> void:
	var path := "res://config/global_balance.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="): path = argument.trim_prefix("--output=")
	var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/global_balance.json"))
	if not raw is Dictionary:
		printerr("global_balance.json must be an object")
		quit(1)
		return
	var candidate: Dictionary = raw.duplicate(true)
	var added := 0
	var defaults: Dictionary = Registry.defaults()
	for key in defaults:
		if not candidate.has(key):
			candidate[key] = defaults[key]
			added += 1
	if not Registry.validate(candidate):
		printerr("Refusing to write invalid balance configuration")
		quit(1)
		return
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		printerr("Cannot write balance configuration: ", path)
		quit(1)
		return
	file.store_string(JSON.stringify(candidate, "  ", false, true) + "\n")
	file.close()
	print("sync_balance: %d numeric defaults added; %d total keys; %s" % [added, candidate.size(), path])
	quit(0)
