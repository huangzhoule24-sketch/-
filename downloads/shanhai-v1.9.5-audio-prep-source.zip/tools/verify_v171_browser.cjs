/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8002').replace(/\/$/, '');
const out = process.argv[2] || 'build/v171-browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  try {
    receipt = await (await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(() => window.shanhaiQAState?.panel === '欢迎', undefined, { timeout: 60000 });
    await click('start:full'); await click('tutorial:ack');
    await click('nav:员工'); await click('panel:close'); await click('tutorial:destination');
    await click('full:marketing:flyer');
    if ((await state()).panel) await click('panel:close');
    if ((await state()).paused) await click('time:pause');
    await page.waitForFunction(() => window.shanhaiQAState?.state.served >= 1, undefined, { timeout: 60000 });
    // Income guidance becomes visible on the same frame as the paid order;
    // wait for its container layout before using the newly visible rect.
    await page.waitForTimeout(700); await sync();
    await click('tutorial:ack');
    await check('Actual income explanation acknowledged', () => window.shanhaiQAState.state.tutorial.completed_steps.includes('income'));
    await click('todo:primary');
    await check('Mandatory guide finishes through the single priority anchor', () => window.shanhaiQAState.state.tutorial.finished);
    const navIds = s => s.buttons.filter(b=>b.qa_id.startsWith('nav:')).map(b=>b.qa_id);
    function record(label,ok) { checks.push({label,ok:!!ok}); if(!ok)throw Error(label); }
    let snapshot=await state();
    record('New game default2x and six game minutes per second',snapshot.speed===2 && snapshot.experience.real_time_rate===6);
    record('Stage0 bottom has exactly three business entries plus More',JSON.stringify(navIds(snapshot).sort())===JSON.stringify(['nav:员工','nav:宣传','nav:招聘','nav:更多'].sort()));
    await shot('01-first-bill');await click('panel:close');
    await click('nav:更多');
    snapshot=await state();
    record('More hides research, prices, skills and future expansion',!snapshot.buttons.some(b=>['研发','菜单定价','装修','会员计划','外卖服务','分店管理','中央厨房','世界排行榜'].some(name=>b.qa_id==='full:open:'+name)));
    await shot('02-stage-zero-more');
    await click('full:open:简单布置');
    await check('Layout has permanent completion and undo controls',()=>{const s=window.shanhaiQAState;return s.experience.decoration_active && s.paused && ['decor:finish','decor:undo','decor:cancel'].every(id=>s.buttons.some(b=>b.qa_id===id&&!b.disabled));});
    const layoutBefore=JSON.stringify((await state()).state.layout),cashBefore=(await state()).state.cash;
    let cell,selectedIndex=-1;
    for(let index=0;index<(await state()).state.layout.length;index++) {
      await click('decor:move:'+index);snapshot=await state();const current=snapshot.state.layout[index];
      cell=snapshot.experience.placement_cells.find(c=>c.x!==current.x||c.y!==current.y);
      if(cell){selectedIndex=index;break;}
    }
    if(!cell)throw Error('No unoccupied furniture with a safe movement destination');
    const grid=snapshot.layout_grid;
    const location=await point({x:grid.x+(cell.x+.5)*grid.w/grid.cols,y:grid.y+(cell.y+.5)*grid.h/grid.rows,w:0,h:0});
    await page.mouse.click(location.x,location.y);actions.push({place_existing:cell});await sync();
    snapshot=await state();
    record('Real map click moves existing furniture without cash cost',snapshot.state.layout[selectedIndex].x===cell.x&&snapshot.state.layout[selectedIndex].y===cell.y&&snapshot.state.cash===cashBefore&&snapshot.experience.undo_steps===1);
    await click('decor:undo');
    record('Undo restores original furniture and money',JSON.stringify((await state()).state.layout)===layoutBefore&&(await state()).state.cash===cashBefore);
    await click('panel:close');await shot('03-layout-exit-confirmation');
    await click('decor:continue');
    await check('Cancel exit keeps layout session',()=>window.shanhaiQAState.experience.decoration_active);
    await click('panel:back');await click('decor:discard');
    await check('Discard returns to More',()=>window.shanhaiQAState.panel==='更多'&&!window.shanhaiQAState.experience.decoration_active);
    record('Discard preserves original layout and cash',JSON.stringify((await state()).state.layout)===layoutBefore&&(await state()).state.cash===cashBefore);
    await click('panel:close');await click('nav:员工');
    record('Roster has no repeated hiring controls',!(await state()).buttons.some(b=>b.qa_id==='hire:normal'));
    await click('panel:close');await click('nav:招聘');
    record('Recruitment is a dedicated entry',(await state()).buttons.some(b=>b.qa_id==='hire:normal')&&!(await state()).buttons.some(b=>b.qa_id.startsWith('culture:employees:')));
    await click('panel:close');
    if(!(await state()).paused)await click('time:pause');
    snapshot=await state();const actor=snapshot.actors[0];const actorPoint=await point({x:actor.x,y:actor.y,w:0,h:0});
    await page.mouse.click(actorPoint.x,actorPoint.y);actions.push({focus_employee:actor.id});await sync();
    await check('Clicking an employee exposes live status and inner speech',()=>window.shanhaiQAState.experience.bubbles.some(b=>b.text.includes('体力')&&b.text.includes('心情')));
    await shot('04-employee-inner-speech');
    await click('nav:员工');
    const staffId=(await state()).employees[0].id;
    await click('employee:detail:'+staffId);
    record('Actual employee detail has schedule and training actions',(await state()).panel==='员工详情' && (await state()).buttons.some(b=>b.qa_id==='employee:training:'+staffId));
    await shot('05-v171-employee-detail');
    await click('employee:training:'+staffId);
    record('Selected employee training contains only selected employee',(await state()).buttons.filter(b=>b.qa_id.startsWith('full:train_attribute:')).every(b=>b.qa_id==='full:train_attribute:'+staffId));
    await click('panel:close');

    await click('time:4');
    await check('Four-speed time control uses12 game minutes per real second',()=>window.shanhaiQAState.speed===4&&window.shanhaiQAState.experience.real_time_rate===12&&!window.shanhaiQAState.paused);
    await page.waitForTimeout(1200);await click('time:pause');
    await click('nav:更多');await click('full:open:系统',true);await click('system:developer');await click('dev:art');
    const artRect=(await state()).art_input_rect,artPoint=await point(artRect);
    await page.mouse.click(artPoint.x,artPoint.y);await page.keyboard.press('Control+A');await page.keyboard.type('UI/thought_bubble.png');
    const [chooser]=await Promise.all([page.waitForEvent('filechooser'),click('art:import')]);
    await chooser.setFiles({name:'thought_bubble.png',mimeType:'image/png',buffer:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=','base64')});await sync();
    await check('Future bubble art uses the actual existing file import channel',()=>window.shanhaiQAState.art_import.ok&&window.shanhaiQAState.experience.bubble_art.available);
    await click('panel:close');await click('nav:更多');await click('full:open:系统',true);await click('system:save');
    const savedMinute=(await state()).last_saved_minute;await page.waitForTimeout(6500);await page.reload();
    await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});await sync();
    snapshot=await state();
    record('Refresh restores time speed, tutorial and imported bubble art',snapshot.speed===4&&snapshot.state.total_minutes===savedMinute&&snapshot.state.tutorial.finished&&snapshot.experience.bubble_art.available);
    await click('start:continue');
    await page.setViewportSize({width:844,height:390});await sync();
    snapshot=await state();
    record('Compact toolbar keeps4x and the single task anchor within viewport',['time:4','todo:primary','todo:summary'].every(id=>snapshot.buttons.some(b=>b.qa_id===id&&b.rect.x>=0&&b.rect.x+b.rect.w<=844&&b.rect.h>=44)));
    await shot('05-phone-hud');await click('nav:更多');await click('full:open:简单布置',true);
    snapshot=await state();record('Compact drawer completion stays visible',snapshot.buttons.some(b=>b.qa_id==='decor:finish'&&b.rect.y+b.rect.h<=390&&b.rect.h>=44));
    await shot('06-phone-layout');await click('decor:finish');
    await check('Explicit completion exits layout',()=>!window.shanhaiQAState.experience.decoration_active&&window.shanhaiQAState.panel==='');
    await page.setViewportSize({width:390,height:844});await sync();await shot('07-portrait-instruction');
  } catch (e) {
    errors.push(String(e.stack||e));
    await shot('failure').catch(()=>{});
    fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())??null,null,2));
  }
  const result = { date: new Date().toISOString(), game_source: receipt?.game_source, actions, checks, errors };
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify({ actions: actions.length, checks: checks.length, errors },null,2));
  await browser.close(); if (errors.length) process.exitCode = 1;
})();
