extends SceneTree
func _initialize():
	var model=load("res://scripts/core/game_model.gd").new(193);model.start_full()
	var targets=load("res://scripts/ui/art_targets.gd").slots(model)
	DirAccess.make_dir_recursive_absolute("res://build/v193-checks")
	var file=FileAccess.open("res://build/v193-checks/art-targets.json",FileAccess.WRITE);file.store_string(JSON.stringify(targets,"  "));file.close()
	print("V1.9.3 import contract: ",targets.size()," targets");quit()
