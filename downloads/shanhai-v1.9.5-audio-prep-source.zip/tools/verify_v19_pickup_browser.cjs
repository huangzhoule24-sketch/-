/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8002').replace(/\/$/, '');
const out = process.argv[2] || 'build/v19-browser-pickup';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  try {
    receipt = await (await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(() => window.shanhaiQAState?.panel === '欢迎', undefined, { timeout: 60000 });
    await click('start:full'); await click('tutorial:ack');
    await click('nav:员工'); await click('panel:close'); await click('tutorial:destination');
    await click('full:marketing:flyer');
    if ((await state()).panel) await click('panel:close');
    if ((await state()).paused) await click('time:pause');
    await page.waitForFunction(() => window.shanhaiQAState?.state.served >= 1, undefined, { timeout: 60000 });
    // Income guidance becomes visible on the same frame as the paid order;
    // wait for its container layout before using the newly visible rect.
    await page.waitForTimeout(700); await sync();
    await click('tutorial:ack');
    await check('Actual income explanation acknowledged', () => window.shanhaiQAState.state.tutorial.completed_steps.includes('income'));
    await click('todo:primary');
    await check('Mandatory guide finishes through the single priority anchor', () => window.shanhaiQAState.state.tutorial.finished);
    const navIds = s => s.buttons.filter(b=>b.qa_id.startsWith('nav:')).map(b=>b.qa_id);
    function record(label,ok) { checks.push({label,ok:!!ok}); if(!ok)throw Error(label); }
    let snapshot=await state();
    record('New game default2x and six game minutes per second',snapshot.speed===2 && snapshot.experience.real_time_rate===6);
    record('Stage0 bottom has exactly three business entries plus More',JSON.stringify(navIds(snapshot).sort())===JSON.stringify(['nav:员工','nav:宣传','nav:招聘','nav:更多'].sort()));
    await shot('01-first-bill');await click('panel:close');
    if(!(await state()).paused)await click('time:pause');
    snapshot=await state();
    record('Single top HUD shows live resources above scene',snapshot.top_status.position==='top'&&snapshot.top_status.single_row&&!snapshot.top_status.top_hidden&&snapshot.top_status.status_rect.y<snapshot.viewport.h/2&&!snapshot.bottom_status.inventory_open);
    const initialGridHeight=snapshot.layout_grid.h;
    await page.setViewportSize({width:844,height:390});await sync();
    await click('time:4');
    let found=null;
    const deadline=Date.now()+55000;
    while(Date.now()<deadline) {
      await page.waitForTimeout(300);await sync();snapshot=await state();
      found=snapshot.buttons.find(b=>b.qa_id.startsWith('pickup:'));
      if(found)break;
      if(snapshot.panel==='事件') {
        const option=snapshot.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
        if(option)await click(option.qa_id);
      } else if(snapshot.panel==='事件结果')await click('event:result:ack');
      else if(snapshot.panel==='今日收支结算')await click('daily:ack');
      else if(snapshot.paused&&!snapshot.panel)await click('time:pause');
    }
    if(!found)throw Error('No natural pickup appeared within the operating window');
    if(!(await state()).paused)await click('time:pause');
    snapshot=await state();
    const id=Number(found.qa_id.split(':')[1]);const drop=snapshot.state.revision18.pickups.find(p=>p.id===id);
    if(!drop)throw Error('Pickup expired before pausing');
    const before={cash:snapshot.state.cash,gems:snapshot.state.gems};
    await shot('01-natural-pickup');await click(found.qa_id);
    const after=await state();
    record('Physical natural pickup credits cash or gems exactly once',!after.state.revision18.pickups.some(p=>p.id===id)&&(drop.kind==='cash'?Math.abs(after.state.cash-before.cash-drop.amount)<.001:after.state.gems===before.gems+drop.amount));
    record('Compact top row and task stay within viewport',after.top_status.status_rect.x+after.top_status.status_rect.w<=844&&after.buttons.some(b=>b.qa_id==='time:menu'));
    await shot('02-natural-pickup-collected');
    await page.setViewportSize({width:390,height:844});await sync();await shot('07-portrait-instruction');
  } catch (e) {
    errors.push(String(e.stack||e));
    await shot('failure').catch(()=>{});
    fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())??null,null,2));
  }
  const result = { date: new Date().toISOString(), game_source: receipt?.game_source, actions, checks, errors };
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify({ actions: actions.length, checks: checks.length, errors },null,2));
  await browser.close(); if (errors.length) process.exitCode = 1;
})();
