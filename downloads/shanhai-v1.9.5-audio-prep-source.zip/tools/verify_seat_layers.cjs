/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8002').replace(/\/$/, '');
const out = process.argv[2] || 'build/v195-browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function sceneReady() {
    for(let attempt=0;attempt<10;attempt++){
      const s=await state();if(!s.panel)return;
      const event=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id.endsWith(':1'))||s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
      if(event)await click(event.qa_id);
      else if(s.buttons.some(b=>b.qa_id==='panel:close'&&!b.disabled))await click('panel:close');
      else throw Error('Unresolved natural interruption during pickup verification: '+s.panel);
    }
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  const observedStages=new Set();let samples=0;let receipt;
  function assertOrder(snapshot,label) {
    const order=snapshot.dollhouse?.draw_order;
    if(!order?.length)throw Error('Missing actual render order');
    const chairs=order.map((x,i)=>x.type==='chair'?i:-1).filter(i=>i>=0);
    const bodies=order.map((x,i)=>['staff','guest','leaving'].includes(x.type)?i:-1).filter(i=>i>=0);
    if(!chairs.length||!bodies.length||Math.max(...chairs)>=Math.min(...bodies))throw Error('Chair covers a body: '+label);
    samples++;
    for(const entity of order)if(entity.type==='guest')observedStages.add(entity.stage);
  }
  try {
    receipt=await(await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:full');await click('tutorial:ack');
    await click('nav:员工');await click('panel:close');await click('tutorial:ack');
    await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');
    if((await state()).panel)await click('panel:close');
    const deadline=Date.now()+60000;let savedSeated=false;
    while(Date.now()<deadline){
      const snapshot=await state();assertOrder(snapshot,'natural arrival/service');
      if(!savedSeated&&snapshot.dollhouse.draw_order.some(x=>x.stage==='eating')){await shot('seated');savedSeated=true;}
      if(snapshot.state.served>=1)break;
      await page.waitForTimeout(120);
    }
    if((await state()).state.served<1)throw Error('No natural completed order');
    checks.push({label:'Sampled live arrivals, seating and service preserve chair back pass',ok:true,samples});
    if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');
    await click('tutorial:ack');await click('tutorial:destination');await click('tutorial:ack');await click('panel:close');
    if(!(await state()).paused)await click('time:pause');
    assertOrder(await state(),'paused desktop');await shot('desktop');
    const stable=JSON.stringify((await state()).dollhouse.draw_order);
    await click('scene:down');await click('scene:up');await click('scene:overview');
    if(JSON.stringify((await state()).dollhouse.draw_order)!==stable)throw Error('Panning changed frozen drawing order');
    checks.push({label:'Camera panning preserves world depth order',ok:true});
    await page.setViewportSize({width:844,height:390});await sync();
    assertOrder(await state(),'mobile');await shot('mobile');
    checks.push({label:'Mobile viewport retains chair/body layering',ok:true});
    const snapshot=await state();fs.writeFileSync(path.join(out,'final-state.json'),JSON.stringify(snapshot,null,2));
  } catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});}
  const report={game_source:receipt?.game_source,actions,checks,samples,observed_stages:[...observedStages],errors};
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({actions:actions.length,checks:checks.length,samples,stages:[...observedStages],errors},null,2));
  await browser.close();if(errors.length)process.exitCode=1;
})();
