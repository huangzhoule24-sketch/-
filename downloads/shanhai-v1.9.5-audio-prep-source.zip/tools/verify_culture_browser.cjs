/* Physical browser acceptance: QA is read-only; actions use mouse/keyboard/file chooser. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const baseURL = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8002').replace(/\/$/, '');
const output = process.argv[2] || 'build/culture-browser-validation';
const pngFixture = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=', 'base64');

(async () => {
  fs.mkdirSync(output, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const checks = [], actions = [], geometry = [], samples = [], errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  const waitFor = (predicate, timeout = 30000) => page.waitForFunction(predicate, undefined, { timeout });
  async function syncSnapshots() {
    // Keep remote handles only: no data is injected into the game or page.
    for (let frame=0; frame<2; frame++) {
      const previous=await page.evaluateHandle(()=>window.shanhaiQAState);
      try { await page.waitForFunction(value=>window.shanhaiQAState!==value,previous,{timeout:10000}); }
      finally { await previous.dispose(); }
    }
  }


  async function check(label, predicate) {
    // QA snapshots publish on a timer; wait for the rendered operation to
    // appear under CPU load instead of comparing an older frame.
    let ok = false;
    const deadline = Date.now() + 5000;
    do { ok = !!predicate(await state()); if (ok) break; await page.waitForTimeout(150); } while (Date.now() < deadline);
    checks.push({ label, ok });
    if (!ok) throw Error(label);
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const snapshot = window.shanhaiQAState;
      const transform = snapshot.screen_transform || { a: 1, b: 0, c: 0, d: 1, tx: 0, ty: 0 };
      const canvas = document.querySelector('canvas');
      const bounds = canvas.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return {
        x: bounds.left + (transform.a * x + transform.c * y + transform.tx) * bounds.width / canvas.width,
        y: bounds.top + (transform.b * x + transform.d * y + transform.ty) * bounds.height / canvas.height,
      };
    }, rect);
  }
  async function click(id) {
    let button = (await state()).buttons.find(button => button.qa_id === id && !button.disabled);
    if (!button) button = await seekId(id, true);
    const location = await point(button.rect);
    await page.mouse.click(location.x, location.y);
    actions.push({ kind: 'click', id });
    await syncSnapshots();
  }
  async function wheel(delta) {
    const snapshot = await state();
    const location = await point({ x: snapshot.viewport.w * 0.63, y: snapshot.viewport.h * 0.64, w: 0, h: 0 });
    await page.mouse.move(location.x, location.y);
    await page.mouse.wheel(0, delta);
    // The read-only snapshot refreshes every 200 ms. Wait beyond that period before deciding
    // which controls are visible; otherwise consecutive wheels can skip an entire card.
    await syncSnapshots();
    const after = await state();
    actions.push({ kind: 'wheel', delta, scroll_before: snapshot.culture_navigation?.scroll_vertical, scroll_after: after.culture_navigation?.scroll_vertical });
  }
  async function seek(predicate, reset = false) {
    if (reset) await wheel(-20000);
    for (let attempt = 0; attempt < 80; attempt++) {
      const snapshot = await state();
      const button = snapshot.buttons.find(predicate);
      if (button) return button;
      await wheel((await state()).viewport.h <= 400 ? 80 : 180);
    }
    throw Error('Scrolled button not found: ' + String(predicate));
  }
  async function seekId(id, reset = false) { return seek(button => button.qa_id === id && !button.disabled, reset); }
  async function shot(name) { await page.screenshot({ path: path.join(output, name + '.png') }); }
  async function sample(label) {
    const snapshot = await state();
    samples.push({ label, panel: snapshot.panel, paused: snapshot.paused, culture_entry: snapshot.culture_entry, culture_navigation: snapshot.culture_navigation, viewport: snapshot.viewport });
  }
  async function culture(kind, id) {
    const qaId = `culture:${kind}:${id}`;
    await seekId(qaId, true);
    await click(qaId);
    await check(`${kind}/${id} opens a complete readable introduction`, snapshot => snapshot.panel === '文化简介' && snapshot.culture_entry.kind === kind && snapshot.culture_entry.id === id && snapshot.culture_entry.summary.length > 10 && snapshot.culture_entry.section_titles.length >= 3 && snapshot.culture_entry.source_count >= 1);
    await check(`${kind}/${id} offers safe HTTPS references`, snapshot => snapshot.culture_entry.source_urls.length === snapshot.culture_entry.source_count && snapshot.culture_entry.source_urls.every(url => { try { const parsed = new URL(url); return parsed.protocol === 'https:' && parsed.hostname.includes('.') && !parsed.username && !parsed.password && !/\s/.test(url); } catch { return false; } }));
    await sample(`${kind}/${id}`);
  }
  async function backToCatalog() {
    const before = await state(), context = before.culture_navigation.return_context;
    await click('culture:back');
    await page.waitForFunction(expected => { const s=window.shanhaiQAState; return s?.panel==='图鉴' && s.culture_navigation.catalog_tab===expected.tab && Math.abs(s.culture_navigation.scroll_vertical-expected.scroll)<=1 && s.paused===expected.paused; }, {tab:context.tab,scroll:context.scroll,paused:before.paused}, {timeout:10000});
    await check('return restores encyclopedia tab, scroll, and pause', snapshot => snapshot.panel === '图鉴' && snapshot.culture_navigation.catalog_tab === context.tab && Math.abs(snapshot.culture_navigation.scroll_vertical - context.scroll) <= 1 && snapshot.paused === before.paused);
  }
  async function referenceButton() {
    const source = await seek(button => button.qa_id.startsWith('culture:source:') && !button.disabled, true);
    await check('scrolled introduction exposes a real reference button', snapshot => snapshot.buttons.some(button => button.qa_id === source.qa_id && button.text.includes('原文') && !button.disabled));
    return source;
  }

  let receipt = {};
  try {
    receipt = await (await page.request.get(baseURL + '/export-receipt.json')).json();
    if (!/^[a-f0-9]{64}$/.test(receipt.game_source?.sha256 || '')) throw Error('Export receipt has no game-source SHA-256');
    if (process.env.SHANHAI_EXPECT_SOURCE && receipt.game_source?.sha256 !== process.env.SHANHAI_EXPECT_SOURCE) throw Error('Export fingerprint differs from requested game source');
    await page.goto(baseURL + '/?qa=1');
    await waitFor(() => window.shanhaiQAState?.panel === '欢迎', 60000);
    await click('start:full');
    // Finish the same six mandatory operations through visible controls; no QA writes.
    await click('time:3');
    await click('tutorial:ack');
    await click('nav:员工'); await click('panel:close');
    await click('tutorial:destination'); await click('full:marketing:flyer');
    if ((await state()).panel) await click('panel:close');
    if ((await state()).paused) await click('time:pause');
    await waitFor(() => window.shanhaiQAState?.state.served >= 1, 60000);
    await click('tutorial:ack'); await click('nav:系统'); await click('system:bills');
    await check('culture acceptance begins after six actual mandatory operations', snapshot => snapshot.state.tutorial.finished && !snapshot.state.tutorial.skipped);
    await click('panel:close');
    if (!(await state()).paused) await click('time:pause');
    const initial = await state();
    const originalUnlocks = JSON.stringify(initial.state.unlocked_dishes);
    const originalEmployees = JSON.stringify(initial.employees.map(employee => employee.id));
    const originalIdle = initial.art_probe;
    await click('nav:图鉴');
    await check('culture is available directly in the new-game encyclopedia', snapshot => snapshot.panel === '图鉴' && snapshot.buttons.some(button => button.qa_id.startsWith('culture:employees:')));
    await culture('employees', 'qianyang');
    await check('no artwork gives a readable placeholder', snapshot => snapshot.culture_entry.image_available === false && snapshot.culture_entry.resource_id === 'Characters/qianyang_lore');
    await shot('01-qianyang-placeholder');
    await referenceButton();
    await shot('02-qianyang-references');
    await backToCatalog();

    await culture('employees', 'eshou');
    await check('post-classical character has a visible origin distinction', snapshot => snapshot.culture_entry.origin_label.length > 0);
    await shot('03-eshou-origin');
    await backToCatalog();
    await seekId('catalog:菜品', true); await click('catalog:菜品');
    await culture('dishes', 'noodles');
    await shot('04-noodles'); await backToCatalog();
    await check('high-level themed recipe starts locked', snapshot => !snapshot.state.unlocked_dishes.includes('phoenix_soup'));
    await culture('dishes', 'phoenix_soup');
    await shot('05-locked-recipe'); await backToCatalog();
    await check('hidden recipe starts locked', snapshot => !snapshot.state.unlocked_dishes.includes('baize_hidden_banquet'));
    await culture('dishes', 'baize_hidden_banquet');
    await shot('06-hidden-recipe');
    await referenceButton(); await shot('07-hidden-references'); await backToCatalog();
    await check('reading never grants staff or unlocks recipes', snapshot => JSON.stringify(snapshot.state.unlocked_dishes) === originalUnlocks && JSON.stringify(snapshot.employees.map(employee => employee.id)) === originalEmployees);
    await click('panel:close');
    await check('closing encyclopedia preserves a previously paused game', snapshot => snapshot.panel === '' && snapshot.paused);
    await click('time:pause'); await click('nav:图鉴');
    await seekId('catalog:员工', true); await click('catalog:员工');
    await culture('employees', 'qianyang'); await backToCatalog(); await click('panel:close');
    await check('closing after a culture round trip resumes a running game', snapshot => snapshot.panel === '' && !snapshot.paused);
    await click('time:pause');

    await click('nav:系统'); await click('system:developer'); await click('dev:art');
    await check('developer culture slot selector is physically exposed', snapshot => snapshot.art_slot_rect?.w > 0);
    const input = await point((await state()).art_input_rect);
    await page.mouse.click(input.x, input.y);
    await page.keyboard.press('Control+A');
    await page.keyboard.type('Characters/qianyang_lore.png');
    actions.push({ kind: 'keyboard', target: 'art path input', text: 'Characters/qianyang_lore.png' });
    await page.waitForTimeout(250);
    const [chooser] = await Promise.all([page.waitForEvent('filechooser'), click('art:import')]);
    await chooser.setFiles({ name: 'culture-test-fixture.png', mimeType: 'image/png', buffer: pngFixture });
    actions.push({ kind: 'filechooser', target: 'Characters/qianyang_lore.png', fixture_only: true });
    await waitFor(() => window.shanhaiQAState?.art_import?.ok === true);
    await check('developer import uses the dedicated culture picture path', snapshot => snapshot.art_import.id === 'Characters/qianyang_lore' && snapshot.art_import.path.includes('CustomAssets/Characters/qianyang_lore.png'));
    await check('culture picture does not replace the worker idle picture', snapshot => snapshot.art_probe.available === originalIdle.available && snapshot.art_probe.custom_path === originalIdle.custom_path);
    await shot('08-real-picture-import');
    await click('panel:close'); await click('nav:图鉴'); await seekId('catalog:员工', true); await click('catalog:员工');
    await culture('employees', 'qianyang');
    await check('imported culture picture displays immediately', snapshot => snapshot.culture_entry.image_available && snapshot.culture_entry.resource_id === 'Characters/qianyang_lore');
    await shot('09-imported-culture-picture'); await backToCatalog(); await click('panel:close');
    await click('nav:系统'); await click('system:save'); await page.waitForTimeout(6500);
    await page.reload(); await waitFor(() => window.shanhaiQAState?.panel === '欢迎', 60000); await click('start:continue');
    await click('nav:图鉴'); await seekId('catalog:员工', true); await click('catalog:员工'); await culture('employees', 'qianyang');
    await check('culture picture remains after browser save and reload', snapshot => snapshot.culture_entry.image_available && snapshot.art_probe.custom_path === originalIdle.custom_path);
    await shot('10-reloaded-picture'); await backToCatalog(); await click('panel:close');

    await page.setViewportSize({ width: 844, height: 390 });
    await waitFor(() => window.shanhaiQAState?.viewport.w <= 850, 10000);
    await click('nav:图鉴'); await seekId('catalog:员工', true); await click('catalog:员工'); await culture('employees', 'qianyang');
    await check('landscape phone has a fixed reachable culture back button', snapshot => snapshot.buttons.some(button => button.qa_id === 'culture:back' && button.rect.h >= 44 && button.rect.y >= 0 && button.rect.y + button.rect.h <= 391));
    const phoneGeometry = await page.evaluate(() => {
      const snapshot = window.shanhaiQAState, transform = snapshot.screen_transform;
      const canvas = document.querySelector('canvas'), rect = canvas.getBoundingClientRect();
      const back = snapshot.buttons.find(button => button.qa_id === 'culture:back');
      return { viewport: snapshot.viewport, canvas: { x: rect.x, y: rect.y, w: rect.width, h: rect.height, backing_w: canvas.width, backing_h: canvas.height }, transform, back_rect: back.rect, physical_back_height: Math.hypot(transform.c * back.rect.h * rect.width / canvas.width, transform.d * back.rect.h * rect.height / canvas.height) };
    });
    geometry.push(phoneGeometry);
    const phoneOK = phoneGeometry.canvas.x === 0 && phoneGeometry.canvas.y === 0 && Math.abs(phoneGeometry.canvas.w - 844) < 1 && Math.abs(phoneGeometry.canvas.h - 390) < 1 && phoneGeometry.physical_back_height >= 43.99;
    checks.push({ label: 'culture phone canvas fills viewport and back remains 44 physical CSS pixels', ok: phoneOK });
    if (!phoneOK) throw Error('Culture phone canvas/back geometry failed');
    await shot('11-phone-culture'); await referenceButton(); await shot('12-phone-references'); await backToCatalog();
    await page.setViewportSize({ width: 390, height: 844 });
    await waitFor(() => window.shanhaiQAState?.viewport.w <= 400, 10000);
    await shot('13-portrait-rotation-hint');
    await sample('portrait screenshot for manual rotation-hint inspection');
  } catch (error) {
    errors.push(String(error.stack || error));
    await shot('failure').catch(() => {});
    fs.writeFileSync(path.join(output, 'failure-state.json'), JSON.stringify((await state()) ?? null, null, 2));
  }
  try {
    const endingReceipt = await (await page.request.get(baseURL + '/export-receipt.json')).json();
    const sameSource = receipt.game_source?.sha256 === endingReceipt.game_source?.sha256;
    checks.push({ label: 'all browser steps use one unchanged exported game source', ok: sameSource });
    if (!sameSource) errors.push('Exported source changed while the browser acceptance was running');
  } catch (error) { errors.push('Final export receipt: ' + String(error)); }
  if (!errors.length) {
    for (const filename of ['failure.png', 'failure-state.json']) {
      fs.rmSync(path.join(output, filename), { force: true });
    }
  }
  const result = { date: new Date().toISOString(), base_url: baseURL, game_source: receipt.game_source, exported_utc: receipt.exported_utc, interactions: 'Physical mouse, wheel, keyboard and file chooser; JavaScript reads QA snapshots only.', reference_scope: 'Reference URLs and enabled source buttons checked without opening external sites.', fixture_scope: 'One test PNG imported only into this temporary browser profile; no formal artwork added.', actions, checks, geometry, samples, errors };
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ actions: actions.length, checks: checks.length, errors }, null, 2));
  await browser.close();
  if (errors.length) process.exitCode = 1;
})();
