extends SceneTree
## Natural campaign probe. All model mutations go through public player actions.
## This is a policy experiment, not a proof that no other strategy can win.
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const Model = preload("res://scripts/core/game_model.gd")
var actions: Array = []
var days: Array = []
var configured: Dictionary = {}
var primary_team: Array = []
var stage_times: Dictionary = {"0": 360}
var max_days: int = 180
var seed_value: int = 20261021
var m
var last_recruit: int = -1440
var last_research: int = -30
var last_training: int = -120
var first_order: int = -1
var source_before: Dictionary = {}
var report_path: String = "res://build/v191-campaign-audit.json"
var roundtrip_numeric_representations: Array = []
var roundtrip_mismatches: Array = []

func same_saved_value(before: Variant, after: Variant, path: String) -> bool:
	# JSON numbers may change between int/float variants without changing value.
	# Otherwise only float-to-float final-bit differences within the declared
	# relative tolerance are accepted; integer values and structure remain exact.
	if (before is int or before is float) and (after is int or after is float):
		var left: float = float(before)
		var right: float = float(after)
		if left == right: return true
		var tolerance: float = maxf(1.0, maxf(absf(left), absf(right))) * 4.0 * 2.220446049250313e-16
		if before is float and after is float and is_finite(left) and is_finite(right) and absf(left - right) <= tolerance:
			roundtrip_numeric_representations.append({"path": path, "before": left, "after": right, "absolute_error": absf(left - right), "tolerance": tolerance})
			return true
		roundtrip_mismatches.append({"path": path, "before": before, "after": after, "reason": "numeric value differs beyond JSON double representation"})
		return false
	if typeof(before) != typeof(after):
		roundtrip_mismatches.append({"path": path, "reason": "variant type changed"})
		return false
	if before is Dictionary:
		if before.size() != after.size():
			roundtrip_mismatches.append({"path": path, "reason": "dictionary size changed"})
			return false
		var equal: bool = true
		for key in before:
			if not after.has(key):
				roundtrip_mismatches.append({"path": path + "." + str(key), "reason": "missing dictionary key"})
				equal = false
			elif not same_saved_value(before[key], after[key], path + "." + str(key)): equal = false
		return equal
	if before is Array:
		if before.size() != after.size():
			roundtrip_mismatches.append({"path": path, "reason": "array size changed"})
			return false
		var equal: bool = true
		for index in range(before.size()):
			if not same_saved_value(before[index], after[index], path + "[%d]" % index): equal = false
		return equal
	if before != after:
		roundtrip_mismatches.append({"path": path, "before": before, "after": after, "reason": "value changed"})
		return false
	return true

func source_fingerprints() -> Dictionary:
	var result: Dictionary = {}
	result["res://tools/v191_campaign_audit.gd"] = FileAccess.get_sha256("res://tools/v191_campaign_audit.gd")
	for directory in ["res://scripts/core", "res://config", "res://scripts/services"]:
		for filename in DirAccess.get_files_at(directory):
			if not filename.ends_with(".gd") and not filename.ends_with(".json"): continue
			var path: String = directory + "/" + filename
			result[path] = FileAccess.get_sha256(path)
	for path in ["res://scripts/ui/restaurant_view.gd","res://scripts/ui/rarity_display.gd"]:result[path]=FileAccess.get_sha256(path)
	return result

func _init() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--days="): max_days = maxi(1, arg.trim_prefix("--days=").to_int())
		if arg.begins_with("--seed="): seed_value = arg.trim_prefix("--seed=").to_int()
		if arg.begins_with("--report="): report_path = arg.trim_prefix("--report=")
	call_deferred("run")

func note(action: String, detail: Variant = null) -> void:
	actions.append({"minute": int(m.state.total_minutes), "action": action, "detail": detail})

func act(action: String, args: Dictionary = {}) -> bool:
	if not bool(m.full_rules.can_perform(action, args).get("ok", false)): return false
	var result: Dictionary = m.full_rules.perform(action, args)
	if bool(result.get("ok", false)):
		note(action, args.duplicate(true))
		return true
	return false

func set_rest(employee: Dictionary, resting: bool) -> void:
	if bool(employee.resting) == resting: return
	m.set_employee_rest(str(employee.id), resting)
	if bool(employee.resting) == resting: note("set_employee_rest", {"id": str(employee.id), "resting": resting})

func roster() -> void:
	var chefs: Array = []
	var front: Array = []
	var sales: Array = []
	for employee in m.employees:
		if not str(employee.get("branch_id", "")).is_empty(): continue
		match str(employee.role):
			"chef", "all": chefs.append(employee)
			"waiter": front.append(employee)
			"salesman": sales.append(employee)
	chefs.sort_custom(func(a, b): return float(a.attributes.get("cooking", 0)) + float(a.attributes.get("speed", 0)) * 0.2 > float(b.attributes.get("cooking", 0)) + float(b.attributes.get("speed", 0)) * 0.2)
	front.sort_custom(func(a, b): return float(a.attributes.get("speed", 0)) + float(a.attributes.get("charm", 0)) * 0.3 > float(b.attributes.get("speed", 0)) + float(b.attributes.get("charm", 0)) * 0.3)
	sales.sort_custom(func(a, b): return float(a.attributes.get("calculation", 0)) + float(a.attributes.get("eloquence", 0)) > float(b.attributes.get("calculation", 0)) + float(b.attributes.get("eloquence", 0)))
	var wanted: Array = []
	var limit: int = m.full_rules.active_limit()
	var chef_limit: int = (1 if not sales.is_empty() else 2) if limit <= 3 else (2 if limit <= 5 else 3)
	var front_limit: int = 1 if limit == 3 else (2 if limit <= 5 else 3)
	for employee in chefs.slice(0, mini(chef_limit, chefs.size())): wanted.append(str(employee.id))
	for employee in front.slice(0, mini(front_limit, front.size())): wanted.append(str(employee.id))
	if wanted.size() < limit and not sales.is_empty(): wanted.append(str(sales[0].id))
	primary_team = wanted.duplicate()
	for employee in m.employees:
		if str(employee.get("branch_id", "")).is_empty() and not str(employee.id) in wanted: set_rest(employee, true)
	for employee in m.employees:
		if not str(employee.id) in wanted: continue
		if float(employee.stamina) < 15: set_rest(employee, true)
		elif float(employee.stamina) > 65: set_rest(employee, false)

func provision(dish_id: String, target: float = 24) -> void:
	var recipe: Dictionary = m.full_rules.management.recipe(dish_id)
	for id in recipe:
		var record: Dictionary = m.full_rules.management.item(str(id))
		if float(record.get("quantity", 0)) >= float(recipe[id]) * 6: continue
		var quantity: int = maxi(1, int(ceil(float(recipe[id]) * target)))
		var price: float = m.full_rules.management.stock_price(str(id))
		if float(m.state.cash) >= quantity * price + 120:
			act("purchase", {"id": str(id), "quantity": quantity})

func menu() -> void:
	var best_id: String = "fried_rice"
	var best_value: float = 0
	for dish in m.dishes:
		var id: String = str(dish.id)
		if not id in m.state.unlocked_dishes: continue
		var allowed: bool = true
		for ingredient in m.full_rules.management.recipe(id):
			var definition: Dictionary = m.full_rules.management._ingredient(str(ingredient))
			if str(definition.kind) == "rare": allowed = false
			if str(definition.kind) == "shanhai" and not "shanhai" in m.state.management.suppliers: allowed = false
		if not allowed: continue
		var value: float = (float(dish.price) - float(dish.cost)) / sqrt(float(dish.cook_minutes))
		if value > best_value:
			best_value = value
			best_id = id
	provision(best_id)
	provision("fried_rice")
	for id in m.state.unlocked_dishes:
		var enabled: bool = str(id) == best_id or str(id) in ["noodles", "fried_rice", "steamed_bun"]
		if (id in m.state.menu_enabled) != enabled: act("set_menu", {"dish_id": str(id), "enabled": enabled})
		if int(m.state.stage) > 0 and not configured.has("price:" + str(id)):
			var base: float = float(m.state.management.base_prices.get(str(id), m._dish(str(id)).price))
			if act("set_price", {"dish_id": str(id), "price": base * 2}): configured["price:" + str(id)] = true

func develop() -> void:
	var now: int = int(m.state.total_minutes)
	if int(m.state.stage) == 0 or float(m.state.cash) < 900: return
	act("unlock_supplier", {"id": "shanhai"})
	if now - last_research >= 60 and m.state.management.projects.is_empty():
		for dish in m.dishes:
			if str(dish.id) in m.state.unlocked_dishes: continue
			if act("research", {"dish_id": str(dish.id)}):
				last_research = now
				break
	if int(m.state.stage) >= 2 and float(m.state.cash) > 12000 and now - last_training >= 180:
		var best = {}
		for employee in m.employees:
			if not str(employee.get("branch_id", "")).is_empty(): continue
			if str(employee.role) in ["chef", "all"] and (best.is_empty() or float(employee.attributes.cooking) > float(best.attributes.cooking)): best = employee
		if not best.is_empty() and float(best.attributes.cooking) < 16:
			if act("train_attribute", {"employee_id": str(best.id), "attribute": "cooking"}): last_training = now

func expansion() -> void:
	var state: Dictionary = m.state.expansion
	if int(m.state.stage) < 2: return
	if float(m.state.cash) > 1500: act("membership_enable")
	# Delivery is exercised only with spare chefs so its long reservation cannot starve the shop.
	if not configured.has("delivery") and m.employees.size() >= 7:
		if act("delivery_toggle", {"enabled": true}): configured.delivery = true
	if bool(state.delivery_enabled) and state.delivery_completed < 3: act("delivery_accept")
	if int(state.delivery_completed) >= 3 and bool(state.delivery_enabled): act("delivery_toggle", {"enabled": false})
	if int(m.state.stage) < 3: return
	if float(m.state.cash) > 20000: act("central_unlock")
	for definition in m.full_rules.expansion._definitions("branches"):
		var id: String = str(definition.id)
		if int(definition.stage) > int(m.state.stage): continue
		if not bool(state.branches[id].open) and float(m.state.cash) > 22000:
			act("branch_open", {"id": id})
		var staffing: Dictionary = {"chefs": 0, "front": 0}
		# Automatic fatigue breaks do not create a new permanent staffing vacancy.
		for employee in m.employees:
			if str(employee.get("branch_id", "")) != id: continue
			if str(employee.role) in ["chef", "all"]: staffing.chefs += 1
			if str(employee.role) in ["waiter", "salesman", "all"]: staffing.front += 1
		if bool(state.branches[id].open):
			for employee in m.employees:
				if not bool(employee.resting) or str(employee.id) in primary_team: continue
				if int(staffing.chefs) == 0 and str(employee.role) in ["chef", "all"]:
					if act("branch_assign", {"id": id, "employee_id": str(employee.id)}): staffing.chefs += 1
				elif int(staffing.front) == 0 and str(employee.role) in ["waiter", "salesman"]:
					if act("branch_assign", {"id": id, "employee_id": str(employee.id)}): staffing.front += 1
	# Share the sustainable main menu rather than exhausting exploration-only ingredients.
	var batch_dish: String = str(m.state.menu_enabled[0]) if not m.state.menu_enabled.is_empty() else "fried_rice"
	if bool(state.central.enabled):
		for id in state.branches:
			if not bool(state.branches[id].open): continue
			var total: int = 0
			for qty in state.branches[id].stock.values(): total += int(qty)
			if total < 12 and int(state.central.stock.get(batch_dish, 0)) >= 10: act("supply_send", {"id": str(id), "dish_id": batch_dish, "quantity": 10})
		if m.business_open() and state.central.jobs.size() < 2 and int(state.central.stock.get(batch_dish, 0)) < 40:
			provision(batch_dish, 40)
			act("central_cook", {"dish_id": batch_dish, "quantity": 20})
	if state.exploration_history.size() < 4 and state.explorations.is_empty() and int(m.state.gems) > 8 and float(m.state.cash) > 6000:
		for employee in m.employees:
			if bool(employee.resting) and act("explore", {"employee_id": str(employee.id)}): break
	if int(m.state.stage) < 4: return
	for employee in m.employees:
		if int(m.state.fragments.get(str(employee.id), 0)) >= 10 and not bool(employee.awakened):
			act("awaken", {"employee_id": str(employee.id)})
	var best = {}
	for employee in m.employees:
		if not str(employee.get("branch_id", "")).is_empty(): continue
		if str(employee.role) in ["chef", "all"] and (best.is_empty() or float(employee.attributes.cooking) > float(best.attributes.cooking)): best = employee
	if not best.is_empty():
		provision(batch_dish, 5)
		var contest_dish: String = ""
		var contest_score: float = -1
		for candidate in m.dishes:
			if not str(candidate.id) in m.state.unlocked_dishes: continue
			if not m.full_rules.management.can_make(str(candidate.id)): continue
			var score: float = m.full_rules.expansion._competition_score(best, candidate)
			if score > contest_score:
				contest_score = score
				contest_dish = str(candidate.id)
		if not contest_dish.is_empty(): act("compete", {"dish_id": contest_dish, "employee_id": str(best.id)})

func summary() -> Dictionary:
	var recommendations: int = int(m.state.customer_service.today.get("recommend_success",0))
	for report in m.state.customer_service.history: recommendations += int(report.get("recommend_success",0))
	return {"minute": int(m.state.total_minutes), "day": int(m.state.total_minutes) / 1440 + 1, "stage": int(m.state.stage), "cash": float(m.state.cash), "debt": float(m.state.debt), "revenue": float(m.state.total_revenue), "reputation": int(m.state.reputation), "served": int(m.state.served), "lost": int(m.state.lost), "gems": int(m.state.gems), "employees": m.employees.size(), "collected": m.state.story.collected_ids.size(), "recipes": m.state.unlocked_dishes.size(), "wage_arrears": float(m.state.wage_arrears), "rent_arrears": float(m.state.rent_arrears), "competition_wins": int(m.state.expansion.competition.wins), "story_claimed": m.state.story.claimed.duplicate(), "story_completed": m.state.story.completed.duplicate(), "recommendations_retained_history":recommendations, "feedback":m.state.customer_service.today.duplicate(true), "pages":m.state.sidequests.pages.size(), "completed_sidequests":m.state.sidequests.quests.values().filter(func(q):return int(q.stage)==3).size(), "blockade": m.state.world.get("blockade", {}).duplicate(true)}

func prepare_festival() -> void:
	var best_args: Dictionary = {}
	var best_score: float = -1
	for employee in m.employees:
		if not m.full_rules.active(str(employee.id)) or not str(employee.role) in ["chef", "all"]: continue
		for dish in m.dishes:
			if not str(dish.id) in m.state.unlocked_dishes: continue
			var args: Dictionary = {"employee_id": str(employee.id), "dish_id": str(dish.id)}
			if not bool(m.full_rules.can_perform("festival_prepare", args).get("ok", false)): continue
			var quality: float = clampf((m._b("prototype.base_quality") + float(employee.attributes.get("cooking", 0)) * m._b("prototype.quality_per_cooking_point")) * m.full_rules.quality_multiplier(employee, dish), 0, m._b("dish.quality_max"))
			var score: float = quality * m.full_rules.world._b("events.festival_score_quality", 0.8) + float(employee.attributes.get("creativity", 0)) * m.full_rules.world._b("events.festival_score_creativity", 1)
			if str(dish.get("required_employee", "")) == str(employee.id): score += m.full_rules.world._b("events.festival_specialty_bonus", 5)
			if score > best_score:
				best_score = score
				best_args = args
	if not best_args.is_empty(): act("festival_prepare", best_args)

func run() -> void:
	source_before = source_fingerprints()
	m = Model.new(seed_value)
	m.start_full()
	var initial_state: Dictionary = {"cash":float(m.state.cash),"debt":float(m.state.debt),"employees":m.employees.size(),"recipes":m.state.unlocked_dishes.duplicate()}
	Guide.observe(m,"welcome_ack")
	Guide.observe(m,"panel:员工")
	Guide.observe(m,"closed:员工")
	act("marketing", {"kind":"flyer"})
	var advanced: int = 0
	var last_day: int = -1
	var stop_reason: String = "time_budget_exhausted"
	while advanced < max_days * 1440:
		var now: int = int(m.state.total_minutes)
		if m.state.rescue171.warning_pending: act("warning_ack")
		if int(m.state.finance.last_bill_day)>int(m.state.revision171.daily_seen):act("daily_ack")
		if bool(m.state.finance.rescue.pending):
			stop_reason = "bankruptcy_rescue_requires_player_choice"
			break
		if int(m.state.served)>0 and not bool(m.state.tutorial.finished):
			Guide.observe(m,"income_ack")
			m.full_rules.finance.preview_bill()
			Guide.observe(m,"panel:账单")
		if int(m.state.served) > 0 and first_order < 0: first_order = now
		var event: Dictionary = m.pending_event()
		if not event.is_empty():
			if str(event.id) == "food_festival": prepare_festival()
			for index in range(event.get("options", []).size()):
				if m.choose_event(str(event.id), index):
					note("choose_event", {"id": str(event.id), "option": index})
					break
		if now % 15 == 0:
			for pickup in m.state.revision18.pickups.duplicate():act("pickup_collect",{"id":int(pickup.id)})
			if m.full_rules.revision18.has_state("hygiene_risk") and m.state.revision18.cleaning.is_empty():
				for employee in m.employees:
					if act("kitchen_clean",{"employee_id":str(employee.id)}):break
			for quest in m.quest_status():
				if bool(quest.complete) and not bool(quest.claimed): act("claim", {"id": str(quest.id)})
			for entry in m.full_rules.story._definitions(): act("story_claim", {"id": str(entry.id)})
			while not m.state.contracts.is_empty():
				if not act("recruit", {"kind": "contract"}): break
			var recruit_interval: int = 1440
			if int(m.state.stage) >= 2 and float(m.state.cash) > 12000: recruit_interval = 360
			if int(m.state.stage) >= 3 and float(m.state.cash) > 30000: recruit_interval = 120
			if int(m.state.stage) >= 4 and float(m.state.cash) > 100000: recruit_interval = 45
			if now - last_recruit >= recruit_interval and (m.state.story.collected_ids.size() < 30 or m.employees.size() < 30) and int(m.state.stage) > 0:
				var reserve: float = 2500 + m.employees.size() * 150
				if float(m.state.cash) > reserve:
					if act("recruit", {"kind": "normal"}): last_recruit = now
				elif int(m.state.gems) > 18 and int(m.state.stage) >= 2:
					if act("recruit", {"kind": "advanced"}): last_recruit = now
			roster()
			sidequests()
			training_and_guidance()
			expand_equipment()
			develop()
			menu()
			if float(m.state.cash) > 1800 and float(m.state.debt) > 0:
				var payment: int = mini(500, int(m.state.debt))
				if m.repay_debt(payment): note("repay_debt", payment)
			if bool(m.full_rules.can_perform("upgrade").ok) and m.upgrade_restaurant():
				note("upgrade", int(m.state.stage))
				stage_times[str(m.state.stage)] = now
			if int(m.state.reputation) >= 500 and int(m.state.world.festival_wins) < 1: act("festival_invitation")
			if bool(m.state.world.get("blockade", {}).get("active", false)):
				for strategy in ["supply", "service", "community"]: act("kunlun_counter", {"strategy": strategy})
			for employee in m.employees:
				if float(employee.mood) < 50 and float(m.state.cash) > 500: act("comfort", {"employee_id": str(employee.id)})
			expansion()
		var day: int = now / 1440
		if day != last_day:
			last_day = day
			days.append(summary())
			print("CAMPAIGN_DAY " + JSON.stringify(days[-1]))
		var all_design_dishes: bool = true
		for dish in m.dishes:
			if not bool(dish.get("hidden", false)) and not str(dish.id) in m.state.unlocked_dishes: all_design_dishes = false
		var all_main_claimed: bool = true
		for milestone in m.full_rules.story.config.get("milestones", []):
			if not str(milestone.id) in m.state.story.claimed: all_main_claimed = false
		if all_main_claimed and "all_beasts" in m.state.story.claimed and m.employees.size() == 30 and all_design_dishes:
			stop_reason = "main_story_all_beasts_and_design_recipes_complete"
			break
		m.advance_minutes(1)
		m.full_rules.revision18.advance_pickups(1.0/6.0)
		advanced += 1
	var saved: bool = m.save_game("/tmp/shanhai-v191-campaign-audit-save.json")
	var restored = Model.new(seed_value + 1)
	var loaded: bool = restored.load_game("/tmp/shanhai-v191-campaign-audit-save.json")
	var save_state_preserved: bool = loaded and same_saved_value(m.state, restored.state, "state")
	var save_employees_preserved: bool = loaded and same_saved_value(m.employees, restored.employees, "employees")
	var save_orders_preserved: bool = loaded and same_saved_value(m.customers, restored.customers, "customers") and same_saved_value(m.scheduler, restored.scheduler, "scheduler")
	var save_random_preserved: bool = loaded and m._rng.state == restored._rng.state
	var source_after: Dictionary = source_fingerprints()
	var all_bills_reconciled: bool = m.state.finance.bills.all(func(bill): return bool(bill.get("cash_reconciled", false)))
	var result: Dictionary = {"seed": seed_value, "policy": "v191_public_actions_recommendation_and_sidequest_campaign", "gameplay_actions_only": true, "initial_state": initial_state, "semantic_guide_callbacks":true, "fixture_resources_used": false, "advance_granularity_minutes": 1, "max_days": max_days, "advanced_minutes": advanced, "first_order_minute": first_order, "stop_reason": stop_reason, "natural_full_clear": stop_reason == "main_story_all_beasts_and_design_recipes_complete", "summary": summary(), "stage_minutes": stage_times, "story_completed": m.state.story.completed, "story_claimed": m.state.story.claimed, "employees": m.employees.map(func(employee): return str(employee.id)), "recipes": m.state.unlocked_dishes, "expansion": m.state.expansion, "sidequests":m.state.sidequests, "customer_service":m.state.customer_service, "finance":m.state.finance, "tutorial":m.state.tutorial, "daily_snapshots": days, "actions": actions, "save_written": saved, "save_loaded": loaded, "source_before": source_before, "source_after": source_after, "source_unchanged_during_run": source_before == source_after, "limitations": ["A bounded deterministic policy can demonstrate a reachable outcome but cannot prove impossibility for every player strategy.", "No render/input/UI coverage is claimed.", "Pickup real time is sampled at one-sixth second per game minute; manual collection is a public player action.", "Success requires all six main story goals claimed, the independent 30-beast achievement, a live 30-employee roster, and all 23 design dishes researched."]}
	DirAccess.make_dir_recursive_absolute("res://build")
	result.employee_status = m.employees.map(func(employee): return {"id": str(employee.id), "role": str(employee.role), "branch": str(employee.get("branch_id", "")), "awakened": bool(employee.get("awakened", false)), "attributes": employee.attributes.duplicate(true), "stamina": float(employee.stamina)})
	result.all_bills_cash_reconciled = all_bills_reconciled
	result.design_recipes_unlocked = m.dishes.filter(func(dish): return not bool(dish.get("hidden", false)) and str(dish.id) in m.state.unlocked_dishes).size()
	result.design_recipes_total = m.dishes.filter(func(dish): return not bool(dish.get("hidden", false))).size()
	result.leaderboard = m.full_rules.expansion.leaderboard()
	result.save_roundtrip = {"state_preserved": save_state_preserved, "employees_preserved": save_employees_preserved, "orders_and_scheduler_preserved": save_orders_preserved, "random_sequence_preserved": save_random_preserved}
	result.save_comparison = {"rule": "All fields, keys, array order, integer numeric values, nonnumeric Variant types and RNG are exact. Equal numeric values may use int or float variants. Otherwise only float-to-float JSON differences within max(1, abs(before), abs(after)) * 4 machine epsilon are accepted and enumerated.", "floating_representation_differences": roundtrip_numeric_representations, "mismatches": roundtrip_mismatches}
	var file = FileAccess.open(report_path, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(result, "  "))
		file.close()
	print("CAMPAIGN_RESULT " + JSON.stringify({"stop_reason": stop_reason, "natural_full_clear": result.natural_full_clear, "summary": result.summary, "save_written": saved, "save_loaded": loaded}))
	quit(0 if saved and loaded and save_state_preserved and save_employees_preserved and save_orders_preserved and save_random_preserved and all_bills_reconciled and bool(result.source_unchanged_during_run) and bool(result.natural_full_clear) else 1)


func sidequests() -> void:
	for id in m.state.story.collected_ids:
		if str(id) != "bai_ze": act("baize_page", {"id":str(id)})
	for quest in m.full_rules.sidequests.config.quests:
		act("sidequest_read", {"id":str(quest.id)})
		act("sidequest_choice", {"id":str(quest.id), "choice_id":"cooperate"})
		act("sidequest_finish", {"id":str(quest.id)})
	for employee in m.employees:
		act("care", {"employee_id":str(employee.id)})
		if float(m.state.cash)>maxf(4000,m.employees.size()*250):
			act("gift", {"employee_id":str(employee.id),"kind":"book"})


func training_and_guidance() -> void:
	if int(m.state.stage)<1: return
	if not configured.has("decoration"):
		for item in m.decorations:
			for x in range(8):
				for y in range(5):
					if configured.has("decoration"): break
					if not m.can_place_decoration(str(item.id),x,y):continue
					for employee in m.employees:
						if not m.full_rules.revision.builder_available(employee):continue
						var booking: Dictionary=m.full_rules.revision.book_build(str(item.id),x,y,str(employee.id))
						if booking.ok:
							m.full_rules.revision.activate_builds();configured.decoration=true
							note("build_decoration",{"id":str(item.id),"x":x,"y":y,"employee_id":str(employee.id)})
							break
	if not configured.has("skill"):
		for employee in m.employees:
			if act("upgrade_skill", {"employee_id":str(employee.id),"method":"book"}):
				configured.skill=true
				break
	if int(m.state.stage)>=2 and not configured.has("campaign"):
		if act("campaign",{"id":"discount"}): configured.campaign=true
	if int(m.state.stage)>=4: Guide.observe(m,"ranking_view")

func expand_equipment() -> void:
	if int(m.state.stage)<1 or float(m.state.cash)<6500:return
	var d=m.full_rules.dollhouse
	var target=mini(5,maxi(2,m.employees.filter(func(e):return str(e.get("branch_id",""))=="" and not bool(e.resting) and d.capable(e,"chef")).size()))
	var pending=m.state.revision171.builds.filter(func(job):return str(job.id)=="stove").size()
	if d.fixtures("stove").size()+pending>=target:return
	var dimensions=preload("res://scripts/services/restaurant_space.gd").grid_dimensions(m)
	for y in range(dimensions.y):
		for x in range(dimensions.x):
			if not m.can_place_decoration("stove",x,y):continue
			for employee in m.employees:
				if not m.full_rules.revision.builder_available(employee):continue
				var booking=m.full_rules.revision.book_build("stove",x,y,str(employee.id))
				if booking.ok:
					m.full_rules.revision.activate_builds();note("build_equipment",{"id":"stove","x":x,"y":y,"employee_id":str(employee.id)});return
