#!/usr/bin/env python3
"""Reproduce the two-glyph reading supplement from an installed OFL Noto CJK font.

The generated font is already bundled; this optional tool needs fontTools.
It keeps original outlines/copyright and renames the subset family.
"""
from pathlib import Path
import argparse
import hashlib
import json
from fontTools.ttLib import TTFont
from fontTools import subset

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default="/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
    parser.add_argument("--index", type=int, default=2, help="Simplified Chinese face in the Noto collection")
    args = parser.parse_args()
    source = Path(args.source)
    font = TTFont(source, fontNumber=args.index)
    options = subset.Options()
    options.name_IDs = ["*"]
    options.name_legacy = True
    options.name_languages = ["*"]
    sub = subset.Subsetter(options=options)
    sub.populate(unicodes=[0x342B, 0x4455])
    sub.subset(font)
    family = "Shanhai CJK Supplement"
    for record in font["name"].names:
        if record.nameID in {1, 4, 6, 16}:
            text = "ShanhaiCJKSupplement-Regular" if record.nameID == 6 else family
            record.string = text.encode(record.getEncoding())
    if "CFF " in font:
        cff = font["CFF "].cff
        cff.fontNames = ["ShanhaiCJKSupplement-Regular"]
        cff.topDictIndex[0].FamilyName = family
        cff.topDictIndex[0].FullName = family + " Regular"
    destination = ROOT / "assets/fonts/ShanhaiCJKSupplement.otf"
    font.save(destination)
    metadata = {"source": source.name, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                "font_index": args.index, "characters": "㐫䑕", "codepoints": ["U+342B", "U+4455"],
                "changes": "Subset to two original outlines; family/PostScript names renamed. Copyright and OFL notices retained.",
                "output_sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}
    (ROOT / "assets/fonts/ShanhaiCJKSupplement.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(metadata, ensure_ascii=False))


if __name__ == "__main__":
    main()
