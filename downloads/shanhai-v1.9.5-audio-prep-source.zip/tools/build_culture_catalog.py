#!/usr/bin/env python3
"""Merge reviewed research records into the offline game catalogue and course notes."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
PARTS = ["employees-a.json", "employees-b.json", "dishes.json"]


def build():
    result = {
        "schema_version": 1,
        "revised_on": "2026-10-18",
        "editorial_note": "白话简介为本项目原创。原典、后世解释与游戏改编分层；引文按电子录文核对，版本差异及整理方式见研究证据。文化阅读不改变招募、研发或存档规则。",
        "sources": [], "employees": {}, "dishes": {},
    }
    seen = set()
    for filename in PARTS:
        part = json.loads((ROOT / "docs/culture-research" / filename).read_text(encoding="utf-8"))
        for source in part["sources"]:
            if source["id"] in seen:
                raise ValueError(f"Duplicate source ID: {source['id']}")
            seen.add(source["id"])
            result["sources"].append(source)
        for kind in ["employees", "dishes"]:
            for entry_id, entry in part.get(kind, {}).items():
                if entry_id in result[kind]:
                    raise ValueError(f"Duplicate reading ID: {kind}/{entry_id}")
                result[kind][entry_id] = entry
    employees = json.loads((ROOT / "config/employees.json").read_text())
    dishes = json.loads((ROOT / "config/dishes.json").read_text())
    hidden = json.loads((ROOT / "config/management.json").read_text())["hidden_recipe"]
    additional = json.loads((ROOT / "config/sidequests.json").read_text())["hidden_recipes"]
    expected = {"employees": employees, "dishes": dishes + [hidden] + additional}
    for kind, records in expected.items():
        if set(result[kind]) != {record["id"] for record in records}:
            raise ValueError(f"Reading IDs do not match the game: {kind}")
        result[kind] = {record["id"]: result[kind][record["id"]] for record in records}
        for record in records:
            if result[kind][record["id"]]["name"] != record["name"]:
                raise ValueError(f"Name mismatch: {record['id']}")
    (ROOT / "config/culture.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    sources = {source["id"]: source for source in result["sources"]}
    notes = ["# 山海员工与菜品文化简介", "", "整理日期：2026-10-18。本文由游戏实际使用的文化JSON生成，与游戏简介保持一致。", "", result["editorial_note"], "", "图片暂缺；开发者接入见[美术说明](art-pipeline.md)。研究过程及版本局限见[culture-guide.md](culture-guide.md)。", ""]
    for kind, heading in [("employees", "26位山海伙伴"), ("dishes", "23道设计菜与2道原创隐藏菜")]:
        notes.extend([f"## {heading}", ""])
        for entry_id, entry in result[kind].items():
            notes.extend([f"### {entry['name']} · {entry['pinyin']}", "", f"{entry['origin_label']} · ID：`{entry_id}`", "", entry["summary"], ""])
            for section in entry["sections"]:
                notes.extend([f"**{section['title']}**", "", section["text"], ""])
            for quote in entry.get("quotes", []):
                source = sources[quote["source_id"]]
                notes.extend([f"> {quote['text']}", f"> ——{source['work']}·{source['chapter']}", ""])
            notes.extend(["来源：", ""])
            for source_id in entry["source_ids"]:
                source = sources[source_id]
                notes.append(f"- [{source['title']}]({source['url']})（核验：{source['accessed_on']}）。{source.get('note', '')}")
            notes.append("")
    (ROOT / "docs/culture-entries.md").write_text("\n".join(notes), encoding="utf-8")
    print(json.dumps({"employees": len(result["employees"]), "dishes": len(result["dishes"]), "source_records": len(sources), "unique_source_urls": len({source['url'] for source in sources.values()})}, ensure_ascii=False))


if __name__ == "__main__":
    build()
