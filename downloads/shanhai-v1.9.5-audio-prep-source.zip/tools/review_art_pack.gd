extends SceneTree
func _init(): call_deferred("run")
func run():
	var assets=load("res://scripts/services/asset_catalog.gd").new()
	var employees=JSON.parse_string(FileAccess.get_file_as_string("res://config/employees.json"))
	var sheet=Image.create(768,800,false,Image.FORMAT_RGBA8);sheet.fill(Color("ece8dd"))
	for i in range(30):
		var frame=assets.get_frames(str(employees[i].id),"idle","down")[0].get_image();frame.resize(128,160,Image.INTERPOLATE_NEAREST)
		sheet.blit_rect(frame,Rect2i(0,0,128,160),Vector2i((i%6)*128,(i/6)*160))
	assert(sheet.save_png("res://build/art-staff-review.png")==OK)
	var strip=Image.create(1024,480,false,Image.FORMAT_RGBA8);strip.fill(Color("ece8dd"))
	for row in range(3):
		var id=["xian_yang","qing_fu","zhu_long"][row]
		var frames=assets.get_frames(id,"walk","down")
		for i in range(8):
			var image=frames[i].get_image();image.resize(128,160,Image.INTERPOLATE_NEAREST);strip.blit_rect(image,Rect2i(0,0,128,160),Vector2i(i*128,row*160))
	strip.save_png("res://build/art-gait-review.png");print("Review sheets saved");quit()
