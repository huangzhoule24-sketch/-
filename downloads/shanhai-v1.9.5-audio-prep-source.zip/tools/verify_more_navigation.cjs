/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8002').replace(/\/$/, '');
const out = process.argv[2] || 'build/more-back/browser';
const branches = ['主线故事','经营升级','库存供应','采购设置','菜单定价','宣传营销','招聘','员工培养','账单','会员外卖','连锁经营','山海探索','三界集团','事件','事件图鉴','羁绊图鉴','相生相克','员工支线','世界排行榜','顾客反馈','待办汇总','封锁对抗','营业日志','说明'];

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;
  try {
    receipt = await (await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');
    await page.waitForFunction(() => window.shanhaiQAState?.panel === '欢迎', undefined, { timeout: 60000 });
    await click('start:full'); await click('time:3'); await click('tutorial:ack');
    await click('nav:员工'); await click('panel:close'); await click('tutorial:destination');
    await click('full:marketing:flyer');
    if ((await state()).panel) await click('panel:close');
    if ((await state()).paused) await click('time:pause');
    await page.waitForFunction(() => window.shanhaiQAState?.state.served >= 1, undefined, { timeout: 60000 });
    // Income guidance becomes visible on the same frame as the paid order;
    // wait for its container layout before using the newly visible rect.
    await page.waitForTimeout(700); await sync();
    await click('tutorial:ack');
    await check('Actual income explanation acknowledged', () => window.shanhaiQAState.state.tutorial.completed_steps.includes('income'));
    await click('nav:系统'); await click('system:bills');
    await check('Six mandatory operations completed normally', () => window.shanhaiQAState.state.tutorial.finished && !window.shanhaiQAState.state.tutorial.skipped);
    await click('panel:close');
    for (const width of [1440,844]) {
      if (width === 844) { await page.setViewportSize({ width: 844, height: 390 }); await sync(); }
      await click('nav:更多');
      for (const name of branches) {
        // Resolve the control before recording scroll; seeking uses only wheels.
        let found = (await state()).buttons.some(b => b.qa_id === 'full:open:'+name);
        for (let attempt = 0; !found && attempt < 50; attempt++) {
          await wheel(width === 844 ? 80 : 160);
          found = (await state()).buttons.some(b => b.qa_id === 'full:open:'+name);
        }
        const before = await state(), scroll = before.culture_navigation.scroll_vertical;
        await click('full:open:'+name);
        const child = await state(), back = child.buttons.find(b => b.qa_id === 'panel:back' && !b.disabled);
        if (child.panel !== name || !back || back.rect.h < 44 || back.rect.x < 0 || back.rect.y < 0 || back.rect.x+back.rect.w > child.viewport.w || back.rect.y+back.rect.h > child.viewport.h) throw Error('Branch return geometry: '+name);
        checks.push({ label: width+'px '+name+' has a fixed44px return', ok: true });
        if (name === '员工培养') await shot(width+'-training-return');
        await click('panel:back');
        const after = await state();
        if (after.panel !== '更多' || Math.abs(after.culture_navigation.scroll_vertical-scroll) > 1 || after.paused !== before.paused || after.state.cash !== before.state.cash || after.state.total_minutes !== before.state.total_minutes) throw Error('Return context: '+name);
        checks.push({ label: width+'px '+name+' restores More, scroll and simulation', ok: true });
      }
      await shot(width+'-more-restored');
      await click('full:open:连锁经营',true); await click('full:open:山海探索',true); await shot(width+'-nested-return');
      await click('panel:back');
      await check(width+'px nested return reaches chain management', () => window.shanhaiQAState.panel === '连锁经营');
      await click('panel:back');
      await check(width+'px second return reaches More', () => window.shanhaiQAState.panel === '更多');
      await click('full:open:员工培养',true); await click('culture:employees:qianyang',true);
      await check(width+'px culture retains its own return', () => { const s=window.shanhaiQAState; return s.panel === '文化简介' && s.buttons.some(b=>b.qa_id==='culture:back') && !s.buttons.some(b=>b.qa_id==='panel:back'); });
      await click('culture:back'); await click('panel:back');
      await check(width+'px culture preserves More ancestry', () => window.shanhaiQAState.panel === '更多');
      await click('panel:close');
    }
  } catch (e) {
    errors.push(String(e.stack||e));
    await shot('failure').catch(()=>{});
    fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())??null,null,2));
  }
  const result = { date: new Date().toISOString(), game_source: receipt?.game_source, branches, actions, checks, errors };
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify({ actions: actions.length, checks: checks.length, errors },null,2));
  await browser.close(); if (errors.length) process.exitCode = 1;
})();
