const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const baseURL=(process.env.SHANHAI_QA_URL||'http://127.0.0.1:8000').replace(/\/$/,'');
(async()=>{
 const out=process.argv[2]||'build/browser-validation';fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1440,height:900}});
 const errors=[]; const actions=[];const checks=[];const geometry=[];
 page.on('pageerror', e=>errors.push(e.message));
 page.on('console', msg=>{if(msg.type()==='error')errors.push(msg.text())});
 async function state(){return page.evaluate(()=>window.shanhaiQAState)}
 async function check(label,fn){const s=await state();const ok=!!fn(s);checks.push({label,ok});if(!ok)throw Error(label)}
 async function waitFor(fn,timeout=30000){await page.waitForFunction(fn,undefined,{timeout});}
 async function operateUntil(fn,timeout=60000){const until=Date.now()+timeout;while(Date.now()<until){if(await page.evaluate(fn))return;const s=await state();if(s?.panel==='事件'){const choice=s.buttons.find(b=>b.qa_id.startsWith('event:')&&b.qa_id!=='event:open'&&!b.disabled);if(choice)await click(choice.qa_id);}await page.waitForTimeout(300);}throw Error('Operating did not reach expected state');}
 async function physicalPoint(rect){return page.evaluate(rect=>{const s=window.shanhaiQAState;const t=s.screen_transform||{a:1,b:0,c:0,d:1,tx:0,ty:0};const canvas=document.querySelector('canvas');const r=canvas.getBoundingClientRect();const x=rect.x+rect.w/2,y=rect.y+rect.h/2;return {x:r.left+(t.a*x+t.c*y+t.tx)*r.width/canvas.width,y:r.top+(t.b*x+t.d*y+t.ty)*r.height/canvas.height};},rect);}
 async function click(id){
  let b=(await state())?.buttons?.find(b=>b.qa_id===id&&!b.disabled);
  if(!b){await page.waitForTimeout(400);b=(await state())?.buttons?.find(b=>b.qa_id===id&&!b.disabled);}
  if(!b){const s=await state();const center=await physicalPoint({x:s.viewport.w*.63,y:s.viewport.h*.64,w:0,h:0});await page.mouse.move(center.x,center.y);await page.mouse.wheel(0,-12000);await page.waitForTimeout(350);}
  for(let attempt=0;!b&&attempt<35;attempt++){b=(await state())?.buttons?.find(b=>b.qa_id===id&&!b.disabled);if(!b){await page.mouse.wheel(0,150);await page.waitForTimeout(350);}}
  if(!b)throw Error('Visible enabled button not found after scrolling: '+id);
  const point=await physicalPoint(b.rect);await page.mouse.click(point.x,point.y);actions.push(id);await page.waitForTimeout(350);
 }
 async function shot(name){await page.screenshot({path:path.join(out,name+'.png')});}
 async function chartShot(name){const s=await state(),point=await physicalPoint({x:s.viewport.w*.6,y:s.viewport.h*.65,w:0,h:0});await page.mouse.move(point.x,point.y);await page.mouse.wheel(0,2500);await page.waitForTimeout(600);await shot(name);}
 try{
 await page.goto(baseURL+'/?qa=1');
 await waitFor(()=>window.shanhaiQAState?.panel==='欢迎',60000);
 await check('full campaign welcome',s=>s.state.mode==='full'&&s.state.cash===800&&s.state.debt===1200&&s.state.seats===8);
 await shot('01-welcome');await click('start:full');
 await click('time:3');await click('tutorial:ack');
 await click('nav:员工');await check('employee panel opened',s=>s.panel==='员工');await shot('02-employees');
 await click('panel:close');
 await check('mandatory introduction has no skip control',s=>!s.buttons.some(b=>b.qa_id==='tutorial:skip')&&!s.state.tutorial.skipped);
 await click('tutorial:destination');
 await check('mandatory promotion opens its actual panel',s=>s.panel==='宣传营销');
 const beforeFlyer=(await state()).state.cash;
 await click('full:marketing:flyer');
 await check('mandatory flyer spends real 20 yuan',s=>beforeFlyer-s.state.cash===20);
 if((await state()).panel)await click('panel:close');
 if((await state()).paused)await click('time:pause');
 await operateUntil(()=>window.shanhaiQAState?.state.served>=1,60000);
 await click('tutorial:ack');
 await click('nav:系统');await click('system:bills');
 await check('six mandatory operations complete on actual day-one bill preview',s=>s.panel==='账单'&&s.state.tutorial.finished&&!s.state.tutorial.skipped&&s.state.tutorial.completed_steps.length===6&&s.state.finance.bills.length===0);
 await shot('03a-day-one-bill');
 await chartShot('03a-bill-horizontal-legend');
 await click('finance:tab:资金流水');await check('cash flow panel shows real transaction records',s=>s.panel==='资金流水'&&s.state.finance.flows.length>=2);await shot('03b-cash-flows');
 const [csvDownload]=await Promise.all([page.waitForEvent('download'),click('finance:csv')]);await csvDownload.saveAs(path.join(out,'actual-cash-flows.csv'));
 await check('cash flow CSV is an actual browser download',s=>fs.statSync(path.join(out,'actual-cash-flows.csv')).size>30);
 await click('finance:tab:采购设置');await check('three procurement policies have actual controls',s=>s.panel==='采购设置'&&['auto','fixed','pause'].every(value=>s.buttons.some(b=>b.qa_id==='full:set_procurement_strategy:'+value)));await shot('03c-procurement');await click('panel:close');await click('nav:系统');
 await click('finance:loan');await check('stage-zero ordinary borrowing remains unavailable',s=>s.panel==='贷款'&&s.state.finance.loan.principal===0);await shot('03d-loans');await click('panel:close');await click('nav:系统');
 await click('finance:feedback');await check('feedback reflects the actual completed first order',s=>s.panel==='顾客反馈'&&s.state.customer_service.today.completed>=1);await shot('03e-feedback');
 await click('panel:close');await click('todo:summary');await check('top todo summary opens',s=>s.panel==='待办汇总');await shot('03f-todos');await click('panel:close');
 await check('real sale produces revenue',s=>s.state.total_revenue>0&&s.state.cash>0);
 await shot('03-operating');
 if((await state()).panel)await click('panel:close');
 await click('nav:更多');await click('full:open:库存供应');await shot('04-inventory');await click('panel:close');
 if(!(await state()).paused)await click('time:pause');
 const beforePurchase=(await state()).state.management.items.generic.quantity;const beforeCash=(await state()).state.cash;
 await click('stock:purchase');await check('sidebar purchase changes inventory and cash',s=>Math.abs(s.state.management.items.generic.quantity-beforePurchase-20)<0.001&&s.state.cash<beforeCash);
 await click('nav:图鉴');await check('all six encyclopedia tabs exist',s=>['员工','菜品','事件','羁绊','道具','装修'].every(x=>s.buttons.some(b=>b.qa_id==='catalog:'+x)));
 await click('catalog:道具');await shot('04b-item-catalog');await click('catalog:装修');await shot('04c-decoration-catalog');await click('panel:close');
 await click('nav:装修');await check('decoration drawer opens with navigation visible',s=>s.panel==='装修'&&s.buttons.some(b=>b.qa_id==='nav:员工'));await shot('04d-decoration-drawer');await click('panel:close');
 await click('nav:系统');await check('system menu pauses simulation',s=>s.panel==='系统'&&s.paused);await click('system:save');const saved=(await state()).last_saved_minute;fs.writeFileSync(path.join(out,'saved-state.json'),JSON.stringify(await state(),null,2));
 await page.waitForTimeout(6500);await page.reload();
 await waitFor(()=>window.shanhaiQAState?.panel==='欢迎',60000);
 await check('page reload restores progress',s=>s.state.served>=1&&s.state.total_minutes===saved&&s.state.tutorial.finished&&!s.state.tutorial.skipped);
 await shot('05-restored');
 await click('start:continue');await click('nav:系统');
 await click('system:developer');await click('dev:art');
 await shot('06-art-paths');
 const [chooser]=await Promise.all([page.waitForEvent('filechooser'),click('art:import')]);
 await chooser.setFiles({name:'qianyang_idle.png',mimeType:'image/png',buffer:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=','base64')});
 await page.waitForTimeout(1000);await shot('07-art-import');
 await check('art import replaces the resource',s=>s.panel==='美术资源'&&s.art_import.ok&&s.art_probe.available&&s.art_probe.custom_path.includes('CustomAssets'));
 const input=await physicalPoint((await state()).art_input_rect);await page.mouse.click(input.x,input.y);await page.keyboard.press('Control+A');await page.keyboard.type('UI/btn_employee.png');
 const [navChooser]=await Promise.all([page.waitForEvent('filechooser'),click('art:import')]);await navChooser.setFiles({name:'btn_employee.png',mimeType:'image/png',buffer:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=','base64')});await page.waitForTimeout(800);
 await check('navigation picture hot refreshes immediately',s=>s.nav_art_probe.available&&s.buttons.some(b=>b.qa_id==='nav:员工'&&b.icon_available));
 await click('panel:close');await click('nav:员工');await shot('08-custom-character');await click('panel:close');
 await click('nav:系统');await click('system:save');await page.waitForTimeout(6500);await page.reload();await waitFor(()=>window.shanhaiQAState?.panel==='欢迎',60000);
 await check('custom art persists after reload',s=>s.art_probe.available&&s.art_probe.custom_path.includes('CustomAssets'));
 await page.setViewportSize({width:844,height:390});await waitFor(()=>window.shanhaiQAState?.viewport.w<=850,10000);await click('start:continue');
 await check('phone landscape uses 44px real controls',s=>s.viewport.w<=850&&['nav:员工','nav:系统','nav:装修'].every(id=>s.buttons.some(b=>b.qa_id===id&&b.rect.h>=44&&b.rect.x+b.rect.w<=845&&b.rect.y+b.rect.h<=391)));
 const phoneGeometry=await page.evaluate(()=>{const s=window.shanhaiQAState,t=s.screen_transform,c=document.querySelector('canvas'),r=c.getBoundingClientRect();return {viewport:s.viewport,canvas:{x:r.x,y:r.y,w:r.width,h:r.height,backing_w:c.width,backing_h:c.height},transform:t,controls:['nav:员工','nav:系统','nav:装修'].map(id=>{const b=s.buttons.find(b=>b.qa_id===id);return {id,physical_height:Math.hypot(t.c*b.rect.h*r.width/c.width,t.d*b.rect.h*r.height/c.height)};})};});geometry.push(phoneGeometry);const physicalControls=phoneGeometry.canvas.x===0&&phoneGeometry.canvas.y===0&&Math.abs(phoneGeometry.canvas.w-844)<1&&Math.abs(phoneGeometry.canvas.h-390)<1&&phoneGeometry.controls.every(b=>b.physical_height>=43.99);checks.push({label:'phone canvas fills viewport and controls retain 44 CSS pixels',ok:physicalControls});if(!physicalControls)throw Error('phone physical canvas/control geometry failed');
 await shot('09-phone-landscape');await click('nav:装修');await check('phone decoration drawer remains actionable',s=>s.panel==='装修'&&s.buttons.some(b=>b.qa_id==='panel:close'&&b.rect.y+b.rect.h<=391));await shot('10-phone-drawer');await click('panel:close');
 await click('nav:系统');await click('system:bills');await chartShot('10a-phone-bill-horizontal-legend');await click('panel:close');
 await page.setViewportSize({width:390,height:844});await waitFor(()=>window.shanhaiQAState?.viewport.w<=400,10000);await shot('11-portrait-instruction');
 const ordinary=await browser.newPage({viewport:{width:1440,height:900}});await ordinary.goto(baseURL+'/');await ordinary.waitForTimeout(2500);checks.push({label:'ordinary players have no QA snapshot',ok:await ordinary.evaluate(()=>typeof window.shanhaiQAState==='undefined')});await ordinary.close();
 }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())??null,null,2));}
 let receipt={};try{receipt=await (await page.request.get(baseURL+'/export-receipt.json')).json();}catch{}
 const result={date:new Date().toISOString(),game_source:receipt.game_source,actions,checks,geometry,errors};fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({actions:actions.length,checks:checks.length,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
