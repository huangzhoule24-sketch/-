extends SceneTree

## Reproducible opening campaign audit using gameplay actions only.
## No direct cash, inventory, stage, employee or clock assignments.
const Model = preload("res://scripts/core/game_model.gd")
var actions: Array = []

func log_action(m, action: String, detail: Variant = null) -> void:
	actions.append({"minute":int(m.state.total_minutes),"action":action,"detail":detail})

func _init() -> void:
	call_deferred("run")

func run() -> void:
	var m = Model.new(20261015)
	m.start_full()
	var max_minutes := 7200
	var advanced := 0
	var first_order_minute := -1
	var research_started := false
	while advanced < max_minutes:
		var event: Dictionary = m.pending_event()
		if not event.is_empty():
			for index in range(event.get("options", []).size()):
				if m.choose_event(str(event.id), index):
					log_action(m, "event", {"id":str(event.id),"option":index})
					break
		for quest in m.quest_status():
			if bool(quest.complete) and not bool(quest.claimed) and m.claim_quest(str(quest.id)):
				log_action(m, "claim", str(quest.id))
		if int(m.state.served) > 0 and first_order_minute < 0:
			first_order_minute = int(m.state.total_minutes)
		if not m.state.contracts.is_empty():
			var recruited: Dictionary = m.recruit("contract")
			if not recruited.is_empty(): log_action(m, "contract", str(recruited.id))
		if not research_started and int(m.state.served) >= 1:
			var trial: Dictionary = m.full_rules.perform("tutorial_research")
			if bool(trial.get("ok", false)):
				research_started = true
				log_action(m, "tutorial_research")
		# Avoid selling the new meat recipe until its supplier is available.
		if "qianyang_soup" in m.state.menu_enabled:
			m.set_menu_enabled("qianyang_soup", false)
		if float(m.state.ingredients) < 10.0 and float(m.state.cash) >= 90.0:
			var stock: Dictionary = m.full_rules.perform("purchase", {"id":"generic","quantity":30})
			if bool(stock.get("ok", false)): log_action(m, "purchase", 30)
		if float(m.state.cash) > 1500.0 and float(m.state.debt) > 0.0:
			var debt_before := float(m.state.debt)
			if m.repay_debt(500): log_action(m, "repay", debt_before - float(m.state.debt))
		if int(m.state.stage) == 0 and bool(m.full_rules.can_perform("upgrade").get("ok", false)):
			if m.upgrade_restaurant():
				log_action(m, "upgrade", 1)
				break
		m.advance_minutes(1)
		advanced += 1
	var saved: bool = m.save_game("user://campaign-audit.json")
	var restored = Model.new(20261016)
	var loaded: bool = restored.load_game("user://campaign-audit.json")
	var result := {"seed":20261015,"gameplay_actions_only":true,"advanced_minutes":advanced,
		"first_order_minute":first_order_minute,"clock":m.clock_label(),"served":int(m.state.served),
		"lost":int(m.state.lost),"cash":float(m.state.cash),"debt":float(m.state.debt),
		"revenue":float(m.state.total_revenue),"reputation":int(m.state.reputation),"stage":int(m.state.stage),
		"recipes":m.state.unlocked_dishes,"employees":m.employees.map(func(e):return str(e.id)),
		"actions":actions,"save_written":saved,"save_loaded":loaded}
	var report_path := "res://build/campaign-opening-audit.json"
	DirAccess.make_dir_recursive_absolute("res://build")
	var report := FileAccess.open(report_path, FileAccess.WRITE)
	if report != null: report.store_string(JSON.stringify(result,"  ")); report.close()
	print(JSON.stringify(result))
	quit(0 if int(m.state.served) > 0 and first_order_minute > 0 and bool(result.save_written) and bool(result.save_loaded) else 1)
