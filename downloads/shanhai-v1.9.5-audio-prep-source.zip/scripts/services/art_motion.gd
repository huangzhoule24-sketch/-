extends RefCounted
## Visual gait only; authoritative paths/speed and RNG are unchanged.
const FLY=["xiao","guan_guan","gu_diao","qing_fu","bi_fang","ying_zhao","jing_wei","qiong_qi","qing_geng","feng_huang","ying_long","di_jiang","beastkin_03"]
const CRAWL=["xuan_gui","zhu_long","ran_yi_yu"]
static func kind(id: String) -> String:
	id=id.get_slice("_awakened",0)
	return "fly" if id in FLY else "crawl" if id in CRAWL else "walk"
static func lift(id: String,action: String) -> float:return 4.0 if kind(id)=="fly" and action.to_lower() in ["move","walk","idle"] else 0.0
