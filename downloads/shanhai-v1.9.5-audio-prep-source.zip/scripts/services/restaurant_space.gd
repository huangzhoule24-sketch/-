class_name RestaurantSpace
extends RefCounted
## Canonical restaurant geometry shared by simulation and presentation.
const Navigation = preload("res://scripts/services/grid_navigation.gd")
const WORLD_SIZE := Vector2(1020, 560)
static var _presentation: Dictionary = {}
static func presentation(key: String,fallback: float) -> float:
	if _presentation.is_empty():
		var data = JSON.parse_string(FileAccess.get_file_as_string("res://config/experience.json"))
		if data is Dictionary: _presentation = data.get("presentation",{})
	return float(_presentation.get(key,fallback))

static func grid_dimensions(model) -> Vector2i:
	if model != null and str(model.state.get("mode", "normal")) == "full":
		return Vector2i(maxi(1, int(model.full_rules.setting("layout", "width", 8))), maxi(1, int(model.full_rules.setting("layout", "height", 5))))
	var bounds: Dictionary = model.demo_config.get("layout", {}) if model != null and "demo_config" in model else {}
	return Vector2i(maxi(1, int(bounds.get("width", 6))), maxi(1, int(bounds.get("height", 4))))

static func world_size(model=null) -> Vector2:
	var d=model.state.get("revision191",{}) if model!=null else {}
	return Vector2(52+float(d.get("cell_width",121))*int(d.get("grid_width",8)),560) if not d.is_empty() else WORLD_SIZE

static func grid_rect(model = null) -> Rect2:
	return Rect2(26,96,world_size(model).x-52,402)

static func cell_rect(model, x: int, y: int, columns: int = 1, rows: int = 1) -> Rect2:
	var bounds := grid_rect(model)
	var step := bounds.size / Vector2(grid_dimensions(model))
	return Rect2(bounds.position + Vector2(x, y) * step, Vector2(columns, rows) * step)

static func layout(model) -> Array:
	var saved: Array = model.state.get("layout", []) if model != null else []
	if not saved.is_empty(): return saved
	return [
		{"id":"table_two", "x":1, "y":0, "w":1, "h":1},
		{"id":"table_two", "x":4, "y":0, "w":1, "h":1},
		{"id":"table_two", "x":1, "y":2, "w":1, "h":1},
		{"id":"table_two", "x":4, "y":2, "w":1, "h":1}]

static func chair_position(rect: Rect2, chair: int, capacity: int) -> Vector2:
	var center := rect.get_center()
	if capacity == 4 and chair >= 2:
		return center + Vector2(0, -minf(rect.size.y * 0.3, 38) if chair == 2 else minf(rect.size.y * 0.3, 38))
	return center + Vector2(-minf(rect.size.x * 0.35, 52) if chair == 0 else minf(rect.size.x * 0.35, 52), 0)

static func _seat_info(model, seat: int) -> Dictionary:
	var cursor := 0
	for item in layout(model):
		if bool(item.get("building",false)): continue
		if not str(item.get("id", "")) in ["table_two", "table_four"]: continue
		var capacity := 4 if str(item.id) == "table_four" else 2
		if seat < cursor + capacity:
			var rect := cell_rect(model, int(item.x), int(item.y), int(item.get("w", 1)), int(item.get("h", 1)))
			return {"rect":rect, "chair":seat - cursor, "capacity":capacity}
		cursor += capacity
	return {}

static func seat_position(model, seat: int) -> Vector2:
	var info := _seat_info(model, seat)
	if info.is_empty(): return grid_rect(model).get_center()
	return chair_position(info.rect, int(info.chair), int(info.capacity))

static func service_point(model, seat: int) -> Vector2:
	var info := _seat_info(model, seat)
	if info.is_empty(): return grid_rect(model).get_center()
	var rect: Rect2 = info.rect
	var center := rect.get_center()
	var direction := (chair_position(rect, int(info.chair), int(info.capacity)) - center).normalized()
	var extent := table_extent(rect)
	# Each chair is approached from its own side, always outside the tabletop.
	var distance := (extent.x if absf(direction.x) > 0.5 else extent.y) * 0.5 + 16.0
	return center + direction * maxf(distance, center.distance_to(chair_position(rect, int(info.chair), int(info.capacity))))

static func table_extent(rect: Rect2) -> Vector2:
	return Vector2(minf(64, rect.size.x * 0.46), minf(54, rect.size.y * 0.54))

static func obstacles(model) -> Array[Rect2]:
	return layout_obstacles(model,layout(model))

static func layout_obstacles(model,items: Array) -> Array[Rect2]:
	var result: Array[Rect2] = []
	for item in items:
		var rect := cell_rect(model, int(item.x), int(item.y), int(item.get("w", 1)), int(item.get("h", 1)))
		var extent: Vector2
		match str(item.get("id", "")):
			"table_two", "table_four": extent = table_extent(rect)
			"wall_mural": extent = Vector2(58, 50)
			"lantern": extent = Vector2(32, 35)
			"kitchen": extent = Vector2(minf(86,rect.size.x*.65),49)
			"stove","basic_pass","serving_counter","basic_cashier","cashier","promotion_board","staff_corner":extent=Vector2(minf(46,rect.size.x*.60),minf(46,rect.size.y*.55))
			_: extent = Vector2(minf(46, rect.size.x * 0.65), minf(62, rect.size.y * 0.7))
		result.append(Rect2(rect.get_center() - extent * 0.5, extent))
	return result

static func interact_point(model,item: Dictionary) -> Vector2:
	var rect=cell_rect(model,int(item.x),int(item.y),int(item.get("w",1)),int(item.get("h",1)))
	return rect.get_center()+Vector2(0,minf(28,rect.size.y*.3)+20)

static func layout_is_safe(model,items: Array) -> bool:
	var walls = layout_obstacles(model,items)
	if model.state.has("revision191"):
		var rules=model.full_rules.dollhouse
		for order in model.customers:
			var held=str(order.get("device_uid",""))
			if not held.is_empty() and not items.any(func(item):return rules.identity(item)==held):return false
		for job in model.state.revision191.aux_jobs.values():
			if not items.any(func(item):return rules.identity(item)==str(job.device_uid)):return false
		for item in items:
			if rules.kind(item) in ["stove","pass","cashier","promotion","rest"]:
				var point=interact_point(model,item)
				if not Navigation.point_is_clear(point,walls) or bool(preload("res://scripts/services/dollhouse_navigation.gd").find_path(entry_position(model),point,walls,walk_bounds(model)).blocked):return false
	var entry = entry_position(model)
	if not Navigation.point_is_clear(entry,walls): return false
	# Existing in-flight routes and workers must not be covered by a new item.
	for employee in model.employees:
		if not str(employee.get("branch_id","")).is_empty(): continue
		var position: Vector2 = model.motion_position(employee) if model.has_method("motion_position") else entry
		if not Navigation.point_is_clear(position,walls): return false
		var motion: Dictionary = employee.get("motion",{})
		var path: Array[Vector2] = []
		for point in motion.get("path",[]): path.append(Vector2(float(point.x),float(point.y)))
		# Ignore already traversed path segments; validate the remainder only.
		var origin = model._motion_point(motion.get("origin",{})) if model.has_method("_motion_point") else position
		var elapsed = maxf(0,float(model.state.total_minutes)-float(motion.get("started",model.state.total_minutes)))
		var walked = Navigation.advance(origin,path,0,elapsed*float(motion.get("speed",0)))
		var previous = position
		var grown: Array = walls.map(func(rect):return rect.grow(4))
		for point in path.slice(int(walked.waypoint)):
			if not Navigation.segment_is_clear(previous,point,grown): return false
			previous = point
	# Every side of every table needs a path from the door.
	for item in items:
		if not str(item.id) in ["table_two","table_four"]: continue
		var rect = cell_rect(model,item.x,item.y,item.w,item.h)
		var capacity = 4 if str(item.id) == "table_four" else 2
		for chair in range(capacity):
			var direction = (chair_position(rect,chair,capacity)-rect.get_center()).normalized()
			var extent = table_extent(rect)
			var distance = maxf((extent.x if absf(direction.x)>0.5 else extent.y)*0.5+16,rect.get_center().distance_to(chair_position(rect,chair,capacity)))
			if bool(Navigation.find_path(entry,rect.get_center()+direction*distance,walls,walk_bounds(model)).blocked): return false
	return true

static func walk_bounds(model=null) -> Rect2:
	return Rect2(8,80,world_size(model).x-16,472)

static func entry_position(model=null) -> Vector2:
	return Vector2(42,455) if model!=null and model.state.has("revision191") else Vector2(WORLD_SIZE.x*.5,WORLD_SIZE.y-48)

static func station_position(model, role: String, slot: int = 0) -> Vector2:
	if role == "all": role = "waiter"
	var spacing = presentation("station_spacing",68)
	var horizontal := 0.2 if role == "chef" else (0.8 if role == "salesman" else (0.94 if role == "tutor" else 0.5))
	var desired := Vector2(WORLD_SIZE.x * horizontal - 25 + (slot % 3) * spacing, 102 + (slot / 3) * spacing)
	if role == "rest": desired = Vector2(WORLD_SIZE.x - 74 - (slot % 5) * 62, WORLD_SIZE.y - 62 - (slot / 5) * 58)
	if Navigation.point_is_clear(desired, obstacles(model)): return desired
	var nearby := Navigation.nearest_reachable_target(entry_position(model), desired, obstacles(model), walk_bounds(model).expand(desired).grow(0.01))
	return nearby.get("point", desired) if not bool(nearby.blocked) else desired

static func _slot(model, employee: Dictionary) -> int:
	var slot := 0
	for other in model.employees:
		if str(other.get("id", "")) == str(employee.get("id", "")): break
		if str(other.get("branch_id", "")) == "" and _bucket(model,other) == _bucket(model,employee): slot += 1
	return slot

static func _bucket(model,employee: Dictionary) -> String:
	var now = int(model.state.get("total_minutes",0))
	if bool(employee.get("resting",false)) or int(employee.get("management_until",0)) > now or int(employee.get("training_until",0)) > now: return "rest"
	var role = str(employee.get("role","waiter"))
	return "waiter" if role == "all" else role

static func reserved_point(model,employee: Dictionary,desired: Vector2,spawn: bool = false,require_route: bool = true) -> Vector2:
	var occupied: Array[Vector2] = []
	for other in model.employees:
		if str(other.id) == str(employee.id) or not str(other.get("branch_id","")).is_empty() or int(other.get("expansion_until",0)) > int(model.state.total_minutes): continue
		if other.get("motion",{}).is_empty(): continue
		var point: Dictionary = other.motion.get("target",{})
		occupied.append(model.motion_position(other) if spawn else Vector2(float(point.get("x",0)),float(point.get("y",0))))
	var walls = obstacles(model)
	var origin: Vector2 = entry_position(model) if employee.get("motion",{}).is_empty() else model.motion_position(employee)
	var candidates: Array[Vector2] = [desired]
	var spacing = presentation("body_spacing",44)
	for ring in range(1,6):
		for direction in [Vector2.LEFT,Vector2.RIGHT,Vector2.UP,Vector2.DOWN,Vector2(-1,-1),Vector2(1,-1),Vector2(-1,1),Vector2(1,1)]: candidates.append(desired+direction*(spacing+4)*ring)
	for point in candidates:
		if not walk_bounds(model).has_point(point) or not Navigation.point_is_clear(point,walls): continue
		var free = true
		for used in occupied:
			if point.distance_to(used) < spacing: free = false;break
		if free and (not require_route or not bool(Navigation.find_path(origin,point,walls,walk_bounds(model).expand(origin).grow(0.01)).blocked)): return point
	return Vector2(INF,INF)

static func spawn_position(model,employee: Dictionary) -> Vector2:
	var point = reserved_point(model,employee,entry_position(model),true)
	return point if point.is_finite() else entry_position(model)

static func employee_station(model,employee: Dictionary) -> Vector2:
	if model.state.has("revision191"):return model.full_rules.dollhouse.idle_target(employee)
	return reserved_point(model,employee,station_position(model,_bucket(model,employee),_slot(model,employee)))

static func task_target(model, employee: Dictionary, customer: Dictionary) -> Vector2:
	var desired: Vector2
	match str(customer.get("stage", "")):
		"queued", "cooking": desired = station_position(model, "chef", _slot(model, employee))
		"paying": desired = station_position(model, "salesman", _slot(model, employee))
		_: desired = service_point(model, int(customer.get("seat", 0)))
	return reserved_point(model,employee,desired,false,false)

static func find_route(model, origin: Vector2, target: Vector2, ignore: bool = false) -> Dictionary:
	if not origin.is_finite() or not target.is_finite(): return {"points":[],"blocked":true,"length":0.0}
	if ignore: return {"points":[target], "blocked":false, "length":origin.distance_to(target)}
	return (preload("res://scripts/services/dollhouse_navigation.gd") if model.state.has("revision191") else Navigation).find_path(origin,target,obstacles(model),walk_bounds(model).expand(origin).expand(target).grow(0.01))
