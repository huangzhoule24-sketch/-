extends RefCounted
## Canonical v1.9.3 employee IDs; compatibility is applied before validating old saves.
const OLD_TO_NEW = {"qianyang": "xian_yang", "owl": "xiao", "earmouse": "er_shu", "guanguan": "guan_guan", "eshou": "e_shou", "taotie": "tao_tie", "ranyiyu": "ran_yi_yu", "dangkang": "dang_kang", "tiangou": "tian_gou", "gudiao": "gu_diao", "xuangui": "xuan_gui", "qingfu": "qing_fu", "nine_tailed_fox": "jiu_wei_hu", "bifang": "bi_fang", "pixiu": "pi_xiu", "yingzhao": "ying_zhao", "luwu": "lu_wu", "jingwei": "jing_wei", "qiongqi": "qiong_qi", "taowu": "tao_wu", "hundun": "hun_dun", "xiezhi": "xie_zhi", "qinggeng": "qing_geng", "tianlu": "tian_lu", "phoenix": "feng_huang", "baize": "bai_ze", "yinglong": "ying_long", "zhulong": "zhu_long", "dijiang": "di_jiang", "jiuying": "jiu_ying"}
static func canonical(id: String) -> String:
    if OLD_TO_NEW.has(id):return str(OLD_TO_NEW[id])
    for old in OLD_TO_NEW:
        if id.begins_with(old+"_awakened"):return str(OLD_TO_NEW[old])+id.trim_prefix(old)
    return id
static func legacy(id: String) -> String:
    for old in OLD_TO_NEW:
        if OLD_TO_NEW[old]==id:return old
        if id.begins_with(str(OLD_TO_NEW[old])+"_awakened"):return str(old)+id.trim_prefix(str(OLD_TO_NEW[old]))
    return id
static func migrate(value: Variant) -> Variant:
    if value is Dictionary:
        var out: Dictionary={}
        for key in value:
            var converted=migrate(key) if key is String else key
            # Reject ambiguous collisions rather than silently overwriting progress.
            if out.has(converted):return value
            out[converted]=migrate(value[key])
        return out
    if value is Array:
        var out: Array=[]
        for item in value:out.append(migrate(item))
        return out
    if value is String:
        if OLD_TO_NEW.has(value):return OLD_TO_NEW[value]
        if ":" in value:
            var parts=value.split(":")
            for index in parts.size():
                if OLD_TO_NEW.has(parts[index]):parts[index]=str(OLD_TO_NEW[parts[index]])
            value=":".join(parts)
        for old in OLD_TO_NEW:
            if value.begins_with(old+"_awakened"):return str(OLD_TO_NEW[old])+value.trim_prefix(old)
            if value.begins_with("employee."+old+"."):return "employee."+str(OLD_TO_NEW[old])+value.trim_prefix("employee."+old)
    return value
