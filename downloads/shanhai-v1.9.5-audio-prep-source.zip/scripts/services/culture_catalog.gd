class_name CultureCatalog
extends RefCounted
## Offline cultural reading. Citations are data; loading never opens a URL.

const DEFAULT_PATH := "res://config/culture.json"
const KINDS := ["employees", "dishes"]

var data: Dictionary = {}
var errors: Array[String] = []
var _sources: Dictionary = {}


func _init(path: String = DEFAULT_PATH) -> void:
	if not FileAccess.file_exists(path):
		errors.append("文化资料文件不存在")
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not parsed is Dictionary:
		errors.append("文化资料不是JSON对象")
		return
	errors = validate(parsed)
	if not errors.is_empty(): return
	data = parsed
	for source in data.sources:
		_sources[str(source.id)] = source


func get_entry(kind: String, id: String) -> Dictionary:
	if not kind in KINDS: return {}
	var entry = data.get(kind, {}).get(id, {})
	return entry.duplicate(true) if entry is Dictionary else {}


func entry_ids(kind: String) -> Array:
	if not kind in KINDS: return []
	var ids: Array = data.get(kind, {}).keys()
	ids.sort()
	return ids


func sources_for(entry: Dictionary) -> Array:
	var result: Array = []
	for id in entry.get("source_ids", []):
		if _sources.has(str(id)): result.append(_sources[str(id)].duplicate(true))
	return result


func get_source(id: String) -> Dictionary:
	return _sources.get(id, {}).duplicate(true)


static func safe_source_url(url: String) -> bool:
	if not url.begins_with("https://") or url.length() > 2048: return false
	for index in range(url.length()):
		if url.unicode_at(index) <= 32 or url.unicode_at(index) == 127: return false
	var host: String = url.trim_prefix("https://").split("/")[0]
	return not host.is_empty() and not "@" in host and "." in host


static func validate(candidate: Dictionary, employee_ids: Array = [], dish_ids: Array = []) -> Array[String]:
	var issues: Array[String] = []
	if candidate.get("schema_version") != 1: issues.append("未知文化资料版本")
	if not candidate.get("sources") is Array:
		issues.append("缺少来源清单")
		return issues
	var source_ids: Dictionary = {}
	for source in candidate.sources:
		if not source is Dictionary:
			issues.append("来源不是对象")
			continue
		var id: String = str(source.get("id", ""))
		if id.is_empty() or source_ids.has(id): issues.append("空或重复的来源ID：" + id)
		source_ids[id] = true
		for field in ["title", "work", "chapter", "url", "accessed_on", "kind"]:
			if not source.get(field) is String or str(source[field]).strip_edges().is_empty(): issues.append("来源字段缺失：%s/%s" % [id, field])
		if not safe_source_url(str(source.get("url", ""))): issues.append("来源地址无效：" + id)
		if not str(source.get("kind", "")) in ["primary", "institutional", "secondary"]: issues.append("来源类型无效：" + id)
	for kind in KINDS:
		if not candidate.get(kind) is Dictionary:
			issues.append("缺少简介类别：" + kind)
			continue
		var expected: Array = employee_ids if kind == "employees" else dish_ids
		for id in expected:
			if not candidate[kind].has(str(id)): issues.append("缺少简介：%s/%s" % [kind, id])
		for id in candidate[kind]:
			var entry = candidate[kind][id]
			if not entry is Dictionary:
				issues.append("简介不是对象：" + str(id))
				continue
			for field in ["name", "pinyin", "origin_label", "summary"]:
				if not entry.get(field) is String or str(entry[field]).strip_edges().is_empty(): issues.append("简介字段缺失：%s/%s" % [id, field])
			if not entry.get("sections") is Array or entry.sections.size() < 3:
				issues.append("简介应区分至少三个阅读层次：" + str(id))
				continue
			var references = entry.get("source_ids", [])
			if not references is Array or references.is_empty():
				issues.append("简介没有来源：" + str(id))
				continue
			for reference in references:
				if not source_ids.has(str(reference)): issues.append("简介引用未登记来源：%s/%s" % [id, reference])
			for section in entry.sections:
				if not section is Dictionary or str(section.get("title", "")).is_empty() or str(section.get("text", "")).is_empty():
					issues.append("空简介段落：" + str(id))
					continue
				if not section.get("source_ids", []) is Array:
					issues.append("段落引用不是数组：" + str(id))
					continue
				for reference in section.get("source_ids", []):
					if not str(reference) in references: issues.append("段落引用未列入简介来源：%s/%s" % [id, reference])
			if not entry.get("quotes", []) is Array:
				issues.append("原文摘录不是数组：" + str(id))
				continue
			for quote in entry.get("quotes", []):
				if not quote is Dictionary or str(quote.get("text", "")).is_empty() or not str(quote.get("source_id", "")) in references: issues.append("原文摘录引用无效：" + str(id))
	return issues
