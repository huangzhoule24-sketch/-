extends RefCounted
## Small visibility graph over physical furniture rectangles, not occupied build cells.
## Routes contain real walkable corners; the caller advances each segment smoothly.
const CORNER_GAP := 0.25

static func point_is_clear(point: Vector2, furniture: Array, clearance: float = 4.0) -> bool:
	for item in furniture:
		if item is Rect2 and item.grow(maxf(0.0, clearance)).has_point(point): return false
	return true

static func nearest_reachable_target(start: Vector2, desired: Vector2, furniture: Array, bounds: Rect2, clearance: float = 4.0) -> Dictionary:
	# Staff station slots are presentation anchors, so a crowded kitchen may use
	# a neighbouring clear spot. Customer table approaches never use this method.
	if not point_is_clear(start, furniture, clearance): return {"point": desired, "blocked": true, "points": []}
	var candidates: Array[Vector2] = [desired]
	for item in furniture:
		if not item is Rect2: continue
		var rect: Rect2 = item.grow(maxf(0.0, clearance) + CORNER_GAP)
		var x := clampf(desired.x, rect.position.x, rect.end.x)
		var y := clampf(desired.y, rect.position.y, rect.end.y)
		for point in [Vector2(rect.position.x, y), Vector2(rect.end.x, y), Vector2(x, rect.position.y), Vector2(x, rect.end.y), rect.position, rect.end, Vector2(rect.position.x, rect.end.y), Vector2(rect.end.x, rect.position.y)]:
			if bounds.has_point(point) and point_is_clear(point, furniture, clearance) and not point in candidates: candidates.append(point)
	candidates.sort_custom(func(first: Vector2, second: Vector2): return first.distance_squared_to(desired) < second.distance_squared_to(desired))
	for point in candidates:
		var route := find_path(start, point, furniture, bounds, clearance)
		if not bool(route.blocked):
			route["point"] = point
			return route
	return {"point": desired, "blocked": true, "points": []}

static func find_path(start: Vector2, goal: Vector2, furniture: Array, bounds: Rect2, clearance: float = 4.0) -> Dictionary:
	var obstacles: Array[Rect2] = []
	for item in furniture:
		if item is Rect2 and item.has_area(): obstacles.append(item.grow(maxf(0.0, clearance)))
	if not _point_free(start, obstacles, bounds) or not _point_free(goal, obstacles, bounds):
		return {"points": [], "blocked": true, "length": 0.0}
	if segment_is_clear(start, goal, obstacles):
		return {"points": [goal], "blocked": false, "length": start.distance_to(goal)}
	var vertices: Array[Vector2] = [start, goal]
	for rect in obstacles:
		var outer := rect.grow(CORNER_GAP)
		for corner in [outer.position, Vector2(outer.end.x, outer.position.y), outer.end, Vector2(outer.position.x, outer.end.y)]:
			if _point_free(corner, obstacles, bounds): vertices.append(corner)
	var cost: Array[float] = []
	var previous: Array[int] = []
	var visited: Array[bool] = []
	for index in range(vertices.size()):
		cost.append(INF)
		previous.append(-1)
		visited.append(false)
	cost[0] = 0.0
	# Dijkstra checks visibility lazily. Direct-line tasks never build a graph.
	for iteration in range(vertices.size()):
		var current := -1
		var cheapest := INF
		for index in range(vertices.size()):
			if not visited[index] and cost[index] < cheapest:
				current = index
				cheapest = cost[index]
		if current < 0: break
		if current == 1: break
		visited[current] = true
		for index in range(1, vertices.size()):
			if visited[index] or current == index: continue
			var candidate := cost[current] + vertices[current].distance_to(vertices[index])
			if candidate < cost[index] and segment_is_clear(vertices[current], vertices[index], obstacles):
				cost[index] = candidate
				previous[index] = current
	if not is_finite(cost[1]): return {"points": [], "blocked": true, "length": 0.0}
	var points: Array[Vector2] = []
	var cursor := 1
	while cursor > 0:
		points.push_front(vertices[cursor])
		cursor = previous[cursor]
	return {"points": points, "blocked": false, "length": cost[1]}

static func _point_free(point: Vector2, obstacles: Array[Rect2], bounds: Rect2) -> bool:
	if not bounds.grow(0.001).has_point(point): return false
	for rect in obstacles:
		if rect.has_point(point): return false
	return true

static func segment_is_clear(start: Vector2, goal: Vector2, obstacles: Array) -> bool:
	for obstacle in obstacles:
		if obstacle is Rect2 and _segment_hits_rect(start, goal, obstacle): return false
	return true

static func _segment_hits_rect(start: Vector2, goal: Vector2, rect: Rect2) -> bool:
	# Slab intersection is deterministic for axis-aligned and zero-length segments.
	var offset := goal - start
	var entry := 0.0
	var exit := 1.0
	for axis in [0, 1]:
		if absf(offset[axis]) < 0.000001:
			if start[axis] < rect.position[axis] or start[axis] > rect.end[axis]: return false
		else:
			var first: float = (rect.position[axis] - start[axis]) / offset[axis]
			var second: float = (rect.end[axis] - start[axis]) / offset[axis]
			entry = maxf(entry, minf(first, second))
			exit = minf(exit, maxf(first, second))
			if entry > exit: return false
	return true

static func remaining_length(position: Vector2, points: Array, waypoint: int = 0) -> float:
	var distance := 0.0
	var previous := position
	for index in range(maxi(0, waypoint), points.size()):
		distance += previous.distance_to(points[index])
		previous = points[index]
	return distance

static func advance(position: Vector2, points: Array, waypoint: int, distance: float) -> Dictionary:
	var current := position
	var cursor := maxi(0, waypoint)
	var remaining := maxf(0.0, distance)
	while cursor < points.size() and remaining > 0.0:
		var next: Vector2 = current.move_toward(points[cursor], remaining)
		remaining = maxf(0.0, remaining - current.distance_to(next))
		current = next
		if current.distance_squared_to(points[cursor]) > 0.000001: break
		cursor += 1
	return {"position": current, "waypoint": cursor}
