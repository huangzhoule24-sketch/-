extends RefCounted
## Deterministic orthogonal grid search. Called only when assigning/rebasing a route.
const Geometry=preload("res://scripts/services/grid_navigation.gd")
const STEP=16.0
static var cache: Dictionary={}
static var searches=0
static func find_path(start: Vector2,goal: Vector2,walls: Array,bounds: Rect2) -> Dictionary:
	var fail={"points":[],"blocked":true,"length":0.0}
	if not start.is_finite() or not goal.is_finite() or not Geometry.point_is_clear(start,walls) or not Geometry.point_is_clear(goal,walls):return fail
	var grown=walls.map(func(r):return r.grow(4.0))
	# Straight orthogonal travel and unobstructed L bends remain on the grid axes.
	for bend in [Vector2(goal.x,start.y),Vector2(start.x,goal.y)]:
		if bounds.has_point(bend) and Geometry.segment_is_clear(start,bend,grown) and Geometry.segment_is_clear(bend,goal,grown):
			var points: Array[Vector2]=[]
			if not bend.is_equal_approx(start):points.append(bend)
			if points.is_empty() or not goal.is_equal_approx(points.back()):points.append(goal)
			return {"points":points,"blocked":false,"length":start.distance_to(bend)+bend.distance_to(goal)}
	var key=hash([start,goal,walls,bounds])
	if cache.has(key):return cache[key].duplicate(true)
	searches+=1
	var columns=int(ceil(bounds.size.x/STEP));var rows=int(ceil(bounds.size.y/STEP))
	var endpoints: Array[Vector2i]=[]
	for endpoint in [start,goal]:
		var cell=Vector2i((endpoint-bounds.position)/STEP);var best=Vector2i(-1,-1);var distance=INF
		for dx in range(-2,3):
			for dy in range(-2,3):
				var c=cell+Vector2i(dx,dy);var p=bounds.position+(Vector2(c)+Vector2(.5,.5))*STEP
				if c.x<0 or c.y<0 or c.x>=columns or c.y>=rows or not bounds.has_point(p):continue
				if Geometry.point_is_clear(p,walls) and Geometry.segment_is_clear(endpoint,p,grown) and endpoint.distance_squared_to(p)<distance:best=c;distance=endpoint.distance_squared_to(p)
		if best.x<0:return fail
		endpoints.append(best)
	var queue: Array[Vector2i]=[endpoints[0]];var cursor=0;var previous={endpoints[0]:Vector2i(-1,-1)}
	while cursor<queue.size() and not previous.has(endpoints[1]):
		var cell=queue[cursor];cursor+=1
		var point=bounds.position+(Vector2(cell)+Vector2(.5,.5))*STEP
		for direction in [Vector2i.RIGHT,Vector2i.LEFT,Vector2i.DOWN,Vector2i.UP]:
			var next=cell+direction
			if next.x<0 or next.y<0 or next.x>=columns or next.y>=rows or previous.has(next):continue
			var p=bounds.position+(Vector2(next)+Vector2(.5,.5))*STEP
			if bounds.has_point(p) and Geometry.point_is_clear(p,walls) and Geometry.segment_is_clear(point,p,grown):previous[next]=cell;queue.append(next)
	if not previous.has(endpoints[1]):return fail
	var route: Array[Vector2]=[goal];var cell=endpoints[1]
	while cell.x>=0:route.push_front(bounds.position+(Vector2(cell)+Vector2(.5,.5))*STEP);cell=previous[cell]
	# Remove collinear intermediate cells, retaining collision-safe right-angle turns.
	for i in range(route.size()-2,0,-1):
		if absf((route[i]-route[i-1]).cross(route[i+1]-route[i]))<.001:route.remove_at(i)
	var result={"points":route,"blocked":false,"length":Geometry.remaining_length(start,route)}
	if cache.size()>=512:cache.clear()
	cache[key]=result.duplicate(true);return result
