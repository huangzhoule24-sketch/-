extends Node
## Audio is a presentation service. It never reads/writes the campaign or its RNG.
signal changed
const CONFIG_PATH = "res://config/audio.json"
const CHANNELS = {"master":"Master", "music":"Music", "sfx":"SFX", "ambience":"Ambience"}
const EXTENSIONS = ["ogg", "mp3", "wav"]
const MAX_BYTES = 64 * 1024 * 1024
var builtin_root: String
var custom_root: String
var settings_path: String
var config: Dictionary = {}
var levels = {"master":0.8, "music":0.65, "sfx":0.75, "ambience":0.4}
var muted = false
var world_paused = true
var unlocked = false
var requested_music = ""
var requested_ambience = ""
var music_starts = 0
var played: Dictionary = {}
var last_errors: Array[String] = []
var _cache: Dictionary = {}
var _overrides: Dictionary = {}
var _next_allowed: Dictionary = {}
var _variant: Dictionary = {}
var _music: Array[AudioStreamPlayer] = []
var _ambient: Array[AudioStreamPlayer] = []
var _voices: Array[AudioStreamPlayer] = []
var _preview: AudioStreamPlayer
var _active = {"music":-1, "ambience":-1}
var _current = {"music":"", "ambience":""}
var _fades: Dictionary = {}
var _clock = 0.0
var _save_in = -1.0

func _init(builtin_directory = "res://assets/audio", custom_directory = "", preferences = "user://audio_settings.cfg"):
	builtin_root = builtin_directory.trim_suffix("/")
	custom_root = custom_directory.trim_suffix("/") if not custom_directory.is_empty() else default_custom_root()
	settings_path = preferences

static func default_custom_root() -> String:
	if OS.has_feature("web"): return "user://CustomAudio"
	if OS.has_feature("editor"): return "res://CustomAudio"
	return OS.get_executable_path().get_base_dir().path_join("CustomAudio")

func _ready():
	for channel in ["Music", "SFX", "Ambience"]:
		if AudioServer.get_bus_index(channel) < 0:
			AudioServer.add_bus(); var index = AudioServer.bus_count - 1
			AudioServer.set_bus_name(index, channel); AudioServer.set_bus_send(index, "Master")
	for i in range(2):
		_music.append(_player("Music")); _ambient.append(_player("Ambience"))
	for i in range(8): _voices.append(_player("SFX"))
	_preview = _player("SFX")
	_preview.finished.connect(stop_preview)
	unlocked = not OS.has_feature("web")
	_load_settings(); _apply_levels(); reload()

func _player(bus_name: String) -> AudioStreamPlayer:
	var player = AudioStreamPlayer.new(); player.bus = bus_name
	add_child(player); return player

func _process(delta: float):
	_clock += maxf(0, delta)
	if _save_in >= 0:
		_save_in -= delta
		if _save_in < 0: save_settings()

func _exit_tree():
	if _save_in >= 0: save_settings()

func unlock():
	if unlocked: return
	unlocked = true
	_switch_loop("music", requested_music, true)
	_switch_loop("ambience", requested_ambience, true)

func reload():
	stop_preview()
	for tween in _fades.values():
		if is_instance_valid(tween): tween.kill()
	_fades.clear()
	for player in _music + _ambient + _voices: player.stop()
	_cache.clear(); _next_allowed.clear(); last_errors.clear()
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(CONFIG_PATH))
	config = parsed if parsed is Dictionary else {}
	_active = {"music":-1, "ambience":-1}; _current = {"music":"", "ambience":""}
	_switch_loop("music", requested_music, true); _switch_loop("ambience", requested_ambience, true)
	changed.emit()

static func safe_path(path: String) -> bool:
	return not path.is_empty() and not path.is_absolute_path() and not ":" in path and not "\\" in path and not ".." in path.split("/") and path.get_extension().to_lower() in EXTENSIONS

func _candidates(cue: String) -> Array:
	var definition: Dictionary = config.get("cues", {}).get(cue, {})
	var result: Array = []
	var override = str(_overrides.get(cue, ""))
	if safe_path(override): result.append(override)
	for base in definition.get("files", []):
		if not safe_path(str(base)): continue
		for ext in EXTENSIONS:
			var file = str(base).get_basename() + "." + ext
			if not file in result: result.append(file)
	return result

func resource_paths(cue: String) -> Array:
	# Custom files have priority over every bundled format, not only a matching suffix.
	var result: Array = []
	for root_path in [custom_root, builtin_root]:
		for relative in _candidates(cue):
			var path = root_path.path_join(relative)
			if FileAccess.file_exists(path) or (root_path == builtin_root and ResourceLoader.exists(path)):
				result.append(path)
	return result

func _decode(bytes: PackedByteArray, extension: String) -> AudioStream:
	if bytes.size() < 16 or bytes.size() > MAX_BYTES: return null
	match extension:
		"ogg":
			if bytes.slice(0,4).get_string_from_ascii() != "OggS": return null
			return AudioStreamOggVorbis.load_from_buffer(bytes)
		"wav":
			if bytes.slice(0,4).get_string_from_ascii() != "RIFF" or bytes.slice(8,12).get_string_from_ascii() != "WAVE": return null
			return AudioStreamWAV.load_from_buffer(bytes)
		"mp3":
			if bytes.slice(0,3).get_string_from_ascii() != "ID3" and not (bytes[0] == 255 and (bytes[1] & 224) == 224): return null
			return AudioStreamMP3.load_from_buffer(bytes)
	return null

func _stream(path: String) -> AudioStream:
	if _cache.has(path): return _cache[path]
	var stream: AudioStream
	if path.begins_with("res://assets/audio/") and ResourceLoader.exists(path):
		stream = load(path) as AudioStream
	else:
		var file = FileAccess.open(path, FileAccess.READ)
		if file != null and file.get_length() <= MAX_BYTES:
			stream = _decode(file.get_buffer(file.get_length()), path.get_extension().to_lower())
	_cache[path] = stream
	if stream == null: last_errors.append("无法读取音频：" + path)
	return stream

static func set_loop(stream: AudioStream, enabled: bool):
	if stream is AudioStreamWAV:
		var samples = roundi(stream.get_length() * stream.mix_rate)
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD if enabled else AudioStreamWAV.LOOP_DISABLED
		stream.loop_begin = 0; stream.loop_end = samples
	elif stream is AudioStreamOggVorbis or stream is AudioStreamMP3:
		stream.loop = enabled

func cue_stream(cue: String, looped = false) -> AudioStream:
	var paths = resource_paths(cue)
	if paths.is_empty(): return null
	# Pick one format per variant basename; prefer the custom root as a whole.
	for root_path in [custom_root, builtin_root]:
		var variants: Array = []; var basenames: Dictionary = {}
		for path in paths:
			if not str(path).begins_with(root_path + "/"): continue
			var base = str(path).get_basename()
			if basenames.has(base): continue
			var raw = _stream(str(path))
			if raw != null: variants.append(raw); basenames[base] = true
		if variants.is_empty(): continue
		var index = int(_variant.get(cue, 0)) % variants.size()
		var stream = variants[index].duplicate() as AudioStream
		set_loop(stream, looped); _variant[cue] = index + 1
		return stream
	return null

func play_cue(cue: String, world = false) -> bool:
	if not unlocked or muted or float(levels.master) <= 0 or float(levels.sfx) <= 0 or (world and world_paused): return false
	var definition: Dictionary = config.get("cues", {}).get(cue, {})
	if definition.is_empty() or str(definition.get("bus", "SFX")) != "SFX": return false
	var gate = "world" if world else "ui" if cue in ["ui.click","ui.back"] else "feedback"
	if _clock < float(_next_allowed.get(cue, -1)) or _clock < float(_next_allowed.get(gate, -1)): return false
	var pool = _voices.slice(0, 6) if world else _voices.slice(6, 8)
	var voice: AudioStreamPlayer
	for player in pool:
		if not player.playing: voice = player; break
	if voice == null: return false
	var stream = cue_stream(cue)
	if stream == null: return false
	voice.stream = stream; voice.volume_db = clampf(float(definition.get("gain_db", 0)), -40, 6)
	voice.set_meta("world", world); voice.play()
	_next_allowed[cue] = _clock + maxf(.04, float(definition.get("cooldown", .15)))
	_next_allowed[gate] = _clock + (.16 if world else .04)
	played[cue] = int(played.get(cue, 0)) + 1
	return true

func set_music(cue: String):
	if requested_music == cue: return
	requested_music = cue; _switch_loop("music", cue)

func set_ambience(cue: String):
	if requested_ambience == cue: return
	requested_ambience = cue; _switch_loop("ambience", cue)

func _switch_loop(kind: String, cue: String, immediate = false):
	if not unlocked or _music.is_empty(): return
	var players = _music if kind == "music" else _ambient
	if _fades.has(kind) and is_instance_valid(_fades[kind]): _fades[kind].kill()
	var old = int(_active[kind]); var next = 0 if old != 0 else 1
	var stream = cue_stream(cue, true) if not cue.is_empty() else null
	var tween = create_tween().set_parallel(true)
	_fades[kind] = tween
	var duration = .01 if immediate else clampf(float(config.get("crossfade_seconds", 1.2)), .05, 5)
	if stream != null:
		players[next].stop(); players[next].stream = stream
		players[next].volume_db = -60
		players[next].stream_paused = false; players[next].play()
		players[next].stream_paused = _preview.playing or (kind == "ambience" and world_paused)
		var definition: Dictionary = config.cues.get(cue, {})
		tween.tween_property(players[next], "volume_db", clampf(float(definition.get("gain_db", 0)), -40, 6), duration)
		_active[kind] = next; _current[kind] = cue
		if kind == "music": music_starts += 1
	else:
		_active[kind] = -1; _current[kind] = ""
	for i in range(players.size()):
		if stream != null and i == next: continue
		tween.tween_property(players[i], "volume_db", -60.0, duration)
		tween.chain().tween_callback(players[i].stop)

func set_world_paused(value: bool):
	if world_paused == value: return
	world_paused = value
	for player in _ambient: player.stream_paused = value or _preview.playing
	if value:
		for player in _voices:
			if bool(player.get_meta("world", false)): player.stop()

func preview(cue: String) -> bool:
	unlock(); stop_preview()
	var stream = cue_stream(cue)
	if stream == null: return false
	var definition: Dictionary = config.cues.get(cue, {})
	_preview.bus = str(definition.get("bus", "SFX"))
	_preview.volume_db = clampf(float(definition.get("gain_db", 0)), -40, 6)
	_preview.stream = stream; _preview.play()
	for player in _music + _ambient: player.stream_paused = true
	return true

func stop_preview():
	if _preview == null: return
	_preview.stop()
	for player in _music: player.stream_paused = false
	for player in _ambient: player.stream_paused = world_paused

func set_level(channel: String, value: float):
	if not levels.has(channel) or not is_finite(value): return
	levels[channel] = clampf(value, 0, 1); _apply_levels(); _save_in = .4

func set_muted(value: bool):
	muted = value; _apply_levels(); _save_in = .4

func _apply_levels():
	for channel in CHANNELS:
		var index = AudioServer.get_bus_index(CHANNELS[channel])
		if index < 0: continue
		AudioServer.set_bus_volume_db(index, linear_to_db(maxf(.00001, float(levels[channel]))))
		AudioServer.set_bus_mute(index, (channel == "master" and muted) or float(levels[channel]) <= 0)

func _load_settings():
	var file = ConfigFile.new()
	if file.load(settings_path) != OK: return
	for channel in levels:
		var value = float(file.get_value("volume", channel, levels[channel]))
		if is_finite(value): levels[channel] = clampf(value, 0, 1)
	muted = bool(file.get_value("volume", "muted", false))
	var overrides = file.get_value("audio", "overrides", {})
	if overrides is Dictionary: _overrides = overrides

func save_settings() -> Error:
	var file = ConfigFile.new()
	for channel in levels: file.set_value("volume", channel, levels[channel])
	file.set_value("volume", "muted", muted); file.set_value("audio", "overrides", _overrides)
	var result = file.save(settings_path)
	if result == OK and OS.has_feature("web"): JavaScriptBridge.force_fs_sync()
	_save_in = -1; return result

func import_bytes(cue: String, bytes: PackedByteArray, extension: String) -> Dictionary:
	extension = extension.to_lower().trim_prefix(".")
	var definition: Dictionary = config.get("cues", {}).get(cue, {})
	if definition.is_empty() or not extension in EXTENSIONS: return {"ok":false, "error":"请选择有效槽位及OGG、MP3或WAV文件。"}
	if bytes.size() > MAX_BYTES: return {"ok":false, "error":"单个音频不能超过64MB。"}
	var stream = _decode(bytes, extension)
	if stream == null or stream.get_length() <= 0: return {"ok":false, "error":"音频无法解码，请重新导出文件。"}
	var relative = str(definition.files[0]).get_basename() + "." + extension
	if not safe_path(relative): return {"ok":false, "error":"音频槽位路径无效。"}
	var path = custom_root.path_join(relative)
	if DirAccess.make_dir_recursive_absolute(path.get_base_dir()) != OK: return {"ok":false, "error":"音频目录无法写入。"}
	var file = FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if file == null: return {"ok":false, "error":"音频文件无法写入。"}
	file.store_buffer(bytes); var error = file.get_error(); file.close()
	if error != OK or DirAccess.rename_absolute(path + ".tmp", path) != OK: return {"ok":false, "error":"保存音频失败。"}
	_overrides[cue] = relative; save_settings(); reload()
	if OS.has_feature("web"): JavaScriptBridge.force_fs_sync()
	return {"ok":true, "path":relative, "seconds":stream.get_length()}

func snapshot() -> Dictionary:
	var index = int(_active.music)
	var playing = index >= 0 and _music[index].playing
	return {"requested_music":requested_music, "active_music":_current.music, "music_playing":playing, "music_position":_music[index].get_playback_position() if playing else 0.0, "requested_ambience":requested_ambience, "active_ambience":_current.ambience, "world_paused":world_paused, "unlocked":unlocked, "muted":muted, "levels":levels.duplicate(), "music_starts":music_starts, "played":played.duplicate(), "cue_count":config.get("cues",{}).size(), "preview_playing":_preview != null and _preview.playing}
