extends RefCounted
## Fixed top-down indoor/outdoor map. Projection, pointer coordinates and overlays share one affine map.
const Space=preload("res://scripts/services/restaurant_space.gd")
var view
var zoom=1.0
var camera=Vector2.ZERO
var controls: HBoxContainer
var dragging=false
var capacity_label: Label
func _init(owner_view):view=owner_view
func m():return view.model
func width() -> float:return Space.world_size(m()).x+24
func scale_factor() -> float:
	var vertical=maxf(40,view.size.y-52)/(Space.world_size(m()).y+24)
	if view.size.x<1000:vertical=maxf(.55,vertical) # Fixed readable mobile scale; pan if the full floor does not fit.
	return maxf(.01,minf(view.size.x/width(),vertical))*zoom
func offset() -> Vector2:
	var scale=scale_factor();return Vector2((view.size.x-width()*scale)*.5,52+(view.size.y-52-(Space.world_size(m()).y+24)*scale)*.5)-camera*scale
func project(point: Vector2) -> Vector2:return point
func unproject(point: Vector2) -> Vector2:return point
func to_view(point: Vector2) -> Vector2:return offset()+project(point)*scale_factor()
func to_world(point: Vector2) -> Vector2:return unproject((point-offset())/scale_factor())
func linear_scale() -> Vector2:return Vector2.ONE*scale_factor()
func set_zoom(value: float):
	zoom=clampf(value,1,2);camera=Vector2.ZERO;view.queue_redraw()
func pan(amount: float):pan_by(Vector2(amount,0))
func pan_by(amount: Vector2):
	var limit=Vector2(maxf(0,(width()-view.size.x/scale_factor())*.5),maxf(0,(Space.world_size(m()).y+24-(view.size.y-52)/scale_factor())*.5))
	camera=(camera+amount).clamp(-limit,limit);view.queue_redraw()
func setup_controls():
	if controls!=null:return
	controls=HBoxContainer.new();controls.position=Vector2(8,5);controls.add_theme_constant_override("separation",4);view.add_child(controls)
	for entry in [["全景","scene:overview",func():set_zoom(1)],["左移","scene:left",func():pan(-120)],["右移","scene:right",func():pan(120)],["上移","scene:up",func():pan_by(Vector2(0,-90))],["下移","scene:down",func():pan_by(Vector2(0,90))]]:
		var button: Button
		var ref=view.get_meta("presentation_host") if view.has_meta("presentation_host") else null
		if ref is WeakRef and ref.get_ref()!=null:button=ref.get_ref().button(str(entry[0]),entry[2],false,str(entry[1]))
		else:button=Button.new();button.text=str(entry[0]);button.pressed.connect(entry[2]);button.set_meta("qa_id",str(entry[1]))
		button.custom_minimum_size=Vector2(44,44);button.add_theme_font_size_override("font_size",12);button.tooltip_text="固定俯视全景，地图超出视野时可拖动或平移查看";controls.add_child(button)
	capacity_label=Label.new();capacity_label.add_theme_font_size_override("font_size",12);capacity_label.add_theme_color_override("font_color",view.ink);capacity_label.mouse_filter=Control.MOUSE_FILTER_IGNORE;controls.add_child(capacity_label)
func input(event: InputEvent) -> bool:
	if event is InputEventMouseButton:
		if event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:pan_by(Vector2(0,-90 if event.button_index==MOUSE_BUTTON_WHEEL_UP else 90));return true
		if event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_LEFT,MOUSE_BUTTON_WHEEL_RIGHT]:pan(-100 if event.button_index==MOUSE_BUTTON_WHEEL_LEFT else 100);return true
		if event.button_index==MOUSE_BUTTON_MIDDLE:dragging=event.pressed;return true
	if event is InputEventMouseMotion and dragging:pan_by(-event.relative/scale_factor());return true
	if event is InputEventScreenDrag:pan_by(-event.relative/scale_factor());return true
	return false
func draw():
	view.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	setup_controls()
	var rules=m().full_rules.dollhouse;var stoves=rules.fixtures("stove");var tills=rules.fixtures("cashier")
	capacity_label.text="灶台 %d/%d · 收银 %d/%d" % [stoves.filter(func(f):return rules.locked(rules.identity(f))).size(),stoves.size(),tills.filter(func(f):return rules.locked(rules.identity(f))).size(),tills.size()]
	var scale=scale_factor();var shift=offset();view.draw_set_transform(shift,0,Vector2.ONE*scale)
	var w=Space.world_size(m()).x;var ground=Space.grid_rect(m());var indoors=Rect2(ground.position,Vector2(ground.size.x,ground.size.y*.8))
	view.box(Rect2(0,60,w,500),Color("c9d6b5"),5)
	var yard=view._asset_texture("Map","floor_yard")
	if yard!=null:view.draw_texture_rect(yard,Rect2(0,60,w,500),true)
	var background=view._asset_texture("Map","restaurant_stage_%d" % int(m().state.stage))
	if background==null:background=view._asset_texture("Map","restaurant")
	if background!=null:view.draw_texture_rect(background,Rect2(0,60,w,500),false)
	view.box(Rect2(0,518,w,42),Color("b7b6ad"),2)
	var street=view._asset_texture("Map","floor_street")
	if street!=null:view.draw_texture_rect(street,Rect2(0,518,w,42),true)
	for x in range(8,int(w),60):view.box(Rect2(x,536,30,3),Color("dedbd0"),0)
	view.box(Rect2(8,430,65,105),Color("b7b6ad"),2)
	view.box(Rect2(28,398,60,32),Color("dbceb0"),2)
	view.box(indoors,Color("ecdfc6"),3)
	var tile=view._asset_texture("Map","floor_wood")
	if tile!=null:view.draw_texture_rect(tile,indoors,true)
	else:
		for x in range(int(indoors.position.x),int(indoors.end.x),32):view.draw_line(Vector2(x,indoors.position.y),Vector2(x,indoors.end.y),Color(.6,.5,.35,.12),1)
		for y in range(int(indoors.position.y),int(indoors.end.y),32):view.draw_line(Vector2(indoors.position.x,y),Vector2(indoors.end.x,y),Color(.6,.5,.35,.12),1)
	view.box(Rect2(indoors.end.x*.65,indoors.position.y,indoors.size.x*.33,indoors.size.y),Color(.56,.69,.61,.15),0)
	view.box(Rect2(indoors.position.x,indoors.position.y-10,indoors.size.x,12),Color("759081"),2)
	var wall=view._asset_texture("Map","wall_shop")
	if wall!=null:view.draw_texture_rect(wall,Rect2(indoors.position.x,indoors.position.y-22,indoors.size.x,24),true)
	view.centered_text("用餐区",Vector2(w*.31,78),16,view.ink);view.centered_text("后厨",Vector2(w*.76,78),16,view.ink)
	var sign=view._asset_texture("Map","decor_sign")
	if sign!=null:view.draw_texture_rect(sign,Rect2(0,380,90,105),false)
	else:view.box(Rect2(120,445,135,34),Color("8a795d"),3)
	view.centered_text("有间小馆",Vector2(187,468),16,view.ink)
	view.centered_text("庭院 · 店门",Vector2(w*.52,473),14,view.green)
	for x in [int(w)-50,int(w)-110]:
		var plant=view._asset_texture("Map","decor_plant")
		if plant!=null:view.draw_texture_rect(plant,Rect2(x-8,421,40,62),false)
		else:
			view.box(Rect2(x,455,22,24),Color("b39771"),2);view.draw_circle(Vector2(x+11,451),18,Color("79a27c"))
	for entity in draw_entities():
		match str(entity.type):
			"chair":chair(entity.point)
			"fixture":fixture(entity.data,project(entity.point),int(entity.number))
			"staff":staff(entity.data,entity.point)
			_:guest(entity.data,project(entity.point),str(entity.type)=="leaving")
	if not view.placement_id.is_empty():placement()
	view.draw_set_transform(Vector2.ZERO)
	view.box(Rect2(0,0,view.size.x,52),Color("faf9f3"),0) # Keep the camera controls clear when panning a tall map.

func draw_entities() -> Array:
	# A chair is the support behind a seated body, not a foreground occluder.
	# Keeping all chairs in their own back pass also avoids a pop when arrival
	# motion ends a fraction of a pixel behind the seat's Y coordinate.
	var entities: Array=[];var table_number=0
	for item in m().state.layout:
		var center=Space.cell_rect(m(),item.x,item.y,item.w,item.h).get_center()
		if str(item.id) in ["table_two","table_four"]:table_number+=1
		entities.append({"type":"fixture","point":center,"data":item,"number":table_number})
		if str(item.id) in ["table_two","table_four"] and not bool(item.get("building",false)):
			var rectangle=Space.cell_rect(m(),item.x,item.y,item.w,item.h)
			var capacity=4 if str(item.id)=="table_four" else 2
			for seat in range(capacity):entities.append({"type":"chair","point":Space.chair_position(rectangle,seat,capacity)})
	for employee in m().employees:
		if view._actors.has(str(employee.id)):
			var actor=view._actors[str(employee.id)];entities.append({"type":"staff","point":actor.get("display_position",actor.position),"data":employee})
	for guest in m().customers:
		if str(guest.stage)=="cleaning":continue
		entities.append({"type":"guest","point":m().full_rules.dollhouse.guest_position(guest,float(m().state.total_minutes)+m()._fraction),"data":guest})
	for departed in m().state.revision191.departures:
		entities.append({"type":"leaving","point":m().motion_position(departed,float(m().state.total_minutes)+m()._fraction),"data":departed})
	for index in range(entities.size()):entities[index]["serial"]=index
	entities.sort_custom(_draws_before)
	return entities

static func _draws_before(a: Dictionary,b: Dictionary) -> bool:
	var a_back=str(a.type)=="chair";var b_back=str(b.type)=="chair"
	if a_back!=b_back:return a_back
	# Subpixel arrival interpolation must not toggle a body behind a tabletop.
	# Sort on the same whole-pixel floor bands as the pixel artwork.
	var a_depth=roundi(float(a.point.y));var b_depth=roundi(float(b.point.y))
	if a_depth!=b_depth:return a_depth<b_depth
	# At equal depth, furniture is drawn before bodies. Explicit serial order
	# makes equal-position crowds deterministic instead of relying on sort stability.
	var priority={"chair":0,"fixture":1,"staff":2,"guest":3,"leaving":4}
	var a_priority=int(priority.get(str(a.type),5));var b_priority=int(priority.get(str(b.type),5))
	if a_priority!=b_priority:return a_priority<b_priority
	return int(a.serial)<int(b.serial)
func fixture(item: Dictionary,p: Vector2,number: int):
	var id=str(item.id);var d=m().full_rules.dollhouse;var kind=d.kind(item)
	var rect=Rect2(p-Vector2(23,30),Vector2(46,40))
	if bool(item.get("building",false)):
		view.box(rect,Color("e6d3a8"),3,Color("bda275"));view.draw_line(rect.position,rect.end,Color("b9955a"),2)
		view.centered_text("施工中",p-Vector2(0,12),12,view.ink);return
	var texture=view._asset_texture("Map",("equip_" if kind in ["stove","pass","cashier","table","upgrade"] else "decor_")+id)
	if texture!=null:
		var table_size=Space.table_extent(Space.cell_rect(m(),item.x,item.y,item.w,item.h))
		var extent=table_size+Vector2(6,12) if kind=="table" else Vector2(72,82)
		var origin=p-Vector2(extent.x*.5,extent.y*.5+12 if kind=="table" else 58)
		view.draw_texture_rect(texture,Rect2(origin,extent),false)
	else:
		match kind:
			"table":
				for x in [-24,24]:view.draw_line(p+Vector2(x,-17),p+Vector2(x,5),Color("9c8063"),5)
				view.box(Rect2(p-Vector2(24,23),Vector2(48,38)),Color("d8ac79"),3,Color("bd925d"))
				view.centered_text("%02d" % number,p-Vector2(0,0),11,Color("7d603e"))
			"stove","pass","cashier","upgrade":
				view.box(rect,Color("899b93") if kind in ["stove","upgrade"] else Color("a5b4a3"),3,Color("677e72"))
				view.box(Rect2(p-Vector2(28,40),Vector2(56,8)),Color("c9d4c4"),2)
				if kind=="stove":
					view.box(Rect2(p-Vector2(17,47),Vector2(34,13)),Color("424e49"),6)
					if d.locked(d.identity(item)):
						view.draw_arc(p-Vector2(0,48),12,0,PI,14,view.orange,4)
						for i in range(2):view.draw_line(p+Vector2(i*9-5,-56),p+Vector2(i*9-5+sin(view.elapsed+i)*3,-68),Color("b6b2a1"),2)
				elif kind=="cashier":
					view.box(Rect2(p-Vector2(17,60),Vector2(34,20)),Color("607b70"),2);view.centered_text("￥",p-Vector2(0,46),14,Color.WHITE)
				elif kind=="pass":view.bowl(p-Vector2(0,43),view.green)
			"promotion":
				view.draw_line(p-Vector2(20,0),p-Vector2(15,60),Color("a48b68"),4);view.draw_line(p+Vector2(20,0),p+Vector2(15,-60),Color("a48b68"),4)
				view.box(Rect2(p-Vector2(24,60),Vector2(48,42)),Color("91ac91"),2);view.centered_text("今日招牌",p-Vector2(0,35),11,Color("fff9de"))
			"rest":view.box(Rect2(p-Vector2(30,25),Vector2(60,25)),Color("a3b695"),6);view.box(Rect2(p-Vector2(31,43),Vector2(62,21)),Color("b9caa8"),5)
			_:
				if id=="lantern":view.box(Rect2(p-Vector2(15,60),Vector2(30,32)),Color("d99e72"),10);view.draw_line(p-Vector2(0,62),p-Vector2(0,81),view.ink,2)
				else:view.box(Rect2(p-Vector2(28,65),Vector2(56,40)),Color("bed0b7"),3);view.centered_text("山海",p-Vector2(0,41),14,view.green)
	if kind!="table":view.centered_text(str(m().full_rules.decoration(id).name).replace("基础",""),p+Vector2(0,17),11,view.ink)
	for order in m().customers:
		if str(order.get("device_uid",""))!=d.identity(item):continue
		var worker=m()._employee(str(order.worker));var title=str(worker.get("name",""))+("·烹饪" if str(order.stage)=="cooking" else "·忙碌")
		view.centered_text(title,p-Vector2(0,76),11,view.green)
func staff(employee: Dictionary,world: Vector2):
	var actor: Dictionary=view._actors[str(employee.id)];var p=project(world);var action=str(actor.action);var phase=float(actor.phase)*TAU
	var bob=0.0 # Baked rig enforces at most one source pixel of body motion.
	var body=p-Vector2(0,22-bob)
	shadow(p)
	var illustrated=view._draw_employee_frame(employee,actor,action,body,1)
	if not illustrated:
		view.draw_set_transform(offset()+body*scale_factor(),0,Vector2(float(actor.facing),1)*scale_factor())
		view.animal(Vector2.ZERO,m().full_rules.dollhouse.capable(employee,"chef"),bool(actor.get("resting",false)),str(employee.id),str(employee.get("icon","")))
		view.draw_set_transform(offset(),0,Vector2.ONE*scale_factor())
	var facing={"up":Vector2(0,-1),"down":Vector2(0,1),"left":Vector2(-1,0),"right":Vector2(1,0)}.get(str(actor.get("direction","down")),Vector2(0,1))
	var at=p+Vector2(0,16);var side=Vector2(-facing.y,facing.x)*4
	view.draw_colored_polygon(PackedVector2Array([at+facing*7,at-facing*3+side,at-facing*3-side]),Color("647b69"))
	if not illustrated and action in ["Move","Cook","Serve","Clean","Cashier","Promote","Order"]:view._draw_action_prop(actor,body)
	if not illustrated and action=="Order":
		view.box(Rect2(body+Vector2(20,-12),Vector2(16,24)),Color("fcf4d9"),2);view.draw_line(body+Vector2(22,-3),body+Vector2(32,-3),view.green,2)
	if not illustrated and action=="Build":view.draw_line(body+Vector2(10,0),body+Vector2(25+sin(phase)*8,-12),view.ink,3)
	var labels={"Idle":"待命","Move":"行走","Cook":"炒菜","Serve":"上菜","Clean":"清台","Cashier":"收银","Promote":"宣传","Order":"点单","Rest":"休息","Build":"施工"}
	var label=str(labels.get(action,action))
	if int(actor.get("task_count",0))>1:label+="×%d" % int(actor.task_count)
	view.box(Rect2(p-Vector2(43,96),Vector2(86,19)),Color("fffaf0"),4)
	view.centered_text(str(employee.name)+"·"+label,p-Vector2(0,82),12,view.ink)
	view.box(Rect2(p-Vector2(18,-9),Vector2(36,3)),Color("d6c9b1"),1)
	view.box(Rect2(p-Vector2(18,-9),Vector2(36*float(employee.get("stamina",100))/100,3)),view.green,1)
func guest(data: Dictionary,p: Vector2,leaving: bool):
	var motion: Dictionary=data.get("checkout_motion",data.get("arrival_motion",data.get("motion",{})))
	var walking=not motion.is_empty() and float(m().state.total_minutes)+m()._fraction<float(motion.get("started",0))+float(motion.get("travel_minutes",0))
	var action="walk" if walking else "eat" if data.get("stage")=="eating" else "sit" if data.get("stage") in ["ordering","queued","cooking","serving"] else "idle"
	var direction="down"
	if walking:
		var at=float(m().state.total_minutes)+m()._fraction;var previous=m().motion_position({"motion":motion},at-.01);var current=m().motion_position({"motion":motion},at);var delta=current-previous
		direction=("right" if delta.x>0 else "left") if absf(delta.x)>=absf(delta.y) else ("down" if delta.y>0 else "up")
	var kind={"human":"human","monster":"demon","descendant":"beastkin"}.get(str(data.get("type","human")),"human")
	var appearance="%s_%02d" % [kind,int(data.id)%3+1]
	if data.has("visitor_id"):kind="special";appearance=str(preload("res://scripts/ui/art_targets.gd").GUEST_IDS.get(str(data.visitor_id),str(data.visitor_id)))
	var image=null
	if view.assets!=null:
		var frames=view.assets.get_customer_frames(kind,appearance,action,direction)
		if not frames.is_empty() and not view.assets.is_placeholder(frames[0]):image=frames[int(view.elapsed*6)%frames.size()]
	if image==null and data.has("visitor_id"):image=view._asset_texture("Characters","guest_"+str(data.visitor_id)+"_idle")
	if not walking and action in ["sit","eat"]:
		direction="down"
		var table=m().full_rules.dollhouse.table_for(data)
		if not table.is_empty():
			var center=Space.cell_rect(m(),table.x,table.y,table.w,table.h).get_center()
			var to_table=center-p
			direction=("right" if to_table.x>0 else "left") if absf(to_table.x)>=absf(to_table.y) else ("down" if to_table.y>0 else "up")
			if view.assets!=null:
				var frames=view.assets.get_customer_frames(kind,appearance,action,direction)
				if not frames.is_empty() and not view.assets.is_placeholder(frames[0]):image=frames[int(view.elapsed*6)%frames.size()]
	if image!=null:
		var anchor=Vector2(32,61) if not walking and action in ["sit","eat"] else Vector2(32,77)
		shadow(p)
		var lift=preload("res://scripts/services/art_motion.gd").lift(appearance,action) if walking or action=="idle" else 0.0
		view.draw_texture_rect(image,Rect2(p-anchor-Vector2(0,lift),Vector2(64,80)),false)
	else:
		view.draw_circle(p-Vector2(0,27),14,Color("a4b9ad"))
		view.box(Rect2(p-Vector2(12,16),Vector2(24,20)),Color("b5c5b3"),4)
	var title="离店" if leaving else {"ordering":"点单","queued":"等餐","cooking":"等餐","serving":"上菜","eating":"用餐","paying":"结账"}.get(str(data.get("stage","")),"食客")
	view.centered_text(str(title),p-Vector2(0,82),11,view.green)
	if data.has("visitor_id"):
		var marker=view._asset_texture("FX","icon_special_guest")
		if marker!=null:view.draw_texture_rect(marker,Rect2(p+Vector2(12,-50),Vector2(20,20)),false)
		else:view.centered_text("★",p+Vector2(20,-34),14,view.orange)
	if data.get("stage")=="eating":
		var dish=view._asset_texture("Dishes",str(data.dish_id))
		if dish!=null:
			var table=m().full_rules.dollhouse.table_for(data)
			var at=p+Vector2(0,-18)
			if not table.is_empty():at=p.lerp(Space.cell_rect(m(),table.x,table.y,table.w,table.h).get_center(),.55)+Vector2(0,-18)
			view.draw_texture_rect(dish,Rect2(at-Vector2(12,12),Vector2(24,24)),false)
		else:view.bowl(p+Vector2(22,-6),view.orange)
func placement():
	var dimensions=view.grid_dimensions()
	for x in range(dimensions.x):
		for y in range(dimensions.y):
			var rect=view.cell_rect(x,y);var p=project(rect.position);var extent=rect.size
			view.box(Rect2(p,extent).grow(-1),Color(.4,.64,.5,.08),1,Color(.4,.64,.5,.3))
	if view.preview_cell.x<0:return
	var definition=view._decoration_entry(view.placement_id);var rect=view.cell_rect(view.preview_cell.x,view.preview_cell.y,int(definition.get("width",1)),int(definition.get("height",1)))
	var p=project(rect.position);var extent=rect.size
	var color=Color("528575") if view._placement_allowed() else Color("c1765d")
	view.box(Rect2(p,extent).grow(-1),Color(color,.32),2,color);view.centered_text("可放" if view._placement_allowed() else "不可放",p+extent*.5+Vector2(0,5),12,view.ink)

func chair(point: Vector2):
	var texture=view._asset_texture("Map","chair")
	if texture!=null:view.draw_texture_rect(texture,Rect2(point-Vector2(18,40),Vector2(36,54)),false)
	else:
		view.box(Rect2(point-Vector2(10,25),Vector2(20,23)),Color("9c8063"),2)
		view.box(Rect2(point-Vector2(11,6),Vector2(22,12)),Color("b69c77"),2)

func shadow(point: Vector2):
	var texture=view._asset_texture("FX","shadow")
	if texture!=null:view.draw_texture_rect(texture,Rect2(point-Vector2(16,3),Vector2(32,12)),false)
