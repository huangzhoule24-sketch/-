extends RefCounted
## Observer-only speech: real-time readability, independent of simulation RNG.
const Policy = preload("res://scripts/ui/interface_policy.gd")
var view
var clock = 0.0
var last_spoken: Dictionary = {}
var bubbles: Array[Dictionary] = []
var seen_notice = -1
func _init(owner_view) -> void: view = owner_view
func state_for(employee: Dictionary,actor: Dictionary) -> String:
	if bool(actor.get("navigation_blocked",false)): return "Blocked"
	if float(employee.get("stamina",100)) <= 20: return "Fatigue"
	if float(employee.get("mood",100)) <= 30: return "LowMood"
	if bool(actor.get("resting",false)):
		return {"训练":"Train","研发":"Research"}.get(str(actor.get("rest_label","")),"Rest")
	return str(actor.get("action","Idle"))
func text_for(employee: Dictionary,state: String) -> String:
	var data = Policy.settings()
	var choices: Array = data.get("thoughts",{}).get(state,["认真做好眼前的一件事。"])
	if state in ["Idle","Move"] and data.get("personal_thoughts",{}).has(str(employee.id)):
		choices = data.personal_thoughts[str(employee.id)]
	var index = posmod(hash(str(employee.id)+str(int(clock/maxf(1,float(data.get("presentation",{}).get("bubble_cooldown_seconds",12)))))),choices.size())
	return str(choices[index])
func limit() -> int:
	var maximum=int(Policy.settings().get("presentation",{}).get("max_bubbles",3))
	var ref=view.get_meta("presentation_host") if view.has_meta("presentation_host") else null
	if ref is WeakRef:
		var ui=ref.get_ref()
		if ui!=null:maximum-=int(ui.toast_timer>0)+ui._cash_floats.size()
	return maxi(0,maximum)
func _remove(index: int) -> void:
	var node = bubbles[index].get("node")
	if is_instance_valid(node): node.queue_free()
	bubbles.remove_at(index)
func speak(employee: Dictionary,focused: bool = false,state_override: String = "") -> void:
	var id = str(employee.id)
	var actor: Dictionary = view._actors.get(id,{})
	if actor.is_empty(): return
	for index in range(bubbles.size()-1,-1,-1):
		if str(bubbles[index].id) == id: _remove(index)
	var settings: Dictionary = Policy.settings().get("presentation",{})
	if limit()<=0:return
	if bubbles.size() >= limit(): _remove(0)
	var state = state_for(employee,actor) if state_override.is_empty() else state_override
	var text = str(employee.get("name",id)) + "：" + text_for(employee,state)
	if focused:
		var labels = {"Idle":"待命","Move":"移动","Cook":"烹饪","Serve":"服务","Clean":"清台","Cashier":"收银","Promote":"宣传","Order":"点单","Build":"施工","Rest":"休息","Train":"训练","Research":"研发","Fatigue":"疲劳","LowMood":"低落","Blocked":"通路受阻"}
		text = "%s · %s · 体力%d 心情%d\n%s" % [str(employee.get("name",id)),str(labels.get(state,state)),int(employee.get("stamina",100)),int(employee.get("mood",100)),text_for(employee,state)]
	var node = Label.new()
	node.text = text
	node.text=text.replace("\n"," · ")
	node.autowrap_mode = TextServer.AUTOWRAP_OFF
	node.clip_text=true
	node.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	node.tooltip_text=text
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	node.add_theme_font_size_override("font_size",12)
	node.add_theme_color_override("font_color",Color("30493f"))
	var style: StyleBox
	if view.assets != null and view.assets.has_image("UI/thought_bubble"):
		var texture = StyleBoxTexture.new()
		texture.texture = view.assets.get_texture("UI/thought_bubble")
		for side in [SIDE_LEFT,SIDE_TOP,SIDE_RIGHT,SIDE_BOTTOM]: texture.set_texture_margin(side,10)
		style = texture
	else:
		var paper = StyleBoxFlat.new()
		paper.bg_color = Color("fffdf3")
		paper.border_color = Color("a9bba7")
		paper.set_border_width_all(1)
		paper.set_corner_radius_all(8)
		style = paper
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 3
	style.content_margin_bottom = 3
	node.add_theme_stylebox_override("normal",style)
	view.add_child(node)
	bubbles.append({"id":id,"state":state,"text":text,"left":minf(4,2+ceilf(maxf(0,text.length()-12)/6.0)*.5),"node":node})
	last_spoken[id] = clock
	place()
func update(delta: float) -> void:
	var real_delta = maxf(0,delta) if not view.model.paused else 0.0
	clock += real_delta
	while bubbles.size()>limit():_remove(0)
	for index in range(bubbles.size()-1,-1,-1):
		bubbles[index].left -= real_delta
		bubbles[index].node.modulate.a=clampf(float(bubbles[index].left)/.35,0,1)
		if float(bubbles[index].left) <= 0 or (not str(bubbles[index].id).begins_with("guest:") and not view._actors.has(str(bubbles[index].id))) or (str(bubbles[index].id).begins_with("guest:") and view.model._customer(int(str(bubbles[index].id).trim_prefix("guest:"))).is_empty()): _remove(index)
	if real_delta > 0:
		var notices: Array = view.model.state.get("customer_service",{}).get("notices",[])
		if not notices.is_empty():
			var serial = int(notices.back().get("serial",0))
			if seen_notice >= 0 and serial > seen_notice and str(notices.back().get("kind","")) == "stockout":
				for employee in view.model.employees:
					if view._actors.has(str(employee.id)):
						speak(employee,false,"Stockout")
						break
			seen_notice = serial
		elif seen_notice < 0: seen_notice = 0
		var settings: Dictionary = Policy.settings().get("presentation",{})
		var candidates: Array = []
		for employee in view.model.employees:
			var id = str(employee.id)
			if not view._actors.has(id): continue
			if clock-float(last_spoken.get(id,-1000)) >= float(settings.get("bubble_cooldown_seconds",12)): candidates.append(employee)
		candidates.sort_custom(func(a,b):return float(last_spoken.get(str(a.id),-1000)) < float(last_spoken.get(str(b.id),-1000)))
		for employee in candidates:
			if bubbles.size() >= limit(): break
			speak(employee)
	if real_delta>0:speak_waiting_guest()
	place()
func place() -> void:
	var rectangles: Array[Rect2] = []
	for bubble in bubbles:
		var node: Label = bubble.node
		var actor: Dictionary = view._actors.get(str(bubble.id),{})
		if str(bubble.id).begins_with("guest:"):
			var customer=view.model._customer(int(str(bubble.id).trim_prefix("guest:")))
			actor={"position":view.model.full_rules.dollhouse.guest_position(customer) if view.is_dollhouse() else view._seat_position(int(customer.get("seat",0)))}
		var point = view._to_view(actor.get("display_position",actor.get("position",Vector2.ZERO)))
		var width = minf(float(Policy.settings().get("presentation",{}).get("bubble_width",220)),maxf(100,view.size.x-16))
		node.size.x = width
		node.custom_minimum_size.x = width
		var height = maxf(24,node.get_minimum_size().y)
		node.size.y = height
		var position = Vector2(clampf(point.x-width/2,8,maxf(8,view.size.x-width-8)),clampf(point.y-height-34,4,maxf(4,view.size.y-height-4)))
		var rect = Rect2(position,Vector2(width,height))
		for other in rectangles:
			if rect.intersects(other): rect.position.y = minf(view.size.y-height-4,other.end.y+4)
		node.position = rect.position
		rectangles.append(rect)
func snapshot() -> Array:
	var result: Array = []
	for bubble in bubbles:
		var node: Label = bubble.node
		result.append({"id":bubble.id,"state":bubble.state,"text":bubble.text,"left":bubble.left,"rect":{"x":node.global_position.x,"y":node.global_position.y,"w":node.size.x,"h":node.size.y}})
	return result

func speak_waiting_guest():
	if bubbles.size()>=limit():return
	for customer in view.model.customers:
		var id="guest:"+str(customer.id)
		if clock-float(last_spoken.get(id,-1000))<12:continue
		if str(customer.stage) not in ["queued","ordering","cooking","eating"]:continue
		var message="饭菜真香，慢慢享用。" if str(customer.stage)=="eating" else "怎么还没上菜呢…" if int(view.model.state.total_minutes)-int(customer.arrival_minute)>=40 else "今天会吃到什么呢？"
		var fake={"id":id,"name":"食客","stamina":100,"mood":float(customer.get("mood",50))}
		view._actors[id]={"position":view._seat_position(int(customer.seat)),"action":"Guest"}
		speak(fake,false,"Guest")
		view._actors.erase(id)
		if not bubbles.is_empty() and str(bubbles.back().id)==id:
			bubbles.back().text="食客："+message;bubbles.back().node.text=bubbles.back().text;bubbles.back().node.tooltip_text=bubbles.back().text
		break
