extends RefCounted
## v1.9: one top status row, expandable inventory and compact contextual popups.
var host
var inventory_open=false
var inventory_box: ScrollContainer
var inventory_grid: GridContainer
var inventory_button: Button
var first: HBoxContainer
var second: HBoxContainer
var badges: Dictionary={}
var signature=""
var details: Dictionary={}
var summary_button: Button
var info_popup: PopupPanel
var speed_popup: PopupPanel
var speed_entry: Button
func _init(ui):host=ui
func m():return host.model
func v():return m().full_rules.revision18
func setup(status_row: HBoxContainer):
	var root=host._layout_controls.root
	first=host._layout_controls.toolbar;second=status_row
	first.item_rect_changed.connect(func():call_deferred("fit_panel"))
	host._layout_controls.header.hide()
	# Inventory expands below the single top row and reduces scene height.
	inventory_box=ScrollContainer.new();inventory_box.name="BottomInventory";inventory_box.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;inventory_box.custom_minimum_size.y=86
	root.add_child(inventory_box);root.move_child(inventory_box,root.get_child_count()-2);inventory_box.hide()
	inventory_grid=GridContainer.new();inventory_grid.columns=6;inventory_grid.size_flags_horizontal=Control.SIZE_EXPAND_FILL;inventory_grid.add_theme_constant_override("h_separation",8);inventory_box.add_child(inventory_grid)
	root.move_child(first,1);root.move_child(inventory_box,2)
	info_popup=PopupPanel.new();host.add_child(info_popup);second.reparent(info_popup)
	for node in [host.training_status,host.building_status]:node.reparent(first)
	for resource in [host.money_label,host.gem_label,host.reputation_label]:resource.get_parent().get_parent().reparent(first)
	host.debt_label.reparent(first)
	var order=[host.clock_label,host.money_label.get_parent().get_parent(),host.gem_label.get_parent().get_parent(),host.reputation_label.get_parent().get_parent(),host.debt_label,host.todo_anchor,host.pause_button]+host.speed_buttons
	for i in order.size():first.move_child(order[i],i)
	host.period_label.reparent(second)
	inventory_button=host.button("物品栏 ▴",toggle_inventory,false,"inventory:toggle");first.add_child(inventory_button)
	for id in v().config.states:
		var key=str(id);var badge=host.button(str({"rush_hour":"峰","ingredient_sale":"惠","word_of_mouth":"誉","hygiene_risk":"洁","zhaocai_day":"财"}[key]),func():host.open_panel("经营状态"),false,"state:"+key)
		badge.custom_minimum_size=Vector2(44,44);second.add_child(badge);badges[key]=badge
	var clean=host.button("清洁",func():host.open_panel("经营状态"),false,"kitchen:open");clean.custom_minimum_size.x=44;second.add_child(clean)
	summary_button=host.button("状态",show_status,false,"status:summary");summary_button.custom_minimum_size=Vector2(60,44);first.add_child(summary_button)
	speed_popup=PopupPanel.new();host.add_child(speed_popup);var speeds=host.row(4);speed_popup.add_child(speeds)
	for control in host.speed_buttons:control.reparent(speeds);control.pressed.connect(func():speed_popup.hide())
	speed_entry=host.button("2×",show_speeds,false,"time:menu");speed_entry.custom_minimum_size=Vector2(44,44);first.add_child(speed_entry)
	first.move_child(inventory_button,first.get_child_count()-5)
	first.move_child(host.training_status,first.get_child_count()-4);first.move_child(host.building_status,first.get_child_count()-3)
	# Existing map owns draw/input; pickups are lightweight children, no grid occupancy.
	var pickups=preload("res://scripts/ui/pickup_overlay.gd").new();pickups.setup(host);host.map_view.add_child(pickups)
func toggle_inventory():
	inventory_open=not inventory_open;inventory_box.visible=inventory_open;inventory_button.text="物品栏 ▾" if inventory_open else "物品栏 ▴";signature="";layout();refresh();host.call_deferred("configure_panel_layout",host.panel_name)
func layout():
	if first==null:return
	var compact=host.compact_layout
	host._layout_controls.root.add_theme_constant_override("separation",6)
	first.add_theme_constant_override("separation",4);second.add_theme_constant_override("separation",4)
	host.event_button.hide();host.period_label.hide();host._layout_controls.time_legend.hide()
	host.clock_label.add_theme_font_size_override("font_size",12 if compact else 15)
	host.clock_label.custom_minimum_size.x=100 if compact else 130;host.clock_label.clip_text=true;host.clock_label.size_flags_horizontal=Control.SIZE_FILL
	host.debt_label.add_theme_font_size_override("font_size",12);host.debt_label.custom_minimum_size.x=50 if compact else 85;host.debt_label.clip_text=true
	for value in [host.money_label,host.gem_label,host.reputation_label]:
		var pill=value.get_parent().get_parent();pill.custom_minimum_size=Vector2(58 if compact else 75,44)
		var style=host.style(host.PAPER,6);style.content_margin_left=4;style.content_margin_right=4;style.content_margin_top=0;style.content_margin_bottom=0;pill.add_theme_stylebox_override("panel",style)
		value.add_theme_font_size_override("font_size",13 if compact else 18);value.clip_text=true;value.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
		value.get_parent().get_child(0).add_theme_font_size_override("font_size",10)
	host.todo_button.custom_minimum_size.x=78 if compact else 145
	host.todo_button.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	host.todo_button.add_theme_font_size_override("font_size",12 if compact else 15)
	var todo_style=host.style(Color("e5ebdf"),6);todo_style.content_margin_left=4;todo_style.content_margin_right=4;todo_style.content_margin_top=4;todo_style.content_margin_bottom=4;host.todo_button.add_theme_stylebox_override("normal",todo_style)
	host.todo_anchor.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	for button in [host.pause_button]+host.speed_buttons:
		var button_style=host.style(Color("edf0e7"),6);button_style.content_margin_left=4;button_style.content_margin_right=4;button_style.content_margin_top=4;button_style.content_margin_bottom=4;button.add_theme_stylebox_override("normal",button_style)
		button.custom_minimum_size=Vector2(44,44);button.add_theme_font_size_override("font_size",12 if compact else 15)
	for parent in [first,second]:
		for child in parent.get_children():
			if child is Button:
				var style=host.style(Color("edf0e7"),6);style.content_margin_left=4;style.content_margin_right=4;style.content_margin_top=4;style.content_margin_bottom=4;child.add_theme_stylebox_override("normal",style)
	for control in [host.training_status,host.building_status]:
		control.custom_minimum_size=Vector2(44 if compact else 95,44);control.clip_text=true;control.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS;control.add_theme_constant_override("icon_max_width",12 if compact else 16);control.add_theme_font_size_override("font_size",10 if compact else 15)
	inventory_button.custom_minimum_size.x=44;inventory_button.text="物品";inventory_button.add_theme_font_size_override("font_size",12)
	summary_button.custom_minimum_size.x=70 if compact else 95;summary_button.clip_text=true;summary_button.add_theme_font_size_override("font_size",10 if compact else 12)
	speed_entry.visible=compact
	for control in host.speed_buttons:
		if compact and control.get_parent()==first:control.reparent(speed_popup.get_child(0))
		elif not compact and control.get_parent()!=first:control.reparent(first)
	inventory_grid.columns=4 if compact else 6
	inventory_box.custom_minimum_size.y=56 if compact else 86
	host.map_view.custom_minimum_size.y=(54 if inventory_open else 90) if compact else 300
	host.toast_label.offset_top=first.global_position.y+first.size.y+6
	host.toast_label.size.y=0
func show_status():
	var rect=Rect2i(Vector2i(16,first.global_position.y+first.size.y+4),Vector2i(mini(int(host.size.x)-32,1100),72))
	info_popup.popup(rect)
func show_speeds():
	speed_popup.popup(Rect2i(Vector2i(maxf(8,host.size.x-280),first.global_position.y+first.size.y+4),Vector2i(264,56)))
func fit_panel():
	if first==null:return
	if host.tutorial_overlay!=null:host.tutorial_overlay.update_layout()
	if not host.overlay.visible:return
	info_popup.hide();speed_popup.hide()
	var top=host._layout_controls.content.global_position.y+4
	var limit=host._layout_controls.bottom.global_position.y-6
	if limit<=top:return
	host.overlay.offset_top=top;host.overlay.offset_bottom=limit-host.size.y
	var height=maxf(110,limit-top-12)
	if not host.compact_layout:height=minf(600,height)
	host.modal_window.offset_top=-height/2;host.modal_window.offset_bottom=height/2
func refresh():
	if not m().state.has("revision18"):return
	for key in badges:
		var active=v().s().states.filter(func(state):return str(state.id)==key and int(state.until)>v().now())
		badges[key].visible=not active.is_empty()
		if not active.is_empty():
			var remaining=int(active[0].until)-v().now()
			badges[key].text=str({"rush_hour":"峰","ingredient_sale":"惠","word_of_mouth":"誉","hygiene_risk":"洁","zhaocai_day":"财"}[key])+str(int(ceil(remaining/60.0)))+"h"
			badges[key].tooltip_text=str(v().config.states[key].title)+" · 剩%d分钟\n" % remaining+str(v().config.states[key].description)
	host.money_label.tooltip_text="钞票 ￥%.2f" % float(m().state.cash)
	if absf(float(m().state.cash))>=10000:host.money_label.text="%.2f万" % (float(m().state.cash)/10000)
	host.gem_label.tooltip_text="灵石 %d" % int(m().state.gems)
	host.reputation_label.tooltip_text="声望 %d" % int(m().state.reputation)
	var debt=float(m().state.debt)+float(m().state.finance.loan.principal)+float(m().state.rescue171.loan.get("principal",0))
	host.debt_label.text=("债%.1f万" % (debt/10000)) if debt>=10000 else "债￥%.0f" % debt;host.debt_label.tooltip_text="全部本金负债￥%.2f，点击账单查看利息及到期日" % debt
	host.clock_label.tooltip_text=m().clock_label()+" · "+m().period_label()
	if host.compact_layout:host.clock_label.text=m().clock_label().replace("  ","\n")
	var waiting=m().customers.filter(func(c):return str(c.stage) in ["ordering","recommending","queued","cooking","serving"]).size()
	host.live_status.text=m().period_label()+" · 顾客%d / 等待%d · 食材%.1f / 新鲜%d%% · 预计工资￥%.0f" % [m().customers.size(),waiting,float(m().state.ingredients),int(m().state.freshness),float(m().full_rules.finance.preview_bill().get("wages_due",0))]
	var low=m().employees.filter(func(e):return float(e.stamina)<=20 or float(e.mood)<=30)
	if summary_button!=null:summary_button.icon=host.assets.get_texture("FX/icon_warning") if not low.is_empty() and host.assets.has_image("FX/icon_warning") else null
	if not low.is_empty():host.live_status.text="⚠ %d位员工状态偏低 · " % low.size()+host.live_status.text
	if float(m().state.cash)<m().full_rules.rescue.fixed_cost():host.live_status.text="现金流告急 · "+host.live_status.text
	var next_stage=int(m().state.stage)+1
	if next_stage<=4 and float(m().state.total_revenue)>=float(m().balance.get("stage.%d.revenue" % next_stage,0)) and float(m().state.reputation)>=float(m().balance.get("stage.%d.reputation" % next_stage,0)):host.live_status.text="可升级 · "+host.live_status.text
	var training=m().employees.filter(func(e):return int(e.get("management_until",0))>v().now())
	if training.size()==1:host.training_status.text=str(training[0].name)+(" 研发%d分" if str(training[0].get("management_job_type",""))=="research" else " 培训%d分") % (int(training[0].management_until)-v().now())
	var builds=m().state.revision171.builds
	if builds.size()==1:host.building_status.text=str(m()._employee(str(builds[0].employee_id)).get("name",""))+" 施工%d分" % int(builds[0].remaining)
	if not v().s().cleaning.is_empty():host.live_status.text="清洁剩%d分 · " % (int(v().s().cleaning.due)-v().now())+host.live_status.text

	var signs: Array[String]=[]
	for state in v().s().states:
		signs.append(str({"rush_hour":"峰","ingredient_sale":"惠","word_of_mouth":"誉","hygiene_risk":"洁","zhaocai_day":"财"}.get(str(state.id),"状"))+str(int(ceil(float(int(state.until)-v().now())/60))))
	if m().full_rules.revision19.auto_active():signs.append("吸"+str(int(ceil(float(m().state.revision19.auto_until-v().now())/60))))
	summary_button.text=" ".join(signs.slice(0,3))+(("\n"+" ".join(signs.slice(3))) if signs.size()>3 else "") if not signs.is_empty() else "等%d" % waiting
	if not low.is_empty():summary_button.text="!%d " % low.size()+summary_button.text
	summary_button.tooltip_text=host.live_status.text+"\n"+"\n".join(v().s().states.map(func(state):return str(v().config.states[state.id].title)+" 剩%d分钟" % (int(state.until)-v().now())))
	if host.compact_layout:
		host.training_status.text=("训%d\n%s" % [training.size(),compact_duration(int(training.map(func(e):return int(e.management_until)-v().now()).min()))]) if not training.is_empty() else "训0"
		host.building_status.text=("建%d\n%s" % [builds.size(),compact_duration(int(builds.map(func(b):return int(b.remaining)).min()))]) if not builds.is_empty() else "建0"
	speed_entry.text="%d×" % m().speed
	if next_stage<=4 and float(m().state.reputation)>=float(m().balance.get("stage.%d.reputation" % next_stage,0)):host.reputation_label.add_theme_color_override("font_color",host.GREEN)
	if not inventory_open:return
	var data={"cash":m().state.cash,"gems":m().state.gems,"books":m().state.management.skill_books,"fragments":m().state.fragments,"items":m().state.management.items,"contracts":m().state.contracts,"tickets":m().state.hire_tickets}
	var next=JSON.stringify(data)
	if next==signature:return
	signature=next
	for child in inventory_grid.get_children():inventory_grid.remove_child(child);child.queue_free()
	item("钞票 ￥%.2f" % float(data.cash),"账单","cash");item("灵石 ×%d" % int(data.gems),"招聘","gems");item("技能书 ×%d" % int(data.books),"员工","books");item("招聘券 ×%d" % int(data.tickets),"招聘","tickets")
	for id in data.fragments:
		if int(data.fragments[id])>0:item(str(m()._employee_config(str(id)).get("name",id))+"碎片 ×%d" % int(data.fragments[id]),"员工","fragment:"+str(id))
	for id in data.contracts:item(str(m()._employee_config(str(id)).get("name",id))+"契约","招聘","contract:"+str(id))
	for id in data.items:
		var record=data.items[id]
		if float(record.quantity)>0:item(str(m().full_rules.management._ingredient(str(id)).get("name",id))+" ×%.1f" % float(record.quantity),"库存供应","stock:"+str(id))
func compact_duration(minutes: int) -> String:return "%dm" % minutes if minutes<60 else "%dh" % int(ceil(minutes/60.0))
func item(label: String,panel: String,id: String):
	var button=host.button(label,func():host.open_panel(panel),false,"inventory:"+id);button.add_theme_font_size_override("font_size",12);button.tooltip_text="查看或使用："+panel+"。资源已经记入余额，不可重复领取。"
	var item_id=str({"books":"skill_book"}.get(id,id.trim_prefix("item:")))
	if host.assets.has_image("Items/item_"+item_id):button.icon=host.assets.get_texture("Items/item_"+item_id);button.expand_icon=true;button.add_theme_constant_override("icon_max_width",24)
	inventory_grid.add_child(button)
func status_extras():
	var parent=host.revision_ui.body("经营状态与后厨维护","客流、采购、体力和投诉效果即时生效；同类收益采用最佳来源。")
	if m().full_rules.revision19.auto_active():host.revision_ui.text(parent,"散财童子自动吸附中 · 剩%d游戏分钟，收益仍记入拾取收入。" % (int(m().state.revision19.auto_until)-v().now()))
	if m().state.has("revision191"):
		var d=m().full_rules.dollhouse
		for pair in [["stove","灶台"],["pass","传菜口"],["cashier","收银台"],["promotion","宣传立牌"],["rest","休息角"]]:
			var items=d.fixtures(str(pair[0]));host.revision_ui.text(parent,"%s · 使用%d / 共%d个" % [str(pair[1]),items.filter(func(item):return d.locked(d.identity(item))).size(),items.size()])
	for state in v().s().states:
		host.revision_ui.text(parent,str(v().config.states[state.id].title)+" · 剩%d分钟\n" % (int(state.until)-v().now())+str(v().config.states[state.id].description))
	host.revision_ui.text(parent,"后厨使用 %d/%d 次 · 清洁用品￥%.0f / %d游戏分钟" % [int(v().s().kitchen_uses),int(v().config.kitchen.usage_limit),float(v().config.kitchen.clean_cost),int(v().config.kitchen.clean_minutes)])
	if not v().s().cleaning.is_empty():
		host.revision_ui.text(parent,"正在清洁："+str(m()._employee(str(v().s().cleaning.employee_id)).get("name",""))+" · 剩%d分钟" % (int(v().s().cleaning.due)-v().now()));return
	var selection=OptionButton.new();selection.custom_minimum_size.y=44;selection.set_meta("qa_id","kitchen:employee");selection.add_item("指派一位空闲员工");selection.set_item_metadata(0,"")
	for employee in m().employees:
		if v().clean_available(employee):selection.add_item(str(employee.name));selection.set_item_metadata(selection.item_count-1,str(employee.id))
	parent.add_child(selection)
	parent.add_child(host.button("安排清洁后厨",func():
		var check=m().full_rules.perform("kitchen_clean",{"employee_id":str(selection.get_selected_metadata())})
		if not check.ok:host.show_requirement(str(check.reason))
		else:host.open_panel("经营状态"),false,"kitchen:clean"))
	if bool(m().state.story.get("v18_legacy_collection",false)):host.revision_ui.text(parent,"全收集成就：已保留旧版26员工成就；新版图鉴目标为30位。")
	elif bool(m().state.story.get("v19_legacy_collection",false)):host.revision_ui.text(parent,"全收集成就：已保留旧版28员工成就；新版图鉴目标为30位。")
func bill(parent: Node,report: Dictionary):
	var host_ui=host.revision_ui
	var flows=report.get("cash_flows",m().full_rules.finance.flows_by_day(int(report.day)))
	var pickup=float(report.get("pickup_income",0));var income=float(report.get("operating_income",float(report.revenue)+pickup))
	host_ui.text(parent,"经营收入  ￥%.2f" % income,host.GREEN)
	var categories: Dictionary={};var incoming=0.0;var outgoing=0.0
	for flow in flows:
		var amount=float(flow.amount)
		if amount>0:incoming+=amount
		else:outgoing-=amount
		if str(flow.type) in ["sales","tips","pickup_cash"]:continue
		var key=str(flow.type);var record=categories.get(key,{"description":str(flow.description),"amount":0.0});record.amount+=amount;categories[key]=record
	for record in categories.values():host_ui.text(parent,str(record.description)+"  %+.2f" % float(record.amount))
	var day=int(report.day)
	parent.add_child(host.button("收起收入明细" if details.get(day,false) else "展开收入明细",func():details[day]=not details.get(day,false);host.open_panel(host.panel_name),false,"bill:details:"+str(day)))
	if details.get(day,false):
		host_ui.text(parent,"菜品￥%.2f · 小费￥%.2f · 手动拾取￥%.2f" % [float(report.dish_revenue),float(report.tips),pickup])
		for flow in flows:host_ui.text(parent,str(flow.description)+"  %+.2f" % float(flow.amount))
	host_ui.text(parent,"收入合计￥%.2f · 支出合计￥%.2f · 净现金流￥%.2f" % [incoming,outgoing,incoming-outgoing])
	host_ui.text(parent,"净利润￥%.2f · 现金核对：%s" % [float(report.net_profit),"已平衡" if report.cash_reconciled else "需检查"],host.GREEN)
	host_ui.text(parent,"采购形成存货、耗用计入成本；贷款本金与装修资产支出不直接计入利润。拾取不计入菜品营业额。")
func snapshot() -> Dictionary:
	var r=first.get_global_rect()
	return {"inventory_open":inventory_open,"status_rect":{"x":r.position.x,"y":r.position.y,"w":r.size.x,"h":r.size.y},"top_hidden":false,"position":"top","single_row":true,"reminders":summary_button.text,"info_open":info_popup.visible,"speed_open":speed_popup.visible}
