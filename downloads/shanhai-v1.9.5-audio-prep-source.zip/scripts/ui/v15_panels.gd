extends RefCounted
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const Pie = preload("res://scripts/ui/stat_pie.gd")
const GREEN = Color("427b6c")
const MUTED = Color("869088")
const WARN = Color("ad624d")
const TYPES = {"sales":"营业收入","tip":"小费","tips":"小费","procurement":"食材采购","interest":"债务利息","repayment":"债务还本","wages":"员工工资","rent":"房租","utilities":"水电","loan_interest":"贷款利息","loan_principal":"贷款本金","loan_repayment":"贷款还本","event":"事件收支","projects":"研发与培养","operating_expenses":"经营费用","other":"其他","stockout":"缺货","timeout":"等待超时","quality":"菜品品质差"}
const EXPENSE_TYPES = {"marketing":"宣传营销","research":"菜品研发","training":"员工培训","comfort":"员工关怀","recruitment":"员工招聘","supplier":"供应商解锁","decoration":"装修购置","expansion":"长期经营项目","debt_principal":"原始债务还本","debt_interest":"原始债务利息","liability_settlement":"经营欠款清偿","event_expense":"事件支出"}
var host
var model
var selected_day = -1
var flow_page = 0
func _init(ui) -> void:
	host = ui
	model = ui.model
func render(name: String) -> bool:
	match name:
		"待办汇总": todo_panel()
		"账单", "日结账单": bill_panel()
		"资金流水": flow_panel()
		"贷款": loan_panel()
		"破产救援": rescue_panel()
		"采购设置": procurement_panel()
		"顾客反馈": feedback_panel()
		"员工支线": sidequest_panel()
		"相生相克": synergy_panel()
		"世界排行榜": ranking_panel()
		_: return false
	return true
func action(parent: Node, text: String, kind: String, args: Dictionary = {}, destination: String = "", primary: bool = false) -> Button:
	return host.full_panels._action(parent,text,kind,args,destination,primary)
func link(parent: Node,text: String,destination: String,id: String = "") -> void:
	parent.add_child(host.button(text,func(): host.open_panel(destination),false,id if not id.is_empty() else "full:open:" + destination))
func section(title: String,detail: String = "") -> VBoxContainer:
	return host.full_panels._body(title,detail)
func text(parent: Node,value: String,color: Color = MUTED) -> void:
	host.full_panels._text(parent,value,color)
func tabs() -> void:
	var row = host.full_panels._flow(host.modal_body)
	for entry in ["账单","资金流水","贷款","顾客反馈","采购设置"]: link(row,entry,entry,"finance:tab:" + entry)
func finance() -> Dictionary:
	return model.full_rules.finance.snapshot(selected_day) if "finance" in model.full_rules and model.full_rules.finance != null else {}
func day_filter() -> void:
	var controls = host.row()
	host.modal_body.add_child(controls)
	controls.add_child(host.label("查看日期",14))
	var select = OptionButton.new()
	select.custom_minimum_size.y = 44
	select.set_meta("qa_id","bill:day_filter")
	select.add_item("全部日期 / 最近记录",-1)
	var current_day = int(model.state.total_minutes / 1440) + 1
	for day in range(current_day,maxi(0,current_day - 60),-1): select.add_item("第%d日" % day,day)
	for index in range(select.item_count):
		if select.get_item_id(index) == selected_day: select.select(index)
	select.item_selected.connect(func(index): selected_day = select.get_item_id(index);flow_page = 0;host.open_panel(host.panel_name))
	controls.add_child(select)
	controls.add_child(host.button("导出所选流水CSV",export_csv,false,"finance:csv"))
func todo_panel() -> void:
	host.action_notifications.update()
	var entries: Array = host.action_notifications.entries().filter(func(item):return str(item.id).begins_with("stage_task:"))
	host.paragraph("这里显示当前阶段的经营任务；教学引导独立展示，山海志和文化彩蛋不进入待办。",MUTED)
	if entries.is_empty(): host.paragraph("当前没有待办，可以安心经营。",GREEN)
	for entry in entries:
		var body = section(("● " if entry.level == "strong" else "● 可选 · ") + str(entry.title),str(entry.detail))
		var row = host.full_panels._flow(body)
		row.add_child(host.button("前往处理",func():
			if str(entry.id).begins_with("guide:"): Guide.resume(model,str(entry.id).substr(6))
			host.open_panel(str(entry.destination)),str(entry.level) == "strong","todo:open:" + str(entry.id)))
		if bool(entry.ignorable) or entry.level == "weak":
			row.add_child(host.button("暂不处理" if entry.level == "strong" else "忽略提示",func():
				host.action_notifications.ignore(str(entry.id));model.autosave_requested.emit();host.open_panel("待办汇总"),false,"todo:ignore:" + str(entry.id)))
func bill_panel() -> void:
	tabs()
	day_filter()
	var snapshot = finance()
	if snapshot.is_empty(): host.paragraph("财务服务正在初始化。",MUTED);return
	var bills: Array = snapshot.get("bills",[])
	if selected_day > 0: bills = bills.filter(func(bill): return int(bill.get("day",0)) == selected_day)
	if bills.is_empty() or selected_day == int(snapshot.get("current_day",-2)):
		var preview: Dictionary = snapshot.get("preview",{})
		var body = section("今日账单 · 结算前预览",str(preview.get("note","这是目前真实累计经营记录；预计费用尚未扣款。")))
		for pair in [["revenue","已记营业额"],["tips","其中小费"],["procurement","已采购支出"],["cost_of_sales","已耗用食材成本"],["wages_due","预计员工工资"],["rent_due","预计房租"],["utilities_due","预计水电"],["interest_due","预计债务利息"],["minimum_due","预计最低还款"],["loan_interest_due","预计贷款利息"],["current_cash","目前现金"]]:
			text(body,"%s：￥%.2f" % [str(pair[1]),float(preview.get(pair[0],0))])
		if bool(snapshot.get("protected",false)): text(body,"当前处于新手保护期：免房租水电、最低还款减半且不触发债务逾期。",GREEN)
		body.add_child(host.button("结算至次日，查看实际账单",func(): model.skip_to_next_morning();host.open_panel("账单"),false,"bill:settle"))
	var shown = bills.slice(maxi(0,bills.size() - 14))
	for bill in shown:
		var body = section("第%d日 · 日结账单" % int(bill.get("day",0)),"期初现金￥%.2f → 期末现金￥%.2f" % [float(bill.get("opening_cash",0)),float(bill.get("closing_cash",0))])
		host.bottom_ui.bill(body,bill)
	host.arrears_control()
	chart(host.modal_body,"近7日实际现金支出构成",snapshot.get("expense_composition",[]))
	host.full_panels.debt_time_panel()
	Guide.observe(model,"panel:账单")
func flow_panel() -> void:
	tabs()
	day_filter()
	var entries: Array = finance().get("flows",[])
	host.paragraph("每笔资金变化记录时间、用途、金额与变化后余额。每页40笔，最新记录优先。",MUTED)
	var start = maxi(0,entries.size() - (flow_page + 1) * 40)
	var finish = maxi(0,entries.size() - flow_page * 40)
	for index in range(finish - 1,start - 1,-1):
		var entry: Dictionary = entries[index]
		var minute = int(entry.get("minute",0))
		var amount = float(entry.get("amount",0))
		var body = section("第%d日 %02d:%02d · %s" % [int(minute / 1440) + 1,int(minute % 1440 / 60),minute % 60,str(entry.get("description",entry.get("type","资金变动")))])
		text(body,"%s￥%.2f · 余额 ￥%.2f" % ["+" if amount >= 0 else "−",absf(amount),float(entry.get("balance",0))],GREEN if amount >= 0 else WARN)
	if entries.is_empty(): host.paragraph("此日期暂无资金流水。",MUTED)
	var row = host.row()
	host.modal_body.add_child(row)
	if flow_page > 0: row.add_child(host.button("更新的40笔",func(): flow_page -= 1;host.open_panel("资金流水"),false,"finance:flow:newer"))
	if start > 0: row.add_child(host.button("更早的40笔",func(): flow_page += 1;host.open_panel("资金流水"),false,"finance:flow:older"))
func loan_panel() -> void:
	var snapshot = finance()
	var loan: Dictionary = snapshot.get("loan",{})
	host.paragraph("白泽：贷款提供周转资金，也带来每日1%的利息。只能保留一笔未结清贷款，30天到期，逾期另有声望与罚款后果。",MUTED)
	if float(loan.get("principal",0)) > 0:
		var body = section("现有贷款", "剩余本金 ￥%.2f · 第%d日到期" % [float(loan.get("principal",0)),int(loan.get("due_day",0))])
		text(body,"利息欠款￥%.2f · 罚款欠款￥%.2f" % [float(loan.get("interest_arrears",0)),float(loan.get("fine_arrears",0))])
		for amount in [100,500,int(ceil(float(loan.get("principal",0)) + float(loan.get("interest_arrears",0)) + float(loan.get("fine_arrears",0))))]:
			action(body,"偿还贷款 ￥%d" % amount,"loan_repay",{"amount":amount},"贷款")
	else:
		for tier in snapshot.get("loan_tiers",[]): action(host.modal_body,"申请贷款 ￥%d · 所需声望%d" % [int(tier.amount),int(tier.get("reputation",0))],"loan_apply",{"amount":int(tier.amount)},"贷款",true)
	var emergency: Dictionary=model.state.rescue171.loan
	if float(emergency.principal)+float(emergency.interest_arrears)+float(emergency.fine_arrears)>0:
		var body=section("一次性紧急救援贷款","日息2%，第%d日到期。本金￥%.2f，欠息￥%.2f，罚款￥%.2f。" % [int(emergency.due_day),float(emergency.principal),float(emergency.interest_arrears),float(emergency.fine_arrears)])
		for amount in [100,500,ceilf(float(emergency.principal)+float(emergency.interest_arrears)+float(emergency.fine_arrears))]:
			host.revision_ui.action(body,"偿还紧急贷款 ￥%.0f" % float(amount),"emergency_repay",{"amount":float(amount)},"贷款")
	if bool(snapshot.get("rescue",{}).get("pending",false)): link(host.modal_body,"返回救援选择","破产救援","rescue:back")
func rescue_panel() -> void:
	var snapshot = finance()
	var rescue: Dictionary = snapshot.get("rescue",{})
	host.paragraph("白泽：小馆暂时陷入周转危机。经营已暂停，存档没有删除。你可以申请紧急贷款（每日1%利息）、保留永久收集重开，或读取最近存档。请先选择一条出路。",WARN)
	host.paragraph(str(rescue.get("reason","连续欠付工资或房租，需要处理资金风险。")),WARN)
	var loan: Dictionary = snapshot.get("loan",{})
	if float(loan.get("principal",0)) <= 0:
		for tier in snapshot.get("loan_tiers",[]): action(host.modal_body,"A · 紧急贷款 ￥%d（每日1%%利息）" % int(tier.amount),"loan_apply",{"amount":int(tier.amount)},"贷款",true)
	else: host.paragraph("已有未结清贷款，不能借新还旧；可选择读取存档或重开。",MUTED)
	action(host.modal_body,"B · 重开本局（保留图鉴与成就）","bankruptcy_restart",{},"欢迎")
	action(host.modal_body,"C · 读取最近存档","bankruptcy_load",{},"欢迎")
func procurement_panel() -> void:
	var management = model.full_rules.management
	var snapshot: Dictionary = management.snapshot()
	var procurement: Dictionary = snapshot.get("procurement",model.state.get("procurement",{}))
	host.paragraph("自动：按前3日平均消耗×1.2补货。固定：按你设置的数量采购。暂停：不自动花钱。全部在日结前执行，记入当日账单，现金不足时不透支。",MUTED)
	host.paragraph("当前策略：" + str(procurement.get("strategy",procurement.get("mode","auto"))),GREEN)
	for pair in [["auto","自动补货"],["fixed","固定数量"],["pause","暂停采购"]]: action(host.modal_body,str(pair[1]),"set_procurement_strategy",{"strategy":str(pair[0])},"采购设置",true)
	var quantities: Dictionary = procurement.get("fixed_quantities",{})
	for item in snapshot.get("stock",[]):
		var id = str(item.get("id",""))
		var body = section(str(item.get("name",id)))
		var row = host.row()
		body.add_child(row)
		var amount = SpinBox.new()
		amount.min_value = 0
		amount.max_value = 10000
		amount.step = 1
		amount.value = float(quantities.get(id,0))
		amount.custom_minimum_size = Vector2(140,44)
		row.add_child(amount)
		row.add_child(host.button("保存固定采购量",func(): host.full_panels._perform("set_procurement_quantity",{"id":id,"quantity":amount.value},"采购设置"),false,"finance:procurement:" + id))
func feedback_panel() -> void:
	if not "customer_service" in model.full_rules or model.full_rules.customer_service == null: return
	var snapshot: Dictionary = model.full_rules.customer_service.snapshot()
	var today: Dictionary = snapshot.get("today",{})
	host.paragraph("顾客到店不受库存控制；缺货会影响能点的菜、心情与口碑。以下来自实际订单，打开面板不会抹除统计。",MUTED)
	var body = section("今日顾客反馈","缺货%d单 · 好评%d · 差评%d · 满意度 %.1f%%" % [int(today.get("stockouts",0)),int(today.get("good_reviews",0)),int(today.get("bad_reviews",0)),float(snapshot.get("satisfaction",0))])
	text(body,"到店%d · 完成%d单 · 等待超时%d" % [int(today.get("arrivals",0)),int(today.get("completed",0)),int(today.get("timeouts",0))])
	text(body,"次日客流系数 %.2f · %s" % [float(snapshot.get("next_day_traffic_multiplier",1)),"口碑受损，及时补货改善服务" if bool(snapshot.get("reputation_damaged",false)) else "尚无缺货口碑标记"],WARN if bool(snapshot.get("reputation_damaged",false)) else GREEN)
	var reasons: Array = []
	for key in today.get("reasons",{}): reasons.append({"type":key,"amount":today.reasons[key]})
	chart(host.modal_body,"差评原因分布",reasons)
	var sold_out: Array = snapshot.get("sold_out",[])
	if not sold_out.is_empty():
		var stock = section("当前售罄菜单")
		for dish in sold_out: text(stock,str(dish.name) + " · 售罄",WARN)
		link(stock,"调整库存与采购","采购设置","finance:tab:采购设置")
	for notice in snapshot.get("notices",[]).slice(-10): text(host.modal_body,str(notice.get("text","")))
func chart(parent: Node,title: String,items: Array) -> void:
	var box = section(title)
	# Wrap the legend as a whole below the pie when space is tight. Wrapped
	# Labels in an HBox otherwise advertise a one-character minimum width.
	var row = HFlowContainer.new()
	row.add_theme_constant_override("h_separation",12)
	row.add_theme_constant_override("v_separation",12)
	box.add_child(row)
	var pie = Pie.new()
	pie.items = items
	pie.custom_minimum_size = Vector2(150,150)
	row.add_child(pie)
	var labels = host.column(4)
	labels.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	labels.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(labels)
	if items.is_empty(): labels.add_child(host.label("暂无数据",14,MUTED))
	for index in range(items.size()):
		var item: Dictionary = items[index]
		var type = str(item.get("type","other"))
		var caption = str(TYPES.get(type,EXPENSE_TYPES.get(type,type)))
		# Legend entries keep their natural width, including the full amount.
		labels.add_child(host.label("● %s  %.2f" % [caption,float(item.get("amount",0))],14,Pie.COLORS[index % Pie.COLORS.size()]))
func export_csv() -> void:
	if not "finance" in model.full_rules or model.full_rules.finance == null: return
	var csv: String = model.full_rules.finance.export_csv(selected_day)
	if OS.has_feature("web"):
		JavaScriptBridge.download_buffer(csv.to_utf8_buffer(),"shanhai-cash-flow.csv","text/csv;charset=utf-8")
		host.show_notice("已请求下载资金流水CSV。")
	else:
		var path = "user://shanhai-cash-flow.csv"
		var file = FileAccess.open(path,FileAccess.WRITE)
		if file == null: host.show_notice("无法写入CSV，请检查用户目录权限。");return
		file.store_string(csv)
		host.show_notice("资金流水已导出：" + ProjectSettings.globalize_path(path))
func sidequest_panel() -> void:
	if not "sidequests" in model.full_rules or model.full_rules.sidequests == null: return
	var snapshot: Dictionary = model.full_rules.sidequests.snapshot()
	host.paragraph("好感、个人剧情与《白泽图》独立记录。文化简介始终可读；剧情解锁需要真实结识与经营任务。",MUTED)
	var pages = section("《白泽图》残页","已收集%d/%d · %s" % [int(snapshot.get("page_count",0)),int(snapshot.get("page_target",25)),"白泽已可招募" if bool(snapshot.get("baize_unlocked",false)) else "白泽仍是引导NPC，不占员工位"])
	for page in snapshot.get("pages",[]):
		if bool(page.get("available",false)) and not bool(page.get("collected",false)): action(pages,"整理" + str(page.name) + "的档案页","baize_page",{"id":str(page.employee_id)},"员工支线")
	for entry in snapshot.get("affinity",[]):
		var body = section(str(entry.name) + " · 好感%d" % int(entry.value))
		action(body,"日常关怀（免费）","care",{"employee_id":str(entry.employee_id)},"员工支线")
		action(body,"赠茶 · ￥20","gift",{"employee_id":str(entry.employee_id),"kind":"tea"},"员工支线")
	for entry in snapshot.get("entries",[]):
		var body = section(str(entry.title),"好感%d · %s" % [int(entry.get("affinity",0)),str(entry.get("reason",""))])
		var node: Dictionary = entry.get("node",{})
		if bool(entry.get("available",false)):
			for line in node.get("lines",[]): text(body,str(line),GREEN)
			if bool(entry.get("can_read",false)): action(body,"阅读并继续","sidequest_read",{"id":str(entry.id)},"员工支线")
			if bool(entry.get("can_choose",false)):
				for choice in node.get("choices",[]): action(body,str(choice.label),"sidequest_choice",{"id":str(entry.id),"choice_id":str(choice.id)},"员工支线")
			if bool(entry.get("can_finish",false)): action(body,"保存结局并领取奖励","sidequest_finish",{"id":str(entry.id)},"员工支线",true)
		var task: Dictionary = entry.get("task",{})
		if not task.is_empty(): text(body,"%s：%s/%s" % [str(task.get("label","任务")),str(task.get("current",0)),str(task.get("target",0))])
		if not str(entry.get("ending","")).is_empty(): text(body,"已保存结局：" + str(entry.ending),GREEN)
	var visitor_lore: Array=model.state.get("special_visitors",{}).get("lore",[])
	if "gourmand_clue" in visitor_lore:
		var clue=section("山海志 · 老饕的口味笔记")
		text(clue,"老饕说，真正的山海盛宴藏在伙伴的故事里。整理白泽图残页、完成凤凰支线，并留意高品质研发与稀有食材，也许能发现菜单外的菜肴。")
	if "baize_old_friend" in visitor_lore:
		var memory=section("山海志 · 故人一盏茶")
		text(memory,"故人捧起茶杯，说起白泽曾在山路上为迷途旅人辨认方向。白泽把沿途异兽的习性记入图册，也记下人们互相照应的小事。故人笑道，今天这些见闻又在小馆的餐桌边续上了。")
	for item in snapshot.get("lore",[]):
		var body = section(("新 · " if bool(item.get("unlocked",false)) and not bool(item.get("read",false)) else "")+str(item.title))
		if bool(item.get("unlocked",false)):
			text(body,"。".join(str(item.text).split("。",false).slice(0,5))+"。")
			action(body,"标记已阅读","lore_read",{"id":str(item.id)},"员工支线")
		else: text(body,"继续完成支线，解锁世界观记录。")
func synergy_panel() -> void:
	if not "synergies" in model.full_rules or model.full_rules.synergies == null: return
	var snapshot: Dictionary = model.full_rules.synergies.snapshot()
	host.paragraph("相生与相克只在两位伙伴同时当班时生效；不同来源按独立规则计算。调整真实排班可以改变组合。",MUTED)
	link(host.modal_body,"前往员工排班","员工培养")
	var active_ids: Array = snapshot.get("active_pairs",[]).map(func(pair): return str(pair.get("id","")))
	for pair in snapshot.get("all_pairs",[]):
		var body = section(str(pair.get("name",pair.get("id","组合"))))
		text(body,str(pair.get("description",pair.get("text",""))))
		text(body,"当前生效" if str(pair.get("id","")) in active_ids else "尚未同时当班",GREEN)
	for pair in snapshot.get("conflicts",[]): text(host.modal_body,"相克警示：" + str(pair.get("name",pair.get("id","组合"))),WARN)
func ranking_panel() -> void:
	Guide.observe(model,"ranking_view")
	host.full_panels._snapshot_cache = host.full_panels._snapshot()
	host.full_panels.group_panel("ranking")
