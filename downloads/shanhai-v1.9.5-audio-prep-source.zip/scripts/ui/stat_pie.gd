extends Control
## Procedural chart; image replacement is optional and uses the existing art service.
var items: Array = []
const COLORS = [Color("6a9b83"),Color("d7a867"),Color("a28db7"),Color("78a4bb"),Color("bf7d73"),Color("a7aa72"),Color("89939b")]
func _draw() -> void:
	var total = 0.0
	for item in items: total += maxf(0,float(item.get("amount",0)))
	var radius = minf(size.y * 0.5 - 3, 70)
	var center = Vector2(radius + 4,size.y * 0.5)
	if total <= 0:
		draw_circle(center,radius,Color("e4e6dc"))
		return
	var angle = -PI / 2
	for index in range(items.size()):
		var value = maxf(0,float(items[index].get("amount",0)))
		var span = TAU * value / total
		if span <= 0: continue
		var points = PackedVector2Array([center])
		for segment in range(33): points.append(center + Vector2.from_angle(angle + span * segment / 32.0) * radius)
		draw_colored_polygon(points,COLORS[index % COLORS.size()])
		angle += span
