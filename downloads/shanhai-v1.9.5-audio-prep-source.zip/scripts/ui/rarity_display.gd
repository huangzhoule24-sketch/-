class_name RarityDisplay
extends RefCounted
## Shared rarity presentation. All colors, labels and optional image IDs come from rarity.json.

const DEFAULTS := {
	"N": {"color": "#9E9E9E", "label": "普通", "stars": 0, "icon_id": "", "scene_marker": ""},
	"R": {"color": "#2196F3", "label": "稀有", "stars": 1, "icon_id": "UI/rarity_r", "scene_marker": ""},
	"SR": {"color": "#9C27B0", "label": "超稀有", "stars": 2, "icon_id": "UI/rarity_sr", "scene_marker": ""},
	"SSR": {"color": "#FFD700", "label": "传说", "stars": 3, "icon_id": "UI/rarity_ssr", "scene_marker": "★"},
}
static var _config: Dictionary = {}


static func reload_config(path: String = "res://config/rarity.json") -> void:
	_config = DEFAULTS.duplicate(true)
	if not FileAccess.file_exists(path):
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not parsed is Dictionary:
		return
	for rarity in DEFAULTS:
		if not parsed.get(rarity) is Dictionary:
			continue
		var entry: Dictionary = parsed[rarity]
		if entry.get("color") is String and Color.html_is_valid(entry["color"]):
			_config[rarity]["color"] = entry["color"]
		if entry.get("label") is String:
			_config[rarity]["label"] = entry["label"]
		if entry.get("stars") is float or entry.get("stars") is int:
			_config[rarity]["stars"] = clampi(int(entry["stars"]), 0, 3)
		for field in ["icon_id", "scene_marker"]:
			if entry.get(field) is String:
				_config[rarity][field] = entry[field]


static func color_for(rarity: String) -> Color:
	return Color(_entry(rarity)["color"])


static func label_for(rarity: String) -> String:
	return str(_entry(rarity)["label"])


static func stars_for(rarity: String) -> int:
	return int(_entry(rarity)["stars"])


static func icon_for(rarity: String) -> String:
	return str(_entry(rarity)["icon_id"])


static func scene_marker_for(rarity: String) -> String:
	return str(_entry(rarity)["scene_marker"])


static func create_badge(rarity: String, compact: bool = false, asset_catalog: RefCounted = null) -> PanelContainer:
	var normalized := rarity.to_upper() if DEFAULTS.has(rarity.to_upper()) else "N"
	var panel := PanelContainer.new()
	panel.name = "RarityBadge"
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	apply_border(panel, normalized)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 5)
	panel.add_child(row)
	var icon_id := icon_for(normalized)
	if asset_catalog != null and not icon_id.is_empty() and asset_catalog.has_method("has_image") and asset_catalog.has_image(icon_id):
		var icon := TextureRect.new()
		icon.texture = asset_catalog.get_texture(icon_id)
		icon.custom_minimum_size = Vector2(18, 18)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		row.add_child(icon)
	var text := Label.new()
	text.name = "RarityText"
	text.text = normalized if compact else "%s · %s%s" % [normalized, label_for(normalized), " ★".repeat(stars_for(normalized))]
	text.add_theme_color_override("font_color", color_for(normalized))
	text.add_theme_font_size_override("font_size", 14)
	row.add_child(text)
	panel.tooltip_text = "%s · %s" % [normalized, label_for(normalized)]
	return panel


static func apply_border(control: Control, rarity: String) -> void:
	var style := StyleBoxFlat.new()
	var color := color_for(rarity)
	style.bg_color = Color(color.r, color.g, color.b, 0.10)
	style.border_color = color
	style.set_border_width_all(2)
	style.set_corner_radius_all(6)
	style.content_margin_left = 7.0
	style.content_margin_right = 7.0
	style.content_margin_top = 3.0
	style.content_margin_bottom = 3.0
	control.add_theme_stylebox_override("panel", style)


static func _entry(rarity: String) -> Dictionary:
	if _config.is_empty():
		reload_config()
	return _config.get(rarity.to_upper(), _config["N"])
