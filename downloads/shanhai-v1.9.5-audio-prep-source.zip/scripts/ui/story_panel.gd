extends RefCounted
## Story UI uses the shared modal and rules actions; all evidence lives in saves.
const MUTED = Color("869088")
const ACCENT = Color("427b6c")
var host
var model
var _show_opening = false
var _dialogue_id = ""

func _init(ui) -> void:
	host = ui
	model = ui.model

func _body(title: String, detail: String = "") -> VBoxContainer:
	var panel: PanelContainer = host.card()
	host.modal_body.add_child(panel)
	var result: VBoxContainer = host.column(8)
	panel.add_child(result)
	_text(result, title, Color("30493f"), 19)
	if not detail.is_empty(): _text(result, detail)
	return result

func _text(parent: Node, value: String, color: Color = MUTED, size: int = 14) -> void:
	var line: Label = host.label(value, size, color)
	line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(line)

func _action(parent: Node, text: String, action: String, args: Dictionary = {}, destination: String = "主线故事") -> void:
	var check: Dictionary = model.full_rules.can_perform(action, args)
	var button: Button = host.button(text, func():
		var result: Dictionary = model.full_rules.perform(action, args)
		host.show_notice(str(result.get("message", result.get("reason", ""))))
		if result.get("ok", false): model.autosave_requested.emit()
		host.open_panel(destination), true, "story:%s:%s" % [action, str(args.get("id", args.get("month", "")))])
	button.disabled = not bool(check.get("ok", false))
	button.tooltip_text = str(check.get("reason", ""))
	parent.add_child(button)
	if button.disabled and not button.tooltip_text.is_empty(): _text(parent, button.tooltip_text, Color("a26c40"), 12)

func _reward_summary(reward: Dictionary) -> String:
	var pieces: Array[String] = []
	if float(reward.get("cash", 0)) > 0: pieces.append("钞票￥%.2f" % float(reward.cash))
	if int(reward.get("gems", 0)) > 0: pieces.append("灵石%d" % int(reward.gems))
	if int(reward.get("skill_books", 0)) > 0: pieces.append("技能书%d本" % int(reward.skill_books))
	if bool(reward.get("hidden_recipe", false)): pieces.append("隐藏配方：白泽万象宴")
	return " · ".join(pieces) if not pieces.is_empty() else "剧情对白与纪念"

func render() -> bool:
	if str(model.state.get("mode", "")) != "full": return false
	var story = model.full_rules.get("story")
	if story == null: return false
	var data: Dictionary = story.snapshot()
	var opening: Dictionary = data.opening
	var intro = _body("有间小馆 · 主线故事", "从负债小馆到三界集团。剧情依据真实经营、事件选择与比赛结果推进；阶段升级沿用营业额与声望门槛。")
	intro.add_child(host.button("收起序章" if _show_opening else "重看序章与白泽引导", func():
		_show_opening = not _show_opening
		host.open_panel("主线故事"), false, "story:opening"))
	if _show_opening:
		_text(intro, str(opening.title), ACCENT)
		_text(intro, str(opening.text))
		_text(intro, str(opening.dialogue))
	_text(intro, "已结识%d / 30种神兽 · 主线收集目标为12种，全30种另有成就。" % int(data.collection))
	if bool(data.complete): _text(intro, "主线已完成，仍可继续经营、培养员工与收集图鉴。", ACCENT)
	for chapter in data.chapters:
		var body = _body(str(chapter.title), str(chapter.text))
		for entry in data.entries:
			if str(entry.chapter) != str(chapter.id): continue
			_render_entry(body, entry)
	var achievements = _body("独立成就", "全收集不是主线十二神兽的替代条件。离职保留曾经结缘的记录。")
	var permanent: Dictionary = model.state.get("permanent_archives", {})
	if not permanent.is_empty():
		var names: Array[String] = []
		for entry in data.entries:
			if permanent.has(str(entry.id)): names.append(str(entry.title))
		_text(achievements, "往局成就记录：" + "、".join(names) + "。本局的资源与剧情条件独立计算。", ACCENT)
	for entry in data.entries:
		if str(entry.chapter) == "collection": _render_entry(achievements, entry)
	var festival = _body("大荒市美食节", "申请只取得原事件的邀请；报名仍收取原定费用，活动冷却、排队、菜品品质与胜率照常生效。")
	_action(festival, "申请美食节邀请", "festival_invitation", {}, "事件")
	var calendar = _body("经营日历 · 第%d天" % int(data.day), "每月日1、5、10为本游戏自设节日；邻里活动需要真实支出，没有自动现金奖励。")
	if data.calendar.is_empty():
		_text(calendar, "今日正常经营。下一次节日会在日界时提醒。")
	else:
		_text(calendar, str(data.calendar.title), ACCENT, 17)
		_text(calendar, str(data.calendar.text))
		_text(calendar, "活动支出￥%.2f · 声望+%d · 员工心情+%d；每日限一次。" % [float(data.festival_cash_cost), int(data.festival_reputation), int(data.festival_mood)])
		_action(calendar, "今日活动已完成" if bool(data.calendar.hosted) else "自费举办邻里活动", "seasonal_activity")
	if not data.week.is_empty(): _text(calendar, "最近一周：营业额￥%.2f · 接待%d位。" % [float(data.week.revenue), int(data.week.served)])
	_text(calendar, "月度真实营业额达到￥%.2f，可领取%d本技能书。旧存档从接入本系统之日起累计，不追补历史月份。" % [float(data.monthly_revenue_target), int(data.monthly_books)])
	if data.monthly_reports.is_empty(): _text(calendar, "本月尚未结算，月末后可查看报告。")
	for report in data.monthly_reports:
		_text(calendar, "第%d月：营业额￥%.2f · 接待%d位%s" % [int(report.month), float(report.revenue), int(report.served), " · 已领取" if report.claimed else ""])
		_action(calendar, "领取第%d月经营技能书" % int(report.month), "monthly_story_claim", {"month": int(report.month)})
	return true

func _render_entry(parent: VBoxContainer, entry: Dictionary) -> void:
	var status = "已领取" if entry.claimed else "可领取" if bool(entry.claim_check.ok) else "条件达成，等待前篇" if entry.complete else "进行中" if entry.unlocked else "等待前篇"
	_text(parent, "%s · %s  (%d / %d)" % [str(entry.title), status, mini(int(entry.progress), int(entry.target)), int(entry.target)], ACCENT, 16)
	_text(parent, str(entry.description))
	_text(parent, "奖励：" + _reward_summary(entry.reward))
	_action(parent, "已领取" if entry.claimed else "领取剧情奖励", "story_claim", {"id": str(entry.id)})
	if entry.claimed:
		var id = str(entry.id)
		parent.add_child(host.button("收起对白" if _dialogue_id == id else "重看这一段对白", func():
			_dialogue_id = "" if _dialogue_id == id else id
			host.open_panel("主线故事"), false, "story:dialogue:" + id))
		if _dialogue_id == id: _text(parent, str(entry.dialogue))
