extends RefCounted
## An uncommitted, paused layout transaction. No clock/RNG/scheduler rollback.
const Space = preload("res://scripts/services/restaurant_space.gd")
var model
var builder_id = ""
var last_error = ""
var active = false
var original: Dictionary = {}
var history: Array[Dictionary] = []
func _init(game_model) -> void: model = game_model
func begin() -> void:
	if active: return
	active = true
	original = model.state.duplicate(true)
	history.clear()
	model.set_paused(true)
func move_reason(index: int,x: int,y: int) -> String:
	var layout: Array = model.state.get("layout",[])
	if index < 0 or index >= layout.size(): return "请先选择要移动的家具"
	var item: Dictionary = layout[index]
	if int(item.x)==x and int(item.y)==y: return ""
	var proposed=Rect2i(x,y,int(item.w),int(item.h))
	for other in range(layout.size()):
		if other==index: continue
		var entry: Dictionary=layout[other]
		if proposed.intersects(Rect2i(entry.x,entry.y,entry.w,entry.h)): return "此处已被其他家具占用，请另选空位"
	var dims=Space.grid_dimensions(model)
	if x<0 or y<0 or proposed.end.x>dims.x or proposed.end.y>dims.y: return "超出店内可用范围，请放在店内区域"
	var cursor=0
	for entry in layout:
		var capacity=0 if bool(entry.get("building",false)) else 4 if str(entry.id)=="table_four" else 2 if str(entry.id)=="table_two" else 0
		if entry==item:
			for guest in model.customers:
				if int(guest.seat)>=cursor and int(guest.seat)<cursor+capacity: return "有客人正在使用这件家具，请等其离座后再移动"
		cursor+=capacity
	var candidate=layout.duplicate(true);candidate[index].x=x;candidate[index].y=y
	if not Space.layout_is_safe(model,candidate): return "落点挡住了通路或员工/顾客的在途路线，请留出走道"
	if bool(item.get("building",false)): return "该设施正在施工中，施工完成后才能移动"
	if model.state.has("revision191") and model.full_rules.dollhouse.locked(model.full_rules.dollhouse.identity(item)): return "该设备正在使用中（有员工/顾客正在操作），请稍后再试"
	return ""
func can_move(index: int,x: int,y: int) -> bool:
	return move_reason(index,x,y).is_empty()
func move_item(index: int,x: int,y: int) -> bool:
	if not active: return false
	last_error=move_reason(index,x,y)
	if not last_error.is_empty(): return false
	if int(model.state.layout[index].x) == x and int(model.state.layout[index].y) == y: return false
	history.append(model.state.duplicate(true))
	model.state.layout[index].x = x
	model.state.layout[index].y = y
	model.changed.emit()
	return true
func purchase(id: String,x: int,y: int) -> bool:
	if not active or (str(model.state.mode) == "full" and int(model.state.stage) < 1): return false
	var before = model.state.duplicate(true)
	if str(model.state.mode)=="full":
		var result: Dictionary=model.full_rules.revision.book_build(id,x,y,builder_id)
		last_error=str(result.get("reason",""))
		if not result.ok:return false
	else:
		if not model.buy_decoration(id,x,y): return false
	history.append(before)
	return true
func undo() -> bool:
	if not active or history.is_empty(): return false
	model.state = history.pop_back().duplicate(true)
	model.changed.emit()
	return true
func finish(keep: bool) -> bool:
	if not active: return false
	var purchased = keep and int(model.state.get("decorations_purchased",0)) > int(original.get("decorations_purchased",0))
	if str(model.state.mode)=="full": purchased=keep and model.state.revision171.builds.size()>original.revision171.builds.size()
	if not keep: model.state = original.duplicate(true)
	elif str(model.state.mode)=="full": model.full_rules.revision.activate_builds()
	active = false
	history.clear()
	original.clear()
	model.changed.emit()
	return purchased
