extends RefCounted

## Read-only cultural context. Opening an entry never changes campaign unlocks.
const Catalog = preload("res://scripts/services/culture_catalog.gd")
const PINYIN_FONT = preload("res://assets/fonts/DejaVuSans.ttf")
const SUPPLEMENT = preload("res://assets/fonts/ShanhaiCJKSupplement.otf")
const GREEN = Color("427b6c")
const MUTED = Color("718078")
var host
var catalog = Catalog.new()
var kind: String = ""
var entry_id: String = ""
var entry: Dictionary = {}
var image_available: bool = false
var text_font: Font

func _init(ui) -> void:
	host = ui
	# Local fallback keeps uncommon quoted characters without changing the theme.
	text_font = host.FONT.duplicate()
	text_font.fallbacks = [SUPPLEMENT, PINYIN_FONT]

func select_entry(next_kind: String, id: String) -> bool:
	var candidate: Dictionary = catalog.get_entry(next_kind, id)
	if candidate.is_empty(): return false
	kind = next_kind
	entry_id = id
	entry = candidate
	return true

func render() -> void:
	if entry.is_empty(): return
	var overview = host.row(16)
	host.modal_body.add_child(overview)
	var image_box: PanelContainer = host.card()
	image_box.name = "CultureImage"
	image_box.custom_minimum_size = Vector2(132, 132) if host.compact_layout else Vector2(176, 176)
	overview.add_child(image_box)
	var texture: Texture2D = host.assets.culture_texture(kind, entry_id)
	image_available = texture != null and not host.assets.is_placeholder(texture)
	if image_available:
		var picture = TextureRect.new()
		picture.name = "CultureArtwork"
		picture.texture = texture
		picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		image_box.add_child(picture)
	else:
		var placeholder: Label = host.label(str(entry.get("name", "山海")).left(1) + "\n图像待补充", 20, GREEN)
		placeholder.name = "CultureImagePlaceholder"
		placeholder.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		placeholder.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		image_box.add_child(placeholder)
	var introduction: VBoxContainer = host.column(8)
	introduction.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	overview.add_child(introduction)
	_text(introduction, str(entry.get("name", entry_id)), 25, GREEN)
	if not str(entry.get("pinyin", "")).is_empty():
		var pinyin_label: Label = _text(introduction, str(entry.pinyin), 15, MUTED)
		pinyin_label.name = "CulturePinyin"
		pinyin_label.add_theme_font_override("font", PINYIN_FONT)
	_text(introduction, brief(str(entry.get("summary","")),3),16)
	if kind=="employees":
		var employee: Dictionary=host.model._employee_config(entry_id)
		_text(introduction,"职责："+host.role_name(str(employee.get("role",""))),14,GREEN)
		_text(introduction,"神通："+str(employee.get("skill_description","")),14)
	else:
		var dish: Dictionary={}
		for item in host.model.dishes:
			if str(item.id)==entry_id:dish=item;break
		if dish.is_empty():dish=host.model.full_rules.management.config.get("hidden_recipe",{})
		_text(introduction,"特色："+str(dish.get("description","山海主题创意菜")),14,GREEN)
		_text(introduction,"食材："+str(dish.get("ingredients_description","按配方采购，详见菜单")),14)
		_text(introduction,"适合厨师："+str(host.model._employee_config(str(dish.get("required_employee",""))).get("name","在职厨师")),14)
		_text(introduction,"效果："+str(dish.get("effect_description",dish.get("bonus_description",dish.get("description","按品质、定价和顾客偏好结算收益")))),14)

func brief(value: String,maximum: int=5) -> String:
	var pieces=value.replace("！","。").replace("？","。").split("。",false)
	return "。".join(pieces.slice(0,maximum))+("。" if not pieces.is_empty() else "")

func snapshot() -> Dictionary:
	var titles: Array[String] = []
	for section in entry.get("sections", []): titles.append(str(section.get("title", "")))
	var urls: Array[String] = []
	for source in catalog.sources_for(entry): urls.append(str(source.get("url", "")))
	return {"kind":kind, "id":entry_id, "name":str(entry.get("name", "")), "summary":str(entry.get("summary", "")), "origin_label":str(entry.get("origin_label", "")), "section_titles":titles, "source_urls":urls, "source_count":urls.size(), "image_available":image_available, "resource_id":host.assets.culture_resource_id(kind, entry_id)}

func _source_short(id: String) -> String:
	for source in catalog.sources_for(entry):
		if str(source.get("id", "")) == id:
			var work: String = str(source.get("work", source.get("title", "")))
			var chapter: String = str(source.get("chapter", ""))
			return work + ("·" + chapter if not chapter.is_empty() else "")
	return id

func _section(title: String) -> VBoxContainer:
	var panel: PanelContainer = host.card()
	host.modal_body.add_child(panel)
	var body: VBoxContainer = host.column(8)
	panel.add_child(body)
	_text(body, title, 18, GREEN)
	return body

func _text(parent: Node, text: String, font_size: int = 16, color: Color = Color("30493f")) -> Label:
	var result: Label = host.label(text, font_size, color)
	result.add_theme_font_override("font", text_font)
	result.set_meta("culture_body_text", true)
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(result)
	return result
