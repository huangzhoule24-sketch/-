extends RefCounted
## State-driven reminders: opening a panel never resolves a required operation.
const Guide = preload("res://scripts/core/tutorial_progress.gd")
const Policy = preload("res://scripts/ui/interface_policy.gd")
var model
var _current: Dictionary = {}

func _init(game_model) -> void:
	model = game_model

func _state() -> Dictionary:
	if not model.state.get("ui_notifications") is Dictionary: model.state["ui_notifications"] = {}
	var data: Dictionary = model.state.ui_notifications
	if not data.get("read") is Dictionary: data["read"] = {}
	if not data.get("ignored") is Dictionary: data["ignored"] = {}
	if not data.get("enabled") is bool: data["enabled"] = true
	return data

func _add(target: Dictionary, key: String, group: String, title: String, destination: String, level: String = "strong", detail: String = "", ignorable: bool = false) -> void:
	target[key] = {"id":key,"group":group,"title":title,"destination":destination,"level":level,"detail":detail,"ignorable":ignorable}

func update() -> void:
	var conditions: Dictionary = {}
	if str(model.state.get("mode", "")) != "full":
		_current = conditions
		return
	for kind in ["normal", "advanced"]:
		if bool(model.full_rules.can_perform("recruit", {"kind":kind}).get("ok", false)):
			_add(conditions, "staff:hire:" + kind, "staff", "可招聘新伙伴", "招聘", "strong", "货币充足；完成招聘或选择暂不招募。", true)
	for id in model.state.get("contracts", []): _add(conditions, "staff:contract:" + str(id), "staff", "契约可招募", "招聘", "strong", "使用已有员工契约。", true)
	for employee in model.employees:
		var id = str(employee.id)
		if float(employee.get("stamina", 100)) <= 20 or float(employee.get("mood", 100)) <= 30:
			_add(conditions, "staff:care:" + id, "staff", str(employee.name) + "需要照顾", "员工培养", "strong", "安排休息或沟通；状态恢复后提醒才消失。")
		if bool(model.full_rules.can_perform("train_attribute", {"id":id,"attribute":"cooking"}).get("ok",false)):
			_add(conditions,"training:" + id,"staff",str(employee.name) + "可训练","员工培养","strong","训练会消耗资金并暂停工作，可手动忽略。",true)
	if int(model.state.stage) >= 1:
		for dish in model.dishes:
			if not str(dish.id) in model.state.unlocked_dishes and bool(model.full_rules.can_perform("research", {"id":str(dish.id)}).get("ok",false)):
				_add(conditions,"research:" + str(dish.id),"research",str(dish.name) + "可研发","研发")
	# Starting a project does not mean its work is finished. Keep the same reminder
	# through the actual project; completion or failure is read from model state.
	for project in model.state.get("management",{}).get("projects",[]):
		if str(project.get("type","")) == "research":
			var dish_id = str(project.get("dish_id",""))
			if not dish_id.is_empty(): _add(conditions,"research:" + dish_id,"research","菜品研发中","研发","strong","等待研发完成；打开面板不会清除此提醒。")
		elif str(project.get("type","")) in ["train_attribute","attribute","secondary","train_secondary"]:
			var employee_id = str(project.get("employee_id",""))
			if not employee_id.is_empty(): _add(conditions,"training:" + employee_id,"staff","员工训练中","员工培养","strong","训练完成后处理本次提醒，也可暂时忽略。",true)
	for decoration in (model.decorations if int(model.state.stage) >= 1 else []):
		if float(model.state.cash) >= float(model.balance.get(str(decoration.cost_key),INF)):
			_add(conditions,"decor:" + str(decoration.id),"decor","可购置" + str(decoration.name),"装修")
			break
	if int(model.state.stage) >= 2:
		var active_ids: Array = []
		for bond in model.active_bonds(): active_ids.append(str(bond.id))
		for bond in model.bonds:
			if str(bond.id) in active_ids: continue
			var owned = true
			for id in bond.get("employee_ids", []):
				if model._employee(str(id)).is_empty(): owned = false
			if owned: _add(conditions,"bonds:" + str(bond.id),"bonds","可排班激活" + str(bond.name),"羁绊图鉴","strong","让组合伙伴同班工作。",true)
	var stage = int(model.state.stage) + 1
	if stage <= 4 and float(model.state.total_revenue) >= float(model.balance.get("stage.%d.revenue" % stage,INF)) and float(model.state.reputation) >= float(model.balance.get("stage.%d.reputation" % stage,INF)):
		_add(conditions,"growth:stage:%d" % stage,"growth","经营升级条件已达成","经营升级","strong","完成升级后逐项学习新功能。",true)
	for quest in model.quest_status():
		if bool(quest.get("unlocked",false)) and bool(quest.get("complete",false)) and not bool(quest.get("claimed",false)): _add(conditions,"growth:claim:" + str(quest.id),"growth","奖励可领取：" + str(quest.get("title",quest.id)),"任务")
	var event: Dictionary = model.pending_event()
	if not event.is_empty(): _add(conditions,"events:%s:%s" % [str(event.id),str(event.get("serial",event.get("queued_minute",0)))],"events","事件待决定：" + str(event.get("title",event.id)),"事件")
	if float(model.state.get("wage_arrears",0)) + float(model.state.get("rent_arrears",0)) + float(model.state.get("interest_arrears",0)) > 0:
		_add(conditions,"debt:arrears","debt","欠款需要处理","账单","strong","补缴欠薪、欠租和利息；打开账单不会清除提醒。")
	if "finance" in model.full_rules and model.full_rules.finance != null:
		var finance: Dictionary = model.full_rules.finance.snapshot()
		if bool(finance.get("rescue",{}).get("pending",false)): _add(conditions,"debt:rescue","debt","经营危机：选择救援出路","破产救援")
		if int(finance.get("unpaid_days",0)) > 0: _add(conditions,"debt:risk","debt","现金周转风险","贷款")
	var stage_task: Dictionary=model.full_rules.revision.current_task() if "revision" in model.full_rules else {}
	if not stage_task.is_empty(): _add(conditions,"stage_task:"+str(stage_task.id),"growth",str(stage_task.title)+" %.0f/%.0f" % [float(stage_task.progress),float(stage_task.target)],str(stage_task.destination),"strong",str(stage_task.description),true)
	for employee_id in model.state.get("story",{}).get("collected_ids",[]):
		_add(conditions,"catalog:employee:" + str(employee_id),"catalog","新员工已收集","图鉴","weak")
	for dish_id in model.state.get("unlocked_dishes",[]):
		_add(conditions,"catalog:dish:" + str(dish_id),"catalog","新菜品已收集","图鉴","weak")
	var data = _state()
	for key in data.ignored.keys():
		if not conditions.has(key): data.ignored.erase(key)
	_current = conditions

func entries(group: String = "") -> Array:
	var data = _state()
	var result: Array = []
	for key in _current:
		var item: Dictionary = _current[key]
		if Policy.minimum_stage(str(item.destination)) > int(model.state.stage): continue
		if not group.is_empty() and str(item.group) != group: continue
		if data.ignored.has(key): continue
		if str(item.level) == "weak" and (not bool(data.enabled) or data.read.has(key)): continue
		result.append(item.duplicate(true))
	result.sort_custom(func(a,b): return str(a.level) == "strong" and str(b.level) != "strong")
	return result

func has_unread(group: String) -> bool:
	return not entries(group).is_empty()

func primary() -> Dictionary:
	var task=model.full_rules.revision.current_task() if str(model.state.get("mode",""))=="full" else {}
	if not task.is_empty():return {"id":"stage_task:"+str(task.id),"title":str(task.title)+" %.0f/%.0f" % [float(task.progress),float(task.target)],"destination":str(task.destination)}
	return {"title":"阶段经营目标已完成","destination":"经营升级"}

func count(group: String = "") -> int:
	return entries(group).size()

func acknowledge(group: String) -> bool:
	# Compatibility API now acknowledges weak notices only.
	var changed = false
	for item in entries(group):
		if str(item.level) == "weak":
			_state().read[item.id] = true
			changed = true
	return changed

func read_entry(id: String) -> void:
	_state().read[id] = true

func ignore(id: String) -> bool:
	if not _current.has(id): return false
	var item: Dictionary = _current[id]
	if not bool(item.ignorable) and str(item.level) != "weak": return false
	_state().ignored[id] = true
	return true

func complete_action(action: String, args: Dictionary = {}) -> void:
	var prefixes: Array = []
	match action:
		"recruit":
			var kind = str(args.get("kind","normal"))
			if kind != "contract": prefixes = ["staff:hire:" + kind]
		"buy_decoration": prefixes = ["decor:"]
	for item in entries():
		for prefix in prefixes:
			if str(item.id).begins_with(prefix): _state().ignored[item.id] = true

func enabled() -> bool:
	return bool(_state().enabled)

func set_enabled(value: bool) -> void:
	# Only optional yellow reminders can be hidden globally.
	_state()["enabled"] = value
