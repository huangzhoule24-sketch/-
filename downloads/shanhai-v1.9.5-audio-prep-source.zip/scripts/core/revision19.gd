extends RefCounted
## Pickup incentives share one authoritative award path, including timed attraction.
var _ref: WeakRef
func _init(host):_ref=weakref(host)
func m():return _ref.get_ref()
func v():return m().full_rules.revision18
func now() -> int:return int(m().state.total_minutes)
func s() -> Dictionary:return m().state.revision19
func ensure_state():
	if not m().state.has("revision19"):
		m().state.revision19={"version":1,"auto_until":0}
		if m().state.get("story") is Dictionary and "all_beasts" in m().state.story.get("completed",[]) and m().state.story.collected_ids.size()<30:m().state.story.v19_legacy_collection=true
func active(id: String) -> bool:return m().full_rules.active(id)
func skill(id: String) -> float:return m().full_rules.skill_scale(m()._employee(id))
func drop_chance(worker: Dictionary) -> float:
	var chance=v().value("pickup_drop_chance",.30)
	if float(m().state.get("cashier_speed_bonus",0))>0:chance+=v().value("pickup_drop_bonus_cashier",.05)
	if str(worker.get("id",""))=="pi_xiu":chance+=v().value("pickup_drop_bonus_pixiu",.05)
	if active("tian_lu"):chance+=v().value("pickup_bonus_tianlu",.05)*skill("tian_lu")
	if v().has_state("zhaocai_day"):chance+=v().value("pickup_event_zhaocai",.10)
	return clampf(chance,0,1)
func amount_bonus() -> float:return v().value("pickup_bonus_qingfu",.20)*skill("qing_fu") if active("qing_fu") else 0.0
func reward(pickup: Dictionary) -> float:
	if str(pickup.kind)=="gems":return float(pickup.amount)
	return m()._money(float(pickup.amount)*(1.0+maxf(amount_bonus(),float(pickup.get("cash_bonus",0)))))
func spawn(kind: String,amount: int):
	var position=v().drop_position()
	var item={"id":int(v().s().next_pickup),"kind":kind,"amount":amount,"x":position.x,"y":position.y,"remaining":15.0}
	if kind=="cash" and v().has_state("zhaocai_day"):item.cash_bonus=v().value("pickup_event_zhaocai_cash",.1)
	v().s().pickups.append(item);v().s().next_pickup+=1
	if auto_active():collect_all()
	while v().s().pickups.size()>3:v().s().pickups.pop_front()
func auto_active() -> bool:return m().state.has("revision19") and int(s().auto_until)>now()
func start_auto(duration: int=120):
	s().auto_until=now()+duration;collect_all()
func collect_all():
	for pickup in v().s().pickups.duplicate():v().perform("pickup_collect",{"id":int(pickup.id),"automatic":true})
func tick():
	if auto_active():collect_all()
	elif int(s().auto_until)>0:s().auto_until=0;m()._notify("散财童子告辞了，掉落物恢复手动拾取。")
func validate(saved: Dictionary) -> bool:
	if not saved.has("revision19"):return true
	var d: Variant=saved.revision19
	return d is Dictionary and d.get("version")==1 and m()._integer(d.get("auto_until")) and int(d.auto_until)<=int(saved.total_minutes)+120
