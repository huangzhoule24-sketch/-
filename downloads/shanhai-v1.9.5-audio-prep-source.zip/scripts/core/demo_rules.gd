extends RefCounted



var _model_ref: WeakRef
const CHAPTER_KEYS: = ["mode", "quests_claimed", "hire_counts", "fragments", "unlocked_dishes", "menu_enabled", "research_projects", "research_experience", "event_queue", "event_history", "event_last_minute", "event_first_triggered", "decorations_purchased", "stats", "hire_tickets", "starter_contract", "contracts", "completed", "layout", "traffic_bonus", "price_bonus", "cooking_speed_bonus", "procurement_discount", "discount_until", "kitchen_pause_until"]


func _init(model: RefCounted) -> void :
	_model_ref = weakref(model)


func _m() -> Variant:
	return _model_ref.get_ref()


func setting(section: String, key: String, fallback: Variant) -> Variant:
	var model: Variant = _m()
	return model.demo_config.get(section, {}).get(key, fallback)


func ensure_state_defaults() -> void :
	var model: Variant = _m()
	var state: Dictionary = model.state
	var initial_menu: Array = []
	for dish in model.dishes:
		if bool(dish.get("unlocked", false)): initial_menu.append(str(dish.id))
	var defaults = {"mode": "normal", "quests_claimed": [], "hire_counts": {"normal": 0, "advanced": 0}, 
		"fragments": {}, "unlocked_dishes": initial_menu.duplicate(), "menu_enabled": initial_menu.duplicate(), 
		"research_projects": [], "research_experience": {}, "event_queue": [], "event_history": [], 
		"event_last_minute": int(state.total_minutes), "event_first_triggered": false, 
		"decorations_purchased": 0, "stats": {"purchases": 0, "contracts": 0, "recruits": 0, "research_success": 0, "decorations": 0}, 
		"hire_tickets": 0, "starter_contract": false, "contracts": [], "completed": false, 
		"layout": [], "traffic_bonus": 0.0, "price_bonus": 0.0, "cooking_speed_bonus": 0.0, 
		"procurement_discount": 1.0, "discount_until": 0, "kitchen_pause_until": 0}
	for key in defaults:
		if not state.has(key): state[key] = defaults[key]
	if state.layout.is_empty():
		for placement in setting("layout", "initial", [{"id": "table_two", "x": 1, "y": 0}, {"id": "table_two", "x": 4, "y": 0}, {"id": "table_two", "x": 1, "y": 2}, {"id": "table_two", "x": 4, "y": 2}]):
			var definition = decoration(str(placement.id))
			state.layout.append({"id": str(placement.id), "x": int(placement.x), "y": int(placement.y), 
				"w": int(definition.get("width", 1)), "h": int(definition.get("height", 1))})
	for employee in model.employees:
		if not employee.has("research_until"): employee.research_until = 0
	for customer in model.customers:
		if not customer.has("task_started_minute"): customer.task_started_minute = int(customer.arrival_minute)


func start_demo() -> void :
	var model: Variant = _m()
	model.reset_game()
	model.state.mode = "demo"
	model.paused = true
	model._log("白泽：先完成第一笔生意，再领取开店奖励与毕方契约。")
	model.changed.emit()


func discard_legacy_chapter_fields() -> void :
	var model: Variant = _m()
	for key in CHAPTER_KEYS: model.state.erase(key)
	for employee in model.employees: employee.research_until = 0


func active_limit() -> int:
	var model: Variant = _m()
	var limits: Array = setting("stage", "active_limits", [3, 5])
	return int(limits[mini(int(model.state.stage), limits.size() - 1)])


func staffed_count() -> int:
	var model: Variant = _m()
	var result = 0
	for employee in model.employees:
		if not bool(employee.resting): result += 1
	return result


func can_return_to_work(id: String) -> bool:
	var model: Variant = _m()
	var employee: Dictionary = model._employee(id)
	return not bool(employee.get("resting", false)) or staffed_count() < active_limit()


func active(id: String) -> bool:
	var model: Variant = _m()
	var employee: Dictionary = model._employee(id)
	return not employee.is_empty() and not bool(employee.resting) and float(employee.stamina) > 0 and int(employee.training_until) <= int(model.state.total_minutes) and int(employee.get("research_until", 0)) <= int(model.state.total_minutes)


func skills_enabled(id: String) -> bool:
	return id in setting("skills", "supported_employee_ids", ["xian_yang", "xiao", "er_shu", "bi_fang", "jiu_wei_hu", "tao_tie", "pi_xiu"])


func coefficient(name: String, fallback_key: String) -> float:
	var model: Variant = _m()
	var mapping: Dictionary = setting("skills", "coefficients", {})
	var key = str(mapping.get(name, fallback_key))
	return float(model.balance.get(key, 0))


func active_bonds() -> Array[Dictionary]:
	var model: Variant = _m()
	var result: Array[Dictionary] = []
	for bond in model.bonds:
		var ready = bool(bond.get("implemented", true))
		for id in bond.get("employee_ids", []):
			if not active(str(id)): ready = false
		if ready: result.append(bond.duplicate(true))
	return result


func _effect_value(effect: Dictionary) -> float:
	var model: Variant = _m()
	var key = str(effect.get("value_key", effect.get("coeff_key", "")))
	return float(model.balance.get(key, 0)) if key != "" else float(effect.get("value", 0))


func bond_bonus(effect_type: String) -> float:
	var result = 0.0
	for bond in active_bonds():
		for effect in bond.get("effects", []):
			if str(effect.get("type", "")) == effect_type: result += _effect_value(effect)
	return result


func traffic_multiplier() -> float:
	var model: Variant = _m()
	return (1 + float(model.state.traffic_bonus)) * (1 + bond_bonus("traffic_bonus"))


func price_multiplier() -> float:
	var model: Variant = _m()
	return (1 + float(model.state.price_bonus)) * (1 + bond_bonus("price_bonus"))


func ingredient_multiplier(worker: Dictionary) -> float:
	var result = 1 + bond_bonus("ingredient_cost") + bond_bonus("ingredient_cost_mult")
	if str(worker.id) == "tao_tie" and active("tao_tie"):
		result *= 1 + coefficient("taotie_ingredient_cost", "coeff.ingredient_cost_mult")
	return result


func quality_multiplier(worker: Dictionary, dish: Dictionary) -> float:
	var result = 1.0
	if str(worker.id) == "xian_yang" and str(dish.id) == "qianyang_soup" and active("xian_yang"):
		result *= 1 + coefficient("qianyang_soup_quality", "coeff.qianyang_soup_quality")
	if str(worker.id) == "bi_fang" and str(dish.category) == "烧烤" and active("bi_fang"):
		result *= 1 + coefficient("bifang_bbq_quality", "coeff.bifang_bbq_quality")
	return result


func speed_multiplier(worker: Dictionary, task: String) -> float:
	var model: Variant = _m()
	var result = 1.0
	if str(worker.id) == "xiao" and model.period() == "night_market" and active("xiao"):
		result *= 1 + coefficient("owl_night_speed", "coeff.owl_night_speed")
	if str(worker.id) == "er_shu" and task == "serving" and active("er_shu"):
		result *= 1 + coefficient("earmouse_serve_speed", "coeff.earmouse_serve_speed")
	if task == "cooking":
		result *= 1 + float(model.state.cooking_speed_bonus)
		if str(worker.id) == "tao_tie" and active("tao_tie"):
			result *= 1 + coefficient("taotie_cooking_speed", "coeff.cooking_speed_mult")
	return result


func checkout_multiplier(worker: Dictionary) -> float:
	return 1 + coefficient("pixiu_checkout_bonus", "coeff.pixiu_checkout_bonus") if str(worker.get("id", "")) == "pi_xiu" and active("pi_xiu") else 1.0


func tip_bonus(worker: Dictionary) -> float:
	return coefficient("fox_tip_chance", "coeff.tip_chance_bonus") if str(worker.get("id", "")) == "jiu_wei_hu" and active("jiu_wei_hu") else 0.0


func stock_price() -> float:
	var model: Variant = _m()
	var discount = float(model.state.procurement_discount) if int(model.state.discount_until) > int(model.state.total_minutes) else 1.0
	return model._b("ingredient.unit_price") * discount


func _recruitable(entry: Dictionary) -> bool:
	return str(_m().state.get("mode",""))!="full" or str(entry.get("id",""))!="bai_ze" or (_m().full_rules.get("sidequests")!=null and _m().full_rules.sidequests.baize_unlocked())

func recruit(kind: String = "normal") -> Dictionary:
	var model: Variant = _m()
	var state: Dictionary = model.state
	if not kind in ["normal", "advanced", "contract"]: return {}
	var selection: Dictionary = {}
	var cost: float = 0.0
	if kind=="contract":
		if state.contracts.is_empty(): model._notify("还没有员工契约，先领取开店任务奖励"); return {}
		selection=model._employee_config(str(state.contracts[0]))
		if selection.is_empty(): return {}
		if not _recruitable(selection): model._notify("白泽仍是引导NPC，完成《白泽图》残页支线后才能招募"); return {}
		cost=float(setting("contracts","cash_cost",0))
	else:
		cost=model._b("hire.ticket_cost_"+kind)
		var pixiu: Dictionary=model._employee("pi_xiu")
		var pixiu_in_store: bool=not pixiu.is_empty() and str(pixiu.get("branch_id",""))=="" if str(state.get("mode",""))=="full" else active("pi_xiu")
		if (kind in ["normal","advanced"] if str(state.get("mode",""))=="full" else kind=="normal") and pixiu_in_store: cost=ceilf(cost*(1+coefficient("pixiu_hire_cost","coeff.hire_cost_mult")))
	if (kind=="advanced" and float(state.gems)<cost) or (kind!="advanced" and float(state.cash)<cost): model._notify("招聘资源不足，先经营或领取任务奖励"); return {}
	# Resolve the real eligible pool before charging or consuming a contract/pity.
	if kind!="contract":
		var count: int=int(state.hire_counts[kind])+1
		var rarity: String="N"
		var rng_before: int=model._rng.state
		if count%int(model._b("hire."+kind+"_pity_ssr"))==0: rarity="SSR"
		elif count%int(model._b("hire."+kind+"_pity_sr"))==0: rarity="SR"
		else:
			var roll: float=model._rng.randf()
			var cumulative: float=0.0
			for candidate in ["N","R","SR","SSR"]:
				cumulative+=model._b("hire."+kind+"_probability_"+candidate)
				if roll<cumulative: rarity=candidate; break
		var candidates: Array=[]
		for employee in model.catalog:
			if str(employee.rarity)==rarity and _recruitable(employee): candidates.append(employee)
		if candidates.is_empty(): model._rng.state=rng_before; model._notify("当前稀有度没有可招募员工，未扣费"); return {}
		selection=candidates[model._rng.randi_range(0,candidates.size()-1)]
	if kind=="contract":
		model.change_cash(-cost,"recruitment","员工契约招募："+str(selection.name))
		state.contracts.pop_front()
		state.hire_tickets=state.contracts.size()
		state.starter_contract=not state.contracts.is_empty()
		state.stats.contracts=int(state.stats.contracts)+1
	else:
		if kind=="advanced": state.gems=int(state.gems)-int(cost)
		else: model.change_cash(-cost,"recruitment","普通招聘："+str(selection.name))
		state.hire_counts[kind]=int(state.hire_counts[kind])+1
	var duplicate: bool = not model._employee(str(selection.id)).is_empty()
	var fragments = 0
	if duplicate:
		fragments = int(model._b("hire.duplicate_fragments"))
		state.fragments[str(selection.id)] = int(state.fragments.get(str(selection.id), 0)) + fragments
	else:
		var employee: Dictionary = model._create_employee(selection)
		employee.resting = staffed_count() >= active_limit()
		model.employees.append(employee)
	state.stats.recruits = int(state.stats.recruits) + 1
	var result = {"id": str(selection.id), "name": str(selection.name), "rarity": str(selection.rarity), "duplicate": duplicate, "fragments": fragments}
	model._notify("重复招募 %s，获得 %d 碎片" % [str(selection.name), fragments] if duplicate else "招募成功：%s（%s）" % [str(selection.name), str(selection.rarity)])
	model.changed.emit()
	return result


func set_menu_enabled(id: String, enabled: bool) -> bool:
	var model: Variant = _m()
	if not id in model.state.unlocked_dishes: return false
	if enabled and not id in model.state.menu_enabled: model.state.menu_enabled.append(id)
	elif not enabled and id in model.state.menu_enabled:
		if model.state.menu_enabled.size() <= 1:
			model._notify("菜单至少保留一道菜品")
			return false
		model.state.menu_enabled.erase(id)
	model.changed.emit()
	return true


func research_dish(id: String) -> bool:
	var model: Variant = _m()
	var state: Dictionary = model.state
	if not id in setting("research", "supported_ids", []) or id in state.unlocked_dishes: return false
	for project in state.research_projects:
		if str(project.dish_id) == id: return false
	var minimum = int(setting("research", "demo_min_stage", 0) if str(state.mode) == "demo" else setting("research", "normal_min_stage", 1))
	if int(state.stage) < minimum:
		model._notify("餐厅升级后才可研发特色菜品")
		return false
	var dish: Dictionary = model._dish(id)
	if dish.is_empty(): return false
	if str(dish.get("required_employee", "")) != "" and model._employee(str(dish.required_employee)).is_empty():
		model._notify("研发需要先招募" + str(model._employee_config(str(dish.required_employee)).get("name", dish.required_employee)))
		return false
	var chef: Dictionary = {}
	for employee in model.employees:
		if str(employee.role) in ["chef", "all"] and active(str(employee.id)):
			if chef.is_empty(): chef = employee
			if int(employee.busy_customer) == 0:
				chef = employee
				break
	if chef.is_empty():
		model._notify("需要一位在岗的厨师主持研发")
		return false
	var cost = float(setting("research", "cash_cost", 80))
	var ingredients = float(setting("research", "ingredient_cost", 2))
	if float(state.cash) < cost or float(state.ingredients) < ingredients:
		model._notify("研发需要 ￥%d 与 %d 份食材" % [int(cost), int(ingredients)])
		return false
	model.change_cash(-cost,"research","菜品研发："+str(dish.get("name",id)))
	state.ingredients = float(state.ingredients) - ingredients
	if int(chef.busy_customer) > 0:
		var customer: Dictionary = model._customer(int(chef.busy_customer))
		if not customer.is_empty():
			customer.remaining_minutes = maxi(1, int(customer.due_minute) - int(state.total_minutes))
			model._release_customer(customer)
			customer.worker = ""
			customer.due_minute = -1
	var due = int(state.total_minutes) + maxi(1, int(setting("research", "minutes", 30)))
	chef.research_until = due
	var guaranteed: bool = str(state.mode) == "demo" and id == str(setting("research", "first_guaranteed_id", "qianyang_soup"))
	state.research_projects.append({"dish_id": id, "employee_id": str(chef.id), "due": due, "guaranteed": guaranteed})
	model.scheduler.append({"type": "research_finish", "due": due, "dish_id": id, "employee_id": str(chef.id)})
	model._notify("开始研发 %s，%d 分钟后揭晓" % [str(dish.name), due - int(state.total_minutes)])
	model.changed.emit()
	return true


func finish_research(id: String) -> void :
	var model: Variant = _m()
	var state: Dictionary = model.state
	var project: Dictionary = {}
	for entry in state.research_projects:
		if str(entry.dish_id) == id: project = entry
	if project.is_empty(): return
	var chef: Dictionary = model._employee(str(project.employee_id))
	var creativity = float(chef.get("attributes", {}).get("creativity", 0))
	var experience = int(state.research_experience.get(id, 0))
	var chance = minf(float(setting("research", "success_cap", 0.99)), float(setting("research", "base_success", 0.9)) + (creativity + experience) * float(setting("research", "creativity_bonus", 0.02)))
	var success = bool(project.guaranteed) or experience >= int(setting("research", "max_failures_before_guarantee", 5)) or model._rng.randf() < chance
	if success:
		state.unlocked_dishes.append(id)
		state.menu_enabled.append(id)
		state.stats.research_success = int(state.stats.research_success) + 1
		model._notify("研发成功！%s 已加入菜单" % str(model._dish(id).name))
	else:
		state.research_experience[id] = experience + 1
		model._notify("研发未成功，积累经验，下次成功率提高")
	if not chef.is_empty(): chef.research_until = 0
	state.research_projects.erase(project)
	model.changed.emit()


func decoration(id: String) -> Dictionary:
	var model: Variant = _m()
	for entry in model.decorations:
		if str(entry.id) == id: return entry
	return {}


func _table_count() -> int:
	var model: Variant = _m()
	var count = 0
	for item in model.state.layout:
		if str(item.id) in ["table_two", "table_four"]: count += 1
	return count


func can_place_decoration(id: String, x: int, y: int) -> bool:
	var model: Variant = _m()
	var definition = decoration(id)
	if definition.is_empty(): return false
	var width = int(definition.get("width", 1))
	var height = int(definition.get("height", 1))
	if x < 0 or y < 0 or x + width > int(setting("layout", "width", 6)) or y + height > int(setting("layout", "height", 4)): return false
	var table_limits: Array = setting("stage", "table_limits", [4, 8])
	if id in ["table_two", "table_four"] and _table_count() >= int(table_limits[mini(int(model.state.stage), table_limits.size() - 1)]): return false
	var proposed = Rect2i(x, y, width, height)
	for item in model.state.layout:
		if proposed.intersects(Rect2i(int(item.x), int(item.y), int(item.w), int(item.h))): return false
	return true


func buy_decoration(id: String, x: int, y: int) -> bool:
	var model: Variant = _m()
	if not can_place_decoration(id, x, y):
		model._notify("这个位置无法摆放，检查范围、占位与餐桌上限")
		return false
	var definition = decoration(id)
	var cost: float = float(model.balance.get(str(definition.get("cost_key", "")), definition.get("cost", 0)))
	if float(model.state.cash) < cost:
		model._notify("现金不足，暂时无法购买装修")
		return false
	model.change_cash(-cost,"decoration","装修购买："+str(definition.name))
	model.state.layout.append({"id": id, "x": x, "y": y, "w": int(definition.get("width", 1)), "h": int(definition.get("height", 1))})
	for effect in definition.get("effects", []):
		var value = _effect_value(effect)
		match str(effect.get("type", "")):
			"seats": model.state.seats = int(model.state.seats) + int(value)
			"comfort": model.state.comfort = minf(float(model.balance.get("decoration.max_comfort", 100)), float(model.state.comfort) + value)
			"traffic_bonus": model.state.traffic_bonus = float(model.state.traffic_bonus) + value
			"price_bonus": model.state.price_bonus = float(model.state.price_bonus) + value
			"cooking_speed": model.state.cooking_speed_bonus = float(model.state.cooking_speed_bonus) + value
	model.state.decorations_purchased = int(model.state.decorations_purchased) + 1
	model.state.stats.decorations = int(model.state.stats.decorations) + 1
	model._notify("已摆放 " + str(definition.name))
	model.changed.emit()
	return true


func quest_status() -> Array[Dictionary]:
	var model: Variant = _m()
	var state: Dictionary = model.state
	var result: Array[Dictionary] = []
	for quest in model.quests_array:
		var progress = 0.0
		var target = 1.0
		var condition: Dictionary = quest.get("condition", {})
		match str(condition.get("type", "")):
			"serve": progress = float(state.served);target = float(condition.get("target", 1))
			"purchase": progress = float(state.stats.purchases);target = float(condition.get("target", 1))
			"contract": progress = float(state.stats.contracts);target = float(condition.get("target", 1))
			"research": progress = 1 if str(condition.get("target", "")) in state.unlocked_dishes else 0
			"decorate": progress = float(state.stats.decorations);target = float(condition.get("target", 1))
			"debt": progress = 1 if float(state.debt) <= float(condition.get("target", 0)) else 0
			"upgrade": progress = float(state.stage);target = float(condition.get("target", 1))
		var unlocked = true
		for prerequisite in quest.get("depends_on", []):
			if not str(prerequisite) in state.quests_claimed: unlocked = false
		var rewards: Dictionary = quest.get("rewards", {})
		var summary: Array[String] = []
		if float(rewards.get("cash", 0)) > 0: summary.append("￥%d" % int(rewards.cash))
		if int(rewards.get("gems", 0)) > 0: summary.append("灵石 %d" % int(rewards.gems))
		if float(rewards.get("ingredients", 0)) > 0: summary.append("食材 %d" % int(rewards.ingredients))
		if str(rewards.get("contract", "")) != "": summary.append(str(model._employee_config(str(rewards.contract)).get("name", "")) + "契约")
		result.append({"id": str(quest.id), "title": str(quest.get("title", "")), "description": str(quest.get("description", "")), 
			"progress": minf(progress, target), "target": target, "complete": progress >= target, 
			"claimed": str(quest.id) in state.quests_claimed, "unlocked": unlocked, "rewards": rewards.duplicate(true), "reward_summary": " / ".join(summary)})
	return result


func claim_quest(id: String) -> bool:
	var model: Variant = _m()
	if str(model.state.mode) != "demo": return false
	var quest: Dictionary = {}
	for entry in quest_status():
		if str(entry.id) == id: quest = entry
	if quest.is_empty() or not bool(quest.complete) or bool(quest.claimed) or not bool(quest.unlocked): return false
	model.state.quests_claimed.append(id)
	var rewards: Dictionary = quest.rewards
	model.change_cash(float(rewards.get("cash",0)),"reward","经营目标奖励："+id)
	model.state.gems = int(model.state.gems) + int(rewards.get("gems", 0))
	var units = float(rewards.get("ingredients", 0))
	if units > 0: model._add_stock(units, 0)
	var contract = str(rewards.get("contract", ""))
	if contract != "":
		model.state.contracts.append(contract)
		model.state.hire_tickets = model.state.contracts.size()
		model.state.starter_contract = true
	model._notify("任务完成：" + str(quest.title) + "  " + str(quest.reward_summary))
	if model.state.quests_claimed.size() == model.quests_array.size() and int(model.state.stage) >= 1:
		model.state.completed = true
		model._notify("有间小馆开业成功！债务还清，欢迎继续自由经营。")
	model.changed.emit()
	return true


func upgrade_restaurant() -> bool:
	var model: Variant = _m()
	if int(model.state.stage) != 0: return false
	var revenue = float(setting("stage", "demo_revenue", 1500)) if str(model.state.mode) == "demo" else float(model.balance.get("stage.1.revenue", 5000))
	var reputation = float(setting("stage", "demo_reputation", 80)) if str(model.state.mode) == "demo" else float(model.balance.get("stage.1.reputation", 100))
	if float(model.state.total_revenue) < revenue or float(model.state.reputation) < reputation:
		model._notify("升级需要累计营业额 ￥%d 与声望 %d" % [int(revenue), int(reputation)])
		return false
	if str(model.state.mode) == "demo" and bool(setting("stage", "require_debt_free", true)) and float(model.state.debt) > 0:
		model._notify("先还清债务，再为街角饭店举办开业典礼")
		return false
	model.state.stage = 1
	model._notify("餐厅升级为街角饭店！解锁 8 张餐桌与 5 个排班位。")
	model.changed.emit()
	return true


func _event_definition(id: String) -> Dictionary:
	var model: Variant = _m()
	for event in model.events:
		if str(event.id) == id: return event
	return {}


func pending_event() -> Dictionary:
	var model: Variant = _m()
	if model.state.event_queue.is_empty(): return {}
	var queued: Dictionary = model.state.event_queue[0]
	var result = _event_definition(str(queued.id)).duplicate(true)
	result["queued_minute"] = int(queued.queued_minute)
	return result


func _event_can_trigger(definition: Dictionary) -> bool:
	var model: Variant = _m()
	var trigger: Dictionary = definition.get("trigger", {})
	if bool(trigger.get("business_only", false)) and not model.business_open(): return false
	var employee_id = str(trigger.get("employee_id", ""))
	if employee_id != "" and not active(employee_id): return false
	var dish_id = str(trigger.get("dish_id", ""))
	if dish_id != "" and not dish_id in model.state.menu_enabled: return false
	for history in model.state.event_history:
		if str(history.id) == str(definition.id) and int(model.state.total_minutes) - int(history.minute) < int(definition.get("cooldown", 720)): return false
	return true


func enqueue_event(id: String) -> bool:
	var model: Variant = _m()
	var definition = _event_definition(id)
	if definition.is_empty() or not _event_can_trigger(definition) or model.state.event_queue.size() >= int(setting("events", "max_pending", 1)): return false
	for queued in model.state.event_queue:
		if str(queued.id) == id: return false
	model.state.event_queue.append({"id": id, "queued_minute": int(model.state.total_minutes)})
	model.state.event_last_minute = int(model.state.total_minutes)
	model._notify("新事件：" + str(definition.title))
	model.changed.emit()
	return true


func tick() -> void :
	var model: Variant = _m()
	var state: Dictionary = model.state
	if str(state.mode) != "demo": return
	var now = int(state.total_minutes)
	if int(state.discount_until) <= now and float(state.procurement_discount) != 1:
		state.procurement_discount = 1.0
	if not bool(state.event_first_triggered) and now >= int(setting("events", "first_minute", 480)):
		if enqueue_event(str(setting("events", "first_id", "supplier_discount"))): state.event_first_triggered = true
	if now - int(state.event_last_minute) >= int(setting("events", "interval", 360)):
		state.event_last_minute = now
		if model.business_open() and model._rng.randf() < float(setting("events", "random_chance", 0.35)):
			var candidates: Array = []
			var weight_sum = 0.0
			for event in model.events:
				if _event_can_trigger(event):
					candidates.append(event)
					weight_sum += float(event.get("weight", 1))
			if weight_sum > 0:
				var roll: float = model._rng.randf() * weight_sum
				for event in candidates:
					roll -= float(event.get("weight", 1))
					if roll <= 0:
						enqueue_event(str(event.id))
						break


func choose_event(id: String, option_index: int) -> bool:
	var model: Variant = _m()
	var event = pending_event()
	if event.is_empty() or str(event.id) != id: return false
	var options: Array = event.get("options", [])
	if option_index < 0 or option_index >= options.size(): return false
	var option: Dictionary = options[option_index]

	var cash = float(model.state.cash)
	var ingredients = float(model.state.ingredients)
	for effect in option.get("effects", []):
		var amount = _event_amount(effect)
		if str(effect.get("type", "")) == "cash": cash += amount
		elif str(effect.get("type", "")) == "ingredients": ingredients += amount
		if cash < 0 or ingredients < 0:
			model._notify("这个选项需要更多资源，请选择另一种处理方式")
			return false
	model.change_cash(cash-float(model.state.cash),"event","事件选择："+str(event.get("title",id)))
	model.state.ingredients = ingredients
	for effect in option.get("effects", []):
		var amount = _event_amount(effect)
		match str(effect.get("type", "")):
			"reputation": model.state.reputation = maxi(0, int(model.state.reputation) + int(amount))
			"mood", "loyalty":
				for employee in model.employees:
					if str(effect.get("employee_id", "all")) in ["all", str(employee.id)]:
						employee[str(effect.type)] = clampf(float(employee[str(effect.type)]) + amount, 0, 100)
			"procurement_discount":
				model.state.procurement_discount = minf(float(model.state.procurement_discount), float(effect.get("multiplier", 1)))
				model.state.discount_until = maxi(int(model.state.discount_until), int(model.state.total_minutes) + int(effect.get("duration", 0)))
			"kitchen_pause":
				model.state.kitchen_pause_until = maxi(int(model.state.kitchen_pause_until), int(model.state.total_minutes) + int(effect.get("duration", 0)))
				for customer in model.customers:
					if str(customer.stage) == "cooking" and int(customer.due_minute) >= 0:
						customer.remaining_minutes = maxi(1, int(customer.due_minute) - int(model.state.total_minutes))
						model._release_customer(customer)
						customer.worker = ""
						customer.due_minute = -1
	model.state.event_queue.pop_front()
	model.state.event_history.append({"id": id, "minute": int(model.state.total_minutes), "option": option_index})
	model._notify(str(event.title) + "：" + str(option.get("label", option.get("text", "已处理"))))
	model.changed.emit()
	return true


func _event_amount(effect: Dictionary) -> float:
	var model: Variant = _m()
	return float(effect.get("sign", 1)) * float(model.balance.get(str(effect.get("amount_key", "")), 0)) if effect.has("amount_key") else float(effect.get("amount", 0))


func validate_state(state: Dictionary, employees: Array, scheduler: Array) -> bool:
	var model: Variant = _m()
	for key in CHAPTER_KEYS:
		if not state.has(key): return false
	if not str(state.mode) in ["normal", "demo"] or not state.event_first_triggered is bool or not state.completed is bool or not state.starter_contract is bool: return false
	for key in ["quests_claimed", "unlocked_dishes", "menu_enabled", "contracts", "research_projects", "event_queue", "event_history", "layout"]:
		if not state[key] is Array: return false
	for key in ["hire_counts", "fragments", "research_experience", "stats"]:
		if not state[key] is Dictionary: return false
	for key in ["event_last_minute", "decorations_purchased", "hire_tickets", "discount_until", "kitchen_pause_until"]:
		if not model._integer(state[key]): return false
	if int(state.event_last_minute) > int(state.total_minutes): return false
	for key in ["traffic_bonus", "price_bonus", "cooking_speed_bonus", "procurement_discount"]:
		if not model._number(state[key]) or float(state[key]) < 0: return false
	if float(state.procurement_discount) <= 0 or float(state.procurement_discount) > 1: return false
	if not model._integer(state.hire_counts.get("normal")) or not model._integer(state.hire_counts.get("advanced")): return false
	for dictionary in [state.fragments, state.research_experience, state.stats]:
		for key in dictionary:
			if not key is String or not model._integer(dictionary[key]): return false
	for key in ["purchases", "contracts", "recruits", "research_success", "decorations"]:
		if not state.stats.has(key): return false
	var claimed: Dictionary = {}
	for id in state.quests_claimed:
		if not id is String or claimed.has(id): return false
		var known = false
		for quest in model.quests_array:
			if str(quest.id) == id: known = true
		if not known: return false
		claimed[id] = true
	for quest in model.quests_array:
		if str(quest.id) in state.quests_claimed:
			for prerequisite in quest.get("depends_on", []):
				if not str(prerequisite) in state.quests_claimed: return false
	if bool(state.completed) and (state.quests_claimed.size() != model.quests_array.size() or int(state.stage) < 1 or float(state.debt) > 0): return false
	for key in ["unlocked_dishes", "menu_enabled"]:
		var seen: Dictionary = {}
		for id in state[key]:
			if not id is String or seen.has(id) or model._dish(str(id)).is_empty(): return false
			if key == "menu_enabled" and not id in state.unlocked_dishes: return false
			seen[id] = true
	if state.menu_enabled.is_empty(): return false
	for id in state.contracts:
		if not id is String or model._employee_config(str(id)).is_empty(): return false
	if int(state.hire_tickets) != state.contracts.size(): return false
	var definitions: Dictionary = {}
	for employee in employees:
		definitions[str(employee.id)] = employee
		if not model._integer(employee.get("research_until", 0)): return false
		if int(employee.get("research_until", 0)) > 0 and int(employee.training_until) > 0: return false
	var staff_count = 0
	for employee in employees:
		if not bool(employee.resting): staff_count += 1
	var limits: Array = setting("stage", "active_limits", [3, 5])
	if staff_count > int(limits[mini(int(state.stage), limits.size() - 1)]): return false
	var researched: Dictionary = {}
	for project in state.research_projects:
		if not project is Dictionary: return false
		for key in ["dish_id", "employee_id", "due", "guaranteed"]:
			if not project.has(key): return false
		if not project.dish_id is String or researched.has(project.dish_id) or not str(project.dish_id) in setting("research", "supported_ids", []) or str(project.dish_id) in state.unlocked_dishes: return false
		if not definitions.has(str(project.employee_id)) or not model._integer(project.due) or int(project.due) <= int(state.total_minutes) or not project.guaranteed is bool: return false
		if int(definitions[str(project.employee_id)].get("research_until", 0)) != int(project.due): return false
		if not str(definitions[str(project.employee_id)].role) in ["chef", "all"]: return false
		if bool(project.guaranteed) and (str(state.mode) != "demo" or str(project.dish_id) != str(setting("research", "first_guaranteed_id", "qianyang_soup"))): return false
		var count = 0
		for event in scheduler:
			if str(event.type) == "research_finish" and str(event.get("dish_id", "")) == str(project.dish_id):
				if int(event.due) != int(project.due) or str(event.get("employee_id", "")) != str(project.employee_id): return false
				count += 1
		if count != 1: return false
		researched[project.dish_id] = project
	for event in scheduler:
		if str(event.type) == "research_finish" and not researched.has(str(event.get("dish_id", ""))): return false
	for employee in employees:
		if int(employee.get("research_until", 0)) > 0:
			var count = 0
			for project in state.research_projects:
				if str(project.employee_id) == str(employee.id): count += 1
			if count != 1 or int(employee.busy_customer) != 0: return false
	var queued_ids: Dictionary = {}
	for queued in state.event_queue:
		if not queued is Dictionary or not queued.get("id") is String or _event_definition(str(queued.id)).is_empty() or queued_ids.has(str(queued.id)) or not model._integer(queued.get("queued_minute")) or int(queued.queued_minute) > int(state.total_minutes): return false
		queued_ids[str(queued.id)] = true
	if state.event_queue.size() > int(setting("events", "max_pending", 1)): return false
	for history in state.event_history:
		if not history is Dictionary or _event_definition(str(history.get("id", ""))).is_empty() or not model._integer(history.get("minute")) or int(history.minute) > int(state.total_minutes) or not model._integer(history.get("option")): return false
		if int(history.option) >= _event_definition(str(history.id)).get("options", []).size(): return false
	var occupied: Array[Rect2i] = []
	var seats = 0
	var table_count = 0
	for item in state.layout:
		if not item is Dictionary or decoration(str(item.get("id", ""))).is_empty(): return false
		for key in ["x", "y", "w", "h"]:
			if not model._integer(item.get(key), 1 if key in ["w", "h"] else 0): return false
		var definition = decoration(str(item.id))
		if int(item.w) != int(definition.get("width", 1)) or int(item.h) != int(definition.get("height", 1)) or int(item.x) + int(item.w) > int(setting("layout", "width", 6)) or int(item.y) + int(item.h) > int(setting("layout", "height", 4)): return false
		var bounds = Rect2i(int(item.x), int(item.y), int(item.w), int(item.h))
		for other in occupied:
			if bounds.intersects(other): return false
		occupied.append(bounds)
		if str(item.id) in ["table_two", "table_four"]: table_count += 1
		if not bool(item.get("building",false)):
			for effect in definition.get("effects", []):
				if str(effect.get("type", "")) == "seats": seats += int(_effect_value(effect))
	if seats != int(state.seats): return false
	var table_limits: Array = setting("stage", "table_limits", [4, 8])
	if table_count > int(table_limits[mini(int(state.stage), table_limits.size() - 1)]): return false
	return true
