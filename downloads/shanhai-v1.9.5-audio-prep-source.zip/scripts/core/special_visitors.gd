extends RefCounted
var _ref: WeakRef
func _init(host) -> void:_ref=weakref(host)
func m():return _ref.get_ref()
func s() -> Dictionary:return m().state.special_visitors
func definitions() -> Array:return m().full_rules.revision.config.guests
func definition(id: String) -> Dictionary:
	for item in definitions():
		if str(item.id)==id:return item
	return {}
func ensure_state() -> void:
	if not m().state.has("special_visitors"):
		m().state.special_visitors={"version":1,"records":{},"history":[],"interactions":[],"adoptions":[],"next_visit":1,"helped":false,"lore":[],"spy_risk_day":-1,"achievement":false}
func eligible(id: String) -> bool:
	match id:
		"old_gourmand":return int(m().state.stage)>=1 and m().full_rules.average_quality()>=75
		"baize_friend":return m()._employee("bai_ze").is_empty() or str(m()._employee("bai_ze").get("branch_id","")).is_empty()
		"lost_cub":return true
		"picky_blogger":return int(m().state.reputation)>=300
		"grateful_monster":return bool(s().helped)
		"kunlun_spy":return int(m().state.stage)>=2
	return false
func prepare(customer: Dictionary,forced_id: String="") -> void:
	interact(customer,{},"greeting")
	if customer.has("visitor_id"):return
	if str(customer.type)!="special" and forced_id.is_empty():return
	var candidates=definitions().filter(func(item):return eligible(str(item.id)))
	if candidates.is_empty():customer.type="descendant";return
	var item: Dictionary=definition(forced_id)
	if item.is_empty():item=candidates[m()._rng.randi_range(0,candidates.size()-1)]
	if not eligible(str(item.id)):customer.type="descendant";return
	var id=str(item.id);customer.visitor_id=id;customer.visit_serial=int(s().next_visit);s().next_visit+=1
	customer.visitor_scores=[];customer.visitor_dishes=[];customer.visitor_first_minute=int(customer.arrival_minute);customer.visitor_done=false
	if not s().records.has(id):s().records[id]={"met":0,"best":"尚未完成接待","best_score":-1.0,"last":"正在用餐"}
	s().records[id].met+=1
	select_order(customer)
	m()._notify("特殊顾客到访："+str(item.name)+" · "+str(item.behavior))
	s().achievement=s().records.size()==definitions().size()
func select_order(customer: Dictionary) -> void:
	var id=str(customer.get("visitor_id",""))
	var menu: Array=m().full_rules.customer_service.menu_dishes(false)
	var options=menu.duplicate()
	if id=="old_gourmand":options.sort_custom(func(a,b):return float(a.price)>float(b.price))
	elif id=="baize_friend":options=menu.filter(func(dish):return str(dish.get("category",""))=="饮品")
	elif id=="lost_cub":options=m().full_rules.customer_service.basic_dishes(false)
	elif id=="picky_blogger":
		var untried=menu.filter(func(dish):return not str(dish.id) in customer.visitor_dishes)
		if not untried.is_empty():options=untried
	if options.is_empty():customer.visitor_unavailable=true;return
	var dish: Dictionary=options[0] if id=="old_gourmand" else options[m()._rng.randi_range(0,options.size()-1)]
	m().full_rules.customer_service.apply_choice(customer,dish)
	customer.order_decided=true;customer.recommendation_done=true;customer.visitor_dishes.append(str(dish.id))
func interact(customer: Dictionary,employee: Dictionary,kind: String) -> void:
	if not customer.has("interaction_kinds"):customer.interaction_kinds=[];customer.interaction_bubbles=0
	if kind in customer.interaction_kinds:return
	var config: Dictionary=m().full_rules.revision.config.interaction
	var lines={"greeting":"欢迎光临，今日菜品请慢慢看。","serving":"菜已上齐，请慢用。","goodbye":"谢谢光临，期待您再次到来。"}
	if not lines.has(kind):return
	if kind=="greeting":
		var staff=m()._worker_for("ordering",customer)
		if staff.is_empty():return
		employee=staff
		customer.mood=clampf(float(customer.get("mood",50))+float(config.greeting_mood),0,100)
		customer.satisfaction=clampf(float(customer.get("satisfaction",50))+float(config.greeting_mood),0,100)
	if kind=="serving":
		customer.mood=clampf(float(customer.get("mood",50))+float(config.serving_mood),0,100)
		customer.satisfaction=clampf(float(customer.get("satisfaction",50))+float(config.serving_mood),0,100)
	if kind=="goodbye":customer.return_chance_bonus=float(config.return_bonus)
	customer.interaction_kinds.append(kind)
	if int(customer.interaction_bubbles)>=int(config.bubble_limit):return
	customer.interaction_bubbles+=1;customer.interaction_text=str(lines[kind]);customer.interaction_until=int(m().state.total_minutes)+8
	s().interactions.append({"minute":int(m().state.total_minutes),"customer_id":int(customer.id),"employee_id":str(employee.get("id","")),"text":str(lines[kind]),"response":"谢谢招待。"})
	while s().interactions.size()>40:s().interactions.pop_front()
func paid(customer: Dictionary) -> void:
	interact(customer,{},"goodbye")
	if not customer.has("visitor_id") or bool(customer.get("visitor_done",false)):return
	customer.visitor_scores.append(float(customer.get("quality",0)))
	if str(customer.visitor_id)=="picky_blogger" and customer.visitor_scores.size()<3:return
	finish(customer,false)
func next_course(customer: Dictionary) -> bool:
	if str(customer.get("visitor_id",""))!="picky_blogger" or bool(customer.get("visitor_done",false)) or customer.visitor_scores.size()>=3:return false
	var keep: Dictionary={}
	for key in ["id","seat","type","visitor_id","visit_serial","visitor_scores","visitor_dishes","visitor_first_minute","interaction_kinds","interaction_bubbles","preference_profile","service_arrival_recorded"]:
		if customer.has(key):keep[key]=customer[key]
	customer.clear();customer.merge(keep,true)
	customer.merge({"dish_id":"noodles","stage":"ordering","due_minute":-1,"arrival_minute":int(m().state.total_minutes),"worker":"","ingredients_reserved":false,"remaining_minutes":0,"paid":false,"quality":75.0,"task_started_minute":int(m().state.total_minutes),"tip_bonus":0.0,"price":0.0,"visitor_done":false},true)
	m().full_rules.customer_service.prepare_customer(customer);select_order(customer);return true
func reputation(delta: int) -> void:m().state.reputation=maxi(0,int(m().state.reputation)+delta)
func finish(customer: Dictionary,failed: bool=false) -> void:
	var id=str(customer.get("visitor_id",""))
	if id.is_empty() or bool(customer.get("visitor_done",false)):return
	customer.visitor_done=true
	var item=definition(id)
	var good=not failed and bool(customer.get("paid",false)) and not bool(customer.get("visitor_unavailable",false))
	var amount=0.0;var rep=0;var text=""
	match id:
		"old_gourmand":
			good=good and float(customer.get("quality",0))>=float(item.quality);rep=30 if good else -20
			text="好评：声望+30，隐藏菜线索已记入山海志。" if good else "差评：声望−20，请改善菜品品质与接待。"
			if good and not "gourmand_clue" in s().lore:s().lore.append("gourmand_clue")
		"baize_friend":
			text="故人谈起白泽走访山海的往事：白泽好感+10，往事已记入山海志。" if good else "未能完成茶饮接待，故人暂且告辞。"
			if good:
				if m()._employee("bai_ze").is_empty():m().state.revision171.baize_bonus=minf(100,float(m().state.revision171.baize_bonus)+10)
				else:m().full_rules.sidequests.add_affinity("bai_ze",10,"故人来访")
				if not "baize_old_friend" in s().lore:s().lore.append("baize_old_friend")
		"lost_cub":
			text="幼崽吃完后恋恋不舍，可在特殊顾客图鉴中选择收养，获得神兽线索碎片×1。" if good else "未能完成接待，幼崽暂时离去。"
			if good:s().adoptions.append({"serial":int(customer.visit_serial),"claimed":false})
		"picky_blogger":
			good=good and customer.visitor_scores.size()==3 and customer.visitor_scores.all(func(score):return float(score)>=float(item.quality))
			rep=50 if good else -15;text="3道菜全获好评：声望+50、客流+10%持续1天。" if good else "有菜品或接待未达要求：声望−15。"
			if good:m().full_rules.world._add_modifier({"key":"traffic","value":0.1,"duration":1440,"source":"picky_blogger"})
		"grateful_monster":
			if good:
				if m()._rng.randf()<0.5:amount=500;text="报恩的妖怪留下500元厚礼。"
				else:
					var pool=m().full_rules.management.ingredients.filter(func(ingredient):return str(ingredient.kind)=="shanhai")
					var gift: Dictionary=pool[m()._rng.randi_range(0,pool.size()-1)]
					var value=2.0*m().full_rules.management.stock_price(str(gift.id));m().full_rules.management.add_item(str(gift.id),2,value);m().full_rules.record("other_income",value,"特殊食客赠予食材")
					text="报恩的妖怪赠予"+str(gift.name)+"×2。"
			else:text="未完成接待，妖怪约定改日再来。"
		"kunlun_spy":
			var detected=m().full_rules.active("xie_zhi") or m().employees.any(func(e):return m().full_rules.active(str(e.id)) and float(e.loyalty)>=float(m().full_rules.revision.config.defaults.high_loyalty))
			if detected:
				m().full_rules.world._enqueue("kunlun_trouble",{"spy_detected":true,"customer_id":int(customer.id)})
				text="已识破密探，昆仑反击事件提供证据选项，执行后声望+20。";good=true
			else:s().spy_risk_day=int(m().state.total_minutes)/1440+1;text="密探未被识破，次日昆仑捣乱事件概率提升。";good=false
	if amount>0:m().change_cash(amount,"visitor_gift","特殊顾客谢礼");m().full_rules.record("other_income",amount,"特殊顾客谢礼")
	if rep!=0:reputation(rep)
	var record: Dictionary=s().records[id]
	record.last=text
	var score=1 if good else 0
	if float(record.best_score)<score:record.best_score=score;record.best=text
	s().history.append({"id":id,"serial":int(customer.visit_serial),"minute":int(m().state.total_minutes),"good":good,"text":text,"cash":amount,"reputation":rep,"scores":customer.get("visitor_scores",[]).duplicate()})
	while s().history.size()>120:s().history.pop_front()
	m()._notify(str(item.name)+"："+text)
func adopt(serial: int) -> Dictionary:
	for adoption in s().adoptions:
		if int(adoption.serial)!=serial or adoption.claimed:continue
		adoption.claimed=true
		var pool=m().catalog.filter(func(e):return str(e.id)!="bai_ze")
		var id=str(pool[m()._rng.randi_range(0,pool.size()-1)].id)
		m().state.fragments[id]=int(m().state.fragments.get(id,0))+1
		return {"ok":true,"reason":"已收养幼崽，获得"+str(m()._employee_config(id).name)+"线索碎片×1"}
	return {"ok":false,"reason":"没有待收养的幼崽，或该奖励已经领取"}
func validate(saved: Dictionary,customers: Array=[]) -> bool:
	if not saved.has("special_visitors"):return true
	var d: Variant=saved.special_visitors
	if not d is Dictionary or d.get("version")!=1 or not d.get("records") is Dictionary:return false
	for key in ["history","interactions","adoptions","lore"]:
		if not d.get(key) is Array:return false
	if not d.get("helped") is bool or not d.get("achievement") is bool or not m()._integer(d.get("next_visit"),1) or not m()._integer(d.get("spy_risk_day"),-1):return false
	for id in d.records:
		var record: Variant=d.records[id]
		if definition(str(id)).is_empty() or not record is Dictionary or not m()._integer(record.get("met"),1) or not record.get("best") is String or not record.get("last") is String or not m()._number(record.get("best_score")):return false
	for entry in d.history:
		if not entry is Dictionary or not d.records.has(str(entry.get("id",""))) or not entry.get("good") is bool or not entry.get("text") is String:return false
		if not m()._integer(entry.get("serial"),1) or int(entry.serial)>=int(d.next_visit) or not m()._integer(entry.get("minute")) or int(entry.minute)>int(saved.total_minutes):return false
		if not entry.get("scores") is Array:return false
		for score in entry.scores:
			if not m()._number(score) or float(score)<0 or float(score)>100:return false
	for entry in d.adoptions:
		if not entry is Dictionary or not m()._integer(entry.get("serial"),1) or not entry.get("claimed") is bool:return false
	for customer in customers:
		if not customer.has("visitor_id"):continue
		if definition(str(customer.visitor_id)).is_empty() or not d.records.has(str(customer.visitor_id)) or not customer.get("visitor_scores") is Array or not customer.get("visitor_dishes") is Array or not customer.get("visitor_done") is bool:return false
		if not m()._integer(customer.get("visit_serial"),1) or int(customer.visit_serial)>=int(d.next_visit):return false
	return true
