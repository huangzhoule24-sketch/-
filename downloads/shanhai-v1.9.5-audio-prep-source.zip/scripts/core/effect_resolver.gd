extends RefCounted
## Completes effects which span customer, worker and world systems.
## Multipliers correct missing effects only; existing management/world bonuses
## remain at their original calculation sites.

var _model_ref: WeakRef
var model: Variant:
	get: return _model_ref.get_ref()

const DEFAULTS := {"customer_satisfaction": 50.0, "satisfaction_probability_scale": 100.0,
	"earmouse_startle_chance": 0.05, "earmouse_startle_mood": 2.0,
	"luwu_dish_time_reduction": 0.15, "jingwei_dish_serving_reduction": 0.2,
	"taowu_refusal_chance": 0.1, "calculation_cashier_speed": 0.05,
	"calculation_escape_reduction": 0.02, "calculation_escape_cap": 0.8,
	"eloquence_complaint_reduction": 0.03, "eloquence_complaint_cap": 0.8,
	"endurance_work_reduction": 0.05, "endurance_rest_recovery": 0.03,
	"complaint_work_minutes": 5.0, "kitchen_chaos_minutes": 3.0}


func _init(host: RefCounted) -> void:
	_model_ref = weakref(host)


func _now() -> int: return int(model.state.get("total_minutes", 0))


func _management() -> Variant: return model.full_rules.management


func _world() -> Variant: return model.full_rules.world


func _coefficient(key: String, fallback: float = 0.0) -> float:
	if model.balance.has("coeff." + key) or _management().config.get("coefficients", {}).has(key): return _management().coefficient(key)
	return float(DEFAULTS.get(key, fallback))


func _active(id: String) -> bool: return model.full_rules.active(id)


func _synergy_bonus(effect: String, context: Dictionary = {}) -> float:
	var rules: Variant = model.get("full_rules")
	var synergies: Variant = rules.get("synergies") if rules != null else null
	return float(synergies.bonus(effect, context)) if synergies != null else 0.0


static func _unique(values: Array) -> float:
	var positive := 0.0
	var negative := 0.0
	for value in values:
		positive = maxf(positive, float(value))
		negative = minf(negative, float(value))
	return positive + negative


func _scale(worker: Dictionary) -> float: return _management().skill_multiplier(worker)


func _day() -> int: return int(_now() / maxi(1, int(model._b("day.minutes"))))


func ensure_state() -> void:
	if not model.state.get("effect_resolution") is Dictionary: model.state.effect_resolution = {}
	var state: Dictionary = model.state.effect_resolution
	if not state.get("first_reviews") is Dictionary: state.first_reviews = {}
	if not state.has("extra_income_total"): state.extra_income_total = 0.0
	if not state.has("prevented_escapes"): state.prevented_escapes = 0
	if not state.has("pending_complaints"): state.pending_complaints = []
	if not state.has("next_complaint_id"): state.next_complaint_id = 1
	if not state.has("kitchen_chaos_count"): state.kitchen_chaos_count = 0


func season() -> String:
	var days_per_month := maxi(1, int(model._b("time.days_per_month")))
	var month := int(_day() / days_per_month) % 12
	return ["spring", "summer", "autumn", "winter"][int(month / 3)]


func tick_minute() -> void:
	ensure_state()
	model.state.world.season = season()
	_tick_complaints()
	# Only one entry per dish is retained; old dates are overwritten at payment.


func traffic_multiplier() -> float:
	return (1.0 + rain_traffic_bonus()) * menu_demand_multiplier()


func rain_traffic_bonus() -> float:
	if str(model.state.get("world", {}).get("weather", "clear")) == "rain" and _active("ying_long"):
		return _coefficient("yinglong_rain_flow") * _scale(model._employee("ying_long"))
	return 0.0


func menu_demand_multiplier() -> float:
	# Demand must change sales even when only one dish is served. Scaling total
	# arrivals by the mean demand, then selecting dishes by their weights, gives
	# every available dish its stated relative demand instead of redistributing
	# a fixed stream of customers between menu entries.
	var demand: float = 0.0
	var count: int = 0
	for id in model.state.get("menu_enabled", []):
		# Demand and advertised menu determine arrivals. Stock is checked only
		# after a guest arrives and chooses an actual order.
		if not id in model.state.get("unlocked_dishes", []): continue
		demand += arrival_dish_weight(str(id))
		count += 1
	return demand / count if count > 0 else 1.0


func dish_weight(dish_id: String) -> float:
	return arrival_dish_weight(dish_id)


func arrival_dish_weight(dish_id: String) -> float:
	var dish: Dictionary = model._dish(dish_id)
	var sources: Array = [_world().dish_demand(str(dish.get("category", ""))) - 1.0]
	var weather = str(model.state.get("world", {}).get("weather", "clear"))
	if dish_id == "qianyang_soup" and (season() == "winter" or weather == "snow"): sources.append(_coefficient("winter_soup_demand"))
	if dish_id == "yinglong_hotpot" and weather == "rain": sources.append(_coefficient("rain_hotpot_demand"))
	if dish_id == "tiangou_tempura" and model.period() == "night_market": sources.append(_coefficient("night_tempura_demand"))
	var definitions: Dictionary = _management().config.get("dish_effects", {}).get(dish_id, {})
	if definitions.has("healthy_demand_bonus"): sources.append(_coefficient(str(definitions.healthy_demand_bonus)))
	return maxf(0.01, 1.0 + _unique(sources))


func allow_customer(customer_type: String) -> bool:
	if customer_type != "human" or not _active("gu_diao"): return true
	return model._rng.randf() >= gudiao_loss_probability()


func gudiao_loss_probability() -> float:
	return clampf(_coefficient("gudiao_human_loss") * _scale(model._employee("gu_diao")) * (1.0 + _synergy_bonus("gudiao_human_loss_mult")), 0, 1)


func special_customer_bonus() -> float:
	return _coefficient("gudiao_special") * _scale(model._employee("gu_diao")) if _active("gu_diao") else 0.0


func ignores_obstacles(worker: Dictionary, dish: Dictionary = {}, task: String = "serving") -> bool:
	if str(worker.get("id", "")) == "di_jiang" and task == "serving": return true
	return task == "serving" and (str(dish.get("id", "")) == "dijiang_dumplings" or _world().modifier("ignore_obstacles") > 1.0)


func quality_multiplier(worker: Dictionary, dish: Dictionary) -> float:
	# Legacy skill code handled only the signature soup. The skill covers soups.
	if str(worker.get("id", "")) == "xian_yang" and str(dish.get("category", "")) == "汤品" and str(dish.get("id", "")) != "qianyang_soup" and _active("xian_yang"):
		return 1.0 + model._b("coeff.qianyang_soup_quality") * _scale(worker)
	return 1.0


func ingredient_multiplier(worker: Dictionary) -> float:
	if str(worker.get("id", "")) == "tao_tie" and _active("tao_tie"):
		var base: float = model._b("coeff.ingredient_cost_mult")
		return (1.0 + base * _scale(worker)) / (1.0 + base)
	return 1.0


func work_multiplier(worker: Dictionary, task: String, dish: Dictionary = {}) -> float:
	var result := 1.0
	var id := str(worker.get("id", ""))
	if task == "paying": result /= cashier_factor(worker)
	if task == "cleaning" and id == "jing_wei": result /= 1.0 + _coefficient("jingwei_clean") * _scale(worker)
	if task == "cooking":
		var global: float = _world().modifier("cooking_speed")
		var category: float = _world().modifier("cooking_speed", str(dish.get("category", "")))
		if category > 0: result *= global / category
		if id == "lu_wu" and str(dish.get("category", "")) == "烧烤":
			var bonus := _coefficient("luwu_speed") * _scale(worker)
			# management already divided by 1 + bonus; restore that and apply
			# the documented time reduction (20% means duration × 0.8).
			result *= (1.0 + bonus) * maxf(0.1, 1.0 - bonus)
		if str(dish.get("id", "")) == "luwu_platter": result *= 1.0 - _coefficient("luwu_dish_time_reduction")
	if task == "serving" and str(dish.get("id", "")) == "jingwei_bibimbap": result *= 1.0 - _coefficient("jingwei_dish_serving_reduction")
	return maxf(0.0, result)


func cashier_factor(worker: Dictionary) -> float:
	if not worker.is_empty() and not model.full_rules.dollhouse.capable(worker,"salesman"):return 1.0
	return maxf(0.01, 1.0 + maxf(0, float(worker.get("attributes", {}).get("calculation", 0))) * _coefficient("calculation_cashier_speed"))


func stamina_drain_factor(worker: Dictionary) -> float:
	var trait_factor=1.0-clampf(float(model.balance.get("coeff.xuangui_stamina_reduction",0.1))*_scale(worker),0,0.8) if str(worker.get("id",""))=="xuan_gui" else 1.0
	return trait_factor / maxf(0.01, 1.0 + maxf(0, float(worker.get("attributes", {}).get("endurance", 0))) * _coefficient("endurance_work_reduction"))


func rest_recovery_factor(worker: Dictionary) -> float:
	return maxf(0.01, 1.0 + maxf(0, float(worker.get("attributes", {}).get("endurance", 0))) * _coefficient("endurance_rest_recovery"))


func prepare_customer(customer: Dictionary) -> void:
	if bool(customer.get("effects_prepared", false)): return
	customer.effects_prepared = true
	var dish_id := str(customer.get("dish_id", ""))
	if not customer.get("dish_effects") is Dictionary: customer.dish_effects = _management().modifiers(dish_id)
	if not customer.has("satisfaction"): customer.satisfaction = _coefficient("customer_satisfaction")
	if not customer.has("preference"):
		customer.preference = "light_food" if float(customer.dish_effects.get("healthy_demand_bonus", 0)) > 0 else "varied_food"
	if _active("guan_guan") and int(model.state.get("promotion_until", 0)) > _now() and str(model._employee("guan_guan").get("role", "")) in ["salesman", "all"]:
		customer.satisfaction = float(customer.satisfaction) + _coefficient("guanguan_mood")


func after_serving(customer: Dictionary, worker: Dictionary) -> void:
	prepare_customer(customer)
	customer.serving_employee_id = str(worker.get("id", ""))
	var effects: Dictionary = customer.get("dish_effects", {})
	var satisfaction := float(effects.get("mood_bonus", 0))
	if season() == "winter" or str(model.state.get("world", {}).get("weather", "")) == "snow": satisfaction += float(effects.get("warmth_bonus", 0))
	if _active("ying_zhao"): satisfaction += _coefficient("yingzhao_mood") * _scale(model._employee("ying_zhao"))
	if str(worker.get("id", "")) == "di_jiang": satisfaction += _coefficient("yingzhao_mood") * _scale(worker)
	customer.satisfaction = clampf(float(customer.get("satisfaction", 50)) + satisfaction, 0, 100)
	if str(worker.get("id", "")) in ["gu_diao", "guan_guan"] and _active("er_shu") and model._rng.randf() < _coefficient("earmouse_startle_chance"):
		var mouse: Dictionary = model._employee("er_shu")
		mouse.mood = maxf(0, float(mouse.mood) - _coefficient("earmouse_startle_mood"))
	var conflict: float = _unique([float(effects.get("conflict_chance", 0)), _world().probability_bonus("conflict"), _synergy_bonus("conflict")])
	if conflict > 0 and model._rng.randf() < minf(1.0, conflict):
		customer.conflict = true
		model.state.reputation = maxi(0, int(model.state.reputation) - 1)
		_world().on_hook("complaint", {"dish_id": str(customer.dish_id), "customer_id": int(customer.id)})


func adjust_checkout(customer: Dictionary, _worker: Dictionary, amount: float) -> float:
	var chef: Dictionary = model._employee(str(customer.get("chef_id", "")))
	if str(chef.get("id", "")) != "ran_yi_yu" or str(model._dish(str(customer.get("dish_id", ""))).get("category", "")) != "汤品": return amount
	var effects: Dictionary = _management().employee_effects(chef)
	if model._rng.randf() < minf(1, float(effects.get("extra_income_chance", 0))):
		var extra := floorf(amount * float(effects.get("extra_income_bonus", 0)))
		customer.extra_income = extra
		return amount + extra
	return amount


func escape_probability(base: float, worker: Dictionary = {}) -> float:
	if not worker.is_empty() and not model.full_rules.dollhouse.capable(worker,"salesman"):return clampf(base*(1.0-clampf(float(model.state.get("escape_reduction",0)),0,1)),0,1)
	var calculation := maxf(0, float(worker.get("attributes", {}).get("calculation", 0)))
	var reductions: Array = [clampf(calculation * _coefficient("calculation_escape_reduction"), 0, _coefficient("calculation_escape_cap")), clampf(float(model.state.get("escape_reduction", 0)), 0, 1), maxf(0, _synergy_bonus("cashier_safety"))]
	if _active("tian_gou") and (worker.is_empty() or str(worker.get("id", "")) == "tian_gou"):
		var guardian: Dictionary = model._employee("tian_gou")
		reductions.append(minf(1, _coefficient("tiangou_prevent_escape") * _scale(guardian)))
	var night = str(model.period()) in ["night_market", "closed"]
	reductions.append(maxf(0, -_synergy_bonus("night_loss", {"night": night})))
	return clampf(base * (1.0 - _unique(reductions)), 0, 1)


func payment_escaped(customer: Dictionary, worker: Dictionary, base: float) -> bool:
	# A single roll permits an honest counter: the same customer would have
	# escaped at baseline but paid after the actual cashier/desk prevention.
	var baseline := clampf(base, 0, 1)
	var final_probability := escape_probability(baseline, worker)
	var roll: float = model._rng.randf()
	var escaped := roll < final_probability
	customer.escape_roll = roll
	customer.escape_probability = final_probability
	customer.escaped_payment = escaped
	if not escaped and roll < baseline:
		ensure_state()
		model.state.effect_resolution.prevented_escapes = int(model.state.effect_resolution.prevented_escapes) + 1
	return escaped


func complaint_probability(customer: Dictionary) -> float:
	var chance := float(customer.get("dish_effects", {}).get("complaint_mult", 1))
	var handler: Dictionary = model._employee(str(customer.get("serving_employee_id", "")))
	# A queued customer may not have met a waiter. In that case, the on-duty
	# sales team handles the complaint; resting or assigned-away staff cannot.
	if handler.is_empty():
		for employee in model.employees:
			if str(employee.get("role", "")) not in ["salesman", "all"] or not _active(str(employee.id)): continue
			if handler.is_empty() or float(employee.get("attributes", {}).get("eloquence", 0)) > float(handler.get("attributes", {}).get("eloquence", 0)): handler = employee
	var eloquence := maxf(0, float(handler.get("attributes", {}).get("eloquence", 0)))
	chance *= 1.0 - clampf(eloquence * _coefficient("eloquence_complaint_reduction"), 0, _coefficient("eloquence_complaint_cap"))
	var satisfaction: float = _world().modifier("satisfaction")
	if satisfaction > 0: chance /= satisfaction
	var protection=_coefficient("xiezhi_complaint_success")*_scale(model._employee("xie_zhi")) if _active("xie_zhi") else 0.0
	if _active("qing_geng"):protection=maxf(protection,float(model.balance.get("coeff.qinggeng_complaint_reduction",0.2))*_scale(model._employee("qing_geng")))
	chance*=1.0-clampf(protection,0,1)
	chance*=_world().modifier("complaint")
	return clampf(chance, 0, 1)


func employee_handles_complaint(employee_id: String) -> bool:
	if employee_id.is_empty(): return false
	for entry in model.state.get("effect_resolution", {}).get("pending_complaints", []):
		if str(entry.get("handler_id", "")) == employee_id: return true
	return false


func _complaint_handler(excluded: Array = []) -> Dictionary:
	var best: Dictionary = {}
	for employee in model.employees:
		var id = str(employee.id)
		if id in excluded or employee_handles_complaint(id) or not _active(id): continue
		if int(employee.get("busy_customer", 0)) != 0 or int(employee.get("busy_until", 0)) > _now(): continue
		if id != "xie_zhi" and str(employee.get("role", "")) not in ["salesman", "waiter", "all"]: continue
		if id == "xie_zhi": return employee
		if best.is_empty() or float(employee.get("attributes", {}).get("eloquence", 0)) > float(best.get("attributes", {}).get("eloquence", 0)): best = employee
	return best

func complaint_work_rate(handler: Dictionary) -> float:
	if handler.is_empty(): return 0.0
	return maxf(0.05, 1.0 + _synergy_bonus("complaint_speed", {"employee_id": str(handler.id)}))


func begin_complaint(context: Dictionary) -> void:
	ensure_state()
	var data: Dictionary = model.state.effect_resolution
	for entry in data.pending_complaints:
		if int(entry.context.get("customer_id", -1)) == int(context.get("customer_id", -1)) and int(entry.started) == _now(): return
	var handler = _complaint_handler()
	var work = _coefficient("complaint_work_minutes", 5)
	var rate = complaint_work_rate(handler)
	var entry = {"id": int(data.next_complaint_id), "started": _now(), "last_tick": _now(), "handler_id": str(handler.get("id", "")), "remaining_work": work, "total_work": work, "due": _now() + int(ceil(work / rate)) if rate > 0 else -1, "context": context.duplicate(true)}
	data.next_complaint_id = int(data.next_complaint_id) + 1
	data.pending_complaints.append(entry)
	model._log("客诉已登记：%s，%s；资源惩罚只按原订单结算一次。" % ["等待当班服务人员" if handler.is_empty() else str(handler.name) + "处理", "有员工上班后继续" if rate <= 0 else "预计%d分钟" % int(ceil(work / rate))])


func _tick_complaints() -> void:
	var data: Dictionary = model.state.effect_resolution
	var completed: Array = []
	var worked: Array = []
	# Oldest complaints are assigned first. A handler can work on only one
	# complaint per minute and remains unavailable to the order scheduler.
	for entry in data.pending_complaints:
		var handler: Dictionary = model._employee(str(entry.handler_id))
		var elapsed = maxi(0, _now() - int(entry.last_tick))
		entry.last_tick = _now()
		if handler.is_empty() or not _active(str(entry.handler_id)) or str(entry.handler_id) in worked:
			entry.handler_id = ""
			handler = _complaint_handler(worked)
			entry.handler_id = str(handler.get("id", ""))
			# Reassignment starts now; time spent waiting is never work time.
			elapsed = 0
		var rate = complaint_work_rate(handler)
		if rate <= 0:
			entry.due = -1
			continue
		worked.append(str(handler.id))
		entry.remaining_work = maxf(0, float(entry.remaining_work) - elapsed * rate)
		entry.due = _now() + int(ceil(float(entry.remaining_work) / rate))
		if float(entry.remaining_work) > 0.000001: continue
		completed.append(entry)
	for entry in completed:
		data.pending_complaints.erase(entry)
		var context: Dictionary = entry.context.duplicate(true)
		context.complaint_processed = true
		context.complaint_handler_id = str(entry.handler_id)
		_world().on_hook("complaint", context)
		model._log("%s完成客诉处理，用时%d分钟；处理结果已写入事件日志。" % [str(model._employee(str(entry.handler_id)).get("name", "员工")), _now() - int(entry.started)])

func kitchen_chaos_delay(customer: Dictionary, worker: Dictionary) -> float:
	if bool(customer.get("kitchen_chaos_checked", false)): return float(customer.get("kitchen_chaos_delay", 0))
	customer.kitchen_chaos_checked = true
	customer.kitchen_chaos_delay = 0.0
	if str(worker.get("id",""))=="xuan_gui":return 0.0
	var probability = clampf(_synergy_bonus("kitchen_chaos"), 0, 1)
	if probability <= 0 or model._rng.randf() >= probability: return 0.0
	var delay = _coefficient("kitchen_chaos_minutes", 3)
	customer.kitchen_chaos_delay = delay
	ensure_state()
	model.state.effect_resolution.kitchen_chaos_count = int(model.state.effect_resolution.kitchen_chaos_count) + 1
	model._log("饕餮与九婴争食抢料，%s的这道%s备菜额外延迟%.0f分钟。" % [str(worker.get("name", "厨师")), str(model._dish(str(customer.get("dish_id", ""))).get("name", "菜品")), delay])
	return delay


func snapshot() -> Dictionary:
	ensure_state()
	var result: Dictionary = model.state.effect_resolution.duplicate(true)
	for entry in result.pending_complaints:
		entry.handler_name = str(model._employee_config(str(entry.handler_id)).get("name", "等待当班服务人员"))
		entry.progress = clampf(1.0 - float(entry.remaining_work) / maxf(0.000001, float(entry.total_work)), 0, 1)
		entry.minutes_remaining = maxi(0, int(entry.due) - _now()) if int(entry.due) >= 0 else -1
	return result


func validate_state(saved: Dictionary, _employees: Array, saved_time: int) -> bool:
	if not saved.get("first_reviews") is Dictionary or not model._number(saved.get("extra_income_total")) or float(saved.extra_income_total) < 0: return false
	if not model._integer(saved.get("prevented_escapes")): return false
	for id in saved.first_reviews:
		if model._dish(str(id)).is_empty() or not model._integer(saved.first_reviews[id]): return false
	if saved.has("kitchen_chaos_count") and not model._integer(saved.kitchen_chaos_count): return false
	if not saved.has("pending_complaints"): return true # historical v1.3 candidate
	if not saved.pending_complaints is Array or not model._integer(saved.get("next_complaint_id"), 1): return false
	var ids: Dictionary = {}
	for entry in saved.pending_complaints:
		if not entry is Dictionary or not model._integer(entry.get("id"), 1) or int(entry.id) >= int(saved.next_complaint_id) or ids.has(int(entry.id)): return false
		ids[int(entry.id)] = true
		for key in ["started", "last_tick"]:
			if not model._integer(entry.get(key)) or int(entry[key]) > saved_time: return false
		if int(entry.last_tick) < int(entry.started) or not model._integer(entry.get("due"), -1): return false
		if not model._number(entry.get("remaining_work")) or not model._number(entry.get("total_work")) or float(entry.total_work) <= 0 or float(entry.remaining_work) <= 0 or float(entry.remaining_work) > float(entry.total_work): return false
		if not entry.get("handler_id") is String or (str(entry.handler_id) != "" and model._employee_config(str(entry.handler_id)).is_empty()): return false
		if not _world()._valid_context(entry.get("context")): return false
	return true


func review_adjustment(customer: Dictionary, review: float) -> float:
	ensure_state()
	var effects: Dictionary = customer.get("dish_effects", {})
	if bool(effects.get("guaranteed_good_review", false)): review = maxf(review, model._b("customer.quality_good_review_rep"))
	if model.state.has("revision18") and model.full_rules.revision18.has_state("word_of_mouth") and model._rng.randf()<model.full_rules.revision18.value("state_word_of_mouth_review",0.1):review=maxf(review,model._b("customer.quality_good_review_rep"))
	var id := str(customer.get("dish_id", ""))
	if bool(effects.get("first_good_review", false)) and int(model.state.effect_resolution.first_reviews.get(id, -1)) != _day():
		model.state.effect_resolution.first_reviews[id] = _day()
		review = maxf(review, model._b("customer.quality_good_review_rep"))
		customer.first_daily_review = true
	return review


func after_payment(customer: Dictionary, _worker: Dictionary) -> void:
	if bool(customer.get("effects_settled", false)): return
	customer.effects_settled = true
	var effects: Dictionary = customer.get("dish_effects", {})
	if float(customer.get("settled_amount", customer.get("price", 0))) <= 0: return
	ensure_state()
	model.state.effect_resolution.extra_income_total = float(model.state.effect_resolution.extra_income_total) + maxf(0, float(customer.get("extra_income", 0)))
	var regular_chance := float(effects.get("regular_bonus", 0))
	if regular_chance > 0 and model._rng.randf() < minf(1, regular_chance):
		model.state.world.regulars = int(model.state.world.get("regulars", 0)) + 1
	var difference := float(customer.get("satisfaction", 50)) - _coefficient("customer_satisfaction")
	var satisfaction: float = _world().modifier("satisfaction")
	difference += maxf(0, satisfaction - 1.0) * _coefficient("satisfaction_probability_scale")
	if difference != 0 and model._rng.randf() < minf(1, absf(difference) / _coefficient("satisfaction_probability_scale")):
		model.state.reputation = maxi(0, int(model.state.reputation) + (1 if difference > 0 else -1))


func promotion_multiplier() -> float:
	var result := 1.0
	for id in model.state.get("menu_enabled", []):
		result = maxf(result, float(_management().modifiers(str(id)).get("promotion_mult", 1)))
	return result


func instruction_allowed(worker: Dictionary) -> bool:
	if str(worker.get("id", "")) != "tao_wu": return true
	var probability: float = _coefficient("refuse_order_prob")
	# Keep previously saved developer overrides readable; new edits use 12.11's
	# canonical ID and take priority if both names are present.
	var saved_overrides: Dictionary = model.state.get("balance_overrides", {})
	if saved_overrides.has("coeff.taowu_refusal_chance") and not saved_overrides.has("coeff.refuse_order_prob"):
		probability = float(saved_overrides["coeff.taowu_refusal_chance"])
	probability += _synergy_bonus("instruction_refusal", {"employee_id": str(worker.get("id", ""))})
	return model._rng.randf() >= clampf(probability, 0, 1)


func daily_mood_cost(worker: Dictionary) -> float:
	return 1.0 + _coefficient("jingwei_mood_cost") if str(worker.get("id", "")) == "jing_wei" else 1.0
