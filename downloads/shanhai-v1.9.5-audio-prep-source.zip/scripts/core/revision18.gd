extends RefCounted
## v1.8: timed states, real-time manual pickups and service closing.
const Space=preload("res://scripts/services/restaurant_space.gd")
const ACTIONS=["pickup_collect","kitchen_clean"]
var _ref: WeakRef
var config: Dictionary
func _init(host) -> void:
	_ref=weakref(host)
	config=JSON.parse_string(FileAccess.get_file_as_string("res://config/revision18.json"))
func m():return _ref.get_ref()
func s() -> Dictionary:return m().state.revision18
func now() -> int:return int(m().state.total_minutes)
func value(key: String,fallback: float=0) -> float:return float(m().balance.get(key,config.defaults.get(key,fallback)))
func result(ok: bool,reason: String="") -> Dictionary:return {"ok":ok,"reason":reason,"message":reason}
func ensure_state() -> void:
	if not m().state.has("revision18"):
		if m().state.has("story"):
			m().state.story.month_start_revenue=float(m().state.total_revenue)
			m().state.story.month_start_served=int(m().state.served)
			m().state.story.v18_legacy_collection="all_beasts" in m().state.story.completed
		m().state.revision18={"version":1,"pickups":[],"next_pickup":1,"collected":[],"states":[],"review_streak":0,"kitchen_uses":0,"cleaning":{},"closing_ids":[],"period":m().period(),"last_cutoff":-1}
func accepting_guests() -> bool:
	var minute=now()%1440
	return m().business_open() and not (minute>=540 and minute<660) and minute<1380
func draining(id: String) -> bool:
	return m().state.has("revision18") and m().period() in ["rest","closed"] and not m().customers.is_empty() and id in s().closing_ids
func before_tick() -> void:
	var period: String=m().period()
	var minute=now()%1440
	if minute in [540,1380] and int(s().last_cutoff)!=now():
		s().last_cutoff=now()
		m()._notify("早餐即将休息，不再接待新客；已入店顾客继续服务。" if minute==540 else "今日即将打烊，不再接待新客；店员完成订单后休息。")
	if period in ["rest","closed"]:
		if str(s().period)!=period:
			s().closing_ids=m().employees.filter(func(e):return m().full_rules.active(str(e.id))).map(func(e):return str(e.id))
		if m().customers.is_empty():
			for id in s().closing_ids:
				var e: Dictionary=m()._employee(str(id))
				if e.is_empty() or not m().full_rules.management._available(e):continue
				e.v18_auto_rest=true;e.v18_pending_rest=false
				m().set_employee_rest(str(id),true,false)
			s().closing_ids=[]
	else:
		s().closing_ids=[]
		for e in m().employees:
			if not bool(e.get("v18_auto_rest",false)):continue
			if bool(e.get("shift_enabled",false)) and not period in e.get("shift_periods",[]):continue
			if not m().full_rules.management._available(e):continue
			m().set_employee_rest(str(e.id),false,false)
			if not e.resting:e.v18_auto_rest=false
	s().period=period
func defer_rest(employee: Dictionary,resting: bool) -> bool:
	if not resting:return false
	if not draining(str(employee.id)):return false
	employee.v18_pending_rest=true
	return true
func tick() -> void:
	for state in s().states.duplicate():
		if int(state.until)<=now():s().states.erase(state);m()._notify(str(config.states[state.id].title)+"已结束。")
	s().closing_ids=s().closing_ids.filter(func(id):return not m()._employee(str(id)).is_empty())
	if not s().cleaning.is_empty() and int(s().cleaning.due)<=now():
		var employee: Dictionary=m()._employee(str(s().cleaning.employee_id))
		if not employee.is_empty():employee.v18_clean_until=0;m().initialize_employee_motion(employee,true)
		s().cleaning={};s().kitchen_uses=0;remove_state("hygiene_risk")
		m()._notify("后厨清洁完成，卫生隐患已解除，设备使用计数已清零。")
	if m().full_rules.active("qing_geng"):
		var gain=value("coeff.qinggeng_mood_per_hour",2)*m().full_rules.skill_scale(m()._employee("qing_geng"))/60.0
		for customer in m().customers:
			customer.mood=clampf(float(customer.get("mood",50))+gain,0,100)
			customer.satisfaction=clampf(float(customer.get("satisfaction",50))+gain,0,100)
	# Finish after cleanup too: there must be no abandoned dirty table at closing.
	if m().customers.is_empty() and m().period() in ["rest","closed"]:before_tick()
func apply_state(id: String) -> void:
	if not config.states.has(id):return
	remove_state(id)
	var definition: Dictionary=config.states[id]
	s().states.append({"id":id,"started":now(),"until":now()+int(definition.duration)})
	var effects: Array=[]
	match id:
		"rush_hour":effects=[{"key":"traffic","value":value("state_rush_hour_traffic")},{"key":"stamina","value":value("state_rush_hour_stamina")}]
		"ingredient_sale":effects=[{"key":"procurement_discount","value":1+value("state_price_cut_cost")}]
		"word_of_mouth":effects=[{"key":"traffic","value":value("state_word_of_mouth_traffic")}]
		"hygiene_risk":effects=[{"key":"complaint","value":value("state_hygiene_complaint")}]
	for effect in effects:
		effect.type="modifier";effect.duration=int(definition.duration);effect.source_tag=id
		m().full_rules.world._add_modifier(effect)
func remove_state(id: String) -> void:
	for state in s().states.duplicate():
		if str(state.id)==id:s().states.erase(state)
	for effect in m().state.world.modifiers.duplicate():
		if str(effect.get("source_tag",""))==id:m().state.world.modifiers.erase(effect)
func has_state(id: String) -> bool:return s().states.any(func(state):return str(state.id)==id and int(state.until)>now())
func on_cooking() -> void:
	s().kitchen_uses+=1
	m().full_rules.world.on_hook("kitchen_usage",{"usage":int(s().kitchen_uses)})
func on_sale(customer: Dictionary,worker: Dictionary,amount: float,review: float) -> void:
	if bool(customer.get("v18_sale_recorded",false)):return
	customer.v18_sale_recorded=true
	s().review_streak=int(s().review_streak)+1 if amount>0 and review>0 else 0
	m().full_rules.world.on_hook("review_streak",{"streak":int(s().review_streak)})
	if amount<=0:return
	var chance=m().full_rules.revision19.drop_chance(worker)
	if m()._rng.randf()>=clampf(chance,0,1):return
	var roll=m()._rng.randf();var cumulative=0.0;var chosen: Dictionary=config.pickup.weights.back()
	for candidate in config.pickup.weights:
		var weight=float(candidate.weight)
		if str(candidate.kind)=="cash":weight=weight/.97*value("pickup_cash_weight",.97)
		else:weight=value("pickup_spirit_weight",.03)
		cumulative+=weight
		if roll<cumulative:chosen=candidate;break
	m().full_rules.revision19.spawn(str(chosen.kind),int(chosen.amount))

func drop_position() -> Vector2:
	var dims=Space.grid_dimensions(m())
	var points: Array[Vector2]=[]
	for y in range(dims.y):
		for x in range(dims.x):
			var occupied=m().state.layout.any(func(item):return Rect2i(item.x,item.y,item.w,item.h).has_point(Vector2i(x,y)))
			var point=Space.cell_rect(m(),x,y).get_center()
			if not occupied and not s().pickups.any(func(p):return point.distance_to(Vector2(p.x,p.y))<75):points.append(point)
	return points[m()._rng.randi_range(0,points.size()-1)] if not points.is_empty() else Vector2(510,500)
func advance_pickups(delta: float) -> void:
	if m().paused or not is_finite(delta) or delta<=0:return
	if m().full_rules.revision19.auto_active():m().full_rules.revision19.collect_all();return
	for pickup in s().pickups.duplicate():
		pickup.remaining=maxf(0,float(pickup.remaining)-delta)
		if float(pickup.remaining)<=0:s().pickups.erase(pickup)
func clean_available(employee: Dictionary) -> bool:
	return not employee.is_empty() and m().full_rules.management._available(employee) and m()._worker_task_count(str(employee.id))==0 and not draining(str(employee.id)) and float(employee.stamina)>0 and (not employee.resting or bool(employee.get("v18_auto_rest",false)))
func can(action: String,args: Dictionary={}) -> Dictionary:
	if action=="pickup_collect":return result(s().pickups.any(func(p):return int(p.id)==int(args.get("id",0)) and float(p.remaining)>0),"该拾取物已消失或已拾取")
	if action=="kitchen_clean":
		if not s().cleaning.is_empty():return result(false,"后厨清洁正在进行")
		if float(m().state.cash)<float(config.kitchen.clean_cost):return result(false,"清洁后厨需要￥%.0f" % float(config.kitchen.clean_cost))
		if not clean_available(m()._employee(str(args.get("employee_id","")))):return result(false,"请选择一位空闲员工；正在收尾、培训、装修或派驻中的员工不可清洁")
		return result(true)
	return result(false,"未知操作")
func perform(action: String,args: Dictionary={}) -> Dictionary:
	var check=can(action,args)
	if not check.ok:return check
	if action=="pickup_collect":
		for pickup in s().pickups.duplicate():
			if int(pickup.id)!=int(args.get("id",0)):continue
			s().pickups.erase(pickup)
			var amount=m().full_rules.revision19.reward(pickup)
			var source="自动吸附" if bool(args.get("automatic",false)) else "手动拾取"
			if str(pickup.kind)=="cash":
				m().change_cash(amount,"pickup_cash",source+"钞票")
				m().full_rules.record("other_income",amount,source+"钞票（非菜品营业额）")
			else:m().state.gems+=int(amount)
			s().collected.append({"id":int(pickup.id),"kind":str(pickup.kind),"amount":amount,"base_amount":int(pickup.amount),"minute":now(),"source":source})
			while s().collected.size()>60:s().collected.pop_front()
			m()._notify("+%.2f %s（%s）" % [amount,"元" if str(pickup.kind)=="cash" else "灵石",source])
	else:
		var employee: Dictionary=m()._employee(str(args.employee_id))
		m().full_rules.management._suspend(employee)
		employee.v18_clean_until=now()+int(config.kitchen.clean_minutes)
		s().cleaning={"employee_id":str(employee.id),"started":now(),"due":int(employee.v18_clean_until)}
		m().change_cash(-float(config.kitchen.clean_cost),"kitchen_clean","清洁后厨")
		m().full_rules.record("expenses",float(config.kitchen.clean_cost),"后厨清洁用品与维护")
		m()._notify(str(employee.name)+"开始清洁后厨，15游戏分钟后完成。")
	m().changed.emit();m().autosave_requested.emit()
	return check
func validate(saved: Dictionary,employees: Array) -> bool:
	if not saved.has("revision18"):return true
	var d: Variant=saved.revision18
	if not d is Dictionary or d.get("version")!=1:return false
	for key in ["pickups","collected","states","closing_ids"]:
		if not d.get(key) is Array:return false
	for key in ["next_pickup","review_streak","kitchen_uses"]:
		if not m()._integer(d.get(key),1 if key=="next_pickup" else 0):return false
	if not d.get("period") in ["closed","breakfast","rest","lunch","tea","dinner","night_market"] or not m()._integer(d.get("last_cutoff"),-1):return false
	if d.pickups.size()>3 or d.collected.size()>60 or d.states.size()>config.states.size():return false
	var ids: Array=[]
	for pickup in d.pickups:
		if not pickup is Dictionary or not m()._integer(pickup.get("id"),1) or int(pickup.id)>=int(d.next_pickup) or pickup.id in ids:return false
		if not config.pickup.weights.any(func(item):return str(item.kind)==str(pickup.get("kind","")) and item.amount==pickup.get("amount")):return false
		if pickup.has("cash_bonus") and (not m()._number(pickup.cash_bonus) or float(pickup.cash_bonus)<0 or float(pickup.cash_bonus)>1):return false
		for key in ["x","y","remaining"]:
			if not m()._number(pickup.get(key)):return false
		if float(pickup.x)<0 or float(pickup.x)>(52+float(saved.revision191.cell_width)*int(saved.revision191.grid_width) if saved.has("revision191") else Space.WORLD_SIZE.x) or float(pickup.y)<0 or float(pickup.y)>Space.WORLD_SIZE.y or float(pickup.remaining)<=0 or float(pickup.remaining)>15:return false
		ids.append(pickup.id)
	for item in d.collected:
		if not item is Dictionary or not m()._integer(item.get("id"),1) or int(item.id)>=int(d.next_pickup) or item.id in ids:return false
		if not m()._integer(item.get("minute")) or int(item.minute)>int(saved.total_minutes):return false
		if not config.pickup.weights.any(func(weight):return str(weight.kind)==str(item.get("kind","")) and weight.amount==item.get("base_amount",item.get("amount"))):return false
		if not m()._number(item.get("amount")) or float(item.amount)<float(item.get("base_amount",item.amount)) or float(item.amount)>float(item.get("base_amount",item.amount))*3:return false
		ids.append(item.id)
	ids=[]
	for state in d.states:
		if not state is Dictionary or not config.states.has(str(state.get("id",""))) or state.id in ids:return false
		if not m()._integer(state.get("started")) or int(state.started)>int(saved.total_minutes) or not m()._integer(state.get("until")) or int(state.until)-int(state.started)!=int(config.states[state.id].duration):return false
		ids.append(state.id)
	for id in d.closing_ids:
		if not id is String or not employees.any(func(e):return str(e.id)==id):return false
	if not d.get("cleaning") is Dictionary:return false
	if not d.cleaning.is_empty():
		if not m()._integer(d.cleaning.get("started")) or not m()._integer(d.cleaning.get("due")) or int(d.cleaning.started)>int(saved.total_minutes) or int(d.cleaning.due)-int(d.cleaning.started)!=int(config.kitchen.clean_minutes):return false
		if employees.filter(func(e):return str(e.id)==str(d.cleaning.get("employee_id","")) and e.get("v18_clean_until",0)==d.cleaning.due).size()!=1:return false
	for employee in employees:
		if int(employee.get("v18_clean_until",0))>0 and (d.cleaning.is_empty() or str(d.cleaning.employee_id)!=str(employee.id)):return false
	return true
