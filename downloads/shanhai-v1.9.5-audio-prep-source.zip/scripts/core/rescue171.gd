extends RefCounted
const ACTIONS=["emergency_accept","emergency_repay","rescue_decline","warning_ack"]
var _ref: WeakRef
func _init(host) -> void:_ref=weakref(host)
func m():return _ref.get_ref()
func s() -> Dictionary:return m().state.rescue171
func cfg() -> Dictionary:return m().full_rules.revision.config.rescue
func ensure_state() -> void:
	if not m().state.has("rescue171"):
		m().state.rescue171={"version":1,"used":false,"ended":false,"menu":false,"warning_pending":false,"warning_day":-1,"checked":int(m().state.total_minutes),"last_cash":float(m().state.cash),"drops":0,"final":{},"loan":{"principal":0.0,"interest_arrears":0.0,"fine_arrears":0.0,"opened_day":0,"due_day":0,"penalty_applied":false}}
func result(ok: bool,reason: String="",extra: Dictionary={}) -> Dictionary:
	var r={"ok":ok,"reason":reason};r.merge(extra,true);return r
func regular_banned() -> bool:
	var ordinary: Dictionary=m().state.finance.loan
	return float(m().state.cash)<0 or (int(m().state.overdue_count)>0 and float(m().state.debt)>0) or float(m().state.interest_arrears)>0 or (int(ordinary.due_day)>0 and m().full_rules.finance.current_day()>=int(ordinary.due_day) and float(ordinary.principal)>0) or float(ordinary.interest_arrears)+float(ordinary.fine_arrears)>0
func fixed_cost() -> float:
	var preview: Dictionary=m().full_rules.finance.preview_bill()
	var total=0.0
	for key in ["wages_due","rent_due","utilities_due","interest_due","minimum_due","loan_interest_due"]:total+=float(preview.get(key,0))
	return total+float(s().loan.principal)*float(cfg().daily_rate)
func tick() -> void:
	if s().ended or bool(m().state.finance.rescue.pending):return
	var now=int(m().state.total_minutes)
	if now-int(s().checked)<int(cfg().warning_interval):return
	s().checked=now
	s().drops=int(s().drops)+1 if float(m().state.cash)<float(s().last_cash) else 0
	s().last_cash=float(m().state.cash)
	if int(s().drops)>=int(cfg().warning_drops) and float(m().state.cash)<fixed_cost() and int(s().warning_day)!=now/1440:
		s().warning_pending=true;s().warning_day=now/1440;m().paused=true
		m()._notify("白泽：现金连续下降且不足预计固定支出，请先补货、安排人手并控制采购。紧急救援本局仅一次，日息2%。")
func assess_rescue() -> void:
	if bool(m().state.finance.rescue.pending) and bool(s().used):end_run("本局已使用紧急救援，再次破产，经营结束。")
func end_run(reason: String) -> void:
	s().ended=true;s().warning_pending=false;m().paused=true;m().state.finance.rescue.pending=true
	s().final={"reason":reason,"revenue":float(m().state.total_revenue),"peak_reputation":maxi(int(m().state.revision171.peak_reputation),int(m().state.reputation)),"collected":m().state.story.collected_ids.size(),"days":int(m().state.total_minutes)/1440+1}
	m()._notify("经营失败："+reason)
func can(action: String,args: Dictionary={}) -> Dictionary:
	match action:
		"warning_ack":return result(bool(s().warning_pending),"当前没有预警")
		"rescue_decline":return result(bool(m().state.finance.rescue.pending) and not s().ended,"当前没有待选择的救援")
		"emergency_accept":
			if not bool(m().state.finance.rescue.pending) or s().ended:return result(false,"紧急贷款仅在濒临破产的救援画面提供")
			if s().used:return result(false,"本局紧急救援已使用，无法再次申请")
			if not bool(args.get("confirmed",false)):return result(false,"请先确认救援代价：5000元，日息2%，20日到期，逾期声望−50/罚款400元；再次破产强制结束")
			return result(true)
		"emergency_repay":
			var amount: Variant=args.get("amount",0)
			if not m()._number(amount) or float(amount)<=0:return result(false,"请输入正数还款金额")
			var owed=float(s().loan.principal)+float(s().loan.interest_arrears)+float(s().loan.fine_arrears)
			if owed<=0:return result(false,"没有待还的紧急贷款")
			return result(float(m().state.cash)>=minf(owed,float(amount)),"现金不足",{"amount":minf(owed,float(amount))})
	return result(false,"未知救援操作")
func perform(action: String,args: Dictionary={}) -> Dictionary:
	var check=can(action,args)
	if not check.ok:return check
	match action:
		"warning_ack":s().warning_pending=false;m().paused=false
		"rescue_decline":end_run("已放弃一次性紧急救援。")
		"emergency_accept":
			s().used=true;s().warning_pending=false
			var day=m().full_rules.finance.current_day()
			s().loan.merge({"principal":float(cfg().amount),"opened_day":day,"due_day":day+int(cfg().term_days)},true)
			m().change_cash(float(cfg().amount),"emergency_principal","一次性紧急救援贷款本金（非营业收入）")
			m().full_rules.record("financing",float(cfg().amount),"紧急救援借款")
			m().settle_arrears()
			if float(m().state.cash)<0 or float(m().state.wage_arrears)+float(m().state.rent_arrears)+float(m().state.interest_arrears)>0.005:
				end_run("救援后仍不能补足欠款，经营结束。")
			else:
				m().state.finance.rescue.pending=false;m().state.finance.unpaid_days=0;m().paused=false
				m()._notify("5000元救援到账并清偿经营欠款。紧急贷款日息2%，20日内偿还；本局不再提供第二次救援。")
		"emergency_repay":
			var remaining=float(check.amount)
			for field in ["fine_arrears","interest_arrears","principal"]:
				var paid=minf(remaining,float(s().loan[field]));s().loan[field]=m()._money(float(s().loan[field])-paid);remaining=m()._money(remaining-paid)
				if paid<=0:continue
				m().change_cash(-paid,"emergency_repayment" if field=="principal" else "liability_settlement","偿还紧急贷款"+str(field))
				if field=="principal":m().full_rules.record("financing",-paid,"偿还紧急贷款本金")
	m().changed.emit();m().autosave_requested.emit();return check
func charge_day(report: Dictionary) -> void:
	var loan: Dictionary=s().loan
	if float(loan.principal)<=0:return
	var finance=m().full_rules.finance
	var due=m()._money(float(loan.principal)*float(cfg().daily_rate))
	var paid=finance._pay(due,"emergency_interest","紧急救援贷款日息2%")
	loan.interest_arrears=m()._money(float(loan.interest_arrears)+due-paid)
	report["emergency_interest_due"]=due;report["emergency_interest"]=paid
	report.loan_interest_due=float(report.loan_interest_due)+due;report.loan_interest=float(report.loan_interest)+paid
	if int(report.day)>=int(loan.due_day) and not loan.penalty_applied:
		loan.penalty_applied=true;m().state.reputation=maxi(0,int(m().state.reputation)-int(cfg().reputation_penalty))
		var fine=float(cfg().fine);var fine_paid=finance._pay(fine,"emergency_fine","紧急贷款逾期罚款400元")
		loan.fine_arrears=m()._money(float(loan.fine_arrears)+fine-fine_paid)
		report.loan_fine=float(report.loan_fine)+fine_paid
		m().full_rules.record("expenses",fine,"紧急救援贷款逾期罚款")
		m()._notify("紧急救援贷款已逾期：声望−50，罚款400元；欠息和罚款均不计复利。")
func validate(saved: Dictionary) -> bool:
	if not saved.has("rescue171"):return true
	var d: Variant=saved.rescue171
	if not d is Dictionary or d.get("version")!=1:return false
	for key in ["used","ended","menu","warning_pending"]:
		if not d.get(key) is bool:return false
	for key in ["checked","drops"]:
		if not m()._integer(d.get(key)):return false
	if not m()._integer(d.get("warning_day"),-1) or not m()._number(d.get("last_cash")) or not d.get("final") is Dictionary:return false
	if not d.get("loan") is Dictionary:return false
	for key in ["principal","interest_arrears","fine_arrears"]:
		if not m()._number(d.loan.get(key)) or float(d.loan[key])<0:return false
	for key in ["opened_day","due_day"]:
		if not m()._integer(d.loan.get(key)):return false
	if not d.loan.get("penalty_applied") is bool:return false
	if float(d.loan.principal)>float(cfg().amount) or (float(d.loan.principal)>0 and not d.used):return false
	if d.used and int(d.loan.due_day)-int(d.loan.opened_day)!=int(cfg().term_days):return false
	if d.ended and (d.final.is_empty() or not bool(saved.finance.rescue.pending)):return false
	return true
