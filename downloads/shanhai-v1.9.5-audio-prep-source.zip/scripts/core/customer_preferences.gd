extends RefCounted
## A guest decides what to eat from independently generated taste and meal needs.
## Demographic tendencies are small soft weights, never menu eligibility rules.

var _model_ref: WeakRef
var model: Variant:
	get: return _model_ref.get_ref()
var config: Dictionary = {}

func _init(host: RefCounted) -> void:
	_model_ref = weakref(host)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/guests.json"))
	if parsed is Dictionary: config = parsed

func _value(key: String, fallback: float) -> float:
	var value: Variant = model.balance.get("guests." + key, fallback)
	return float(value) if (value is int or value is float) and is_finite(float(value)) else fallback

func _pick(section: String) -> Dictionary:
	var entries: Array = config.get(section, [])
	var total: float = 0
	for entry in entries: total += maxf(0, _value(section + "." + str(entry.id) + ".weight", float(entry.weight)))
	if total <= 0: return entries.front() if not entries.is_empty() else {}
	var roll: float = model._rng.randf() * total
	for entry in entries:
		roll -= maxf(0, _value(section + "." + str(entry.id) + ".weight", float(entry.weight)))
		if roll < 0: return entry
	return entries.back()

func generate_profile() -> Dictionary:
	var age_group: Dictionary = _pick("ages")
	var gender: Dictionary = _pick("genders")
	# These are separate rolls: any age or gender can choose any taste/need.
	var taste: Dictionary = _pick("tastes")
	var need: Dictionary = _pick("needs")
	var prefix: String = "ages." + str(age_group.get("id", "adult"))
	var minimum: int = int(_value(prefix + ".minimum", float(age_group.get("minimum", 18))))
	var maximum: int = int(_value(prefix + ".maximum", float(age_group.get("maximum", 80))))
	return {"age_group":str(age_group.get("id", "adult")), "age":model._rng.randi_range(minimum, maxi(minimum, maximum)),
		"gender":str(gender.get("id", "unspecified")), "tastes":[str(taste.get("id", "homestyle"))], "needs":[str(need.get("id", "ordinary"))]}

func _matches(tags: Array, choices: Array) -> bool:
	for tag in tags:
		if tag in choices: return true
	return false

func dish_weight(dish: Dictionary, profile: Dictionary) -> float:
	var choice: Dictionary = config.get("choice", {})
	var result: float = maxf(0.01, _value("choice.base_weight", float(choice.get("base_weight", 1))))
	if _matches(dish.get("taste_tags", []), profile.get("tastes", [])):
		result *= 1 + maxf(0, _value("choice.taste_match_bonus", float(choice.get("taste_match_bonus", 2))))
	if _matches(dish.get("need_tags", []), profile.get("needs", [])):
		result *= 1 + maxf(0, _value("choice.need_match_bonus", float(choice.get("need_match_bonus", 2))))
	for tendency in config.get("demographic_tendencies", []):
		if str(profile.get(str(tendency.field), "")) == str(tendency.value) and str(dish.get("id", "")) in tendency.dish_ids:
			result *= 1 + clampf(_value("demographic_tendencies." + str(tendency.id) + ".bonus", float(tendency.bonus)), 0, 0.5)
	return maxf(0.01, result)

func _label(section: String, id: String) -> String:
	for entry in config.get(section, []):
		if str(entry.id) == id: return str(entry.get("label", id))
	return id

func describe_profile(profile: Dictionary) -> String:
	var labels: PackedStringArray = []
	for taste in profile.get("tastes", []): labels.append(_label("tastes", str(taste)))
	for need in profile.get("needs", []): labels.append(_label("needs", str(need)))
	return "、".join(labels)

func explain(dish: Dictionary, profile: Dictionary) -> Array[String]:
	var result: Array[String] = []
	for taste in profile.get("tastes", []):
		if taste in dish.get("taste_tags", []): result.append("个人口味：" + _label("tastes", str(taste)))
	for need in profile.get("needs", []):
		if need in dish.get("need_tags", []): result.append("用餐需求：" + _label("needs", str(need)))
	for tendency in config.get("demographic_tendencies", []):
		if str(profile.get(str(tendency.field), "")) == str(tendency.value) and str(dish.get("id", "")) in tendency.dish_ids:
			result.append(str(tendency.label) + "（不限制其他选择）")
	if result.is_empty(): result.append("菜单中的自由选择")
	return result

func validate_profile(profile: Variant) -> bool:
	if not profile is Dictionary: return false
	var valid_age: bool = false
	for age_group in config.get("ages", []):
		if str(profile.get("age_group", "")) == str(age_group.id):
			# Saved age is not checked against a subsequently hot-edited range.
			valid_age = true
	var age: Variant = profile.get("age")
	if not valid_age or not (age is int or age is float) or not is_finite(float(age)) or float(age) != floorf(float(age)) or int(age) < 0 or int(age) > 150: return false
	for section in ["genders", "tastes", "needs"]:
		var choices: Variant = [profile.get("gender", "")] if section == "genders" else profile.get(section)
		if not choices is Array or choices.is_empty() or choices.size() > config.get(section, []).size(): return false
		var seen: Array = []
		for id in choices:
			if not id is String or id in seen: return false
			var found: bool = false
			for entry in config.get(section, []):
				if str(entry.id) == id: found = true
			if not found: return false
			seen.append(id)
	return true

func balance_defaults() -> Dictionary:
	var result: Dictionary = {}
	for section in ["ages", "genders", "tastes", "needs", "demographic_tendencies"]:
		for entry in config.get(section, []):
			for key in entry:
				if entry[key] is int or entry[key] is float: result["guests.%s.%s.%s" % [section, entry.id, key]] = entry[key]
	for key in config.get("choice", {}): result["guests.choice." + key] = config.choice[key]
	return result

func validate_balance(candidate: Dictionary) -> bool:
	var values: Dictionary = balance_defaults()
	for key in candidate:
		if not str(key).begins_with("guests."): continue
		var value: Variant = candidate[key]
		if not values.has(key) or not (value is int or value is float) or not is_finite(float(value)) or float(value) < 0: return false
		values[key] = value
	for section in ["ages", "genders", "tastes", "needs"]:
		var total: float = 0
		for entry in config.get(section, []): total += float(values["guests.%s.%s.weight" % [section, entry.id]])
		if total <= 0: return false
	for entry in config.get("ages", []):
		var minimum: float = float(values["guests.ages.%s.minimum" % entry.id])
		var maximum: float = float(values["guests.ages.%s.maximum" % entry.id])
		if minimum != floorf(minimum) or maximum != floorf(maximum) or maximum < minimum or maximum > 150: return false
	for entry in config.get("demographic_tendencies", []):
		if float(values["guests.demographic_tendencies.%s.bonus" % entry.id]) > 0.5: return false
	return float(values["guests.choice.base_weight"]) > 0
