extends RefCounted
## Staff development, full dish research and separately valued ingredient inventory.
## Standalone projects deliberately do not add legacy scheduler events.

var _model_ref: WeakRef
var model: Variant:
	get: return _model_ref.get_ref()
var config: Dictionary = {}
var ingredients: Array = []
var _canonical_prices: Dictionary = {}
var _canonical_quality: Dictionary = {}

func _init(host: Variant) -> void:
	_model_ref = weakref(host)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/management.json"))
	config = parsed if parsed is Dictionary else {}
	# v1.3 adds Tutor as a real occupation. Keep the on-disk v1.2 config
	# readable; expose the new role through the same configuration API.
	if not "tutor" in config.get("roles", []): config.get_or_add("roles", []).append("tutor")
	if not config.get("coefficients", {}).has("hidden_creativity"):
		config.get_or_add("coefficients", {})["hidden_creativity"] = 0.01
	parsed = JSON.parse_string(FileAccess.get_file_as_string("res://config/ingredients.json"))
	ingredients = parsed if parsed is Array else []
	parsed = JSON.parse_string(FileAccess.get_file_as_string("res://config/dishes.json"))
	if parsed is Array:
		for dish in parsed:
			_canonical_prices[str(dish.id)] = float(dish.price)
			_canonical_quality[str(dish.id)] = float(dish.get("quality", 75))
	var sidequest_config: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"))
	if sidequest_config is Dictionary:
		for dish in sidequest_config.get("hidden_recipes",[]):
			_canonical_prices[str(dish.id)]=float(dish.price)
			_canonical_quality[str(dish.id)]=float(dish.get("quality",75))
	var hidden: Dictionary = config.get("hidden_recipe", {})
	if not hidden.is_empty(): _canonical_quality[str(hidden.id)] = float(hidden.get("quality", 75))

func _v(group: String, key: String, fallback: Variant = 0) -> Variant:
	var value: Variant = config.get(group, {}).get(key, fallback)
	if value is int or value is float:
		var override: Variant = model.balance.get("management.%s.%s" % [group, key], value)
		if (override is int or override is float) and is_finite(float(override)): return override
	return value

func coefficient(id: String) -> float:
	# Shared coefficients in global_balance take priority over module-specific values.
	return float(model.balance.get("coeff." + id, config.get("coefficients", {}).get(id, 0)))

func dish_quality(dish_id: String) -> float:
	# Per-dish quality is independently adjustable. The prototype knob remains
	# a fallback for legacy/missing definitions, never a mask over the catalog.
	var dish: Dictionary = model._dish(dish_id)
	var fallback: float = float(dish.get("quality", model.balance.get("prototype.base_quality", 75)))
	var value: Variant = model.balance.get("dish.%s.quality" % dish_id, fallback)
	return float(value) if _finite(value) else fallback

func _now() -> int:
	return int(model.state.get("total_minutes", 0))

func _data() -> Dictionary:
	return model.state.get("management", {})

func ensure_state() -> void:
	if not model.state.get("management", null) is Dictionary:
		model.state.management = {}
	var data: Dictionary = _data()
	var fresh: bool = not data.has("items")
	var defaults: Dictionary = {"version": 1, "items": {}, "projects": [], "suppliers": [], "skill_books": int(_v("initial", "skill_books")), "auto_procure": bool(_v("initial", "auto_procure", true)), "procurement_strategy": "auto" if bool(_data().get("auto_procure",_v("initial","auto_procure",true))) else "pause", "fixed_quantities": {}, "procurement_prepared_day": 0, "pending_auto_purchases": [], "tutorial_trial_available": bool(_v("initial", "tutorial_trial_available", true)) and str(model.state.get("mode",""))!="full", "base_prices": {}, "price_overrides": {}, "hidden_effects": {}, "departed": [], "daily_cogs": 0.0, "total_cogs": 0.0, "daily_procurement": 0.0, "total_procurement": 0.0, "daily_development": 0.0, "last_day": {}}
	for key in defaults:
		if not data.has(key): data[key] = defaults[key].duplicate(true) if defaults[key] is Dictionary or defaults[key] is Array else defaults[key]
	for definition in ingredients:
		var id: String = str(definition.id)
		if not data.items.has(id):
			data.items[id] = {"quantity": 0.0, "freshness": 100.0, "value": 0.0, "consumption_today": 0.0, "history": []}
	if fresh:
		var quantity: float = maxf(0, float(model.state.get("ingredients", 0)))
		data.items.generic.quantity = quantity
		data.items.generic.value = quantity * float(_ingredient("generic").get("price", 3))
		data.items.generic.freshness = clampf(float(model.state.get("freshness", 100)), 0, 100)
	for employee in model.employees: _ensure_employee(employee)
	if fresh:
		var hidden_id: String = str(config.get("hidden_recipe", {}).get("id", ""))
		for index in range(model.dishes.size() - 1, -1, -1):
			if str(model.dishes[index].id) == hidden_id and not bool(data.get("hidden_unlocked", false)): model.dishes.remove_at(index)
	for dish in model.dishes:
		var id: String = str(dish.id)
		var fallback: float=float(config.get("hidden_recipe",{}).get("price",dish.price)) if id==str(config.get("hidden_recipe",{}).get("id","")) else float(dish.price)
		var canonical: float = float(_canonical_prices.get(id,fallback))
		if not data.base_prices.has(id): data.base_prices[id] = canonical
		dish.price = float(data.price_overrides.get(id, canonical))
	if bool(data.get("hidden_unlocked", false)): _ensure_hidden_dish()
	_sync_totals()

func _ensure_employee(employee: Dictionary) -> void:
	# Values explicitly present in the catalog remain unchanged; only absent
	# fields use the seven-attribute schema's v1.3 default of zero.
	if not employee.get("attributes") is Dictionary: employee.attributes = {}
	for attribute in config.get("attributes", []):
		if not employee.attributes.has(attribute): employee.attributes[attribute] = 0
	var defaults: Dictionary = {"primary_role": str(employee.get("role", "waiter")), "secondary_role": "", "skill_level": 1, "wage_extra": 0, "management_until": 0, "management_job_type": "", "shift_enabled": false, "shift_periods": config.get("periods", []).duplicate(), "training_history": {}, "training_experience_by_attribute": {}, "phoenix_revived_day": -1, "pending_resignation": false}
	for key in defaults:
		if not employee.has(key): employee[key] = defaults[key].duplicate(true) if defaults[key] is Array or defaults[key] is Dictionary else defaults[key]

func _ingredient(id: String) -> Dictionary:
	for definition in ingredients:
		if str(definition.id) == id:
			var result: Dictionary = definition.duplicate(true)
			var override: Variant = model.balance.get("management.ingredients.%s.price" % id, definition.price)
			if (override is int or override is float) and is_finite(float(override)) and float(override) > 0: result.price = float(override)
			return result
	return {}

func item(id: String) -> Dictionary:
	return _data().get("items", {}).get(id, {})

func _sync_totals() -> void:
	var quantity: float = 0
	var freshness: float = 0
	for record in _data().get("items", {}).values():
		quantity += float(record.quantity)
		freshness += float(record.quantity) * float(record.freshness)
	model.state.ingredients = quantity
	model.state.freshness = freshness / quantity if quantity > 0 else 100.0

func recipe(dish_id: String) -> Dictionary:
	var dish: Dictionary = model._dish(dish_id)
	if dish.is_empty(): return {}
	var weights: Dictionary = config.get("recipes", {}).get(dish_id, {})
	if weights.is_empty(): weights=model._dish(dish_id).get("recipe_weights",{})
	if dish_id == str(config.get("hidden_recipe", {}).get("id", "")):
		weights = config.hidden_recipe.get("recipe_weights", {})
	var denominator: float = 0
	for id in weights:
		denominator += float(weights[id]) * float(_ingredient(str(id)).get("price", 0))
	if denominator <= 0: return {}
	var result: Dictionary = {}
	for id in weights:
		result[id] = float(weights[id]) * float(dish.cost) / denominator
	return result

func can_make(dish_id: String, mult: float = 1) -> bool:
	if not is_finite(mult) or mult <= 0: return false
	var requirements: Dictionary = recipe(dish_id)
	if requirements.is_empty(): return false
	for id in requirements:
		if float(item(id).get("quantity", 0)) + 0.000001 < float(requirements[id]) * mult: return false
	return true

func consume(dish_id: String, mult: float = 1, recognize_cogs: bool = true) -> Dictionary:
	if not can_make(dish_id, mult): return _result(false, "所需食材不足")
	var consumed: Dictionary = {}
	var cost: float = 0
	for id in recipe(dish_id):
		var quantity: float = float(recipe(dish_id)[id]) * mult
		var record: Dictionary = item(id)
		var value: float = float(record.value) * quantity / float(record.quantity)
		record.quantity = maxf(0, float(record.quantity) - quantity)
		record.value = maxf(0, float(record.value) - value)
		record.consumption_today = float(record.consumption_today) + quantity
		consumed[id] = quantity
		cost += value
	if recognize_cogs: recognize_cost(cost)
	_sync_totals()
	return {"ok": true, "reason": "", "cost": cost, "items": consumed}

func recognize_cost(cost: float) -> bool:
	if not is_finite(cost) or cost < 0: return false
	_data().daily_cogs = float(_data().daily_cogs) + cost
	_data().total_cogs = float(_data().total_cogs) + cost
	return true

func _consume_generic(quantity: float) -> bool:
	var record: Dictionary = item("generic")
	if quantity < 0 or float(record.get("quantity", 0)) < quantity: return false
	if quantity == 0: return true
	var value: float = float(record.value) * quantity / float(record.quantity)
	record.quantity = float(record.quantity) - quantity
	record.value = maxf(0, float(record.value) - value)
	record.consumption_today = float(record.consumption_today) + quantity
	_data().daily_development = float(_data().daily_development) + value
	var rules: Variant = model.get("full_rules")
	if rules != null and rules.has_method("record"): rules.record("expenses", value, "研发耗用食材")
	_sync_totals()
	return true

func add_item(id: String, quantity: float, cost: float = 0) -> bool:
	if _ingredient(id).is_empty() or not is_finite(quantity) or not is_finite(cost) or quantity <= 0 or cost < 0: return false
	var record: Dictionary = item(id)
	if record.is_empty(): return false
	var old: float = float(record.quantity)
	record.freshness = (old * float(record.freshness) + quantity * 100) / (old + quantity)
	record.quantity = old + quantity
	record.value = float(record.value) + cost
	_sync_totals()
	return true

func purchase(id: String, quantity: float) -> Dictionary:
	return perform("purchase", {"id": id, "quantity": quantity})

func stock_price(id: String) -> float:
	var price: float = float(_ingredient(id).get("price", 0))
	var discount: float = 1
	if _now() < int(model.state.get("discount_until", 0)):
		discount = minf(discount, float(model.state.get("procurement_discount", 1)))
	var world: Dictionary = model.state.get("world", {})
	for effect in world.get("effects", []):
		if effect is Dictionary and int(effect.get("until", 0)) > _now() and str(effect.get("stat", "")) == "procurement_discount": discount = minf(discount, float(effect.get("value", 1)))
	var rules: Variant = model.get("full_rules")
	if rules != null and rules.get("world") != null and rules.world.has_method("procurement_multiplier"):
		discount = minf(discount, float(rules.world.procurement_multiplier(str(_ingredient(id).get("kind", "ordinary")))))
	return maxf(0.01, price * discount)

func quality_freshness(dish_id: String) -> float:
	var requirements: Dictionary = recipe(dish_id)
	var quantity: float = 0
	var fresh: float = 0
	for id in requirements:
		quantity += float(requirements[id])
		fresh += float(requirements[id]) * float(item(id).get("freshness", 100))
	return fresh / quantity if quantity > 0 else 100.0

func inventory_value() -> float:
	var value: float = 0
	for record in _data().get("items", {}).values(): value += float(record.value)
	return value

func stock_snapshot() -> Array:
	var result: Array = []
	for definition in ingredients:
		var record: Dictionary = item(str(definition.id))
		var row: Dictionary = definition.duplicate(true)
		row.merge(record.duplicate(true), true)
		row.cost_basis = float(record.get("value", 0)) / float(record.quantity) if float(record.get("quantity", 0)) > 0 else 0
		row.price = stock_price(str(definition.id))
		row.purchasable = str(definition.kind) == "ordinary" or (str(definition.kind) == "shanhai" and "shanhai" in _data().get("suppliers", []))
		row.reason = "稀有食材只能通过探索或事件获得" if str(definition.kind) == "rare" else ("先解锁山海供应商" if not row.purchasable else "")
		result.append(row)
	return result

func _available(employee: Dictionary, include_branch: bool = false) -> bool:
	if employee.is_empty() or (not include_branch and str(employee.get("branch_id", "")) != ""): return false
	if bool(employee.get("pending_resignation", false)): return false
	if model.state.has("revision171") and model.full_rules.revision.is_building(str(employee.id)): return false
	for field in ["training_until", "research_until", "management_until", "expansion_until", "leave_until", "construction_until", "v18_clean_until"]:
		if int(employee.get(field, 0)) > _now(): return false
	return true

func _active(employee: Dictionary) -> bool:
	return _available(employee) and not bool(employee.get("resting", false)) and float(employee.get("stamina", 0)) > 0

func _researcher(args: Dictionary) -> Dictionary:
	var requested: String = str(args.get("employee_id", ""))
	var best: Dictionary = {}
	for employee in model.employees:
		if not _active(employee) or not str(employee.role) in ["chef", "all", "tutor"]: continue
		if requested != "" and str(employee.id) != requested: continue
		if best.is_empty() or float(employee.attributes.get("creativity", 0)) > float(best.attributes.get("creativity", 0)): best = employee
	return best

func _employee_id(args: Dictionary) -> String:
	return str(args.get("employee_id", args.get("id", "")))

func _dish_id(args: Dictionary) -> String:
	return str(args.get("dish_id", args.get("id", "")))

func _result(ok: bool, reason: String = "", extra: Dictionary = {}) -> Dictionary:
	var result: Dictionary = {"ok": ok, "reason": reason}
	result.merge(extra, true)
	return result

func training_cost(employee: Dictionary, attribute: String = "") -> float:
	var rarity: float = float(_v("rarity_multipliers", str(employee.get("rarity", "N")), 1))
	return ceilf(float(_v("costs", "training")) * rarity * maxf(0, float(employee.get("attributes", {}).get(attribute, 0))))

func skill_cost(employee: Dictionary) -> int:
	return int(ceil(pow(2, int(employee.get("skill_level", 1)) - 1) * float(_v("rarity_multipliers", str(employee.get("rarity", "N")), 1))))

func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	if action == "auto_procure": action = "set_auto_procure"
	var employee: Dictionary = model._employee(_employee_id(args))
	var id: String = str(args.get("id", ""))
	var cost: float = 0
	match action:
		"purchase":
			var definition: Dictionary = _ingredient(id)
			var quantity: float = float(args.get("quantity", 0))
			if definition.is_empty() or not is_finite(quantity) or quantity <= 0: return _result(false, "请选择有效食材与正数数量")
			if str(definition.kind) == "rare": return _result(false, "稀有食材只能通过探索或事件获得")
			if str(definition.kind) == "shanhai" and not "shanhai" in _data().suppliers: return _result(false, "先解锁山海供应商")
			cost = model._money(quantity * stock_price(id))
		"discard_stock":
			var quantity: float = float(args.get("quantity", 0))
			if not is_finite(quantity) or quantity <= 0 or item(id).is_empty() or quantity > float(item(id).quantity): return _result(false, "请选择不超过现有库存的正数数量")
		"unlock_supplier":
			if id != "shanhai": return _result(false, "未知供应商")
			if id in _data().suppliers: return _result(false, "已解锁该供应商")
			if int(model.state.stage) < int(_v("thresholds", "supplier_stage")): return _result(false, "街角饭店阶段解锁山海供应商")
			cost = float(_v("costs", "supplier"))
		"train_attribute", "train_secondary", "switch_role", "upgrade_skill", "raise_wage", "comfort", "set_shift":
			if employee.is_empty(): return _result(false, "员工不存在")
			_ensure_employee(employee)
			if action in ["train_attribute", "train_secondary", "switch_role"] and not _available(employee): return _result(false, "员工正在执行任务，或已调往分店")
			match action:
				"train_attribute":
					if model.state.has("revision171") and int(employee.get("level",1))>=model.full_rules.revision.level_cap(employee): return _result(false,"已达到该阶次等级上限，需觉醒突破后继续培训")
					var attribute: String = str(args.get("attribute", "speed"))
					if not attribute in config.get("attributes", []): return _result(false, "未知属性")
					if float(employee.attributes.get(attribute, 0)) >= float(_v("limits", "attribute")): return _result(false, "属性已达到训练上限")
					cost = training_cost(employee, attribute)
				"train_secondary":
					var role: String = str(args.get("role", ""))
					if not role in config.get("roles", []): return _result(false, "未知职业")
					if role == str(employee.primary_role) or role == str(employee.secondary_role) or str(employee.primary_role) == "all": return _result(false, "员工已经掌握该职业")
					cost = ceilf(float(_v("costs", "secondary")) * float(_v("rarity_multipliers", str(employee.rarity), 1)))
				"switch_role":
					var role: String = str(args.get("role", ""))
					if not role in config.get("roles", []) and role != "all": return _result(false, "未知职业")
					if not role in [str(employee.primary_role), str(employee.secondary_role)] and str(employee.primary_role) != "all": return _result(false, "先完成该副职业培训")
				"upgrade_skill":
					if int(model.state.stage) < int(_v("thresholds", "skill_stage")): return _result(false, "街角饭店阶段解锁神通升级")
					if int(employee.skill_level) >= int(_v("limits", "skill_level")): return _result(false, "神通已达到最高等级")
					if str(args.get("method", "fragments")) == "book":
						if int(_data().skill_books) < 1: return _result(false, "技能书不足")
					elif int(model.state.get("fragments", {}).get(str(employee.id), 0)) < skill_cost(employee): return _result(false, "员工碎片不足", {"fragments_required": skill_cost(employee)})
				"raise_wage":
					if int(employee.wage_extra) >= int(_v("limits", "wage_extra")): return _result(false, "加薪已达到每日上限")
				"comfort": cost = float(_v("costs", "comfort"))
				"set_shift":
					if model.state.has("revision171") and (model.full_rules.revision.is_building(str(employee.id)) or int(employee.management_until)>_now()): return _result(false,"培训、研发或装修中不可重新排班")
					if not args.get("periods", []) is Array: return _result(false, "排班时段格式无效")
					for period in args.get("periods", []):
						if not period in config.get("periods", []): return _result(false, "未知排班时段")
		"research":
			var dish_id: String = _dish_id(args)
			var dish: Dictionary = model._dish(dish_id)
			if dish.is_empty(): return _result(false, "菜谱不存在")
			if bool(dish.get("hidden",false)) and dish_id!=str(config.get("hidden_recipe",{}).get("id","")): return _result(false,"该隐藏菜须完成对应神兽支线后领取")
			if dish_id in model.state.get("unlocked_dishes", []): return _result(false, "该菜品已经解锁")
			for project in _data().projects:
				if str(project.get("dish_id", "")) == dish_id: return _result(false, "该菜品正在研发中")
			var tutorial: bool = bool(args.get("tutorial", false))
			if tutorial and (dish_id != "qianyang_soup" or not bool(_data().tutorial_trial_available)): return _result(false, "免费试制只能进行一次羬羊汤研发")
			if not tutorial and int(model.state.stage) < int(_v("thresholds", "research_stage")): return _result(false, "餐厅升级至街角饭店后解锁常规研发")
			var required: String = str(dish.get("required_employee", ""))
			if required != "" and model._employee(required).is_empty(): return _result(false, "需要拥有" + str(model._employee_config(required).get("name", required)))
			if _researcher(args).is_empty(): return _result(false, "需要主店在岗且空闲于其他任务的厨师或培训导师主持研发")
			if not tutorial and float(item("generic").get("quantity", 0)) < float(_v("costs", "research_generic")): return _result(false, "普通通用食材不足")
			cost = 0 if tutorial else float(_v("costs", "research_cash"))
		"set_price":
			if int(model.state.stage) < int(_v("thresholds", "pricing_stage")): return _result(false, "街角饭店阶段解锁菜品定价")
			var dish_id: String = _dish_id(args)
			if not dish_id in model.state.get("unlocked_dishes", []): return _result(false, "菜品尚未解锁")
			var price: float = float(args.get("price", 0))
			var base: float = float(_data().base_prices.get(dish_id, 0))
			if not is_finite(price) or price < base * float(_v("limits", "price_min")) or price > base * float(_v("limits", "price_max")): return _result(false, "定价需在默认价格的50%至200%之间")
		"set_menu":
			if not _dish_id(args) in model.state.get("unlocked_dishes", []): return _result(false, "菜品尚未解锁")
		"set_auto_procure": pass
		"set_procurement_strategy":
			if not str(args.get("strategy","")) in ["auto","fixed","pause"]: return _result(false,"采购策略须为自动补货、固定数量或暂停采购")
		"set_procurement_quantity":
			var definition: Dictionary=_ingredient(id)
			var quantity: Variant=args.get("quantity",-1)
			if definition.is_empty() or str(definition.kind)=="rare" or not _finite(quantity) or float(quantity)<0 or float(quantity)!=floorf(float(quantity)) or float(quantity)>100000: return _result(false,"请选择可采购食材与0至100000的整数数量")
			if str(definition.kind)=="shanhai" and not "shanhai" in _data().suppliers: return _result(false,"请先解锁山海供应商")
		_: return _result(false, "未知管理操作：" + action)
	if float(model.state.cash) + 0.000001 < cost: return _result(false, "现金不足，需要 ￥%s" % str(cost), {"cost": cost})
	return _result(true, "", {"cost": cost})

func perform(action: String, args: Dictionary = {}) -> Dictionary:
	if action == "auto_procure": action = "set_auto_procure"
	var allowed: Dictionary = can_perform(action, args)
	if not bool(allowed.ok): return allowed
	var employee: Dictionary = model._employee(_employee_id(args))
	var id: String = str(args.get("id", ""))
	var cost: float = float(allowed.get("cost", 0))
	var result: Dictionary = _result(true, "", {"cost": cost})
	match action:
		"purchase":
			model.change_cash(-cost,"procurement","食材采购："+str(_ingredient(id).get("name",id)))
			add_item(id, float(args.quantity), cost)
			_data().daily_procurement = float(_data().daily_procurement) + cost
			_data().total_procurement = float(_data().total_procurement) + cost
			if model.state.get("stats", null) is Dictionary: model.state.stats.purchases = int(model.state.stats.get("purchases", 0)) + 1
		"discard_stock":
			var record: Dictionary = item(id)
			var quantity: float = float(args.quantity)
			var value: float = float(record.value) * quantity / float(record.quantity)
			record.quantity = maxf(0, float(record.quantity) - quantity)
			record.value = maxf(0, float(record.value) - value)
			result.write_off = value
			var rules: Variant = model.get("full_rules")
			if rules != null and rules.has_method("record"): rules.record("expenses", value, "食材报损")
			_sync_totals()
		"unlock_supplier":
			model.change_cash(-cost,"supplier","解锁山海食材供应商")
			_data().suppliers.append(id)
		"train_attribute", "train_secondary":
			model.change_cash(-cost,"training","员工培训："+str(employee.name))
			_data().daily_development = float(_data().daily_development) + cost
			_suspend(employee)
			var rarity: float = float(_v("rarity_multipliers", str(employee.rarity), 1))
			var duration: float = float(_v("minutes", "training" if action == "train_attribute" else "secondary")) * rarity
			if _has_active("bai_ze"):
				var benefit: float=(1.0-coefficient("training_time_mult"))*(1.0+_synergy_bonus("baize_training_bonus"))
				duration *= 1.0-benefit
			var due: int = _now() + maxi(1, int(ceil(duration)))
			var project: Dictionary = {"type": action, "employee_id": str(employee.id), "due": due, "attribute": str(args.get("attribute", "speed")), "role": str(args.get("role", ""))}
			_data().projects.append(project)
			employee.management_until = due
			employee.management_job_type = action
			result.due = due
		"switch_role":
			_suspend(employee)
			if str(args.role)==str(employee.secondary_role) and str(employee.primary_role) in ["chef","waiter","salesman"]:
				var previous=str(employee.primary_role);employee.primary_role=str(args.role);employee.secondary_role=previous
			employee.role = str(args.role)
		"upgrade_skill":
			if str(args.get("method", "fragments")) == "book": _data().skill_books = int(_data().skill_books) - 1
			else: model.state.fragments[str(employee.id)] = int(model.state.fragments.get(str(employee.id), 0)) - skill_cost(employee)
			employee.skill_level = int(employee.skill_level) + 1
		"raise_wage":
			employee.wage_extra = mini(int(_v("limits", "wage_extra")), int(employee.wage_extra) + int(_v("costs", "raise_step")))
			employee.loyalty = minf(100, float(employee.loyalty) + coefficient("raise_loyalty"))
		"comfort":
			model.change_cash(-cost,"comfort","员工关怀："+str(employee.name))
			employee.mood = minf(100, float(employee.mood) + coefficient("comfort_mood"))
			employee.loyalty = minf(100, float(employee.loyalty) + coefficient("comfort_loyalty"))
		"set_shift":
			employee.shift_periods = args.get("periods", []).duplicate()
			employee.shift_enabled = bool(args.get("enabled", true))
			_apply_shift(employee)
		"research": result = _start_research(args)
		"set_price":
			var dish_id: String = _dish_id(args)
			var price: float = model._money(float(args.price))
			_data().price_overrides[dish_id] = price
			model._dish(dish_id).price = price
		"set_menu":
			var dish_id: String = _dish_id(args)
			if bool(args.get("enabled", true)):
				if not dish_id in model.state.menu_enabled: model.state.menu_enabled.append(dish_id)
			else: model.state.menu_enabled.erase(dish_id)
		"set_auto_procure":
			_data().auto_procure = bool(args.get("enabled", true))
			_data().procurement_strategy = "auto" if bool(_data().auto_procure) else "pause"
		"set_procurement_strategy":
			_data().procurement_strategy=str(args.strategy)
			_data().auto_procure=str(args.strategy)!="pause"
		"set_procurement_quantity": _data().fixed_quantities[id]=int(args.quantity)
	model.changed.emit()
	return result

func _suspend(employee: Dictionary) -> void:
	if model.state.has("revision191"):model.full_rules.dollhouse.release_aux(str(employee.id))
	var assigned: Array = []
	for customer in model.customers:
		if str(customer.get("worker", "")) == str(employee.id): assigned.append(customer)
	for customer in assigned:
		customer.remaining_minutes = maxi(1, int(customer.due_minute) - _now())
		if customer.get("task_motion") is Dictionary:
			var motion: Dictionary = customer.task_motion
			var worked: float = maxf(0, float(_now()) - float(motion.started) - float(motion.travel_minutes))
			customer.remaining_minutes = maxi(1, int(ceil(maxf(0, float(motion.work_minutes) - worked))))
		model._release_customer(customer)
		customer.worker = ""
		customer.due_minute = -1
	employee.busy_customer = 0
	employee.busy_until = 0
	if employee.get("motion") is Dictionary and model.has_method("motion_position"):
		var position: Vector2 = model.motion_position(employee)
		var point: Dictionary = {"x": position.x, "y": position.y}
		employee.motion = {"origin":point,"target":point.duplicate(),"path":[],"started":_now(),"speed":0.0,"travel_minutes":0.0,"work_minutes":0.0,"action":"Idle","blocked":false}

func _has_active(id: String) -> bool:
	return _active(model._employee(id))

func _research_bond_bonus() -> float:
	var rules: Variant = model.get("full_rules")
	if rules != null and rules.get("world") != null and rules.world.has_method("probability_bonus"):
		return float(rules.world.probability_bonus("research_success"))
	return coefficient("research_bond_bonus") if int(model.state.stage) >= 2 and _has_active("hun_dun") and _has_active("di_jiang") else 0.0

func _start_research(args: Dictionary) -> Dictionary:
	var employee: Dictionary = _researcher(args)
	var dish_id: String = _dish_id(args)
	var tutorial: bool = bool(args.get("tutorial", false))
	var cost: float = 0 if tutorial else float(_v("costs", "research_cash"))
	model.change_cash(-cost,"research","菜品研发："+str(model._dish(dish_id).name))
	_data().daily_development = float(_data().daily_development) + cost
	if not tutorial: _consume_generic(float(_v("costs", "research_generic")))
	else: _data().tutorial_trial_available = false
	var duration: float = float(_v("minutes", "research"))
	var hundun: bool = str(employee.id) == "hun_dun"
	if hundun: duration *= 1 + coefficient("research_hundun_time")
	var baize: bool = _has_active("bai_ze") or str(employee.id) == "bai_ze"
	var bond_success_bonus: float = _research_bond_bonus()+_synergy_bonus("research_success")
	var bond_bonus: bool = not is_zero_approx(bond_success_bonus)
	_suspend(employee)
	var due: int = _now() + maxi(1, int(ceil(duration)))
	var project: Dictionary = {"type": "research", "employee_id": str(employee.id), "dish_id": dish_id, "due": due, "guaranteed": tutorial or (baize and _synergy_bonus("baize_research_bonus")>=0), "tutorial": tutorial, "bai_ze": baize, "hun_dun": hundun, "bond_bonus": bond_bonus, "bond_success_bonus": bond_success_bonus}
	_data().projects.append(project)
	employee.management_until = due
	employee.management_job_type = "research"
	model._notify("开始研发 %s，主持员工在此期间暂停工作" % str(model._dish(dish_id).name))
	return _result(true, "", {"cost": cost, "due": due, "employee_id": str(employee.id)})

func tick_minute() -> void:
	for employee in model.employees:
		_ensure_employee(employee)
		_apply_shift(employee)
	var ready: Array = []
	for project in _data().get("projects", []):
		if int(project.due) <= _now(): ready.append(project)
	for project in ready:
		_finish_project(project)
		_data().projects.erase(project)
	settle_pending_departures()

func _has_unfinished_project(employee: Dictionary) -> bool:
	for field in ["training_until", "research_until", "management_until", "expansion_until", "leave_until", "construction_until", "v18_clean_until"]:
		if int(employee.get(field, 0)) > _now(): return true
	# A due project still exists until its completion code removes its reference.
	for project in _data().get("projects", []):
		if str(project.get("employee_id", "")) == str(employee.id): return true
	if str(employee.get("expansion_job_id", "")) != "": return true
	return false

func _depart_employee(employee: Dictionary) -> void:
	_suspend(employee)
	_data().departed.append({"id": str(employee.id), "day": int(_now() / int(_v("minutes", "day")))})
	model.employees.erase(employee)
	model._notify(str(employee.name) + "因长期情绪低落离职，可通过招募再次邀请")

func settle_pending_departures() -> void:
	var ready: Array = []
	for employee in model.employees:
		if bool(employee.get("pending_resignation", false)) and not _has_unfinished_project(employee): ready.append(employee)
	for employee in ready: _depart_employee(employee)

func _apply_shift(employee: Dictionary) -> void:
	if not bool(employee.get("shift_enabled", false)) or not _available(employee): return
	var should_work: bool = model.period() in employee.get("shift_periods", [])
	if should_work and float(employee.stamina) <= 0: return
	if should_work == not bool(employee.get("resting", false)): return
	# Saving the instruction already rolls refusal in FullRules.perform. Later
	# timetable transitions execute that saved plan without a second random roll.
	model.set_employee_rest(str(employee.id), not should_work, false)

func _finish_project(project: Dictionary) -> void:
	var employee: Dictionary = model._employee(str(project.employee_id))
	if employee.is_empty(): return
	employee.management_until = 0
	employee.management_job_type = ""
	match str(project.type):
		"train_secondary":
			employee.secondary_role = str(project.role)
			model._notify(str(employee.name) + "完成副职业培训，可切换岗位")
		"train_attribute":
			var attribute: String = str(project.attribute)
			var experience: int = int(employee.training_experience_by_attribute.get(attribute, 0))
			var chance: float = minf(coefficient("training_cap"), coefficient("training_success") + float(employee.attributes.get("creativity", 0)) * coefficient("training_creativity") + experience * coefficient("training_experience"))
			if experience >= int(_v("guarantees", "training_failures")) or model._rng.randf() < chance:
				employee.attributes[attribute] = minf(float(_v("limits", "attribute")), float(employee.attributes.get(attribute, 0)) + 1)
				if model.has_method("initialize_employee_motion"): model.initialize_employee_motion(employee, true)
				employee.training_history[attribute] = int(employee.training_history.get(attribute, 0)) + 1
				if model.state.has("revision171"): employee.level=mini(model.full_rules.revision.level_cap(employee),int(employee.get("level",1))+1)
				model._notify(str(employee.name) + "训练成功：" + attribute + "+1")
			else:
				employee.training_experience_by_attribute[attribute] = experience + 1
				employee.training_experience = int(employee.get("training_experience", 0)) + 1
				model._notify(str(employee.name) + "训练未成功，积累经验")
		"research": _finish_research(project, employee)

func _finish_research(project: Dictionary, employee: Dictionary) -> void:
	var id: String = str(project.dish_id)
	var experience: int = int(model.state.get("research_experience", {}).get(id, 0))
	var chance: float = research_chance(employee, experience, bool(project.get("hun_dun", false)), float(project.get("bond_success_bonus", coefficient("research_bond_bonus"))) if bool(project.get("bond_bonus", false)) else 0.0)
	if bool(project.get("bai_ze",false)) and not bool(project.get("guaranteed",false)):
		chance=clampf(chance+(1.0-chance)*(1.0+_synergy_bonus("baize_research_bonus")),0,1)
	var success: bool = bool(project.get("guaranteed", false)) or experience >= int(_v("guarantees", "research_failures")) or model._rng.randf() < chance
	if success:
		if not id in model.state.unlocked_dishes: model.state.unlocked_dishes.append(id)
		if not id in model.state.menu_enabled: model.state.menu_enabled.append(id)
		model.state.stats.research_success = int(model.state.stats.get("research_success", 0)) + 1
		if bool(project.get("tutorial", false)): model.state.tutorial_researched = true
		if id == "hundun_wonton":
			var choices: Array = config.get("hidden_effect_choices", [])
			_data().hidden_effects[id] = choices[model._rng.randi_range(0, choices.size() - 1)] if not choices.is_empty() else "quality_mult"
		if bool(project.get("bai_ze", false)) and model._rng.randf() < hidden_recipe_chance(employee):
			_data().hidden_unlocked = true
			_ensure_hidden_dish()
		model._notify("研发成功！" + str(model._dish(id).name))
	else:
		model.state.research_experience[id] = experience + 1
		model._notify("研发未成功，保留经验；下一次成功率提高")
	var rules: Variant = model.get("full_rules")
	if rules != null and rules.get("world") != null and rules.world.has_method("on_hook"):
		rules.world.on_hook("research", {"employee_id": str(employee.id), "dish_id": id, "success": success})

func research_chance(employee: Dictionary, experience: int = 0, hundun: bool = false, bond_success_bonus: float = 0) -> float:
	# Section 4.2 requires both cooking and creativity to improve research.
	# Its unspecified cooking weight is exposed as 1 percentage point per point.
	var attributes: Dictionary = employee.get("attributes", {})
	var chance: float = coefficient("research_success") + float(attributes.get("creativity", 0)) * coefficient("research_creativity") + float(attributes.get("cooking", 0)) * coefficient("research_cooking") + experience * coefficient("research_experience")
	if hundun: chance += coefficient("dev_success_bonus") * skill_multiplier(employee)
	return clampf(chance + bond_success_bonus, 0, coefficient("research_cap"))

func hidden_recipe_chance(employee: Dictionary) -> float:
	# The design specifies that creativity affects this chance but supplies no
	# numeric factor. Expose the added 1 percentage point/creativity coefficient
	# in the developer balance settings, alongside Baize's 10% base chance.
	return clampf((coefficient("hidden_chance") + float(employee.get("attributes", {}).get("creativity", 0)) * coefficient("hidden_creativity"))*(1.0+_synergy_bonus("baize_research_bonus"))+_synergy_bonus("hidden_recipe"), 0, 1)

func discover_hidden_recipe() -> bool:
	if bool(_data().get("hidden_unlocked", false)): return false
	_data().hidden_unlocked = true
	_ensure_hidden_dish()
	return true

func _ensure_hidden_dish() -> void:
	var definition: Dictionary = config.get("hidden_recipe", {}).duplicate(true)
	if definition.is_empty(): return
	var id: String = str(definition.id)
	var present: bool = false
	for dish in model.dishes:
		if str(dish.id) == id: present = true
	if not present:
		definition.unlocked = false
		model.dishes.append(definition)
	if not model.state.unlocked_dishes.has(id): model.state.unlocked_dishes.append(id)
	if not model.state.menu_enabled.has(id): model.state.menu_enabled.append(id)
	if not _data().base_prices.has(id): _data().base_prices[id] = float(definition.price)

func unlock_supplier(id: String = "shanhai", free: bool = true) -> Dictionary:
	if not free: return perform("unlock_supplier", {"id": id})
	if id != "shanhai": return _result(false, "未知供应商")
	if not id in _data().suppliers: _data().suppliers.append(id)
	return _result(true)

func add_skill_books(quantity: int) -> bool:
	if quantity <= 0: return false
	_data().skill_books = int(_data().skill_books) + quantity
	return true

func _synergy_bonus(effect: String) -> float:
	var rules: Variant=model.get("full_rules")
	if rules!=null and rules.get("synergies")!=null: return float(rules.synergies.bonus(effect))
	return 0.0

func procurement_snapshot() -> Dictionary:
	var rows: Array=[]
	for definition in ingredients:
		if str(definition.kind)=="rare": continue
		var id: String=str(definition.id)
		var record: Dictionary=item(id)
		var history: Array=record.history.duplicate()
		history.append(float(record.consumption_today))
		while history.size()>int(_v("limits","history_days")): history.pop_front()
		var total: float=0.0
		for used in history: total+=float(used)
		var auto_quantity: int=int(ceil(total/maxi(1,history.size())*coefficient("auto_procure")))
		var fixed: int=int(_data().fixed_quantities.get(id,0))
		var requested: int=auto_quantity if str(_data().procurement_strategy)=="auto" and str(definition.kind)=="ordinary" else (fixed if str(_data().procurement_strategy)=="fixed" else 0)
		var unlocked: bool=str(definition.kind)!="shanhai" or "shanhai" in _data().suppliers
		if not unlocked: requested=0
		rows.append({"id":id,"name":str(definition.name),"kind":str(definition.kind),"stock":float(record.quantity),"auto_quantity":auto_quantity,"fixed_quantity":fixed,"requested":requested,"unit_price":stock_price(id),"estimated_cost":model._money(requested*stock_price(id)),"unlocked":unlocked})
	return {"strategy":str(_data().procurement_strategy),"fixed_quantities":_data().fixed_quantities.duplicate(true),"rows":rows,"prepared_day":int(_data().procurement_prepared_day)}

func prepare_day_procurement(day: int = -1) -> Dictionary:
	ensure_state()
	if day<0: day=maxi(1,_now()/int(_v("minutes","day")))
	if int(_data().procurement_prepared_day)>=day: return {"day":day,"duplicate":true,"purchases":_data().pending_auto_purchases.duplicate(true),"cost":0.0}
	_data().procurement_prepared_day=day
	_data().pending_auto_purchases=[]
	var cost: float=0.0
	var planned: Dictionary=procurement_snapshot()
	for row in planned.rows:
		var price: float=float(row.unit_price)
		var quantity: int=mini(int(row.requested),maxi(0,int(floor(float(model.state.cash)/price)))) if price>0 else int(row.requested)
		if quantity<=0: continue
		var paid: Dictionary=purchase(str(row.id),quantity)
		if paid.ok:
			cost+=float(paid.cost)
			_data().pending_auto_purchases.append({"id":str(row.id),"quantity":quantity,"cost":float(paid.cost)})
			var rules: Variant = model.get("full_rules")
			if rules != null and rules.has_method("record"): rules.record("procurement",float(paid.cost),"日结前食材备货")
	return {"day":day,"duplicate":false,"purchases":_data().pending_auto_purchases.duplicate(true),"cost":model._money(cost)}

func on_day() -> void:
	var report: Dictionary = {"cogs":float(_data().daily_cogs),"procurement":float(_data().daily_procurement),"development":float(_data().daily_development),"inventory_value":inventory_value(),"auto_purchases":_data().pending_auto_purchases.duplicate(true),"departures":[]}
	for definition in ingredients:
		var record: Dictionary=item(str(definition.id))
		var freshness_mult: float=1.0+_synergy_bonus("aquatic_freshness") if str(definition.id) in ["seafood","shan_hai_fish"] else 1.0
		record.freshness=maxf(0,float(record.freshness)-coefficient("freshness_"+str(definition.kind))*freshness_mult)
		record.history.append(float(record.consumption_today))
		while record.history.size()>int(_v("limits","history_days")): record.history.pop_front()
		record.consumption_today=0.0
	# Staff with poor morale receive the documented daily retention roll.
	var leaving: Array = []
	for employee in model.employees:
		if bool(employee.get("pending_resignation", false)):
			if not _has_unfinished_project(employee): leaving.append(employee)
			continue
		if float(employee.get("mood", 100)) > float(_v("thresholds", "quit_mood")): continue
		var probability: float = coefficient("quit_loyal_chance") if float(employee.loyalty) >= float(_v("thresholds", "loyalty_high")) else coefficient("quit_chance")
		if float(employee.get("affinity",0))>=80: probability*=0.5
		if model._rng.randf() < probability:
			if _has_unfinished_project(employee):
				employee.pending_resignation = true
				model._notify(str(employee.name) + "提出离职，将在当前项目结束后完成交接")
			else: leaving.append(employee)
	for employee in leaving:
		report.departures.append(str(employee.id))
		_depart_employee(employee)
	report.procurement = float(_data().daily_procurement)
	report.inventory_value = inventory_value()
	_data().last_day = report
	_data().pending_auto_purchases=[]
	_data().daily_cogs = 0.0
	_data().daily_procurement = 0.0
	_data().daily_development = 0.0
	_sync_totals()

func skill_multiplier(employee: Dictionary) -> float:
	return 1 + maxi(0, int(employee.get("skill_level", 1)) - 1) * coefficient("skill_level_step")

func employee_effects(employee: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	if employee.is_empty(): return result
	var level: float = skill_multiplier(employee)
	match str(employee.id):
		"guan_guan": result = {"promotion_bonus": coefficient("guanguan_promotion") * level, "mood_bonus": coefficient("guanguan_mood")}
		"e_shou": result = {"promotion_bonus": coefficient("eshou_promotion") * level}
		"ran_yi_yu": result = {"extra_income_chance": coefficient("ranyiyu_income_chance") * level, "extra_income_bonus": coefficient("ranyiyu_income_bonus") * level}
		"tian_gou": result = {"prevent_escape_chance": coefficient("tiangou_prevent_escape") * level}
		"gu_diao": result = {"special_customer_bonus": coefficient("gudiao_special") * level, "human_loss_chance": coefficient("gudiao_human_loss")}
		"ying_zhao": result = {"traffic_bonus": coefficient("yingzhao_flow") * level, "mood_bonus": coefficient("yingzhao_mood") * level}
		"lu_wu": result = {"barbecue_speed": coefficient("luwu_speed") * level}
		"jing_wei": result = {"clean_speed": coefficient("jingwei_clean") * level, "mood_cost_bonus": coefficient("jingwei_mood_cost")}
		"qiong_qi": result = {"spicy_price_bonus": coefficient("qiongqi_price") * level}
		"tao_wu": result = {"promotion_bonus": coefficient("taowu_promotion") * level}
		"hun_dun": result = {"research_bonus": coefficient("dev_success_bonus") * level}
		"xie_zhi": result = {"complaint_success_bonus": coefficient("xiezhi_complaint_success") * level}
		"ying_long": result = {"seafood_quality_bonus": coefficient("yinglong_quality") * level, "rain_traffic_bonus": coefficient("yinglong_rain_flow") * level}
		"di_jiang": result = {"mood_bonus": coefficient("yingzhao_mood") * level}
		"jiu_ying": result = {"batch_size": int(coefficient("jiuying_batch"))}
	if result.has("promotion_bonus"): result.promotion_mult = 1 + float(result.promotion_bonus)
	return result

func _best_bonus(sources: Dictionary) -> float:
	var positive: float=0.0
	var negative: float=0.0
	for value in sources.values():
		positive=maxf(positive,float(value))
		negative=minf(negative,float(value))
	return positive+negative

func modifiers(dish_id: String, employee: Dictionary = {}) -> Dictionary:
	var result: Dictionary = {"quality_sources":{},"cook_speed_sources":{},"quality_mult": 1.0, "price_mult": 1.0, "cook_speed": 1.0, "eat_mult": 1.0, "serve_mult": 1.0, "patience_mult": 1.0, "traffic_mult": 1.0, "ingredient_mult": 1.0, "complaint_mult": 1.0, "promotion_mult": 1.0, "review_bonus": 0.0, "tip_bonus": 0.0, "repeat_chance": 0.0, "first_good_review": false, "guaranteed_good_review": false, "batch_size": 1, "mood_bonus": 0.0, "warmth_bonus": 0.0, "regular_bonus": 0.0, "conflict_chance": 0.0}
	var base_price: float = float(_data().base_prices.get(dish_id, model._dish(dish_id).get("price", 1)))
	result.price_setting = float(model._dish(dish_id).get("price", 1)) / base_price if base_price > 0 else 1
	var effects: Dictionary = config.get("dish_effects", {}).get(dish_id, {})
	for stat in effects:
		if effects[stat] is bool:
			result[stat] = effects[stat]
			continue
		var value: float = coefficient(str(effects[stat]))
		match stat:
			"patience_bonus": result.patience_mult += value
			"ingredient_reduction": result.ingredient_mult -= value
			"complaint_reduction": result.complaint_mult -= value
			"promotion_bonus": result.promotion_mult += value
			_: result[stat] = value
	var world: Dictionary = model.state.get("world", {})
	var weather: String = str(world.get("weather", model.state.get("weather", "clear")))
	var season: String = str(world.get("season", model.state.get("season", "spring")))
	if dish_id == "qianyang_soup" and (season == "winter" or weather == "snow"): result.traffic_mult += coefficient("winter_soup_demand")
	if dish_id == "yinglong_hotpot" and weather == "rain": result.traffic_mult += coefficient("rain_hotpot_demand")
	if dish_id == "tiangou_tempura" and model.period() == "night_market": result.traffic_mult += coefficient("night_tempura_demand")
	if quality_freshness(dish_id) < float(_v("thresholds", "freshness")): result.quality_sources.freshness=-coefficient("freshness_penalty")
	if _data().get("hidden_effects", {}).has(dish_id):
		var hidden: String = str(_data().hidden_effects[dish_id])
		var coefficient_id: String = {"quality_mult": "hidden_quality", "price_mult": "hidden_choice_price", "cook_speed": "hidden_choice_speed"}.get(hidden, "hidden_quality")
		if hidden=="quality_mult": result.quality_sources.hidden=coefficient(coefficient_id)
		elif hidden=="cook_speed": result.cook_speed_sources.hidden=coefficient(coefficient_id)
		else: result[hidden] = float(result.get(hidden, 1)) + coefficient(coefficient_id)
	if dish_id == str(config.get("hidden_recipe", {}).get("id", "")):
		result.quality_sources.signaturehidden=coefficient("hidden_quality")
		result.review_bonus += coefficient("phoenix_review")
	if not employee.is_empty():
		var extra: Dictionary = employee_effects(employee)
		var category: String = str(model._dish(dish_id).get("category", ""))
		if category == "烧烤": result.cook_speed_sources.seafoodskill=float(extra.get("barbecue_speed",0))
		if dish_id == "qiongqi_hotpot": result.price_mult += float(extra.get("spicy_price_bonus", 0))
		if category == "水产": result.quality_sources.seafoodskill=float(extra.get("seafood_quality_bonus",0))
		if extra.has("batch_size"): result.batch_size = maxi(int(result.batch_size), int(extra.batch_size))
		if extra.has("serve_mult"): result.serve_mult *= float(extra.serve_mult)
	result.quality_mult=1.0+_best_bonus(result.quality_sources)
	if absf(float(result.cook_speed)-1.0)>0.000001: result.cook_speed_sources.dish=float(result.cook_speed)-1.0
	result.cook_speed=1.0+_best_bonus(result.cook_speed_sources)
	return result

func snapshot() -> Dictionary:
	var employees: Array = []
	var researchers: Array = []
	for employee in model.employees:
		_ensure_employee(employee)
		var row: Dictionary = employee.duplicate(true)
		row.fragments = int(model.state.get("fragments", {}).get(str(employee.id), 0))
		row.skill_cost = skill_cost(employee)
		row.skill_books = int(_data().skill_books)
		row.available = _available(employee)
		row.busy_until = maxi(int(employee.get("management_until", 0)), maxi(int(employee.get("research_until", 0)), int(employee.get("expansion_until", 0))))
		row.training_costs = {}
		for attribute in config.get("attributes", []): row.training_costs[attribute] = training_cost(employee, attribute)
		employees.append(row)
		if _active(employee) and str(employee.role) in ["chef", "all", "tutor"]:
			researchers.append({"id": str(employee.id), "name": str(employee.name), "role": str(employee.role), "attributes": employee.attributes.duplicate(true), "success_chance": research_chance(employee, 0, str(employee.id) == "hun_dun", _research_bond_bonus()), "guaranteed": _has_active("bai_ze")})
	var research: Array = []
	for dish in model.dishes:
		var id: String = str(dish.id)
		var allowed: Dictionary = can_perform("research", {"id": id})
		var recipe_rows: Array = []
		for ingredient_id in recipe(id):
			recipe_rows.append({"id": ingredient_id, "name": str(_ingredient(ingredient_id).get("name", ingredient_id)), "quantity": recipe(id)[ingredient_id], "owned": float(item(ingredient_id).get("quantity", 0))})
		var active: bool = false
		for project in _data().projects:
			if str(project.get("dish_id", "")) == id: active = true
		research.append({"id": id, "name": str(dish.name), "required_employee": str(dish.get("required_employee", "")), "owned": str(dish.get("required_employee", "")) == "" or not model._employee(str(dish.required_employee)).is_empty(), "unlocked": id in model.state.unlocked_dishes, "active": active, "in_menu": id in model.state.menu_enabled, "price": float(dish.price), "base_price": float(_data().base_prices.get(id, dish.price)), "cost": float(dish.cost), "recipe": recipe_rows, "can_research": allowed.ok, "reason": allowed.reason, "research_cash": float(_v("costs", "research_cash")), "research_ingredients": float(_v("costs", "research_generic")), "can_make": can_make(id), "freshness": quality_freshness(id)})
	var supplier: Dictionary = can_perform("unlock_supplier", {"id": "shanhai"})
	return {"stock": stock_snapshot(), "employees": employees, "researchers": researchers, "research": research, "projects": _data().projects.duplicate(true), "suppliers": [{"id": "shanhai", "name": "山海食材供应商", "unlocked": "shanhai" in _data().suppliers, "cost": float(_v("costs", "supplier")), "can_unlock": supplier.ok, "reason": supplier.reason}], "skill_books": int(_data().skill_books), "auto_procure": bool(_data().auto_procure), "procurement":procurement_snapshot(), "inventory_value": inventory_value(), "daily_cogs": float(_data().daily_cogs), "last_day": _data().last_day.duplicate(true), "tutorial_trial_available": bool(_data().tutorial_trial_available), "attributes": config.get("attributes", []), "roles": config.get("roles", []), "periods": config.get("periods", [])}

func _finite(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _integer(value: Variant, minimum: int = 0) -> bool:
	return _finite(value) and float(value) >= minimum and float(value) == floorf(float(value))

func validate_state(saved: Dictionary, saved_employees: Array, saved_time: int) -> bool:
	# Validate only the candidate payload. Never consult live inventory or mutate it.
	for key in ["items", "base_prices", "price_overrides", "hidden_effects", "last_day"]:
		if not saved.get(key) is Dictionary: return false
	for key in ["projects", "suppliers", "departed"]:
		if not saved.get(key) is Array: return false
	for key in ["auto_procure", "tutorial_trial_available"]:
		if not saved.get(key) is bool: return false
	if not str(saved.get("procurement_strategy","")) in ["auto","fixed","pause"] or not saved.get("fixed_quantities") is Dictionary: return false
	if not _integer(saved.get("procurement_prepared_day")) or int(saved.procurement_prepared_day)>saved_time/int(_v("minutes","day")): return false
	if not saved.get("pending_auto_purchases") is Array: return false
	for id in saved.fixed_quantities:
		if _ingredient(str(id)).is_empty() or str(_ingredient(str(id)).kind)=="rare" or not _integer(saved.fixed_quantities[id]) or int(saved.fixed_quantities[id])>100000: return false
	for entry in saved.pending_auto_purchases:
		if not entry is Dictionary or _ingredient(str(entry.get("id",""))).is_empty() or not _integer(entry.get("quantity"),1) or not _finite(entry.get("cost")) or float(entry.cost)<0: return false
	if not _integer(saved.get("skill_books")) or not _integer(saved.get("version"), 1): return false
	if int(saved.version) != 1: return false
	for key in ["daily_cogs", "total_cogs", "daily_procurement", "total_procurement", "daily_development"]:
		if not _finite(saved.get(key)) or float(saved[key]) < 0: return false
	if saved.has("hidden_unlocked") and not saved.hidden_unlocked is bool: return false
	var ingredient_ids: Array = []
	for definition in ingredients: ingredient_ids.append(str(definition.id))
	if saved.items.size() != ingredient_ids.size(): return false
	for id in saved.items:
		if not id in ingredient_ids or not saved.items[id] is Dictionary: return false
		var record: Dictionary = saved.items[id]
		for key in ["quantity", "freshness", "value", "consumption_today"]:
			if not _finite(record.get(key)) or float(record[key]) < 0: return false
		if float(record.freshness) > 100: return false
		if is_zero_approx(float(record.quantity)) and float(record.value) > 0.00001: return false
		if not record.get("history") is Array or record.history.size() > int(_v("limits", "history_days")): return false
		for consumed in record.history:
			if not _finite(consumed) or float(consumed) < 0: return false
	if saved.suppliers.size() > 1: return false
	for supplier in saved.suppliers:
		if not supplier is String or supplier != "shanhai": return false
	var dish_definitions: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/dishes.json"))
	if not dish_definitions is Array: return false
	var prices: Dictionary = {}
	for dish in dish_definitions: prices[str(dish.id)] = float(dish.price)
	var sidequest_config: Variant=JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"))
	if sidequest_config is Dictionary:
		for dish in sidequest_config.get("hidden_recipes",[]): prices[str(dish.id)]=float(dish.price)
	var hidden_id: String = str(config.get("hidden_recipe", {}).get("id", ""))
	if bool(saved.get("hidden_unlocked", false)): prices[hidden_id] = float(config.hidden_recipe.price)
	for id in saved.base_prices:
		if not id in prices or not _finite(saved.base_prices[id]) or not is_equal_approx(float(saved.base_prices[id]), float(prices[id])): return false
	for id in saved.price_overrides:
		if not id in prices or not _finite(saved.price_overrides[id]): return false
		if float(saved.price_overrides[id]) < float(prices[id]) * float(_v("limits", "price_min")) or float(saved.price_overrides[id]) > float(prices[id]) * float(_v("limits", "price_max")): return false
	for id in saved.hidden_effects:
		if id != "hundun_wonton" or not saved.hidden_effects[id] is String or not saved.hidden_effects[id] in config.get("hidden_effect_choices", []): return false
	var employee_ids: Dictionary = {}
	var catalog_ids: Array = []
	for definition in model.catalog: catalog_ids.append(str(definition.id))
	for employee in saved_employees:
		if not employee is Dictionary: return false
		var id: String = str(employee.get("id", ""))
		if not id in catalog_ids or employee_ids.has(id): return false
		employee_ids[id] = employee
		if not employee.get("primary_role") is String or not employee.primary_role in config.get("roles", []) + ["all"]: return false
		if not employee.get("secondary_role") is String or not employee.secondary_role in config.get("roles", []) + [""]: return false
		if employee.secondary_role != "" and employee.secondary_role == employee.primary_role: return false
		if str(employee.primary_role) != "all" and not str(employee.get("role", "")) in [str(employee.primary_role), str(employee.secondary_role)]: return false
		if not _integer(employee.get("skill_level"), 1) or int(employee.skill_level) > int(_v("limits", "skill_level")): return false
		if not _integer(employee.get("wage_extra")) or int(employee.wage_extra) > int(_v("limits", "wage_extra")): return false
		if int(employee.wage_extra) % maxi(1, int(_v("costs", "raise_step"))) != 0: return false
		if not _integer(employee.get("management_until")) or not employee.get("management_job_type") is String: return false
		if employee.has("pending_resignation") and not employee.pending_resignation is bool: return false
		if not employee.get("shift_enabled") is bool or not employee.get("shift_periods") is Array: return false
		var periods: Array = []
		for period in employee.shift_periods:
			if not period is String or not period in config.get("periods", []) or period in periods: return false
			periods.append(period)
		for dictionary in [employee.get("training_history"), employee.get("training_experience_by_attribute")]:
			if not dictionary is Dictionary: return false
			for attribute in dictionary:
				if not attribute in config.get("attributes", []) or not _integer(dictionary[attribute]): return false
	var project_employees: Dictionary = {}
	var project_dishes: Array = []
	for project in saved.projects:
		if not project is Dictionary: return false
		var id: String = str(project.get("employee_id", ""))
		var type: String = str(project.get("type", ""))
		if not id in employee_ids or project_employees.has(id) or not type in ["train_attribute", "train_secondary", "research"]: return false
		if not _integer(project.get("due")) or int(project.due) <= saved_time: return false
		var employee: Dictionary = employee_ids[id]
		if int(employee.management_until) != int(project.due) or str(employee.management_job_type) != type: return false
		if str(employee.get("branch_id", "")) != "" or int(employee.get("busy_customer", 0)) != 0: return false
		for field in ["training_until", "research_until", "expansion_until"]:
			if int(employee.get(field, 0)) > saved_time: return false
		if type == "train_attribute" and not project.get("attribute", "") in config.get("attributes", []): return false
		if type == "train_secondary" and not project.get("role", "") in config.get("roles", []): return false
		if type == "research":
			if not str(employee.get("role", "")) in ["chef", "all", "tutor"]: return false
			var dish_id: String = str(project.get("dish_id", ""))
			if not dish_id in prices or dish_id in project_dishes: return false
			for flag in ["guaranteed", "tutorial", "bai_ze", "hun_dun", "bond_bonus"]:
				if not project.get(flag) is bool: return false
			if bool(project.tutorial) and (dish_id != "qianyang_soup" or not bool(project.guaranteed) or bool(saved.tutorial_trial_available)): return false
			if project.has("bond_success_bonus") and (not _finite(project.bond_success_bonus) or float(project.bond_success_bonus) < 0 or float(project.bond_success_bonus) > 1): return false
			project_dishes.append(dish_id)
		project_employees[id] = true
	for id in employee_ids:
		var employee: Dictionary = employee_ids[id]
		if not project_employees.has(id) and (int(employee.management_until) != 0 or str(employee.management_job_type) != ""): return false
	for departure in saved.departed:
		if not departure is Dictionary or not str(departure.get("id", "")) in catalog_ids or not _integer(departure.get("day")): return false
	return true

func balance_defaults() -> Dictionary:
	var result: Dictionary = {}
	for group in config:
		# Only expose numeric fields that the rules actually resolve through _v().
		if not group in ["coefficients", "rarity_multipliers", "limits", "costs", "minutes", "thresholds", "guarantees", "initial"]: continue
		if not config[group] is Dictionary: continue
		for key in config[group]:
			var value: Variant = config[group][key]
			if value is int or value is float:
				result[("coeff." + str(key)) if group == "coefficients" else ("management.%s.%s" % [group, key])] = value
	for definition in ingredients: result["management.ingredients.%s.price" % str(definition.id)] = float(definition.price)
	for id in _canonical_quality: result["dish.%s.quality" % id] = _canonical_quality[id]
	return result

func validate_balance(candidate: Dictionary) -> bool:
	# Validate proposed values against module defaults, never the live model's
	# existing overrides. A failed hot edit therefore cannot modify game state.
	var defaults: Dictionary = balance_defaults()
	var values: Dictionary = defaults.duplicate(true)
	for key in candidate:
		if not key is String: return false
		if defaults.has(key):
			if not _finite(candidate[key]): return false
			values[key] = candidate[key]
		elif str(key).begins_with("management.") or (str(key).begins_with("dish.") and str(key).ends_with(".quality")):
			return false
	for key in values:
		var value: float = float(values[key])
		if not is_finite(value): return false
		if key == "coeff.guanguan_mood":
			if value < -100 or value > 100: return false
		elif value < 0: return false
		if str(key).begins_with("management.ingredients.") and value <= 0: return false
		if str(key).begins_with("management.rarity_multipliers.") and value <= 0: return false
		if str(key).begins_with("dish.") and str(key).ends_with(".quality") and value > 100: return false
	for group in ["minutes", "guarantees"]:
		for key in config.get(group, {}):
			var minimum: int = 1 if group == "minutes" else 0
			var value: Variant = values.get("management.%s.%s" % [group, key])
			if not _integer(value, minimum) or float(value) > 2147483647: return false
	for key in ["attribute", "skill_level", "wage_extra", "history_days"]:
		var minimum: int = 0 if key == "wage_extra" else 1
		var value: Variant = values.get("management.limits." + key)
		if not _integer(value, minimum) or float(value) > 2147483647: return false
	# Fragment costs use 2^(level-1), so preserve an exact, representable range.
	if float(values["management.limits.skill_level"]) > 32: return false
	if not _integer(values.get("management.costs.raise_step"), 1): return false
	if float(values["management.costs.raise_step"]) > 2147483647: return false
	if int(values["management.limits.wage_extra"]) % int(values["management.costs.raise_step"]) != 0: return false
	if not _integer(values.get("management.initial.skill_books")) or float(values["management.initial.skill_books"]) > 2147483647: return false
	if float(values["management.limits.price_min"]) <= 0 or float(values["management.limits.price_max"]) < float(values["management.limits.price_min"]): return false
	if float(values["management.minutes.day"]) != 24 * float(values["management.minutes.minutes_per_hour"]): return false
	for key in ["freshness", "quit_mood", "loyalty_high"]:
		if float(values["management.thresholds." + key]) > 100: return false
	for key in ["research_stage", "supplier_stage", "skill_stage", "pricing_stage"]:
		var value: Variant = values.get("management.thresholds." + key)
		if not _integer(value) or float(value) > 4: return false
	for key in ["training_success", "training_creativity", "training_experience", "training_cap", "research_success", "research_creativity", "research_cooking", "research_experience", "research_cap", "dev_success_bonus", "research_bond_bonus", "hidden_chance", "hidden_creativity", "quit_chance", "quit_loyal_chance", "freshness_penalty", "milk_tip", "salad_complaints", "rice_cost", "fish_repeat", "spicy_conflict", "xiezhi_complaints", "xiezhi_regulars", "ranyiyu_income_chance", "gudiao_special", "gudiao_human_loss", "tiangou_prevent_escape", "xiezhi_complaint_success"]:
		if float(values["coeff." + key]) > 1: return false
	if float(values["coeff.buffet_turnover"]) <= 0: return false
	if float(values["coeff.training_time_mult"]) <= 0 or float(values["coeff.training_time_mult"]) > 1: return false
	if not _integer(values["coeff.jiuying_batch"], 1) or float(values["coeff.jiuying_batch"]) > 512: return false
	return true
