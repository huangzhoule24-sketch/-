extends RefCounted
## Real equipment reservations derive from orders; no parallel cosmetic scheduler.
const Space=preload("res://scripts/services/restaurant_space.gd")
const Geometry=preload("res://scripts/services/grid_navigation.gd")
const Grid=preload("res://scripts/services/dollhouse_navigation.gd")
var _ref: WeakRef
var fresh_start=false
func _init(host):_ref=weakref(host)
func m():return _ref.get_ref()
func s() -> Dictionary:return m().state.revision191
func now() -> int:return int(m().state.total_minutes)
func enabled() -> bool:return m().state.get("mode")=="full" and m().state.has("revision191")
static func identity(item: Dictionary) -> String:return "%s@%d,%d" % [str(item.id),int(item.x),int(item.y)]
func kind(item: Dictionary) -> String:return str(m().full_rules.decoration(str(item.id)).get("device_type","decoration"))
func fixtures(type: String="",include_building: bool=false) -> Array:
	return m().state.layout.filter(func(item):return (include_building or not bool(item.get("building",false))) and (type.is_empty() or kind(item)==type))
func by_id(id: String) -> Dictionary:
	for item in m().state.layout:
		if identity(item)==id:return item
	return {}
func ensure_state():
	if enabled():return
	if m().state.get("mode")!="full":return
	var is_new=fresh_start;fresh_start=false
	m().state.revision191={"version":1,"grid_width":16 if is_new else 8,"grid_height":5,"cell_width":968.0/(16 if is_new else 8),"aux_jobs":{},"departures":[],"promotion_cycles":0,"legacy_import":not is_new}
	if is_new:
		m().state.layout=[]
		for x in [2,4,6,8]:m().state.layout.append({"id":"table_two","x":x,"y":1,"w":1,"h":1})
	# Install only the baseline architecture, without charging or granting stats.
	for pair in [["stove",2],["basic_pass",1],["basic_cashier",1]]:
		var wanted=str(pair[0]);var count=fixtures(str({"stove":"stove","basic_pass":"pass","basic_cashier":"cashier"}[wanted])).size()
		for index in range(maxi(0,int(pair[1])-count)):_install(wanted,is_new)
	# Existing in-flight orders retain their exact deadline, route and ingredients.
	# Give their old reservations distinct equipment; only new tasks use new paths.
	for customer in m().customers:
		if str(customer.get("worker",""))=="" or int(customer.get("due_minute",-1))<0:continue
		var type=task_kind(str(customer.stage))
		if customer.has("device_uid"):continue
		customer.legacy_equipment_task=true
		var available=fixtures(type).filter(func(item):return not locked(identity(item)))
		if available.is_empty() and type in ["stove","cashier","pass"]:
			_install({"stove":"stove","cashier":"basic_cashier","pass":"basic_pass"}[type],false);available=fixtures(type).filter(func(item):return not locked(identity(item)))
		if not available.is_empty():customer.device_uid=identity(available[0]);customer.legacy_equipment_task=true
func _install(id: String,is_new: bool):
	var preferred={"stove":[Vector2i(11,0),Vector2i(12,0)],"basic_pass":[Vector2i(10,0)],"basic_cashier":[Vector2i(14,1)]}
	var cells: Array=[]
	if is_new:cells.assign(preferred.get(id,[]))
	for y in range(5):
		for x in range(int(s().grid_width)):cells.append(Vector2i(x,y))
	for cell in cells:
		if m().state.layout.any(func(item):return Rect2i(item.x,item.y,item.w,item.h).has_point(cell)):continue
		var item={"id":id,"x":cell.x,"y":cell.y,"w":1,"h":1}
		var candidate: Array=m().state.layout.duplicate(true);candidate.append(item)
		if not is_new and not Space.layout_is_safe(m(),candidate):continue
		m().state.layout.append(item);return
	# A packed legacy floor can grow to the right while keeping its cell size,
	# existing coordinates, seat IDs and in-flight routes unchanged.
	var x=int(s().grid_width);s().grid_width=x+1
	m().state.layout.append({"id":id,"x":x,"y":0,"w":1,"h":1})
func local_available(employee: Dictionary) -> bool:
	return m().full_rules.management._available(employee) and m().full_rules.world._present(str(employee.id))
func roles(employee: Dictionary) -> Array:
	if str(employee.get("role",""))=="tutor":return ["tutor"]
	return [str(employee.get("primary_role",employee.get("role","waiter"))),str(employee.get("secondary_role",""))]
func capable(employee: Dictionary,role: String) -> bool:
	var tags=roles(employee);return role in tags or "all" in tags
func task_kind(task: String) -> String:
	return {"queued":"stove","cooking":"stove","paying":"cashier","serving":"pass","cleaning":"table","ordering":"table","recommending":"table"}.get(task,"")
func locked(id: String,except_employee: String="") -> bool:
	for customer in m().customers:
		if str(customer.get("worker",""))!=except_employee and str(customer.get("device_uid",""))==id and int(customer.get("due_minute",-1))>=0:return true
	for employee_id in s().aux_jobs:
		if employee_id!=except_employee and str(s().aux_jobs[employee_id].device_uid)==id:return true
	return false
func operation_point(item: Dictionary) -> Vector2:
	return Space.interact_point(m(),item) if not item.is_empty() else Vector2(INF,INF)
func table_for(customer: Dictionary) -> Dictionary:
	var seat=int(customer.get("seat",0));var count=0
	for item in fixtures("table"):
		var capacity=4 if str(item.id)=="table_four" else 2
		if seat<count+capacity:return item
		count+=capacity
	return {}
func plan(employee: Dictionary,task: String,customer: Dictionary) -> Dictionary:
	var type=task_kind(task);var choices=fixtures(type)
	if type=="table":
		var table=table_for(customer);choices=[] if table.is_empty() else [table]
	var origin: Vector2=m().motion_position(employee)
	var best: Dictionary={};var distance=INF
	for item in choices:
		var id=identity(item)
		if locked(id,str(employee.id)):continue
		# One worker with several cook jobs still needs a different stove per job.
		if type=="stove" and m().customers.any(func(c):return str(c.get("device_uid",""))==id and int(c.get("due_minute",-1))>=0):continue
		var point=Space.service_point(m(),int(customer.get("seat",0))) if type=="table" else operation_point(item)
		var destination=Space.service_point(m(),int(customer.get("seat",0))) if task=="serving" else point
		var ignores=m().full_rules.effects.ignores_obstacles(employee,m()._dish(str(customer.get("dish_id",""))),task)
		var teleport=str(employee.id)=="di_jiang" and task=="serving"
		var route={"points":[destination],"blocked":false,"length":0.0} if teleport else Space.find_route(m(),origin,point,ignores)
		if bool(route.blocked):continue
		if task=="serving" and not teleport:
			var after=Space.find_route(m(),point,destination,ignores)
			if bool(after.blocked):continue
			route.points.append_array(after.points);route.length=float(route.length)+float(after.length)
		if float(route.length)<distance:
			distance=float(route.length);best={"device_uid":id,"target":destination,"route":route,"teleport":teleport}
	return best
func select_worker(task: String,customer: Dictionary) -> Dictionary:
	var wanted="chef" if task=="cooking" else "salesman" if task in ["paying","recommending"] else "waiter"
	var best: Dictionary={};var best_score=-INF;var best_distance=INF
	for employee in m().employees:
		var fallback=task=="paying" and capable(employee,"waiter") and not capable(employee,"salesman")
		if not capable(employee,wanted) and not fallback:continue
		if not local_available(employee) or not m().full_rules.active(str(employee.id)) or (float(employee.stamina)<=0 and not m().full_rules.revision18.draining(str(employee.id))):continue
		if m().full_rules.effects.employee_handles_complaint(str(employee.id)):continue
		if task=="recommending" and not m().full_rules.customer_service.can_recommend(employee,customer):continue
		var capacity=1
		if task=="cooking" and str(employee.id)=="jiu_ying":capacity=maxi(int(m().balance.get("coeff.jiuying_batch",3)),int(m().full_rules.sidequests.modifiers().get("jiuying_batch_capacity",3)))
		if task=="cooking" and bool(customer.get("group_parallel",false)):
			if m().customers.filter(func(c):return str(c.get("worker",""))==str(employee.id)).all(func(c):return int(c.get("group_id",-1))==int(customer.get("group_id",-2))):capacity=maxi(capacity,int(customer.get("group_size",1)))
		if m()._worker_task_count(str(employee.id))>=capacity:continue
		var candidate=plan(employee,task,customer)
		if candidate.is_empty():continue
		var attributes: Dictionary=employee.attributes
		var score=float(attributes.get("cooking",0)) if task=="cooking" else float(attributes.get("eloquence",0)) if task=="recommending" else (float(attributes.get("calculation",0))+float(attributes.get("charm",0))) if task=="paying" else float(attributes.get("speed",0))
		if fallback:score=float(attributes.get("speed",0))-10000
		if score>best_score or (is_equal_approx(score,best_score) and float(candidate.route.length)<best_distance):best=employee;best_score=score;best_distance=float(candidate.route.length)
	return best
func align_batches():
	var groups: Dictionary={}
	for customer in m().customers:
		if bool(customer.get("group_parallel",false)) and str(customer.stage)=="cooking" and int(customer.due_minute)>=0:
			var key=str(customer.get("group_id",customer.id))
			if not groups.has(key):groups[key]=[]
			groups[key].append(customer)
	for batch in groups.values():
		if batch.size()!=int(batch[0].get("group_size",1)) or batch.size()<2:continue
		# The complete platter batch begins once its distinct stations are ready.
		var due=0
		for customer in batch:due=maxi(due,int(customer.due_minute))
		for customer in batch:
			customer.due_minute=due
			if customer.get("task_motion") is Dictionary:customer.task_motion.travel_minutes=maxf(float(customer.task_motion.travel_minutes),due-float(customer.task_motion.started)-float(customer.task_motion.work_minutes))
			for event in m().scheduler:
				if str(event.type)=="customer_step" and int(event.get("customer_id",-1))==int(customer.id):event.due=due
			m()._sync_worker(str(customer.worker))

func release_aux(id: String):
	if s().aux_jobs.has(id):s().aux_jobs.erase(id)
func idle_target(employee: Dictionary) -> Vector2:
	if s().aux_jobs.has(str(employee.id)):return operation_point(by_id(str(s().aux_jobs[str(employee.id)].device_uid)))
	var choices=fixtures("rest" if bool(employee.get("resting",false)) else "stove" if capable(employee,"chef") else "cashier" if capable(employee,"salesman") else "pass")
	var desired=Vector2(Space.world_size(m()).x-70,465)
	if not choices.is_empty():
		choices.sort_custom(func(a,b):return m().motion_position(employee).distance_squared_to(operation_point(a))<m().motion_position(employee).distance_squared_to(operation_point(b)))
		desired=operation_point(choices[0])+Vector2(0,56)
	return Space.reserved_point(m(),employee,desired)
func work_multiplier(task: String) -> float:
	return 1.0/(1+float(m().balance.get("equipment.pass_speed_bonus",.15))) if task=="serving" and fixtures("pass").any(func(item):return str(item.id)=="serving_counter") else 1.0
func rest_multiplier(employee: Dictionary) -> float:
	var job: Dictionary=s().aux_jobs.get(str(employee.id),{})
	if not local_available(employee):return 1.0
	if job.get("action")!="Rest":return 1.0
	var motion: Dictionary=employee.get("motion",{})
	return 1.0+float(m().balance.get("equipment.rest_recovery_bonus",.1)) if now()>=float(motion.get("started",now()))+float(motion.get("travel_minutes",0)) else 1.0
func begin_motion(employee: Dictionary,item: Dictionary,action: String,work: float) -> bool:
	var origin: Vector2=m().motion_position(employee);var target=operation_point(item);var route=Space.find_route(m(),origin,target)
	if bool(route.blocked):return false
	var speed=float(m().AnimationRules.animation_settings(m().balance).base_move_pixels_per_game_minute)*m().AnimationRules.animation_factor(employee,"Move",m().balance)
	var points: Array=[]
	for p in route.points:points.append(m()._point_data(p))
	employee.motion={"origin":m()._point_data(origin),"target":m()._point_data(target),"path":points,"started":now(),"speed":speed,"travel_minutes":float(route.length)/maxf(.001,speed),"work_minutes":work,"blocked":false,"action":action}
	return true
func tick():
	for customer in m().customers:
		if str(customer.get("stage","")) not in ["cooking","ordering"] or bool(customer.get("device_hook_fired",false)) or bool(customer.get("legacy_equipment_task",false)):continue
		var motion: Dictionary=customer.get("task_motion",{})
		if motion.is_empty() or float(now())<float(motion.get("started",now()))+float(motion.get("travel_minutes",0)):continue
		customer.device_hook_fired=true
		m().full_rules.world.on_hook(str(customer.stage),{"employee_id":str(customer.get("worker","")),"dish_id":str(customer.get("dish_id","")),"customer_id":int(customer.id)})
	for departed in s().departures.duplicate():
		if now()>=int(departed.until):s().departures.erase(departed)
	for id in s().aux_jobs.keys():
		var employee=m()._employee(str(id));var job: Dictionary=s().aux_jobs[id]
		if employee.is_empty() or not local_available(employee) or m()._worker_task_count(str(id))>0 or (job.action=="Rest" and not bool(employee.resting)) or (job.action=="Promote" and (not m().full_rules.active(str(id)) or int(m().state.promotion_until)<=now())):release_aux(str(id));continue
		if job.action=="Promote" and not bool(job.get("hook_fired",false)) and float(now())>=float(employee.motion.get("started",now()))+float(employee.motion.get("travel_minutes",0)):
			job.hook_fired=true;m().full_rules.world.on_hook("promote",{"employee_id":str(id),"kind":str(m().state.get("last_promotion_kind","flyer")),"promotion_kind":str(m().state.get("last_promotion_kind","flyer"))})
		if job.action=="Promote" and now()>=int(job.due):s().promotion_cycles+=1;release_aux(str(id));m().initialize_employee_motion(employee,true)
	for employee in m().employees:
		var id=str(employee.id)
		if not local_available(employee) or m()._worker_task_count(id)>0 or s().aux_jobs.has(id) or int(employee.get("management_until",0))>now() or m().full_rules.revision.is_building(id) or not str(employee.get("branch_id","")).is_empty():continue
		var action="Rest" if bool(employee.resting) else "Promote"
		if action=="Promote" and (not capable(employee,"salesman") or not m().full_rules.active(id) or int(m().state.promotion_until)<=now()):continue
		var choices=fixtures("rest" if action=="Rest" else "promotion").filter(func(item):return not locked(identity(item)))
		if choices.is_empty():continue
		var item: Dictionary=choices[0];var duration=float(m().balance.get("equipment.promotion_work_minutes",10))/m().AnimationRules.animation_factor(employee,"Promote",m().balance) if action=="Promote" else 0.0
		if begin_motion(employee,item,action,duration):s().aux_jobs[id]={"device_uid":identity(item),"action":action,"due":now()+int(ceil(float(employee.motion.travel_minutes)+duration))}
func guest_motion(origin: Vector2,target: Vector2) -> Dictionary:
	var route=Space.find_route(m(),origin,target)
	if bool(route.blocked):return {}
	var speed=float(m().AnimationRules.animation_settings(m().balance).base_move_pixels_per_game_minute)
	var path: Array=[]
	for p in route.points:path.append(m()._point_data(p))
	return {"origin":m()._point_data(origin),"target":m()._point_data(target),"path":path,"started":now(),"speed":speed,"travel_minutes":float(route.length)/speed,"work_minutes":0.0,"action":"Idle","blocked":false}
func guest_position(customer: Dictionary,at: float=-1) -> Vector2:
	var motion: Dictionary=customer.get("checkout_motion",customer.get("arrival_motion",{}))
	if motion.is_empty():return Space.seat_position(m(),int(customer.get("seat",0)))
	return m().motion_position({"motion":motion},float(now()) if at<0 else at)
func begin_arrival(customer: Dictionary,origin: Vector2=Vector2(INF,INF)):
	var motion=guest_motion(origin if origin.is_finite() else Space.entry_position(m()),Space.seat_position(m(),int(customer.seat)))
	if motion.is_empty():return
	customer.erase("checkout_motion");customer.arrival_motion=motion;customer.arrival_due=now()+int(ceil(float(motion.travel_minutes)))
func prepare_checkout(customer: Dictionary,plan: Dictionary) -> float:
	var point: Vector2=plan.target+Vector2(-36,30)
	if not Geometry.point_is_clear(point,Space.obstacles(m())):point=plan.target+Vector2(0,40)
	var motion=guest_motion(guest_position(customer),point)
	if motion.is_empty():return 0.0
	customer.checkout_motion=motion
	return float(motion.travel_minutes)
func begin_exit(customer: Dictionary):
	if customer.get("departed_visual",false):return
	if str(customer.get("visitor_id",""))=="picky_blogger" and not bool(customer.get("visitor_done",false)) and customer.get("visitor_scores",[]).size()<3:return
	var motion=guest_motion(guest_position(customer),Space.entry_position(m()))
	if motion.is_empty():return
	customer.departed_visual=true
	var actor={"id":int(customer.id),"type":str(customer.type),"motion":motion,"until":now()+maxi(1,int(ceil(float(motion.travel_minutes))))}
	if customer.has("visitor_id"):actor.visitor_id=customer.visitor_id
	s().departures.append(actor)
func validate(saved: Dictionary,employees: Array,customers: Array) -> bool:
	if not saved.has("revision191"):return true
	var d: Variant=saved.revision191
	if not d is Dictionary or d.get("version")!=1 or not d.get("aux_jobs") is Dictionary or not d.get("departures") is Array or not d.get("legacy_import") is bool:return false
	if not m()._integer(d.get("grid_width"),8) or int(d.grid_width)>64 or d.get("grid_height")!=5 or not m()._number(d.get("cell_width")) or float(d.cell_width)<15 or float(d.cell_width)>121.001 or not m()._integer(d.get("promotion_cycles")):return false
	if d.departures.size()>512:return false
	for guest in d.departures:
		if not guest is Dictionary or not m()._integer(guest.get("id"),1) or not m()._integer(guest.get("until")) or not m()._valid_motion(guest.get("motion")):return false
	var ids: Array=[]
	for customer in customers:
		if int(customer.get("due_minute",-1))<0 or str(customer.get("worker",""))=="":continue
		if not customer.get("device_uid","") is String:return false
		var id=str(customer.get("device_uid",""))
		if id.is_empty():
			if not bool(customer.get("legacy_equipment_task",false)):return false
			continue # Previous-schema orders may finish unchanged.
		if id in ids or not saved.layout.any(func(item):return identity(item)==id and kind(item)==task_kind(str(customer.stage)) and not bool(item.get("building",false))):return false
		ids.append(id)
	for worker in d.aux_jobs:
		var job: Variant=d.aux_jobs[worker]
		if not job is Dictionary or not job.get("action") in ["Rest","Promote"] or not m()._integer(job.get("due")):return false
		if job.action=="Rest" and not employees.any(func(e):return str(e.id)==str(worker) and bool(e.resting)):return false
		var id=str(job.get("device_uid",""))
		if id in ids or not saved.layout.any(func(item):return identity(item)==id and not bool(item.get("building",false))) or employees.filter(func(e):return str(e.id)==worker).size()!=1:return false
		ids.append(id)
	return true
