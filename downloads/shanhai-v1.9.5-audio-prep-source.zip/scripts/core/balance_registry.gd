extends RefCounted
## Numeric defaults and validation without constructing a GameModel.
## Existing global_balance values are authoritative; module defaults only fill gaps.

const Management = preload("res://scripts/core/management_rules.gd")
const Effects = preload("res://scripts/core/effect_resolver.gd")
const Preferences = preload("res://scripts/core/customer_preferences.gd")
const Finance = preload("res://scripts/core/finance_rules.gd")
const CustomerService = preload("res://scripts/core/customer_service.gd")
const Synergies = preload("res://scripts/core/synergy_rules.gd")
const Sidequests = preload("res://scripts/core/sidequest_rules.gd")
const MODULES := [Finance, CustomerService, Synergies, Sidequests]
const MODULE_PREFIXES := ["finance.", "recommend.", "service.", "sidequests."]
const SOURCES := {"animation": "res://config/animation.json", "full": "res://config/full_game.json", "expansion": "res://config/expansion.json", "story":"res://config/story.json"}


static func _read(path: String) -> Dictionary:
	if not FileAccess.file_exists(path): return {}
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	return parsed if parsed is Dictionary else {}


static func _numeric(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))


static func _fill(target: Dictionary, source: Dictionary) -> void:
	for key in source:
		if not target.has(key) and _numeric(source[key]): target[key] = source[key]


static func flatten(value: Variant, prefix: String = "") -> Dictionary:
	var result: Dictionary = {}
	if value is Dictionary:
		for key in value:
			# Schema versions and labels are metadata, never gameplay knobs.
			if str(key) == "version": continue
			var path := str(key) if prefix.is_empty() else prefix + "." + str(key)
			result.merge(flatten(value[key], path), false)
	elif value is Array:
		for index in value.size():
			var entry: Variant = value[index]
			var segment := str(entry.id) if entry is Dictionary and entry.has("id") else str(index)
			result.merge(flatten(entry, prefix + "." + segment), false)
	elif _numeric(value): result[prefix] = value
	return result


static func defaults() -> Dictionary:
	var result: Dictionary = {}
	# Preserve authored global values; new module defaults only fill gaps.
	var authored := _read("res://config/global_balance.json")
	_fill(result, authored)
	_fill(result, _read("res://config/event_balance.json"))
	var host := RefCounted.new()
	var management := Management.new(host)
	_fill(result, management.balance_defaults())
	_fill(result, Preferences.new(host).balance_defaults())
	for module in MODULES: _fill(result, module.new(host).balance_defaults())
	for key in Effects.DEFAULTS:
		_fill(result, {"coeff." + str(key): Effects.DEFAULTS[key]})
	_fill(result, {"coeff.charm_price": 0.01, "coeff.eloquence_price": 0.01, "coeff.charm_tip": 0.005})
	_fill(result, {"employee.role_tutor": 0.4})
	for prefix in SOURCES:
		_fill(result, flatten(_read(SOURCES[prefix]), prefix))
	# Authored canonical coeffs beat authored aliases. An authored alias remains
	# usable when the canonical key was absent before this version's defaults.
	for alias in CustomerService.COEFFICIENT_ALIASES:
		var canonical: String = CustomerService.COEFFICIENT_ALIASES[alias]
		var value: Variant = authored.get(canonical, authored.get(alias, result.get(canonical, result.get(alias))))
		if _numeric(value):
			result[canonical] = value
			result[alias] = value
	return result


static func normalize_overrides(candidate: Dictionary) -> Dictionary:
	# Normalize the EDIT before merging it with a complete runtime table. This
	# lets recommend.* tuning work even when a default coeff.* already exists.
	var result := candidate.duplicate(true)
	for alias in CustomerService.COEFFICIENT_ALIASES:
		var canonical: String = CustomerService.COEFFICIENT_ALIASES[alias]
		if not candidate.has(alias) and not candidate.has(canonical): continue
		var value: Variant = candidate.get(canonical, candidate.get(alias))
		result[alias] = value
		result[canonical] = value
	return result


static func _module_key(key: String) -> bool:
	for prefix in MODULE_PREFIXES:
		if key.begins_with(prefix): return true
	return false


static func overlay(source: Variant, prefix: String, balance: Dictionary) -> Variant:
	# Return a deep copy; never rewrite a module's source configuration in memory.
	if source is Dictionary:
		var result: Dictionary = {}
		for key in source:
			result[key] = overlay(source[key], prefix + "." + str(key), balance)
		return result
	if source is Array:
		var result: Array = []
		for index in source.size():
			var entry: Variant = source[index]
			var segment := str(entry.id) if entry is Dictionary and entry.has("id") else str(index)
			result.append(overlay(entry, prefix + "." + segment, balance))
		return result
	if _numeric(source) and _numeric(balance.get(prefix)): return balance[prefix]
	return source


static func _integer(value: Variant, minimum: int = 0) -> bool:
	return _numeric(value) and float(value) >= minimum and float(value) == floorf(float(value)) and float(value) <= 2147483647.0


static func _positive_key(key: String) -> bool:
	var leaf := key.get_slice(".", key.get_slice_count(".") - 1)
	if key.begins_with("story."):
		return leaf in ["day_minutes","week_days","month_days","report_limit"]
	if key.begins_with("animation."):
		return leaf in ["base_move_pixels_per_game_minute", "arrival_distance", "transition_seconds", "frames_per_second", "minimum", "maximum"]
	if key.begins_with("full.stage.active_limits.") or key.begins_with("full.stage.table_limits.") or key in ["full.layout.width", "full.layout.height", "full.economy.record_limit", "full.economy.daily_report_limit", "full.defaults.minimum_travel_minutes"]: return true
	if key.begins_with("expansion."):
		return leaf in ["offer_interval", "offer_expiry", "travel_minutes", "capacity", "enroll_every_orders", "redeem_points", "minutes", "order_minutes", "batch_max", "cook_minutes_each", "shipping_minutes", "storage_capacity", "cooldown_minutes"]
	if key.begins_with("events."):
		return leaf.ends_with("_interval") or leaf.ends_with("_duration") or leaf.ends_with("_cooldown") or leaf.ends_with("_period_days") or leaf.ends_with("_reset_days") or leaf.ends_with("_delay") or leaf.ends_with("_delay_min") or leaf in ["queue_limit", "history_limit", "feedback_history_limit", "pause_day", "delay_three_days", "day_duration", "three_day_duration", "two_hour_duration", "ten_minute_duration", "influencer_quality_scale"]
	return false


static func _fraction_key(key: String) -> bool:
	var leaf := key.get_slice(".", key.get_slice_count(".") - 1)
	if ("probability" in leaf or "chance" in leaf) and not leaf.ends_with("_scale") and not leaf.ends_with("_multiplier"): return true
	return key in ["events.festival_base_win", "events.inspection_base_pass", "events.inspection_prepared_base_pass", "events.discount", "events.weather_rain_traffic", "events.weather_snow_traffic", "events.weather_heat_traffic", "events.kunlun_customer_loss", "coeff.bond_justice_ingredient", "coeff.calculation_escape_cap", "coeff.eloquence_complaint_cap", "coeff.endurance_work_reduction", "coeff.endurance_rest_recovery", "coeff.luwu_dish_time_reduction", "coeff.jingwei_dish_serving_reduction", "expansion.delivery.commission", "expansion.membership.voucher_discount", "expansion.membership.max_traffic_bonus"]


static func _count_key(key: String) -> bool:
	var leaf := key.get_slice(".", key.get_slice_count(".") - 1)
	if key.begins_with("full.stage.reward_gems.") or key.begins_with("full.defaults.festival_days."): return true
	return (key.begins_with("story.") and leaf in ["skill_books","gems","monthly_books","target","month_day"]) or leaf in ["gems", "fragments", "points_per_order", "base_demand", "member_multiplier", "attribute_gain", "first_win_gems", "first_win_reputation", "repeat_win_reputation", "participation_reputation"] or (key.begins_with("full.milestones.") and leaf == "target")


static func validate(candidate: Dictionary) -> bool:
	var values := defaults()
	for key in candidate:
		if not key is String or not _numeric(candidate[key]): return false
		if values.has(key): values[key] = candidate[key]
		elif str(key).begins_with("animation.") or str(key).begins_with("full.") or str(key).begins_with("expansion.") or str(key).begins_with("events.") or str(key).begins_with("story.") or _module_key(str(key)): return false
	if float(values.get("time.minutes_per_real_second",3)) <= 0 or float(values.get("time.minutes_per_real_second",3)) > 60: return false
	for key in ["time.default_speed","time.maximum_speed"]:
		if not _integer(values.get(key,2),1) or float(values.get(key,2)) > 4: return false
	if float(values.get("time.default_speed",2)) > float(values.get("time.maximum_speed",4)): return false
	# Reuse the staff/inventory validator, which also checks coupled limits.
	var host := RefCounted.new()
	if not Management.new(host).validate_balance(candidate): return false
	if not Preferences.new(host).validate_balance(candidate): return false
	for module in MODULES:
		if not module.new(host).validate_balance(candidate): return false
	for key in ["pickup_drop_chance","pickup_drop_bonus_cashier","pickup_drop_bonus_pixiu","state_word_of_mouth_review","coeff.xuangui_stamina_reduction","coeff.qinggeng_complaint_reduction","pickup_cash_weight","pickup_spirit_weight","pickup_bonus_qingfu","pickup_bonus_tianlu","pickup_event_zhaocai","pickup_event_zhaocai_cash"]:
		if float(values.get(key,0))<0 or float(values.get(key,0))>1:return false
	for key in ["decoration.stove_cost","decoration.serving_counter_cost","decoration.promotion_board_cost","decoration.staff_corner_cost"]:
		if float(values.get(key,0))<0:return false
	for key in ["equipment.pass_speed_bonus","equipment.rest_recovery_bonus"]:
		if float(values.get(key,0))<0 or float(values.get(key,0))>1:return false
	if float(values.get("equipment.promotion_work_minutes",10))<=0:return false
	if not is_equal_approx(float(values.get("pickup_cash_weight",.97))+float(values.get("pickup_spirit_weight",.03)),1):return false
	for key in ["customer.patience_order_rate","customer.patience_cooking_rate"]:
		if float(values.get(key,1.5))<=0 or float(values.get(key,1.5))>10:return false
	var event_defaults := _read("res://config/event_balance.json")
	for key in values:
		var value: float = float(values[key])
		if not is_finite(value) or absf(value) > 1.0e12: return false
		if not (str(key).begins_with("events.") or str(key).begins_with("animation.") or str(key).begins_with("full.") or str(key).begins_with("expansion.") or event_defaults.has(key) or Effects.DEFAULTS.has(str(key).trim_prefix("coeff.")) or str(key) in ["coeff.charm_price", "coeff.eloquence_price", "coeff.charm_tip"]): continue
		var signed: bool = str(key) in ["events.weather_rain_traffic", "events.weather_snow_traffic", "events.weather_heat_traffic", "events.fine_unpaid_reputation", "events.collection_reputation", "events.kunlun_customer_loss", "events.blockade_traffic_penalty", "events.taotie_saving", "events.tiangou_panic", "coeff.bond_justice_ingredient"]
		if value < 0 and not signed: return false
		if _positive_key(str(key)) and value <= 0: return false
		if _fraction_key(str(key)) and (value > 1 or value < (-1.0 if signed else 0.0)): return false
		if str(key).ends_with(".stage") and not _integer(value, 0): return false
		if str(key).ends_with(".stage") and value > 4: return false
		if _positive_key(str(key)) and not str(key).begins_with("animation.") and str(key) != "events.influencer_quality_scale" and not _integer(value, 1): return false
		if _count_key(str(key)) and not _integer(value): return false
	for category in ["move", "cook", "charm"]:
		var prefix: String = "animation." + str(category)
		if float(values[prefix + ".minimum"]) > float(values[prefix + ".maximum"]): return false
	if float(values["animation.mood.threshold"]) > float(values["animation.mood.maximum"]): return false
	if float(values["animation.mood.maximum"]) > 100: return false
	if float(values["expansion.membership.voucher_discount"]) >= 1: return false
	return true
