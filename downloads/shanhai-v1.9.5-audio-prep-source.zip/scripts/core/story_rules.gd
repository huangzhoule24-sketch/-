extends RefCounted
## Campaign story reads actual simulation outcomes; it never invents event wins.
var _model_ref: WeakRef
var config: Dictionary = {}
var _source_config: Dictionary = {}
const BalanceRegistry = preload("res://scripts/core/balance_registry.gd")

func _init(host: RefCounted) -> void:
	_model_ref = weakref(host)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/story.json"))
	if parsed is Dictionary: _source_config = parsed
	refresh_balance()

func refresh_balance() -> void:
	config = BalanceRegistry.overlay(_source_config, "story", _m().balance)

func _m() -> Variant:
	return _model_ref.get_ref()

func _s() -> Dictionary:
	return _m().state.story

func _v(key: String, fallback: float = 0) -> float:
	var clock_keys = {"day_minutes": "day.minutes", "week_days": "time.days_per_week", "month_days": "time.days_per_month"}
	if clock_keys.has(key): return float(_m().balance.get(clock_keys[key], fallback))
	return float(_m().balance.get("story.defaults." + key, config.get("defaults", {}).get(key, fallback)))

func _now() -> int:
	return int(_m().state.total_minutes)

func _day() -> int:
	return int(floor(float(_now()) / maxf(1, _v("day_minutes", 1440)))) + 1

func _definitions() -> Array:
	return config.get("milestones", []) + config.get("achievements", [])

func _definition(id: String) -> Dictionary:
	for entry in _definitions():
		if str(entry.id) == id: return entry
	return {}

func ensure_state() -> void:
	refresh_balance()
	var m = _m()
	if not m.state.get("story") is Dictionary: m.state.story = {}
	var defaults = {"version": 1, "collected_ids": [], "completed": [], "claimed": [], "completion_minutes": {}, "debt_cleared": false, "kunlun_resolved": false, "baseline_day": _day(), "last_day": _day() - 1, "week_start_revenue": float(m.state.total_revenue), "week_start_served": int(m.state.served), "month_start_revenue": float(m.state.total_revenue), "month_start_served": int(m.state.served), "last_week": {}, "monthly_reports": [], "calendar_current": {}}
	for key in defaults:
		if not m.state.story.has(key): m.state.story[key] = defaults[key].duplicate(true) if defaults[key] is Array or defaults[key] is Dictionary else defaults[key]
	_observe()

func _observe() -> void:
	var m = _m()
	var known: Dictionary = {}
	for employee in m.catalog: known[str(employee.id)] = true
	var observed: Array = m.employees.duplicate()
	observed.append_array(m.state.get("management", {}).get("departed", []))
	for employee in observed:
		var id = str(employee.get("id", ""))
		if known.has(id) and not id in _s().collected_ids: _s().collected_ids.append(id)
	if float(m.state.debt) <= 0: _s().debt_cleared = true
	if bool(m.state.get("world", {}).get("blockade", {}).get("resolved", false)):
		_s().kunlun_resolved = true
	var previous = ""
	for entry in _definitions():
		var id = str(entry.id)
		var main = entry in config.get("milestones", [])
		var ready: bool = not main or previous.is_empty() or previous in _s().completed
		if ready and _progress(entry) >= int(entry.target) and not id in _s().completed:
			_s().completed.append(id)
			_s().completion_minutes[id] = _now()
			_m()._log("主线进展：%s，可到「主线故事」领取。" % str(entry.title))
		if main: previous = id

func _progress(entry: Dictionary) -> int:
	match str(entry.type):
		"debt_free": return 1 if bool(_s().debt_cleared) else 0
		"festival_wins": return int(_m().state.get("world", {}).get("festival_wins", 0))
		"collection": return _s().collected_ids.size()
		"kunlun_resolved": return 1 if bool(_s().kunlun_resolved) else 0
		"stage": return int(_m().state.stage)
		"competition_wins": return int(_m().state.get("expansion", {}).get("competition", {}).get("wins", 0))
	return 0

func tick_minute() -> void:
	ensure_state()
	_update_calendar()

func on_day() -> void:
	tick_minute()

func _update_calendar() -> void:
	var day = _day()
	if day <= int(_s().last_day): return
	var m = _m()
	var elapsed = day - 1
	var week_days = maxi(1, int(_v("week_days", 7)))
	var month_days = maxi(1, int(_v("month_days", 30)))
	if elapsed > 0 and day > int(_s().baseline_day) and elapsed % week_days == 0:
		_s().last_week = {"day": day, "revenue": maxf(0, float(m.state.total_revenue) - float(_s().week_start_revenue)), "served": maxi(0, int(m.state.served) - int(_s().week_start_served))}
		_s().week_start_revenue = float(m.state.total_revenue)
		_s().week_start_served = int(m.state.served)
		m._log("本周经营回顾：营业额￥%.2f，接待%d位；到主线故事查看。" % [float(_s().last_week.revenue), int(_s().last_week.served)])
	if elapsed > 0 and day > int(_s().baseline_day) and elapsed % month_days == 0:
		var revenue = maxf(0, float(m.state.total_revenue) - float(_s().month_start_revenue))
		var served = maxi(0, int(m.state.served) - int(_s().month_start_served))
		var report = {"month": elapsed / month_days, "day": day, "revenue": revenue, "served": served, "eligible": revenue > 0 and served > 0 and revenue >= _v("monthly_revenue_target", 1000), "claimed": false}
		_s().monthly_reports.append(report)
		while _s().monthly_reports.size() > maxi(1, int(_v("report_limit", 12))): _s().monthly_reports.pop_front()
		_s().month_start_revenue = float(m.state.total_revenue)
		_s().month_start_served = int(m.state.served)
		m._log("本月经营回顾：营业额￥%.2f；达标后可领取%d本技能书。" % [revenue, int(_v("monthly_books", 1))])
	_s().calendar_current = {}
	var month_day = elapsed % month_days + 1
	for festival in config.get("festivals", []):
		if int(festival.month_day) != month_day: continue
		_s().calendar_current = {"id": str(festival.id), "day": day, "hosted": false}
		m._log("今日节日提醒：%s。可自费举办邻里活动，非自动发放奖金。" % str(festival.title))
	_s().last_day = day

func _result(ok: bool, reason: String = "") -> Dictionary:
	return {"ok": ok, "reason": reason, "message": reason}

func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	ensure_state()
	_update_calendar()
	match action:
		"story_claim":
			var id = str(args.get("id", ""))
			if _definition(id).is_empty(): return _result(false, "未知剧情目标")
			if id in _s().claimed: return _result(false, "剧情奖励已领取")
			var previous = ""
			for entry in config.get("milestones", []):
				if str(entry.id) == id:
					if not previous.is_empty() and not previous in _s().claimed: return _result(false, "请先领取前一个主线目标")
					break
				previous = str(entry.id)
			if not id in _s().completed: return _result(false, "剧情条件尚未达成")
			return _result(true)
		"festival_invitation":
			var world: Variant = _m().full_rules.world
			var definition: Dictionary = world._definition("food_festival")
			if definition.is_empty(): return _result(false, "美食节配置不可用")
			if not world.can_enqueue("food_festival"): return _result(false,"美食节邀请今日已发生或已在队列中")
			if not world._eligible(definition, "random", {}): return _result(false, "需要声望达到500、正在营业，且没有同类邀请排队或冷却")
			if _m().state.world.queue.size() >= int(world._b("events.queue_limit")): return _result(false, "请先处理队列中的事件")
			return _result(true)
		"seasonal_activity":
			if _s().calendar_current.is_empty(): return _result(false, "今日没有节日活动")
			if bool(_s().calendar_current.hosted): return _result(false, "今日邻里活动已经举办")
			if not _m().business_open(): return _result(false, "请在营业时举办活动")
			if float(_m().state.cash) < _v("festival_cash_cost", 80): return _result(false, "活动经费不足")
			return _result(true)
		"monthly_story_claim":
			for report in _s().monthly_reports:
				if int(report.month) != int(args.get("month", -1)): continue
				return _result(bool(report.eligible) and not bool(report.claimed), "月度奖励已领取或营业额未达标" if not report.eligible or report.claimed else "")
			return _result(false, "没有对应的月度报告")
	return _result(false, "未知剧情操作")

func _reward_value(id: String, key: String, fallback: float) -> float:
	var section = "achievements" if id == "all_beasts" else "milestones"
	return float(_m().balance.get("story.%s.%s.reward.%s" % [section, id, key], fallback))

func perform(action: String, args: Dictionary = {}) -> Dictionary:
	var check = can_perform(action, args)
	if not check.ok: return check
	var m = _m()
	match action:
		"story_claim":
			var id = str(args.id)
			var definition = _definition(id)
			var reward: Dictionary = definition.get("reward", {})
			var cash = _reward_value(id, "cash", float(reward.get("cash", 0)))
			m.change_cash(cash,"reward","主线奖励："+str(definition.title))
			m.state.gems = int(m.state.gems) + int(_reward_value(id, "gems", float(reward.get("gems", 0))))
			var books = int(_reward_value(id, "skill_books", float(reward.get("skill_books", 0))))
			if books > 0: m.full_rules.management.add_skill_books(books)
			if bool(reward.get("hidden_recipe", false)): m.full_rules.management.discover_hidden_recipe()
			if cash != 0: m.full_rules.record("financing", cash, "主线奖励：" + str(definition.title))
			_s().claimed.append(id)
			m._log(str(definition.dialogue))
			return _result(true, "已领取：" + str(definition.title))
		"festival_invitation":
			# Eligibility checks reputation, opening hours, existing queue and cooldown.
			# The original event still charges the entry fee and resolves the actual contest.
			return _result(bool(m.full_rules.world._enqueue("food_festival", {"source": "story_invitation"})), "已申请美食节邀请；请到事件面板决定是否报名")
		"seasonal_activity":
			var cost = _v("festival_cash_cost", 80)
			m.change_cash(-cost,"event_expense","节日邻里活动")
			m.full_rules.record("expenses", cost, "节日邻里活动")
			m.state.reputation = int(m.state.reputation) + int(_v("festival_reputation", 8))
			for employee in m.employees: employee.mood = clampf(float(employee.mood) + _v("festival_mood", 3), 0, 100)
			_s().calendar_current.hosted = true
			m._log("邻里活动结束：经费￥%.2f，声望+%d，伙伴心情+%d。" % [cost, int(_v("festival_reputation", 8)), int(_v("festival_mood", 3))])
			return _result(true, "邻里活动已完成，支出已记入费用")
		"monthly_story_claim":
			for report in _s().monthly_reports:
				if int(report.month) != int(args.month): continue
				var books = int(_v("monthly_books", 1))
				if books > 0: m.full_rules.management.add_skill_books(books)
				report.claimed = true
				return _result(true, "已领取月度经营技能书%d本" % books)
	return _result(false, "未知剧情操作")

func snapshot() -> Dictionary:
	ensure_state()
	_update_calendar()
	var entries: Array = []
	var previous = ""
	for definition in _definitions():
		var entry: Dictionary = definition.duplicate(true)
		var id = str(entry.id)
		var main = definition in config.get("milestones", [])
		entry.merge({"progress": _progress(entry), "complete": id in _s().completed, "claimed": id in _s().claimed, "unlocked": not main or previous.is_empty() or previous in _s().claimed, "claim_check": can_perform("story_claim", {"id": id})})
		for key in ["cash", "gems", "skill_books"]: entry.reward[key] = _reward_value(id, key, float(entry.reward.get(key, 0)))
		entries.append(entry)
		if main: previous = id
	var calendar: Dictionary = _s().calendar_current.duplicate(true)
	if not calendar.is_empty():
		for definition in config.get("festivals", []):
			if str(definition.id) == str(calendar.id): calendar.merge(definition)
	return {"opening": config.get("opening", {}).duplicate(true), "chapters": config.get("chapters", []).duplicate(true), "entries": entries, "collection": _s().collected_ids.size(), "calendar": calendar, "day": _day(), "week": _s().last_week.duplicate(true), "monthly_reports": _s().monthly_reports.duplicate(true), "monthly_revenue_target": _v("monthly_revenue_target", 1000), "monthly_books": int(_v("monthly_books", 1)), "festival_cash_cost": _v("festival_cash_cost", 80), "festival_reputation": int(_v("festival_reputation", 8)), "festival_mood": int(_v("festival_mood", 3)), "complete": "champion" in _s().claimed}

func _integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum and float(value) == floorf(float(value))

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0

func validate_state(saved_story: Dictionary, _employees: Array, time: int) -> bool:
	# The caller accepts a missing story field for legacy saves. A present one is strict.
	if not _integer(saved_story.get("version"), 1) or int(saved_story.version) != 1: return false
	for key in ["collected_ids", "completed", "claimed", "monthly_reports"]:
		if not saved_story.get(key) is Array: return false
	for key in ["completion_minutes", "last_week", "calendar_current"]:
		if not saved_story.get(key) is Dictionary: return false
	for key in ["debt_cleared", "kunlun_resolved"]:
		if not saved_story.get(key) is bool: return false
	for key in ["week_start_revenue", "month_start_revenue"]:
		if not _number(saved_story.get(key)): return false
	for key in ["week_start_served", "month_start_served", "last_day", "baseline_day"]:
		if not _integer(saved_story.get(key)): return false
	var today = int(floor(float(time) / maxf(1, _v("day_minutes", 1440)))) + 1
	if int(saved_story.last_day) > today: return false
	if int(saved_story.baseline_day) < 1 or int(saved_story.baseline_day) > today: return false
	var known: Dictionary = {}
	for entry in _m().catalog: known[str(entry.id)] = true
	var seen: Dictionary = {}
	for id in saved_story.collected_ids:
		if not id is String or not known.has(id) or seen.has(id): return false
		seen[id] = true
	for field in ["completed", "claimed"]:
		seen = {}
		for id in saved_story[field]:
			if not id is String or _definition(id).is_empty() or seen.has(id): return false
			if field == "claimed" and not id in saved_story.completed: return false
			seen[id] = true
	for id in saved_story.completed:
		if not _integer(saved_story.completion_minutes.get(id)) or int(saved_story.completion_minutes[id]) > time: return false
	for id in saved_story.completion_minutes:
		if not id in saved_story.completed: return false
	var previous = ""
	for entry in config.get("milestones", []):
		var id = str(entry.id)
		if not previous.is_empty():
			if id in saved_story.claimed and not previous in saved_story.claimed: return false
			if id in saved_story.completed and not previous in saved_story.completed: return false
		previous = id
	for entry in _definitions():
		if str(entry.type) == "collection" and str(entry.id) in saved_story.completed and saved_story.collected_ids.size() < (26 if bool(saved_story.get("v18_legacy_collection",false)) else 28 if bool(saved_story.get("v19_legacy_collection",false)) else int(entry.target)): return false
	if "debt" in saved_story.completed and not bool(saved_story.debt_cleared): return false
	if "kunlun" in saved_story.completed and not bool(saved_story.kunlun_resolved): return false
	if not saved_story.last_week.is_empty() and not _valid_report(saved_story.last_week, today): return false
	var months: Dictionary = {}
	for report in saved_story.monthly_reports:
		if not report is Dictionary or not _valid_report(report, today): return false
		if not _integer(report.get("month"), 1) or months.has(int(report.month)): return false
		if int(report.month) > (today - 1) / maxi(1, int(_v("month_days", 30))): return false
		if not report.get("eligible") is bool or not report.get("claimed") is bool: return false
		if report.claimed and not report.eligible: return false
		months[int(report.month)] = true
	var calendar: Dictionary = saved_story.calendar_current
	if not calendar.is_empty():
		if not _integer(calendar.get("day"), 1) or int(calendar.day) > today or not calendar.get("hosted") is bool: return false
		var valid = false
		for definition in config.get("festivals", []):
			if str(calendar.get("id", "")) == str(definition.id) and (int(calendar.day) - 1) % maxi(1, int(_v("month_days", 30))) + 1 == int(definition.month_day): valid = true
		if not valid or int(calendar.day) != int(saved_story.last_day): return false
	return true

func _valid_report(report: Dictionary, today: int) -> bool:
	return _integer(report.get("day"), 1) and int(report.day) <= today and _number(report.get("revenue")) and _integer(report.get("served"))
