extends RefCounted
## v1.7.1 rules shared by model, UI and saved-state validation.
var _ref: WeakRef
var config: Dictionary
var tasks: Array
func _init(host) -> void:
	_ref=weakref(host)
	config=JSON.parse_string(FileAccess.get_file_as_string("res://config/revision171.json"))
	tasks=JSON.parse_string(FileAccess.get_file_as_string("res://config/stage_tasks.json")).tasks
func m(): return _ref.get_ref()
func now() -> int: return int(m().state.total_minutes)
func s() -> Dictionary: return m().state.revision171
func result(ok: bool,reason: String = "",extra: Dictionary = {}) -> Dictionary:
	var r={"ok":ok,"reason":reason};r.merge(extra,true);return r
func ensure_state() -> void:
	if not m().state.has("revision171"):
		m().state.revision171={"version":1,"builds":[],"next_build":1,"completed_builds":0,"dismissals":[],"task_completed":[],"daily_auto":true,"daily_pending":false,"daily_seen":int(m().state.finance.last_bill_day),"peak_reputation":int(m().state.reputation),"baize_bonus":0.0,"notice_running":false}
	if not s().has("daily_pending"):s().daily_pending=false
	for employee in m().employees:
		if not employee.has("level"):
			var points=trained_points(employee)
			employee.level=mini(int(config.level_caps.get(str(employee.rarity),20)),1+points)
		if not employee.has("awakening_count"): employee.awakening_count=1 if bool(employee.get("awakened",false)) else 0
func trained_points(employee: Dictionary) -> int:
	var points=0
	for value in employee.get("training_history",{}).values(): points+=int(value)
	return points
func level_cap(employee: Dictionary) -> int:
	return int(config.level_caps.get(str(employee.get("rarity","N")),20))+int(employee.get("awakening_count",0))*int(config.awakening_cap_gain)
func is_building(id: String) -> bool:
	for job in s().builds:
		if str(job.employee_id)==id:return true
	return false
func status(employee: Dictionary) -> String:
	if int(employee.get("v18_clean_until",0))>now():return "清洁后厨 · 剩%d分" % (int(employee.v18_clean_until)-now())
	if m().full_rules.revision18.draining(str(employee.id)):return "收尾服务中 · 完成全部订单后休息"
	for job in s().builds:
		if str(job.employee_id)==str(employee.id):return "装修中 · %d/%d分钟%s" % [int(job.duration)-int(job.remaining),int(job.duration),"（闭店暂停）" if now()%1440<360 else ""]
	if int(employee.get("management_until",0))>now():return ("研发中" if str(employee.get("management_job_type",""))=="research" else "培训中")+" · 剩%d分" % (int(employee.management_until)-now())
	if int(employee.get("expansion_until",0))>now():return "派遣中"
	if not str(employee.get("branch_id","")).is_empty():return "分店派驻"
	return "休息中" if bool(employee.get("resting",false)) else "主店当班"
func builder_available(employee: Dictionary) -> bool:
	return not employee.is_empty() and m().full_rules.management._available(employee) and not bool(employee.get("resting",false)) and float(employee.get("stamina",0))>0 and m()._worker_task_count(str(employee.id))==0 and not is_building(str(employee.id))
func build_check(id: String,employee_id: String = "",x: int = -1,y: int = -1) -> Dictionary:
	var definition: Dictionary=m().full_rules.decoration(id)
	var reasons: Array[String]=[]
	if definition.is_empty():return result(false,"未知装修项目")
	if bool(definition.get("initial_only",false)):return result(false,"这是开局设施，扩建请选对应设备项目")
	var stage=maxi(1,int(definition.get("min_stage",0)))
	var cost=float(m().balance.get(str(definition.get("cost_key","")),definition.get("cost",0)))
	var gems=int(definition.get("gem_cost",0))
	if int(m().state.stage)<stage:reasons.append("该装修需阶段%d解锁" % stage)
	if float(m().state.cash)<cost:reasons.append("钞票不足，还差￥%.2f" % (cost-float(m().state.cash)))
	if int(m().state.gems)<gems:reasons.append("灵石不足，还差%d颗" % (gems-int(m().state.gems)))
	if bool(m().state.finance.rescue.pending):reasons.append("请先处理经营救援")
	var available: Array=m().employees.filter(func(e):return builder_available(e))
	if available.is_empty():reasons.append("当前无当班空闲员工，请先排班并等待订单或项目结束")
	if employee_id.is_empty():reasons.append("请选择1名装修负责人")
	elif not builder_available(m()._employee(employee_id)):reasons.append("该员工未当班、正忙碌或已负责另一项目")
	if x>=0 and not m().full_rules.can_place_decoration(id,x,y):reasons.append("位置不可施工，请检查占位、通路、在途路线和餐桌上限")
	return result(reasons.is_empty(),"\n".join(reasons),{"cost":cost,"gems":gems,"duration":int(definition.get("build_minutes",60))})
func book_build(id: String,x: int,y: int,employee_id: String) -> Dictionary:
	var check=build_check(id,employee_id,x,y)
	if not check.ok:return check
	var definition: Dictionary=m().full_rules.decoration(id)
	var serial=int(s().next_build);s().next_build=serial+1
	m().change_cash(-float(check.cost),"decoration","装修预订："+str(definition.name));m().state.gems-=int(check.gems)
	m().full_rules.record("capital",float(check.cost),"装修资产："+str(definition.name))
	m().state.layout.append({"id":id,"x":x,"y":y,"w":int(definition.get("width",1)),"h":int(definition.get("height",1)),"build_id":serial,"building":true})
	s().builds.append({"serial":serial,"id":id,"employee_id":employee_id,"duration":int(check.duration),"remaining":int(check.duration),"active":false,"started":now()})
	m().changed.emit();return check
func activate_builds() -> void:
	for job in s().builds:
		if job.active:continue
		var employee: Dictionary=m()._employee(str(job.employee_id))
		m().full_rules.management._suspend(employee)
		employee.construction_until=now()+int(job.remaining)
		job.active=true
		if m().full_rules.dollhouse.enabled():
			for item in m().state.layout:
				if int(item.get("build_id",0))==int(job.serial):m().full_rules.dollhouse.begin_motion(employee,item,"Build",float(job.duration));break
func tick() -> void:
	s().peak_reputation=maxi(int(s().peak_reputation),int(m().state.reputation))
	for job in s().builds.duplicate():
		if not job.active:continue
		var employee: Dictionary=m()._employee(str(job.employee_id))
		var motion: Dictionary=employee.get("motion",{})
		if m().full_rules.dollhouse.enabled() and now()<=float(motion.get("started",now()))+ceilf(float(motion.get("travel_minutes",0))):continue
		if now()%1440>=360:job.remaining=maxi(0,int(job.remaining)-1)
		employee.construction_until=now()+maxi(1,int(job.remaining))
		if int(job.remaining)>0:continue
		for item in m().state.layout:
			if int(item.get("build_id",0))!=int(job.serial):continue
			item.building=false
			m().state.layout.erase(item);m().state.layout.append(item) # Usable seat IDs never shift.
			for effect in m().full_rules.decoration(str(job.id)).get("effects",[]):
				var value=m().full_rules._effect_value(effect)
				match str(effect.type):
					"seats":m().state.seats+=int(value)
					"comfort":m().state.comfort=minf(float(m().balance.get("decoration.max_comfort",100)),float(m().state.comfort)+value)
					"traffic_bonus":m().state.traffic_bonus+=value
					"price_bonus":m().state.price_bonus+=value
					"cooking_speed":m().state.cooking_speed_bonus+=value
					"cashier_speed":m().state.cashier_speed_bonus=minf(0.95,float(m().state.get("cashier_speed_bonus",0))+value)
					"escape_reduction":m().state.escape_reduction=minf(0.95,float(m().state.get("escape_reduction",0))+value)
			break
		employee.construction_until=0;s().builds.erase(job)
		m().initialize_employee_motion(employee,true)
		m().state.decorations_purchased+=1;m().state.stats.decorations+=1;s().completed_builds+=1
		preload("res://scripts/core/tutorial_progress.gd").observe(m(),"buy_decoration")
		m()._notify(str(m().full_rules.decoration(str(job.id)).name)+"装修完工，效果已生效")
func dismissal_quote(id: String) -> Dictionary:
	var e: Dictionary=m()._employee(id)
	if e.is_empty():return result(false,"员工不存在或已经离场")
	if id=="bai_ze":return result(false,"白泽是主线关键角色，不可解雇")
	var cost=m()._money(float(e.get("level",1))*float(config.dismissal.per_level)+trained_points(e)*float(config.dismissal.per_trained_point)+float(e.loyalty)*float(config.dismissal.per_loyalty)+float(config.dismissal.severance))
	if not m().full_rules.management._available(e) or is_building(id) or m()._worker_task_count(id)>0:return result(false,"请先完成订单、培训、研发、派遣或装修，并将分店员工调回",{"cost":cost})
	var remaining: Array=m().employees.filter(func(other):return str(other.id)!=id and str(other.get("branch_id","")).is_empty())
	if remaining.size()<2:return result(false,"至少保留1名厨师和1名服务员，请先招聘接替人员",{"cost":cost})
	for role in ["chef","waiter"]:
		if not remaining.any(func(other):return str(other.role) in [role,"all"]):return result(false,"最小编制不足，必须保留1名厨师和1名服务员",{"cost":cost})
	return result(float(m().state.cash)>=cost,"" if float(m().state.cash)>=cost else "补偿及遣散费共￥%.2f，现金不足" % cost,{"cost":cost,"level":int(e.get("level",1)),"points":trained_points(e),"loyalty":float(e.loyalty)})
func dismiss(id: String) -> Dictionary:
	var quote=dismissal_quote(id)
	if not quote.ok:return quote
	var e: Dictionary=m()._employee(id)
	m().full_rules.management._suspend(e)
	m().change_cash(-float(quote.cost),"dismissal","解雇补偿及遣散费："+str(e.name));m().full_rules.record("expenses",float(quote.cost),"解雇补偿及遣散费")
	m().state.management.departed.append({"id":id,"day":now()/1440,"reason":"dismissal"})
	s().dismissals.append({"id":id,"minute":now(),"cost":float(quote.cost)})
	m().employees.erase(e);return quote
func task_progress(metric: String) -> float:
	match metric:
		"employees":return m().employees.size()
		"served":return float(m().state.served)
		"revenue":return float(m().state.total_revenue)
		"reputation":return float(m().state.reputation)
		"research":return float(m().state.get("stats",{}).get("research_success",0))
		"builds":return float(m().state.decorations_purchased)
		"membership":return 1 if m().state.expansion.membership.enabled else 0
		"delivery":return float(m().state.expansion.get("delivery_completed",0))
		"branches":return m().state.expansion.branches.values().filter(func(branch):return bool(branch.open)).size()
		"central":return 1 if m().state.expansion.central.enabled else 0
		"explorations":return m().state.expansion.get("exploration_history",[]).size()
		"awakening":return m().employees.filter(func(e):return bool(e.get("awakened",false))).size()
		"wins":return float(m().state.expansion.competition.wins)
	return 0
func current_task() -> Dictionary:
	for task in tasks:
		if int(task.stage)!=int(m().state.stage):continue
		if str(task.id) in s().task_completed:continue
		var progress=task_progress(str(task.metric))
		if progress>=float(task.target):s().task_completed.append(str(task.id));continue
		var entry: Dictionary=task.duplicate(true);entry.progress=progress;return entry
	return {}
func validate(saved: Dictionary,employees: Array) -> bool:
	if not saved.has("revision171"):return true
	var d: Variant=saved.revision171
	if not d is Dictionary or d.get("version")!=1:return false
	for key in ["builds","dismissals","task_completed"]:
		if not d.get(key) is Array:return false
	for key in ["next_build","completed_builds","daily_seen","peak_reputation"]:
		if not m()._integer(d.get(key)):return false
	if d.has("daily_pending") and not d.daily_pending is bool:return false
	if not d.get("daily_auto") is bool or not m()._number(d.get("baize_bonus")) or float(d.baize_bonus)<0 or float(d.baize_bonus)>100:return false
	var ids: Array=[];var workers: Array=[]
	for job in d.builds:
		if not job is Dictionary or not job.get("active") is bool or not job.active or not job.get("id") is String or not job.get("employee_id") is String:return false
		for key in ["serial","duration","remaining"]:
			if not m()._integer(job.get(key),1):return false
		if int(job.serial)>=int(d.next_build) or job.serial in ids or job.employee_id in workers or int(job.remaining)>int(job.duration):return false
		if m().full_rules.decoration(str(job.id)).is_empty():return false
		if not m()._integer(job.get("started")) or int(job.started)>int(saved.total_minutes):return false
		if employees.filter(func(e):return str(e.id)==str(job.employee_id) and int(e.get("construction_until",0))>int(saved.total_minutes)).size()!=1:return false
		if saved.layout.filter(func(item):return bool(item.get("building",false)) and int(item.get("build_id",0))==int(job.serial) and str(item.id)==str(job.id)).size()!=1:return false
		ids.append(job.serial);workers.append(job.employee_id)
	for item in saved.layout:
		if bool(item.get("building",false)) and not item.get("build_id",0) in ids:return false
	for employee in employees:
		if not m()._integer(employee.get("level"),1) or not m()._integer(employee.get("awakening_count")):return false
		if int(employee.level)>level_cap(employee):return false
		if int(employee.get("construction_until",0))>0 and not str(employee.id) in workers:return false
	for id in d.task_completed:
		if not id is String or not tasks.any(func(task):return str(task.id)==id):return false
	for entry in d.dismissals:
		if not entry is Dictionary or m()._employee_config(str(entry.get("id",""))).is_empty() or not m()._integer(entry.get("minute")) or not m()._number(entry.get("cost")) or float(entry.cost)<0:return false
	return true
