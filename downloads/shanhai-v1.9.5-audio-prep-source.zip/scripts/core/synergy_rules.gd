extends RefCounted
## v1.5 8.3. Effects are declarative; actual consumers remain authoritative.
## No proximity, random activation or duration is invented: only simultaneous duty.
var _model_ref: WeakRef
var config: Dictionary = {}

func _init(host: RefCounted, _rules: Variant = null) -> void:
	_model_ref = weakref(host)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/synergies.json"))
	if parsed is Dictionary: config = parsed

func _m() -> Variant: return _model_ref.get_ref()

func default_state() -> Dictionary:
	return {"version":1, "announced_pairs":[]}

func ensure_state() -> void:
	if not _m().state.get("synergies") is Dictionary: _m().state.synergies = default_state()
	for key in default_state():
		if not _m().state.synergies.has(key): _m().state.synergies[key] = default_state()[key]

func _active(id: String) -> bool:
	return _m().full_rules.active(id)

func active_pairs() -> Array:
	var result: Array = []
	for pair in config.get("pairs", []):
		var ready := true
		for id in pair.employee_ids:
			if not _active(str(id)): ready = false
		if ready: result.append(pair.duplicate(true))
	return result

func _matches(effect: Dictionary, context: Dictionary) -> bool:
	for key in ["category", "gender", "weather", "night", "employee_id"]:
		if effect.has(key) and effect[key] != context.get(key): return false
	return true

func sources(context: Dictionary = {}) -> Array:
	var result: Array = []
	for pair in active_pairs():
		for effect in pair.effects:
			if not _matches(effect, context): continue
			result.append({"source":"synergy:" + str(pair.id), "pair_id":str(pair.id), "effect":str(effect.effect), "value":float(_m().balance.get(str(effect.coeff_key), effect.value)), "kind":str(pair.kind)})
	return result

static func unique_bonus(effect: String, entries: Array) -> float:
	var positive := 0.0
	var negative := 0.0
	var seen: Dictionary = {}
	for entry in entries:
		if not entry is Dictionary or str(entry.get("effect", "")) != effect: continue
		var identity := str(entry.get("source", "")) + ":" + effect
		if seen.has(identity): continue
		seen[identity] = true
		var value := float(entry.get("value", 0))
		positive = maxf(positive, value)
		negative = minf(negative, value)
	return positive + negative

func bonus(effect: String, context: Dictionary = {}) -> float:
	return unique_bonus(effect, sources(context))

func modifier(effect: String, context: Dictionary = {}) -> float:
	return maxf(0.0, 1.0 + bonus(effect, context))

func tick_minute() -> Array:
	ensure_state()
	var current: Array = []
	var new_conflicts: Array = []
	for pair in active_pairs():
		current.append(str(pair.id))
		if str(pair.id) in _m().state.synergies.announced_pairs: continue
		_m()._log("排班%s：%s。%s" % [str(pair.kind), str(pair.name), str(pair.description)])
		if str(pair.kind) == "相克": new_conflicts.append(pair.duplicate(true))
	_m().state.synergies.announced_pairs = current
	return new_conflicts

func snapshot() -> Dictionary:
	var active := active_pairs()
	var conflicts: Array = []
	for pair in active:
		if str(pair.kind) == "相克": conflicts.append(pair.duplicate(true))
	return {"active_pairs":active, "conflicts":conflicts, "sources":sources(), "all_pairs":config.get("pairs", []).duplicate(true)}

func balance_defaults() -> Dictionary:
	var result: Dictionary = {}
	for pair in config.get("pairs", []):
		for effect in pair.effects: result[str(effect.coeff_key)] = float(effect.value)
	return result

func validate_balance(candidate: Dictionary) -> bool:
	var defaults := balance_defaults()
	for key in defaults:
		var value: Variant = candidate.get(key, defaults[key])
		if not (value is int or value is float) or not is_finite(float(value)): return false
		if float(value) < -1.0 or float(value) > 1.0: return false
	return true

func validate_state(saved: Dictionary, _employees: Array = [], _time: int = 0) -> bool:
	if saved.get("version") != 1 or not saved.get("announced_pairs") is Array: return false
	var known: Array = []
	for pair in config.get("pairs", []): known.append(str(pair.id))
	var seen: Array = []
	for id in saved.announced_pairs:
		if not id is String or not id in known or id in seen: return false
		seen.append(id)
	return true
