extends RefCounted
## v1.9.3: waiters order directly from the whole enabled menu; inventory never gates arrivals.
## The host owns motion, scheduler and deleting customers. This module owns only
## service decisions, sale-price arithmetic, and measured customer feedback.
var _model_ref: WeakRef
var model: Variant:
	get: return _model_ref.get_ref()
var config: Dictionary = {}
const PREFIX := "service."
const COEFFICIENT_ALIASES := {
	"service.feedback.out_of_stock_mood_penalty":"coeff.out_of_stock_mood_penalty",
	"service.feedback.out_of_stock_rep_penalty":"coeff.out_of_stock_rep_penalty",
	"service.feedback.stockout_traffic_decay":"coeff.stockout_traffic_decay"
}
const INTEGER_METRICS := ["arrivals", "orders", "completed", "stockouts", "good_reviews", "bad_reviews", "timeouts", "satisfaction_count", "recommend_attempts", "recommend_success", "premium_orders", "preference_matches"]
const REASONS := ["stockout", "timeout", "quality", "other"]

func _init(host: RefCounted) -> void:
	_model_ref = weakref(host)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/customer_service.json"))
	if parsed is Dictionary: config = parsed

func _value(path: String, fallback: float = 0) -> float:
	var value: Variant = config
	for part in path.split("."):
		if not value is Dictionary or not value.has(part): value = fallback; break
		value = value[part]
	var key: String = ("recommend." + path.trim_prefix("recommend.")) if path.begins_with("recommend.") else PREFIX + path
	if model != null and "balance" in model:
		var primary: String = str(COEFFICIENT_ALIASES.get(key, key))
		value = model.balance.get(primary, model.balance.get(key, value))
	return float(value) if _number(value) else fallback

func _now() -> int: return int(model.state.get("total_minutes", 0))
func _day() -> int: return _now() / maxi(1, int(model.balance.get("day.minutes", 1440)))
func _data() -> Dictionary: return model.state.customer_service
func _number(value: Variant) -> bool: return (value is int or value is float) and is_finite(float(value))
func _integer(value: Variant, minimum: int = 0) -> bool: return _number(value) and float(value) >= minimum and floorf(float(value)) == float(value)

func _blank_day(day: int) -> Dictionary:
	var result: Dictionary = {"day":day, "sales":0.0, "wait_minutes":0.0, "satisfaction_sum":0.0, "reasons":{"stockout":0, "timeout":0, "quality":0, "other":0}, "dish_orders":{}}
	for key in INTEGER_METRICS: result[key] = 0
	return result

func default_state() -> Dictionary:
	return {"version":1, "today":_blank_day(_day()), "history":[], "cooldowns":{}, "traffic_day":-1,
		"traffic_multiplier":1.0, "notices":[], "next_notice_id":1, "acknowledged_notice":0}

func ensure_state() -> void:
	if not model.state.has("customer_service"): model.state.customer_service = default_state()

func prepare_customer(customer: Dictionary) -> void:
	# Call after arrival; deliberately does not inspect inventory, recipes or menu.
	ensure_state()
	if bool(customer.get("service_arrival_recorded", false)): return
	customer.service_arrival_recorded = true
	customer.recommendation_done = bool(customer.get("recommendation_done", false))
	_data().today.arrivals = int(_data().today.arrivals) + 1

func _base_price(dish: Dictionary) -> float:
	return float(model.state.get("management", {}).get("base_prices", {}).get(str(dish.get("id", "")), dish.get("price", 0)))

func menu_dishes(available_only: bool = true) -> Array:
	var result: Array = []
	for id in model.state.get("menu_enabled", []):
		if not id in model.state.get("unlocked_dishes", []): continue
		var dish: Dictionary = model._dish(str(id))
		if dish.is_empty(): continue
		if not available_only or model.full_rules.management.can_make(str(id)): result.append(dish)
	return result

func basic_dishes(available_only: bool = true) -> Array:
	var result: Array = []
	for dish in menu_dishes(available_only):
		if _base_price(dish) <= _value("menu.basic_maximum_price", 10): result.append(dish)
	return result

func _weighted_dish(choices: Array, customer: Dictionary, high_margin: bool = false) -> Dictionary:
	if choices.is_empty(): return {}
	var profile: Dictionary = customer.get("preference_profile", {})
	var weights: Array[float] = []
	var total: float = 0
	for dish in choices:
		var weight: float = model.full_rules.preferences.dish_weight(dish, profile) * model.full_rules.effects.dish_weight(str(dish.id))
		weights.append(maxf(0.001, weight)); total += weights.back()
	var roll: float = model._rng.randf() * total
	for index in choices.size():
		roll -= weights[index]
		if roll < 0: return choices[index]
	return choices.back()

func order_pool(customer: Dictionary, available_only: bool=true) -> Array:
	return menu_dishes(available_only).filter(func(dish):return str(dish.id)!="jiuying_platter" or int(customer.get("group_size",1))>=3)

func choose_default_dish(customer: Dictionary) -> Dictionary:
	return _weighted_dish(order_pool(customer), customer)

func apply_choice(customer: Dictionary, dish: Dictionary) -> void:
	if dish.is_empty(): return
	customer.dish_id = str(dish.id)
	customer.price = float(dish.price)
	customer.dish_effects = model.full_rules.management.modifiers(str(dish.id))
	customer.preference_reasons = model.full_rules.preferences.explain(dish, customer.get("preference_profile", {}))
	customer.erase("effects_prepared")
	model.full_rules.effects.prepare_customer(customer)

# Retired API accepts old callers and saves; it never creates tasks, premiums or RNG draws.
func can_recommend(_employee: Dictionary, _customer: Dictionary = {}) -> bool:return false
func available_salesperson(_customer: Dictionary = {}) -> Dictionary:return {}
func recommendation_chance(_employee: Dictionary) -> float:return 0.0
func finish_recommendation(_customer: Dictionary, _employee: Dictionary) -> Dictionary:return {"ok":false,"reason":"荐菜机制已移除"}

func record_order(customer: Dictionary) -> void:
	ensure_state()
	if bool(customer.get("service_order_recorded", false)): return
	customer.service_order_recorded = true
	_data().today.orders = int(_data().today.orders) + 1
	var id: String = str(customer.get("dish_id", ""))
	_data().today.dish_orders[id] = int(_data().today.dish_orders.get(id, 0)) + 1
	var dish: Dictionary = model._dish(id)
	var profile: Dictionary = customer.get("preference_profile", {})
	var match_found: bool = false
	for tag in dish.get("taste_tags", []):
		if tag in profile.get("tastes", []): match_found = true
	for tag in dish.get("need_tags", []):
		if tag in profile.get("needs", []): match_found = true
	customer.preference_matched = match_found
	if match_found:
		_data().today.preference_matches = int(_data().today.preference_matches) + 1
		customer.satisfaction = clampf(float(customer.get("satisfaction", _value("feedback.initial_satisfaction", 50))) + _value("feedback.preference_match_satisfaction", 3), 0, 100)

func _notice(customer: Dictionary, dish: Dictionary, text: String, kind: String) -> void:
	var serial: int = int(_data().next_notice_id)
	_data().next_notice_id = serial + 1
	_data().notices.append({"serial":serial, "minute":_now(), "customer_id":int(customer.get("id", 0)), "dish_id":str(dish.get("id", "")), "text":text, "kind":kind})
	while _data().notices.size() > int(_value("feedback.notice_limit", 40)): _data().notices.pop_front()
	model._notify(text)

func stockout(customer: Dictionary, dish: Dictionary = {}) -> Dictionary:
	ensure_state()
	if bool(customer.get("stockout_recorded", false)):
		_record_satisfaction(customer)
		return {"ok":false, "leave":true, "changed":false, "reason":"替代菜也已售罄，食客离店"}
	if dish.is_empty(): dish = model._dish(str(customer.get("dish_id", "")))
	customer.stockout_recorded = true
	customer.satisfaction = clampf(float(customer.get("satisfaction", _value("feedback.initial_satisfaction", 50))) + _value("feedback.out_of_stock_mood_penalty", -10), 0, 100)
	_data().today.stockouts = int(_data().today.stockouts) + 1
	var bad_review: bool = model._rng.randf() < _value("feedback.stockout_bad_review_chance", 0.3)
	if bad_review:
		model.state.reputation = maxi(0, int(model.state.reputation) + int(_value("feedback.out_of_stock_rep_penalty", -2)))
		_record_review("stockout", false)
	var alternatives: Array = basic_dishes(true).filter(func(entry): return str(entry.id) != str(dish.get("id", "")))
	var alternative: Dictionary = _weighted_dish(alternatives, customer)
	var text: String = "食材不足：%s售罄。食客心情%d" % [str(dish.get("name", "当前菜品")), int(_value("feedback.out_of_stock_mood_penalty", -10))]
	if bad_review: text += "，缺货差评，声望%d" % int(_value("feedback.out_of_stock_rep_penalty", -2))
	if not alternative.is_empty():
		apply_choice(customer, alternative)
		customer.recommendation_success = false; customer.recommendation_premium = 0.0
		text += "，改点" + str(alternative.name)
	else:
		text += "，食客离店"
		_record_satisfaction(customer)
	_notice(customer, dish, text, "stockout")
	return {"ok":true, "changed":not alternative.is_empty(), "dish_id":str(alternative.get("id", "")), "leave":alternative.is_empty(), "bad_review":bad_review}

func _record_review(reason: String, good: bool) -> void:
	if good: _data().today.good_reviews = int(_data().today.good_reviews) + 1
	else:
		_data().today.bad_reviews = int(_data().today.bad_reviews) + 1
		_data().today.reasons[reason if reason in REASONS else "other"] = int(_data().today.reasons.get(reason, 0)) + 1

func _record_satisfaction(customer: Dictionary) -> void:
	if bool(customer.get("service_feedback_recorded", false)): return
	customer.service_feedback_recorded = true
	var waited: float = maxf(0, float(customer.get("served_minute", _now())) - float(customer.get("arrival_minute", _now())))
	var score: float = clampf(float(customer.get("satisfaction", _value("feedback.initial_satisfaction", 50))) - waited * _value("feedback.waiting_satisfaction_per_minute", 0.1), 0, 100)
	_data().today.wait_minutes = float(_data().today.wait_minutes) + waited
	_data().today.satisfaction_sum = float(_data().today.satisfaction_sum) + score
	_data().today.satisfaction_count = int(_data().today.satisfaction_count) + 1

func record_sale(customer: Dictionary, amount: float, review: float) -> void:
	ensure_state()
	if bool(customer.get("service_sale_recorded", false)): return
	customer.service_sale_recorded = true
	_data().today.completed = int(_data().today.completed) + 1
	_data().today.sales = float(_data().today.sales) + maxf(0, amount)
	if review > 0:
		_record_review("other", true)
		customer.satisfaction = clampf(float(customer.get("satisfaction", 50)) + _value("feedback.satisfaction_good_review", 5), 0, 100)
	elif review < 0:
		_record_review("quality" if float(customer.get("quality", 75)) < float(model.balance.get("dish.quality_poor_threshold", 60)) else "other", false)
		customer.satisfaction = clampf(float(customer.get("satisfaction", 50)) + _value("feedback.satisfaction_bad_review", -5), 0, 100)
	_record_satisfaction(customer)

func record_timeout(customer: Dictionary, complained: bool = true) -> void:
	ensure_state()
	if bool(customer.get("service_timeout_recorded", false)): return
	customer.service_timeout_recorded = true
	_data().today.timeouts = int(_data().today.timeouts) + 1
	if complained: _record_review("timeout", false)
	_record_satisfaction(customer)

func daily_rollover() -> void:
	ensure_state()
	if int(_data().today.day) == _day(): return
	var previous: Dictionary = _data().today.duplicate(true)
	previous.satisfaction = satisfaction(previous)
	_data().history.append(previous)
	while _data().history.size() > int(_value("feedback.history_limit", 30)): _data().history.pop_front()
	_data().traffic_day = _day()
	_data().traffic_multiplier = maxf(0.01, 1.0 + _value("feedback.stockout_traffic_decay", -0.05)) if int(previous.stockouts) >= int(_value("feedback.stockout_daily_threshold", 3)) else 1.0
	_data().today = _blank_day(_day())
	for id in _data().cooldowns.keys():
		if int(_data().cooldowns[id]) <= _now(): _data().cooldowns.erase(id)

func traffic_multiplier() -> float:
	ensure_state()
	return float(_data().traffic_multiplier) if int(_data().traffic_day) == _day() else 1.0

func satisfaction(day: Dictionary = {}) -> float:
	if day.is_empty(): day = _data().today
	return float(day.satisfaction_sum) / int(day.satisfaction_count) if int(day.get("satisfaction_count", 0)) > 0 else _value("feedback.initial_satisfaction", 50)

func snapshot() -> Dictionary:
	ensure_state()
	var sold_out: Array = []
	for dish in menu_dishes(false):
		if not model.full_rules.management.can_make(str(dish.id)): sold_out.append({"id":str(dish.id), "name":str(dish.name)})
	return {"today":_data().today.duplicate(true), "history":_data().history.duplicate(true), "notices":_data().notices.duplicate(true), "acknowledged_notice":int(_data().acknowledged_notice), "satisfaction":satisfaction(),
		"reputation_damaged":int(_data().today.stockouts) >= int(_value("feedback.stockout_daily_threshold", 3)),
		"next_day_traffic_multiplier":1.0 + _value("feedback.stockout_traffic_decay", -0.05) if int(_data().today.stockouts) >= int(_value("feedback.stockout_daily_threshold", 3)) else 1.0,
		"current_traffic_multiplier":traffic_multiplier(), "sold_out":sold_out}

func can(action: String, _args: Dictionary = {}) -> Dictionary:
	return {"ok":action == "feedback_ack", "reason":"" if action == "feedback_ack" else "未知顾客服务操作"}
func perform(action: String, args: Dictionary = {}) -> Dictionary:
	var result: Dictionary = can(action, args)
	if result.ok:
		ensure_state()
		_data().acknowledged_notice = int(_data().next_notice_id) - 1
	return result

func _best_source(sources: Dictionary) -> Dictionary:
	var positive: float = 0
	var negative: float = 0
	var positive_id: String = ""
	var negative_id: String = ""
	for id in sources:
		if not _number(sources[id]): continue
		var value: float = float(sources[id])
		if value > positive: positive = value; positive_id = str(id)
		if value < negative: negative = value; negative_id = str(id)
	return {"value":positive + negative, "positive_source":positive_id, "negative_source":negative_id, "sources":sources.duplicate(true)}

func quality_price(quality: float) -> float:
	if quality < float(model.balance.get("dish.quality_poor_threshold", 60)): return _value("price.quality_poor", 0.8)
	if quality < float(model.balance.get("dish.quality_good_threshold", 80)): return _value("price.quality_medium", 1)
	if quality < float(model.balance.get("dish.quality_excellent_threshold", 90)): return _value("price.quality_good", 1.15)
	return _value("price.quality_excellent", 1.3)

func collect_price_sources(dish: Dictionary, chef: Dictionary = {}, cashier: Dictionary = {}) -> Dictionary:
	# Keep raw source identities. Do not use world.modifier("price"), which
	# already combines bonds with events and would count a bond twice.
	var sources: Dictionary = {"period":{}, "bond":{}, "skill":{}}
	var period: String = str(model.period())
	var period_bonus: float = _value("price.period_" + period)
	if period_bonus != 0: sources.period["period:" + period] = period_bonus
	var world = model.full_rules.world
	var category: String = str(dish.get("category", ""))
	var chef_id: String = str(chef.get("id", ""))
	var cashier_id: String = str(cashier.get("id", ""))
	for bond in world.active_bonds():
		for index in bond.get("effects", []).size():
			var effect: Dictionary = bond.effects[index]
			if not str(effect.get("type", "")) in ["price", "price_bonus"]: continue
			if not world._effect_matches(effect, category, chef_id) and not world._effect_matches(effect, category, cashier_id): continue
			var fallback: float = world._b(str(effect.get("coeff_key", ""))) if str(effect.get("coeff_key", "")) != "" else 0.0
			sources.bond["bond:%s:%d" % [str(bond.id),index]] = world._value(effect, "value", fallback)
	for index in model.state.get("world", {}).get("modifiers", []).size():
		var effect: Dictionary = model.state.world.modifiers[index]
		if int(effect.get("until", 0)) <= _now() or str(effect.get("key", "")) != "price": continue
		if not world._effect_matches(effect, category, chef_id) and not world._effect_matches(effect, category, cashier_id): continue
		var identity: String = str(effect.get("identity", "event:%d" % index))
		sources.skill["event:" + identity] = world._value(effect, "value") * float(effect.get("sign", 1))
	var permanent: float = float(model.state.get("price_bonus", 0))
	if permanent != 0: sources.skill["restaurant:permanent_price"] = permanent
	var hidden: String = str(model.state.get("management", {}).get("hidden_effects", {}).get(str(dish.get("id", "")), ""))
	if hidden == "price_mult": sources.skill["dish:" + str(dish.id) + ":hidden_price"] = model.full_rules.management.coefficient("hidden_choice_price")
	if str(dish.get("id", "")) == "qiongqi_hotpot" and not chef.is_empty():
		var extra: Dictionary = model.full_rules.management.employee_effects(chef)
		var premium: float = float(extra.get("spicy_price_bonus", 0))
		if premium != 0: sources.skill["employee:" + chef_id + ":spicy_price"] = premium
	if not cashier.is_empty():
		var bonus: float = float(model.full_rules.checkout_multiplier(cashier)) - 1.0
		if bonus != 0: sources.skill["employee:" + cashier_id + ":checkout"] = bonus
	return sources

func price_quote(dish: Dictionary, quality: float, customer: Dictionary, per_customer: Dictionary = {}, global_sources: Dictionary = {}) -> Dictionary:
	# Explicit stages implement revised 12.14: integer floor at EVERY step.
	# global_sources = {period:{source_id:bonus},bond:{...},skill:{...}}.
	var base: float = _base_price(dish)
	var asking: float = float(dish.get("price", base))
	var quality_mult: float = quality_price(quality)
	var personal_sources: Dictionary = {}
	var personal_bonus: float = 0
	var resolved: Dictionary = {}
	var global_bonus: float = 0
	for bucket in ["period", "bond", "skill"]:
		resolved[bucket] = _best_source(global_sources.get(bucket, {}))
		global_bonus += float(resolved[bucket].value)
	global_bonus = clampf(global_bonus, -1, _value("price.global_bonus_cap", 1))
	var type_mult: float = _value("price.type_" + str(customer.get("type", "human")), 1)
	var stages: Dictionary = {"base":maxf(0, floorf(asking)), "quality":0.0, "per_customer":0.0, "global":0.0, "type":0.0, "cap":maxf(0, floorf(base * _value("price.customer_multiplier_cap", 8)))}
	stages.quality = maxf(0, floorf(float(stages.base) * quality_mult + 0.000000001))
	stages.per_customer = maxf(0, floorf(float(stages.quality) * (1 + personal_bonus) + 0.000000001))
	stages.global = maxf(0, floorf(float(stages.per_customer) * (1 + global_bonus) + 0.000000001))
	stages.type = maxf(0, floorf(float(stages.global) * type_mult + 0.000000001))
	var result: float = minf(float(stages.type), float(stages.cap))
	return {"base":base, "asking":asking, "quality_multiplier":quality_mult, "per_customer_bonus":personal_bonus, "per_customer_sources":personal_sources, "global_bonus":global_bonus,
		"global_sources":resolved, "type_multiplier":type_mult, "stages":stages, "cap":float(stages.cap), "capped":float(stages.type) > float(stages.cap), "final":result}

func balance_defaults() -> Dictionary:
	var result: Dictionary = {}
	for section in ["feedback", "price"]:
		for key in config.get(section, {}):
			var value: Variant = config[section][key]
			var prefix: String = PREFIX + section + "."
			if _number(value): result[prefix + str(key)] = value
			elif value is Dictionary:
				for id in value:
					if _number(value[id]): result[prefix + str(key) + "." + str(id)] = value[id]
	for alias in COEFFICIENT_ALIASES: result[COEFFICIENT_ALIASES[alias]] = result[alias]
	return result

func validate_balance(candidate: Dictionary) -> bool:
	var defaults: Dictionary = balance_defaults()
	var values: Dictionary = defaults.duplicate(true)
	for key in candidate:
		if str(key).begins_with("recommend.") or str(key).begins_with("coeff.recommend_"):return false
		if not str(key).begins_with(PREFIX) and not str(key).begins_with("recommend.") and not key in COEFFICIENT_ALIASES.values(): continue
		if not defaults.has(key) or not _number(candidate[key]): return false
		values[key] = candidate[key]
	# A candidate may use either documented spelling. When both are supplied,
	# the 12.11 coefficient is authoritative, matching runtime lookups.
	for alias in COEFFICIENT_ALIASES:
		var primary: String = COEFFICIENT_ALIASES[alias]
		if candidate.has(primary): values[alias] = candidate[primary]
		elif candidate.has(alias): values[primary] = candidate[alias]
	var negative_keys: Array = ["service.feedback.out_of_stock_mood_penalty", "service.feedback.out_of_stock_rep_penalty", "service.feedback.stockout_traffic_decay", "service.feedback.satisfaction_bad_review"]
	var integer_keys: Array = ["service.feedback.stockout_daily_threshold", "service.feedback.history_limit", "service.feedback.notice_limit"]
	for key in values:
		if key in COEFFICIENT_ALIASES.values(): continue
		var value: float = float(values[key])
		if key in negative_keys:
			if value > 0: return false
		elif value < 0: return false
		if key in integer_keys and (value <= 0 or value != floorf(value)): return false
		if ("chance" in str(key) or "cost_ratio" in str(key) or str(key) in ["recommend.eloquence_bonus", "recommend.price_premium"] or str(key).begins_with("recommend.skills.")) and value > 1: return false
		if str(key).begins_with("service.price.quality_") and value <= 0: return false
		if str(key).begins_with("service.price.type_") and (value <= 0 or value > 8): return false
	if float(values["service.feedback.stockout_traffic_decay"]) <= -1: return false
	if float(values["service.price.customer_multiplier_cap"]) < 1 or float(values["service.price.customer_multiplier_cap"]) > 8: return false
	if float(values["service.price.global_bonus_cap"]) > 1: return false
	if float(values["service.feedback.initial_satisfaction"]) > 100: return false
	if not float(values["service.price.quality_poor"]) <= float(values["service.price.quality_medium"]) or not float(values["service.price.quality_medium"]) <= float(values["service.price.quality_good"]) or not float(values["service.price.quality_good"]) <= float(values["service.price.quality_excellent"]): return false
	return true

func _valid_day(day: Variant) -> bool:
	if not day is Dictionary or not _integer(day.get("day")): return false
	for key in INTEGER_METRICS:
		if not _integer(day.get(key)): return false
	for key in ["sales", "wait_minutes", "satisfaction_sum"]:
		if not _number(day.get(key)) or float(day[key]) < 0: return false
	if float(day.satisfaction_sum) > int(day.satisfaction_count) * 100 + 0.001: return false
	if not day.get("reasons") is Dictionary or not day.get("dish_orders") is Dictionary: return false
	var bad_total: int = 0
	for key in REASONS:
		if not _integer(day.reasons.get(key)): return false
		bad_total += int(day.reasons[key])
	if bad_total != int(day.bad_reviews): return false
	for id in day.dish_orders:
		if model._dish(str(id)).is_empty() or not _integer(day.dish_orders[id]): return false
	if int(day.recommend_success) > int(day.recommend_attempts) or int(day.premium_orders) > int(day.recommend_success): return false
	return true

func validate_state(saved: Dictionary, saved_employees: Array = [], _saved_scheduler: Array = []) -> bool:
	if not saved.get("customer_service") is Dictionary: return false
	var data: Dictionary = saved.customer_service
	if not _integer(data.get("version"), 1) or int(data.version) != 1 or not _valid_day(data.get("today")): return false
	if not data.get("history") is Array or data.history.size() > int(_value("feedback.history_limit", 30)): return false
	for day in data.history:
		if not _valid_day(day): return false
	if not data.get("cooldowns") is Dictionary: return false
	for id in data.cooldowns:
		# A worker may resign or be dismissed during its three-minute cooldown.
		# The key is a known catalogue identity, not a live employee reference.
		if model._employee_config(str(id)).is_empty() or not _integer(data.cooldowns[id]): return false
	if not _integer(data.get("traffic_day"), -1) or not _number(data.get("traffic_multiplier")) or float(data.traffic_multiplier) <= 0 or float(data.traffic_multiplier) > 1: return false
	if not data.get("notices") is Array or data.notices.size() > int(_value("feedback.notice_limit", 40)): return false
	if not _integer(data.get("next_notice_id"), 1) or not _integer(data.get("acknowledged_notice")) or int(data.acknowledged_notice) >= int(data.next_notice_id): return false
	var previous: int = 0
	for notice in data.notices:
		if not notice is Dictionary or not _integer(notice.get("serial"), 1) or int(notice.serial) <= previous or int(notice.serial) >= int(data.next_notice_id): return false
		if not _integer(notice.get("minute")) or not _integer(notice.get("customer_id")) or not notice.get("dish_id") is String or not notice.get("text") is String or not notice.get("kind") is String: return false
		previous = int(notice.serial)
	return true
