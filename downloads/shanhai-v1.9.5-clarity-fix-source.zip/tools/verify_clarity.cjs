/* Read-only QA snapshots; all navigation uses physical mouse clicks and wheels. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const base = (process.env.SHANHAI_QA_URL || 'http://127.0.0.1:8004').replace(/\/$/, '');
const out = process.argv[2] || 'build/v195-browser';

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const actions = [], checks = [], errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  const state = () => page.evaluate(() => window.shanhaiQAState);
  async function sync() {
    for (let frame = 0; frame < 2; frame++) {
      const previous = await page.evaluateHandle(() => window.shanhaiQAState);
      try { await page.waitForFunction(value => window.shanhaiQAState !== value, previous, { timeout: 10000 }); }
      finally { await previous.dispose(); }
    }
  }
  async function check(label, predicate) {
    await page.waitForFunction(predicate, undefined, { timeout: 10000 });
    checks.push({ label, ok: true });
  }
  async function point(rect) {
    return page.evaluate(rect => {
      const t = window.shanhaiQAState.screen_transform;
      const c = document.querySelector('canvas'), r = c.getBoundingClientRect();
      const x = rect.x + rect.w / 2, y = rect.y + rect.h / 2;
      return { x: r.x + (t.a*x+t.c*y+t.tx)*r.width/c.width, y: r.y + (t.b*x+t.d*y+t.ty)*r.height/c.height };
    }, rect);
  }
  async function wheel(delta) {
    const s = await state(), p = await point({ x: s.viewport.w*.6, y: s.viewport.h*.64, w: 0, h: 0 });
    await page.mouse.move(p.x,p.y); await page.mouse.wheel(0,delta); actions.push({ wheel: delta }); await sync();
  }
  async function click(id, reset = false) {
    if (id === 'kitchen:open' && !(await state()).buttons.some(b=>b.qa_id===id)) await click('status:summary');
    if (id.startsWith('time:') && /^time:[1-4]$/.test(id) && !(await state()).buttons.some(b=>b.qa_id===id)) await click('time:menu');
    if (reset) await wheel(-20000);
    let b;
    for (let attempt = 0; attempt < 50; attempt++) {
      const s = await state();
      b = s.buttons.find(b => b.qa_id === id && !b.disabled);
      if (b) break;
      await wheel(s.viewport.h < 500 ? 80 : 160);
    }
    if (!b) throw Error('Enabled visible control missing: ' + id);
    const p = await point(b.rect);
    await page.mouse.click(p.x,p.y); actions.push({ click: id, rect: b.rect, point: p }); await sync();
    fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({ last: actions.at(-1), panel: (await state()).panel, checks: checks.length }));
  }
  async function sceneReady() {
    for(let attempt=0;attempt<10;attempt++){
      const s=await state();if(!s.panel)return;
      const event=s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled&&b.qa_id.endsWith(':1'))||s.buttons.find(b=>b.qa_id.startsWith('event:')&&!b.disabled);
      if(event)await click(event.qa_id);
      else if(s.buttons.some(b=>b.qa_id==='panel:close'&&!b.disabled))await click('panel:close');
      else throw Error('Unresolved natural interruption during pickup verification: '+s.panel);
    }
  }
  async function shot(name) { await page.screenshot({ path: path.join(out,name+'.png') }); }
  let receipt;const samples=[];
  const overlaps=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
  async function inspect(){const s=await state();for(const bubble of s.experience.bubbles){if(!bubble.visible)continue;for(const rect of s.experience.bubble_exclusion_rects||[])if(overlaps(bubble.rect,rect))throw Error('Speech overlaps a person');samples.push(bubble);}return s;}
  try{
    receipt=await(await page.request.get(base+'/export-receipt.json')).json();
    await page.goto(base+'/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
    await click('start:full');await click('tutorial:ack');await click('nav:员工');await click('panel:close');await click('tutorial:ack');
    await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');if((await state()).panel)await click('panel:close');
    await page.waitForFunction(()=>window.shanhaiQAState?.state.served>=1,undefined,{timeout:60000});
    if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');
    await click('tutorial:ack');await click('tutorial:destination');await click('tutorial:ack');await click('panel:close');
    const s=await inspect();if(s.text_rendering?.body_font!=='NotoSansSC'||s.text_rendering.scene_text_scales_with_map!==false)throw Error('Scene text is still scaled pixel text');checks.push({label:'Scalable CJK font and screen-size scene text are active',ok:true});if(s.buttons.some(b=>b.qa_id.startsWith('scene:')))throw Error('Old pan buttons remain');
    const r=s.dollhouse.viewport;const from=await point({x:r.x+r.w*.72,y:r.y+r.h*.70,w:0,h:0});const to={x:from.x-110,y:from.y-55};
    await page.mouse.move(from.x,from.y);await page.mouse.down();await page.mouse.move(to.x,to.y,{steps:15});await page.mouse.up();await sync();
    actions.push({drag:{from,to,button:'left'}});const shifted=await inspect();
    if(Math.abs(shifted.dollhouse.camera.x-s.dollhouse.camera.x)<10)throw Error('Left drag did not pan');
    checks.push({label:'Physical left mouse drag pans the scene without buttons',ok:true});
    await page.waitForTimeout(500);await sync();if((await state()).dollhouse.camera.x!==shifted.dollhouse.camera.x)throw Error('Camera drifts after release');
    checks.push({label:'Camera stops when mouse releases',ok:true});
    const directions=new Set(shifted.dollhouse.chairs.map(c=>c.direction));if(!directions.has('left')||!directions.has('right'))throw Error('Chairs do not face one another');
    checks.push({label:'Opposing seats face toward their shared tabletop',ok:true});await shot('desktop-scene');if(shifted.dollhouse.pinned_conflicts!==0)throw Error('A working person occupies a seated diner');checks.push({label:'Active service and seated diners keep distinct fixed positions',ok:true});
    for(let i=0;i<18;i++){await page.waitForTimeout(1000);await inspect();}
    checks.push({label:'Sampled visible speech avoids actor body/name bounds',ok:true,samples:samples.length});await shot('desktop-bubbles');
    await click('nav:员工');await shot('desktop-employees');await click('panel:close');
    await page.setViewportSize({width:1280,height:800});await sync();await shot('window-1280');checks.push({label:'Inspected common 1280x800 window',ok:true});await page.setViewportSize({width:844,height:390});await sync();await inspect();await shot('mobile-scene');
    const mobile=(await state()).dollhouse.viewport;const p=await point({x:mobile.x+mobile.w*.65,y:mobile.y+mobile.h*.65,w:0,h:0});
    await page.mouse.move(p.x,p.y);await page.mouse.down();await page.mouse.move(p.x-70,p.y-20,{steps:10});await page.mouse.up();await sync();await inspect();
    checks.push({label:'Mobile landscape viewport retains direct mouse pan and safe speech',ok:true});
    fs.writeFileSync(path.join(out,'final-state.json'),JSON.stringify(await state(),null,2));
  }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify(await state(),null,2));}
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt?.game_source,actions,checks,samples,errors},null,2));console.log(JSON.stringify({actions:actions.length,checks:checks.length,speech_samples:samples.length,errors}));await browser.close();if(errors.length)process.exitCode=1;
})();
