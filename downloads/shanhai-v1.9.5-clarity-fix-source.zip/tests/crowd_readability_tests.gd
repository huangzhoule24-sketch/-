extends SceneTree
const Model = preload("res://scripts/core/game_model.gd")
const Space = preload("res://scripts/services/restaurant_space.gd")
const Crowd = preload("res://scripts/ui/crowd_presentation.gd")
const View = preload("res://scripts/ui/restaurant_view.gd")
var checks = 0
var failures = 0
func _init(): call_deferred("run")
func expect(ok: bool, message: String):
	checks += 1
	if not ok: failures += 1; push_error(message)
func run():
	var m = Model.new(20261028); m.start_full(); m.events.clear()
	var dense = m.state.layout.duplicate(true)
	dense.append({"id":"table_two","x":4,"y":1,"w":1,"h":1})
	expect(not Space.layout_is_safe(m,dense),"New table placements cannot squeeze adjacent diners into one body space")
	for seat in range(int(m.state.seats)):
		var point = Space.service_point(m,seat)
		expect(point.distance_to(Space.seat_position(m,seat)) >= 40,"Service endpoint is separate from the diner")
		expect(not Space.find_route(m,Space.entry_position(m),point).blocked,"Separated service endpoint remains reachable")
		for other in range(int(m.state.seats)):
			expect(not Crowd.overlaps(point,Space.seat_position(m,other)),"Service worker does not occupy any diner's body space")
	# Seated and working actors are fixed. Three moving kinds share the avoidance lanes.
	var center = Vector2(480,440)
	var entries = [{"key":"guest:seated","point":center,"pinned":true},
		{"key":"staff:working","point":center+Vector2(110,0),"pinned":true},
		{"key":"staff:walking","point":center,"pinned":false},
		{"key":"guest:walking","point":center,"pinned":false},
		{"key":"leaving:walking","point":center,"pinned":false}]
	var crowd = Crowd.new(); var before = JSON.stringify(m.state); var rng = m._rng.state
	crowd.update(m,entries,.016)
	expect(crowd.point("guest:seated",Vector2.ZERO)==center,"Diners stay attached to their actual chairs")
	expect(crowd.point("staff:working",Vector2.ZERO)==center+Vector2(110,0),"Working hands stay at the actual equipment")
	for i in range(entries.size()):
		for j in range(i+1,entries.size()):
			expect(not Crowd.overlaps(crowd.positions[entries[i].key],crowd.positions[entries[j].key]),"Shared lanes separate simultaneous walking staff, arrivals and departures")
	var stable = crowd.positions.duplicate()
	for frame in range(60): crowd.update(m,entries,.016)
	expect(stable==crowd.positions,"An unchanged crowd cannot oscillate between lanes")
	for offset in crowd.offsets.values(): expect(offset.length()<=53,"Visual sidesteps remain local rather than relocating workers")
	expect(before==JSON.stringify(m.state) and rng==m._rng.state,"Avoidance does not alter simulation data or random outcomes")
	var arriving = [{"key":"staff:arriving","point":center,"pinned":false,"radius":2.0},{"key":"guest:fixed","point":center,"pinned":true}]
	crowd.update(m,arriving,.016)
	expect(crowd.offsets["staff:arriving"].length()<=2,"Approach lanes taper before an interaction rather than snapping back at work start")
	var font = load("res://assets/fonts/ReadableUI.tres")
	expect(font.base_font.resource_path.ends_with("NotoSansSC.otf"),"Small UI text uses a scalable Chinese font")
	for character in "饕餮貔貅羬羊讹兽账单培训装修文化简介":
		expect(font.has_char(character.unicode_at(0)),"UI font covers common and rare game names")
	# Actual busy play: service completes and visual observation preserves equipment and state.
	m.state.stage=1; m.state.cash=10000; m.balance["customer.base_flow"]=20
	m.full_rules.management.purchase("generic",500)
	var view = View.new(); view.model=m; view.font=font; view.size=Vector2(1200,600)
	root.add_child(view); view.set_process(false)
	var peak = 0; var pinned_conflicts = 0; var moving_frames = 0
	for minute in range(120):
		m.advance_minutes(1); peak=maxi(peak,m.customers.size())
		for frame in range(5):
			view._update_employee_animation(.05); view._resolve_actor_spacing(.05)
			pinned_conflicts=maxi(pinned_conflicts,view.crowd.pinned_conflicts)
			for actor in view._actors.values():
				if actor.action=="Move": moving_frames+=1
				else: expect(actor.display_position==actor.position,"Stationary work never gets a cosmetic displacement")
	expect(moving_frames>0 and peak>=4 and m.state.served>0,"Live simulation exercises motion, multiple diners and completed sales")
	expect(pinned_conflicts==0,"Normal new-game service has no fixed worker/diner overlap")
	view.queue_free(); await process_frame
	var report={"checks":checks,"failures":failures,"minutes":120,"peak_guests":peak,"served":m.state.served,"moving_actor_frames":moving_frames,"peak_pinned_conflicts":pinned_conflicts}
	FileAccess.open("res://build/crowd-readability-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Crowd readability: ",JSON.stringify(report)); quit(1 if failures else 0)
