/* Real navigation and clicks; QA observations never mutate game state. */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const base=(process.env.SHANHAI_QA_URL||'http://127.0.0.1:8039/game').replace(/\/$/,'');
const out=process.argv[2]||'build/web-r3/portrait-browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-timer-throttling','--disable-renderer-backgrounding']});const page=await browser.newPage({viewport:{width:1440,height:900}}),actions=[],checks=[],errors=[],entries=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});const state=()=>page.evaluate(()=>window.shanhaiQAState);
 async function sync(){for(let i=0;i<2;i++){const old=await page.evaluateHandle(()=>window.shanhaiQAState);try{await page.waitForFunction(x=>window.shanhaiQAState!==x,old,{timeout:15000})}finally{await old.dispose()}}}
 async function point(r){return page.evaluate(r=>{const t=window.shanhaiQAState.screen_transform,c=document.querySelector('canvas'),v=c.getBoundingClientRect();return{x:v.x+(t.a*(r.x+r.w/2)+t.c*(r.y+r.h/2)+t.tx)*v.width/c.width,y:v.y+(t.b*(r.x+r.w/2)+t.d*(r.y+r.h/2)+t.ty)*v.height/c.height}},r)}
 async function wheel(n){const s=await state(),p=await point({x:s.viewport.w*.6,y:s.viewport.h*.6,w:0,h:0});await page.mouse.move(p.x,p.y);await page.mouse.wheel(0,n);await sync()}
 async function click(id,reset=false){await sync();if(reset)await wheel(-20000);let b;for(let i=0;i<65;i++){b=(await state()).buttons.find(x=>x.qa_id===id&&!x.disabled);if(b)break;await wheel((await state()).viewport.h<500?85:210)}if(!b)throw Error('Missing visible control: '+id);await page.mouse.click(...Object.values(await point(b.rect)));actions.push(id);await sync();fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({last:id,checks:checks.length}));}
 function check(ok,label){checks.push({label,ok});if(!ok)throw Error(label)}
 async function shot(name){await page.screenshot({path:path.join(out,name+'.png')})}
 let receipt;
 try{
  receipt=await(await page.request.get(base+'/export-receipt.json')).json();await page.goto(base+'/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
  await click('locale:en');await click('start:full');await click('tutorial:ack');await click('nav:员工');await click('panel:close');await click('tutorial:ack');await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');if((await state()).panel)await click('panel:close');
  await page.waitForFunction(()=>window.shanhaiQAState?.state.served>=1,undefined,{timeout:120000});check(true,'Real opening service completes');
  if(!(await state()).state.tutorial.completed_steps.includes('first_order')){
   await page.waitForFunction(()=>window.shanhaiQAState.state.tutorial.ready_to_ack.includes('first_order')||window.shanhaiQAState.state.tutorial.completed_steps.includes('first_order'),undefined,{timeout:15000});
   if(!(await state()).state.tutorial.completed_steps.includes('first_order'))await click('tutorial:ack');
  }
  if(!(await state()).state.tutorial.completed_steps.includes('income')){await click('tutorial:ack');await page.waitForFunction(()=>window.shanhaiQAState.state.tutorial.completed_steps.includes('income'),undefined,{timeout:15000});}
  if(!(await state()).state.tutorial.completed_steps.includes('bill')){await click('tutorial:destination');await click('tutorial:ack');}
  if((await state()).panel)await click('panel:close');await click('nav:更多');await click('full:open:图鉴',true);
  const all=JSON.parse(fs.readFileSync('config/employees.json','utf8'));
  const selected=(process.env.SHANHAI_PORTRAIT_IDS||'').split(',').filter(Boolean);
  const catalog=selected.length?all.filter(e=>selected.includes(e.id)):all;
  check(catalog.length===(selected.length||30),'Requested employee coverage is available');
  for(const e of catalog){
   await click('culture:employees:'+e.id);const s=await state(),entry=s.culture_entry;entries.push(entry);
   check(entry.id===e.id&&entry.image_resource_id==='Sprites/'+e.id+'/idle_down_0'&&entry.image_style==='pixel'&&entry.image_crop.h>0&&entry.image_crop.y+entry.image_crop.h<=80,'Matching complete pixel portrait: '+e.id);
   if(['feng_huang','qing_fu','bi_fang'].includes(e.id))await shot(e.id+'-culture');
   if(e.id==='qing_fu'){
    await click('culture:language:en');check((await state()).culture_entry.image_resource_id===entry.image_resource_id,'English keeps the same portrait');
    await page.setViewportSize({width:844,height:390});await sync();check((await state()).culture_entry.image_style==='pixel','Small landscape retains the head');await shot('qing-fu-mobile');await page.setViewportSize({width:1440,height:900});await sync();await click('culture:language:zh');
   }
   await click('culture:back');check((await state()).panel==='图鉴','Culture Back returns to the catalog: '+e.id);
   if(e.id==='bi_fang'){
    await click('employee:portrait:bi_fang',true);check((await state()).portrait_preview,'Full portrait popup remains available');await shot('bi-fang-full-portrait');await page.keyboard.press('Escape');await sync();
    await wheel(-20000);let b;for(let i=0;i<65;i++){b=(await state()).buttons.find(x=>x.qa_id==='employee:portrait:bi_fang');if(b)break;await wheel(210)}await shot('bi-fang-catalog');
   }
  }
  check(entries.length===catalog.length,'All selected employee cultural portraits visited through actual UI');
 }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())||null,null,2));}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt?.game_source,actions,checks,entries,errors},null,2));console.log(JSON.stringify({actions:actions.length,checks:checks.length,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
