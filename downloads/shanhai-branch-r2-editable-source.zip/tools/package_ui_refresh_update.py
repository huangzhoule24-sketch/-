#!/usr/bin/env python3
"""Deduplicate shared game parts for one small desktop/mobile UI update ZIP."""
import hashlib
import json
import shutil
from package_release import BUILD,ROOT,sha256,write_json,write_zip
from publish_web_site import git


def main():
    out=BUILD/'ui-refresh-r1';build=json.loads((out/'site-build.json').read_text());site=BUILD/'ui-r1-site';fresh=BUILD/'ui-export-site';package=BUILD/'workbuddy-ui-update'
    if package.exists():shutil.rmtree(package)
    package.mkdir(parents=True);plans={'combined':[],'single':[]};stored={}
    def blob(data):
        key=hashlib.sha256(data).hexdigest();name='payload/'+key+'.bin'
        if key not in stored:
            path=package/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);stored[key]=name
        return name
    def action(layout,destination,data,optional=False,known=None):
        record={'destination':destination,'source':blob(data)}
        if optional:record.update({'preserve_custom':True,'known_hashes':known or[]})
        plans[layout].append(record)
    for name in build['changes']:
        data=(site/name).read_bytes();old=git(['show',build['parent']+':'+name],raw=True)
        optional=name in ['index.html','share.html','portrait/index.html','portrait/share.html','device-router.js']
        action('combined',name,data,optional,[hashlib.sha256(old).hexdigest(),hashlib.sha256(data).hexdigest()])
    for path in (fresh/'game').rglob('*'):
        if not path.is_file():continue
        name=path.relative_to(fresh).as_posix();data=path.read_bytes()
        old=git(['show',build['parent']+':portrait/'+name],raw=True)
        old_desktop=git(['show',build['parent']+':'+name],raw=True)
        old_portrait=git(['show','a57fbe378510ad9357bedf66b27ab26cabc8c40a:portrait/'+name],raw=True)
        if data!=old or data!=old_desktop or data!=old_portrait:action('single',name,data)
    # A standalone project may have a custom landing page; keep it while
    # refreshing metadata to describe the actual files after applying.
    action('single','site-receipt.json',(fresh/'site-receipt.json').read_bytes())
    action('single','README.md',(ROOT/'docs/ui-refresh-r1.md').read_bytes())
    for name in ['export_presets.cfg','config/localization.json','scripts/ui/main.gd','scripts/ui/phone_layout.gd','scripts/ui/revision18_ui.gd','scripts/ui/full_panels.gd','scripts/ui/tutorial_overlay.gd','scripts/ui/overview_panel.gd','scripts/ui/overview_panel.gd.uid','tests/ui_refresh_tests.gd','tests/ui_refresh_tests.gd.uid','tests/inventory_return_tests.gd','tests/v19_ui_tests.gd']:
        target=package/'source-update'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
    shutil.copyfile(ROOT/'tools/apply_ui_refresh_update.py',package/'apply-update.py')
    text='''请在原WorkBuddy项目应用这个UI第一阶段补丁，保留原应用和域名。
先备份当前静态网站到非公开目录，再在补丁目录运行：python apply-update.py --site-root <实际网站根目录>。可用--backup-dir指定非公开备份目录。
脚本会识别电脑＋手机组合站或单版站点，校验基线、更新UI、保留自定义介绍页并核对完整资源。它只修改本地文件，不自行发布。
请检查：手机顶部两行操作与概览资源、物品与其他管理页固定返回、文化页父级返回与全局返回、更多功能搜索/清空及键盘、横竖屏切换、电脑顶栏、暂停音乐、保存刷新。
验证后重新部署当前应用到原链接，不新建应用、不换域名、不清除浏览器存档。若Python不可用，请按UI-PATCH-MANIFEST.json中plans对应的映射复制文件，并核对资源SHA。
source-update目录是给Godot源码工程的UI变更，不放进网页发布目录。未增加菜系、剧情、战斗或调整经营数值。
最后请提供原网址、发布版本SH-WEB-UI-R1和实际检查结果，区分模拟与真机。
'''
    (package/'给WorkBuddy的更新指令.txt').write_text(text,encoding='utf-8-sig')
    (package/'使用说明.txt').write_text('''UI第一阶段更新 · SH-WEB-UI-R1

手机HUD缩减为两行操作，详细数据在概览；更多支持搜索；普通页面有位置提示与固定返回餐厅；电脑资源和管理进度分行，正文更清晰。
将本ZIP上传到原WorkBuddy项目，发送“给WorkBuddy的更新指令.txt”。使用apply-update.py自动更新，payload为共享资源，请勿直接将payload当网站目录。
脚本支持此前的组合站、独立手机版及独立电脑版，先备份再覆盖，有错误会恢复本次覆盖的文件。不要清除浏览器网站数据。
Godot工程：将source-update内部内容合并到上一版完整源码工程，保留其他文件后重新导入。它是源码增量，运行素材仍使用原主包。
部署后使用原网址，必要时在游戏页面地址加?v=ui-r1绕过旧页面缓存。此补丁不会自动替你更新WorkBuddy，需要在原项目重新部署。
''',encoding='utf-8-sig')
    files={p.relative_to(package).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p)}for p in package.rglob('*')if p.is_file()}
    known=['71aa6dee3ece74281d41ddac608940233ea2cc1f0ce6bf945ee58e70a842be9a','68d3a7d44d51ea4c4772022609910db61be34d8d200d3918bde82d58269b643c','e5333a5044cde2936c34aad86d0ea0f6e531efb7081b31a51e8ba819519fe737',build['game_source']['sha256']]
    write_json(package/'UI-PATCH-MANIFEST.json',{'version':build['version'],'game_source':build['game_source'],'accepted_sources':known,'plans':plans,'files':files})
    artifact=write_zip(BUILD/'shanhai-ui-r1-workbuddy-update.zip',[(p,p.relative_to(package).as_posix())for p in sorted(package.rglob('*'))if p.is_file()]);assert artifact['bytes']<100*1024*1024
    write_json(out/'patch-build.json',{'artifact':artifact,'game_source':build['game_source'],'shared_blobs':len(stored),'combined_updates':len(plans['combined']),'single_updates':len(plans['single'])});print(json.dumps(artifact,indent=2))


if __name__=='__main__':main()
