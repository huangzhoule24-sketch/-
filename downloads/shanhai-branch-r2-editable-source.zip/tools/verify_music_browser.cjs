/* Historical SH-MUSIC-R4 contract: music used to continue during world pause.
 * For the current pause/resume requirements use verify_music_continuity_browser.cjs.
 * This retained scenario documents the earlier release, not the R8 audio policy.
 * Real mouse/keyboard UI checks; audio analyser taps only observe WebAudio output. */
const { chromium }=require('playwright');const fs=require('fs'),path=require('path');
const base=(process.env.SHANHAI_QA_URL||'http://127.0.0.1:8035').replace(/\/$/,'');
const out=process.argv[2]||'build/music-r4/browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1440,height:900}});const actions=[],checks=[],errors=[],samples=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.addInitScript(()=>{
  window.shanhaiAudioTaps=[];
  const connect=AudioNode.prototype.connect;
  AudioNode.prototype.connect=function(destination,...rest){
   const result=connect.call(this,destination,...rest);
   if(destination instanceof AudioDestinationNode){const analyser=this.context.createAnalyser();analyser.fftSize=2048;connect.call(this,analyser);window.shanhaiAudioTaps.push(analyser);}
   return result;
  };
 });
 const state=()=>page.evaluate(()=>window.shanhaiQAState);
 async function sync(){
  for(let i=0;i<2;i++){const previous=await page.evaluateHandle(()=>window.shanhaiQAState);try{await page.waitForFunction(value=>window.shanhaiQAState!==value,previous,{timeout:10000})}finally{await previous.dispose()}}
 }
 async function point(r){return page.evaluate(r=>{const t=window.shanhaiQAState.screen_transform,c=document.querySelector('canvas'),v=c.getBoundingClientRect();return{x:v.x+(t.a*(r.x+r.w/2)+t.c*(r.y+r.h/2)+t.tx)*v.width/c.width,y:v.y+(t.b*(r.x+r.w/2)+t.d*(r.y+r.h/2)+t.ty)*v.height/c.height}},r)}
 async function wheel(delta){const s=await state(),p=await point({x:s.viewport.w*.6,y:s.viewport.h*.6,w:0,h:0});await page.mouse.move(p.x,p.y);await page.mouse.wheel(0,delta);await sync()}
 async function click(id,reset=false){if(reset)await wheel(-20000);let b;for(let i=0;i<45;i++){b=(await state()).buttons.find(b=>b.qa_id===id&&!b.disabled);if(b)break;await wheel(100)}if(!b)throw Error('Visible control missing: '+id);const p=await point(b.rect);await page.mouse.click(p.x,p.y);actions.push({click:id,rect:b.rect,point:p});await sync();fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({last:actions.at(-1),panel:(await state()).panel,checks:checks.length}));}
 function check(ok,label){checks.push({label,ok});if(!ok)throw Error(label)}
 async function shot(n){await page.screenshot({path:path.join(out,n+'.png')})}
 async function amplitude(label){await page.waitForTimeout(600);const data=await page.evaluate(async()=>{let peak=0,sum=0,n=0;const taps=window.shanhaiAudioTaps||[];for(let frame=0;frame<8;frame++){for(const a of taps){const b=new Float32Array(a.fftSize);a.getFloatTimeDomainData(b);for(const v of b){peak=Math.max(peak,Math.abs(v));sum+=v*v;n++}}await new Promise(r=>setTimeout(r,25))}return{taps:taps.length,peak,rms:n?Math.sqrt(sum/n):0}});samples.push({label,...data});return data}
 let receipt;
 try{
  receipt=await(await page.request.get(base+'/export-receipt.json')).json();await page.goto(base+'/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});
  await click('locale:en');await click('start:full');await click('tutorial:ack');await click('nav:员工');await click('panel:close');await click('tutorial:ack');await click('tutorial:destination');await click('full:marketing:flyer');await click('tutorial:ack');if((await state()).panel)await click('panel:close');
  const until=Date.now()+120000;while((await state()).state.served<1&&Date.now()<until)await page.waitForTimeout(300);
  check((await state()).state.served>=1,'Music accompanies a real paid first order');
  if((await state()).state.tutorial.ready_to_ack.includes('first_order'))await click('tutorial:ack');await click('tutorial:ack');await click('tutorial:destination');await click('tutorial:ack');await click('panel:close');
  await click('nav:更多');await click('full:open:系统',true);await shot('01-system-switches');
  let s=await state();check(s.audio.enabled.music&&s.audio.enabled.sfx&&s.audio.music_playing,'Both channels default on and bundled music actually starts after user input');
  const starts=s.audio.music_starts;const before=JSON.stringify(s.state);
  await click('system:audio:music');s=await state();check(!s.audio.enabled.music&&s.audio.enabled.sfx,'System music switch is independent');
  const silent=await amplitude('Music disabled, world paused, effects idle');check(silent.taps>0&&silent.peak<.00001,'Actual WebAudio output is silent when background music is disabled');
  await click('system:audio:sfx');await click('system:audio:music');s=await state();check(s.audio.enabled.music&&!s.audio.enabled.sfx&&s.audio.music_starts===starts,'Re-enabling music resumes without restarting, while effects remain off');
  const music=await amplitude('Music only');check(music.peak>.0001&&music.peak<.95,'Actual music-only output is audible and has headroom');check(JSON.stringify((await state()).state)===before,'Switching audio leaves the paused campaign untouched');
  await click('system:audio',true);await shot('02-sound-settings');check((await state()).audio_panel.switches.music&&!(await state()).audio_panel.switches.sfx,'Detailed sound settings agree with system switches');
  const slider=(await state()).audio_panel.sliders.music;const pos=await point({x:slider.x+slider.w*.35,y:slider.y,w:0,h:slider.h});await page.mouse.click(pos.x,pos.y);await sync();const chosen=(await state()).audio.levels.music;
  check(chosen>0&&chosen<.6,'Real volume slider adjusts the music');
  await click('audio:enabled:music',true);await click('audio:mute');await click('audio:enabled:music',true);let muted=await amplitude('Master mute with music enabled');check(muted.peak<.00001,'Music switch cannot bypass master mute');await click('audio:mute');
  await click('audio:enabled:music',true);await page.setViewportSize({width:844,height:390});await sync();await shot('03-mobile-switches');
  check((await state()).buttons.some(b=>b.qa_id==='audio:enabled:music'),'Music switch remains reachable on a small landscape display');
  await page.setViewportSize({width:1440,height:900});await sync();await click('panel:back');await click('system:save',true);await page.waitForTimeout(2000);
  await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:60000});s=await state();
  check(!s.audio.enabled.music&&!s.audio.enabled.sfx&&Math.abs(s.audio.levels.music-chosen)<.001,'Both switches and chosen volume survive actual browser reload');
  await click('panel:close');await click('nav:更多');await click('full:open:系统',true);await click('system:audio:music');await click('system:audio:sfx');await click('locale:zh',true);await shot('04-chinese-settings');
  check((await state()).audio.enabled.music&&(await state()).audio.enabled.sfx,'Both channels can be restored after reload in Chinese settings');
 }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,'failure-state.json'),JSON.stringify((await state())??null,null,2));}
 const report={game_source:receipt?.game_source,actions,checks,samples,errors};fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
