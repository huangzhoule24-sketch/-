#!/usr/bin/env python3
"""Publishable desktop/phone site using one newly exported game source."""
import json
import shutil
from package_release import ROOT,BUILD,sha256,write_json,utc_now,game_source_fingerprint
from publish_web_site import git

REVISION='web-international-r1'
VERSION='SH-WEB-INTERNATIONAL-R1'
BASELINE='0a8326367ce212fd53f0f8527152eaa009252738'

def signature(path):return {'bytes':path.stat().st_size,'sha256':sha256(path)}
def main():
    fresh=BUILD/'international-release';site=BUILD/'international-site'
    source=json.loads((fresh/'site-receipt.json').read_text())
    assert source['game_source']==game_source_fingerprint()
    if site.exists():shutil.rmtree(site)
    names=git(['ls-tree','-rz','--name-only',BASELINE],raw=True).decode().rstrip('\0').split('\0')
    original={n:git(['show',BASELINE+':'+n],raw=True)for n in names}
    for n,data in original.items():
        if n.startswith(('game/','portrait/game/')):continue
        path=site/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    for prefix,variant in[('','desktop'),('portrait/','mobile')]:
        base=site/prefix;shutil.copytree(fresh,base,dirs_exist_ok=True)
        for name,kind in[('index.html','home'),('share.html','share'),('game/index.html','game')]:
            page=base/name;html=page.read_text();depth=(1 if prefix else 0)+(1 if kind=='game'else 0);root='../'*depth if depth else'./'
            include='<script src="'+root+'device-router.js?v='+REVISION+'" data-root="'+root+'" data-variant="'+variant+'" data-page="'+kind+'"></script>'
            html=html.replace('<head>','<head>\n'+include,1)
            if kind=='game':html=html.replace('(function () {','(function () {\n\tif (window.shanhaiDeviceRoute && window.shanhaiDeviceRoute.redirecting) return;',1)
            else:html=html.replace('</head>','<link rel="stylesheet" href="'+root+'device-entry.css?v='+REVISION+'">\n</head>',1)
            page.write_text(html)
        router=base/'device-router.js';router.write_text(router.read_text().replace('web-ui-r1',REVISION))
        shutil.copyfile(ROOT/'docs/international-release-r1.md',base/'README.md')
        receipt_path=base/'game/export-receipt.json';receipt=json.loads(receipt_path.read_text());receipt['files']['index.html']=signature(base/'game/index.html');receipt['entry_router']={'version':REVISION,'variant':variant};write_json(receipt_path,receipt)
        manifest=json.loads((fresh/'site-receipt.json').read_text());manifest['version']=VERSION;manifest['created_utc']=utc_now();manifest['entry_router']={'version':REVISION,'variant':variant}
        manifest['files']={p.relative_to(base).as_posix():signature(p)for p in base.rglob('*')if p.is_file()and not p.relative_to(base).as_posix().startswith('portrait/')and p.name!='site-receipt.json'}
        write_json(base/'site-receipt.json',manifest)
    # The root router serves both entry shells; the nested copy is harmless.
    changes={p.relative_to(site).as_posix():signature(p)for p in site.rglob('*')if p.is_file()and original.get(p.relative_to(site).as_posix())!=p.read_bytes()}
    removed=[n for n in original if not(site/n).is_file()]
    write_json(BUILD/'international-r1/site-build.json',{'version':VERSION,'revision':REVISION,'parent':BASELINE,'game_source':source['game_source'],'changes':changes,'removed':removed,'both_views_current':True})
    print(json.dumps({'source':source['game_source'],'changed':len(changes),'removed':len(removed)},indent=2))

if __name__=='__main__':main()
