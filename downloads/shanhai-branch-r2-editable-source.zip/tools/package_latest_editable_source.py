#!/usr/bin/env python3
"""Package current editable game sources, without private presentation material."""
import ast
import hashlib
import json
import shutil
import struct
import zipfile
from pathlib import Path
from package_release import ROOT,BUILD,sha256,game_source_fingerprint,allowed_source,write_json,write_zip


def fingerprint(root):
    h=hashlib.sha256();count=0
    paths=[]
    for name in ['assets','config','scenes','scripts']:
        paths.extend(p for p in (root/name).rglob('*')if p.is_file())
    paths.extend(root/name for name in ['project.godot','export_presets.cfg'])
    for path in sorted(paths,key=lambda p:p.relative_to(root).as_posix()):
        name=path.relative_to(root).as_posix().encode();h.update(struct.pack('!I',len(name)));h.update(name);h.update(bytes.fromhex(sha256(path)));count+=1
    return {'sha256':h.hexdigest(),'files':count,'algorithm':'sha256(path-length + utf8-path + file-sha256), sorted paths'}


def main():
    expected=json.loads((ROOT/'docs/validation-artifacts/inventory-return-r1/publication.json').read_text())['game_source']
    assert game_source_fingerprint()==expected,'Runtime changed after the latest validated fix'
    stage=BUILD/'latest-editable-source';out=BUILD/'source-inventory-r1'
    if stage.exists():shutil.rmtree(stage)
    stage.mkdir(parents=True);out.mkdir(parents=True,exist_ok=True)
    selected=set()
    for top in ['assets','config','scenes','scripts','tests','web','CustomAssets','CustomAudio']:
        selected.update(p for p in (ROOT/top).rglob('*')if p.is_file()and allowed_source(p))
    selected.update(ROOT/name for name in ['project.godot','export_presets.cfg','.gitignore'])
    # Art masters are optional for regeneration; all playable artwork is in assets/.
    selected.update(p for p in (ROOT/'art-source').rglob('*')if p.is_file()and allowed_source(p)and 'masters'not in p.relative_to(ROOT/'art-source').parts)
    denied=('classroom','ppt','presentation','outlook','materials','slides')
    for p in (ROOT/'tools').rglob('*'):
        if p.is_file()and allowed_source(p)and not any(word in p.name.lower()for word in denied):selected.add(p)
    docs={'docs/cultural-redesign-guide.md','docs/english-version-guide.md','docs/mobile-portrait-r9.md','docs/device-auto-entry.md','docs/workbuddy-inventory-return-update.md','docs/management-rules.md','docs/expansion-rules.md','docs/web-site-guide.md','docs/mainland-hosting-guide.md','docs/classroom-free-hosting.md','docs/proposals/feedback-revision-20261104.md'}
    # Include the public technical documents used by export support, not the
    # project diary, uploaded presentations, private images or their history.
    for tool in ['tools/package_release.py','tools/build_web_site.py']:
        for node in ast.walk(ast.parse((ROOT/tool).read_text())):
            if isinstance(node,ast.Constant)and isinstance(node.value,str)and node.value.startswith('docs/')and (ROOT/node.value).is_file():docs.add(node.value)
    selected.update(ROOT/name for name in docs)
    for top in ['docs/culture-research','docs/translation-research','docs/free-sfx','docs/music-r4','docs/menu-r5']:
        selected.update(p for p in (ROOT/top).rglob('*')if p.is_file()and p.suffix.lower()in ['.json','.md','.csv','.txt'])
    for folder in ['inventory-return-r1','device-auto-entry']:
        selected.update(p for p in (ROOT/'docs/validation-artifacts'/folder).glob('*')if p.suffix in ['.json','.txt'])
    for path in selected:
        relative=path.relative_to(ROOT);assert relative.as_posix()not in ['AGENTS.md','docs/project-memory.md']
        target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
    readme='''# 山海食肆物语 · 最新可编辑源码

版本：SH-SOURCE-INVENTORY-R1 · 2026年11月4日

本工程保持当前已验证的游戏实现，包含手机版物品栏固定“返回餐厅”、完整角色与菜品、像素场景与水墨立绘、音乐音效、中英切换及电脑/手机布局。默认按正式经营流程解锁。

## 打开工程

1. 全部解压源码主包。
2. 使用Godot 4.6.3导入同目录的project.godot，等待首次资源导入。
3. 在编辑器运行主场景，或命令行执行 `godot --path .`。
4. 要导出Web或Windows，在Godot中安装对应4.6.3导出模板，选择Web或Windows Desktop预设。

源码主包已经包含全部游戏实际使用的图像、字体与音频，可直接运行和编辑。需要重新生成像素图集或重做美术裁剪时，再把美术母图补充包解压到相同目录，使art-source/masters位于工程内。

## 文件位置

- scripts/core：经营与存档逻辑；scripts/ui：界面、地图和手机布局。
- config：角色、菜品、文化、翻译与数值；assets：当前完整运行资源。
- web：网站壳层、手机浏览器适配、设备自动识别入口。
- tests：原生检查；tools：构建、资源处理及验证脚本。
- docs/proposals/feedback-revision-20261104.md：本轮修改意见，只有文档，没有启用新增玩法。

验证示例：`godot --headless --path . --script tests/inventory_return_tests.gd`。
浏览器自动化工具需要另外安装Node.js/Playwright/Chromium；编辑器运行游戏不依赖这些浏览器测试工具。

本次独立导入与51项物品栏回归通过。Linux主场景欢迎页启动成功；定时退出时仍有1项资源引用清理提示，已在交付验证记录中保留。尚未声明真实Windows或手机硬件验收。

## 版本边界

此源码对应最新手机版运行源码指纹e5333a5044cde2936c34aad86d0ea0f6e531efb7081b31a51e8ba819519fe737，共842项运行源文件。当前线上双版本站点此前保留的R8电脑版二进制属于既有发布；本包是目前统一可编辑工程，直接导出会使用本工程的当前实现。

部分历史网站发布工具引用旧构建目录或Git快照。迁移到新电脑时，应先安装标准导出模板重新导出；不要直接假定那些历史构建缓存已经存在。网页运行/部署包与可编辑源码包的用途不同。

素材来源与许可见assets/audio/CREDITS.md、assets/fonts和tools/licenses。源码运行需要的许可文件均保留。没有打包个人存档、登录凭据、项目聊天记录或课堂PPT。
'''
    (stage/'README.md').write_text(readme,encoding='utf-8')
    assert fingerprint(stage)==expected
    names=[p.relative_to(stage).as_posix()for p in stage.rglob('*')if p.is_file()]
    assert not any(n.startswith(('.git/','.godot/','build/'))or n=='AGENTS.md'or n=='docs/project-memory.md'or n.endswith(('.pptx','.pdf','.key','.pem'))for n in names)
    write_json(stage/'SOURCE-INFO.json',{'version':'SH-SOURCE-INVENTORY-R1','game_source':expected,'proposal_implemented':False,'files':{n:{'bytes':(stage/n).stat().st_size,'sha256':sha256(stage/n)}for n in sorted(names)}})
    main_zip=write_zip(BUILD/'shanhai-v1.9.5-latest-editable-source.zip',[(p,p.relative_to(stage).as_posix())for p in sorted(stage.rglob('*'))if p.is_file()])
    masters=[p for p in (ROOT/'art-source/masters').rglob('*')if p.is_file()and allowed_source(p)]
    masters_zip=write_zip(BUILD/'shanhai-v1.9.5-art-masters-supplement.zip',[(p,p.relative_to(ROOT).as_posix())for p in sorted(masters)])
    for artifact in [main_zip,masters_zip]:assert artifact['bytes']<100*1024*1024
    for artifact in [main_zip,masters_zip]:
        with zipfile.ZipFile(BUILD/artifact['file'])as z:assert z.testzip()is None
    write_json(out/'package.json',{'version':'SH-SOURCE-INVENTORY-R1','game_source':expected,'source_files':len(names)+1,'artifacts':[main_zip,masters_zip],'proposal_implemented':False,'privacy_scope':'Editable game, technical docs and public validation only; no private presentations, diary, credentials or player saves'})
    print(json.dumps({'artifacts':[main_zip,masters_zip],'runtime':expected,'source_files':len(names)+1},indent=2))


if __name__=='__main__':main()
