#!/usr/bin/env python3
"""Publish the validated UI website and a resumable small WorkBuddy update."""
import json,urllib.request,zipfile
from package_release import BUILD,sha256,game_source_fingerprint,write_json
import publish_web_site as publisher

def main():
    output=BUILD/'ui-refresh-r1';publisher.REVISION='ui-refresh-r1'
    build=json.loads((output/'site-build.json').read_text());patch=json.loads((output/'patch-build.json').read_text());site=BUILD/'ui-r1-site'
    assert build['game_source']==patch['game_source']==game_source_fingerprint()
    for name in ['browser','desktop-browser']:
        r=json.loads((output/name/'report.json').read_text());assert r['game_source']==build['game_source']and not r['errors']and all(c['ok']for c in r['checks'])
    for name in ['device-browser','share-browser','site-browser','apply-tests']:
        r=json.loads((output/name/'report.json').read_text());assert not r['errors']and all(c['ok']for c in r['checks'])
    assert '"checks":74,"failures":[]' in (BUILD/'ui-refresh-native.log').read_text()
    for name in ['desktop-http.json','mobile-http.json']:
        r=json.loads((output/name).read_text());assert r['game_source']==build['game_source']and r['gzip_sha_and_roundtrip_verified']
    for prefix in ['','portrait/']:
        manifest=json.loads((site/prefix/'site-receipt.json').read_text())
        for name,e in manifest['files'].items():
            p=site/prefix/name;assert p.stat().st_size==e['bytes']and sha256(p)==e['sha256'],prefix+name
    entries={p.relative_to(site).as_posix():p for p in site.rglob('*')if p.is_file()}
    website=publisher.publish('gh-pages',entries,'Improve desktop and mobile UI hierarchy, overview, search and return paths',build['parent'])
    changes=publisher.git(['diff-tree','-z','--no-commit-id','--name-only','-r',build['parent'],website],raw=True).decode().rstrip('\0').split('\0');assert sorted(changes)==sorted(build['changes'])
    print(json.dumps({'site_commit':website}),flush=True)
    artifact=patch['artifact'];archive=BUILD/artifact['file'];assert sha256(archive)==artifact['sha256']
    with zipfile.ZipFile(archive)as z:assert z.testzip()is None
    sums=output/'SHA256SUMS.txt';sums.write_text(artifact['sha256']+'  '+artifact['file']+'\n');package=BUILD/'workbuddy-ui-update'
    downloads={'downloads/'+artifact['file']:archive,'downloads/SHA256SUMS.txt':sums,'instructions/workbuddy-update.txt':package/'给WorkBuddy的更新指令.txt','instructions/readme.txt':package/'使用说明.txt','preview/phone-ui.png':output/'browser/05b-restored-hud.png','preview/overview.png':output/'browser/05c-overview.png','preview/more-search.png':output/'browser/06b-more-search.png'}
    commit=publisher.publish('ui-refresh-r1-20261105',downloads,'Provide the validated UI update for existing WorkBuddy projects')
    url='https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/downloads/'+artifact['file'];target=output/'public-ui-update.zip'
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shanhai-UI-update-verifier'}),timeout=120)as r:
        status=r.status;length=int(r.headers.get('Content-Length','0'))
        with target.open('wb')as f:
            while block:=r.read(1024*1024):f.write(block)
    assert status==200 and length==artifact['bytes']and target.stat().st_size==length and sha256(target)==artifact['sha256']
    with zipfile.ZipFile(target)as z:assert z.testzip()is None
    start=1048576;size=64
    with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes={start}-{start+size-1}'}),timeout=45)as r:partial=r.read();rs=r.status;cr=r.headers.get('Content-Range')
    with archive.open('rb')as f:f.seek(start);expected=f.read(size)
    assert rs==206 and partial==expected and cr==f'bytes {start}-{start+size-1}/{length}'
    proof={'version':build['version'],'game_source':build['game_source'],'static_site':{'commit':website,'parent':build['parent'],'both_views_current':True,'pages_url':'https://huangzhoule24-sketch.github.io/-/','live_http_verified':False},'commit':commit,'downloads':[{**artifact,'url':url,'direct_url':url,'http_status':status,'content_length':length,'sha256_verified':True,'zip_crc_valid':True,'range_status':rs,'range_verified':True}],'workbuddy_project_deployed_by_assistant':False,'workbuddy_instructions_url':'https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/instructions/workbuddy-update.txt'}
    write_json(output/'publication.json',proof);print(json.dumps(proof,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
