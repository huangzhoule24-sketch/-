#!/usr/bin/env python3
"""Add automatic PC/mobile entry to the exact two already-published game builds."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

from package_release import ROOT, BUILD, sha256, write_json, utc_now
from publish_web_site import git

REVISION = 'web-auto-r1'
SITE = BUILD / 'device-site'


def signature(path):
    return {'bytes': path.stat().st_size, 'sha256': sha256(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--site-commit', required=True)
    args = parser.parse_args()
    names = git(['ls-tree', '-rz', '--name-only', args.site_commit], raw=True).decode().rstrip('\0').split('\0')
    assert 'portrait/game/index.html' in names and 'game/index.html' in names
    assert 'device-router.js' not in names, 'Use the pre-router snapshot documented in docs/device-auto-entry.md; refusing duplicate routing scripts.'
    original = {n: git(['show', args.site_commit + ':' + n], raw=True) for n in names}
    if SITE.exists():
        shutil.rmtree(SITE)
    for name, data in original.items():
        target = SITE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    for name in ['device-router.js', 'device-entry.css']:
        shutil.copyfile(ROOT / 'web/site' / name, SITE / name)
    for prefix, variant in [('', 'desktop'), ('portrait/', 'mobile')]:
        base = SITE / prefix
        for name, kind in [('index.html', 'home'), ('share.html', 'share'), ('game/index.html', 'game')]:
            path = base / name
            text = path.read_text()
            depth = (1 if prefix else 0) + (1 if kind == 'game' else 0)
            relative = '../' * depth if depth else './'
            include = '<script src="' + relative + 'device-router.js?v=' + REVISION + '" data-root="' + relative + '" data-variant="' + variant + '" data-page="' + kind + '"></script>'
            text = text.replace('<head>', '<head>\n' + include, 1)
            if '<head>' not in path.read_text():
                # Godot uses an indented head, but the tag itself remains literal.
                raise AssertionError('Missing head: ' + str(path))
            if kind == 'game':
                assert '(function () {' in text
                text = text.replace('(function () {', '(function () {\n\tif (window.shanhaiDeviceRoute && window.shanhaiDeviceRoute.redirecting) return;', 1)
            else:
                text = text.replace('</head>', '<link rel="stylesheet" href="' + relative + 'device-entry.css?v=' + REVISION + '">\n</head>', 1)
                text = text.replace('preview-access.js?v=web-r8', 'preview-access.js?v=' + REVISION).replace('preview-access.js?v=web-r9-portrait', 'preview-access.js?v=' + REVISION)
                text = text.replace('share.js?v=web-r8', 'share.js?v=' + REVISION).replace('share.js?v=web-r9-portrait', 'share.js?v=' + REVISION)
                if kind == 'share':
                    text = text.replace('手机请横屏，使用 Safari、Edge、Chrome 或较新的系统浏览器。', '同一个地址自动识别设备：电脑进入电脑版，手机和平板进入手机版。')
                    text = text.replace('Landscape on phones.', 'One link selects desktop or mobile automatically.')
            path.write_text(text)
        access = base / 'preview-access.js'
        text = access.read_text().replace("const url=new URL('./',location.href);", "const url=new URL(window.shanhaiDeviceRoute?window.shanhaiDeviceRoute.root:new URL('./',location.href));")
        text = text.replace("url.searchParams.set('v','web-r9-portrait');", "url.searchParams.set('v',window.shanhaiDeviceRoute?window.shanhaiDeviceRoute.version:'web-r9-portrait');")
        text = text.replace("url.searchParams.set('v','web-r8');", "url.searchParams.set('v',window.shanhaiDeviceRoute?window.shanhaiDeviceRoute.version:'web-r8');")
        access.write_text(text)
        shell = base / 'game/export-receipt.json'
        receipt = json.loads(shell.read_text())
        receipt['files']['index.html'] = signature(base / 'game/index.html')
        receipt['entry_router'] = {'version': REVISION, 'variant': variant}
        receipt['site_shell_updated_utc'] = utc_now()
        write_json(shell, receipt)
        manifest = json.loads((base / 'site-receipt.json').read_text())
        manifest['entry_router'] = {'version': REVISION, 'variant': variant, 'root_relative': '../' if prefix else './'}
        for name in manifest['files']:
            manifest['files'][name] = signature(base / name)
        if not prefix:
            for name in ['device-router.js', 'device-entry.css']:
                manifest['files'][name] = signature(base / name)
        write_json(base / 'site-receipt.json', manifest)
    changed = {p.relative_to(SITE).as_posix(): signature(p) for p in SITE.rglob('*') if p.is_file() and original.get(p.relative_to(SITE).as_posix()) != p.read_bytes()}
    assert not any('/parts/' in n or n.endswith('.bin') for n in changed)
    assert all(hashlib.sha256(data).hexdigest() == sha256(SITE / n) for n, data in original.items() if n not in changed)
    write_json(BUILD / REVISION / 'build.json', {
        'version': REVISION, 'parent': args.site_commit, 'changed_files': changed,
        'preserved_original_files': len(original) - sum(n in original for n in changed),
        'desktop_source': json.loads((SITE / 'site-receipt.json').read_text())['game_source'],
        'mobile_source': json.loads((SITE / 'portrait/site-receipt.json').read_text())['game_source'],
        'game_binary_chunks_unchanged': True,
    })
    print(json.dumps({'version': REVISION, 'changed_files': list(changed), 'game_binary_chunks_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
