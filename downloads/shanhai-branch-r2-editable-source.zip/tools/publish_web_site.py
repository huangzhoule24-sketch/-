#!/usr/bin/env python3
"""Publish verified static files and a download without exposing development history."""
import argparse,hashlib,json,os,re,subprocess,tempfile,urllib.request,zipfile
from pathlib import Path
from package_release import ROOT,BUILD,sha256,write_json

def git(args,data=None,env=None,raw=False):
    r=subprocess.run(['git',*args],cwd=ROOT,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    if r.returncode:raise RuntimeError('Git '+args[0]+' failed; potentially sensitive remote output suppressed')
    return r.stdout if raw else r.stdout.decode().strip()

REVISION='web-r8'
def publish(branch,entries,message,expected_parent=None):
    remote=git(['ls-remote','--heads','origin',branch])
    if remote and expected_parent is None:
        commit=remote.split()[0]
        assert sorted(git(['ls-tree','-r','--name-only',commit]).splitlines())==sorted(entries),'Existing branch differs; refusing to overwrite'
        for name,value in entries.items():
            expected=sha256(value)if isinstance(value,Path)else hashlib.sha256(value).hexdigest()
            assert hashlib.sha256(git(['show',commit+':'+name],raw=True)).hexdigest()==expected,name
        return commit
    if expected_parent is not None:
        assert branch=='gh-pages'and remote.split()[0]==expected_parent,'Website branch changed; refusing to overwrite'
    fd,index=tempfile.mkstemp(prefix='shanhai-site-',dir='/tmp');os.close(fd);Path(index).unlink()
    env={**os.environ,'GIT_INDEX_FILE':index}
    try:
        git(['read-tree','--empty'],env=env)
        for name,value in entries.items():
            blob=git(['hash-object','-w',str(value)],env=env)if isinstance(value,Path)else git(['hash-object','-w','--stdin'],value,env)
            git(['update-index','--add','--cacheinfo','100644',blob,name],env=env)
        tree=git(['write-tree'],env=env)
        commit=git(['commit-tree',tree,*(['-p',expected_parent]if expected_parent else []),'-m',message],env=env)
        assert int(git(['rev-list','--count',commit]))==(int(git(['rev-list','--count',expected_parent]))+1 if expected_parent else 1)
        write_json(BUILD/REVISION/('pending-'+branch+'.json'),{'branch':branch,'commit':commit})
        git(['push',*([]if expected_parent else ['--force-with-lease=refs/heads/'+branch+':']),'origin',commit+':refs/heads/'+branch])
        return commit
    finally:Path(index).unlink(missing_ok=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--expected-site-commit',required=True);args=parser.parse_args()
    site=BUILD/'web-site';manifest=json.loads((site/'site-receipt.json').read_text());build=json.loads((BUILD/REVISION/'site-build.json').read_text())
    for name,e in manifest['files'].items():
        p=site/name;assert p.stat().st_size==e['bytes']and sha256(p)==e['sha256'],name
    for name in ['preview-browser','site-browser','whole-view-browser','music-browser']:
        report=json.loads((BUILD/REVISION/name/'report.json').read_text())
        assert not report['errors']and all(c['ok']for c in report['checks']),name
        if 'game_source'in report:assert report['game_source']==build['game_source'],'Browser report is stale'
    archive=BUILD/build['artifact']['file'];assert archive.stat().st_size==build['artifact']['bytes']and sha256(archive)==build['artifact']['sha256']
    with zipfile.ZipFile(archive)as z:
        assert z.testzip()is None
        assert sorted(z.namelist())==sorted(p.relative_to(site).as_posix()for p in site.rglob('*')if p.is_file())
        for name in z.namelist():assert z.read(name)==(site/name).read_bytes(),name
    site_commit=publish('gh-pages',{p.relative_to(site).as_posix():p for p in site.rglob('*')if p.is_file()},'Preserve continuous background music and pause cursor SH-WEB-R8',args.expected_site_commit)
    print(json.dumps({'static_site_branch':'gh-pages','commit':site_commit}),flush=True)
    entries={'downloads/'+archive.name:archive,'downloads/SHA256SUMS.txt':(sha256(archive)+'  '+archive.name+'\n').encode(),'downloads/site-build.json':BUILD/REVISION/'site-build.json','README.md':(ROOT/'docs/web-site-guide.md').read_bytes()}
    download_commit=publish('web-r8-v1.9.5-20261102',entries,'Publish Shanhai Inn continuous-music website SH-WEB-R8')
    url='https://github.com/huangzhoule24-sketch/-/raw/'+download_commit+'/downloads/'+archive.name
    target=BUILD/REVISION/'public-site.zip'
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shanhai-site-integrity-verifier'}),timeout=120)as response:
        status=response.status
        with target.open('wb')as f:
            while True:
                block=response.read(1048576)
                if not block:break
                f.write(block)
    assert status==200 and sha256(target)==sha256(archive)and target.stat().st_size==archive.stat().st_size
    with zipfile.ZipFile(target)as z:assert z.testzip()is None
    proof={'version':'SH-WEB-R8','game_source':build['game_source'],'static_site':{'branch':'gh-pages','commit':site_commit,'parent_commit':args.expected_site_commit,'files':sum(p.is_file()for p in site.rglob('*')),'pages_url':'https://huangzhoule24-sketch.github.io/-/','live_url_verified':False,'note':'Live deployment status must be checked separately.'},'download':{**build['artifact'],'url':url,'commit':download_commit,'http_status':status,'sha256_verified':True,'zip_crc_valid':True}}
    # Public Actions HTML remains accessible when the GitHub API or github.io is blocked.
    # Keep deployment success distinct from an actual HTTP check of the live game.
    try:
        with urllib.request.urlopen('https://github.com/huangzhoule24-sketch/-/actions',timeout=20)as r:body=r.read().decode()
        runs=[]
        for script in re.findall(r'<script\b[^>]*type="application/json"[^>]*>([\s\S]*?)</script>',body):
            try:runs+=json.loads(script).get('payload',{}).get('allWorkflowRunsRoute',{}).get('workflowRuns',[])
            except (ValueError,AttributeError):pass
        for run in runs:
            if run['branch']['name']!='refs/heads/gh-pages'or run['state'].get('conclusion')!='WORKFLOW_RUN_CONCLUSION_SUCCESS':continue
            with urllib.request.urlopen(run['runUrl'],timeout=20)as r:page=r.read().decode()
            if site_commit not in page or proof['static_site']['pages_url']not in page:continue
            proof['static_site'].update({'github_deployment_success':True,'run_url':run['runUrl'],'run_id':run['id'],'run_state':run['state'],'note':'GitHub Pages deployment succeeded for the exact website commit. Direct live-domain HTTP verification remains separate.'});break
    except Exception:proof['static_site']['deployment_status_note']='Public deployment status unavailable; inspect GitHub Actions separately.'
    write_json(BUILD/REVISION/'publication.json',proof);print(json.dumps(proof,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
