#!/usr/bin/env python3
"""Check the delivered archive in a clean directory and import it with official Godot."""
import argparse,json,shutil,subprocess,zipfile
from pathlib import Path
from package_release import ROOT,BUILD,sha256,write_json,game_source_fingerprint
from package_latest_editable_source import fingerprint

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--profile',choices=['branch','branch2'],default='branch');args=parser.parse_args();tag='branch-r2'if args.profile=='branch2'else'branch-r1'
 out=BUILD/tag;artifact=json.loads((out/'source-package.json').read_text());expected=game_source_fingerprint();assert artifact['game_source']==expected
 archive=BUILD/artifact['artifact']['file'];assert sha256(archive)==artifact['artifact']['sha256']
 stage=BUILD/(args.profile+'-source-check')
 if stage.exists():shutil.rmtree(stage)
 stage.mkdir()
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None
  assert all(not Path(n).is_absolute()and'..'not in Path(n).parts for n in z.namelist())
  z.extractall(stage)
 info=json.loads((stage/'SOURCE-INFO.json').read_text());assert info['game_source']==expected
 names={p.relative_to(stage).as_posix()for p in stage.rglob('*')if p.is_file()}
 assert names==set(info['files'])|{'SOURCE-INFO.json'}
 for name,e in info['files'].items():assert(stage/name).stat().st_size==e['bytes']and sha256(stage/name)==e['sha256'],name
 assert fingerprint(stage)==expected
 results=[];failures=[]
 commands=[('clean-import',['godot','--headless','--path',str(stage),'--editor','--import'])]+[(test,['godot','--headless','--path',str(stage),'--script','res://tests/'+test+'.gd'])for test in(['branch_r2_tests','branch_scene_ui_tests']if args.profile=='branch2'else['branch_floor_tests','branch_scene_ui_tests'])]
 for label,command in commands:
  log=out/('source-'+label+'.log')
  with log.open('w')as f:r=subprocess.run(command,cwd=stage,stdout=f,stderr=subprocess.STDOUT,timeout=150)
  text=log.read_text();ok=r.returncode==0 and'SCRIPT ERROR'not in text and'Parse Error'not in text
  results.append({'check':label,'ok':ok,'exit':r.returncode,'last_line':text.splitlines()[-1]if text.splitlines()else''})
  if not ok:failures.append(label)
  print(results[-1],flush=True)
 matches=fingerprint(stage)==expected
 if not matches:failures.append('Runtime source changed during clean import')
 report={'game_source':expected,'files_checked':len(names),'archive_crc_valid':True,'manifest_sha256_verified':True,'source_fingerprint_after_import_matches':matches,'checks':results,'failures':failures}
 write_json(out/'source-verification.json',report);assert not failures;print(json.dumps(report,indent=2))
if __name__=='__main__':main()
