/* Website-only checks. Game regressions run separately against game/. */
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path');
const base=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8039').replace(/\/$/,'');
const out=process.argv[2]||'build/web-r1/site-browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const checks=[],errors=[],transfers={};
 function check(ok,label){checks.push({label,ok});if(!ok)throw Error(label);}
 async function scenario(name,setup){
  const context=await browser.newContext({viewport:{width:1440,height:900}}),page=await context.newPage(),requests=[];
  page.on('pageerror',e=>errors.push(name+': '+e.message));
  page.on('request',r=>{if(new URL(r.url()).pathname.includes('/parts/'))requests.push(new URL(r.url()).pathname);});
  try{
   if(setup)await setup(page);
   if(name==='homepage'){
    await page.setViewportSize({width:390,height:844});await page.goto(base+'/');await page.locator('#en').click();
    check(await page.locator('html').getAttribute('lang')==='en','Homepage switches to English');
    check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Phone homepage has no horizontal overflow');
    await page.screenshot({path:path.join(out,'homepage-mobile.png'),fullPage:true});
    await page.reload();check(await page.locator('html').getAttribute('lang')==='en','Homepage language survives reload');
    await page.locator('#zh').click();await page.setViewportSize({width:1440,height:900});
    await page.screenshot({path:path.join(out,'homepage-desktop.png'),fullPage:true});await page.locator('#play').click();
    await page.waitForFunction(()=>!document.getElementById('status'),undefined,{timeout:90000});
    check(new URL(page.url()).pathname.endsWith('/game/'),'Play opens the full game page');
   }else{
    await page.goto(base+'/game/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',undefined,{timeout:90000});
   }
   const transfer=await page.evaluate(()=>({isolated:crossOriginIsolated,transfer:window.shanhaiTransfer}));transfers[name]={...transfer,requests};
   check(!transfer.isolated,name+': starts without cross-origin isolation');
   if(name==='homepage')check(transfer.transfer.resources.length===2&&transfer.transfer.resources.every(x=>x.transfer==='gzip')&&requests.length===transfer.transfer.resources.reduce((n,x)=>n+x.parts,0)&&requests.every(x=>x.includes('.gzip.')),'Both game resources use compressed downloads');
   if(name==='no-decompression')check(transfer.transfer.mode==='original'&&requests.length===transfer.transfer.resources.reduce((n,x)=>n+x.parts,0)&&requests.every(x=>x.includes('.raw.')),'Older browser path loads both original resources');
   if(name==='missing-gzip')check(transfer.transfer.resources.length===2&&transfer.transfer.resources.every(x=>x.transfer==='original-fallback'),'Missing compressed files fall back to full original game');
   await page.screenshot({path:path.join(out,name+'-game.png')});
  }finally{await context.close();}
 }
 try{
  await scenario('homepage');
  await scenario('no-decompression',p=>p.addInitScript(()=>Object.defineProperty(window,'DecompressionStream',{value:undefined,configurable:true})));
  await scenario('missing-gzip',p=>p.route(/\/parts\/index\.(wasm|pck)\.gzip\.\d+\.bin(?:\?|$)/,route=>route.fulfill({status:404,body:'Unavailable for fallback test'})));
 }catch(e){errors.push(String(e.stack||e));}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks,transfers,errors},null,2));
 console.log(JSON.stringify({checks,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
