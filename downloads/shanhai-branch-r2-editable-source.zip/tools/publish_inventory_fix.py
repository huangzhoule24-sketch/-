#!/usr/bin/env python3
"""Publish the tested phone fix and one small WorkBuddy ZIP with range support."""
import json
import urllib.request
import zipfile
from package_release import BUILD,sha256,game_source_fingerprint,write_json
import publish_web_site as publisher


def main():
    revision='inventory-return-r1';publisher.REVISION=revision;output=BUILD/revision
    build=json.loads((output/'site-build.json').read_text());patch=json.loads((output/'patch-build.json').read_text());site=BUILD/'inventory-site'
    assert build['game_source']==patch['game_source']==game_source_fingerprint()
    browser=json.loads((output/'browser/report.json').read_text());assert browser['game_source']==build['game_source']and not browser['errors']and all(c['ok']for c in browser['checks'])
    applied=json.loads((output/'apply-tests/report.json').read_text());assert not applied['errors']and all(c['ok']for c in applied['checks'])
    http=json.loads((output/'mobile-http.json').read_text());assert http['game_source']==build['game_source']and http['gzip_sha_and_roundtrip_verified']
    for prefix in ['', 'portrait/']:
        manifest=json.loads((site/prefix/'site-receipt.json').read_text())
        for name,e in manifest['files'].items():
            path=site/prefix/name;assert path.stat().st_size==e['bytes']and sha256(path)==e['sha256'],prefix+name
    entries={p.relative_to(site).as_posix():p for p in site.rglob('*')if p.is_file()}
    website=publisher.publish('gh-pages',entries,'Restore phone inventory navigation and stable restaurant HUD',build['parent'])
    changed=publisher.git(['diff-tree','-z','--no-commit-id','--name-only','-r',build['parent'],website],raw=True).decode().rstrip('\0').split('\0')
    assert sorted(changed)==sorted(build['changes'])and all(n.startswith('portrait/')for n in changed)
    print(json.dumps({'site_commit':website}),flush=True)
    artifact=patch['artifact'];archive=BUILD/artifact['file'];assert archive.stat().st_size==artifact['bytes']and sha256(archive)==artifact['sha256']
    with zipfile.ZipFile(archive)as z:assert z.testzip()is None
    checksums=output/'PATCH-SHA256SUMS.txt';checksums.write_text(artifact['sha256']+'  '+artifact['file']+'\n')
    package=BUILD/'workbuddy-inventory-update'
    downloads={'downloads/'+artifact['file']:archive,'downloads/SHA256SUMS.txt':checksums,'instructions/workbuddy-update.txt':package/'给WorkBuddy的更新指令.txt','instructions/readme.txt':package/'更新说明.txt','preview/inventory-return.png':output/'browser/05a-inventory-return.png','preview/restored-hud.png':output/'browser/05b-restored-hud.png'}
    commit=publisher.publish('inventory-return-r1-20261104',downloads,'Provide the tested inventory return patch for existing WorkBuddy projects')
    url='https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/downloads/'+artifact['file']
    target=output/'public-workbuddy-update.zip'
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shanhai-inventory-patch-check'}),timeout=120)as r:
        status=r.status;length=int(r.headers.get('Content-Length','0'))
        with target.open('wb')as f:
            while block:=r.read(1024*1024):f.write(block)
    assert status==200 and length==artifact['bytes']and target.stat().st_size==length and sha256(target)==artifact['sha256']
    with zipfile.ZipFile(target)as z:assert z.testzip()is None
    start=1048576;size=64
    request=urllib.request.Request(url,headers={'User-Agent':'Shanhai-resume-check','Range':f'bytes={start}-{start+size-1}'})
    with urllib.request.urlopen(request,timeout=45)as r:partial=r.read();range_status=r.status;content_range=r.headers.get('Content-Range')
    with archive.open('rb')as f:f.seek(start);expected=f.read(size)
    assert range_status==206 and partial==expected and content_range==f'bytes {start}-{start+size-1}/{artifact["bytes"]}'
    proof={'version':build['version'],'game_source':build['game_source'],'static_site':{'commit':website,'parent':build['parent'],'only_changed_prefix':'portrait/','desktop_and_device_entry_unchanged':True,'pages_url':'https://huangzhoule24-sketch.github.io/-/','live_http_verified':False},'commit':commit,'downloads':[{**artifact,'url':url,'direct_url':url,'http_status':status,'content_length':length,'sha256_verified':True,'zip_crc_valid':True,'range_status':range_status,'range_verified':True}],'workbuddy_project_deployed_by_assistant':False,'workbuddy_instructions_url':'https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/instructions/workbuddy-update.txt'}
    write_json(output/'publication.json',proof);print(json.dumps(proof,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':main()
