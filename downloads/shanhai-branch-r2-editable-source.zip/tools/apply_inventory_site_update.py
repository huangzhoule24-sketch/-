#!/usr/bin/env python3
"""Apply the inventory fix to a combined or standalone phone static website."""
import argparse
import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path


def digest(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def atomic(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.shanhai-update-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb')as f:f.write(data)
        os.replace(name,path)
    finally:Path(name).unlink(missing_ok=True)


def apply(package,root,backup):
    manifest=json.loads((package/'PATCH-MANIFEST.json').read_text())
    for name,e in manifest['files'].items():
        p=package/name
        if p.stat().st_size!=e['bytes']or digest(p)!=e['sha256']:raise ValueError('Patch integrity failed: '+name)
    combined=(root/'portrait/game/export-receipt.json').is_file()
    base=root/'portrait'if combined else root
    receipt_path=base/'game/export-receipt.json'
    if not receipt_path.is_file():raise ValueError('Cannot find the phone game export receipt in this website root')
    current=json.loads(receipt_path.read_text()).get('game_source',{}).get('sha256')
    if current not in [manifest['base_source'],manifest['new_source']]:raise ValueError('Phone build differs from this patch. Preserve the project and check its version first.')
    plan={}
    for name in manifest['payload']:
        relative=name[len('site/'):]if combined else name[len('site/portrait/'):]
        if not combined and relative in ['index.html','site-receipt.json']:continue
        target=root/relative
        if root not in target.resolve().parents:raise ValueError('Destination must remain inside the selected website')
        # Keep a custom WorkBuddy landing page; it does not control the game fix.
        if relative=='portrait/index.html'and target.exists()and digest(target)!=manifest['old_hashes'].get(relative):continue
        data=(package/name).read_bytes()
        if not combined and relative=='game/index.html':data=(package/'alternatives/game-index-standalone.html').read_bytes()
        plan[relative]=data
    if not combined:
        relative='game/export-receipt.json';receipt=json.loads(plan[relative]);receipt.pop('entry_router',None)
        data=plan['game/index.html'];receipt['files']['index.html']={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        plan[relative]=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode()
    originals={}
    for relative in plan:
        p=root/relative;originals[relative]=p.read_bytes()if p.exists()else None
    manifest_relative='portrait/site-receipt.json'if combined else'site-receipt.json'
    if manifest_relative not in originals:
        p=root/manifest_relative;originals[manifest_relative]=p.read_bytes()if p.exists()else None
    backup.mkdir(parents=True,exist_ok=False)
    for relative,data in originals.items():
        if data is not None:
            p=backup/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    try:
        for relative,data in plan.items():atomic(root/relative,data)
        receipt=json.loads((package/'site/portrait/site-receipt.json').read_text())
        if not combined:receipt.pop('entry_router',None)
        for name in list(receipt['files']):
            p=base/name
            if p.is_file():receipt['files'][name]={'bytes':p.stat().st_size,'sha256':digest(p)}
            else:del receipt['files'][name]
        atomic(root/manifest_relative,(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode())
        resources=json.loads((base/'game/resource-map.json').read_text())
        for resource in resources['resources'].values():
            for encoding in ['raw','gzip']:
                for part in resource[encoding]:
                    p=base/'game'/part['path']
                    if not p.is_file()or p.stat().st_size!=part['bytes']or digest(p)!=part['sha256']:raise ValueError('Resource missing or different: '+part['path'])
    except Exception:
        for relative,data in originals.items():
            if data is None:(root/relative).unlink(missing_ok=True)
            else:atomic(root/relative,data)
        raise
    report={'version':manifest['version'],'layout':'combined'if combined else'standalone-mobile','site_root':str(root),'backup':str(backup),'files_written':len(plan),'resource_parts_verified':True,'publish_performed':False}
    (backup/'UPDATE-REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--site-root',type=Path,required=True);parser.add_argument('--backup-dir',type=Path)
    args=parser.parse_args();root=args.site_root.resolve()
    backup=args.backup_dir.resolve()if args.backup_dir else root.parent/('shanhai-backup-inventory-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
    print(json.dumps(apply(Path(__file__).resolve().parent,root,backup),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
