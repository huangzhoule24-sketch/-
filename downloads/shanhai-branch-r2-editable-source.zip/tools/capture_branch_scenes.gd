extends SceneTree
## Explicit completed-guide layout fixtures, not natural campaign/physical-phone evidence.
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var ui
func _init():call_deferred("run")
func settle():
 for i in range(25):await process_frame
func shot(name):
 ui.toast_label.hide();await settle();await RenderingServer.frame_post_draw;root.get_texture().get_image().save_png("/workspace/-/build/branch-r1/"+name+".png")
func run():
 for rid in["india","nordic","greece"]:
  root.size=Vector2i(1280,800);ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle();ui.return_to_restaurant();await settle()
  var r=ui.model.full_rules.international;r.perform("int_open",{"region":rid});var first=str(r.definition("regions",rid).dishes[0]);r.perform("int_auto",{"region":rid,"id":first})
  for n in range(49):ui.model.state.total_minutes+=1;r.tick()
  ui.scene_switcher.visit(rid);ui.model.set_paused(true);await shot(rid+"-primary-desktop")
  root.size=Vector2i(390,844);ui.update_ui_layout();await settle();ui.refresh();ui.map_view.house().fit_all();await shot(rid+"-primary-phone-fit")
  ui.map_view.house().focus_room("dining");await shot(rid+"-primary-phone-hall")
  ui.map_view.house().focus_room("kitchen");await shot(rid+"-primary-phone-kitchen")
  ui.scene_switcher.manage("店铺");await shot(rid+"-phone-management")
  ui.queue_free();await settle()
 quit()
