#!/usr/bin/env python3
"""Apply the UI overlay to exact old layouts and preserve custom landing pages."""
import json,runpy,shutil
from package_release import BUILD,sha256,write_json

def main():
    package=BUILD/'workbuddy-ui-update';apply=runpy.run_path(str(package/'apply-update.py'))['apply'];out=BUILD/'ui-refresh-r1/apply-tests';out.mkdir(parents=True,exist_ok=True);checks=[];reports=[]
    for shape,source in [('combined',BUILD/'inventory-site'),('standalone-mobile',BUILD/'portrait-site'),('standalone-desktop',BUILD/'web-site')]:
        target=out/shape;backup=out/(shape+'-backup')
        for p in [target,backup]:
            if p.exists():shutil.rmtree(p)
        shutil.copytree(source,target);reports.append(apply(package,target,backup))
        desired=BUILD/'ui-r1-site'if shape=='combined'else BUILD/'ui-export-site/game';actual=target if shape=='combined'else target/'game'
        for p in desired.rglob('*'):
            if p.is_file():
                q=actual/p.relative_to(desired)
                if p.name=='site-receipt.json':assert json.loads(p.read_text())==json.loads(q.read_text())
                else:assert sha256(p)==sha256(q),str(q)
        checks.append({'ok':True,'label':shape+' equals the tested runtime, all parts verified, backup created'})
    home=out/'combined/index.html';custom=home.read_bytes()+b'\n<!-- WorkBuddy custom landing page -->';home.write_bytes(custom);backup=out/'custom-backup'
    if backup.exists():shutil.rmtree(backup)
    apply(package,home.parent,backup);assert home.read_bytes()==custom
    checks.append({'ok':True,'label':'Repeat update preserves a custom landing page'})
    wrong=out/'wrong-build';(wrong/'game').mkdir(parents=True,exist_ok=True);(wrong/'game/export-receipt.json').write_text(json.dumps({'game_source':{'sha256':'unrelated'}}))
    try:apply(package,wrong,out/'wrong-backup')
    except ValueError:checks.append({'ok':True,'label':'Unrecognized build refused before writes'})
    else:raise AssertionError('Unrecognized build accepted')
    write_json(out/'report.json',{'checks':checks,'reports':reports,'errors':[]});print(json.dumps(checks,indent=2))
if __name__=='__main__':main()
