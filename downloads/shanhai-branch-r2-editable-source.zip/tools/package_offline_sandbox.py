#!/usr/bin/env python3
"""Package the already exported offline-only Windows free-play build. No deployment."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import struct
import zipfile

from package_release import ROOT, BUILD, game_source_fingerprint, sha256, utc_now, write_json

OUT = BUILD / "offline-sandbox"
ARCHIVE = "shanhai-offline-freeplay-win64-20261102.zip"


def launch_text(flags: str, log: str) -> bytes:
    # Use real CRLF; literal backslash-r/backslash-n produces broken CMD files.
    body = f'''@echo off
setlocal
cd /d "%~dp0"
if not exist "%LOCALAPPDATA%\\ShanhaiFreePlay" mkdir "%LOCALAPPDATA%\\ShanhaiFreePlay"
if not exist "%~dp0Shanhai-FreePlay.exe" goto missing
if not exist "%~dp0Shanhai-FreePlay.pck" goto missing
start "Shanhai Inn - Offline Free Play" /D "%~dp0" "%~dp0Shanhai-FreePlay.exe" {flags} --log-file "%LOCALAPPDATA%\\ShanhaiFreePlay\\{log}.log"
exit /b 0
:missing
echo Extract the ENTIRE ZIP first. Keep the EXE and PCK together.
pause
exit /b 1
'''
    return body.replace("\n", "\r\n").encode("ascii")


def main():
    exe, pck = OUT / "Shanhai-FreePlay.exe", OUT / "Shanhai-FreePlay.pck"
    with exe.open("rb") as f:
        assert f.read(2) == b"MZ"
        f.seek(0x3C)
        f.seek(struct.unpack("<I", f.read(4))[0])
        assert f.read(4) == b"PE\0\0" and f.read(2) == b"\x64\x86", "Expected Windows x64 PE"
    with pck.open("rb") as f:
        assert f.read(4) == b"GDPC", "Expected matching Godot pack"
    directory = OUT / "package" / "Shanhai-FreePlay"
    if directory.exists():
        shutil.rmtree(directory)
    directory.mkdir(parents=True)
    for source in (exe, pck):
        shutil.copy2(source, directory / source.name)
    for name, flags, log in (
        ("Start-Game.cmd", "--rendering-driver opengl3_angle --max-fps 60", "game"),
        ("Start-Low-Power.cmd", "--rendering-driver opengl3_angle --max-fps 30", "low-power"),
        ("Start-OpenGL-Fallback.cmd", "--rendering-driver opengl3 --max-fps 30", "opengl-fallback"),
    ):
        target = directory / name
        target.write_bytes(launch_text(flags, log))
        data = target.read_bytes()
        assert b"\\r\\n" not in data and b"\r\n" in data
        assert b"\n" not in data.replace(b"\r\n", b"")
    (directory / "00-先读我.txt").write_text(
        (ROOT / "docs/offline-sandbox-guide.md").read_text(encoding="utf-8"), encoding="utf-8-sig"
    )
    for tree in ("CustomAssets", "CustomAudio"):
        for source in (ROOT / tree).rglob("*"):
            if source.is_symlink() or not source.is_file() or source.name == ".gdignore":
                continue
            target = directory / tree / source.relative_to(ROOT / tree)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    licenses = directory / "licenses"
    licenses.mkdir()
    for source in (ROOT / "tools/licenses").glob("*.txt"):
        shutil.copy2(source, licenses / source.name)
    for source, name in (
        ("LICENSE.txt", "NotoSansSC-LICENSE.txt"),
        ("ArkPixel-OFL.txt", "ArkPixel-OFL.txt"),
        ("DejaVuSans-LICENSE.txt", "DejaVuSans-LICENSE.txt"),
        ("NotoCJKSupplement-LICENSE.txt", "NotoCJKSupplement-LICENSE.txt"),
    ):
        shutil.copy2(ROOT / "assets/fonts" / source, licenses / name)
    shutil.copytree(ROOT / "assets/audio/licenses", licenses / "audio")
    shutil.copy2(ROOT / "assets/audio/CREDITS.md", licenses / "audio/CREDITS.md")
    for name in ("sources.json", "selection.json"):
        shutil.copy2(ROOT / "docs/free-sfx" / name, licenses / "audio" / name)
    for name in ("art-pipeline.md", "audio-pipeline.md", "audio-resource-list.csv"):
        shutil.copy2(ROOT / "docs" / name, directory / name)
    source = game_source_fingerprint()
    receipt = {
        "version": "SH-OFFLINE-FREEPLAY-R1", "created_utc": utc_now(),
        "platform": "Windows 10/11 x64", "offline": True,
        "game_source": source, "online_site_updated": False,
        "files": {p.relative_to(directory).as_posix(): {"bytes": p.stat().st_size, "sha256": sha256(p)}
                  for p in sorted(directory.rglob("*")) if p.is_file()},
    }
    write_json(directory / "package-receipt.json", receipt)
    archive = BUILD / ARCHIVE
    files = sorted(p for p in directory.rglob("*") if p.is_file())
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=7) as z:
        for path in files:
            z.write(path, "Shanhai-FreePlay/" + path.relative_to(directory).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files)
        for path in files:
            assert hashlib.sha256(z.read("Shanhai-FreePlay/" + path.relative_to(directory).as_posix())).hexdigest() == sha256(path)
    assert archive.stat().st_size < 100 * 1024 * 1024, "Keep downloadable artifact below GitHub file limit"
    result = {"version": receipt["version"], "game_source": source,
              "artifact": {"file": archive.name, "bytes": archive.stat().st_size,
                           "sha256": sha256(archive), "zip_crc_valid": True, "files": len(files)}}
    write_json(OUT / "package-build.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
