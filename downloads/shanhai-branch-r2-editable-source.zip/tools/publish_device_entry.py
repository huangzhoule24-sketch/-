#!/usr/bin/env python3
"""Publish tested device routing, refusing changes to either game binary set."""
import json

import publish_web_site as publisher
from package_release import BUILD, sha256, write_json


def main():
    revision = 'web-auto-r1'
    publisher.REVISION = revision
    receipt = json.loads((BUILD / revision / 'build.json').read_text())
    site = BUILD / 'device-site'
    for name, entry in receipt['changed_files'].items():
        assert sha256(site / name) == entry['sha256']
    for name in ['browser', 'preview-browser', 'site-browser']:
        report = json.loads((BUILD / revision / name / 'report.json').read_text())
        assert not report['errors'] and all(c['ok'] for c in report['checks']), name
    for variant in ['desktop', 'mobile']:
        report = json.loads((BUILD / revision / (variant + '-http.json')).read_text())
        assert report['gzip_sha_and_roundtrip_verified']
        assert report['game_source'] == receipt[variant + '_source']
    names = publisher.git(['ls-tree', '-rz', '--name-only', receipt['parent']], raw=True).decode().rstrip('\0').split('\0')
    entries = {p.relative_to(site).as_posix(): p for p in site.rglob('*') if p.is_file()}
    assert set(names).issubset(entries), 'Existing site files must be retained'
    for name in names:
        if name not in receipt['changed_files']:
            assert publisher.git(['show', receipt['parent'] + ':' + name], raw=True) == entries[name].read_bytes(), name
    for variant in ['', 'portrait/']:
        path = site / variant
        manifest = json.loads((path / 'site-receipt.json').read_text())
        for name, entry in manifest['files'].items():
            assert (path / name).stat().st_size == entry['bytes'] and sha256(path / name) == entry['sha256'], variant + name
    commit = publisher.publish('gh-pages', entries, 'Automatically select desktop or native mobile game at the shared entry', receipt['parent'])
    changed = publisher.git(['diff-tree', '-z', '--no-commit-id', '--name-only', '-r', receipt['parent'], commit], raw=True).decode().rstrip('\0').split('\0')
    assert sorted(changed) == sorted(receipt['changed_files'])
    assert all('/parts/' not in n and not n.endswith('.bin') for n in changed)
    proof = {
        'version': revision, 'branch': 'gh-pages', 'commit': commit, 'parent': receipt['parent'],
        'entry_url': 'https://huangzhoule24-sketch.github.io/-/',
        'desktop_source': receipt['desktop_source'], 'mobile_source': receipt['mobile_source'],
        'changed_files': changed, 'game_binary_chunks_unchanged': True,
        'live_http_verified': False, 'physical_devices_tested': False,
    }
    write_json(BUILD / revision / 'publication.json', proof)
    print(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
