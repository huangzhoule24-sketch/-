#!/usr/bin/env python3
"""Publish a complete site snapshot and verify its single GitHub archive download."""
import hashlib
import json
import urllib.request
import zipfile
from pathlib import Path

import publish_web_site as publisher
from package_release import BUILD, sha256, write_json


def main():
    revision = 'web-auto-r1-package'
    publisher.REVISION = revision
    output = BUILD / revision
    package = json.loads((output / 'package.json').read_text())
    site = BUILD / 'complete-device-site'
    entries = {p.relative_to(site).as_posix(): p for p in site.rglob('*') if p.is_file()}
    info = json.loads((site / 'PACKAGE-INFO.json').read_text())
    assert len(entries) == package['zip_files']
    for name, expected in info['files'].items():
        assert entries[name].stat().st_size == expected['bytes'] and sha256(entries[name]) == expected['sha256'], name
    branch = 'web-auto-r1-complete-20261104'
    remote = publisher.git(['ls-remote', '--heads', 'origin', branch])
    if remote:
        commit = remote.split()[0]
        names = publisher.git(['ls-tree', '-rz', '--name-only', commit], raw=True).decode().rstrip('\0').split('\0')
        assert sorted(names) == sorted(entries), 'Existing package differs; refusing to replace it'
        for name in names:
            assert publisher.git(['show', commit + ':' + name], raw=True) == entries[name].read_bytes(), name
    else:
        commit = publisher.publish(branch, entries, 'Complete desktop and portrait game website with automatic device entry')
    assert int(publisher.git(['rev-list', '--count', commit])) == 1, 'Package must have no development history'
    # The whole ZIP exceeds Git's per-blob limit. GitHub archives this ordinary
    # file tree server-side, retaining one normal ZIP and every game resource.
    url = 'https://github.com/huangzhoule24-sketch/-/archive/' + commit + '.zip'
    target = output / 'public-complete-site.zip'
    print(json.dumps({'snapshot_commit': commit, 'download_url': url}), flush=True)
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Shanhai-complete-package-verifier'}), timeout=120) as response:
        status = response.status
        with target.open('wb') as handle:
            while block := response.read(1024 * 1024):
                handle.write(block)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        files = [n for n in archive.namelist() if not n.endswith('/')]
        prefix = files[0].split('/', 1)[0] + '/'
        assert all(n.startswith(prefix) for n in files)
        assert sorted(n[len(prefix):] for n in files) == sorted(entries)
        for name, path in entries.items():
            assert hashlib.sha256(archive.read(prefix + name)).hexdigest() == sha256(path), name
    assert publisher.git(['ls-remote', '--heads', 'origin', 'gh-pages']).split()[0] == package['site_commit'], 'Live website changed unexpectedly'
    proof = {
        'version': package['version'], 'site_commit': package['site_commit'],
        'snapshot_branch': branch, 'snapshot_commit': commit, 'live_website_unchanged': True,
        'download': {'url': url, 'http_status': status, 'bytes': target.stat().st_size,
                     'sha256': sha256(target), 'zip_files': len(files), 'top_level_folder': prefix,
                     'zip_crc_valid': True, 'every_file_matches_snapshot': True},
        'published_site_files_preserved': package['published_files_preserved'],
        'includes_desktop_and_mobile': True,
    }
    write_json(output / 'publication.json', proof)
    (output / 'PUBLIC-SHA256SUMS.txt').write_text(sha256(target) + '  public-complete-site.zip\n')
    print(json.dumps(proof, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
