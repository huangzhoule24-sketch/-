/* Local dummy preview parameters only. No real provider token is stored in reports. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8045').replace(/\/$/,'');
const out=process.argv[2]||'build/web-r8/preview-browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const context=await browser.newContext(),page=await context.newPage(),checks=[],errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 function check(value,label){checks.push({label,ok:!!value});if(!value)throw Error(label);}
 const version=process.env.SHANHAI_SITE_VERSION||'web-r8';
 const token='local-dummy-preview-token',time='1700000000',expected=root+'/?eo_token='+token+'&eo_time='+time;
 try{
  await page.goto(root+'/share.html');check(await page.locator('#share-url').inputValue()===root+'/?classroom=1&v='+version,'Public sharing keeps the normal classroom link');
  await page.goto(expected+'&irrelevant=not-for-sharing');
  const link=await page.locator('a[href*="share.html"]').first().getAttribute('href'),target=new URL(link,root);
  check(target.search===''&&target.hash.includes('eo_token='+token),'Homepage passes preview access to sharing in the fragment only');
  check(!target.hash.includes('irrelevant'),'Only the two allowlisted access parameters are carried');
  await page.locator('a[href*="share.html"]').first().click();check(await page.locator('#share-url').inputValue()===expected,'Share entry retains complete preview access without adding new signed query parameters');
  check((await page.locator('#share-status').textContent()).includes('有效期'),'Temporary-link sharing shows a validity reminder');
  await page.locator('#qr').screenshot({path:path.join(out,'signed-qr-dummy.png')});
  const downloadPromise=page.waitForEvent('download');await page.locator('#download').click();const download=await downloadPromise;await download.saveAs(path.join(out,'signed-qr-dummy.svg'));check(fs.readFileSync(path.join(out,'signed-qr-dummy.svg'),'utf8').includes('<svg'),'QR download contains an SVG');
  await page.goto(root+'/share.html');check(await page.locator('#share-url').inputValue()===expected,'Same-tab refresh and direct sharing retain the preview parameters');
  await page.goto(root+'/?eo_token=new-dummy-token&eo_time=1800000000');await page.locator('a[href*="share.html"]').first().click();check((await page.locator('#share-url').inputValue()).includes('eo_token=new-dummy-token'),'A newly supplied access link replaces the old one');
  const isolated=await browser.newContext(),p2=await isolated.newPage();await p2.goto(root+'/share.html');check(await p2.locator('#share-url').inputValue()===root+'/?classroom=1&v='+version,'Preview access is not copied to an unrelated browser context');await isolated.close();
  const blocked=await browser.newContext(),p3=await blocked.newPage();await p3.addInitScript(()=>Object.defineProperty(window,'sessionStorage',{get(){throw Error('Storage unavailable for test');}}));await p3.goto(expected);await p3.locator('a[href*="share.html"]').first().click();check(await p3.locator('#share-url').inputValue()===expected,'Fragment handoff works when session storage is unavailable');await blocked.close();
 }catch(e){errors.push(String(e.stack||e));await page.screenshot({path:path.join(out,'failure.png')}).catch(()=>{});}
 const receipt=await(await page.request.get(root+'/game/export-receipt.json')).json();fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt.game_source,checks,errors,credentials:'Only fabricated local preview parameters used'},null,2));console.log(JSON.stringify({checks,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
