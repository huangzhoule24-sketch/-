#!/usr/bin/env python3
"""Build both UI views from the current project, preserving the device entry."""
import json
import shutil
from package_release import BUILD,ROOT,sha256,write_json,utc_now
from publish_web_site import git

REVISION='ui-refresh-r1';VERSION='SH-WEB-UI-R1'


def main():
    baseline='171dc41f719b4bd83abfdc589bb017f4d3c9c9a9';site=BUILD/'ui-r1-site';fresh=BUILD/'ui-export-site'
    if site.exists():shutil.rmtree(site)
    names=git(['ls-tree','-rz','--name-only',baseline],raw=True).decode().rstrip('\0').split('\0')
    old={n:git(['show',baseline+':'+n],raw=True)for n in names}
    for n,data in old.items():
        p=site/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    for name in ['device-router.js','device-entry.css']:shutil.copyfile(ROOT/'web/site'/name,site/name)
    current=json.loads((fresh/'site-receipt.json').read_text())
    for prefix,variant in [('', 'desktop'),('portrait/','mobile')]:
        base=site/prefix;shutil.copytree(fresh/'game',base/'game',dirs_exist_ok=True)
        for name,kind in [('index.html','home'),('share.html','share'),('game/index.html','game')]:
            path=base/name
            text=(fresh/name).read_text()if kind=='game'else(ROOT/'web/site'/name).read_text().replace('SH-WEB-R8',VERSION).replace('web-r8','web-ui-r1')
            depth=(1 if prefix else 0)+(1 if kind=='game'else 0);root='../'*depth if depth else'./'
            include='<script src="'+root+'device-router.js?v=web-ui-r1" data-root="'+root+'" data-variant="'+variant+'" data-page="'+kind+'"></script>'
            text=text.replace('<head>','<head>\n'+include,1)
            if kind=='game':
                text=text.replace('(function () {','(function () {\n\tif (window.shanhaiDeviceRoute && window.shanhaiDeviceRoute.redirecting) return;',1)
                text=text.replace('</head>','<meta name="shanhai-build" content="'+VERSION+'">\n</head>',1)
            else:text=text.replace('</head>','<link rel="stylesheet" href="'+root+'device-entry.css?v=web-ui-r1">\n</head>',1)
            path.write_text(text)
        shutil.copyfile(ROOT/'docs/ui-refresh-r1.md',base/'README.md')
        receipt_path=base/'game/export-receipt.json';receipt=json.loads(receipt_path.read_text());page=base/'game/index.html'
        receipt['files']['index.html']={'bytes':page.stat().st_size,'sha256':sha256(page)};receipt['entry_router']={'version':'web-ui-r1','variant':variant};write_json(receipt_path,receipt)
        manifest=json.loads((base/'site-receipt.json').read_text())
        for key in ['version','game_source','compression','resource_map']:manifest[key]=current[key]
        manifest['version']=VERSION;manifest['created_utc']=utc_now();manifest['entry_router']={'version':'web-ui-r1','variant':variant}
        for name in manifest['files']:
            p=base/name;manifest['files'][name]={'bytes':p.stat().st_size,'sha256':sha256(p)}
        write_json(base/'site-receipt.json',manifest)
    changes={p.relative_to(site).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p)}for p in site.rglob('*')if p.is_file()and old.get(p.relative_to(site).as_posix())!=p.read_bytes()}
    assert all(not n.endswith(('.wasm','.exe'))for n in changes)
    write_json(BUILD/REVISION/'site-build.json',{'version':VERSION,'parent':baseline,'game_source':current['game_source'],'changes':changes,'both_views_current':True})
    print(json.dumps({'version':VERSION,'source':current['game_source'],'changes':len(changes)},indent=2))


if __name__=='__main__':main()
