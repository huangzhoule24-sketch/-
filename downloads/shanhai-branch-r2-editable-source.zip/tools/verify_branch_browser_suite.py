#!/usr/bin/env python3
"""Run isolated real-input browser cases with at most two renderers, then merge proof."""
import argparse,concurrent.futures,json,os,subprocess
from pathlib import Path
from package_release import ROOT,BUILD,game_source_fingerprint,write_json

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--only',help='Comma-separated failed cases to rerun; preserve the other recorded cases');args=parser.parse_args()
 out=BUILD/'branch-r1';expected=game_source_fingerprint();env=dict(os.environ);env.setdefault('SHANHAI_SITE_URL','http://127.0.0.1:8069');env['SHANHAI_SITE_VERSION']='web-branch-r1'
 cases=[(rid,'verify_international_browser.cjs','browser-'+rid,{'SHANHAI_REGIONS':rid,'SHANHAI_BRANCH_CHECKS':'1','SHANHAI_VISUAL_CHECKS':'1'})for rid in['india','nordic','greece']]
 cases += [(name,tool,name+'-browser',{})for name,tool in[('music','verify_music_continuity_browser.cjs'),('portrait','verify_native_portrait_browser.cjs'),('device','verify_device_entry_browser.cjs'),('share','verify_preview_links.cjs'),('site','verify_site_browser.cjs')]]
 def run(case):
  name,tool,folder,extra=case;local=dict(env);local.update(extra)
  print('START '+name,flush=True)
  with(out/('suite-'+name+'.log')).open('w')as log:r=subprocess.run(['node',str(ROOT/'tools'/tool),str(out/folder)],cwd=ROOT,env=local,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  report=json.loads((out/folder/'report.json').read_text());ok=r.returncode==0 and not report['errors']and all(c['ok']for c in report['checks'])
  if 'game_source'in report:ok=ok and report['game_source']==expected
  value={'case':name,'ok':ok,'exit':r.returncode,'checks':len(report['checks']),'actions':len(report.get('actions',[])),'report':folder+'/report.json'}
  print(json.dumps(value),flush=True);return value
 selected=cases if not args.only else[c for c in cases if c[0]in args.only.split(',')]
 old=json.loads((out/'browser-suite.json').read_text()).get('cases',[])if args.only and(out/'browser-suite.json').exists()else[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:fresh=list(pool.map(run,selected))
 result_map={v['case']:v for v in old+fresh};results=[result_map.get(c[0],{'case':c[0],'ok':False,'missing':True})for c in cases]
 merged={'game_source':expected,'checks':[],'actions':[],'regions':[],'errors':[],'emulation':'Chromium desktop and Android touch, DPR2; real inputs, no physical-device claim'}
 for rid in['india','nordic','greece']:
  report=json.loads((out/('browser-'+rid)/'report.json').read_text())
  for k in['checks','actions','regions','errors']:merged[k].extend(report[k])
 write_json(out/'browser/report.json',merged);write_json(out/'browser-suite.json',{'game_source':expected,'cases':results,'errors':[v['case']for v in results if not v['ok']]})
 assert all(v['ok']for v in results),results
if __name__=='__main__':main()
