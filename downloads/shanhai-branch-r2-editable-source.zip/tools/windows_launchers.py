"""Generate portable launchers. No elevation, registry changes, or security bypasses."""
from pathlib import Path
EXE='shanhai-v1.9.5-menu-r5.exe'
def write_launchers(directory:Path):
    for name,driver,fps in [('Start-Game.cmd','opengl3_angle',60),('Start-Low-Power.cmd','opengl3_angle',30),('Start-OpenGL-Fallback.cmd','opengl3',60)]:
        text=f'''@echo off
setlocal
cd /d "%~dp0"
if not exist "{EXE}" goto missing
if not exist "shanhai-v1.9.5-menu-r5.pck" goto missing
if /i "%PROCESSOR_ARCHITECTURE%"=="x86" if "%PROCESSOR_ARCHITEW6432%"=="" goto arch
if not defined LOCALAPPDATA set "LOCALAPPDATA=%TEMP%"
set "SHANHAI_LOG_DIR=%LOCALAPPDATA%\\ShanhaiInn"
if not exist "%SHANHAI_LOG_DIR%" mkdir "%SHANHAI_LOG_DIR%" >nul 2>&1
start "" /d "%~dp0" "%~dp0{EXE}" --rendering-method gl_compatibility --rendering-driver {driver} --max-fps {fps} --log-file "%SHANHAI_LOG_DIR%\\{name[:-4]}.log"
exit /b 0
:missing
echo Please extract the ENTIRE ZIP to a local folder before starting.
echo Keep the EXE and PCK in the same folder. Do not run inside the ZIP.
pause
exit /b 1
:arch
echo This build requires 64-bit Windows 10 or Windows 11.
pause
exit /b 1
'''
        (directory/name).write_bytes(text.replace('\n','\r\n').encode('ascii'))
