#!/usr/bin/env python3
"""Author the three regions, recipes and bilingual cultural reading as game data."""
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PLAN=ROOT/'docs/proposals/localization-india-nordic-greece-integrated-r2-20261105.md'

def pair(zh,en):return {'zh':zh,'en':en}
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

REGIONS=[
 ('india','印度','India','晨香廊','Morning Spice Veranda',350,24,500,505,
  '红瓦长檐下，早餐的蒸汽从市集第一盏灯旁升起。','Breakfast steam rises beneath a red-tiled veranda as the market opens.',
  '卡纳塔克沿海、门格洛尔一带的日常食肆参考；菜单保留各自地域。','An original eatery inspired by coastal Karnataka and Mangaluru; each dish keeps its own regional origin.'),
 ('nordic','北欧','Nordic region','港灯食屋','Harbour Lamplight',400,28,450,460,
  '窗外的船还没有靠岸，屋里先为晚归的人留了一锅热汤。','The ship has not docked; a warm pot already waits for those coming home.',
  '挪威伯根一带海港木屋参考，菜单含明确标注的丹麦、瑞典合作菜。','A Bergen-inspired harbour house, with clearly credited Danish and Swedish menu collaborations.'),
 ('greece','希腊','Greece','橄榄炉庭','Olive Hearth Courtyard',450,26,505,510,
  '炉门开合之间，院子里的桌子有了不同的相聚方式。','Between oven rounds, the courtyard finds more than one way to share a meal.',
  '基克拉泽斯群岛与锡夫诺斯院落食肆参考，非古代神殿复原。','An original courtyard eatery inspired by the Cyclades and Sifnos, not a reconstruction of an ancient temple.')]

# English cultural descriptions are project paraphrases, never invented quotations.
CAST_EN=[
 ('Garuda','Messenger partner','India’s divine bird Garuda is associated with Vishnu. The opening book of the Mahabharata tells of Vinata, the serpent family and his quest for amrita. His restaurant delivery work is an original continuation.','He sets the last sack down and asks which table is still waiting.','rush','加急采购','Rush procurement','以额外运费缩短一批备料；完成后需要休息。','Pay extra carriage to shorten one batch; the partner rests afterwards.'),
 ('Lotus-pool Keeper · Naga','Preparation partner','Nagas are serpent or serpent-shaped beings in several South Asian traditions. Some stories connect them with water, guardianship or treasure; they do not all share one temperament. This keeper is an original individual.','She writes the start time on each jar before checking the water.','ferment','分批发酵','Fermentation planning','发酵类备料时间缩短；合作名额有限。','Fermented preparations finish sooner, using one of the limited partner slots.'),
 ('Woodland Storekeeper · Yaksha','Supply partner','Yakshas have varied roles in Indian religious and literary traditions, including associations with place, nature and wealth. This woodland storekeeper is an original individual, not a description of every yaksha.','He asks when the next sack will be used before accepting a bulk discount.','stock','核对采购','Supply check','采购并备料的原料成本降低，仍须按实际数量付款。','Reduce ingredient purchase cost; every prepared portion is still paid for.'),
 ('Spice Scorekeeper · Gandharva','Cooking partner','Gandharvas are associated with celestial music in Indian traditions. Translating musical timing into a restaurant preparation method is this game’s invention.','He lifts the lid and invites you to smell before adding another spice.','spice','香料备料','Spice preparation','香料类菜品备料更快，并能承接低辣定制。','Prepare spice-based dishes sooner and support requested mild versions.'),
 ('Table Guide · Apsara','Dining host','Apsaras appear in Indian mythological and literary traditions, often in connection with dance and music. This host’s identity, choices and restaurant life are original.','She finds a quiet seat for the guest who does not want to join the celebration.','host','分流领席','Dining coordination','缩短装盘交接时间；不会强迫顾客参加聚餐。','Shorten service handover without making every guest join a group meal.'),
 ('Ratatoskr','Message-checking partner','In Eddic accounts, Ratatoskr runs along the world tree carrying words between its upper and lower inhabitants. Learning to distinguish a report from verified news belongs to this game’s story.','For once, the squirrel lays both letters down before giving an opinion.','verify','核实到货','Verify forecast','可花工时核实本次天气与供货消息。','Spend working time to verify the current weather and supply report.'),
 ('Brokkr','Equipment partner','Brokkr is a dwarf smith in the treasure-making narrative of the Prose Edda. Names and section numbers vary between translations. His restaurant equipment work is original.','He asks how long the oven may stop before he reaches for his tools.','oven','炉具改装','Oven craft','烤炉类备料更快；维护升级仍要付费并停用。','Prepare oven dishes sooner; maintenance upgrades still cost money and time.'),
 ('Skadi','Winter-route partner','Skadi is a figure of mountain travel, skiing and hunting in Norse mythology. Her family and relationship with Njord appear in Eddic narratives. This local delivery cooperation is original.','She crosses out the short route: it will not be the quick route today.','route','冬路安排','Winter route','不利天气中的备料运输延误减少。','Reduce the supply delay affecting preparation during poor weather.'),
 ('Harbour-house Nisse','Handover partner','Nisse belongs to Danish and Norwegian household and farm folklore, with related but distinct traditions such as the Swedish tomte. This individual is not presented as an Eddic god.','He adds his own name to a handover sheet that used to overlook him.','night','备料交接','Preparation handover','增加一项并行备料位，仍受设备及休息限制。','Add one concurrent preparation slot, while equipment and rest still apply.'),
 ('Forest-edge Huldra','Seasonal supplier','Huldra is a forest-associated figure in Norwegian and related folklore. A cow tail is a familiar identifying feature; other details depend on the local version. This supplier is an original individual.','She brings what the forest can offer, then writes down a reliable grower’s address.','season','季节供货','Seasonal supply','本地蔬菜与菌菇菜原料成本降低；不提供无限食材。','Reduce ingredient costs for vegetable and mushroom dishes, not unlimited stock.'),
 ('Hestia','Hearth adviser','Hestia is associated with hearth and household in Greek tradition, including the Homeric Hymns. Advising this restaurant’s oven rounds is an original encounter.','The fire is ready, she says; now arrange the people’s time.','batch','炉次安排','Oven rounds','烤炉备料更快，可增加一份采购批量。','Prepare oven dishes sooner and allow one extra portion per batch.'),
 ('Hermes','Harbour messenger','Hermes is associated with messages, travel and exchange in Greek tradition. The Homeric Hymn to Hermes is one source for his literary character. The restaurant agreements here are original.','Instead of saying soon, he points to the second oven round on the order sheet.','promise','约定时段','Clear promises','订单等待时限延长，承诺仍须实际履约。','Allow a longer agreed order window; the meal still has to be delivered.'),
 ('Arachne','Textile and table designer','A major surviving account of Arachne’s weaving contest and transformation is in Book VI of Ovid’s Metamorphoses, a Latin work by a Roman poet. Her later restaurant career is this game’s invention.','She trims the cloth that blocks the aisle and joins the pattern again at the corner.','layout','桌席设计','Table design','共享席布局提高接单容量，同时增加分餐工作。','A shared-table layout admits more orders and needs additional portioning work.'),
 ('Spring Recordkeeper · Naiad','Water and handover partner','Naiads are freshwater nymphs connected with springs, streams and related waters in Greek tradition. They are not a name for every sea divinity. This spring keeper is an original individual.','She marks the water level, then removes a promise the kitchen cannot yet keep.','water','餐具交接','Dishware handover','缩短分餐与清洁交接时间；不会以神力代替实际流程。','Shorten portioning and handover without replacing the actual work with magic.'),
 ('Demeter','Seasonal grain adviser','Demeter is associated with grain and agriculture in Greek tradition. The Homeric Hymn to Demeter tells an important story involving Persephone. The restaurant’s seasonal cooperation is original.','She asks which dishes will stay and how much room the next harvest will have.','grain','分期供粮','Grain contract','谷物、豆类与派饼原料成本降低，仍逐批采购。','Reduce ingredient cost for grain, pulse and pastry dishes; buy each batch normally.')]

FOOD=[
 ('Masala dosa',4.2,13,12,'griddle',['fermented','spice','vegetable'],[],['vegan','mild'],'米、乌豆、土豆、洋葱、芥菜籽、香料、植物油','Rice, black gram, potato, onion, mustard seed, spices and vegetable oil','南印度饮食传统；本店选植物油版本。','A South Indian food tradition; this house uses a vegetable-oil version.'),
 ('Chole bhature',4.8,14,10,'fryer',['spice','grain'],['gluten','milk'],['vegetarian','mild'],'鹰嘴豆、番茄、洋葱、香料、小麦面粉、酸奶','Chickpeas, tomato, onion, spices, wheat flour and yogurt','与旁遮普和北印度饮食联系密切；本店面团含酸奶。','Closely associated with Punjab and North Indian food; this house dough contains yogurt.'),
 ('Hyderabadi-style chicken biryani',8.5,25,24,'oven',['spice','grain'],['milk','chicken'],['mild'],'长粒米、鸡肉、酸奶、洋葱、香料；基础版不加坚果','Long-grain rice, chicken, yogurt, onion and spices; no nuts in the base recipe','海得拉巴风味样例；分层焖制与预约锅量影响排程。','A Hyderabad-inspired version; layered cooking and planned batches shape the schedule.'),
 ('Idli with sambar',3.8,12,14,'steamer',['fermented','vegetable','grain'],[],['vegan','mild'],'发酵米豆蒸糕；扁豆、蔬菜、罗望子与香料汤','Fermented rice-and-pulse cakes; lentil, vegetable, tamarind and spice soup','南印度早餐组合；蒸糕与汤按一道组合餐售卖。','A South Indian breakfast combination, sold here as one meal.'),
 ('Gulab jamun',4.5,13,16,'fryer',['sweet','grain'],['milk','gluten'],['vegetarian'],'乳固形物、少量小麦粉、糖浆、豆蔻、玫瑰水','Milk solids, a little wheat flour, syrup, cardamom and rose water','印度及南亚广泛流传的糖浆甜点；同名配方存在差异。','A syrup sweet found widely in India and South Asia; recipes vary.'),
 ('Mushroom and egg smorrebrod',5,15,6,'cold',['vegetable','grain'],['gluten','egg','milk'],['vegetarian'],'黑麦面包、蘑菇、鸡蛋、黄油','Rye bread, mushrooms, egg and butter','丹麦开放三明治形式，本店选蘑菇鸡蛋搭配。','A Danish open-sandwich form with this house’s mushroom-and-egg topping.'),
 ('Swedish meatball plate',8,23,14,'hot',['meat'],['beef','pork','gluten','egg','milk'],[],'牛猪混合肉丸、面包屑、蛋、奶油汁、土豆泥、越橘酱','Beef-and-pork meatballs, breadcrumbs, egg, cream sauce, potato mash and lingonberry preserve','瑞典餐点样例；肉丸、酱汁与配菜共同构成一餐。','A Swedish meal example with meatballs, sauce and sides.'),
 ('Gravlax',7,22,32,'cold',['cured'],['fish'],[],'鲑鱼、盐、糖、莳萝；酱汁单独说明','Salmon, salt, sugar and dill; sauce listed separately','北欧腌鲑鱼形式；腌渍不等于加热熟制。','A Nordic cured-salmon preparation; curing is not heat cooking.'),
 ('Norwegian creamy fish soup',7.5,21,18,'hot',['soup'],['fish','milk'],[],'白肉鱼、胡萝卜、韭葱、土豆、奶油','White fish, carrot, leek, potato and cream','挪威鱼汤的本店版本，不默认加入贝类。','This house’s Norwegian-style fish soup does not include shellfish by default.'),
 ('Swedish cinnamon bun',4,12,22,'oven',['grain','sweet'],['gluten','milk','egg'],['vegetarian'],'小麦、乳、黄油、糖、肉桂、豆蔻；蛋液刷面','Wheat, milk, butter, sugar, cinnamon and cardamom; egg wash','瑞典烘焙样例，螺旋纹样来自卷制；本配方不加坚果。','A Swedish baking example with a rolled spiral; this recipe has no nuts.'),
 ('Horiatiki',4,13,7,'cold',['vegetable'],['milk'],['vegetarian'],'番茄、黄瓜、洋葱、青椒、橄榄、菲达奶酪、橄榄油、牛至','Tomato, cucumber, onion, pepper, olives, feta, olive oil and oregano','当代希腊乡村沙拉样例；含乳，不加面包。','A contemporary Greek village-salad example with dairy and no bread.'),
 ('Spanakopita',6,18,18,'oven',['grain','vegetable'],['gluten','milk','egg'],['vegetarian'],'薄酥皮、菠菜、菲达奶酪、葱、香草、蛋','Filo pastry, spinach, feta, spring onion, herbs and egg','希腊咸派样例；整盘或分份都要预留烤炉时间。','A Greek savoury-pie example; whole trays and portions both need oven time.'),
 ('Sifnos-style revithada',4,14,28,'oven',['grain','vegetable'],[],['vegan'],'鹰嘴豆、洋葱、橄榄油、柠檬与调味','Chickpeas, onion, olive oil, lemon and seasoning','以锡夫诺斯相关慢烤鹰嘴豆传统为参考的本店配方。','A house recipe inspired by the slow-cooked chickpea tradition associated with Sifnos.'),
 ('Greek-style moussaka',9,26,26,'oven',['meat'],['lamb','gluten','milk','egg'],[],'茄子、土豆、羊肉末、番茄；白酱含小麦、乳和蛋','Aubergine, potato, minced lamb and tomato; wheat, milk and egg in the topping','当代希腊风味版本；相近菜肴跨地区流传，不写成神话时代食谱。','A modern Greek-style version of a dish with cross-regional histories, not a mythical-age recipe.'),
 ('Honey loukoumades',3.8,12,13,'fryer',['grain','sweet'],['gluten','honey'],['vegetarian'],'小麦发酵面团、蜂蜜、肉桂；基础版无乳蛋和坚果','Fermented wheat dough, honey and cinnamon; no dairy, egg or nuts in the base recipe','希腊饮食中的炸面团形式，周边地区有相近传统。','A fried-dough form in Greek food, with related traditions in neighbouring regions.')]

LIVES=[
 ('他把路上的风收进翅膀，先替你数清袋子，再同地面的伙伴核对交接。飞得快是一回事，肯为一句约定停下来，又是另一回事。','He folds the road’s wind into his wings, counts the sacks and checks the handover with the ground team. Flying fast and stopping to honour a promise are different skills.'),
 ('她在每只容器上记下开始的时刻。客人催单时，她会陪你看一眼蒸位，也会认真告诉你，哪些等待还不能省去。','She marks a starting time on every container. When an order is urgent, she checks the steamer with you and explains which waits cannot yet be shortened.'),
 ('他喜欢存粮，也喜欢知道每一袋粮将去往哪里。商人说起折扣，他却先问明天的菜单，免得便宜的袋子在角落里越堆越高。','He likes a full store, but also knowing where each sack will go. When a merchant offers a discount, he asks about tomorrow’s menu before another cheap sack goes into the corner.'),
 ('乐声停下以后，他仍能记得不同香料入锅的次序。他请客人先闻一闻，再慢慢说明自己喜欢什么；少一点辣椒，也可以有完整的香气。','After the music stops, he remembers the order in which spices meet the pan. He asks guests to smell first and explain what they enjoy. Less chilli can still leave a full aroma.'),
 ('她把热闹安排得有始有终，也替想安静吃饭的人留一把椅子。等最后一桌坐稳，她才用手势告诉乐师，今晚可以开始了。','She gives the celebration a beginning and an end, while keeping a chair for someone who wants a quiet meal. Only when the last table is settled does she signal the musicians.'),
 ('从前沿树奔跑时，他总想最快说完一封信。如今他在港口学会多问一句：这是谁亲眼见到的，又是哪一段还没有确认？','He once hurried to finish every message while running along the tree. At the harbour he learns one more question: who saw this, and which part is still unconfirmed?'),
 ('炉门的尺寸、烤盘的边沿，他都愿意亲手量一量。漂亮的陈设若挡住厨师，他会先搬开，再同你讨论它该放在哪里。','He measures oven doors and tray edges himself. If a handsome decoration blocks the cook, he moves it aside before discussing where it should belong.'),
 ('她熟悉山间的路，也尊重海上的风。指着地图的时候，她会把自己知道的说清楚，把仍要向船长询问的留在另一栏。','She knows the mountain paths and respects the sea wind. On the map she separates what she knows from what still needs to be asked of the captain.'),
 ('灯笼照过储藏柜，也照着他的名字。夜里盘过的数量交给早班后，他便把帽子放在一旁，认真享受轮到自己的休息。','The lantern lights the shelves and his name on the roster. After handing the night’s count to the morning team, he puts his cap aside and takes his own rest seriously.'),
 ('她不答应林子每天都给同样多的东西。篮子轻的时候，她会和你一起换一份菜单，再向可靠的种植者约好下一次供货。','She does not promise that the forest will give the same amount every day. When the basket is light, she helps change the menu and arranges the next delivery with a reliable grower.'),
 ('她留意炉火，也留意谁一直站在炉边。晚宴之前，她请你把人手与轮次写在同一张纸上，给忙碌的人也留下一段坐下来的时间。','She watches the fire and the person who has been standing beside it. Before dinner she asks for staffing and oven rounds on the same sheet, leaving time for the workers to sit down too.'),
 ('港口里的名字和时刻总在变化，他却渐渐习惯把约定写得具体。说出口的话若能在订单簿里找到，送到门口时便少一分误会。','Names and times keep changing at the port, but he grows used to making agreements precise. A promise that can be found in the order book leaves less room for misunderstanding at the door.'),
 ('她愿意为一张好看的桌布花很久，也愿意为了通道重新剪裁。图案可以接回去，作品的署名留下来，而端盘的人终于能够顺畅走过。','She spends time on a beautiful cloth and will cut it again to clear the aisle. The pattern can be joined, the maker’s name retained, and the person carrying a tray can finally pass.'),
 ('她把水位和容器的用途记得清楚。院子最忙的时候，她先帮人们找到已经准备好的餐具，再同你商量下一轮怎样安排。','She remembers the water level and each vessel’s purpose. At the courtyard’s busiest moment, she finds the ready dishware first, then helps plan the next round.'),
 ('她带来的不只有一篮谷物，还有下一季的消息。菜单可以留下几道熟悉的菜，也应给新收成腾出位置；丰收之后，安排仍要慢慢做好。','She brings grain and news of the next season. A menu may keep familiar dishes while making room for a new harvest. After abundance arrives, there is still planning to do.')]

FOOD_LIVES=[
 ('面糊早早备好，薄饼却要等客人点单后才铺上煎板。金黄的饼边卷起时，土豆馅与蘸料各在一旁，吃的人可以先认识自己的这一份。','The batter is prepared early, but the crepe meets the griddle after the order. Potato filling and separate sauces let the guest recognise each part of the meal.'),
 ('豆酱已经在锅里等候，面饼仍要临近出餐才鼓起来。先把这两件事安排好，送到桌边的热气才不会在等候中散尽。','The chickpea sauce waits in its pot; the bread puffs nearer to serving. Planning the two together keeps the meal warm when it reaches the table.'),
 ('锅盖合上以后，米与调味慢慢相遇。开锅不是最后一步，分装、核对份量与送到约好的桌边，同样值得耐心。','Once the lid closes, rice and seasoning gradually come together. Opening the pot is not the final task: portioning and reaching the agreed table also deserve care.'),
 ('白色蒸糕与带酸味的汤分开上桌，一份柔软，一份温热。两只容器各有准备的时刻，也让初次尝试的人看清这一餐的组成。','The white cakes and tangy soup arrive separately, soft and warm in different ways. Each vessel has its own preparation time and makes the meal’s parts clear to a new guest.'),
 ('乳团从油中捞起，再慢慢浸入糖浆。玫瑰水与豆蔻轻轻留下香气，一小碗甜点也有需要提前准备的等待。','The milk dough balls leave the oil and take time in syrup. Rose water and cardamom leave a gentle aroma; even a small sweet needs preparation before service.'),
 ('深色面包托住蘑菇和鸡蛋，配料没有被另一片面包藏起来。忙碌的时候，这种看得见组成的餐点，也提醒领席的人把用料说清楚。','Dark bread carries mushrooms and egg without another slice hiding the topping. In a busy service, its visible layers invite a clear explanation of the ingredients.'),
 ('肉丸、酱汁、土豆泥与越橘酱落在同一只盘中。热的一边与带酸甜的一边相邻，整份餐点才有了自己熟悉的模样。','Meatballs, sauce, mash and lingonberry preserve share a plate. The warm savoury elements sit beside the tart-sweet preserve to make this house meal complete.'),
 ('鲑鱼切成薄片，莳萝散在旁边，腌渍留下的质地与加热不同。把制作方式说清楚，比只写一个陌生名字更能帮助客人选择。','The salmon is sliced thinly with dill nearby; curing leaves a texture different from heating. Explaining the method helps a guest choose beyond an unfamiliar name.'),
 ('汤锅准备好底味，鱼肉在合适的轮次加入。窗外的天气可以变，端出去的每一碗仍要照顾到温度、份量和等着它的人。','The pot holds the soup base, and fish joins at the planned time. Weather outside may change, but each bowl still deserves attention to warmth, portion and the person waiting.'),
 ('面团卷出螺旋，肉桂藏在层与层之间。下一批出炉的时刻写在门边，路过的人便知道这阵香气还要等多久。','The dough rolls into a spiral with cinnamon between the layers. A note by the door gives the next baking time, so passers-by know how long the aroma will take.'),
 ('蔬菜洗切后再拌装，橄榄与菲达各自保留形状。颜色鲜明的一盘，既适合放上长桌，也可以按约定单独送到一个人面前。','Vegetables are cut before assembly, while olives and feta retain their shapes. The bright plate can join a shared table or be served separately as agreed.'),
 ('菠菜先处理多余水分，再与馅料一起包进薄酥皮。切开时看见的层次，来自入炉前已经完成的那些细小工作。','The spinach is drained before the filling meets filo. The layers revealed at the cut edge begin with the small tasks completed before baking.'),
 ('豆子在开门前便开始准备，陶锅也早早占好炉中的位置。等到院子里有人坐下，一份慢做的餐点才从长长的准备里来到桌边。','The chickpeas are prepared before opening and the clay pot has its place in the oven. When the courtyard fills, a slow meal finally comes from its long preparation to the table.'),
 ('蔬菜、肉酱和白酱分层铺好，出炉后仍要等待合适的切份时刻。把这一份完整送出，需要烤炉，也需要装盘台旁的配合。','Vegetables, meat sauce and the topping are layered before baking; portioning still waits after the oven. Serving an intact piece needs cooperation at the plating station as well as the oven.'),
 ('小小的面团现炸起锅，蜂蜜随后落下。它可以是长桌晚餐的最后一份热闹，也可以只是一位客人认真点下的小甜食。','The small dough pieces are freshly fried before honey is added. They can finish a shared dinner or simply be one guest’s chosen sweet.')]

def main():
 plan=PLAN.read_text();regions=[];characters=[];dishes=[];culture={'schema_version':1,'reading_version':4,'sources':[],'employees':{},'dishes':{},'guests':{}}
 source_defs=[('india_myth','印度史诗与神话参考','Indian epic and mythological traditions','《摩诃婆罗多》及神话资料入口','https://en.wikisource.org/wiki/The_Mahabharata','secondary'),('norse_myth','埃达神话参考','Eddic narratives','《诗体埃达》《散文埃达》','https://en.wikisource.org/wiki/Prose_Edda','primary'),('nordic_folk','斯堪的纳维亚民俗参考','Scandinavian folklore','Scandinavian Folk Belief and Legend；地方版本需分别校对','https://en.wikipedia.org/wiki/Scandinavian_folklore','secondary'),('greek_myth','希腊神话参考','Greek mythological traditions','《荷马颂歌》等资料入口','https://www.theoi.com/','secondary'),('arachne_ovid','阿拉克涅的传世叙事','Arachne in Ovid','奥维德《变形记》第六卷，拉丁文传世作品','https://en.wikisource.org/wiki/Metamorphoses_(Ovid)','primary'),('india_food','印度地区饮食参考','Regional food in India','本店配方参考与地域登记；不是唯一传统版本','https://www.incredibleindia.gov.in/','institutional'),('nordic_food','北欧地区饮食参考','Nordic food references','丹麦/瑞典/挪威具体做法分开登记','https://sweden.se/culture/food','institutional'),('greek_food','希腊地区饮食参考','Greek food references','当代菜品与区域流传，具体版本待地方读者复核','https://www.visitgreece.gr/experiences/gastronomy/','institutional')]
 for sid,title,en,chapter,url,kind in source_defs:culture['sources'].append({'id':'international_'+sid,'title':title,'work':title,'work_en':en,'chapter':chapter,'url':url,'accessed_on':'2026-11-05（书目登记，未逐段在线校勘）','kind':kind})
 for ri,record in enumerate(REGIONS):
  rid,zh,en,shop,shop_en,cost,rent,top,bottom,summary,summary_en,origin,origin_en=record
  regions.append({'id':rid,'name':pair(zh,en),'shop':pair(shop,shop_en),'opening_cost':cost,'daily_cost':rent,'summary':pair(summary,summary_en),'origin':pair(origin,origin_en),'cast_top':top,'cast_bottom':bottom,'characters':[],'dishes':[]})
  prefix=['IN','ND','GR'][ri]
  for index in range(5):
   number=ri*5+index;cid=prefix.lower()+'_0'+str(index+1)
   block=re.search(r'^#### '+prefix+'-0'+str(index+1)+r' (.*?)(?=^#### |^### )',plan,re.M|re.S)[0]
   heading=block.splitlines()[0].split(' ',2)[2];name=heading.split(' · ')[0];name=re.sub(r'（.*?）','',name)
   basis=re.search(r'\*\*文化依据：\*\*(.*)',block)[1].strip();opening=re.search(r'\*\*故事句：\*\*“(.*?)”',block)[1]
   en_name,role,basis_en,opening_en,skill,skill_zh,skill_en,desc,desc_en=CAST_EN[number]
   char={'id':cid,'region':rid,'column':index,'name':pair(name,en_name),'role':pair(heading.split(' · ')[1].split('（')[0]if' · 'in heading else name,role),'skill':skill,'skill_name':pair(skill_zh,skill_en),'skill_description':pair(desc,desc_en),'rest_minutes':20}
   characters.append(char);regions[-1]['characters'].append(cid)
   sid='india_myth'if ri==0 else ('norse_myth'if index<3 else'nordic_folk')if ri==1 else'arachne_ovid'if index==2 else'greek_myth';sid='international_'+sid
   sections=[{'title':'相逢在食肆','text':opening+'你在'+shop+'遇见了这位远道而来的伙伴。','source_ids':[]},{'title':'传说与来处','text':basis,'source_ids':[sid]},{'title':'灯火下的日常','text':LIVES[number][0],'source_ids':[]}]
   english=[{'title':'A meeting at the eatery','text':opening_en+' You meet this travelling companion at '+shop_en+'.'},{'title':'Stories and origins','text':basis_en},{'title':'Life in the lamplight','text':LIVES[number][1]}]
   culture['employees'][cid]={'name':name,'pinyin':en_name,'origin_label':basis.split('；')[0],'summary':opening,'sections':sections,'quotes':[],'source_ids':[sid],'reading_version':4,'international_region':rid,'en':{'name':en_name,'summary':opening_en,'sections':english}}
  table=re.findall(r'^\| '+prefix+r'-D0[1-5] (.*?) \|',plan,re.M)
  for index,heading in enumerate(table):
   did=prefix.lower()+'_d0'+str(index+1);f=FOOD[ri*5+index];en_name,cost,price,minutes,station,tags,contains,suits,ingredients,ingredients_en,background,background_en=f
   name=heading.split('（')[0];sid='international_'+['india_food','nordic_food','greek_food'][ri]
   dish={'id':did,'region':rid,'column':index,'name':pair(name,en_name),'cost':cost,'price':price,'minutes':minutes,'station':station,'tags':tags,'contains':contains,'suits':suits,'ingredients':pair(ingredients,ingredients_en),'unlock_orders':index*2,'shelf_minutes':180 if'cured'in tags else 100,'origin':pair(background,background_en)}
   dishes.append(dish);regions[-1]['dishes'].append(did)
   zh_summary='从'+shop+'的菜牌上认识'+name+'：'+ingredients+'。'
   sections=[{'title':'一份怎样的餐点','text':zh_summary+'端上桌时，客人看到的用料与本次点单记录应当一致。','source_ids':[]},{'title':'风味的来处','text':background+'同名菜在家庭、街区和餐馆中有不同做法，这张菜牌记下的是本店选定的一份。','source_ids':[sid]},{'title':'灶台与餐桌之间','text':FOOD_LIVES[ri*5+index][0],'source_ids':[]}]
   english=[{'title':'What is on the plate','text':ingredients_en+'. The served ingredients should match this order.'},{'title':'Where the flavour comes from','text':background_en+' Households, neighbourhoods and eateries have different versions; this menu records the one chosen here.'},{'title':'From preparation to the table','text':FOOD_LIVES[ri*5+index][1]}]
   culture['dishes'][did]={'name':name,'pinyin':en_name,'origin_label':background,'summary':zh_summary,'sections':sections,'quotes':[],'source_ids':[sid],'reading_version':4,'international_region':rid,'en':{'name':en_name,'summary':ingredients_en,'sections':english}}
 data={'version':1,'regions':regions,'characters':characters,'dishes':dishes,'settings':{'order_interval':24,'order_window':55,'batch_limit':3,'prep_slots':2,'service_minutes':5,'supplier_delay':4},'note':'Three original collaborating eateries. Costs, durations and skills are game design, not historical claims.'}
 assert len(characters)==len(dishes)==15
 write(ROOT/'config/international.json',data);write(ROOT/'config/international_culture.json',culture)
 print('Built 3 regions, 15 partners, 15 recipes and 30 bilingual cultural entries')

if __name__=='__main__':main()
