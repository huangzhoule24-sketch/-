#!/usr/bin/env python3
"""Package the exact published desktop + portrait website with a current user guide."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

from package_release import BUILD, ROOT, sha256, write_json, write_zip
from publish_web_site import git

REVISION = 'web-auto-r1-package'


def main():
    proof = json.loads((ROOT / 'docs/validation-artifacts/device-auto-entry/publication.json').read_text())
    commit = proof['commit']
    assert git(['ls-remote', '--heads', 'origin', 'gh-pages']).split()[0] == commit, 'Published site changed; inspect the current version first'
    for name in ['browser', 'site-browser', 'preview-browser']:
        report = json.loads((ROOT / 'docs/validation-artifacts/device-auto-entry' / (name + '-report.json')).read_text())
        assert not report['errors'] and all(c['ok'] for c in report['checks']), name
    directory = BUILD / 'complete-device-site'
    if directory.exists():
        shutil.rmtree(directory)
    names = git(['ls-tree', '-rz', '--name-only', commit], raw=True).decode().rstrip('\0').split('\0')
    assert 'device-router.js' in names and 'portrait/game/index.html' in names and 'game/index.html' in names
    files = {}
    for name in names:
        data = git(['show', commit + ':' + name], raw=True)
        target = directory / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        files[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    guide = '''《山海食肆物语》最新版完整网页资源包
SH-WEB-AUTO-R1 · 2026年11月4日

本包包含电脑版、原生竖屏手机版、设备自动识别与手动切换入口，以及两版完整游戏运行资源、美术、音乐音效、双语文化内容及素材鸣谢。
保留正常经营进度、解锁条件和存档格式，不自动解锁全部功能。

一、电脑本地打开
1. 将整个ZIP全部解压到同一个文件夹。
2. 双击根目录 Start-Web.cmd，保持启动窗口打开。
3. 该本地启动方式需要电脑安装Python 3；浏览器会打开本地游戏网址。
4. 网页游戏需要HTTP/HTTPS，请通过启动后显示的网址进入。

二、上传到现有托管平台
1. 上传解压后的全部内容，入口是根目录 index.html。
2. 保留 game 和 portrait 等全部目录及文件，不要只上传某一版。
3. 静态托管选择 Static/Other；这些文件已经构建完成，不需要Godot构建命令。
4. 玩家打开生成的网站网址即可游玩，无需安装Python或Godot。

三、设备识别
电脑自动进入电脑版（根目录SH-WEB-R8运行包）；手机自动进入原生竖屏手机版（portrait目录SH-WEB-R9-PORTRAIT运行包）。
首页可以手动选择“自动识别／电脑版／手机竖屏版”。手机旋转由游戏内部处理，不会因为横竖屏切换重启游戏。
分享页的二维码使用当前网站的统一入口，学生们不需要分别选择两条网址。

四、手机操作
餐厅单指拖动、双指缩放；大厅、后厨、庭院按钮定位，点击全景查看全貌。
管理页面和长列表上下滑动，返回与关闭位于面板标题栏。教程有独立阅读区域。

五、进度与声音
请在系统中保存进度后再关闭页面或手动切换版本。
进度保存在当前浏览器的网站本地存储中，没有新增跨设备、跨域自动同步。
音乐与音效可以独立开关；暂停时音乐暂停，继续后接着播放。

六、版本与验证
本包网页文件来自已发布提交7a01f224562072d554dce448ad04f2536e99f301。
只有本说明和PACKAGE-INFO.json是打包时新增的文件，原发布网站文件完整保留。
设备入口与两版开局、分享、网站加载共56项浏览器模拟检查通过；两版完整资源的HTTP下载重构SHA已核对。
此前的竖屏教学、装修、阅读、保存和旋转检查仍适用。尚未进行实体手机、真实Safari和课堂网络验收。

在线统一入口：https://huangzhoule24-sketch.github.io/-/?v=web-auto-r1
'''
    guide_path = directory / '最新版使用说明.txt'
    guide_path.write_text(guide, encoding='utf-8-sig')
    files[guide_path.name] = {'bytes': guide_path.stat().st_size, 'sha256': sha256(guide_path)}
    write_json(directory / 'PACKAGE-INFO.json', {
        'version': 'SH-WEB-AUTO-R1', 'published_site_commit': commit,
        'desktop_source': proof['desktop_source'], 'mobile_source': proof['mobile_source'],
        'published_files': len(names), 'published_files_unchanged': True,
        'includes_desktop_and_mobile': True, 'formal_campaign': True,
        'files': files,
    })
    for prefix in ['', 'portrait/']:
        manifest = json.loads((directory / prefix / 'site-receipt.json').read_text())
        for name, entry in manifest['files'].items():
            path = directory / prefix / name
            assert path.stat().st_size == entry['bytes'] and sha256(path) == entry['sha256'], prefix + name
    archive = BUILD / 'shanhai-v1.9.5-web-auto-r1-complete-site.zip'
    entries = [(p, p.relative_to(directory).as_posix()) for p in sorted(directory.rglob('*')) if p.is_file()]
    artifact = write_zip(archive, entries)
    with zipfile.ZipFile(archive) as package:
        assert len(package.namelist()) == len(entries)
        for path, name in entries:
            assert hashlib.sha256(package.read(name)).hexdigest() == sha256(path), name
    release = BUILD / REVISION
    release.mkdir(parents=True, exist_ok=True)
    (release / 'SHA256SUMS.txt').write_text(artifact['sha256'] + '  ' + artifact['file'] + '\n')
    shutil.copyfile(guide_path, release / '使用说明.txt')
    (release / 'release-notes.md').write_text('''完整网页资源包，包含电脑版、原生竖屏手机版和设备自动识别入口。保留正常经营、美术音频、双语文化内容、存档格式与素材鸣谢。

下载ZIP后全部解压；电脑本地使用根目录Start-Web.cmd（需要Python 3），也可将全部解压内容上传静态托管平台，入口index.html。请保留portrait目录。

设备入口、两版开局、分享及加载通过56项浏览器模拟检查；资源包全部文件与已发布网站逐项核对并验证ZIP CRC/SHA256。实体手机、Safari与课堂网络仍需实际试玩。
''')
    write_json(release / 'package.json', {
        'version': 'SH-WEB-AUTO-R1', 'site_commit': commit, 'artifact': artifact,
        'zip_files': len(entries), 'published_files_preserved': len(names),
        'all_zip_entry_hashes_verified': True, 'zip_crc_valid': True,
        'artifact_branch': 'web-auto-r1-complete-20261104',
    })
    print(json.dumps({'artifact': artifact, 'zip_files': len(entries), 'published_files_preserved': len(names)}, indent=2))


if __name__ == '__main__':
    main()
