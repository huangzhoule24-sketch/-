#!/usr/bin/env python3
"""Inspect alpha and record atlas geometry; never rewrite generated artwork."""
import json,hashlib
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def main():
 data={'version':1,'characters':{},'fixtures':{},'walking':{}}
 cast=Image.open(ROOT/'assets/art/VisualRefinement/characters.png')
 for i,id in enumerate(['bi_fang','di_jiang','xian_yang']):
  cell=cast.crop((i*512,570,(i+1)*512,1024));b=cell.getchannel('A').point(lambda a:255 if a>128 else 0).getbbox();left=max(0,b[0]-4);top=max(0,b[1]-4);right=min(512,b[2]+4);bottom=min(454,b[3]+4)
  data['characters'][id]={'portrait':[i*512,0,512,560],'pixel':[i*512+left,570+top,right-left,bottom-top],'anchors':{'bi_fang':['single leg','red-blue wings','dark tunic'],'di_jiang':['six arms','four wings','faceless'],'xian_yang':['ram horns','horse tail','green-ivory robe']}[id]}
 names=['equip_stove','equip_kitchen','equip_basic_pass','equip_basic_cashier','equip_table_two','equip_table_four','decor_lantern','chair_down']
 im=Image.open(ROOT/'assets/art/VisualRefinement/fixtures.png');w,h=im.width/4,im.height/2
 for i,id in enumerate(names):data['fixtures'][id]=[i%4*w,i//4*h,w,h]
 for rid in['india','nordic','greece']:
  im=Image.open(ROOT/'assets/art/International'/f'{rid}_walk.png');w,h=im.width/6,im.height/5
  for row in range(5):
   frames=[]
   for col in range(6):
    region=(int(col*w)+1,int(row*h)+1,int((col+1)*w)-1,int((row+1)*h)-1)
    cell=im.crop(region);mask=cell.getchannel('A').point(lambda a:255 if a>128 else 0);bounds=mask.getbbox()or(0,0,cell.width,cell.height)
    centre=mask.crop((int(cell.width*.36),0,int(cell.width*.64),cell.height)).getbbox();ground=(centre[3]if centre else bounds[3])-1
    frames.append({'bounds':list(bounds),'ground':[round(cell.width*.5,2),ground]})
   reference=max(f['ground'][1]-f['bounds'][1]for f in frames)
   data['walking'][f'{rid}:{row}']={'reference_height':reference,'frames':frames}
 (ROOT/'config/visual_refinement.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 provenance={'tool':'image_gen.imagegen','generated_assets':[{'file':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in(ROOT/'assets/art/VisualRefinement').glob('*.png')],'geometry':'Alpha inspection produces JSON only. Generated masters remain unchanged. Six-arm correction explicitly reviewed before integration.'}
 (ROOT/'docs/visual-art-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
if __name__=='__main__':main()
