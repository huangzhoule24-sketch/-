extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var ui
func _init():call_deferred("run")
func settle():
 for i in range(30):await process_frame
func shot(name):
 ui.toast_label.hide();await settle();await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png("/workspace/-/build/visual-r1/"+name+".png")
func run():
 root.size=Vector2i(1280,800);ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
 ui.return_to_restaurant();await settle();await shot("main-desktop")
 for id in["bi_fang","di_jiang","xian_yang"]:
  ui.open_culture("employees",id);await shot("culture-"+id)
 root.size=Vector2i(390,844);ui.update_ui_layout();await settle()
 ui.open_culture("employees","di_jiang");await shot("culture-phone-dijiang")
 ui.return_to_restaurant();await settle();ui.map_view.house().fit_all();await shot("main-phone")
 ui.open_panel("跨国食肆");await settle();ui.international_ui.rules().perform("int_open",{"region":"india"});ui.international_ui.refresh_page(false);await shot("india-room")
 ui.open_panel("系统");await shot("settings-phone")
 ui.queue_free();await process_frame;quit()
