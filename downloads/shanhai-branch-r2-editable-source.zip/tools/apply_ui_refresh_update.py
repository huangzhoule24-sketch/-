#!/usr/bin/env python3
"""Apply a verified UI overlay to the existing static site with a rollback copy."""
import argparse
import hashlib
import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path


def digest(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def atomic(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.ui-update-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb')as f:f.write(data)
        os.replace(tmp,path)
    finally:Path(tmp).unlink(missing_ok=True)


def apply(package,root,backup):
    manifest=json.loads((package/'UI-PATCH-MANIFEST.json').read_text())
    for name,e in manifest['files'].items():
        p=package/name
        if p.stat().st_size!=e['bytes']or digest(p)!=e['sha256']:raise ValueError('Patch integrity failed: '+name)
    combined=(root/'portrait/game/export-receipt.json').is_file();layout='combined'if combined else'single'
    bases=[root,root/'portrait']if combined else[root]
    for base in bases:
        p=base/'game/export-receipt.json'
        if not p.exists()or json.loads(p.read_text()).get('game_source',{}).get('sha256')not in manifest['accepted_sources']:raise ValueError('Unrecognized game build; preserve this project and inspect the existing version first.')
    plan={}
    for action in manifest['plans'][layout]:
        name=action['destination'];path=root/name
        if '..'in Path(name).parts or root not in path.resolve().parents:raise ValueError('Destination outside website root')
        if action.get('preserve_custom')and path.exists()and digest(path)not in action.get('known_hashes',[]):continue
        plan[name]=(package/action['source']).read_bytes()
    originals={n:(root/n).read_bytes()if(root/n).exists()else None for n in plan}
    backup.mkdir(parents=True,exist_ok=False)
    for name,data in originals.items():
        if data is not None:
            path=backup/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    try:
        for name,data in plan.items():atomic(root/name,data)
        for base in bases:
            p=base/'site-receipt.json';data=json.loads(p.read_text())
            for name in list(data['files']):
                actual=base/name
                if actual.is_file():data['files'][name]={'bytes':actual.stat().st_size,'sha256':digest(actual)}
                else:del data['files'][name]
            atomic(p,(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
            resources=json.loads((base/'game/resource-map.json').read_text())
            for resource in resources['resources'].values():
                for encoding in ['raw','gzip']:
                    for part in resource[encoding]:
                        actual=base/'game'/part['path']
                        if not actual.is_file()or actual.stat().st_size!=part['bytes']or digest(actual)!=part['sha256']:raise ValueError('Missing or different game part: '+part['path'])
    except Exception:
        for name,data in originals.items():
            if data is None:(root/name).unlink(missing_ok=True)
            else:atomic(root/name,data)
        raise
    report={'version':manifest['version'],'layout':layout,'files_written':len(plan),'backup':str(backup),'resource_parts_verified':True,'published':False}
    (backup/'UPDATE-REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');return report


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--site-root',type=Path,required=True);parser.add_argument('--backup-dir',type=Path)
    args=parser.parse_args();root=args.site_root.resolve();backup=args.backup_dir.resolve()if args.backup_dir else root.parent/('shanhai-ui-backup-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
    print(json.dumps(apply(Path(__file__).resolve().parent,root,backup),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
