/* Device routing + actual game starts; fabricated access parameters only. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8057').replace(/\/$/,''),out=process.argv[2]||'build/web-auto-r1/browser';
const version=process.env.SHANHAI_SITE_VERSION||'web-auto-r1';
const win='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36';
const android='Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36';
const iphone='Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const checks=[],errors=[],routes=[];function check(ok,label){checks.push({ok:!!ok,label});if(!ok)throw Error(label)}
 async function entry(label,opts,url,expected,extra){
  const context=await browser.newContext(opts),page=await context.newPage();page.on('pageerror',e=>errors.push(label+': '+e.message));
  if(extra)await extra(page);
  try{
   await page.goto(root+url);await page.waitForURL(u=>u.pathname===new URL(root+expected).pathname);await page.waitForSelector('#device-entry-status');
   const data=await page.evaluate(()=>window.shanhaiDeviceRoute);routes.push({label,url:page.url(),...data});
   check(data.current===data.selected&&!data.redirecting,label+' selects '+data.selected+' without a redirect loop');
   check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),label+' entry fits the viewport');
   return {context,page};
  }catch(e){await context.close();throw e}
 }
 try{
  for(const [label,options,url,expected,extra]of [
   ['Windows desktop',{userAgent:win,viewport:{width:1440,height:900}},'/','/'],
   ['Narrow desktop window',{userAgent:win,viewport:{width:390,height:844}},'/','/'],
   ['Touch Windows laptop',{userAgent:win,hasTouch:true,viewport:{width:1280,height:800}},'/','/'],
   ['Android portrait',{userAgent:android,isMobile:true,hasTouch:true,viewport:{width:390,height:844}},'/','/portrait/'],
   ['Android landscape',{userAgent:android,isMobile:true,hasTouch:true,viewport:{width:844,height:390}},'/','/portrait/'],
   ['iPhone',{userAgent:iphone,isMobile:true,hasTouch:true,viewport:{width:375,height:667}},'/','/portrait/'],
   ['Desktop opening previous phone link',{userAgent:win,viewport:{width:1440,height:900}},'/portrait/','/'],
   ['iPad desktop-style user agent',{userAgent:'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) AppleWebKit/605.1.15 Version/18.0 Safari/605.1.15',hasTouch:true,viewport:{width:768,height:1024}},'/','/portrait/',p=>p.addInitScript(()=>{Object.defineProperty(navigator,'platform',{get:()=> 'MacIntel'});Object.defineProperty(navigator,'maxTouchPoints',{get:()=>5})})],
  ]){const{context}=await entry(label,options,url,expected,extra);await context.close()}
  const{context,page}=await entry('Manual selection',{userAgent:android,isMobile:true,hasTouch:true,viewport:{width:390,height:844}},'/','/portrait/');
  await page.locator('#device-desktop').click();await page.waitForURL(u=>u.pathname===new URL(root+'/').pathname&&u.searchParams.get('device')==='desktop');
  check((await page.evaluate(()=>window.shanhaiDeviceRoute)).mode==='desktop','Phone can explicitly stay in desktop mode');
  await page.reload();check((await page.evaluate(()=>window.shanhaiDeviceRoute)).current==='desktop','Manual choice survives a refresh via URL');
  await page.locator('#en').click();check((await page.locator('#device-entry-status').textContent()).includes('Manually'),'Version selection follows English');
  await page.locator('#device-auto').click();await page.waitForURL(u=>u.pathname.endsWith('/portrait/')&&!u.searchParams.has('device'));
  check((await page.evaluate(()=>window.shanhaiDeviceRoute)).mode==='auto','Automatic selection can be restored');
  const before=page.url();await page.setViewportSize({width:844,height:390});check(page.url()===before,'Rotating never navigates or restarts the game build');
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(out,'phone-entry.png'),fullPage:true});
  await page.locator('a[href*="share.html"]').first().click();check(await page.locator('#share-url').inputValue()===root+'/?classroom=1&v='+version,'Mobile QR uses the common auto-detect root');
  await page.goto(root+'/?eo_token=fabricated-local-token&eo_time=1800000000');await page.waitForURL(u=>u.pathname.endsWith('/portrait/'));
  const signed=new URL(page.url());check(!signed.searchParams.has('eo_token')&&signed.hash.includes('eo_token=fabricated-local-token'),'Path changes carry preview access only in a browser fragment');
  await page.locator('a[href*="share.html"]').first().click();check(await page.locator('#share-url').inputValue()===root+'/?eo_token=fabricated-local-token&eo_time=1800000000','Canonical sharing preserves fabricated preview access');
  await context.close();
  // Also exercise an installation under an additional directory, not just /.
  if(new URL(root).pathname==='/'){
   const nested=await browser.newContext({userAgent:android,isMobile:true,hasTouch:true,viewport:{width:390,height:844}}),p=await nested.newPage();
   await p.route('**/*',async route=>{const u=new URL(route.request().url());if(u.origin===new URL(root).origin&&u.pathname.startsWith('/nested/')){const target=new URL(u);target.pathname=u.pathname.slice('/nested'.length);const response=await route.fetch({url:target.href});await route.fulfill({response})}else await route.continue()});
   await p.goto(root+'/nested/');await p.waitForURL(u=>u.pathname==='/nested/portrait/');await p.waitForSelector('#device-entry');
   check((await p.evaluate(()=>window.shanhaiDeviceRoute)).root===root+'/nested/','Imported hosts with a path prefix keep that prefix');await nested.close();
  }
  for(const variant of ['desktop','mobile']){
   const mobile=variant==='mobile',c=await browser.newContext({userAgent:mobile?android:win,viewport:mobile?{width:390,height:844}:{width:1440,height:900},isMobile:mobile,hasTouch:mobile}),p=await c.newPage(),requests=[];
   p.on('pageerror',e=>errors.push(variant+': '+e.message));p.on('console',m=>{if(/SCRIPT ERROR|Parse Error/.test(m.text()))errors.push(variant+': '+m.text())});p.on('request',r=>{if(r.url().includes('/parts/'))requests.push(new URL(r.url()).pathname)});
   // Deliberately start at the opposite old game URL to verify old bookmarks.
   await p.goto(root+(mobile?'/game/':'/portrait/game/')+'?qa=1');
   await p.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});
   const state=await p.evaluate(()=>window.shanhaiQAState),u=new URL(p.url());
   check(u.pathname===new URL(root+(mobile?'/portrait/game/':'/game/')).pathname,variant+' old game bookmark reaches the correct build');
   check(requests.length>0&&requests.every(n=>mobile?n.includes('/portrait/game/parts/'):!n.includes('/portrait/')),variant+' downloads only its own complete game resources');
   check(state.state.stage===0&&state.state.cash===800,variant+' still starts the formal campaign');
   check(mobile?state.responsive.native_portrait===true:!state.responsive.native_portrait,variant+' renders its intended game layout');
   const oldUrl=p.url();if(mobile){await p.setViewportSize({width:844,height:390});await p.waitForTimeout(500);check(p.url()===oldUrl,'Rotation inside the running game does not redirect');await p.setViewportSize({width:390,height:844});await p.waitForTimeout(500)}
   await p.screenshot({path:path.join(out,variant+'-welcome.png')});await c.close();
  }
 }catch(e){errors.push(String(e.stack||e))}
 const report={checks,routes,errors,physical_devices_tested:false,version};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({checks,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})();
