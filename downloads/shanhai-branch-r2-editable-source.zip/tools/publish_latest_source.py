#!/usr/bin/env python3
"""Provide the current editable project and the unimplemented feedback proposal."""
import hashlib
import json
import urllib.request
import zipfile
from package_release import BUILD,ROOT,sha256,game_source_fingerprint,write_json
import publish_web_site as publisher


def main():
    revision='source-inventory-r1';publisher.REVISION=revision;out=BUILD/revision
    package=json.loads((out/'package.json').read_text());assert game_source_fingerprint()==package['game_source']
    assert '"checks":51,"failures":[]'in(out/'inventory-test.log').read_text()
    assert '"welcome_presented"'in(out/'main-boot.log').read_text()
    entries={};checksums=[]
    for artifact in package['artifacts']:
        p=BUILD/artifact['file'];assert p.stat().st_size==artifact['bytes']and sha256(p)==artifact['sha256']
        with zipfile.ZipFile(p)as z:assert z.testzip()is None
        entries['downloads/'+artifact['file']]=p;checksums.append(artifact['sha256']+'  '+artifact['file']+'\n')
    (out/'SHA256SUMS.txt').write_text(''.join(checksums))
    proposal=ROOT/'docs/proposals/feedback-revision-20261104.md'
    entries.update({'downloads/SHA256SUMS.txt':out/'SHA256SUMS.txt','downloads/source-package.json':out/'package.json','downloads/shanhai-feedback-revision-proposal-20261104.md':proposal,'README.md':(BUILD/'latest-editable-source/README.md').read_bytes()})
    before=publisher.git(['ls-remote','--heads','origin','gh-pages']).split()[0]
    commit=publisher.publish('source-inventory-r1-20261104',entries,'Latest editable Shanhai project and feedback revision proposal; gameplay unchanged')
    print(json.dumps({'commit':commit}),flush=True)
    results=[]
    for artifact in package['artifacts']:
        url='https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/downloads/'+artifact['file']
        target=out/('public-'+artifact['file'])
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Shanhai-source-delivery-check'}),timeout=120)as r:
            status=r.status;length=int(r.headers.get('Content-Length','0'))
            with target.open('wb')as f:
                while block:=r.read(1024*1024):f.write(block)
        assert status==200 and length==artifact['bytes']and sha256(target)==artifact['sha256']
        with zipfile.ZipFile(target)as z:
            assert z.testzip()is None
            if artifact['file'].endswith('editable-source.zip'):
                metadata=json.loads(z.read('SOURCE-INFO.json'));assert metadata['game_source']==package['game_source']and metadata['files']
                assert len(z.namelist())==package['source_files']
                for name,e in metadata['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==e['sha256'],name
                assert 'AGENTS.md'not in z.namelist()and 'docs/project-memory.md'not in z.namelist()
        request=urllib.request.Request(url,headers={'Range':'bytes=1048576-1048639','User-Agent':'Shanhai-source-resume-check'})
        with urllib.request.urlopen(request,timeout=45)as r:range_status=r.status;block=r.read()
        with target.open('rb')as f:f.seek(1048576);expected=f.read(64)
        assert range_status==206 and block==expected
        results.append({**artifact,'url':url,'http_status':status,'content_length':length,'sha256_verified':True,'zip_crc_valid':True,'range_verified':True})
    proposal_url='https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+commit+'/downloads/shanhai-feedback-revision-proposal-20261104.md'
    with urllib.request.urlopen(proposal_url,timeout=45)as r:assert r.status==200 and r.read()==proposal.read_bytes()
    assert publisher.git(['ls-remote','--heads','origin','gh-pages']).split()[0]==before
    write_json(out/'publication.json',{'version':package['version'],'game_source':package['game_source'],'commit':commit,'artifacts':results,'proposal_url':proposal_url,'proposal_implemented':False,'live_website_unchanged':True,'fresh_import_passed':True,'inventory_checks':51,'main_welcome_booted':True,'headless_exit_resource_warning':1,'physical_device_tested':False})
    print(json.dumps({'artifacts':results,'proposal_url':proposal_url},ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__':main()
