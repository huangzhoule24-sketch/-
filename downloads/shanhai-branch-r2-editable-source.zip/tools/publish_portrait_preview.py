#!/usr/bin/env python3
"""Publish an isolated portrait preview while preserving the existing classroom site."""
import argparse
import json
import urllib.request
import zipfile
from pathlib import Path

import publish_web_site as publisher
from package_release import BUILD, ROOT, game_source_fingerprint, sha256, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-site-commit', required=True)
    args = parser.parse_args()
    revision = 'web-r9-portrait'
    publisher.REVISION = revision
    site = BUILD / 'portrait-site'
    build = json.loads((BUILD / revision / 'site-build.json').read_text())
    receipt = json.loads((site / 'site-receipt.json').read_text())
    assert build['game_source'] == receipt['game_source'] == game_source_fingerprint()
    assert receipt['version'] == 'SH-WEB-R9-PORTRAIT'
    for name, entry in receipt['files'].items():
        path = site / name
        assert path.stat().st_size == entry['bytes'] and sha256(path) == entry['sha256'], name
    for name in ['browser', 'preview-browser', 'site-browser', 'music-browser']:
        report = json.loads((BUILD / revision / name / 'report.json').read_text())
        assert not report['errors'] and all(c['ok'] for c in report['checks']), name
        if 'game_source' in report:
            assert report['game_source'] == build['game_source'], name + ' stale source'
    archive = BUILD / build['artifact']['file']
    assert archive.stat().st_size == build['artifact']['bytes']
    assert sha256(archive) == build['artifact']['sha256']
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        assert sorted(package.namelist()) == sorted(p.relative_to(site).as_posix() for p in site.rglob('*') if p.is_file())
        for name in package.namelist():
            assert package.read(name) == (site / name).read_bytes(), name

    old_names = publisher.git(['ls-tree', '-rz', '--name-only', args.expected_site_commit], raw=True).decode().rstrip('\0').split('\0')
    assert old_names and not any(n.startswith('portrait/') for n in old_names)
    original = {name: publisher.git(['show', args.expected_site_commit + ':' + name], raw=True) for name in old_names}
    entries = {**original, **{'portrait/' + p.relative_to(site).as_posix(): p for p in site.rglob('*') if p.is_file()}}
    commit = publisher.publish('gh-pages', entries, 'Add independent native portrait preview SH-WEB-R9-PORTRAIT', args.expected_site_commit)
    changes = publisher.git(['diff-tree', '-z', '--no-commit-id', '--name-only', '-r', args.expected_site_commit, commit], raw=True).decode().rstrip('\0').split('\0')
    assert changes and all(name.startswith('portrait/') for name in changes)
    old_blobs = publisher.git(['ls-tree', '-rz', args.expected_site_commit], raw=True).decode().rstrip('\0').split('\0')
    new_blobs = publisher.git(['ls-tree', '-rz', commit], raw=True).decode().rstrip('\0').split('\0')
    assert [row for row in new_blobs if not row.split('\t', 1)[1].startswith('portrait/')] == old_blobs
    print(json.dumps({'site_commit': commit, 'original_files_preserved': len(old_names)}), flush=True)

    downloads = {
        'downloads/' + archive.name: archive,
        'downloads/SHA256SUMS.txt': (sha256(archive) + '  ' + archive.name + '\n').encode(),
        'downloads/site-build.json': BUILD / revision / 'site-build.json',
        'README.md': (ROOT / 'docs/mobile-portrait-r9.md').read_bytes(),
    }
    for name in ['01-portrait-welcome', '03-portrait-staff', '05-portrait-restaurant']:
        downloads['preview/' + name + '.png'] = BUILD / revision / 'browser' / (name + '.png')
    download_commit = publisher.publish('web-r9-portrait-20261104', downloads, 'Publish full native portrait game website and screenshots')
    url = 'https://github.com/huangzhoule24-sketch/-/raw/' + download_commit + '/downloads/' + archive.name
    target = BUILD / revision / 'public-site.zip'
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Shanhai-site-integrity-verifier'}), timeout=120) as response:
        status = response.status
        with target.open('wb') as handle:
            while block := response.read(1024 * 1024):
                handle.write(block)
    assert status == 200 and sha256(target) == sha256(archive) and target.stat().st_size == archive.stat().st_size
    with zipfile.ZipFile(target) as package:
        assert package.testzip() is None
    proof = {
        'version': receipt['version'], 'game_source': build['game_source'],
        'static_site': {
            'branch': 'gh-pages', 'commit': commit, 'parent_commit': args.expected_site_commit,
            'original_files_preserved': len(old_names), 'only_changed_prefix': 'portrait/',
            'pages_url': 'https://huangzhoule24-sketch.github.io/-/portrait/',
            'live_url_verified': False,
        },
        'download': {**build['artifact'], 'url': url, 'commit': download_commit, 'http_status': status,
                     'sha256_verified': True, 'zip_crc_valid': True},
        'physical_phone_tested': False,
    }
    write_json(BUILD / revision / 'publication.json', proof)
    print(json.dumps(proof, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
