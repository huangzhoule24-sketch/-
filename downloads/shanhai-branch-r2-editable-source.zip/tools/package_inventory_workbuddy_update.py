#!/usr/bin/env python3
"""Build a small verified overlay for the original WorkBuddy deployment."""
import json
import shutil
from package_release import BUILD,ROOT,sha256,write_json,write_zip
from publish_web_site import git


def main():
    revision='inventory-return-r1';build=json.loads((BUILD/revision/'site-build.json').read_text());site=BUILD/'inventory-site';package=BUILD/'workbuddy-inventory-update'
    if package.exists():shutil.rmtree(package)
    package.mkdir(parents=True)
    old={}
    for name in build['changes']:
        p=package/'site'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(site/name,p)
        old[name]=__import__('hashlib').sha256(git(['show',build['parent']+':'+name],raw=True)).hexdigest()
    alternative=package/'alternatives/game-index-standalone.html';alternative.parent.mkdir();shutil.copyfile(BUILD/'inventory-mobile-site/game/index.html',alternative)
    shutil.copyfile(ROOT/'tools/apply_inventory_site_update.py',package/'apply-update.py')
    prompt='''请在当前WorkBuddy项目更新现有应用，继续使用原来的发布链接与域名。
这是“物品栏返回”更新补丁，不是新建项目用的原始游戏。

1. 先备份当前静态网站文件到非公开目录，保留我的介绍页、电脑版本、设备自动识别和所有素材；不要清除浏览器存档。
2. 解压补丁，找到网站实际发布根目录（里面有index.html和game或portrait目录）。运行补丁中的apply-update.py --site-root <实际网站根目录>，可用--backup-dir指定非公开备份目录。脚本会校验旧手机版来源、识别完整版或独立手机版、备份并覆盖必要文件、核对完整资源。
3. 如果不能运行Python，按PATCH-MANIFEST.json和更新说明手动覆盖。完整版：将site文件夹里面的内容覆盖网站根目录。独立手机版：把site/portrait/game里的补丁文件覆盖原game，并用alternatives/game-index-standalone.html覆盖game/index.html；保留原首页和部署结构，更新回执与资源清单。不要把补丁的site文件夹当作网站额外套一层。
4. 确认手机“物品”现在打开独立物品栏，底部“返回餐厅”和顶部关闭均能退出；重复打开关闭后时钟、负债、培训、施工和状态按钮仍可见。点击物品详情后可返回物品栏。横竖屏切换后仍可返回，手动暂停状态不被改动。
5. 使用当前应用的更新/重新部署流程发布到原链接，确认新文件已进入发布产物。不要创建新的应用或更换域名。不要清除网站存储，也不要改经营数值、解锁条件或音频。
6. 最后给我原网址、已发布版本SH-WEB-R9-INVENTORY-R1和你实际完成的检查记录。浏览器模拟与实体手机检查请分清。
'''
    (package/'给WorkBuddy的更新指令.txt').write_text(prompt,encoding='utf-8-sig')
    (package/'更新说明.txt').write_text('''物品栏返回修复 · SH-WEB-R9-INVENTORY-R1

本补丁只更新手机版运行包及相关清单，电脑运行包、设备识别入口与原网站链接保留。
手机版现在使用独立物品栏，固定提供“返回餐厅”，顶部“关闭”也可退出；关闭后经营HUD恢复，物品详情可以返回物品栏。

推荐：将整个补丁ZIP上传到WorkBuddy原项目的对话，粘贴“给WorkBuddy的更新指令.txt”。让它在原应用中更新与重新部署。
补丁内site/表示要覆盖的网站文件；最终网站根目录应直接包含index.html、game与portrait，不能额外套一层site。
apply-update.py可自动识别组合包的portrait/game或独立手机版的game，校验基线、备份并覆盖，还会核对所有资源分片。它只修改本地文件，不会自行发布网站。

发布后，继续使用原网址。刷新页面后检查：物品→返回餐厅→再开物品→顶部关闭；时钟与负债应一直存在。再试详情页返回和横竖屏切换。
若仍是旧画面，可在原网址末尾增加?v=inventory-r1后打开；如果已有问号则加&v=inventory-r1。请勿清除网站数据，以免丢失存档。
WorkBuddy不同版本的按钮名称可能不同，关键是更新当前应用并复用现有域名。更新补丁不会自动修改你已经发布在WorkBuddy上的应用，需要在原项目重新部署。
''',encoding='utf-8-sig')
    payload=['site/'+n for n in build['changes']]
    files={p.relative_to(package).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p)}for p in package.rglob('*')if p.is_file()}
    write_json(package/'PATCH-MANIFEST.json',{'version':build['version'],'base_site_commit':build['parent'],'base_source':'68d3a7d44d51ea4c4772022609910db61be34d8d200d3918bde82d58269b643c','new_source':build['game_source']['sha256'],'payload':payload,'old_hashes':old,'files':files})
    artifact=write_zip(BUILD/'shanhai-inventory-return-workbuddy-update.zip',[(p,p.relative_to(package).as_posix())for p in sorted(package.rglob('*'))if p.is_file()])
    write_json(BUILD/revision/'patch-build.json',{'artifact':artifact,'game_source':build['game_source'],'game_changes':list(build['changes']),'supports_combined_and_standalone':True})
    print(json.dumps(artifact,indent=2))


if __name__=='__main__':main()
