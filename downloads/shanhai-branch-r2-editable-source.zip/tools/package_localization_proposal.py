#!/usr/bin/env python3
"""Prepare editable Word and Markdown copies of the three-region proposal."""
import argparse
import re
import shutil
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]


def inline(paragraph, text):
    for part in re.split(r'(\*\*.*?\*\*|`[^`]+`)', text):
        run = paragraph.add_run(part[2:-2] if part.startswith('**') else part[1:-1] if part.startswith('`') else part)
        run.bold = part.startswith('**')


def build(source, out, stem):
    out.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, out / (stem + '.md'))
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(1.8)
    section.left_margin = section.right_margin = Cm(1.9)
    for name in ['Normal', 'Title', 'Heading 1', 'Heading 2', 'Heading 3', 'List Bullet', 'Quote']:
        style = doc.styles[name]
        style.font.name = 'Calibri'
        style._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    normal = doc.styles['Normal']
    normal.font.size = Pt(10.5)
    normal.paragraph_format.line_spacing = 1.18
    normal.paragraph_format.space_after = Pt(5)
    for name, size in [('Title', 23), ('Heading 1', 17), ('Heading 2', 14), ('Heading 3', 12)]:
        doc.styles[name].font.size = Pt(size)
        doc.styles[name].font.color.rgb = RGBColor.from_string('315E52')
    footer = section.footer.paragraphs[0]
    footer.alignment = 2
    footer.add_run('更改策划案 · 2026-11-05　|　')
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    lines = source.read_text().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        figure = re.fullmatch(r'!\[([^\]]+)\]\(([^)]+)\)', line)
        if figure:
            image = source.parent / figure[2]
            assert image.is_file(), image
            paragraph = doc.add_paragraph()
            paragraph.alignment = 1
            picture = paragraph.add_run().add_picture(str(image), width=Cm(17.2))
            picture._inline.docPr.set('descr', figure[1])
            caption = doc.add_paragraph(figure[1], style='Caption')
            caption.alignment = 1
            target = out / figure[2]
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(image, target)
            vector = image.with_suffix('.svg')
            if vector.is_file():
                shutil.copyfile(vector, target.with_suffix('.svg'))
            i += 1
            continue
        if line.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?', c.replace(' ', '')) for c in cells):
                    rows.append(cells)
                i += 1
            table = doc.add_table(rows=1, cols=len(rows[0]))
            table.style = 'Table Grid'
            table.autofit = False
            widths = [17.2 / len(rows[0])] * len(rows[0])
            if len(rows[0]) == 4:
                widths = [3.2, 4.7, 4.7, 4.6]
            elif len(rows[0]) == 3:
                widths = [3.4, 6.9, 6.9]
            for column, width in zip(table.columns, widths):
                column.width = Cm(width)
            for row_index, cells in enumerate(rows):
                row = table.rows[0] if row_index == 0 else table.add_row()
                prevent = OxmlElement('w:cantSplit')
                row._tr.get_or_add_trPr().append(prevent)
                if row_index == 0:
                    repeat = OxmlElement('w:tblHeader')
                    row._tr.get_or_add_trPr().append(repeat)
                for cell, text, width in zip(row.cells, cells, widths):
                    cell.width = Cm(width)
                    paragraph = cell.paragraphs[0]
                    inline(paragraph, text)
                    paragraph.paragraph_format.space_after = Pt(3)
                    for run in paragraph.runs:
                        run.font.size = Pt(9.5)
                        if row_index == 0:
                            run.bold = True
                    if row_index == 0:
                        shade = OxmlElement('w:shd')
                        shade.set(qn('w:fill'), 'E5EEE8')
                        cell._tc.get_or_add_tcPr().append(shade)
            doc.add_paragraph()
            continue
        heading = re.match(r'^(#{1,4}) (.*)$', line)
        if heading:
            level, text = len(heading[1]), heading[2]
            paragraph = doc.add_paragraph(style='Title' if level == 1 else 'Heading ' + str(level - 1))
            inline(paragraph, text)
            if level == 2 and text.startswith(('三、', '四、', '五、')):
                paragraph.paragraph_format.page_break_before = True
        else:
            paragraph = doc.add_paragraph(style='List Bullet' if line.startswith('- ') else 'Quote' if line.startswith('> ') else 'Normal')
            inline(paragraph, line[2:] if line.startswith(('- ', '> ')) else line)
        i += 1
    doc.core_properties.title = '山海食肆物语：印度、北欧、希腊本土化综合策划案'
    doc.core_properties.subject = '角色、菜品、剧情与地区店面；策划稿，尚未实施'
    doc.core_properties.author = '山海食肆物语项目'
    destination = out / (stem + '.docx')
    doc.save(destination)
    loaded = Document(destination)
    text = '\n'.join(p.text for p in loaded.paragraphs)
    text += '\n' + '\n'.join(c.text for t in loaded.tables for r in t.rows for c in r.cells)
    for prefix in ['IN', 'ND', 'GR']:
        for number in range(1, 6):
            assert f'{prefix}-0{number}' in text and f'{prefix}-D0{number}' in text
    assert '进入开发前的核对要点' in text
    image_count = len(re.findall(r'^!\[', source.read_text(), re.M))
    assert len(loaded.inline_shapes) == image_count
    print(destination)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT / 'docs/proposals/localization-india-nordic-greece-20261105.md')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'build/localization-plan-r1')
    parser.add_argument('--stem', default='shanhai-localization-india-nordic-greece-plan-20261105')
    args = parser.parse_args()
    build(args.source.resolve(), args.output_dir.resolve(), args.stem)
