#!/usr/bin/env python3
"""Offer the complete site as two ordinary ZIPs with fixed direct downloads."""
import hashlib
import json
import urllib.request
import zipfile
from pathlib import Path

import publish_web_site as publisher
from package_release import BUILD, sha256, write_json, write_zip

REVISION = 'web-auto-r1-small-downloads'


def verify_combined(archives, expected):
    combined = {}
    for path in archives:
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None, path.name
            for name in archive.namelist():
                assert name not in combined, 'Packages must not overwrite one another: ' + name
                assert not name.startswith('/') and '..' not in Path(name).parts
                combined[name] = hashlib.sha256(archive.read(name)).hexdigest()
    assert set(combined) == set(expected)
    for name, digest in combined.items():
        assert digest == expected[name], name
    return len(combined)


def main():
    publisher.REVISION = REVISION
    source = BUILD / 'complete-device-site'
    original = json.loads((source / 'PACKAGE-INFO.json').read_text())
    for name, entry in original['files'].items():
        path = source / name
        assert path.stat().st_size == entry['bytes'] and sha256(path) == entry['sha256'], name
    files = {p.relative_to(source).as_posix(): p for p in source.rglob('*') if p.is_file()}
    assert len(files) == 212 and 'portrait/game/index.html' in files
    output = BUILD / REVISION
    output.mkdir(parents=True, exist_ok=True)
    guide = output / '下载与合并说明.txt'
    guide.write_text('''《山海食肆物语》最新版完整网页资源 · 两包下载说明

两个文件均为普通ZIP，可使用Windows系统自带的解压功能：
1. shanhai-web-auto-r1-main.zip：主包，含电脑版与自动识别入口。
2. shanhai-web-auto-r1-mobile-addon.zip：手机补充包，含完整portrait目录。

请两个都下载。它们是两份独立ZIP，各自可以正常解压。

合并方法：
1. 先将主包解压到一个文件夹。
2. 解压手机补充包，将里面的portrait文件夹复制到主包文件夹内。
3. 完成后，index.html、Start-Web.cmd、game文件夹、portrait文件夹应位于同一层。
4. 不要将portrait放到game内，也不要将它再套进其他文件夹。

本地运行：在合并后的根目录双击Start-Web.cmd，需要Python 3。
网站部署：上传合并后的整个文件夹内部内容，入口为index.html。
两个包合在一起保留全部电脑版、竖屏手机版、自动识别、完整美术音频和双语内容。
正式游戏的解锁、数值和存档格式没有变化。
''', encoding='utf-8-sig')
    groups = {
        'shanhai-web-auto-r1-main.zip': [(p, n) for n, p in files.items() if not n.startswith('portrait/')],
        'shanhai-web-auto-r1-mobile-addon.zip': [(p, n) for n, p in files.items() if n.startswith('portrait/')],
    }
    groups['shanhai-web-auto-r1-main.zip'].append((guide, guide.name))
    artifacts = [write_zip(output / name, sorted(entries, key=lambda x: x[1])) for name, entries in groups.items()]
    assert all(a['bytes'] < 100 * 1024 * 1024 for a in artifacts)
    expected = {n: sha256(p) for n, p in files.items()}
    expected[guide.name] = sha256(guide)
    paths = [output / a['file'] for a in artifacts]
    combined_count = verify_combined(paths, expected)
    (output / 'SHA256SUMS.txt').write_text(''.join(a['sha256'] + '  ' + a['file'] + '\n' for a in artifacts))
    entries = {'downloads/' + a['file']: output / a['file'] for a in artifacts}
    entries.update({'downloads/SHA256SUMS.txt': output / 'SHA256SUMS.txt', 'README.txt': guide})
    branch = 'web-auto-r1-small-downloads-20261104'
    remote = publisher.git(['ls-remote', '--heads', 'origin', branch])
    if remote:
        commit = remote.split()[0]
        names = publisher.git(['ls-tree', '-rz', '--name-only', commit], raw=True).decode().rstrip('\0').split('\0')
        assert sorted(names) == sorted(entries), 'Existing download branch differs'
        for name in names:
            assert publisher.git(['show', commit + ':' + name], raw=True) == entries[name].read_bytes(), name
    else:
        commit = publisher.publish(branch, entries, 'Offer fixed direct ZIP downloads for the complete desktop and mobile website')
    print(json.dumps({'commit': commit, 'artifacts': artifacts}), flush=True)
    downloads = []
    for artifact in artifacts:
        url = 'https://github.com/huangzhoule24-sketch/-/raw/' + commit + '/downloads/' + artifact['file']
        target = output / ('public-' + artifact['file'])
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Shanhai-small-download-verifier'}), timeout=120) as response:
            status = response.status
            length = int(response.headers['Content-Length']) if response.headers.get('Content-Length') else None
            with target.open('wb') as handle:
                while block := response.read(1024 * 1024):
                    handle.write(block)
        assert status == 200 and target.stat().st_size == artifact['bytes'] and sha256(target) == artifact['sha256']
        assert length is None or length == artifact['bytes']
        downloads.append({**artifact, 'url': url, 'http_status': status, 'content_length': length, 'sha256_verified': True})
    verify_combined([output / ('public-' + a['file']) for a in artifacts], expected)
    proof = {
        'version': 'SH-WEB-AUTO-R1', 'branch': branch, 'commit': commit,
        'download_format': 'Two independent ordinary ZIPs; extract and copy portrait into the main folder',
        'original_complete_package_files_preserved': 212, 'combined_files_with_new_guide': combined_count,
        'game_contents_unchanged': True, 'zip_crc_valid': True,
        'both_public_downloads_and_combination_verified': True, 'downloads': downloads,
    }
    write_json(output / 'publication.json', proof)
    print(json.dumps(proof, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
