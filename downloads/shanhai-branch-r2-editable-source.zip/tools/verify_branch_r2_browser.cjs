/* Actual touch gameplay only: no fixture grants, time jumps, save injection or QA mutations. */
const{chromium}=require('playwright'),fs=require('fs'),path=require('path');
const root=(process.env.SHANHAI_SITE_URL||'http://127.0.0.1:8065').replace(/\/$/,''),out=process.argv[2]||'build/branch-r2/browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--enable-unsafe-swiftshader','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 const checks=[],actions=[],errors=[],regions=[];const ua='Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36';let receipt;
 function check(ok,label){checks.push({ok:!!ok,label});if(!ok)throw Error(label)}
 for(const rid of(process.env.SHANHAI_REGIONS||'india,nordic,greece').split(',')){
  const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,userAgent:ua,deviceScaleFactor:1,locale:'zh-CN'}),page=await context.newPage(),cdp=await context.newCDPSession(page);
  page.on('pageerror',e=>errors.push(rid+': '+e.message));page.on('console',m=>{if(/SCRIPT ERROR|Parse Error|ERROR:/.test(m.text()))errors.push(rid+': '+m.text())});
  const state=()=>page.evaluate(()=>window.shanhaiQAState);const sync=()=>page.waitForTimeout(550);const freshSnapshot=async()=>{const previous=await page.evaluateHandle(()=>window.shanhaiQAState);try{await page.waitForFunction(x=>window.shanhaiQAState!==x,previous,{timeout:20000})}finally{await previous.dispose()}};
  async function persistedSaves(){return page.evaluate(async()=>{const found=[];for(const entry of await indexedDB.databases()){const db=await new Promise((resolve,reject)=>{const q=indexedDB.open(entry.name);q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error)});for(const store of db.objectStoreNames){const tx=db.transaction(store,'readonly'),st=tx.objectStore(store);const keys=await new Promise((res,rej)=>{const q=st.getAllKeys();q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});for(const key of keys){if(!String(key).endsWith('campaign_savegame.json'))continue;const fresh=db.transaction(store,'readonly').objectStore(store);const value=await new Promise((res,rej)=>{const q=fresh.get(key);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});try{const parsed=JSON.parse(new TextDecoder().decode(value.contents));found.push({key,minute:parsed.state.total_minutes,reduced:parsed.state.culture_experience.reduce_fx,active:parsed.state.international.active_scene,hired:parsed.state.international.regions[parsed.state.international.active_scene]?.hired,served:parsed.state.international.regions[parsed.state.international.active_scene]?.served})}catch(e){found.push({key,error:String(e)})}}}db.close()}return found})}

  async function point(r){return page.evaluate(r=>{const b=document.querySelector('canvas').getBoundingClientRect(),s=window.shanhaiQAState;return{x:b.x+(r.x+r.w/2)*b.width/s.viewport.w,y:b.y+(r.y+r.h/2)*b.height/s.viewport.h}},r)}
  async function swipe(reverse=false){
   const s=await state(),r=s.responsive.scroll;let top=r.y+12,bottom=r.y+r.h-12;const m=s.international_view?.scene_rect;
   if(s.panel==='跨国食肆'&&m?.h>0&&m.y<bottom&&m.y+m.h>top){const above=Math.max(0,m.y-top-6),below=Math.max(0,bottom-m.y-m.h-6);if(above>=below)bottom=Math.min(bottom,m.y-8);else top=Math.max(top,m.y+m.h+8)}
   if(bottom-top<35){top=r.y+6;bottom=r.y+r.h-6}
   const a=await point({x:r.x+r.w*.5,y:reverse?top:bottom,w:0,h:0}),b=await point({x:r.x+r.w*.5,y:reverse?bottom:top,w:0,h:0});
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...a,id:0}]});for(let i=1;i<=7;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:a.x+(b.x-a.x)*i/7,y:a.y+(b.y-a.y)*i/7,id:0}]});await page.waitForTimeout(25)}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await sync();
  }
  async function tap(id){let b;for(let i=0;i<28;i++){const s=await state();b=s?.buttons.find(x=>x.qa_id===id&&!x.disabled);if(b)break;await swipe(i<4)}if(!b)throw Error(rid+': Missing enabled control '+id);const p=await point(b.rect);await page.touchscreen.tap(p.x,p.y);await sync();actions.push(rid+':'+id);fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({region:rid,last:id,checks:checks.length,panel:(await state()).panel}));}
  async function handleEvents(){
   for(let i=0;i<5;i++){const s=await state();if(s.panel==='现金流预警'){await tap('revision:warning_ack:');continue}if(s.panel==='今日收支结算'){await tap('daily:ack');continue}if(!['事件','事件结果'].includes(s.panel))return;
    const close=s.buttons.find(b=>b.qa_id==='panel:close'&&!b.disabled);if(close){await tap('panel:close');continue}
    const choice=s.buttons.find(b=>b.qa_id.startsWith('event:')&&b.qa_id!=='event:open'&&!b.disabled);if(!choice)throw Error(rid+': Pending event has no available ordinary choice');await tap(choice.qa_id);
   }
   throw Error(rid+': Event sequence did not resolve');
  }
  async function shot(name){await page.screenshot({path:path.join(out,rid+'-'+name+'.png')});const s=await state();fs.writeFileSync(path.join(out,rid+'-'+name+'-view.json'),JSON.stringify({panel:s.panel,view:s.international_view,scroll:s.culture_navigation?.scroll_vertical,responsive:s.responsive,browser:await page.evaluate(()=>({scrollY,innerHeight,visualHeight:visualViewport?.height,canvas:document.querySelector('canvas').getBoundingClientRect().toJSON()}))},null,2))}
  try{
   receipt=await(await page.request.get(root+'/game/export-receipt.json')).json();await page.goto(root+'/game/?qa=1');await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});await sync();
   await tap('start:full');if(!(await state()).paused)await tap('time:pause');await tap('tutorial:ack');await tap('nav:员工');await tap('panel:close');await tap('tutorial:ack');await tap('tutorial:destination');await tap('full:marketing:flyer');await tap('tutorial:ack');if((await state()).panel)await tap('panel:close');if((await state()).paused)await tap('time:pause');
   await page.waitForFunction(()=>shanhaiQAState.state.served>=1,null,{timeout:120000});for(const id of['first_order','income']){if(!(await state()).state.tutorial.completed_steps.includes(id)){if(id==='first_order')await page.waitForFunction(id=>shanhaiQAState.state.tutorial.ready_to_ack.includes(id),id,{timeout:20000});await tap('tutorial:ack')}}
   if(!(await state()).state.tutorial.completed_steps.includes('bill')){await tap('tutorial:destination');await tap('tutorial:ack')}if((await state()).panel)await tap('panel:close');if(!(await state()).paused)await tap('time:pause');check((await state()).state.tutorial.finished,rid+' completes actual opening guidance');
   await tap('nav:更多');await tap('full:open:跨国食肆');await tap('int:region:'+rid);await tap('int:int_open:');
   let current=await state(),local=current.international.regions[rid];const role={in_01:'host',in_02:'chef',in_03:'cashier',in_04:'chef',in_05:'host',nd_01:'host',nd_02:'chef',nd_03:'host',nd_04:'chef',nd_05:'chef',gr_01:'chef',gr_02:'host',gr_03:'host',gr_04:'host',gr_05:'chef'};
   check(local.served===0&&local.partners.some(id=>role[id]==='chef'),rid+' opening assigns a named chef before any sale');
   await tap('int:int_auto:service');check(!(await state()).international.regions[rid].auto_service,rid+' manual service holds guests waiting for inspection');
   await tap('int:enter:'+rid);await page.waitForFunction(rid=>shanhaiQAState.restaurant_scene.active===rid,rid,{polling:100,timeout:20000});
   await tap('nav:招聘');check((await state()).panel==='跨国食肆'&&(await state()).international_view.tab==='招聘',rid+' main recruitment button opens an independent local recruitment page');await shot('01-recruitment');
   const candidate={india:'in_04',nordic:'nd_05',greece:'gr_05'}[rid],cash=(await state()).state.cash,music=(await state()).audio.music_starts;
   await tap('int:int_recruit:'+candidate+':cash');await page.waitForFunction(x=>shanhaiQAState.international.regions[x.rid].hired.includes(x.id),{rid,id:candidate},{polling:100,timeout:15000});current=await state();
   check(current.international.regions[rid].served===0&&current.international.regions[rid].hired.includes(candidate),rid+' formerly sales-gated chef can be hired at zero local orders');
   check(Math.abs(current.state.cash-(cash-200))<.001,rid+' real recruitment spends the normal main-store cash price once');
   check(current.international.regions[rid].partners.includes(candidate),rid+' vacant active slot automatically assigns the hire');
   check(current.audio.music_starts===music,rid+' recruitment preserves the current music recording');await shot('02-hired');
   await tap('panel:restaurant');await tap('nav:员工');check((await state()).international_view.tab==='伙伴',rid+' staff navigation opens shifts rather than recruitment');
   await tap('int:tab:来信');await tap('int:int_story:'+{india:'limited',nordic:'reserve',greece:'separate'}[rid]);
   await tap('int:tab:菜单');const first={india:'in_d01',nordic:'nd_d01',greece:'gr_d01'}[rid];await tap('int:int_prepare:'+first+':q3');await tap('int:int_auto:'+first);await tap('panel:restaurant');
   if((await state()).paused)await tap('time:pause');
   const waitUntil=Date.now()+90000;while(!(await state()).restaurant_scene.guest_poses.some(g=>g.stage==='waiting')&&Date.now()<waitUntil){await handleEvents();await page.waitForTimeout(300)}
   let visual=(await state()).restaurant_scene.guest_poses.find(g=>g.stage==='waiting');check(!!visual,rid+' a real guest reaches the waiting stage');const held={id:visual.id,point:visual.point};await page.waitForTimeout(900);visual=(await state()).restaurant_scene.guest_poses.find(g=>g.id===held.id);
   check(visual?.action==='sit'&&visual.seated&&JSON.stringify(visual.point)===JSON.stringify(held.point)&&JSON.stringify(visual.point)===JSON.stringify(visual.chair),rid+' the waiting guest stays in the same actual chair while time runs');
   if(!(await state()).paused)await tap('time:pause');await shot('03-waiting-in-chair');
   await tap('nav:员工');await tap('int:tab:店铺');await tap('int:int_auto:service');await tap('panel:restaurant');if((await state()).paused)await tap('time:pause');
   const servedUntil=Date.now()+120000;while((await state()).international.regions[rid].served<3&&Date.now()<servedUntil){await handleEvents();await page.waitForTimeout(400)}await handleEvents();current=await state();
   check(current.international.regions[rid].served>=3,rid+' hired crew prepares and completes at least three real paid meals');
   check(current.international.regions[rid].story.status==='resolved',rid+' actual fulfilment still produces the local reply');
   if(!current.paused)await tap('time:pause');await shot('04-paid-service');await tap('nav:更多');await tap('full:open:系统');await freshSnapshot();await tap('system:save');
   const persistStart=Date.now();let stored=await persistedSaves();while(!stored.some(x=>x.active===rid&&x.hired?.includes(candidate)&&x.served>=3)&&Date.now()-persistStart<20000){await page.waitForTimeout(500);stored=await persistedSaves()}
   check(stored.some(x=>x.active===rid&&x.hired?.includes(candidate)&&x.served>=3),rid+' real IndexedDB save contains paid recruitment and business progress');fs.writeFileSync(path.join(out,rid+'-persisted-save-proof.json'),JSON.stringify(stored,null,2));
   await page.reload();await page.waitForFunction(()=>window.shanhaiQAState?.panel==='欢迎',null,{timeout:90000});current=await state();
   check(current.restaurant_scene.active===rid&&current.international.regions[rid].hired.includes(candidate)&&current.international.regions[rid].served>=3,rid+' browser reload retains the selected eatery, hired chef and actual sales');
   regions.push({region:rid,served:current.international.regions[rid].served,hired:candidate});
  }catch(e){errors.push(String(e.stack||e));await shot('failure').catch(()=>{});fs.writeFileSync(path.join(out,rid+'-failure-state.json'),JSON.stringify((await state())||null,null,2));}
  await context.close();if(errors.length)break;
 }
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({game_source:receipt?.game_source,checks,actions,regions,errors,emulation:'Chromium Android touch, DPR1; no physical device claim'},null,2));console.log(JSON.stringify({checks,actions:actions.length,errors},null,2));await browser.close();if(errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
