#!/usr/bin/env python3
"""Keep the published desktop/entry and replace only the repaired phone runtime."""
import json
import shutil
from pathlib import Path
from package_release import BUILD, sha256, write_json, utc_now
from publish_web_site import git

REVISION='inventory-return-r1'
VERSION='SH-WEB-R9-INVENTORY-R1'


def main():
    baseline='7a01f224562072d554dce448ad04f2536e99f301'
    site=BUILD/'inventory-site';fresh=BUILD/'inventory-mobile-site'
    if site.exists():shutil.rmtree(site)
    names=git(['ls-tree','-rz','--name-only',baseline],raw=True).decode().rstrip('\0').split('\0')
    old={name:git(['show',baseline+':'+name],raw=True)for name in names}
    for name,data in old.items():
        p=site/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    shutil.copytree(fresh/'game',site/'portrait/game',dirs_exist_ok=True)
    page=site/'portrait/game/index.html';html=page.read_text()
    include='<script src="../../device-router.js?v=web-auto-r1" data-root="../../" data-variant="mobile" data-page="game"></script>'
    html=html.replace('<head>','<head>\n'+include,1)
    html=html.replace('(function () {','(function () {\n\tif (window.shanhaiDeviceRoute && window.shanhaiDeviceRoute.redirecting) return;',1)
    html=html.replace('</head>','<meta name="shanhai-build" content="'+VERSION+'">\n</head>',1);page.write_text(html)
    home=site/'portrait/index.html';home.write_text(home.read_text().replace('SH-WEB-R9-PORTRAIT',VERSION))
    receipt_path=site/'portrait/game/export-receipt.json';receipt=json.loads(receipt_path.read_text())
    receipt['files']['index.html']={'bytes':page.stat().st_size,'sha256':sha256(page)};receipt['entry_router']={'version':'web-auto-r1','variant':'mobile'}
    write_json(receipt_path,receipt)
    base=site/'portrait';manifest=json.loads((base/'site-receipt.json').read_text());current=json.loads((fresh/'site-receipt.json').read_text())
    for key in ['version','game_source','compression','resource_map']:manifest[key]=current[key]
    manifest['created_utc']=utc_now();manifest['inventory_return_fix']=True
    for name in manifest['files']:
        p=base/name;manifest['files'][name]={'bytes':p.stat().st_size,'sha256':sha256(p)}
    write_json(base/'site-receipt.json',manifest)
    changes={p.relative_to(site).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p)} for p in site.rglob('*') if p.is_file() and old.get(p.relative_to(site).as_posix())!=p.read_bytes()}
    assert changes and all(n.startswith('portrait/')for n in changes)
    for name,data in old.items():
        if not name.startswith('portrait/'):assert (site/name).read_bytes()==data,name
    write_json(BUILD/REVISION/'site-build.json',{'version':VERSION,'parent':baseline,'game_source':current['game_source'],'desktop_and_device_entry_unchanged':True,'changes':changes})
    print(json.dumps({'version':VERSION,'changes':list(changes),'source':current['game_source']},indent=2))


if __name__=='__main__':main()
