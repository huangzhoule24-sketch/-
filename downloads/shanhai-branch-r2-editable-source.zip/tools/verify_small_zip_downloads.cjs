/* Verify browser download behavior and complete file hashes; no game changes. */
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const input=process.argv[2]||'build/web-auto-r1-small-downloads/publication.json',out=process.argv[3]||'build/web-auto-r1-small-downloads/browser';
(async()=>{
 fs.mkdirSync(out,{recursive:true});const info=JSON.parse(fs.readFileSync(input,'utf8'));
 const options={executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']};
 const proxyValue=process.env.HTTPS_PROXY||process.env.https_proxy;
 if(proxyValue){const p=new URL(proxyValue);options.proxy={server:p.protocol+'//'+p.hostname+(p.port?':'+p.port:'')};if(p.username){options.proxy.username=decodeURIComponent(p.username);options.proxy.password=decodeURIComponent(p.password)}}
 const browser=await chromium.launch(options),context=await browser.newContext({acceptDownloads:true}),checks=[],errors=[],downloads=[];
 try{
  for(const item of info.downloads){
   const url=item.direct_url||'https://raw.githubusercontent.com/huangzhoule24-sketch/-/'+info.commit+'/downloads/'+item.file,page=await context.newPage();
   await page.setContent('<a id="download">Download ZIP</a>');await page.locator('#download').evaluate((element,value)=>element.setAttribute('href',value),url);
   const [download]=await Promise.all([page.waitForEvent('download',{timeout:120000}),page.locator('#download').click()]);
   const target=path.join(out,item.file);await download.saveAs(target);const failure=await download.failure();
   if(failure)throw Error('Browser download failed for '+item.file+': '+failure);
   const hash=crypto.createHash('sha256');for await(const block of fs.createReadStream(target))hash.update(block);
   const digest=hash.digest('hex'),size=fs.statSync(target).size;
   const ok=size===item.bytes&&digest===item.sha256&&download.suggestedFilename()===item.file;
   checks.push({ok,label:'Browser downloads the named complete ZIP: '+item.file});
   if(!ok)throw Error('Browser ZIP filename, length or hash mismatch');
   downloads.push({url,file:item.file,bytes:size,sha256:digest,suggested_filename:download.suggestedFilename()});await page.close();
  }
 }catch(e){errors.push(String(e.message||e))}
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks,downloads,errors,browser:'Chromium with actual anonymous download clicks'},null,2));
 await browser.close();console.log(JSON.stringify({checks,errors}));if(errors.length)process.exitCode=1;
})();
