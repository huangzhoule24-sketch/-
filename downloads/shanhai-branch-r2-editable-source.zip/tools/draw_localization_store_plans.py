#!/usr/bin/env python3
"""Draw planning diagrams, not game artwork or architectural construction plans."""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/proposals/localization-plan-r2'
FONT = font_manager.FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['svg.fonttype'] = 'path'
INK = '#344A44'
COLORS = {'seat': '#EEE2C6', 'prep': '#DFE9CE', 'hot': '#EDCEBA', 'clean': '#D9E8E7', 'store': '#E1DFDC', 'entry': '#F1E9D7', 'guest': '#AF7535', 'food': '#267E68', 'supply': '#527A9B'}


def text(ax, x, y, label, size=16, **kwargs):
    color = kwargs.pop('color', INK)
    return ax.text(x, y, label, fontsize=size, fontproperties=FONT, color=color, ha='center', va='center', **kwargs)


def box(ax, x, y, w, h, color, label='', size=16):
    ax.add_patch(Rectangle((x, y), w, h, facecolor=color, edgecolor='#64746A', linewidth=1.35))
    if label:
        rgb = matplotlib.colors.to_rgb(color)
        brightness = sum(a*b for a, b in zip(rgb, [.2126, .7152, .0722]))
        text(ax, x+w/2, y+h/2, label, size, color='#FAF7EF' if brightness < .49 else INK)


def zone(ax, x, y, w, h, kind, label):
    box(ax, x, y, w, h, COLORS[kind], label)


def route(ax, points, kind):
    color = COLORS[kind]
    ax.plot([p[0] for p in points], [p[1] for p in points], color=color, linewidth=2.3, zorder=7)
    ax.add_patch(FancyArrowPatch(points[-2], points[-1], arrowstyle='-|>', mutation_scale=17, color=color, linewidth=2.3, zorder=8))


def table(ax, x, y, w=2.7, h=1.2):
    box(ax, x, y, w, h, '#D5B78E')
    for sy in [y-.32, y+h]:
        ax.add_patch(Rectangle((x+.45, sy), max(.5, w-.9), .32, facecolor='#9D8670', edgecolor='none'))


def facade(ax, region):
    ax.set_xlim(-1, 25)
    ax.set_ylim(-1.4, 10)
    ax.axis('off')
    ax.plot([-1, 25], [0, 0], color='#A09D8D', lw=2)
    if region == 'india':
        box(ax, 2, .2, 20, 5.7, '#EBD8AF')
        box(ax, 2, .2, 20, .65, '#A96C48')
        ax.add_patch(Polygon([[.6, 5.8], [3.6, 8], [20.4, 8], [23.4, 5.8]], facecolor='#B65F3A', edgecolor='#754934', linewidth=2))
        for y in [6.2, 6.65, 7.1, 7.55]:
            ax.plot([3.1, 20.9], [y, y], color='#D38B63', lw=1)
        for x in [2.4, 8, 15.8, 21.6]:
            box(ax, x, .3, .32, 5.45, '#65503D')
        box(ax, 3.6, 2.3, 3.2, 2.1, '#A7B18A', '通风屏', 14)
        box(ax, 8.8, .8, 4, 3.7, '#376B60', '堂食入口', 15)
        box(ax, 16.5, 2.3, 4.3, 2.1, '#376B60', '取餐窗口', 15)
        box(ax, 8.9, 4.7, 6.2, .85, '#65503D')
        text(ax, 12, 5.12, '晨香廊', 18, bbox={'facecolor': '#F2E5CA', 'edgecolor': 'none', 'pad': 1.5})
        text(ax, 12, -1, '红瓦长檐 · 通风前廊 · 独立取餐口', 15)
    elif region == 'nordic':
        box(ax, 6.5, .2, 11, 6.1, '#A66F39')
        ax.add_patch(Polygon([[5.4, 6.2], [12, 9.5], [18.6, 6.2]], facecolor='#813E35', edgecolor='#654838', linewidth=2))
        for x in [7+i*.55 for i in range(19)]:
            ax.plot([x, x], [.7, 6], color='#C39862', linewidth=.7, zorder=1)
        box(ax, 10.7, 6.2, 2.6, 1.6, '#D8E4DF')
        box(ax, 7.3, .5, 3.4, 3.2, '#604F3E', '门斗', 15)
        box(ax, 11.8, 1.9, 4.3, 2.5, '#D9E4DD')
        for x in [13.2, 14.6]:
            ax.plot([x, x], [1.9, 4.4], color='#64746A', lw=1.7)
        ax.plot([11.8, 16.1], [3.15, 3.15], color='#64746A', lw=1.7)
        text(ax, 13.95, 3.15, '暖光分格窗', 14, bbox={'facecolor': '#F3ECD9', 'edgecolor': 'none', 'pad': 1.5})
        box(ax, 9.8, 4.7, 5.4, .9, '#F3ECD9', '港灯食屋', 17)
        box(ax, 17.8, 2.2, .75, 1.1, '#D7AA54')
        ax.plot([18.2, 18.2], [3.3, 5.3], color='#4D5B54', lw=2)
        text(ax, 12, -1, '窄面山墙木屋 · 防风门斗 · 港口灯', 15)
    else:
        box(ax, 1.5, .2, 8.8, 6, '#F1EBDD')
        box(ax, 10.3, .2, 12.2, 4.8, '#E8DFCC')
        box(ax, 1.2, 6.1, 9.4, .6, '#D8C9AE')
        box(ax, 10.1, 4.9, 12.7, .6, '#D8C9AE')
        box(ax, 19.8, 5.3, 1.1, 2.35, '#BDA27C')
        box(ax, 3, 2.6, 3.6, 2.1, '#5E7D84', '木窗扇', 14)
        box(ax, 8.1, .4, 4.1, 3.7, '#B7B08E', '院门', 16)
        box(ax, 15, 2, 4.5, 2.2, '#73805A', '交接窗口', 15)
        box(ax, 10.9, 3.7, 11.8, .34, '#977959')
        for x in [11.2, 13, 14.8, 16.6, 18.4, 20.2, 22]:
            ax.plot([x, x+.35], [3.9, 4.9], color='#73805A', lw=3)
        box(ax, 7.9, 4.7, 7.1, .85, '#C9B28A', '橄榄炉庭', 17)
        text(ax, 12, -1, '错落灰泥墙 · 石铺庭院 · 遮荫棚与烤炉', 15)


def plan(ax, region):
    ax.set_xlim(-1, 25)
    ax.set_ylim(-3.2, 20.2)
    ax.set_aspect('equal')
    ax.axis('off')
    text(ax, 12, 19.4, '功能分区｜上方为后场，下方为街道', 18)
    if region == 'india':
        zone(ax, 0, 12, 5, 5, 'store', '后门收货\n干货柜')
        zone(ax, 5, 12, 4, 5, 'clean', '回收\n清洁交接')
        zone(ax, 9, 12, 6, 5, 'prep', '香料与面糊\n备料架')
        zone(ax, 15, 12, 9, 5, 'hot', '蒸位／煎板\n热厨与出餐')
        zone(ax, 0, 3, 5, 9, 'seat', '')
        text(ax, 2.5, 10, '安静小桌')
        table(ax, 1.1, 5.8, 2.8, 1.2)
        zone(ax, 5, 3, 10, 7.5, 'prep', '')
        text(ax, 10, 8.5, '通风庭心\n可组合席')
        table(ax, 7, 4.3, 5.6, 1.3)
        zone(ax, 15, 3, 9, 7.5, 'entry', '点单与\n独立取餐')
        zone(ax, 0, 0, 24, 3, 'entry', '')
        text(ax, 5.2, 1.4, '有檐等位廊', 15)
        text(ax, 19.6, 1.4, '取餐队列', 15)
        route(ax, [(10.7, -2), (10.7, 1.5), (10.7, 3.7)], 'guest')
        route(ax, [(19.5, 12.8), (19.5, 11.2), (12.7, 11.2), (12.7, 6.5)], 'food')
        route(ax, [(2.4, 18.2), (2.4, 16.1)], 'supply')
    elif region == 'nordic':
        box(ax, 4, 0, 16, 18, '#F3ECD9')
        zone(ax, 4, 14, 6, 4, 'store', '收货\n冷热储备')
        zone(ax, 10, 14, 10, 4, 'hot', '热厨／冷装盘\n炉具维护')
        zone(ax, 4, 11, 6, 3, 'clean', '交接／休息角')
        zone(ax, 13, 11, 7, 3, 'entry', '保温餐台')
        zone(ax, 4, 4, 6, 7, 'seat', '')
        zone(ax, 13, 4, 7, 7, 'seat', '')
        text(ax, 7, 9.8, '窗边席', 15)
        text(ax, 16.5, 9.8, '卡座／小桌', 15)
        table(ax, 5.5, 6.4, 3, 1.2)
        table(ax, 14.7, 6.4, 3.6, 1.2)
        text(ax, 11.9, 9.5, '中\n央\n通\n道', 15)
        zone(ax, 4, 0, 6, 4, 'entry', '防风门斗\n擦靴挂衣')
        zone(ax, 14, 0, 6, 4, 'entry', '接待与取餐')
        route(ax, [(9.4, -2), (9.4, 1), (11.5, 3), (11.5, 5.1)], 'guest')
        route(ax, [(16, 14.4), (10.6, 14.4), (10.6, 12), (10.6, 7.4), (13.6, 7.4)], 'food')
        route(ax, [(7, 18.8), (7, 17.45)], 'supply')
    else:
        zone(ax, 0, 14, 7, 4, 'store', '后门收货\n粮食与陶锅')
        zone(ax, 7, 14, 10, 4, 'clean', '清洁与备料\n餐具交接')
        zone(ax, 17, 10, 7, 8, 'hot', '后场工作翼\n烤炉／待烤架')
        zone(ax, 17, 5, 7, 5, 'prep', '')
        text(ax, 20.5, 8.6, '独立装盘\n分餐台')
        zone(ax, 0, 3, 6, 11, 'seat', '')
        text(ax, 3, 11.7, '避风小厅\n独立小桌')
        table(ax, 1.5, 6.8, 3, 1.2)
        zone(ax, 6, 3, 11, 10, 'prep', '')
        text(ax, 11.5, 11.3, '棚架下庭院\n可调整共享桌')
        table(ax, 8, 6, 7.2, 1.6)
        zone(ax, 17, 0, 7, 5, 'entry', '预约／取餐')
        box(ax, 0, 0, 17, 3, '#EBE3D0')
        text(ax, 4, 1.4, '低墙与院门', 15)
        route(ax, [(10, -2), (10, 1.2), (7.4, 3.8), (7.4, 5.4)], 'guest')
        route(ax, [(22.8, 11), (22.8, 6.2), (17.7, 6.2), (15.8, 6.2)], 'food')
        route(ax, [(3.5, 18.9), (3.5, 17.45)], 'supply')
    handles = [Line2D([0], [0], color=COLORS[k], linewidth=2.7, label=l) for k, l in [('guest', '顾客主要路线'), ('food', '出餐主要路线'), ('supply', '后场到货')]]
    ax.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5, -.025), ncol=3, prop=FONT, fontsize=12, frameon=False)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for region, title in [('india', '印度｜晨香廊（IN-S01）'), ('nordic', '北欧｜港灯食屋（ND-S01）'), ('greece', '希腊｜橄榄炉庭（GR-S01）')]:
        fig, axes = plt.subplots(2, 1, figsize=(11.6, 12.8), gridspec_kw={'height_ratios': [.72, 1.28]})
        fig.patch.set_facecolor('#FAF7EF')
        fig.suptitle(title, fontproperties=FONT, fontsize=23, color=INK, y=.98)
        fig.text(.5, .946, '立面轮廓与功能分区示意 · 游戏策划用，非正式美术或施工图', ha='center', fontproperties=FONT, fontsize=13, color=INK)
        facade(axes[0], region)
        plan(axes[1], region)
        fig.subplots_adjust(left=.045, right=.955, top=.92, bottom=.025, hspace=.10)
        for ext in ['png', 'svg']:
            fig.savefig(OUT / f'{region}-store-design.{ext}', dpi=160, facecolor=fig.get_facecolor())
        plt.close(fig)
    print(OUT)


if __name__ == '__main__':
    main()
