extends SceneTree
## Labelled seat/roster layout fixtures. No claim of natural browser progress.
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
const Scene=preload("res://scripts/ui/international_scene.gd")
var ui
func _init():call_deferred("run")
func settle():
 for n in range(20):await process_frame
func save(name):
 await settle();await RenderingServer.frame_post_draw;root.get_texture().get_image().save_png("res://build/branch-r2/"+name+".png")
func run():
 for rid in["india","nordic","greece"]:
  root.size=Vector2i(1280,800);ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle();ui.return_to_restaurant();await settle()
  var r=ui.model.full_rules.international;r.perform("int_open",{"region":rid});var d=r.region(rid);d.accepting=false;d.auto_service=false
  for layout in["balanced","sharing"]:
   d.orders.clear();d.jobs.clear();d.floor.guests.clear()
   for w in d.floor.workers.values():w.job=0;w.motion={}
   d.layout=layout;r.floor.apply_layout(rid)
   for n in range(8):r._new_order(rid)
   for n in range(12):ui.model.state.total_minutes+=1;r.tick()
   ui.hide();var map=Scene.new();map.setup(ui.ensure_international_ui(),rid);root.add_child(map);map.size=Vector2(1280,800);await save(rid+"-chairs-"+layout);map.queue_free();await settle();ui.show()
  ui.scene_switcher.visit(rid);root.size=Vector2i(390,844);ui.update_ui_layout();await settle();ui.refresh();ui.map_view.house().focus_room("dining");await save(rid+"-phone-seated")
  ui.scene_switcher.manage("招聘");await save(rid+"-phone-recruitment")
  ui.queue_free();await settle()
 quit()
