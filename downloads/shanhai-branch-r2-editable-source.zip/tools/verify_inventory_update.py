#!/usr/bin/env python3
"""Verify both supported WorkBuddy layouts, backups and refusal of a wrong game."""
import json
import runpy
import shutil
from pathlib import Path
from package_release import ROOT,BUILD,sha256,write_json


def main():
    package=BUILD/'workbuddy-inventory-update';apply=runpy.run_path(str(package/'apply-update.py'))['apply']
    output=BUILD/'inventory-return-r1/apply-tests';output.mkdir(parents=True,exist_ok=True);checks=[];reports=[]
    for shape,source in [('combined',BUILD/'device-site'),('standalone-mobile',BUILD/'portrait-site')]:
        target=output/shape;backup=output/(shape+'-backup')
        for p in [target,backup]:
            if p.exists():shutil.rmtree(p)
        shutil.copytree(source,target);reports.append(apply(package,target,backup))
        desired=BUILD/'inventory-site'if shape=='combined'else BUILD/'inventory-mobile-site/game'
        actual=target if shape=='combined'else target/'game'
        for p in desired.rglob('*'):
            if p.is_file():assert sha256(p)==sha256(actual/p.relative_to(desired)),str(p.relative_to(desired))
        checks.append({'ok':True,'label':shape+' matches the tested runtime and creates a backup'})
    target=output/'combined';home=target/'portrait/index.html';custom=home.read_bytes()+b'\n<!-- WorkBuddy custom landing page -->';home.write_bytes(custom)
    backup=output/'custom-backup'
    if backup.exists():shutil.rmtree(backup)
    apply(package,target,backup);assert home.read_bytes()==custom
    checks.append({'ok':True,'label':'Custom WorkBuddy landing page remains intact on a repeat update'})
    wrong=output/'wrong-build';(wrong/'game').mkdir(parents=True,exist_ok=True)
    (wrong/'game/export-receipt.json').write_text(json.dumps({'game_source':{'sha256':'different-desktop-build'}}))
    try:apply(package,wrong,output/'wrong-backup')
    except ValueError:checks.append({'ok':True,'label':'Unrelated or desktop-only build is refused before copying'})
    else:raise AssertionError('Wrong runtime accepted')
    write_json(output/'report.json',{'checks':checks,'reports':reports,'errors':[]});print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
