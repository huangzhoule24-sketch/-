extends RefCounted

## Persisted, data-driven events and all eleven on-duty employee bonds.
## The simulation sends action hooks; rendering never creates event outcomes.
var _model_ref: WeakRef
var defaults: Dictionary = {}
var _resolution_details: Array = []
const COEFFICIENT_ALIASES := {
	"events.steal_consumption": "coeff.ingredient_cost_mult",
	"events.false_ad_probability": "coeff.false_ad_prob",
	"events.luwu_quality": "coeff.dish_quality_bonus",
	"events.bifang_repair_cost": "coeff.repair_cost",
	"events.inspection_fine": "coeff.fine_hygiene",
	"events.kunlun_pr_cost": "coeff.fine_bribe",
	"events.morale_bonus_cost": "coeff.bonus_morale",
	"coeff.bond_phoenix_yinglong_quality": "coeff.dish_quality_bonus",
	"coeff.bond_fierce_conflict": "coeff.fight_event_prob",
	"coeff.bond_justice_satisfaction": "coeff.satisfaction_bonus",
}


func _init(host: RefCounted) -> void:
	_model_ref = weakref(host)
	var file = FileAccess.open("res://config/event_balance.json", FileAccess.READ)
	if file != null:
		var parsed = JSON.parse_string(file.get_as_text())
		if parsed is Dictionary: defaults = parsed


func _m() -> Variant:
	return _model_ref.get_ref()


func _b(key: String, fallback: float = 0.0) -> float:
	var canonical = str(COEFFICIENT_ALIASES.get(key, key))
	if _m().balance.has(canonical): return float(_m().balance[canonical])
	return float(_m().balance.get(key, defaults.get(key, fallback)))


func _value(data: Dictionary, field: String, fallback: float = 0.0) -> float:
	var key = str(data.get(field + "_key", ""))
	return _b(key, fallback) if key != "" else float(data.get(field, fallback))


func _now() -> int:
	return int(_m().state.total_minutes)


func _day() -> int:
	return int(floor(float(_now()) / _b("day.minutes", 1440)))


func ensure_state() -> void:
	var state: Dictionary = _m().state
	if not state.get("world") is Dictionary: state.world = {}
	var world_defaults = {
		"queue": [], "history": [], "seen_events": [], "cooldowns": {}, "delayed": [], "modifiers": [],
		"weather": "clear", "weather_until": 0, "outstanding_receipts": 0.0,
		"regulars": 0, "unpaid_fines": 0.0, "special_guests": 0,
		"phoenix_day": -1, "zhulong_day": -1, "zhulong_period": "",
		"last_random_minute": _now(), "last_day": -1, "next_event_id": 1,
		"festival_wins": 0, "festival_entries": 0, "legal_cases": 0,
		"festival": {"employee_id": "", "dish_id": "", "last_result": {}},
		"feedback": {}, "flags": [], "easter_eggs": [], "event_days": {}, "waiting_guests": [],
		"pixiu_receipts": {"day": -1, "due": 0, "turnover": 0.0, "principal": 0.0, "advanced": 0.0, "bonus_rate": 0.0, "settled": true},
		"blockade": {"active": false, "resolved": false, "responses": 0, "service_orders": 0, "supply_secured": false, "community_support": false, "service_secured": false},
	}
	for key in world_defaults:
		if not state.world.has(key): state.world[key] = world_defaults[key]
	# Older saves retain already-earned story progress; event history alone no
	# longer turns a newly encountered commercial blockade into a victory.
	if bool(state.get("story", {}).get("kunlun_resolved", false)):
		state.world.blockade.resolved = true
		state.world.blockade.active = false


func _s() -> Dictionary:
	return _m().state.world


func _definition(id: String) -> Dictionary:
	for entry in _m().events:
		if str(entry.id) == id: return entry
	return {}


func _employee(id: String) -> Dictionary:
	return _m()._employee(id)


func _present(id: String) -> bool:
	var employee = _employee(id)
	return not employee.is_empty() and int(employee.get("away_until", 0)) <= _now() and int(employee.get("leave_until", 0)) <= _now() and int(employee.get("expansion_until", 0)) <= _now() and str(employee.get("branch_id", "")) == ""


func _active(id: String) -> bool:
	var employee = _employee(id)
	return _present(id) and not bool(employee.get("resting", false)) and float(employee.get("stamina", 0)) > 0 and int(employee.get("training_until", 0)) <= _now() and int(employee.get("research_until", 0)) <= _now() and int(employee.get("management_until", 0)) <= _now()


func active_bonds() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if int(_m().state.get("stage", 0)) < 2: return result
	for bond in _m().bonds:
		var ready = bool(bond.get("implemented", true))
		for id in bond.get("employee_ids", []):
			if not _active(str(id)): ready = false
		if ready: result.append(bond.duplicate(true))
	return result


func _effect_matches(effect: Dictionary, category: String, employee_id: String = "") -> bool:
	if effect.has("category") and str(effect.category) != category: return false
	if effect.has("categories") and not category in effect.categories: return false
	if effect.has("employee_id") and employee_id != str(effect.employee_id): return false
	if effect.has("period"):
		if not _m().business_open() or _m().period() != str(effect.period): return false
	if effect.has("weather") and str(_s().weather) != str(effect.weather): return false
	return true


func effect_multipliers(key: String, category: String = "", employee_id: String = "") -> Array:
	ensure_state()
	var aliases = {"price_bonus": "price", "traffic_bonus": "traffic", "ingredient_cost": "ingredient", "ingredient_cost_mult": "ingredient"}
	# v1.5: duplicate benefits never compound; a loss remains a distinct
	# detrimental effect so a beneficial bond cannot silently erase a penalty.
	var benefit = 0.0
	var penalty = 0.0
	for bond in active_bonds():
		for effect in bond.get("effects", []):
			var kind = str(aliases.get(str(effect.get("type", "")), str(effect.get("type", ""))))
			if kind == key and _effect_matches(effect, category, employee_id):
				var value = _value(effect, "value", _b(str(effect.get("coeff_key", ""))))
				benefit = maxf(benefit, value)
				penalty = minf(penalty, value)
	for effect in _s().modifiers:
		if int(effect.get("until", 0)) > _now() and str(effect.get("key", "")) == key and _effect_matches(effect, category, employee_id):
			var value = _value(effect, "value") * float(effect.get("sign", 1))
			benefit = maxf(benefit, value)
			penalty = minf(penalty, value)
	return [1.0 + benefit, 1.0 + penalty]

func _bonus(key: String, category: String = "", employee_id: String = "") -> float:
	var parts: Array = effect_multipliers(key, category, employee_id)
	return float(parts[0]) + float(parts[1]) - 2.0


func modifier(key: String, category: String = "", employee_id: String = "") -> float:
	var result = 1.0 + _bonus(key, category, employee_id)
	if key == "traffic": return result * traffic_environment() if _m().business_open() else 1.0
	return maxf(0.0, result)

func traffic_environment() -> float:
	var result: float = 1.0
	if not _m().business_open(): return result
	if bool(_s().blockade.active): result *= 1.0 + _b("events.blockade_traffic_penalty", -0.2)
	result *= 1 + minf(_b("events.regular_traffic_cap"), int(_s().regulars) * _b("events.regular_traffic_each"))
	if str(_s().weather) == "rain": result *= 1 + _b("events.weather_rain_traffic")
	elif str(_s().weather) == "snow": result *= 1 + _b("events.weather_snow_traffic")
	elif str(_s().weather) == "heat": result *= 1 + _b("events.weather_heat_traffic")
	if int(_s().zhulong_day) == _day() and str(_s().zhulong_period) != "":
		var base = _b("traffic." + str(_m().period()))
		if base > 0: result *= _b("traffic." + str(_s().zhulong_period)) / base
	return maxf(0.0, result)


func probability_bonus(key: String, category: String = "") -> float:
	return _bonus(key, category)


func dish_demand(category: String) -> float:
	ensure_state()
	if str(_s().weather) == "rain" and category == "水产": return 1 + _b("events.weather_rain_aquatic_sales")
	if str(_s().weather) == "snow" and category == "汤品": return 1 + _b("events.weather_snow_soup_sales")
	if str(_s().weather) == "heat" and category == "饮品": return 1 + _b("events.weather_heat_drink_sales")
	return 1.0


func procurement_multiplier(kind: String = "ordinary") -> float:
	ensure_state()
	var result = 1.0
	for effect in _s().modifiers:
		if str(effect.get("key", "")) != "procurement_discount" or int(effect.get("until", 0)) <= _now(): continue
		if effect.has("ingredient_kind") and str(effect.ingredient_kind) != kind: continue
		result = minf(result, _value(effect, "value", 1))
	return result


func _context_for(definition: Dictionary, context: Dictionary) -> Dictionary:
	var result = context.duplicate(true)
	var trigger: Dictionary = definition.get("trigger", {})
	if str(trigger.get("employee_id", "")) != "" and not result.has("employee_id"): result.employee_id = str(trigger.employee_id)
	if trigger.has("mood_below") and str(result.get("employee_id", "")) == "":
		for employee in _m().employees:
			if float(employee.get("mood", 100)) <= float(trigger.mood_below):
				result.employee_id = str(employee.id)
				break
	if str(result.get("dish_id", "")) != "":
		var dish = _m()._dish(str(result.dish_id))
		result.category = str(dish.get("category", result.get("category", "")))
	return result


func _eligible(definition: Dictionary, hook: String, context: Dictionary) -> bool:
	var trigger: Dictionary = definition.get("trigger", {})
	if not hook in trigger.get("hooks", []): return false
	if bool(trigger.get("business_only", true)) and not _m().business_open(): return false
	if int(_m().state.get("stage", 0)) < int(trigger.get("min_stage", 0)): return false
	if float(_m().state.get("reputation", 0)) < float(trigger.get("min_reputation", 0)): return false
	if trigger.has("employee_any") and not trigger.employee_any.any(func(id):return _present(str(id))):return false
	if trigger.has("minimum_streak") and int(context.get("streak",0))<int(trigger.minimum_streak):return false
	if trigger.has("minimum_usage") and int(context.get("usage",0))<int(trigger.minimum_usage):return false
	if trigger.has("periods") and not _m().period() in trigger.periods: return false
	if trigger.has("promotion_kind") and str(context.get("promotion_kind", context.get("kind", ""))) != str(trigger.promotion_kind): return false
	if trigger.has("min_overdue") and int(_m().state.get("overdue_count", 0)) < int(trigger.min_overdue): return false
	if trigger.has("min_overdue") and float(_m().state.get("debt", 0)) <= 0: return false
	if trigger.has("day_multiple") and (_day() <= 0 or _day() % int(trigger.day_multiple) != 0): return false
	var employee_id = str(trigger.get("employee_id", ""))
	if employee_id != "":
		if not _present(employee_id): return false
		if hook in ["cooking", "serving", "cleaning", "paying", "promote", "research", "fatigue"] and str(context.get("employee_id", "")) != employee_id: return false
		if str(context.get("employee_id", "")) != "" and str(context.employee_id) != employee_id: return false
		var employee = _employee(employee_id)
		if hook in ["cooking", "serving", "cleaning", "paying", "promote", "research"] and not _active(employee_id) and hook != "research": return false
		if trigger.has("role") and not _m().full_rules.dollhouse.capable(employee,str(trigger.role)): return false
		if trigger.has("actions"):
			var motion: Dictionary=employee.get("motion",{})
			if not str(motion.get("action","")) in trigger.actions or float(_now())<float(motion.get("started",_now()))+float(motion.get("travel_minutes",0)):return false
		if bool(trigger.get("stamina_zero", false)) and float(employee.get("stamina", 100)) > 0: return false
	if trigger.has("mood_below"):
		var target = _employee(str(context.get("employee_id", "")))
		if target.is_empty() or float(target.get("mood", 100)) > float(trigger.mood_below): return false
	if trigger.has("category") and str(context.get("category", "")) != str(trigger.category): return false
	if trigger.has("minimum_parallel"):
		var parallel = 0
		for customer in _m().customers:
			if str(customer.get("stage", "")) == "cooking" and str(customer.get("worker", "")) == employee_id: parallel += 1
		if parallel < int(trigger.minimum_parallel): return false
	if str(definition.id) == "phoenix_rebirth" and int(_s().phoenix_day) == _day(): return false
	if str(definition.id) == "zhulong_eyes" and int(_s().zhulong_day) == _day(): return false
	if str(definition.id) == "pixiu_withholds" and int(_s().pixiu_receipts.day) == _day(): return false
	if str(definition.id) == "pixiu_withholds" and float(context.get("amount", 0)) <= 0: return false
	if str(definition.id) == "qiongqi_fight" and not _active("qiong_qi"): return false
	if str(definition.id) == "xiezhi_judgment" and not _active("xie_zhi"): return false
	if int(_s().event_days.get(str(definition.id), -1)) == _day(): return false
	# Pixiu covers a calendar day; yesterday's late checkout must not suppress
	# today's event with a rolling 24-hour cooldown.
	if int(_s().cooldowns.get(str(definition.id), -1)) > _now():
		# Old one-bill saves keep their remaining cooldown once, so loading one
		# cannot grant that bill a second event bonus before its legacy return.
		if str(definition.id) != "pixiu_withholds" or int(_s().pixiu_receipts.day) == -1: return false
	for pending in _s().queue:
		if str(pending.id) == str(definition.id): return false
	return true


func on_hook(kind: String, context: Dictionary = {}) -> void:
	if _m().sandbox!=null and not bool(_m().sandbox.options().get("random_events",false)):return
	ensure_state()
	if kind == "complaint" and not bool(context.get("complaint_processed", false)):
		_m().full_rules.effects.begin_complaint(context)
		return
	if kind == "paying" and bool(_s().blockade.active) and float(context.get("amount", 0)) > 0:
		var customer: Dictionary = _m()._customer(int(context.get("customer_id", -1)))
		if not customer.is_empty() and not bool(customer.get("blockade_counted", false)) and float(customer.get("quality", 0)) >= _b("events.blockade_service_quality", 80):
			_s().blockade.service_orders = int(_s().blockade.service_orders) + 1
			customer.blockade_counted = true
	for definition in _m().events:
		var event_context = _context_for(definition, context)
		if not _eligible(definition, kind, event_context): continue
		if _m()._rng.randf() <= event_probability(definition): _enqueue(str(definition.id), event_context)


func event_probability(definition: Dictionary) -> float:
	var probability = _value(definition, "probability", _b("events.default_probability"))
	if str(definition.id) == "kunlun_trouble" and _m().state.has("special_visitors") and int(_m().state.special_visitors.spy_risk_day)==_day(): probability *= float(_m().full_rules.revision.config.defaults.spy_risk_multiplier)
	if str(definition.id) == "false_ad": probability *= modifier("false_ad")
	if str(definition.id) == "qiongqi_fight": probability += probability_bonus("conflict")
	if (str(definition.id) == "taotie_steals" and has_flag("taotie_indulgence")) or (str(definition.id) == "bifang_fire" and has_flag("fire_risk")) or (str(definition.id) == "kunlun_trouble" and has_flag("kunlun_hostility")):
		probability *= _b("events.risk_probability_multiplier", 2)
	return clampf(probability, 0, 1)


func can_enqueue(id: String) -> bool:
	ensure_state()
	if _definition(id).is_empty() or int(_s().event_days.get(id, -1)) == _day(): return false
	for entry in _s().queue:
		if str(entry.id) == id: return false
	return true


func _enqueue(id: String, context: Dictionary = {}) -> bool:
	ensure_state()
	var definition = _definition(id)
	if definition.is_empty(): return false
	for entry in _s().queue:
		if str(entry.id) == id: return false
	if not bool(definition.get("auto", false)) and not bool(definition.get("forced", false)) and _s().queue.size() >= int(_b("events.queue_limit")): return false
	if id == "kunlun_trouble" and not bool(_s().blockade.resolved):
		_s().blockade.active = true
	var pending = {"id": id, "context": context.duplicate(true), "minute": _now(), "serial": int(_s().next_event_id)}
	if not id in _s().seen_events: _s().seen_events.append(id)
	_s().next_event_id = int(_s().next_event_id) + 1
	_s().cooldowns[id] = (_day() + 1) * int(_b("day.minutes", 1440))
	_s().event_days[id] = _day()
	if bool(definition.get("auto", false)):
		var option: Dictionary = definition.options[0]
		_resolve(pending, option)
	else:
		if str(definition.get("type",""))=="notice" and not has_notice() and _m().state.has("revision171"): _m().state.revision171.notice_running=not _m().paused
		_s().queue.append(pending)
		if str(definition.get("type",""))=="notice": _m().paused=true
		_s().queue.sort_custom(func(a, b): return int(_definition(str(a.id)).get("priority", 1)) > int(_definition(str(b.id)).get("priority", 1)))
		_m()._notify("新事件：" + str(definition.title))
	_m().changed.emit()
	return true


func pending_event() -> Dictionary:
	ensure_state()
	if _s().queue.is_empty(): return {}
	var pending: Dictionary = _s().queue[0]
	var result = _definition(str(pending.id)).duplicate(true)
	result.context = pending.context.duplicate(true)
	result.options = result.options.filter(func(option):return not bool(option.get("requires_spy",false)) or bool(result.context.get("spy_detected",false)))
	result.queued_minute = int(pending.minute)
	result.serial = int(pending.serial)
	if str(result.get("type",""))=="notice":
		result["result_preview"] = _effect_preview(result.options[0].get("effects",[]))
	return result


func _can_afford(effects: Array) -> bool:
	var available = {"cash": float(_m().state.cash), "gems": float(_m().state.gems), "ingredients": float(_m().state.ingredients)}
	for effect in effects:
		var kind = str(effect.get("type", ""))
		if kind in ["bulk_purchase", "normal_purchase"]:
			available.cash = float(available.cash) - float(_supplier_quote(kind == "bulk_purchase").cost)
			if float(available.cash) < 0: return false
		if kind == "repayment":
			available.cash = float(available.cash) - minf(float(_m().state.debt), _value(effect, "amount"))
			if float(available.cash) < 0: return false
		if available.has(kind):
			available[kind] = float(available[kind]) + _value(effect, "amount") * float(effect.get("sign", 1))
			if float(available[kind]) < 0: return false
	return true


func choose(option_id: String) -> Dictionary:
	var pending = pending_event()
	if pending.is_empty(): return {"ok": false, "message": "没有待处理事件"}
	var chosen: Dictionary = {}
	for option in pending.get("options", []):
		if str(option.id) == option_id: chosen = option
	if chosen.is_empty(): return {"ok": false, "message": "未知选项"}
	if str(pending.id) == "food_festival" and option_id == "enter":
		var preparation = _festival_check()
		if not preparation.ok: return preparation
	if not _can_afford(chosen.get("effects", [])):
		_m()._notify("资源不足，尚未执行这个选项")
		return {"ok": false, "message": "资源不足"}
	var entry: Dictionary = _s().queue.pop_front()
	var feedback = _resolve(entry, chosen)
	if str(pending.get("type",""))=="notice" and not has_notice() and _m().state.has("revision171"):
		_m().paused=not bool(_m().state.revision171.notice_running)
	if str(entry.id)=="phoenix_rebirth": _m().set_employee_rest("feng_huang",false,false)
	if str(entry.id)=="low_mood" and str(chosen.id)=="bonus" and _m().state.has("special_visitors"): _m().state.special_visitors.helped=true
	_m().changed.emit()
	return {"ok": true, "event_id": str(entry.id), "option_id": option_id, "feedback": feedback, "message": str(pending.title) + "：" + str(chosen.label)}


func _resolve(entry: Dictionary, chosen: Dictionary) -> Dictionary:
	var before = _metrics()
	_resolution_details.clear()
	var context: Dictionary = entry.context.duplicate(true)
	context._source_id = str(entry.id)
	context._source_option = str(chosen.id)
	var old_promotion = modifier("promotion")
	var old_category = str(_m()._dish(str(entry.context.get("dish_id", ""))).get("category", entry.context.get("category", "")))
	var old_quality = modifier("quality", old_category)
	var old_tip = probability_bonus("tip")
	_apply_effects(chosen.get("effects", []), context)
	# A choice in the currently running promotion must affect that promotion.
	if str(entry.id) == "taowu_stubborn" and int(_m().state.get("promotion_until", 0)) > _now():
		_m().state.promotion_bonus = float(_m().state.get("promotion_bonus", 0)) * modifier("promotion") / maxf(0.001, old_promotion)
	if str(entry.id) == "luwu_fire":
		var customer: Dictionary = _m()._customer(int(entry.context.get("customer_id", -1)))
		if not customer.is_empty() and not bool(customer.get("paid", false)):
			var previous = float(customer.get("quality", 0))
			var category = str(_m()._dish(str(customer.dish_id)).get("category", ""))
			customer.quality = clampf(previous * modifier("quality", category) / maxf(0.001, old_quality), 0, _b("dish.quality_max", 100))
			customer.price = float(customer.price) * _m()._quality_price(float(customer.quality)) / maxf(0.001, _m()._quality_price(previous))
	if str(entry.id) == "fox_charm":
		var customer: Dictionary = _m()._customer(int(entry.context.get("customer_id", -1)))
		if not customer.is_empty() and not bool(customer.get("paid", false)):
			customer.tip_bonus = clampf(float(customer.get("tip_bonus", 0)) + probability_bonus("tip") - old_tip, 0, 1)
	if str(entry.id) == "kunlun_trouble":
		_s().blockade.responses = int(_s().blockade.responses) + 1
	return _record(entry, chosen, before)


func _record(entry: Dictionary, option: Dictionary, before: Dictionary = {}, title_override: String = "") -> Dictionary:
	var definition = _definition(str(entry.id))
	var after = _metrics()
	var changes: Array = []
	var metric_keys = before.keys()
	for key in after:
		if not key in metric_keys: metric_keys.append(key)
	for key in metric_keys:
		if not before.has(key): before[key] = 0.0
		var delta = float(after.get(key, before[key])) - float(before[key])
		if absf(delta) > 0.000001:
			changes.append({"key": str(key), "label": _metric_label(str(key)), "delta": delta, "before": float(before[key]), "after": float(after.get(key, before[key]))})
	var feedback = {"id": str(entry.id), "minute": _now(), "serial": int(entry.get("serial", 0)), "option": str(option.id), "context": entry.context.duplicate(true), "title": str(definition.get("title", entry.id)) if title_override.is_empty() else title_override, "label": str(option.get("label", "已处理")), "type": str(definition.get("type", "decision")), "changes": changes, "before": before.duplicate(true), "after": after, "details": _resolution_details.duplicate()}
	if changes.is_empty() and _resolution_details.is_empty(): feedback.details.append("本次没有资源或属性变化；你保留了现有经营安排。")
	_s().history.append(feedback)
	_s().feedback = feedback.duplicate(true)
	while _s().history.size() > int(_b("events.history_limit")): _s().history.pop_front()
	var summary: Array[String] = []
	for change in changes: summary.append("%s %+.2f" % [str(change.label), float(change.delta)])
	for detail in feedback.details: summary.append(str(detail))
	_m()._notify(str(feedback.title) + "：" + str(feedback.label) + "；" + "；".join(summary))
	return feedback


func _metrics() -> Dictionary:
	var result: Dictionary = {}
	for key in ["cash", "gems", "reputation", "ingredients", "debt"]: result[key] = float(_m().state.get(key, 0))
	for key in ["outstanding_receipts", "unpaid_fines", "regulars", "special_guests"]: result[key] = float(_s().get(key, 0))
	result["unlocked_dishes"] = _m().state.get("unlocked_dishes", []).size()
	for employee in _m().employees:
		for key in ["mood", "loyalty", "stamina"]: result["employee." + str(employee.id) + "." + key] = float(employee.get(key, 0))
	for id in _m().state.get("fragments", {}): result["fragment." + str(id)] = float(_m().state.fragments[id])
	return result


func _metric_label(key: String) -> String:
	var labels = {"cash": "钞票", "gems": "灵石", "reputation": "声望", "ingredients": "食材", "debt": "债务本金", "outstanding_receipts": "待收营业款", "unpaid_fines": "待付罚款", "regulars": "回头客", "special_guests": "特殊食客", "unlocked_dishes": "已解锁菜品", "mood": "心情", "loyalty": "忠诚", "stamina": "体力"}
	if key.begins_with("employee."):
		var parts = key.split(".")
		return str(_m()._employee_config(parts[1]).get("name", parts[1])) + "·" + str(labels.get(parts[2], parts[2]))
	if key.begins_with("fragment."):
		var id = key.trim_prefix("fragment.")
		return str(_m()._employee_config(id).get("name", id)) + "碎片"
	return str(labels.get(key, key))


func _target_ids(effect: Dictionary, context: Dictionary) -> Array:
	var id = str(effect.get("employee_id", "all"))
	if id == "context": id = str(context.get("employee_id", ""))
	var result: Array = []
	for employee in _m().employees:
		if id in ["all", str(employee.id)]: result.append(str(employee.id))
	return result


func _add_modifier(effect: Dictionary) -> void:
	var item = effect.duplicate(true)
	item.until = _now() + int(_value(effect, "duration", _b("events.day_duration")))
	if bool(effect.get("until_day_end", false)): item.until = (_day() + 1) * int(_b("day.minutes", 1440))
	# A repeated effect refreshes its duration rather than stacking the same source.
	var identity = str(item.get("key", "")) + ":" + str(item.get("employee_id", "")) + ":" + str(item.get("category", "")) + ":" + str(item.get("value_key", "")) + (":"+str(item.source_tag) if item.has("source_tag") else "")
	item.identity = identity
	for index in range(_s().modifiers.size() - 1, -1, -1):
		if str(_s().modifiers[index].get("identity", "")) == identity: _s().modifiers.remove_at(index)
	_s().modifiers.append(item)
	var labels = {"traffic": "客流", "quality": "品质", "ingredient": "食材耗用", "tip": "小费", "promotion": "宣传效果", "cleaning_speed": "清台速度", "serving_speed": "传菜速度", "cooking_speed": "厨房效率", "stamina": "体力消耗", "procurement_discount": "采购价格", "no_wait": "顾客等待保护", "ignore_obstacles": "传菜穿行"}
	var amount_text = "为原价%.0f%%" % (_value(item, "value") * 100) if str(item.key) == "procurement_discount" else "%+.0f%%" % (_value(item, "value") * float(item.get("sign", 1)) * 100)
	_resolution_details.append("%s %s，持续至第%d天 %02d:%02d" % [str(labels.get(str(item.key), item.key)), amount_text, int(item.until) / 1440 + 1, (int(item.until) % 1440) / 60, int(item.until) % 60])


func has_flag(id: String) -> bool:
	for flag in _s().flags:
		if str(flag.id) == id and int(flag.until) > _now() and int(flag.get("from", 0)) <= _now(): return true
	return false


func _set_flag(effect: Dictionary, context: Dictionary) -> void:
	_clear_flag(str(effect.id))
	var flag = {"id": str(effect.id), "title": str(effect.get("title", effect.id)), "description": str(effect.get("description", "")), "source_id": str(context.get("_source_id", "")), "from": _now(), "until": _now() + int(_value(effect, "duration", _b("events.three_day_duration", 4320)))}
	if bool(effect.get("active_next_day", false)):
		flag.from = (_day() + 1) * int(_b("day.minutes", 1440))
		flag.until = (_day() + 2) * int(_b("day.minutes", 1440))
	_s().flags.append(flag)
	_resolution_details.append("状态「%s」：%s；持续至第%d天" % [str(flag.title), str(flag.description), int(flag.until) / 1440 + 1])


func _clear_flag(id: String) -> void:
	for index in range(_s().flags.size() - 1, -1, -1):
		if str(_s().flags[index].id) == id: _s().flags.remove_at(index)


func _supplier_quote(bulk: bool) -> Dictionary:
	var quantity = _b("events.supplier_normal_units", 20) * (_b("events.supplier_bulk_multiplier", 3) if bulk else 1.0)
	var unit_price = float(_m().full_rules.management._ingredient("generic").get("price", 0))
	return {"quantity": quantity, "cost": _m()._money(quantity * unit_price * (_b("events.discount", 0.8) if bulk else 1.0))}


func _supplier_purchase(bulk: bool) -> void:
	var quote = _supplier_quote(bulk)
	if float(_m().state.cash) < float(quote.cost): return
	_cash(-float(quote.cost), "供应商采购", false)
	_m().full_rules.management.add_item("generic", float(quote.quantity), float(quote.cost))
	_m().full_rules.record("procurement", float(quote.cost), "供应商8折囤货" if bulk else "供应商正常采购")
	_resolution_details.append("实际入库普通食材 %.0f 份，采购支出 %.2f 元；采购形成存货，耗用时计入成本。" % [float(quote.quantity), float(quote.cost)])


func _set_weather(kind: String, duration: int) -> void:
	_s().weather = kind
	_s().weather_until = _now() + duration
	_m()._notify("天气变化：" + {"rain": "雨天", "snow": "暴雪", "heat": "酷暑", "clear": "晴天"}.get(kind, kind))
	var descriptions = {"rain": "雨天：客流-10%，水产类需求+50%", "snow": "暴雪：客流-25%，汤品需求+50%", "heat": "酷暑：客流-15%，饮品需求+50%", "clear": "恢复晴天"}
	_resolution_details.append(str(descriptions.get(kind, kind)) + "，持续%d分钟。" % duration)


func _cash(delta: float, category: String = "事件", accounting: bool = true) -> void:
	var cash_category = "receivable" if not accounting and ("应收" in category or "待收" in category or "营业款" in category) else ("procurement" if "采购" in category else "event")
	if _m().has_method("change_cash"): _m().change_cash(delta, cash_category, category)
	else: _m().state.cash = _m()._money(maxf(0, float(_m().state.cash) + delta))
	if not accounting: return
	var rules: Variant = _m().get("full_rules")
	if rules != null and rules.has_method("record"):
		rules.record("expenses" if delta < 0 else "other_income", absf(delta), category)


func _fine(amount: float) -> void:
	var paid = minf(float(_m().state.cash), amount)
	_cash(-paid, "罚款")
	_s().unpaid_fines = float(_s().unpaid_fines) + amount - paid
	_s().legal_cases = int(_s().legal_cases) + 1
	if paid < amount: _m()._notify("罚款未付余额已记入事件账目，请在经营恢复后处理")


func _give_ingredient(id: String, units: float) -> void:
	var rules: Variant = _m().get("full_rules")
	if rules != null:
		var management: Variant = rules.get("management")
		if management != null and management.has_method("add_item"):
			management.add_item("generic" if id == "ordinary" else id, units)
			return
	_m().state.ingredients = float(_m().state.ingredients) + units
	var stock: Variant = _m().state.get("inventory", null)
	if stock is Dictionary:
		stock[id] = float(stock.get(id, 0)) + units


func _pause_kitchen(duration: int) -> void:
	_m().state.kitchen_pause_until = maxi(int(_m().state.get("kitchen_pause_until", 0)), _now() + duration)
	for customer in _m().customers:
		if str(customer.get("stage", "")) == "cooking" and int(customer.get("due_minute", -1)) >= 0:
			customer.remaining_minutes = maxi(1, int(customer.due_minute) - _now())
			_m()._release_customer(customer)
			customer.worker = ""
			customer.due_minute = -1


func _apply_effects(effects: Array, context: Dictionary = {}) -> void:
	for effect in effects:
		var amount = _value(effect, "amount") * float(effect.get("sign", 1))
		match str(effect.get("type", "")):
			"flag": _set_flag(effect, context)
			"clear_flag": _clear_flag(str(effect.id))
			"clear_promotion":
				_m().state.promotion_bonus = 0.0
				_m().state.promotion_until = _now()
				_resolution_details.append("本次宣传效果归零；已支付宣传费不重复扣除。")
			"easter_egg":
				var exists = false
				for item in _s().easter_eggs:
					if str(item.id) == str(effect.id): exists = true
				if not exists: _s().easter_eggs.append({"id": str(effect.id), "title": str(effect.title), "description": str(effect.description), "minute": _now()})
				_resolution_details.append("山海志彩蛋已解锁：" + str(effect.title))
			"bulk_purchase": _supplier_purchase(true)
			"normal_purchase": _supplier_purchase(false)
			"dispute":
				_m().state.reputation = maxi(0, int(_m().state.reputation) - int(_b("events.rep5", 5)))
				_s().legal_cases = int(_s().legal_cases) + 1
				_resolution_details.append("客人因过度热情发生纠纷，声望-5；已进入客诉处理。")
				var complaint_context = context.duplicate(true)
				complaint_context.erase("employee_id")
				_m().full_rules.world.on_hook("complaint", complaint_context)
			"scare_guest": _scare_guest()
			"cash": _cash(amount)
			"gems": _m().state.gems = maxi(0, int(_m().state.gems) + int(amount))
			"ingredients": _give_ingredient(str(effect.get("ingredient_id", "ordinary")), amount)
			"reputation": _m().state.reputation = maxi(0, int(_m().state.reputation) + int(amount))
			"debt": _m().state.debt = maxf(0, float(_m().state.debt) + amount)
			"repayment": _m().repay_debt(int(amount))
			"mood", "loyalty":
				for id in _target_ids(effect, context):
					var employee = _employee(str(id))
					employee[str(effect.type)] = clampf(float(employee.get(str(effect.type), 0)) + amount, 0, _b("employee.max_mood", 100))
			"stamina_set":
				for id in _target_ids(effect, context):
					var employee = _employee(str(id))
					employee.stamina = clampf(amount, 0, _b("employee.max_stamina", 100))
					employee.resting = false
				_s().phoenix_day = _day()
			"state_begin":_m().full_rules.revision18.apply_state(str(effect.id))
			"pickup_auto":_m().full_rules.revision19.start_auto(int(effect.get("duration",120)))
			"pickup_spawn":_m().full_rules.revision19.spawn(str(effect.kind),int(effect.amount))
			"modifier":
				var modifier_effect = effect.duplicate(true)
				modifier_effect.source_id = str(context.get("_source_id", ""))
				_add_modifier(modifier_effect)
			"discount":
				var discount = effect.duplicate(true)
				discount.key = "procurement_discount"
				_add_modifier(discount)
			"weather":
				var duration = int(_value(effect, "duration", _b("events.weather_duration")))
				if bool(effect.get("until_day_end", false)): duration = (_day() + 1) * int(_b("day.minutes", 1440)) - _now()
				_set_weather(str(effect.get("weather", "clear")), duration)
			"random_weather": _set_weather("snow" if _m()._rng.randf() < _b("events.coin_flip_probability") else "heat", int(_b("events.weather_duration")))
			"kitchen_pause": _pause_kitchen(int(_value(effect, "duration", _b("events.pause_day"))))
			"delay":
				_s().delayed.append({"due": _now() + int(_value(effect, "delay")), "effects": effect.get("effects", []).duplicate(true), "context": context.duplicate(true), "probability": _value(effect, "probability", 1), "title": str(effect.get("title", "延迟事件后果")), "source_id": str(context.get("_source_id", "")), "source_option": str(context.get("_source_option", ""))})
				_resolution_details.append("%d分钟后判定后续影响，概率%.0f%%。" % [int(_value(effect, "delay")), _value(effect, "probability", 1) * 100])
			"chance":
				if _m()._rng.randf() <= _value(effect, "probability", 1): _apply_effects(effect.get("effects", []), context)
			"fine": _fine(amount)
			"random_reward":
				if _m()._rng.randf() < _b("events.coin_flip_probability"): _cash(_b("events.forecast_cash"), "事件奖励")
				else: _give_ingredient("ordinary", _b("events.forecast_ingredients"))
			"regulars":
				_s().regulars = int(_s().regulars) + int(amount)
				var customer: Dictionary = _m()._customer(int(context.get("customer_id", -1)))
				if not customer.is_empty():
					customer.regular = true
					customer.complaint_resolved = true
					customer.satisfaction = 100.0
			"clear_overdue": _m().state.overdue_count = 0
			"mark_zhulong": _s().zhulong_day = _day()
			"leave":
				for id in _target_ids(effect, context):
					var employee = _employee(str(id))
					_m().set_employee_rest(str(id), true)
					employee.leave_until = _now() + int(_value(effect, "duration", _b("events.day_duration")))
			"defer_receipt": _defer_receipt(context)
			"festival": _festival()
			"inspection": _inspection(bool(effect.get("prepared", false)))
			"influencer":
				if _m()._rng.randf() < clampf(_average_quality() * _b("events.influencer_quality_scale"), _b("events.influencer_quality_floor"), 1):
					_m().state.reputation = int(_m().state.reputation) + int(_b("events.rep30"))
					_m()._notify("网红根据实际菜品给出了好评")
				else:
					_m().state.reputation = maxi(0, int(_m().state.reputation) - int(_b("events.rep10", 10)))
					_resolution_details.append("网红根据实际菜品给出差评，声望-10。")
			"special_guest": _special_guest()
			"research_surprise": _research_surprise()
			"rift_reward": _rift_reward()
			"receipt_return":
				var principal = float(effect.get("principal", 0))
				_cash(amount, "待收营业款到账", false)
				_s().outstanding_receipts = maxf(0, float(_s().outstanding_receipts) - principal)
				var rules: Variant = _m().get("full_rules")
				if rules != null and rules.has_method("record"):
					rules.record("receivables", -principal, "待收款本金到账")
					rules.record("other_income", maxf(0, amount - principal), "聚宝袋增益")


func _defer_receipt(context: Dictionary) -> void:
	_settle_pixiu_receipts()
	if int(_s().pixiu_receipts.day) == _day(): return
	# The triggering checkout has already been counted and paid. Reclaim the
	# whole day's turnover from fungible cash still on hand. Money already spent
	# is an advance against that turnover, never a new debt or a second payout.
	var turnover = _m()._money(maxf(0, float(_m().state.daily_revenue)))
	if turnover <= 0 or float(context.get("amount", 0)) <= 0: return
	var principal = _m()._money(minf(turnover, float(_m().state.cash)))
	_s().pixiu_receipts = {"day": _day(), "due": (_day() + 1) * int(_b("day.minutes", 1440)), "turnover": turnover, "principal": principal, "advanced": _m()._money(turnover - principal), "bonus_rate": _b("events.delay_bonus"), "settled": false}
	_cash(-principal, "全天营业款转应收", false)
	_add_receivable(principal, "貔貅暂存当日营业款；已支用部分不重复收付")
	_m()._notify("貔貅暂存全天营业款：已转待收￥%.2f，触发前已支用￥%.2f；后续营业款日末统一到账并按全天营业额增加%.0f%%" % [principal, turnover - principal, _b("events.delay_bonus") * 100])


func _add_receivable(amount: float, description: String) -> void:
	_s().outstanding_receipts = _m()._money(float(_s().outstanding_receipts) + amount)
	_m().full_rules.record("receivables", amount, description)


func collect_sales_receipt(amount: float, gross: float = -1.0) -> float:
	# Every sales channel calls once before adding its cash. Revenue remains the
	# caller's responsibility: neither deferral nor settlement creates a sale.
	ensure_state()
	_settle_pixiu_receipts()
	amount = _m()._money(maxf(0, amount))
	if gross < 0: gross = amount
	gross = _m()._money(maxf(amount, gross))
	var receipts: Dictionary = _s().pixiu_receipts
	if bool(receipts.settled) or int(receipts.day) != _day(): return amount
	receipts.turnover = _m()._money(float(receipts.turnover) + gross)
	receipts.principal = _m()._money(float(receipts.principal) + amount)
	# Fees are paid out of gross sales. Only net cash becomes a receivable;
	# gross still earns the advertised five-percent daily turnover bonus.
	receipts.advanced = _m()._money(float(receipts.advanced) + gross - amount)
	_add_receivable(amount, "貔貅暂存后续营业款")
	return 0.0


func _settle_pixiu_receipts() -> void:
	var receipts: Dictionary = _s().pixiu_receipts
	if bool(receipts.settled) or int(receipts.due) > _now(): return
	var before = _metrics()
	# Mark paid before mutating cash so ticks, day hooks and save reloads can
	# never pay the same principal or bonus twice.
	receipts.settled = true
	var principal = float(receipts.principal)
	var bonus = _m()._money(float(receipts.turnover) * float(receipts.bonus_rate))
	_cash(principal + bonus, "全天营业应收款到账", false)
	_add_receivable(-principal, "貔貅当日待收款本金到账")
	_m().full_rules.record("other_income", bonus, "貔貅全天营业额增益；不重复计销售收入")
	_m()._notify("貔貅日末到账：本金￥%.2f＋全天营业额增益￥%.2f；已支用￥%.2f不重复返还" % [principal, bonus, float(receipts.advanced)])
	_resolution_details = ["待收本金%.2f元与全天营业额5%%增益%.2f元已入账；已支用%.2f元不重复返还。" % [principal, bonus, float(receipts.advanced)]]
	var entry = {"id": "pixiu_withholds", "context": {}, "serial": int(_s().next_event_id)}
	_s().next_event_id = int(_s().next_event_id) + 1
	_record(entry, {"id": "wait", "label": "次日营业款到账"}, before, "貔貅次日入账")


func _average_quality() -> float:
	var count = 0
	var total = 0.0
	for employee in _m().employees:
		if _active(str(employee.id)) and str(employee.get("role", "")) in ["chef", "all"]:
			total += _b("prototype.base_quality", 75) + float(employee.get("attributes", {}).get("cooking", 1)) * _b("prototype.quality_per_cooking_point", 1)
			count += 1
	return clampf(total / maxf(1, count), 0, _b("dish.quality_max", 100))


func _festival_candidates() -> Dictionary:
	var chefs: Array = []
	var dishes: Array = []
	for employee in _m().employees:
		if _active(str(employee.id)) and str(employee.get("role", "")) in ["chef", "all"]:
			chefs.append({"id": str(employee.id), "name": str(employee.name), "cooking": float(employee.attributes.get("cooking", 0)), "creativity": float(employee.attributes.get("creativity", 0))})
	for dish in _m().dishes:
		if str(dish.id) in _m().state.unlocked_dishes:
			dishes.append({"id": str(dish.id), "name": str(dish.name), "can_make": _m().full_rules.management.can_make(str(dish.id))})
	return {"chefs": chefs, "dishes": dishes}


func _festival_selection(args: Dictionary = {}) -> Dictionary:
	var candidates = _festival_candidates()
	var employee_id = str(args.get("employee_id", _s().festival.employee_id))
	var dish_id = str(args.get("dish_id", _s().festival.dish_id))
	if employee_id.is_empty() and not candidates.chefs.is_empty(): employee_id = str(candidates.chefs[0].id)
	if dish_id.is_empty():
		for dish in candidates.dishes:
			if dish.can_make: dish_id = str(dish.id); break
	return {"employee_id": employee_id, "dish_id": dish_id}


func _festival_check(args: Dictionary = {}) -> Dictionary:
	var selection = _festival_selection(args)
	var employee = _employee(str(selection.employee_id))
	if employee.is_empty() or not _active(str(selection.employee_id)) or str(employee.get("role", "")) not in ["chef", "all"]:
		return {"ok": false, "message": "请为美食节选择一位当班厨师"}
	if not str(selection.dish_id) in _m().state.unlocked_dishes or not _m().full_rules.management.can_make(str(selection.dish_id)):
		return {"ok": false, "message": "请选择已解锁且食材充足的参赛菜品"}
	return {"ok": true, "message": "参赛准备就绪", "selection": selection}


func _festival() -> void:
	var selection = _festival_selection()
	var chef = _employee(str(selection.employee_id))
	var dish: Dictionary = _m()._dish(str(selection.dish_id))
	var management: Variant = _m().full_rules.management
	# Score the actual selected dish before consuming its real stock/freshness.
	var quality = clampf((management.dish_quality(str(dish.id)) + float(chef.attributes.get("cooking", 0)) * _b("prototype.quality_per_cooking_point", 1)) * _m().full_rules.quality_multiplier(chef, dish), 0, _b("dish.quality_max", 100))
	var score = quality * _b("events.festival_score_quality", 0.8) + float(chef.attributes.get("creativity", 0)) * _b("events.festival_score_creativity", 1)
	if str(dish.get("required_employee", "")) == str(chef.id): score += _b("events.festival_specialty_bonus", 5)
	var consumed: Dictionary = management.consume(str(dish.id), 1, false)
	if not consumed.ok: return # choose() checks stock before charging or removing the invitation.
	management.recognize_cost(float(consumed.cost))
	_m().full_rules.record("expenses", float(consumed.cost), "美食节参赛食材")
	var opponent_score = _b("events.festival_opponent_score", 70)
	var won = score >= opponent_score
	_s().festival.employee_id = str(chef.id)
	_s().festival.dish_id = str(dish.id)
	_s().festival.last_result = {"minute": _now(), "employee_id": str(chef.id), "dish_id": str(dish.id), "quality": quality, "score": score, "opponent_score": opponent_score, "won": won, "ingredient_cost": float(consumed.cost)}
	_s().festival_entries = int(_s().festival_entries) + 1
	if won:
		_s().festival_wins = int(_s().festival_wins) + 1
		_cash(_b("events.festival_reward_cash"), "美食节奖金")
		_m().state.reputation = int(_m().state.reputation) + int(_b("events.festival_reward_reputation"))
		_m().state.gems = int(_m().state.gems) + int(_b("events.festival_reward_gems"))
		_m()._notify("美食节：%s凭%s获得%.1f分，超过连锁品牌%.1f分，夺得冠军！" % [str(chef.name), str(dish.name), score, opponent_score])
	else: _m()._notify("美食节：%s获得%.1f分，连锁品牌%.1f分。提升厨艺、创意或选择拿手菜后可再次参赛。" % [str(dish.name), score, opponent_score])


func _blockade_check(strategy: String) -> Dictionary:
	var blockade: Dictionary = _s().blockade
	if not bool(blockade.active): return {"ok": false, "message": "当前没有需要突破的商业封锁"}
	if not _m().business_open(): return {"ok": false, "message": "请在营业时组织应对"}
	var field = {"supply": "supply_secured", "service": "service_secured", "community": "community_support"}.get(strategy, "")
	if str(field).is_empty(): return {"ok": false, "message": "未知封锁应对策略"}
	if bool(blockade[field]): return {"ok": false, "message": "这一项应对已经完成"}
	if int(blockade.responses) < 1: return {"ok": false, "message": "请先处理昆仑集团捣乱事件，明确经营立场"}
	if strategy == "service" and int(blockade.service_orders) < int(_b("events.blockade_service_target", 12)):
		return {"ok": false, "message": "需要在封锁期间完成%d单品质至少%.0f的真实营业订单" % [int(_b("events.blockade_service_target", 12)), _b("events.blockade_service_quality", 80)]}
	if strategy == "community" and float(_m().state.reputation) < _b("events.blockade_community_reputation", 500):
		return {"ok": false, "message": "社区合作需要声望达到%.0f" % _b("events.blockade_community_reputation", 500)}
	var cost = _b("events.blockade_" + strategy + "_cost", 0)
	if float(_m().state.cash) < cost: return {"ok": false, "message": "封锁应对经费不足"}
	return {"ok": true, "message": "", "field": field, "cost": cost}


func _blockade_counter(strategy: String) -> Dictionary:
	var check = _blockade_check(strategy)
	if not check.ok: return check
	var blockade: Dictionary = _s().blockade
	var cost = float(check.cost)
	_cash(-cost, "商业封锁应对：" + strategy)
	blockade[str(check.field)] = true
	if bool(blockade.supply_secured) and bool(blockade.service_secured) and bool(blockade.community_support):
		blockade.active = false
		blockade.resolved = true
		blockade.resolved_minute = _now()
		_m()._notify("稳定供货、真实服务与社区支持已形成合力，昆仑商业封锁正式解除！")
	_m().changed.emit()
	return {"ok": true, "message": "已完成封锁应对：" + {"supply": "建立独立供货", "service": "兑现服务承诺", "community": "建立社区合作"}[strategy]}


func _inspection(prepared: bool = false) -> void:
	var chance = clampf(_b("events.inspection_prepared_base_pass", 0.85) if prepared else _b("events.inspection_base_pass"), 0, 1)
	chance = clampf(chance + float(_m().state.comfort) * _b("events.inspection_comfort_weight"), 0, 1)
	_resolution_details.append("本次卫生检查通过概率%.0f%%（%s）。" % [chance * 100, "已认真准备" if prepared else "未增加准备"])
	if _m()._rng.randf() <= chance:
		_m().state.reputation = int(_m().state.reputation) + int(_b("events.rep10"))
		_m()._notify("卫生检查通过：声望+10")
	else:
		_fine(_b("events.inspection_fine"))
		_m().state.reputation = maxi(0, int(_m().state.reputation) - int(_b("events.rep10")))
		_m()._notify("卫生检查未通过：罚款200、声望-10，整改后继续经营")


func _special_guest() -> void:
	_s().special_guests = int(_s().special_guests) + 1
	var old_count = _m().customers.size()
	_m()._spawn_customer("", false)
	if _m().customers.size() > old_count:
		var customer: Dictionary = _m().customers.back()
		customer.type = "special"
		customer.special_guest_source = "gudiao_call"
		_m().full_rules.visitors.prepare(customer)
	var guest_kind = _m()._rng.randi_range(0, 2)
	if _m().customers.size() > old_count: _m().customers.back().special_guest_kind = ["beast", "fraud", "patron"][guest_kind]
	if guest_kind == 1:
		_cash(-minf(_b("events.special_fraud_loss"), float(_m().state.cash)), "特殊食客受骗损失")
		_resolution_details.append("来客是骗子：已记录实际损失，今后要核对来客信息。")
	elif guest_kind == 2:
		_cash(_b("events.special_guest_cash"), "大主顾预付赠礼")
		_resolution_details.append("迎来大主顾，留下%.0f元赠礼；消费仍按实际订单结算。" % _b("events.special_guest_cash"))
	else:
		_cash(_b("events.special_guest_cash"), "神兽食客赠礼")
		_m().state.reputation = int(_m().state.reputation) + int(_b("events.special_guest_reputation"))
		_resolution_details.append("迎来神兽食客，留下赠礼与好评。")
	if _m().customers.size() == old_count:
		_s().waiting_guests.append({"kind": ["beast", "fraud", "patron"][guest_kind], "minute": _now(), "source_id": "gudiao_call"})
		_resolution_details.append("当前座位已满，特殊来客已加入候座；赠礼或损失照实记账，有座位后入店消费。")


func _seat_waiting_guest() -> void:
	if _s().waiting_guests.is_empty() or not _m().business_open(): return
	var count = _m().customers.size()
	_m()._spawn_customer("", false)
	if _m().customers.size() <= count: return
	var guest: Dictionary = _s().waiting_guests.pop_front()
	var customer: Dictionary = _m().customers.back()
	customer.type = "special"
	customer.special_guest_kind = str(guest.kind)
	customer.special_guest_source = str(guest.source_id)
	_m().full_rules.visitors.prepare(customer)
	_m()._notify("蛊雕迎来的候座特殊食客已经入店；接下来按实际菜单与订单结算。")


func _scare_guest() -> void:
	for customer in _m().customers:
		if str(customer.get("type", "human")) not in ["human", "普通人类"] or bool(customer.get("paid", false)): continue
		_m()._release_customer(customer)
		if bool(customer.get("ingredients_reserved", false)): _m().full_rules.record("expenses", float(customer.get("ingredient_cost", 0)), "受惊离店订单食材报损")
		_m().customers.erase(customer)
		_m().state.lost = int(_m().state.lost) + 1
		_resolution_details.append("1位普通顾客受惊提前离店，未形成销售收入。")
		return
	_add_modifier({"key": "traffic", "value": -0.2, "duration": 60, "type": "modifier", "source_id": "gudiao_call"})
	_resolution_details.append("当时没有可受惊的普通顾客；接下来1小时普通迎客受到影响。")


func _research_surprise() -> void:
	var rules: Variant = _m().get("full_rules")
	if rules != null and _m()._rng.randf() <= _b("events.hidden_probability"):
		var management: Variant = rules.get("management")
		if management != null and management.has_method("discover_hidden_recipe") and management.discover_hidden_recipe():
			_m()._notify("混沌的试验发现了隐藏菜品配方")
			return
	_give_ingredient("rare", _b("events.research_rare_units"))
	_m()._notify("试验发现可用的稀有食材")


func _rift_reward() -> void:
	if _m()._rng.randf() < _b("events.coin_flip_probability"): _give_ingredient("rare", _b("events.rift_rare_units"))
	else:
		var employee: Dictionary = _m().catalog[_m()._rng.randi_range(0, _m().catalog.size() - 1)]
		var id = str(employee.id)
		_m().state.fragments[id] = int(_m().state.fragments.get(id, 0)) + int(_b("events.rift_fragments"))
		_m()._notify("裂缝探索获得 %s 碎片" % str(employee.name))


func tick_minute() -> void:
	ensure_state()
	_seat_waiting_guest()
	_settle_pixiu_receipts()
	for index in range(_s().delayed.size() - 1, -1, -1):
		var item: Dictionary = _s().delayed[index]
		if int(item.due) <= _now():
			_s().delayed.remove_at(index)
			if _m()._rng.randf() <= float(item.get("probability", 1)):
				var before = _metrics()
				_resolution_details.clear()
				_apply_effects(item.get("effects", []), item.get("context", {}))
				var source_id = str(item.get("source_id", item.get("context", {}).get("_source_id", "")))
				if not _definition(source_id).is_empty():
					var entry = {"id": source_id, "context": item.get("context", {}), "serial": int(_s().next_event_id)}
					_s().next_event_id = int(_s().next_event_id) + 1
					_record(entry, {"id": str(item.get("source_option", "")), "label": "后续影响已结算"}, before, str(item.get("title", "延迟事件后果")))
				else: _m()._notify("延迟影响已结算：现金与属性变化已记入账本。")
	for index in range(_s().modifiers.size() - 1, -1, -1):
		if int(_s().modifiers[index].get("until", 0)) <= _now(): _s().modifiers.remove_at(index)
	for index in range(_s().flags.size() - 1, -1, -1):
		if int(_s().flags[index].until) <= _now(): _s().flags.remove_at(index)
	if int(_s().weather_until) <= _now(): _s().weather = "clear"
	on_hook("minute")
	if _now() - int(_s().last_random_minute) >= int(_b("events.random_interval")):
		_s().last_random_minute = _now()
		on_hook("random")


func on_day() -> void:
	ensure_state()
	if int(_s().last_day) == _day(): return
	_s().last_day = _day()
	on_hook("day")


func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	ensure_state()
	var check: Dictionary
	match action:
		"festival_prepare": check = _festival_check(args)
		"kunlun_counter": check = _blockade_check(str(args.get("strategy", "")))
		_: return {"ok": false, "reason": "未知事件操作", "message": "未知事件操作"}
	check.reason = str(check.get("message", ""))
	return check


func perform(action: String, args: Dictionary = {}) -> Dictionary:
	ensure_state()
	if action == "event_choose": return choose(str(args.get("option_id", "")))
	if action == "festival_prepare":
		var check = _festival_check(args)
		if not check.ok: return check
		_s().festival.employee_id = str(check.selection.employee_id)
		_s().festival.dish_id = str(check.selection.dish_id)
		_m().changed.emit()
		return {"ok": true, "message": "美食节厨师与菜品已准备；报名时仍需支付费用并耗用食材"}
	if action == "kunlun_counter": return _blockade_counter(str(args.get("strategy", "")))
	if action == "pay_fines":
		var paid = minf(float(_m().state.cash), float(_s().unpaid_fines))
		if paid <= 0: return {"ok": false, "message": "没有可支付的罚款或现金不足"}
		_cash(-paid, "补缴罚款")
		_s().unpaid_fines = maxf(0, float(_s().unpaid_fines) - paid)
		_m().changed.emit()
		return {"ok": true, "message": "已支付罚款 ￥%.2f" % paid}
	if action == "zhulong_shift":
		if not _active("zhu_long") or not _m().business_open(): return {"ok": false, "message": "烛龙需在营业时当班"}
		if int(_s().zhulong_day) == _day(): return {"ok": false, "message": "今日已使用昼夜神通"}
		var target = str(args.get("period", "dinner"))
		if not target in ["breakfast", "lunch", "tea", "dinner", "night_market"]: return {"ok": false, "message": "只能切换为营业时段系数"}
		_s().zhulong_period = target
		_s().zhulong_day = _day()
		_m().changed.emit()
		return {"ok": true, "message": "今日客流采用%s时段系数" % target}
	return {"ok": false, "message": "未知事件操作"}


func snapshot() -> Dictionary:
	ensure_state()
	var festival = _s().festival.duplicate(true)
	festival.merge(_festival_candidates())
	festival.merge(_festival_selection(), true)
	festival.opponent_score = _b("events.festival_opponent_score", 70)
	festival.quality_weight = _b("events.festival_score_quality", 0.8)
	festival.creativity_weight = _b("events.festival_score_creativity", 1)
	festival.specialty_bonus = _b("events.festival_specialty_bonus", 5)
	var blockade = _s().blockade.duplicate(true)
	blockade.service_target = int(_b("events.blockade_service_target", 12))
	blockade.service_quality = _b("events.blockade_service_quality", 80)
	blockade.community_reputation = _b("events.blockade_community_reputation", 500)
	blockade.traffic_penalty = _b("events.blockade_traffic_penalty", -0.2)
	blockade.costs = {"supply": _b("events.blockade_supply_cost", 150), "service": _b("events.blockade_service_cost", 0), "community": _b("events.blockade_community_cost", 100)}
	return {"pending": pending_event(), "queue_count": _s().queue.size(), "history": _s().history.duplicate(true), "feedback": _s().feedback.duplicate(true), "flags": _s().flags.duplicate(true), "easter_eggs": _s().easter_eggs.duplicate(true), "seen_events": _s().seen_events.duplicate(), "weather": str(_s().weather), "weather_until": int(_s().weather_until), "modifiers": _s().modifiers.duplicate(true), "active_bonds": active_bonds(), "regulars": int(_s().regulars), "outstanding_receipts": float(_s().outstanding_receipts), "pixiu_receipts": _s().pixiu_receipts.duplicate(true), "unpaid_fines": float(_s().unpaid_fines), "festival_wins": int(_s().festival_wins), "festival_entries": int(_s().festival_entries), "festival": festival, "blockade": blockade, "zhulong_used_today": int(_s().zhulong_day) == _day()}


func _integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value)) and float(value) >= minimum


func _number(value: Variant, minimum: float = 0) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum


func _valid_context(context: Variant) -> bool:
	if not context is Dictionary: return false
	if context.has("employee_id") and str(context.employee_id) != "" and _m()._employee_config(str(context.employee_id)).is_empty(): return false
	if context.has("dish_id") and str(context.dish_id) != "" and _m()._dish(str(context.dish_id)).is_empty(): return false
	if context.has("amount") and not _number(context.amount): return false
	if context.has("customer_id") and not _integer(context.customer_id): return false
	return true


func _valid_effects(effects: Variant, depth: int = 0) -> bool:
	if not effects is Array or depth > 8: return false
	var allowed = ["cash", "gems", "ingredients", "reputation", "debt", "repayment", "mood", "loyalty", "stamina_set", "modifier", "discount", "weather", "random_weather", "kitchen_pause", "delay", "chance", "fine", "random_reward", "regulars", "clear_overdue", "mark_zhulong", "leave", "defer_receipt", "festival", "inspection", "influencer", "special_guest", "research_surprise", "rift_reward", "receipt_return", "flag", "clear_flag", "clear_promotion", "easter_egg", "bulk_purchase", "normal_purchase", "dispute", "scare_guest", "state_begin", "pickup_auto", "pickup_spawn"]
	for effect in effects:
		if not effect is Dictionary or not str(effect.get("type", "")) in allowed: return false
		if str(effect.type)=="pickup_auto" and (not _integer(effect.get("duration"),1) or int(effect.duration)>120):return false
		if str(effect.type)=="pickup_spawn" and (effect.get("kind")!="gems" or effect.get("amount")!=1):return false
		if str(effect.type)=="state_begin" and not _m().full_rules.revision18.config.states.has(str(effect.get("id",""))):return false
		for field in ["amount", "value", "sign", "principal", "probability"]:
			if effect.has(field) and not _number(effect[field], -INF): return false
		for field in ["duration", "delay"]:
			if effect.has(field) and not _integer(effect[field]): return false
		for field in ["amount_key", "value_key", "duration_key", "delay_key", "probability_key"]:
			if effect.has(field) and (not effect[field] is String or not (_m().balance.has(effect[field]) or defaults.has(effect[field]))): return false
		if effect.has("effects") and not _valid_effects(effect.effects, depth + 1): return false
	return true


func _valid_feedback(feedback: Variant, saved_time: int) -> bool:
	if not feedback is Dictionary: return false
	if feedback.is_empty(): return true
	if _definition(str(feedback.get("id", ""))).is_empty() or not _integer(feedback.get("minute")) or int(feedback.minute) > saved_time: return false
	if not str(feedback.get("type", "")) in ["broadcast", "decision", "notice", "state"]: return false
	if not feedback.get("title") is String or not feedback.get("label") is String or not feedback.get("details") is Array: return false
	if not feedback.get("before") is Dictionary or not feedback.get("after") is Dictionary or not feedback.get("changes") is Array: return false
	for key in ["before", "after"]:
		for metric in feedback[key]:
			if not metric is String or not _number(feedback[key][metric], -INF): return false
	for detail in feedback.details:
		if not detail is String: return false
	for change in feedback.changes:
		if not change is Dictionary or not change.get("key") is String or not change.get("label") is String: return false
		for key in ["before", "after", "delta"]:
			if not _number(change.get(key), -INF): return false
		if not is_equal_approx(float(change.after) - float(change.before), float(change.delta)): return false
	return true


func validate_state(saved_world: Dictionary, saved_employees: Array, saved_time: int) -> bool:
	# Validate the supplied candidate only. Reading a bad save must not mutate live state.
	# New fields are optional only for older v1.3 saves, then ensure_state fills them.
	var pixiu_principal := 0.0
	if saved_world.has("feedback") and not _valid_feedback(saved_world.feedback, saved_time): return false
	if saved_world.has("flags"):
		if not saved_world.flags is Array: return false
		var flag_ids = {}
		for flag in saved_world.flags:
			if not flag is Dictionary or not str(flag.get("id", "")) in ["taotie_indulgence", "reputation_risk", "fire_risk", "legal_risk", "kunlun_hostility"] or flag_ids.has(str(flag.id)): return false
			flag_ids[str(flag.id)] = true
			if not flag.get("title") is String or not flag.get("description") is String or _definition(str(flag.get("source_id", ""))).is_empty(): return false
			if not _integer(flag.get("from")) or not _integer(flag.get("until")) or int(flag.until) <= int(flag.from): return false
	if saved_world.has("event_days"):
		if not saved_world.event_days is Dictionary: return false
		for id in saved_world.event_days:
			if _definition(str(id)).is_empty() or not _integer(saved_world.event_days[id]) or int(saved_world.event_days[id]) > int(floor(float(saved_time) / _b("day.minutes", 1440))): return false
	if saved_world.has("easter_eggs"):
		if not saved_world.easter_eggs is Array: return false
		var egg_ids = {}
		for egg in saved_world.easter_eggs:
			if not egg is Dictionary or str(egg.get("id", "")) != "tiangou_past" or egg_ids.has(str(egg.id)): return false
			egg_ids[str(egg.id)] = true
			if not egg.get("title") is String or not egg.get("description") is String or not _integer(egg.get("minute")) or int(egg.minute) > saved_time: return false
	if saved_world.has("waiting_guests"):
		if not saved_world.waiting_guests is Array: return false
		for guest in saved_world.waiting_guests:
			if not guest is Dictionary or not str(guest.get("kind", "")) in ["beast", "fraud", "patron"] or str(guest.get("source_id", "")) != "gudiao_call": return false
			if not _integer(guest.get("minute")) or int(guest.minute) > saved_time: return false
	if saved_world.has("pixiu_receipts"):
		if not saved_world.pixiu_receipts is Dictionary: return false
		var receipts: Dictionary = saved_world.pixiu_receipts
		if not _integer(receipts.get("day"), -1) or not _integer(receipts.get("due")) or not receipts.get("settled") is bool: return false
		for field in ["turnover", "principal", "advanced", "bonus_rate"]:
			if not _number(receipts.get(field)): return false
		if float(receipts.bonus_rate) > 1 or not is_equal_approx(float(receipts.turnover), float(receipts.principal) + float(receipts.advanced)): return false
		var day_minutes = int(_b("day.minutes", 1440))
		if int(receipts.day) > int(floor(float(saved_time) / day_minutes)): return false
		if int(receipts.day) == -1:
			if not receipts.settled or int(receipts.due) != 0 or float(receipts.turnover) != 0: return false
		elif int(receipts.due) != (int(receipts.day) + 1) * day_minutes: return false
		if not receipts.settled: pixiu_principal = float(receipts.principal)
	if saved_world.has("festival"):
		if not saved_world.festival is Dictionary: return false
		var festival: Dictionary = saved_world.festival
		if not festival.get("employee_id") is String or not festival.get("dish_id") is String or not festival.get("last_result") is Dictionary: return false
		if str(festival.employee_id) != "" and _m()._employee_config(str(festival.employee_id)).is_empty(): return false
		if str(festival.dish_id) != "" and _m()._dish(str(festival.dish_id)).is_empty(): return false
		if not festival.last_result.is_empty():
			var result: Dictionary = festival.last_result
			if not _integer(result.get("minute")) or int(result.minute) > saved_time or not result.get("won") is bool: return false
			for key in ["quality", "score", "opponent_score", "ingredient_cost"]:
				if not _number(result.get(key)): return false
			if _m()._employee_config(str(result.get("employee_id", ""))).is_empty() or _m()._dish(str(result.get("dish_id", ""))).is_empty(): return false
	if saved_world.has("blockade"):
		if not saved_world.blockade is Dictionary: return false
		var blockade: Dictionary = saved_world.blockade
		for key in ["active", "resolved", "supply_secured", "community_support", "service_secured"]:
			if not blockade.get(key) is bool: return false
		for key in ["responses", "service_orders"]:
			if not _integer(blockade.get(key)): return false
		if blockade.active and blockade.resolved: return false
		if blockade.has("resolved_minute") and (not _integer(blockade.resolved_minute) or int(blockade.resolved_minute) > saved_time): return false
		if blockade.has("resolved_minute") and (not blockade.resolved or int(blockade.responses) < 1 or not blockade.supply_secured or not blockade.service_secured or not blockade.community_support): return false
	for field in ["queue", "history", "seen_events", "delayed", "modifiers"]:
		if not saved_world.get(field) is Array: return false
	if not saved_world.get("cooldowns") is Dictionary: return false
	for field in ["weather_until", "regulars", "special_guests", "last_random_minute", "next_event_id", "festival_wins", "festival_entries", "legal_cases"]:
		if not _integer(saved_world.get(field)): return false
	for field in ["phoenix_day", "zhulong_day", "last_day"]:
		if not _integer(saved_world.get(field), -1): return false
	for field in ["outstanding_receipts", "unpaid_fines"]:
		if not _number(saved_world.get(field)): return false
	if not str(saved_world.get("weather", "")) in ["clear", "rain", "snow", "heat"]: return false
	if not str(saved_world.get("zhulong_period", "")) in ["", "breakfast", "lunch", "tea", "dinner", "night_market"]: return false
	if int(saved_world.last_random_minute) > saved_time: return false
	var known_employees: Dictionary = {}
	for employee in saved_employees:
		if not employee is Dictionary: return false
		known_employees[str(employee.get("id", ""))] = true
	for id in saved_world.cooldowns:
		if not id is String or _definition(id).is_empty() or not _integer(saved_world.cooldowns[id]): return false
	var seen_ids: Dictionary = {}
	for id in saved_world.seen_events:
		if not id is String or _definition(id).is_empty() or seen_ids.has(id): return false
		seen_ids[id] = true
	var pending_ids: Dictionary = {}
	for entry in saved_world.queue:
		if not entry is Dictionary or _definition(str(entry.get("id", ""))).is_empty(): return false
		if pending_ids.has(str(entry.id)): return false
		pending_ids[str(entry.id)] = true
		if not _integer(entry.get("minute")) or int(entry.minute) > saved_time or not _integer(entry.get("serial"), 1): return false
		if not _valid_context(entry.get("context")): return false
	for entry in saved_world.history:
		if not entry is Dictionary or _definition(str(entry.get("id", ""))).is_empty(): return false
		if not _integer(entry.get("minute")) or int(entry.minute) > saved_time or not _valid_context(entry.get("context")): return false
		var valid_option = false
		for option in _definition(str(entry.id)).get("options", []):
			if str(option.id) == str(entry.get("option", "")): valid_option = true
		if not valid_option: return false
		if entry.has("changes") and not _valid_feedback(entry, saved_time): return false
	for entry in saved_world.delayed:
		if not entry is Dictionary or not _integer(entry.get("due")) or not _valid_context(entry.get("context")): return false
		if not _number(entry.get("probability")) or float(entry.probability) > 1: return false
		if not _valid_effects(entry.get("effects")): return false
		# Existing saves may still contain the original one-receipt delayed
		# return. Keep its principal separate from the new calendar-day balance.
		for effect in entry.effects:
			if str(effect.get("type", "")) == "receipt_return":
				if not _number(effect.get("principal")) or float(effect.get("amount", 0)) < float(effect.principal): return false
				pixiu_principal += float(effect.principal)
	if not is_equal_approx(float(saved_world.outstanding_receipts), pixiu_principal): return false
	for entry in saved_world.modifiers:
		if not entry is Dictionary or not _integer(entry.get("until")): return false
		if not entry.get("key") is String or not entry.get("identity") is String: return false
		if not str(entry.key) in ["traffic", "price", "quality", "cooking_speed", "serving_speed", "waiter_speed", "cleaning_speed", "ingredient", "research_success", "promotion", "satisfaction", "conflict", "group", "tip", "stamina", "ignore_obstacles", "no_wait", "procurement_discount", "complaint"]: return false
		var effect = entry.duplicate(true)
		effect.type = "modifier"
		if not _valid_effects([effect]): return false
	return true

func has_notice() -> bool:
	if not _m().state.get("world") is Dictionary:return false
	for entry in _m().state.world.get("queue",[]):
		if str(_definition(str(entry.id)).get("type",""))=="notice":return true
	return false
func _effect_preview(effects: Array) -> Array:
	var lines: Array[String]=[]
	for effect in effects:
		var kind=str(effect.get("type",""))
		if kind in ["cash","gems","reputation","mood","loyalty","stamina_set"]:
			lines.append("%s %+.2f" % [{"cash":"钞票","gems":"灵石","reputation":"声望","mood":"心情","loyalty":"忠诚","stamina_set":"体力恢复至"}.get(kind,kind),_value(effect,"amount")*float(effect.get("sign",1))])
		elif kind=="pickup_auto":lines.append("自动收取已有及新掉落物，持续%d游戏分钟" % int(effect.get("duration",120)))
		elif kind=="pickup_spawn":lines.append("确认后在地面刷新灵石×1，须在15真实秒内手动拾取")
		elif kind=="state_begin":
			var state_definition=_m().full_rules.revision18.config.states.get(str(effect.get("id","")),{})
			lines.append(str(state_definition.get("title","经营状态"))+"，持续%d游戏分钟" % int(state_definition.get("duration",0)))
		elif kind=="defer_receipt":lines.append("确认后托管今日营业款，日末返还待收本金及全天5%增益")
		elif kind=="discount":lines.append("采购价调整为%.0f%%，持续%d游戏分钟" % [_value(effect,"value")*100,int(_value(effect,"duration"))])
		elif kind=="weather":
			var duration=int(_value(effect,"duration",_b("events.weather_duration")))
			if bool(effect.get("until_day_end",false)):duration=(_day()+1)*int(_b("day.minutes",1440))-_now()
			var weather=str({"rain":"雨天","snow":"暴雪","heat":"酷暑","clear":"晴天"}.get(str(effect.get("weather","clear")),effect.get("weather","clear")))
			lines.append("天气变为%s，持续%d游戏分钟"%[weather,duration])
		elif kind=="modifier":
			var labels={"traffic":"客流","quality":"品质","ingredient":"食材耗用","tip":"小费","promotion":"宣传效果","cleaning_speed":"清台速度","serving_speed":"传菜速度","cooking_speed":"厨房效率","stamina":"体力消耗","procurement_discount":"采购价格","no_wait":"顾客等待保护","ignore_obstacles":"传菜穿行"}
			var duration=int(_value(effect,"duration",_b("events.day_duration")))
			if bool(effect.get("until_day_end",false)):duration=(_day()+1)*int(_b("day.minutes",1440))-_now()
			lines.append("%s %+.0f%%，持续%d游戏分钟"%[str(labels.get(str(effect.get("key","")),effect.get("key",""))),_value(effect,"value")*float(effect.get("sign",1))*100,duration])
		else:lines.append(str(effect.get("key",kind))+"："+str(_value(effect,"value"))+"，持续%d游戏分钟" % int(_value(effect,"duration")))
	return lines
