extends RefCounted
## Soft, persisted v1.5 character stories. Every task reads real operations.
## Cultural cards stay freely readable; atlas pages require actual collection.
var _model_ref: WeakRef
var config: Dictionary = {}
var _history_tail := ""
const ACTIONS := ["sidequest_read", "sidequest_choice", "sidequest_finish", "baize_page", "lore_read", "gift", "care"]

func _init(host: RefCounted, _rules: Variant = null) -> void:
	_model_ref = weakref(host)
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"))
	if parsed is Dictionary: config = parsed

func _m() -> Variant: return _model_ref.get_ref()
func _s() -> Dictionary: return _m().state.sidequests
func _now() -> int: return int(_m().state.get("total_minutes", 0))
func _day() -> int: return int(_now() / maxi(1, int(_v("day_minutes", 1440))))
func _v(key: String, fallback: float = 0) -> float:
	return float(_m().balance.get("sidequests." + key, config.get("defaults", {}).get(key, fallback)))

func default_state() -> Dictionary:
	return {"version":1, "quests":{}, "pages":[], "lore_unlocked":[], "lore_read":[], "observed_events":[], "event_counts":{}, "counters":{}, "affinity_records":{}, "last_minute":-1, "legacy_baize_owned":false}

func _quest_default() -> Dictionary:
	return {"stage":0, "choice":"", "ending":"", "completed_minute":-1, "reward_claimed":false}

func _affinity_default() -> Dictionary:
	return {"duty_minutes":0, "last_duty_day":_day(), "last_neglect_day":_day(), "gift_day":-1, "care_day":-1, "counter_day":-1}

func ensure_state() -> void:
	if not _m().state.get("sidequests") is Dictionary:
		_m().state.sidequests = default_state()
		_s().legacy_baize_owned = bool(_m().state.get("migration_v15", {}).get("legacy_baize_owned", false))
	for key in default_state():
		if not _s().has(key): _s()[key] = default_state()[key]
	for definition in config.get("quests", []):
		if not _s().quests.has(str(definition.id)): _s().quests[str(definition.id)] = _quest_default()
	for employee in _m().employees:
		if not employee.has("affinity"): employee.affinity = 0.0
		if not _s().affinity_records.has(str(employee.id)): _s().affinity_records[str(employee.id)] = _affinity_default()
		var unlocked: String = appearance_for(str(employee.id))
		if not unlocked.is_empty(): employee.appearance = unlocked

func appearance_for(employee_id: String) -> String:
	for definition in config.get("quests", []):
		if str(definition.employee_id) == employee_id and int(_s().quests.get(str(definition.id), {}).get("stage", 0)) == 3:
			return str(definition.get("reward", {}).get("appearance", ""))
	return ""

func _definition(id: String) -> Dictionary:
	for quest in config.get("quests", []):
		if str(quest.id) == id: return quest
	return {}

func _lore_definition(id: String) -> Dictionary:
	for lore in config.get("lore", []):
		if str(lore.id) == id: return lore
	return {}

func _collected() -> Array:
	var ids: Array = _m().state.get("story", {}).get("collected_ids", []).duplicate()
	for employee in _m().employees:
		if not str(employee.id) in ids: ids.append(str(employee.id))
	for employee in _m().state.get("management", {}).get("departed", []):
		if not str(employee.id) in ids: ids.append(str(employee.id))
	return ids

func affinity(id: String) -> float:
	if id == "bai_ze" and _m()._employee(id).is_empty(): return minf(_v("affinity_max", 100), _s().pages.size() * _v("baize_page_gain", 4)+float(_m().state.get("revision171",{}).get("baize_bonus",0)))
	return float(_m()._employee(id).get("affinity", 0))

func add_affinity(id: String, amount: float, reason: String = "") -> float:
	var employee: Dictionary = _m()._employee(id)
	if employee.is_empty() or not is_finite(amount): return 0.0
	var previous := float(employee.get("affinity", 0))
	employee.affinity = clampf(previous + amount, 0, _v("affinity_max", 100))
	var actual := float(employee.affinity) - previous
	if not is_zero_approx(actual) and not reason.is_empty(): _m()._log("%s好感 %+.0f：%s" % [str(employee.name), actual, reason])
	return actual

func baize_unlocked() -> bool:
	ensure_state()
	return bool(_s().legacy_baize_owned) or int(_s().quests.get("baize_atlas", {}).get("stage", 0)) == 3

func _has_event(id: String) -> bool:
	return int(_s().event_counts.get(id, 0)) > 0

func _task(definition: Dictionary) -> Dictionary:
	var task: Dictionary = definition.task.duplicate(true)
	match str(task.type):
		"pages":
			task.current = _s().pages.size()
			task.target = int(_v("page_target", 25))
		"ingredients":
			task.current = 0
			task.target = task.items.size()
			for id in task.items:
				if float(_m().full_rules.management.item(str(id)).get("quantity", 0)) >= float(task.items[id]): task.current = int(task.current) + 1
		"counter": task.current = int(_s().counters.get(str(task.key), 0))
	task.ready = _m().sandbox!=null or int(task.get("current", 0)) >= int(task.get("target", 1))
	return task

func _stage_two_ready(definition: Dictionary) -> bool:
	if _m().sandbox!=null:return true
	if affinity(str(definition.employee_id)) < _v("affinity_second", 60): return false
	if str(definition.employee_id) == "bai_ze": return true
	return _has_event(str(definition.event_id))

func _result(ok: bool, reason: String = "") -> Dictionary:
	return {"ok":ok, "reason":reason, "message":reason}

func can_perform(action: String, args: Dictionary = {}) -> Dictionary:
	ensure_state()
	if action in ["gift", "care"]:
		var id := str(args.get("employee_id", args.get("id", "")))
		if _m()._employee(id).is_empty(): return _result(false, "请先招募这位员工；引导白泽可通过档案残页建立好感")
		if affinity(id) >= _v("affinity_max", 100): return _result(false, "好感已满")
		var record: Dictionary = _s().affinity_records[id]
		if int(record.gift_day if action == "gift" else record.care_day) == _day(): return _result(false, "今天已赠礼" if action == "gift" else "今天已经交谈")
		if action == "gift":
			if not str(args.get("kind", "tea")) in ["tea", "book"]: return _result(false, "请选择茶点或书册")
			if float(_m().state.cash) < _v("gift_cost", 20): return _result(false, "现金不足，礼物需要￥%.0f" % _v("gift_cost", 20))
		return _result(true)
	if action == "baize_page":
		var id := str(args.get("id", ""))
		if not id in _m().full_rules.revision18.config.original_page_ids:return _result(false,"白泽支线保留原有25页，旋龟与青耕不新增必需残页")
		if id in _s().pages: return _result(false, "这页档案已整理")
		if not id in _collected(): return _result(false, "真正结识并招募这位异兽后，才能整理档案页")
		return _result(true)
	if action == "lore_read":
		return _result(str(args.get("id", "")) in _s().lore_unlocked, "山海志尚未发现" if not str(args.get("id", "")) in _s().lore_unlocked else "")
	var definition := _definition(str(args.get("id", "")))
	if definition.is_empty(): return _result(false, "未知神兽支线")
	var progress: Dictionary = _s().quests[str(definition.id)]
	var stage := int(progress.stage)
	if stage == 3: return _result(false, "这条支线已完成，可随时重读")
	if str(definition.employee_id) != "bai_ze" and _m()._employee(str(definition.employee_id)).is_empty(): return _result(false, "招募对应神兽后开启支线")
	match action:
		"sidequest_read":
			if stage != 0: return _result(false, "来处已经读过，请查看后续心结与专属任务")
		"sidequest_choice":
			if stage != 1: return _result(false, "请先阅读来处")
			if not _stage_two_ready(definition): return _result(false, "需要好感≥%.0f并经历专属事件；白泽以收集残页推进" % _v("affinity_second", 60))
			var found := false
			for choice in definition.nodes[1].get("choices", []):
				if str(choice.id) == str(args.get("choice_id", "")): found = true
			if not found: return _result(false, "请选择一项对话回应")
		"sidequest_finish":
			if stage != 2: return _result(false, "请先完成心结对话")
			if affinity(str(definition.employee_id)) < _v("affinity_final", 90): return _result(false, "归处需要好感≥%.0f" % _v("affinity_final", 90))
			if not bool(_task(definition).ready): return _result(false, str(definition.task.label))
		_: return _result(false, "未知支线操作")
	return _result(true)

func perform(action: String, args: Dictionary = {}) -> Dictionary:
	var check := can_perform(action, args)
	if not bool(check.ok): return check
	if action in ["gift", "care"]:
		var id := str(args.get("employee_id", args.get("id", "")))
		if action == "gift":
			var cost := _v("gift_cost", 20)
			_m().change_cash(-cost, "operating_expenses", "员工赠礼")
			_m().full_rules.record("expenses", cost, "员工赠礼")
			_s().affinity_records[id].gift_day = _day()
			add_affinity(id, _v("gift_gain", 8), "收到书册" if str(args.get("kind", "tea")) == "book" else "一同分享茶点")
		else:
			_s().affinity_records[id].care_day = _day()
			add_affinity(id, _v("care_gain", 2), "认真听完彼此今日的感受")
		return _result(true, "好感已更新；心情与忠诚保持独立")
	if action == "baize_page":
		var id := str(args.id)
		_s().pages.append(id)
		_m()._log("白泽图残页：整理了%s的档案（%d/%d）。文化简介仍可自由阅读。" % [str(_m()._employee_config(id).name), _s().pages.size(), int(_v("page_target", 25))])
		return _result(true, "白泽图档案残页已保存")
	if action == "lore_read":
		if not str(args.id) in _s().lore_read: _s().lore_read.append(str(args.id))
		return _result(true, "山海志阅读进度已保存；不发放数值奖励")
	var definition := _definition(str(args.id))
	var progress: Dictionary = _s().quests[str(definition.id)]
	match action:
		"sidequest_read": progress.stage = 1
		"sidequest_choice":
			progress.stage = 2
			progress.choice = str(args.choice_id)
		"sidequest_finish":
			if str(definition.task.type) == "ingredients": _consume_quest_items(definition.task.items)
			progress.stage = 3
			progress.ending = str(definition.endings.get(str(progress.choice), ""))
			progress.completed_minute = _now()
			progress.reward_claimed = true
			_apply_reward(definition.reward)
			add_affinity(str(definition.employee_id), _v("quest_gain", 5), "共同完成专属支线")
			_unlock_lore_by("quest_id", str(definition.id))
			_m()._log("神兽支线完成：%s。%s" % [str(definition.title), str(progress.ending)])
			return {"ok":true, "reason":"", "message":"支线完成：" + str(definition.title), "reward":definition.reward.duplicate(true)}
	_m()._log("神兽支线：%s，已保存%s。" % [str(definition.title), "来处" if action == "sidequest_read" else "心结回应"])
	return _result(true, "剧情进度已保存，可随时返回经营")

func _apply_reward(reward: Dictionary) -> void:
	var appearance: String = str(reward.get("appearance", ""))
	if not appearance.is_empty():
		var employee: Dictionary = _m()._employee(appearance.trim_suffix("_awakened"))
		if not employee.is_empty(): employee.appearance = appearance
	var id := str(reward.get("hidden_recipe", ""))
	if id.is_empty(): return
	for dish in additional_dishes():
		if str(dish.id) != id: continue
		if _m()._dish(id).is_empty(): _m().dishes.append(dish.duplicate(true))
		if not id in _m().state.unlocked_dishes: _m().state.unlocked_dishes.append(id)
		if not id in _m().state.menu_enabled: _m().state.menu_enabled.append(id)
		var management: Dictionary = _m().state.management
		if not management.base_prices.has(id): management.base_prices[id] = float(dish.price)
		_m()._log("专属隐藏菜已进入实际菜单：" + str(dish.name))

func _consume_quest_items(items: Dictionary) -> void:
	var management: Variant = _m().full_rules.management
	var expense := 0.0
	for id in items:
		var record: Dictionary = management.item(str(id))
		var quantity := float(items[id])
		var value := float(record.value) * quantity / float(record.quantity)
		record.quantity = maxf(0, float(record.quantity) - quantity)
		record.value = maxf(0, float(record.value) - value)
		record.consumption_today = float(record.consumption_today) + quantity
		expense += value
	management._data().daily_development = float(management._data().daily_development) + expense
	_m().full_rules.record("expenses", expense, "凤凰专属支线食材耗用")
	management._sync_totals()

func _increment(key: String, amount: int = 1) -> void:
	_s().counters[key] = int(_s().counters.get(key, 0)) + amount

func _unlock_lore(id: String) -> void:
	if id in _s().lore_unlocked: return
	_s().lore_unlocked.append(id)
	_m()._log("发现山海志：%s（剧情收藏，无数值奖励）。" % str(_lore_definition(id).get("title", id)))

func _unlock_lore_by(key: String, value: String) -> void:
	for lore in config.get("lore", []):
		if str(lore.get("trigger", {}).get(key, "")) == value: _unlock_lore(str(lore.id))

func on_event(id: String, option: String, context: Dictionary = {}, minute: int = -1) -> void:
	ensure_state()
	var event_minute := _now() if minute < 0 else minute
	var identity := "%d:%s:%s" % [event_minute, id, option]
	if identity in _s().observed_events: return
	_s().observed_events.append(identity)
	while _s().observed_events.size() > int(_v("history_limit", 256)): _s().observed_events.pop_front()
	_s().event_counts[id] = int(_s().event_counts.get(id, 0)) + 1
	_s().event_counts[id + ":" + option] = int(_s().event_counts.get(id + ":" + option, 0)) + 1
	for definition in config.get("quests", []):
		if str(definition.event_id) == id: add_affinity(str(definition.employee_id), _v("event_gain", 3), "共同经历专属事件")
	if id == "jiuying_multitask":
		_s().counters.jiuying_sequence = int(_s().counters.get("jiuying_sequence", 0)) + 1 if option == "coordinate" else 0
	if id == "qiongqi_fight" and option == "mediate": _increment("qiongqi_mediated")
	if id == "xiezhi_judgment" and option == "resolve": _increment("xiezhi_resolved")
	for lore in config.get("lore", []):
		var trigger: Dictionary = lore.get("trigger", {})
		if str(trigger.get("event_id", "")) == id and str(trigger.get("option", option)) == option: _unlock_lore(str(lore.id))
	# The context stays informational: it never fabricates an employee or payout.
	if not context.is_empty(): pass

func on_hook(kind: String, context: Dictionary = {}) -> void:
	ensure_state()
	if kind == "cleaning" and str(context.get("employee_id", "")) == "jing_wei": _increment("jingwei_cleaned")

func on_action(action: String, args: Dictionary = {}, result: Dictionary = {}) -> void:
	if not bool(result.get("ok", true)): return
	ensure_state()
	if action == "exploration_complete": on_exploration(str(args.get("location", "")), args)

func on_customer_served(customer: Dictionary, worker: Dictionary = {}) -> void:
	ensure_state()
	# Parent invokes once after settlement. Escape/unpaid orders do not satisfy
	# these guest-facing tasks; the cashier is not mistaken for the server.
	if not bool(customer.get("paid", false)) or float(customer.get("settled_amount", 0)) <= 0: return
	# Keep completion idempotent even if a saved scheduler callback is replayed.
	# A repeat purchase clears the customer dictionary and starts a fresh order.
	if bool(customer.get("sidequest_sale_recorded", false)): return
	customer.sidequest_sale_recorded = true
	var chef := str(customer.get("chef_id", ""))
	var server := str(customer.get("serving_employee_id", worker.get("id", "")))
	var category := str(_m()._dish(str(customer.get("dish_id", ""))).get("category", ""))
	if chef == "ying_long" and category == "水产": _increment("yinglong_aquatic_served")
	if chef == "zhu_long" and _m().period() in ["dinner", "night_market"]: _increment("zhulong_night_served")
	if server == "di_jiang": _increment("dijiang_served")
	if server == "jiu_wei_hu": _increment("fox_served")

func on_exploration(location: String, _context: Dictionary = {}) -> void:
	ensure_state()
	_unlock_lore_by("location", location)

func on_counter_pairs(pairs: Array) -> void:
	ensure_state()
	for pair in pairs:
		for id in pair.get("employee_ids", []):
			if not _s().affinity_records.has(str(id)): continue
			var record: Dictionary = _s().affinity_records[str(id)]
			if int(record.counter_day) == _day(): continue
			record.counter_day = _day()
			add_affinity(str(id), -_v("counter_loss", 2), "相克同班产生分歧（每人每日最多一次）")

func _on_duty(employee: Dictionary) -> bool:
	if not _m().business_open(): return false
	if bool(employee.get("resting", false)) or float(employee.get("stamina", 0)) <= 0: return false
	if bool(employee.get("shift_enabled", false)) and not _m().period() in employee.get("shift_periods", []): return false
	for key in ["away_until", "leave_until", "training_until", "research_until", "management_until", "expansion_until"]:
		if int(employee.get(key, 0)) > _now(): return false
	return true

func tick_minute() -> void:
	ensure_state()
	# Polling persisted history also covers existing auto events and legacy hooks;
	# identity de-duplication prevents double affinity when a direct hook is used.
	var history: Array = _m().state.get("world", {}).get("history", [])
	if not history.is_empty():
		var tail: Dictionary = history.back()
		var identity := "%d:%s:%s" % [int(tail.get("minute", _now())), str(tail.get("id", "")), str(tail.get("option", ""))]
		if identity != _history_tail:
			for event in history:
				var key := "%d:%s:%s" % [int(event.get("minute", _now())), str(event.get("id", "")), str(event.get("option", ""))]
				if not key in _s().observed_events: on_event(str(event.get("id", "")), str(event.get("option", "")), event.get("context", {}), int(event.get("minute", _now())))
			_history_tail = identity
	if bool(_m().state.get("world", {}).get("blockade", {}).get("resolved", false)): _unlock_lore_by("state", "kunlun_resolved")
	var synergy: Variant = _m().full_rules.get("synergies")
	if synergy != null:
		for pair in synergy.active_pairs(): _unlock_lore_by("pair_id", str(pair.id))
	var previous := int(_s().last_minute)
	if _now() <= previous: return
	# A missed callback does not award hours of imaginary work; at most this
	# actual minute is observed, matching the model's minute scheduler.
	_s().last_minute = _now()
	for employee in _m().employees:
		if not _on_duty(employee): continue
		var record: Dictionary = _s().affinity_records[str(employee.id)]
		record.last_duty_day = _day()
		record.duty_minutes = int(record.duty_minutes) + 1
		if int(record.duty_minutes) >= maxi(1, int(_v("stable_minutes", 120))):
			record.duty_minutes = 0
			add_affinity(str(employee.id), _v("stable_gain", 1))

func on_day() -> void:
	ensure_state()
	for employee in _m().employees:
		var record: Dictionary = _s().affinity_records[str(employee.id)]
		var since := maxi(int(record.last_duty_day), int(record.last_neglect_day))
		if _day() - since >= maxi(1, int(_v("neglect_days", 10))):
			record.last_neglect_day = _day()
			add_affinity(str(employee.id), -_v("neglect_loss", 2), "连续十天未排班（无自然衰减）")

func modifiers() -> Dictionary:
	ensure_state()
	var result := {"jiuying_batch_capacity":3, "appearances":[], "hidden_recipes":[]}
	for definition in config.get("quests", []):
		if int(_s().quests[str(definition.id)].stage) != 3: continue
		var reward: Dictionary = definition.reward
		if reward.has("jiuying_batch_capacity"): result.jiuying_batch_capacity = int(reward.jiuying_batch_capacity)
		if reward.has("appearance"): result.appearances.append(str(reward.appearance))
		if reward.has("hidden_recipe"): result.hidden_recipes.append(str(reward.hidden_recipe))
	return result

func additional_dishes() -> Array:
	return config.get("hidden_recipes", []).duplicate(true)

func snapshot() -> Dictionary:
	ensure_state()
	var entries: Array = []
	for definition in config.get("quests", []):
		var item: Dictionary = definition.duplicate(true)
		var progress: Dictionary = _s().quests[str(definition.id)]
		var stage := int(progress.stage)
		item.merge(progress, true)
		item.affinity = affinity(str(definition.employee_id))
		item.owned = not _m()._employee(str(definition.employee_id)).is_empty()
		item.available = item.owned or str(definition.employee_id) == "bai_ze"
		item.node = definition.nodes[mini(stage, 2)].duplicate(true)
		item.task = _task(definition)
		var read_check := can_perform("sidequest_read", {"id":str(definition.id)})
		var choice_check := can_perform("sidequest_choice", {"id":str(definition.id), "choice_id":"understand"})
		var finish_check := can_perform("sidequest_finish", {"id":str(definition.id)})
		item.can_read = bool(read_check.ok)
		item.can_choose = bool(choice_check.ok)
		item.can_finish = bool(finish_check.ok)
		item.ready = item.can_read or item.can_choose or item.can_finish
		item.reason = str(read_check.reason if stage == 0 else (choice_check.reason if stage == 1 else finish_check.reason))
		item.image_key = "Characters/" + str(definition.employee_id) + "_lore.png"
		entries.append(item)
	var pages: Array = []
	var collected := _collected()
	for employee in _m().catalog:
		if not str(employee.id) in _m().full_rules.revision18.config.original_page_ids: continue
		pages.append({"employee_id":str(employee.id), "name":str(employee.name), "collected":str(employee.id) in _s().pages, "available":str(employee.id) in _m().full_rules.revision18.config.original_page_ids and str(employee.id) in collected and not str(employee.id) in _s().pages})
	var lore_entries: Array = []
	for definition in config.get("lore", []):
		var item: Dictionary = definition.duplicate(true)
		item.unlocked = str(definition.id) in _s().lore_unlocked
		item.read = str(definition.id) in _s().lore_read
		if not item.unlocked: item.text = "尚未发现。线索：" + str(definition.source)
		lore_entries.append(item)
	var affinity_entries: Array = []
	for employee in _m().employees:
		var id := str(employee.id)
		affinity_entries.append({"employee_id":id, "name":str(employee.name), "value":affinity(id), "can_gift":bool(can_perform("gift", {"employee_id":id}).ok), "can_care":bool(can_perform("care", {"employee_id":id}).ok), "gift_cost":_v("gift_cost", 20), "gift_gain":_v("gift_gain", 8), "care_gain":_v("care_gain", 2)})
	return {"entries":entries, "pages":pages, "page_count":_s().pages.size(), "page_target":int(_v("page_target", 25)), "baize_unlocked":baize_unlocked(), "lore":lore_entries, "lore_count":_s().lore_unlocked.size(), "lore_total":lore_entries.size(), "affinity":affinity_entries, "exploration_locations":config.get("exploration_locations", []).duplicate(true)}

func balance_defaults() -> Dictionary:
	var result: Dictionary = {}
	for key in config.get("defaults", {}): result["sidequests." + str(key)] = config.defaults[key]
	return result

func validate_balance(candidate: Dictionary) -> bool:
	var defaults := balance_defaults()
	for key in defaults:
		var value: Variant = candidate.get(key, defaults[key])
		if not (value is int or value is float) or not is_finite(float(value)) or float(value) <= 0: return false
	for key in ["affinity_max", "affinity_second", "affinity_final", "affinity_resignation"]:
		if float(candidate.get("sidequests." + key, defaults["sidequests." + key])) > 100: return false
	if float(candidate.get("sidequests.affinity_second", 60)) >= float(candidate.get("sidequests.affinity_final", 90)): return false
	if int(candidate.get("sidequests.page_target", 25)) != 25: return false
	return true

func _integer(value: Variant, minimum: int = 0) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= minimum and float(value) == floorf(float(value))

func validate_state(saved: Dictionary, employees: Array, time: int) -> bool:
	if not _integer(saved.get("version"), 1) or int(saved.version) != 1 or not saved.get("legacy_baize_owned") is bool: return false
	for field in ["quests", "event_counts", "counters", "affinity_records"]:
		if not saved.get(field) is Dictionary: return false
	for field in ["pages", "lore_unlocked", "lore_read", "observed_events"]:
		if not saved.get(field) is Array: return false
	if not _integer(saved.get("last_minute"), -1) or int(saved.last_minute) > time: return false
	var known_employees: Array = []
	for employee in _m().catalog: known_employees.append(str(employee.id))
	for employee in employees:
		if not (employee.get("affinity") is int or employee.get("affinity") is float) or not is_finite(float(employee.affinity)) or float(employee.affinity) < 0 or float(employee.affinity) > 100: return false
	var seen: Array = []
	for id in saved.pages:
		if not id is String or not id in _m().full_rules.revision18.config.original_page_ids or not id in known_employees or id in seen: return false
		seen.append(id)
	if saved.pages.size() > 25: return false
	for field in ["lore_unlocked", "lore_read"]:
		seen = []
		for id in saved[field]:
			if not id is String or _lore_definition(id).is_empty() or id in seen: return false
			if field == "lore_read" and not id in saved.lore_unlocked: return false
			seen.append(id)
	if saved.quests.size() != config.get("quests", []).size(): return false
	for id in saved.quests:
		var definition := _definition(str(id))
		if definition.is_empty() or not saved.quests[id] is Dictionary: return false
		var quest: Dictionary = saved.quests[id]
		if not _integer(quest.get("stage")) or int(quest.stage) > 3: return false
		if not quest.get("choice") is String or not quest.get("ending") is String or not quest.get("reward_claimed") is bool: return false
		if not _integer(quest.get("completed_minute"), -1) or int(quest.completed_minute) > time: return false
		if int(quest.stage) < 2 and str(quest.choice) != "": return false
		if int(quest.stage) >= 2 and not str(quest.choice) in ["understand", "cooperate"]: return false
		if (int(quest.stage) == 3) != bool(quest.reward_claimed): return false
		if int(quest.stage) == 3:
			if int(quest.completed_minute) < 0 or str(quest.ending) != str(definition.endings[str(quest.choice)]): return false
			if str(id) == "baize_atlas" and saved.pages.size() != 25: return false
		elif int(quest.completed_minute) != -1 or str(quest.ending) != "": return false
	for field in ["event_counts", "counters"]:
		for key in saved[field]:
			if not key is String or not _integer(saved[field][key]): return false
	var today := int(time / maxi(1, int(_v("day_minutes", 1440))))
	for id in saved.affinity_records:
		if not id is String or not id in known_employees or not saved.affinity_records[id] is Dictionary: return false
		var record: Dictionary = saved.affinity_records[id]
		if not _integer(record.get("duty_minutes")) or int(record.duty_minutes) >= maxi(1, int(_v("stable_minutes", 120))): return false
		for key in ["last_duty_day", "last_neglect_day", "gift_day", "care_day", "counter_day"]:
			if not _integer(record.get(key), -1) or int(record[key]) > today: return false
	seen = []
	if saved.observed_events.size() > int(_v("history_limit", 256)): return false
	for value in saved.observed_events:
		if not value is String or value in seen: return false
		seen.append(value)
	return true
