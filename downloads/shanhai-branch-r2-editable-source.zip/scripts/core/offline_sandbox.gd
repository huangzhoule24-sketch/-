extends RefCounted
## Explicit offline-only free-play tools. Never write normal campaign files.
const SAVE="user://classroom_sandbox.json"
const CHECKPOINT="user://classroom_sandbox_checkpoint.json"
var _ref: WeakRef
var remaining=0
var last_message=""
func _init(model):_ref=weakref(model)
func m():return _ref.get_ref()
func options() -> Dictionary:return m().state.get("sandbox_mode",{})
func start():
 m().start_full()
 m().state.sandbox_mode={"enabled":true,"protect":true,"random_events":false}
 unlock_all()
 m().paused=true
func unlock_all():
 var model=m();var s=model.state
 s.stage=4;s.debt=0.0;s.reputation=maxi(20000,int(s.reputation));s.developer_mode=false
 model.full_rules.ensure_state_defaults()
 for entry in model.catalog:
  if model._employee(str(entry.id)).is_empty():model.employees.append(model._create_employee(entry))
 s.story.collected_ids=model.catalog.map(func(e):return str(e.id))
 s.management.hidden_unlocked=true;model.full_rules.management._ensure_hidden_dish()
 for definition in model.full_rules.sidequests.additional_dishes():
  if model._dish(str(definition.id)).is_empty():model.dishes.append(definition.duplicate(true))
 s.unlocked_dishes=model.dishes.map(func(d):return str(d.id));s.menu_enabled=s.unlocked_dishes.duplicate()
 s.management.suppliers=["ordinary","shanhai"];s.management.skill_books=1000
 s.sidequests.pages=model.full_rules.revision18.config.original_page_ids.duplicate()
 s.sidequests.lore_unlocked=model.full_rules.sidequests.config.get("lore",[]).map(func(l):return str(l.id))
 for e in model.employees:
  e.affinity=100.0;e.stamina=100.0;e.mood=100.0;e.loyalty=100.0
  s.fragments[str(e.id)]=1000
  e.resting=not str(e.id) in ["xian_yang","xiao","dang_kang","bi_fang","di_jiang","jiu_ying","zhu_long","bai_ze"]
  e.shift_enabled=false
 s.expansion.membership.enabled=true;s.expansion.delivery_enabled=true;s.expansion.central.enabled=true
 for id in s.expansion.branches:s.expansion.branches[id].open=true
 s.tutorial.completed_steps=preload("res://scripts/core/tutorial_progress.gd").config().steps.map(func(e):return str(e.id));s.tutorial.finished=true
 s.tutorial.stage_completed=preload("res://scripts/core/tutorial_progress.gd").config().stage_steps.map(func(e):return str(e.id))
 s.special_visitors.helped=true
 for guest in model.full_rules.visitors.definitions():
  if not s.special_visitors.records.has(str(guest.id)):s.special_visitors.records[str(guest.id)]={"met":1,"best":"自由体验解锁","best_score":-1.0,"last":"自由体验解锁"}
 model.full_rules.ensure_state_defaults()
 s.culture_experience.route_completed=model.full_rules.culture_experience.config.regions.map(func(r):return str(r.id))
 for id in ["menu","bifang","harvest"]:model.full_rules.culture_experience.event(id).status="offered"
 # A third real stove permits Jiuying's actual parallel-work mechanic.
 if model.full_rules.dollhouse.fixtures("stove").size()<3:model.full_rules.dollhouse._install("stove",false)
 refill()
 last_message="全部阶段、30位员工、菜谱、供应商、分店与文化阅读已开放。"
 model.changed.emit()
func refill():
 var model=m();var s=model.state
 add_cash(maxf(0,10000000-float(s.cash)));s.gems=maxi(100000,int(s.gems));s.freshness=100.0;s.hire_tickets=maxi(1000,int(s.hire_tickets))
 for d in model.full_rules.management.ingredients:
  var item: Dictionary=s.management.items[str(d.id)];item.quantity=maxf(5000,float(item.quantity));item.freshness=100.0;item.value=float(item.quantity)*float(d.price)
 for id in s.expansion.central.stock:s.expansion.central.stock[id]=maxi(100,int(s.expansion.central.stock[id]))
 for dish in model.dishes:
  s.expansion.central.stock[str(dish.id)]=100;s.expansion.central.stock_cost[str(dish.id)]=0.0
 model.full_rules.management._sync_totals();recover();model.changed.emit()
func add_cash(amount: float):
 if is_zero_approx(amount):return
 m().change_cash(amount,"financing","自由体验：资源注资/调整（不计营业额）")
 m().full_rules.record("financing",amount,"自由体验资源调整")
func max_staff():
 for e in m().employees:
  e.level=m().full_rules.revision.level_cap(e);e.skill_level=5
  for attribute in e.attributes:e.attributes[attribute]=20
  e.stamina=100.0;e.mood=100.0;e.loyalty=100.0
 last_message="全部员工已达到当前等级上限、七属性20、技能5。";m().changed.emit()
func recover():
 var s=m().state
 s.finance.rescue.pending=false;s.finance.summary_pending=false;s.rescue171.ended=false;s.rescue171.warning_pending=false
 s.revision171.daily_pending=false;s.revision171.daily_auto=false;s.revision171.daily_seen=int(s.finance.last_bill_day)
func before_tick():
 if not bool(options().get("protect",true)):return
 var s=m().state
 add_cash(maxf(0,1000000-float(s.cash)));s.gems=maxi(1000,int(s.gems));s.freshness=100.0
 for e in m().employees:e.stamina=100.0;e.mood=100.0;e.loyalty=100.0
 recover()
func queue_minutes(value: int):
 remaining+=clampi(value,0,43200);m().paused=true;last_message="按真实经营逐分钟推演；可随时停止。";m().changed.emit()
func step():
 if remaining<=0:return
 var amount=mini(16,remaining);var before=int(m().state.total_minutes)
 m().advance_minutes(amount)
 remaining-=int(m().state.total_minutes)-before
 if int(m().state.total_minutes)==before:remaining=0;last_message="推演已暂停，请恢复经营状态后继续。"
 elif remaining<=0:last_message="推演完成，订单、项目与日结按真实过程计算。"
func clock_jump(target: int) -> bool:
 if target<0 or target>1440*9999+1439:return false
 remaining=0
 var model=m();var old=int(model.state.total_minutes);var delta=target-old;var day_delta=target/1440-old/1440
 var skip=["finance","ledger","logs","history","records","day_reports","transactions","completion_minutes","affinity_records","sandbox_mode"]
 _shift(model.state,delta,skip);_shift(model.employees,delta,skip);_shift(model.customers,delta,skip);_shift(model.scheduler,delta,skip)
 model.state.total_minutes=target;model._next_spawn_minute+=delta;model._fraction=0
 var f=model.state.finance
 f.last_settled_day=target/1440;f.last_bill_day=target/1440;f.summary_pending=false
 if float(f.loan.principal)>0:f.loan.opened_day+=day_delta;f.loan.due_day+=day_delta
 model.state.expansion.last_day=target/1440;model.state.world.last_day=target/1440+1
 model.state.revision171.daily_seen=int(f.last_bill_day);model.state.revision171.daily_pending=false
 model.full_rules.finance._closing_day=0
 model.paused=true
 last_message="已调整日历并平移在途计时；未补算营业、未回滚收支。回退全部经营请恢复回溯点。"
 model.changed.emit();return true
func _shift(value,delta: int,skip: Array):
 if value is Array:
  for child in value:_shift(child,delta,skip)
 elif value is Dictionary:
  for key in value.keys():
   if str(key) in skip:continue
   var child=value[key]
   if child is Dictionary or child is Array:_shift(child,delta,skip)
   elif (child is int or child is float) and (str(key).ends_with("_until") or str(key).ends_with("_minute") or str(key) in ["started","due","expires","until","next_order","next_entry","next_offer"]):
    if float(child)>0 or str(key)=="started":value[key]=child+delta
func snapshot() -> Dictionary:
 var model=m()
 return {"sandbox_format":1,"state":model.state.duplicate(true),"employees":model.employees.duplicate(true),"customers":model.customers.duplicate(true),"scheduler":model.scheduler.duplicate(true),"logs":model.logs.duplicate(),"speed":model.speed,"fraction":model._fraction,"next_customer_id":model._next_customer_id,"next_spawn_minute":model._next_spawn_minute,"initial_seed":str(model._initial_seed),"rng_seed":str(model._rng.seed),"rng_state":str(model._rng.state)}
func save(path: String=SAVE) -> bool:
 var f=FileAccess.open(path+".tmp",FileAccess.WRITE)
 if f==null:return false
 f.store_string(JSON.stringify(snapshot()));f.flush();f.close()
 return DirAccess.rename_absolute(path+".tmp",path)==OK
func load_save(path: String=SAVE) -> bool:
 var raw=m()._read_json(path,false)
 if not raw is Dictionary or raw.get("sandbox_format",0)!=1:return false
 for key in ["state","employees","customers","scheduler","logs"]:
  if not raw.has(key):return false
 if not raw.state is Dictionary or not raw.employees is Array or not raw.customers is Array or not raw.scheduler is Array or not raw.logs is Array:return false
 if not raw.state.get("sandbox_mode") is Dictionary:return false
 if not raw.state.sandbox_mode.get("enabled",false) or raw.state.get("mode","")!="full":return false
 if not m()._integer(raw.state.get("total_minutes")) or not m()._number(raw.state.get("cash")) or raw.employees.size()>60:return false
 for e in raw.employees:
  if not e is Dictionary or m()._employee_config(str(e.get("id",""))).is_empty():return false
 var model=m()
 model.state=raw.state.duplicate(true);model.employees.assign(raw.employees.duplicate(true));model.customers.assign(raw.customers.duplicate(true));model.scheduler.assign(raw.scheduler.duplicate(true));model.logs.assign(raw.logs)
 model.speed=clampi(int(raw.get("speed",2)),1,128);model._fraction=float(raw.get("fraction",0));model._next_customer_id=int(raw.get("next_customer_id",1));model._next_spawn_minute=int(raw.get("next_spawn_minute",int(model.state.total_minutes)+10));model._initial_seed=str(raw.get("initial_seed","0")).to_int();model._rng.seed=str(raw.get("rng_seed","0")).to_int();model._rng.state=str(raw.get("rng_state","0")).to_int()
 model.full_rules.ensure_state_defaults();model.paused=true;remaining=0;last_message="自由体验存档已恢复，当前暂停。";model.changed.emit();return true
func prepare_case(id: String):
 # Explicit presets are labelled sandbox setups, never presented as earned play.
 start();clock_jump(480 if id!="harvest" else 4*1440+480)
 for e in m().employees:e.resting=not str(e.id) in ["xian_yang","xiao","dang_kang","bi_fang","di_jiang"]
 if id in ["menu","bifang","harvest"]:m().full_rules.culture_experience.event(id).status="offered"
 last_message="已建立课堂演示条件；这是自由体验预设进度。";m().changed.emit()
