extends RefCounted
## Read-only atlas geometry. Imported replacements still take precedence.
static var _data: Dictionary={}
static var _cache: Dictionary={}
static func data() -> Dictionary:
	if _data.is_empty():_data=JSON.parse_string(FileAccess.get_file_as_string("res://config/visual_refinement.json"))
	return _data
static func region(path: String,coordinates: Array) -> Texture2D:
	var key=path+str(coordinates)
	if _cache.has(key):return _cache[key]
	if not ResourceLoader.exists(path):return null
	var image=AtlasTexture.new();image.atlas=load(path);image.region=Rect2(coordinates[0],coordinates[1],coordinates[2],coordinates[3]);image.filter_clip=true;_cache[key]=image
	return image
static func texture(id: String) -> Texture2D:
	if id.begins_with("Portraits/"):
		var character=id.trim_prefix("Portraits/")
		if data().characters.has(character):return region("res://assets/art/VisualRefinement/characters.png",data().characters[character].portrait)
	if id.begins_with("Map/"):
		var name=id.trim_prefix("Map/");name={"equip_serving_counter":"equip_basic_pass","equip_cashier":"equip_basic_cashier"}.get(name,name)
		if data().fixtures.has(name):return region("res://assets/art/VisualRefinement/fixtures.png",data().fixtures[name])
	return null
static func pixel(id: String) -> Texture2D:
	if not data().characters.has(id):return null
	return region("res://assets/art/VisualRefinement/characters.png",data().characters[id].pixel)
static func walking(region_id: String,column: int,frame: int) -> Dictionary:
	var rig=data().walking.get(region_id+":"+str(column),{})
	if rig.is_empty():return {}
	var result=rig.frames[posmod(frame,6)].duplicate();result.reference_height=rig.reference_height
	return result
static func sprite_rect(point: Vector2,height: float,geometry: Dictionary) -> Rect2:
	var scale=height/maxf(1,float(geometry.reference_height));var bounds=geometry.bounds
	return Rect2(point+(Vector2(bounds[0],bounds[1])-Vector2(geometry.ground[0],geometry.ground[1]))*scale,Vector2(bounds[2]-bounds[0],bounds[3]-bounds[1])*scale)
static func reduced(model) -> bool:return bool(model.state.get("culture_experience",{}).get("reduce_fx",false))
