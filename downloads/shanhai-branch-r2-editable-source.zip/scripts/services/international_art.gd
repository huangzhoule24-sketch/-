extends RefCounted
## Atlas regions are rendered directly; generated master images remain intact.
static var _config: Dictionary={}
static var _textures: Dictionary={}
static func config() -> Dictionary:
	if _config.is_empty():_config=JSON.parse_string(FileAccess.get_file_as_string("res://config/international.json"))
	return _config
static func definition(kind: String,id: String) -> Dictionary:
	for item in config().get(kind,[]):
		if str(item.id)==id:return item
	return {}
static func _texture(path: String) -> Texture2D:
	if not _textures.has(path):_textures[path]=load(path)if ResourceLoader.exists(path)else null
	return _textures[path]
static func _region(texture: Texture2D,rect: Rect2) -> Texture2D:
	if texture==null:return null
	var key="frame:"+str(texture.get_instance_id())+":"+str(rect)
	if _textures.has(key):return _textures[key]
	var result=AtlasTexture.new();result.atlas=texture;result.region=rect;result.filter_clip=true;_textures[key]=result;return result
static func character(id: String,pixel=false) -> Texture2D:
	var item=definition("characters",id)
	if item.is_empty():return null
	var region=definition("regions",str(item.region));var image=_texture("res://assets/art/International/"+str(item.region)+"_cast.png")
	if image==null:return null
	var cell=float(image.get_width())/5;var top=int(region.cast_bottom)if pixel else 0;var height=image.get_height()-top if pixel else int(region.cast_top)
	return _region(image,Rect2(cell*int(item.column)+1,top,cell-2,height))
static func dish(id: String) -> Texture2D:
	var item=definition("dishes",id)
	if item.is_empty():return null
	var image=_texture("res://assets/art/International/dishes.png")
	if image==null:return null
	var row=["india","nordic","greece"].find(str(item.region));var w=float(image.get_width())/5;var h=float(image.get_height())/3
	return _region(image,Rect2(w*int(item.column)+1,h*row+1,w-2,h-2))
static func walking(id: String,frame: int) -> Texture2D:
	var item=definition("characters",id)
	if item.is_empty():return null
	var image=_texture("res://assets/art/International/"+str(item.region)+"_walk.png")
	if image==null:return character(id,true)
	var w=float(image.get_width())/6;var h=float(image.get_height())/5
	return _region(image,Rect2(posmod(frame,6)*w+1,int(item.column)*h+1,w-2,h-2))
static func furniture(region_id: String,index: int) -> Texture2D:
	var image=_texture("res://assets/art/International/furniture.png")
	if image==null:return null
	var row=["india","nordic","greece"].find(region_id);var w=float(image.get_width())/5;var h=float(image.get_height())/3
	return _region(image,Rect2(posmod(index,5)*w+1,row*h+1,w-2,h-2))
static func store(id: String,inside=false) -> Texture2D:
	var image=_texture("res://assets/art/International/"+id+"_store.png")
	if image==null:return null
	var half=float(image.get_width())/2
	return _region(image,Rect2(half if inside else 0,0,half,image.get_height()))
static func lore(kind: String,id: String) -> Texture2D:
	return character(id,true)if kind=="employees"else dish(id)if kind=="dishes"else null
