extends RefCounted
var host
func _init(ui):host=ui
func tools():return host.model.sandbox
func button(label: String,fn: Callable,id: String):return host.button(label,fn,false,"sandbox:"+id)
func number(parent: Node,value: float,minimum: float,maximum: float,id: String) -> SpinBox:
 var input=SpinBox.new();input.min_value=minimum;input.max_value=maximum;input.step=1;input.value=value;input.custom_minimum_size=Vector2(110,44);input.set_meta("qa_id","sandbox:"+id);parent.add_child(input)
 input.get_line_edit().add_theme_color_override("font_color",host.INK);input.get_line_edit().add_theme_stylebox_override("normal",host.style(host.PAPER,6))
 return input
func reopen():host.open_panel("自由控制台",false)
func render():
 host.paragraph("离线自由体验版 · 独立存档",host.GREEN)
 host.paragraph("全部功能已开放。修改、快进与演示预设均属自由体验进度；不会覆盖正式版存档。",host.MUTED)
 host.paragraph("当前："+host.model.clock_label()+" · 倍速%d×"%host.model.speed)
 if not tools().last_message.is_empty():host.paragraph(tools().last_message,host.GREEN)
 var actions=host.full_panels._flow(host.modal_body)
 actions.add_child(button("一键全部解锁",func():tools().unlock_all();reopen(),"unlock"))
 actions.add_child(button("补满资金、灵石与库存",func():tools().refill();reopen(),"refill"))
 actions.add_child(button("全部员工满级满属性",func():tools().max_staff();reopen(),"max_staff"))
 actions.add_child(button("保存自由体验进度",func():tools().save();host.show_notice("自由体验进度已保存。"),"save"))
 var options=host.full_panels._flow(host.modal_body)
 for pair in [["protect","资源与体力保护"],["random_events","自动随机事件"]]:
  var id=str(pair[0]);var control=CheckButton.new();control.text=str(pair[1]);control.button_pressed=bool(tools().options().get(id,id=="protect"));control.custom_minimum_size.y=44;control.set_meta("qa_id","sandbox:"+id)
  for color in ["font_color","font_hover_color","font_pressed_color","font_focus_color","font_hover_pressed_color"]:control.add_theme_color_override(color,host.INK)
  control.toggled.connect(func(value):tools().options()[id]=value;tools().save());options.add_child(control);host._qa_buttons.append(control)
 host.paragraph("时间速度与真实推演",host.GREEN)
 var speedrow=host.row();host.modal_body.add_child(speedrow);var speed=number(speedrow,host.model.speed,1,128,"speed")
 speedrow.add_child(button("应用倍速",func():host.model.set_speed(int(speed.value));reopen(),"speed_apply"))
 speedrow.add_child(button("暂停 / 继续",func():host.model.set_paused(not host.model.paused),"pause"))
 var jumps=host.full_panels._flow(host.modal_body)
 for count in [10,60,360,1440]:
  var amount=count;jumps.add_child(button("推演 +%d 分钟"%amount,func():tools().queue_minutes(amount);reopen(),"advance:"+str(amount)))
 var custom=host.row();host.modal_body.add_child(custom);var minutes=number(custom,60,1,43200,"minutes")
 custom.add_child(button("推演指定分钟数",func():tools().queue_minutes(int(minutes.value));reopen(),"advance_custom"))
 custom.add_child(button("停止推演",func():tools().remaining=0;tools().last_message="推演已停止，当前进度保留。";reopen(),"stop"))
 host.paragraph("推演会计算真实订单、培训、装修、探索及日结；资源保护开启时保底资金、体力，避免演示中断。")
 var pending=host.label("",15,host.GREEN);pending.name="SandboxPending";host.modal_body.add_child(pending)
 host.paragraph("日历跳转（不补算营业）",host.GREEN)
 var calendar=host.row();host.modal_body.add_child(calendar);calendar.add_child(host.label("第几日 / 时 / 分"))
 var now=int(host.model.state.total_minutes)
 var day=number(calendar,now/1440+1,1,9999,"day");var hour=number(calendar,now%1440/60,0,23,"hour");var minute=number(calendar,now%60,0,59,"minute")
 host.modal_body.add_child(button("跳转到指定日期时间",func():tools().clock_jump((int(day.value)-1)*1440+int(hour.value)*60+int(minute.value));reopen(),"clock_apply"))
 host.paragraph("日历可向前或向后调整，并平移在途任务的计时；不补算收入费用，已发生账目不回滚。需要恢复整个经营状态时，使用下面的回溯点。",host.MUTED)
 var checkpoints=host.full_panels._flow(host.modal_body)
 checkpoints.add_child(button("记录当前回溯点",func():tools().save(tools().CHECKPOINT);reopen();host.show_notice("已记录回溯点。"),"checkpoint"))
 var restore=button("恢复回溯点",func():tools().load_save(tools().CHECKPOINT);reopen(),"restore");restore.disabled=not FileAccess.file_exists(tools().CHECKPOINT);checkpoints.add_child(restore)
 host.paragraph("课堂案例预设",host.GREEN)
 host.paragraph("预设会重建当前自由体验进度，建议先记录回溯点；这些准备条件不能作为自然通关成果。",host.MUTED)
 var cases=host.full_panels._flow(host.modal_body)
 for entry in [["menu","Lin 菜牌交流"],["bifang","毕方炉边宴"],["harvest","当康丰收分配"]]:
  var id=str(entry[0]);cases.add_child(button(str(entry[1]),func():host.confirm_action("建立课堂预设","会重建当前自由体验进度。已记录的回溯点保留。",func():tools().prepare_case(id);host.open_panel("山海驿路"),"sandbox:preset_confirm:"+id),"preset:"+id))
 host.paragraph("手动触发原有事件",host.GREEN)
 var events=host.row();host.modal_body.add_child(events);var select=OptionButton.new();select.custom_minimum_size=Vector2(240,44)
 for definition in host.model.events:select.add_item(str(definition.get("title",definition.get("name",definition.id))));select.set_item_metadata(select.item_count-1,str(definition.id))
 events.add_child(select)
 events.add_child(button("触发所选事件",func():
  var id=str(select.get_item_metadata(select.selected));var world=host.model.full_rules.world
  var trigger=world._definition(id).get("trigger",{});var who=str(trigger.get("employee_id","xian_yang"))
  if trigger.get("employee_any",[]).size()>0:who=str(trigger.employee_any[0])
  if world._enqueue(id,{"employee_id":who,"dish_id":"bifang_wings"}):host.open_panel("事件")
  else:host.show_notice("该事件当前已在队列中或暂不可重复触发。"),"event"))
