extends RefCounted
## Native portrait chrome. The model and canonical restaurant coordinates stay shared.
var host
var active=false
var hud: VBoxContainer
var resources: HBoxContainer
var statuses: VBoxContainer
var actions: HBoxContainer
var glance: Label
var navigation: GridContainer
var homes: Dictionary={}
var tab_labels: Dictionary={}
var _adapting=false
var cash_message=""
var cash_deadline=0
var cash_color=Color.WHITE

func _init(ui):host=ui
func setup():
	hud=host.column(4);hud.name="PortraitHUD";host._layout_controls.root.add_child(hud);host._layout_controls.root.move_child(hud,0);hud.hide()
	resources=host.row(4);statuses=host.column(0);statuses.name="OverviewOnlyControls";actions=host.row(4)
	for line in [resources,actions,statuses]:hud.add_child(line)
	statuses.hide()
	glance=host.label("",12,host.MUTED);glance.clip_text=true;glance.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS;glance.custom_minimum_size.y=22;glance.set_meta("l10n_managed_text",true);hud.add_child(glance)
	navigation=GridContainer.new();navigation.columns=5;navigation.name="PortraitNavigation";navigation.add_theme_constant_override("h_separation",3);host._layout_controls.bottom.add_child(navigation);navigation.hide()
	for control in top_controls():homes[control]=control.get_parent()
	for name in host.navigation_buttons:
		var control=host.navigation_buttons[name];homes[control]=control.get_parent()
		var column=VBoxContainer.new();column.mouse_filter=Control.MOUSE_FILTER_IGNORE;column.add_theme_constant_override("separation",0);control.add_child(column);column.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);column.offset_left=2;column.offset_right=-2;column.offset_top=4;column.offset_bottom=-2;column.hide()
		var image=TextureRect.new();image.texture=control.icon;image.custom_minimum_size=Vector2(20,22);image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED;image.mouse_filter=Control.MOUSE_FILTER_IGNORE;column.add_child(image)
		var label=host.label(str(name),12);label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;label.mouse_filter=Control.MOUSE_FILTER_IGNORE;column.add_child(label)
		tab_labels[name]={"box":column,"image":image,"label":label,"tooltip":control.tooltip_text}
func top_controls() -> Array:
	return [host.money_label.get_parent().get_parent(),host.gem_label.get_parent().get_parent(),host.reputation_label.get_parent().get_parent(),host.bottom_ui.summary_button,host.clock_label,host.debt_label,host.training_status,host.building_status,host.bottom_ui.inventory_button,host.todo_anchor,host.pause_button,host.bottom_ui.speed_entry]
func apply():
	var next=host.portrait_layout
	if active and not next:
		for control in homes:
			if is_instance_valid(control)and is_instance_valid(homes[control]):control.reparent(homes[control])
		for name in tab_labels:
			var b=host.navigation_buttons[name];tab_labels[name].box.hide();b.icon=tab_labels[name].image.texture;b.text="···"if name=="更多"else str(name);b.custom_minimum_size=Vector2(0,45);b.tooltip_text=tab_labels[name].tooltip
		active=false;hud.hide();navigation.hide();host.bottom_ui.layout();host.map_view.house().fit_all()
		host.overlay.mouse_filter=Control.MOUSE_FILTER_STOP;host.overlay.get_child(0).show()
	if not next:return
	var entering=not active;active=true
	var pill=host.money_label.get_parent().get_parent();move(pill,resources);pill.custom_minimum_size=Vector2(98,44);pill.size_flags_horizontal=Control.SIZE_EXPAND_FILL;host.money_label.add_theme_font_size_override("font_size",18)
	for value in [host.gem_label,host.reputation_label]:move(value.get_parent().get_parent(),statuses)
	for control in [host.debt_label,host.training_status,host.building_status]:move(control,statuses)
	for control in [host.clock_label,host.pause_button,host.bottom_ui.speed_entry]:move(control,resources)
	var primary_order=[pill,host.clock_label,host.pause_button,host.bottom_ui.speed_entry]
	for i in primary_order.size():resources.move_child(primary_order[i],i)
	host.bottom_ui.inventory_button.text=tr_name("物品");host.bottom_ui.inventory_button.custom_minimum_size.x=44;host.bottom_ui.inventory_button.add_theme_font_size_override("font_size",12)
	host.clock_label.custom_minimum_size.x=82;host.clock_label.add_theme_font_size_override("font_size",12)
	host.debt_label.custom_minimum_size.x=52
	for b in [host.training_status,host.building_status]:b.custom_minimum_size.x=44;b.add_theme_font_size_override("font_size",12)
	for control in [host.todo_anchor,host.bottom_ui.inventory_button,host.bottom_ui.summary_button]:move(control,actions)
	host.bottom_ui.summary_button.custom_minimum_size.x=64;host.bottom_ui.summary_button.add_theme_font_size_override("font_size",12)
	host.todo_anchor.size_flags_horizontal=Control.SIZE_EXPAND_FILL;host.todo_button.add_theme_font_size_override("font_size",14)
	host.todo_button.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	for name in host.navigation_buttons:
		var b=host.navigation_buttons[name];move(b,navigation);b.custom_minimum_size=Vector2(0,60);b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		for state in ["normal","hover","pressed","disabled"]:
			var skin=b.get_theme_stylebox(state).duplicate();skin.set_content_margin_all(3);b.add_theme_stylebox_override(state,skin)
	host.bottom_ui.first.hide();host.bottom_ui.narrow_row.hide();host._layout_controls.header.hide()
	host.bottom_ui.inventory_grid.columns=2;host.bottom_ui.inventory_box.custom_minimum_size.y=88
	host.map_view.custom_minimum_size=Vector2(120,140)
	glance.add_theme_font_size_override("font_size",12)
	for b in [host.pause_button,host.bottom_ui.speed_entry]:
		var skin=host.style(host.PAPER,6);skin.set_content_margin_all(4);b.add_theme_stylebox_override("normal",skin)
	if entering:host.map_view.house().focus_room("dining")
	chrome();refresh()
func move(control: Control,parent: Node):
	if control.get_parent()!=parent:control.reparent(parent)
func chrome():
	if not active:return
	hud.visible=not host.scene_focus;navigation.visible=true
	host.bottom_ui.first.hide();host.bottom_ui.narrow_row.hide()
func refresh():
	if not active:return
	var m=host.model;var english=host.localization!=null and host.localization.language=="en"
	var waiting=m.customers.filter(func(c):return str(c.stage)in ["ordering","recommending","queued","cooking","serving"]).size()
	glance.text=("Paused"if m.paused else"Open")if english else("已暂停"if m.paused else"营业中")
	glance.text+=(" · Waiting %d · Served %d"if english else" · 等待%d位 · 已接待%d位")%[waiting,int(m.state.served)]
	if host.scene_switcher!=null and host.scene_switcher.foreign():
		var r=m.full_rules.international;var data=r.region(host.scene_switcher.active());var shop=r.label(r.definition("regions",host.scene_switcher.active()).shop,english)
		glance.text=shop+(" · Guests%d · Paid%d"if english else" · 在店%d位 · 已结账%d单")%[data.floor.guests.filter(func(g):return g.stage!="cleaning").size(),data.served]
	var warning={}
	if host.action_notifications!=null:
		for entry in host.action_notifications.entries():
			if str(entry.id).begins_with("debt:")or str(entry.id).begins_with("staff:care:")or str(entry.id).begins_with("events:"):warning=entry;break
	if not warning.is_empty():glance.text=tr_name(str(warning.title));glance.add_theme_color_override("font_color",Color("b14e40"))
	elif Time.get_ticks_msec()<cash_deadline:glance.text=cash_message;glance.add_theme_color_override("font_color",cash_color)
	else:glance.add_theme_color_override("font_color",host.MUTED)
	host.bottom_ui.summary_button.text=tr_name("概览");host.bottom_ui.summary_button.icon=null;host.bottom_ui.summary_button.tooltip_text=tr_name("查看灵石、声望、负债与工作进度")
	host.bottom_ui.summary_button.set_meta("l10n_managed_text",true)
	for name in tab_labels:
		var b=host.navigation_buttons[name];b.text="";b.icon=null;b.tooltip_text="";tab_labels[name].box.show();tab_labels[name].label.text=tr_name(str(name))
func tr_name(value: String) -> String:return host.localization.translate(value)if host.localization!=null else value
func show_cash(description: String,amount: float):
	cash_message="%s %s￥%.2f"%[tr_name(description),"+"if amount>=0 else"−",absf(amount)];cash_color=host.GREEN if amount>=0 else Color("c25148");cash_deadline=Time.get_ticks_msec()+1800;refresh()
func fit_modal():
	if not active or host.modal_window.get_parent()!=host.overlay:return
	var placing=host.decoration_active()and not host.map_view.placement_id.is_empty()
	host.overlay.mouse_filter=Control.MOUSE_FILTER_IGNORE
	host.overlay.get_child(0).visible=not placing
	if placing:
		host.overlay.offset_left=4;host.overlay.offset_right=-4;host.overlay.offset_top=0;host.overlay.offset_bottom=0
		host.modal_window.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
		host.modal_window.offset_left=0;host.modal_window.offset_right=0;host.modal_window.offset_top=-270;host.modal_window.offset_bottom=-4
		return
	host.overlay.offset_left=4;host.overlay.offset_right=-4;host.overlay.offset_top=8;host.overlay.offset_bottom=-8
	var guide=host.tutorial_overlay
	var hide_guide=host.panel_name in ["欢迎","重新开始","破产救援","文化简介","美术资源","开发者选项","数值面板"]
	var reserve=guide.portrait_height()if guide!=null and guide.tutorial_card.visible and not hide_guide else 0.0
	host.overlay.offset_bottom=-maxf(8,reserve+8)
	host.modal_window.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	host.modal_window.offset_left=0;host.modal_window.offset_right=0;host.modal_window.offset_top=0;host.modal_window.offset_bottom=0
	var skin=host.style();skin.set_content_margin_all(10);host.modal_window.add_theme_stylebox_override("panel",skin)
	var header=host.modal_window.get_child(0).get_node("Header")
	for c in header.get_children():
		if c is Button:
			c.add_theme_font_size_override("font_size",14)
			for state in ["normal","hover","pressed","disabled"]:
				var b=c.get_theme_stylebox(state).duplicate();b.set_content_margin_all(6);c.add_theme_stylebox_override(state,b)
		elif c is Label:c.add_theme_font_size_override("font_size",20)
func adapt_content():
	if not active or _adapting:return
	_adapting=true;_adapt(host.modal_body,maxf(160,host._layout_size.x-42));_adapting=false
func _adapt(node: Node,width: float):
	if not is_instance_valid(node):return
	if node is Control:
		if node.custom_minimum_size.x>width:node.custom_minimum_size.x=width
		if node is Label:
			node.custom_minimum_size.x=0;node.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;node.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		if node is Button:
			var minimum=52 if bool(node.get_meta("compact_local_navigation",false))else 96
			node.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;node.custom_minimum_size.x=minf(width,maxf(minimum,node.custom_minimum_size.x));node.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		if node is GridContainer:node.columns=mini(int(node.get_meta("phone_columns",1)),2)if width>=280 else 1
	for child in node.get_children():_adapt(child,width-20 if node is PanelContainer else width)
	if node is HBoxContainer and node!=host.modal_body:
		var minimum=node.get_combined_minimum_size().x
		if minimum>width or (node.get_child_count()>1 and node.get_children().any(func(c):return c is TextureRect or c.get_script()==preload("res://scripts/ui/portrait_frame.gd"))):
			var parent=node.get_parent();var place=node.get_index();var replacement: Container
			if node.get_children().all(func(c):return c is BaseButton):replacement=HFlowContainer.new()
			else:replacement=VBoxContainer.new()
			replacement.name="PortraitStack";replacement.size_flags_horizontal=Control.SIZE_EXPAND_FILL;replacement.add_theme_constant_override("separation",8);parent.add_child(replacement);parent.move_child(replacement,place)
			for child in node.get_children():child.reparent(replacement)
			node.hide();node.queue_free()
func snapshot() -> Dictionary:
	var status={}
	for entry in [["clock",host.clock_label],["debt",host.debt_label],["training",host.training_status],["building",host.building_status],["summary",host.bottom_ui.summary_button]]:
		status[entry[0]]={"visible":entry[1].is_visible_in_tree(),"rect":rect(entry[1])}
	return {"active":active,"hud":rect(hud),"navigation":rect(navigation),"body_width":host.modal_body.size.x,"status_controls":status}
func rect(control: Control) -> Dictionary:
	var r=control.get_global_rect();return {"x":r.position.x,"y":r.position.y,"w":r.size.x,"h":r.size.y}
