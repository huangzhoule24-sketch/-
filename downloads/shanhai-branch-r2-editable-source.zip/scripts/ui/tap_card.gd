extends PanelContainer
## A card activates on a completed tap, never on the start of a scroll.
signal activated
var armed=false
var origin=Vector2.ZERO
func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
		if event.pressed:
			armed=true;origin=event.global_position
		else:
			var tapped=armed and event.global_position.distance_to(origin)<8 and Rect2(Vector2.ZERO,size).has_point(event.position)
			armed=false
			if tapped:accept_event();activated.emit()
	elif event is InputEventMouseMotion and armed and event.global_position.distance_to(origin)>=8:
		armed=false
func _notification(what: int) -> void:
	if what==NOTIFICATION_SCROLL_BEGIN or what==NOTIFICATION_VISIBILITY_CHANGED:armed=false
