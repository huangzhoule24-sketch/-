extends RefCounted
## Read-only UI aggregation. Existing panels keep all mutations and stage gates.
var host
var values={}
func _init(ui):host=ui
func translated(text: String) -> String:return host.localization.translate(text)if host.localization!=null else text
func metric(parent: Node,key: String,title: String):
	var panel=host.card();panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL;parent.add_child(panel)
	var body=host.column(4);panel.add_child(body);body.add_child(host.label(title,14,host.MUTED))
	var value=host.label("",20);value.set_meta("overview_metric",key);value.set_meta("l10n_managed_text",true);body.add_child(value);values[key]=weakref(value)
func link(parent: Node,title: String,destination: String):
	var button=host.button(title,func():host.open_panel(destination),false,"full:open:"+destination)
	button.disabled=not host.Guide.allows_panel(host.model,destination)or host.Policy.minimum_stage(destination)>int(host.model.state.stage)
	if button.disabled:button.tooltip_text="完成当前教学或经营阶段后可查看"
	parent.add_child(button)
func render():
	values.clear();host.paragraph("店内资源、负债与进行中的工作",host.MUTED)
	var grid=GridContainer.new();grid.columns=2;grid.set_meta("phone_columns",2);grid.add_theme_constant_override("h_separation",8);grid.add_theme_constant_override("v_separation",8);grid.size_flags_horizontal=Control.SIZE_EXPAND_FILL;host.modal_body.add_child(grid)
	for pair in [["cash","可用现金"],["gems","灵石"],["reputation","声望"],["ingredients","食材库存"]]:metric(grid,pair[0],pair[1])
	var alerts=[]
	if host.action_notifications!=null:
		for entry in host.action_notifications.entries():
			if str(entry.id).begins_with("debt:")or str(entry.id).begins_with("staff:care:")or str(entry.id).begins_with("events:"):alerts.append(entry)
	if not alerts.is_empty():
		var attention=host.full_panels._body("需要留意")
		for entry in alerts.slice(0,3):link(attention,str(entry.title),str(entry.destination))
	var finance=host.full_panels._body("本金负债")
	var debt=host.label("",20);debt.set_meta("l10n_managed_text",true);debt.set_meta("overview_metric","debt");finance.add_child(debt);values.debt=weakref(debt)
	host.full_panels._text(finance,"本金、利息和待付费用可在账单中分别查看。")
	link(finance,"查看账单","账单")
	var jobs=host.full_panels._body("工作进度")
	for pair in [["training","培训与研发"],["building","施工"]]:
		var line=host.label("",16);line.set_meta("l10n_managed_text",true);line.set_meta("overview_metric",pair[0]);jobs.add_child(line);values[pair[0]]=weakref(line)
	link(jobs,"查看人员与后厨状态","经营状态")
	var shortcuts=host.full_panels._flow(host.modal_body)
	link(shortcuts,"查看物品","物品栏");link(shortcuts,"系统与存档","系统")
	refresh()
func refresh():
	if host.panel_name!="经营概览":return
	var m=host.model
	var training=m.employees.filter(func(e):return int(e.get("management_until",0))>int(m.state.total_minutes)).size()
	var builds=m.state.revision171.builds.size()
	var data={"cash":"￥%.2f"%float(m.state.cash),"gems":str(int(m.state.gems)),"reputation":str(int(m.state.reputation)),"ingredients":"%.1f"%float(m.state.ingredients),"debt":"￥%.2f"%(float(m.state.debt)+float(m.state.finance.loan.principal)+float(m.state.rescue171.loan.get("principal",0))),"training":translated("培训与研发")+" · "+str(training),"building":translated("施工")+" · "+str(builds)}
	for key in values:
		var node=values[key].get_ref()
		if is_instance_valid(node):node.text=str(data[key])
func snapshot() -> Dictionary:
	var result={}
	if host.panel_name!="经营概览":return result
	for key in values:
		var node=values[key].get_ref()
		if is_instance_valid(node):result[key]={"text":node.text,"visible":node.is_visible_in_tree(),"rect":host.phone_ui.rect(node)}
	return result
