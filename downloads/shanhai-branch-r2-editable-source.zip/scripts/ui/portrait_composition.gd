extends RefCounted
## Stable upper-body composition. Never infer a head from the width of shoulders/wings.
const UPPER_BODY = Rect2(.20, 0.0, .60, .66)

static func region(texture: Texture2D, aspect: float, whole_image: bool = false) -> Rect2:
	var extent = texture.get_size()
	if whole_image or aspect <= 0.0: return Rect2(Vector2.ZERO, extent)
	var focus = Rect2(UPPER_BODY.position * extent, UPPER_BODY.size * extent)
	var crop_size = Vector2(maxf(focus.size.x, focus.size.y * aspect), focus.size.y)
	crop_size.y = crop_size.x / aspect
	# Very narrow/wide layouts show the complete image rather than cutting the subject.
	if crop_size.x > extent.x or crop_size.y > extent.y: return Rect2(Vector2.ZERO, extent)
	var origin = Vector2(clampf(focus.get_center().x - crop_size.x * .5, 0, extent.x - crop_size.x), 0)
	return Rect2(origin, crop_size)

static func destination(window: Rect2, source_size: Vector2) -> Rect2:
	var scale = minf(window.size.x / source_size.x, window.size.y / source_size.y)
	var fitted = source_size * scale
	return Rect2(window.position + (window.size - fitted) * .5, fitted)

static func pixel_region(texture: Texture2D) -> Rect2:
	# Locate the complete figure in its actual frame, including raised heads and head ornaments.
	# The old fixed 48x42 cut-out could contain only feet for small/flying characters.
	var image = texture.get_image()
	var full = Rect2i(Vector2i.ZERO, Vector2i(texture.get_size()))
	if image == null: return Rect2(full)
	var used = image.get_used_rect()
	return Rect2(full if not used.has_area() else used.grow(1).intersection(full))

static func cropped_texture(texture: Texture2D, source: Rect2) -> AtlasTexture:
	var result = AtlasTexture.new()
	# Flatten the atlas reference so the region is not applied twice to a sprite-sheet frame.
	result.atlas = texture.atlas if texture is AtlasTexture else texture
	result.region = Rect2(texture.region.position + source.position, source.size) if texture is AtlasTexture else source
	result.filter_clip = true
	return result
