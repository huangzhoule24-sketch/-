extends Control
## A view of the authoritative local floor. This renderer never advances simulation.
const Art=preload("res://scripts/services/international_art.gd")
const Floor=preload("res://scripts/core/international_floor.gd")
const Visual=preload("res://scripts/services/visual_refinement.gd")
var ui
var rid="india"
var inside=true
var preview=""
var camera: Dictionary={"zoom":1.0,"pan":Vector2.ZERO}
var touches={}
var dragging=false
var touch_used=false
var _elapsed=0.0
var _last_view=""
var _render_count=0
var primary=false
var crowd=preload("res://scripts/ui/crowd_presentation.gd").new()
var press=Vector2.ZERO
var moved=false
var placement_uid=""
var placement_point=Vector2.ZERO
var placement_valid=false
var _last_clock=-1.0
var _initial_focus=false
func setup(owner_ui,region_id: String,interior=true,as_primary=false):
 ui=owner_ui;rid=region_id;inside=interior;primary=as_primary
 var key=("world:"if primary else"")+rid;_initial_focus=primary and ui.host.portrait_layout and not ui.cameras.has(key)
 camera=ui.cameras.get(key,{"zoom":1.0,"pan":Vector2.ZERO});ui.cameras[key]=camera
 var key_material=ShaderMaterial.new();var shader_code=Shader.new()
 shader_code.code="shader_type canvas_item; void fragment(){ vec4 c=COLOR; if(abs(TEXTURE_PIXEL_SIZE.x-1.0/1536.0)<0.000001 && abs(TEXTURE_PIXEL_SIZE.y-1.0/1024.0)<0.000001 && c.r>0.65 && c.b>0.65 && c.g<0.25){c.a=0.0;} COLOR=c;}"
 key_material.shader=shader_code;material=key_material
 custom_minimum_size=Vector2(0,310);size_flags_horizontal=Control.SIZE_EXPAND_FILL;clip_contents=true;mouse_filter=Control.MOUSE_FILTER_STOP;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
func fit():camera.zoom=1.0;camera.pan=Vector2.ZERO;cancel_gesture();queue_redraw()
func cancel_gesture():touches.clear();dragging=false
func _notification(what):
 if what in[NOTIFICATION_APPLICATION_FOCUS_OUT,NOTIFICATION_EXIT_TREE,NOTIFICATION_RESIZED]:cancel_gesture()
 if what==NOTIFICATION_VISIBILITY_CHANGED and not is_visible_in_tree():cancel_gesture()
func clock() -> float:return float(ui.rules().now())+float(ui.host.model._fraction)
func _process(delta):
 if ui==null:return
 if _initial_focus and size.x>0 and size.y>0:_initial_focus=false;focus_zone("dining")
 _elapsed+=delta
 var signature=str([camera.zoom,camera.pan,size,inside,preview,placement_uid,ui.host.model.paused,Visual.reduced(ui.host.model),ui.rules().region(rid).jobs.size(),ui.rules().region(rid).orders.size()])
 if signature!=_last_view or(not ui.host.model.paused and _elapsed>=(1.0/12 if Visual.reduced(ui.host.model)else 1.0/30)):
  _last_view=signature;_elapsed=0;queue_redraw()
func zoom_at(factor: float,anchor: Vector2):
 var old_extent=maxf(.001,base_scale()*float(camera.zoom));var unit=(anchor-size*.5-Vector2(camera.pan))/old_extent
 camera.zoom=clampf(float(camera.zoom)*factor,.65,2.8)
 camera.pan=anchor-size*.5-unit*base_scale()*float(camera.zoom);queue_redraw()
func _touch(event):
 touch_used=true
 if event is InputEventScreenTouch:
  if event.pressed:
   if touches.is_empty():press=event.position;moved=false
   else:moved=true
   if touches.size()<2:touches[event.index]=event.position
  else:
   if touches.size()==1 and not moved and not event.canceled:_pick(event.position)
   touches.erase(event.index)
 elif event is InputEventScreenDrag and touches.has(event.index):
  if event.position.distance_to(press)>8:moved=true
  if touches.size()==2:
   var old=touches.values();var distance=Vector2(old[0]).distance_to(old[1]);var centre=(Vector2(old[0])+Vector2(old[1]))*.5
   touches[event.index]=event.position;var next=touches.values();var new_centre=(Vector2(next[0])+Vector2(next[1]))*.5
   camera.pan+=new_centre-centre
   if distance>1:zoom_at(Vector2(next[0]).distance_to(next[1])/distance,new_centre)
  else:camera.pan+=event.position-Vector2(touches[event.index]);touches[event.index]=event.position
 queue_redraw()
func _input(event):
 if not is_visible_in_tree():return
 if(event is InputEventScreenDrag or event is InputEventScreenTouch)and touches.has(event.index):
  _touch(event.xformed_by(get_global_transform_with_canvas().affine_inverse()));get_viewport().set_input_as_handled()
 elif event is InputEventMouseMotion and dragging:
  if event.device==-1 and touch_used:return
  if event.position.distance_to(get_global_transform_with_canvas()*press)>8:moved=true
  camera.pan+=event.relative;queue_redraw();get_viewport().set_input_as_handled()
 elif event is InputEventMouseButton and not event.pressed and event.button_index==MOUSE_BUTTON_LEFT and dragging:
  dragging=false
  if not moved:_pick(get_global_transform_with_canvas().affine_inverse()*event.position)
  get_viewport().set_input_as_handled()
func _gui_input(event):
 if event is InputEventScreenTouch or event is InputEventScreenDrag:_touch(event);accept_event()
 elif event is InputEventMouseButton:
  if event.device==-1 and touch_used:return
  if event.button_index in[MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]and event.pressed:zoom_at(1.12 if event.button_index==MOUSE_BUTTON_WHEEL_UP else 1/1.12,event.position);accept_event()
  elif event.button_index==MOUSE_BUTTON_LEFT:
   if event.pressed:dragging=true;press=event.position;moved=false
   accept_event()
func base_scale() -> float:return maxf(.001,minf(size.x/Floor.WORLD.x,size.y/Floor.WORLD.y))
func scale_factor() -> float:return base_scale()*float(camera.zoom)
func offset() -> Vector2:return (size-Floor.WORLD*scale_factor())*.5+Vector2(camera.pan)
func to_view(p: Vector2) -> Vector2:return offset()+p*scale_factor()
func to_world(p: Vector2) -> Vector2:return (p-offset())/scale_factor()
func focus_zone(zone: String):
 camera.zoom=clampf(maxf(1.0,size.y/(Floor.WORLD.y*base_scale())*.85),1,2.8)
 var target=Vector2(330,310)if zone=="dining"else Vector2(850,270)if zone=="kitchen"else Vector2(560,530)
 camera.pan=(Floor.WORLD*.5-target)*scale_factor();cancel_gesture();queue_redraw()
func _pick(p: Vector2):
 if not primary or not inside:return
 var at=to_world(p);var manager=ui.host.scene_switcher
 if not placement_uid.is_empty():
  placement_point=Vector2(snappedf(at.x,20),snappedf(at.y,20));placement_valid=ui.rules().floor.can_move(rid,placement_uid,placement_point.x,placement_point.y);queue_redraw();manager.update_placement();return
 for worker in ui.rules().floor.worker_snapshot(rid,clock()):
  if Rect2(worker.position-Vector2(32,78),Vector2(64,85)).has_point(at):manager.manage("伙伴");return
 for g in ui.rules().floor.state(rid).guests:
  var foot=ui.rules().floor.guest_pose(rid,g,clock()).point
  if g.stage!="cleaning"and Rect2(foot-Vector2(32,78),Vector2(64,85)).has_point(at):manager.manage("店铺");return
 for item in ui.rules().floor.fixtures(rid):
  if Floor.fixture_rect(item).grow(18).has_point(at):manager.manage("菜单"if item.kind in["stove","prep","pass"]else"店铺");return
func actor_pose(index: int,minute: float,_layout: String) -> Dictionary:
 var workers=ui.rules().floor.worker_snapshot(rid,minute)
 if workers.is_empty():return {"point":Vector2.ZERO,"frame":0}
 var w=workers[index%workers.size()];return {"point":w.position/Floor.WORLD,"frame":int(minute*2)%3}
static func table_positions(_region_id: String,layout: String) -> Array:
 return Floor.default_fixtures(layout).filter(func(f):return f.kind=="table").map(func(f):return Floor.centre(f)/Floor.WORLD)
func _direction(motion: Dictionary,minute: float,fallback="down") -> String:
 if motion.is_empty()or Floor.arrived(motion,minute):return fallback
 var d=Floor.position(motion,minute+.04)-Floor.position(motion,minute)
 return("right"if d.x>0 else"left")if absf(d.x)>absf(d.y)else("down"if d.y>0 else"up")
func _texture_at(image: Texture2D,foot: Vector2,dimensions: Vector2,anchor=Vector2(.5,1)):
 if image!=null:draw_texture_rect(image,Rect2(to_view(foot)-dimensions*anchor*scale_factor(),dimensions*scale_factor()),false)
func _actor(id: String,frame: int,foot: Vector2,height: float):
 var image=Art.walking(id,frame);var entry=Art.definition("characters",id);var geometry=Visual.walking(rid,int(entry.column),frame)
 if image==null:return
 if geometry.is_empty():_texture_at(image,foot,Vector2.ONE*height);return
 var b=geometry.bounds;draw_texture_rect_region(image,Visual.sprite_rect(to_view(foot),height*scale_factor(),geometry),Rect2(b[0],b[1],b[2]-b[0],b[3]-b[1]))
func _human(index: int,action: String,direction: String,foot: Vector2,minute: float):
 var frames=ui.host.assets.get_customer_frames("human","human_%02d"%(posmod(index,3)+1),action,direction)
 if not frames.is_empty():_texture_at(frames[int(minute*2)%frames.size()],foot,Vector2(64,80),Vector2(32,61 if action in["sit","eat"]else 77)/Vector2(64,80))
func _caption(foot: Vector2,title: String,color=Color("29483f")):
 var font=ui.host.get_theme_default_font();var sz=12;var width=font.get_string_size(title,HORIZONTAL_ALIGNMENT_LEFT,-1,sz).x
 var at=to_view(foot);var rect=Rect2(at+Vector2(-width*.5-4,2),Vector2(width+8,19))
 draw_rect(rect,Color(.99,.98,.91,.91));draw_string(font,rect.position+Vector2(4,14),title,HORIZONTAL_ALIGNMENT_LEFT,-1,sz,color)
func _draw_worker(w: Dictionary,minute: float):
 var foot=crowd.point("w:"+str(w.id),w.position);var direction=_direction(w.motion,minute,str(w.get("look","down")));var walking=not w.motion.is_empty()and not Floor.arrived(w.motion,minute)
 draw_ellipse_shadow(to_view(foot),15*scale_factor())
 if str(w.id).begins_with("helper:"):_human(["chef","host","cashier","builder"].find(str(w.role)),"walk"if walking else"idle",direction,foot,minute)
 else:_actor(str(w.id),([0,1,2,1][int(minute*2)%4]if walking else 0)+(3 if direction in["up","left"]else 0),foot,82)
 var job={}
 for candidate in ui.rules().region(rid).jobs:
  if int(candidate.id)==int(w.job):job=candidate;break
 if not job.is_empty():
  if job.kind=="service":_texture_at(Art.dish(str(job.dish_id)),foot+Vector2(22,-35),Vector2(38,30))
  if str(job.phase)=="working":
   var at=to_view(foot+Vector2(0,-85));var fraction=clampf(1-(float(job.due)-minute)/maxf(1,float(job.work_minutes)),0,1)
   draw_rect(Rect2(at-Vector2(20,0),Vector2(40,5)),Color("584936"));draw_rect(Rect2(at-Vector2(19,-1),Vector2(38*fraction,3)),Color("6eac77"))
 var roles={"chef":["后厨","Kitchen"],"host":["前厅","Service"],"cashier":["收银","Cashier"],"builder":["改装","Build"]}
 var action={"Cook":["备餐","Cooking"],"Order":["点单","Order"],"Cashier":["结账","Payment"],"Clean":["清台","Clean"],"Train":["培训","Training"],"Promote":["宣传","Promote"],"Build":["改装","Build"],"Serve":["送餐","Serving"]}
 var title=ui.t(roles[w.role][0],roles[w.role][1])if str(w.id).begins_with("helper:")else ui.name_of(Art.definition("characters",str(w.id)).name)
 if action.has(str(w.action)):title+=" · "+ui.t(action[w.action][0],action[w.action][1])
 _caption(foot,title)
func _fixture(item: Dictionary):
 var p=Floor.centre(item);var image: Texture2D;var dimensions: Vector2
 if item.kind=="table":
  var atlas=Art._texture("res://assets/art/BranchFloors/tables.png");var cell=Vector2(atlas.get_width()/2.0,atlas.get_height()/3.0)
  image=Art._region(atlas,Rect2(Vector2(1 if item.get("shared",false)else 0,["india","nordic","greece"].find(rid))*cell,cell));dimensions=Vector2(240,160)if item.get("shared",false)else Vector2(240,160)
 elif item.kind=="storage":image=Art.furniture(rid,3 if rid=="nordic"else 4);dimensions=Vector2(115,115)
 else:
  var index=["stove","prep","pass","cashier"].find(str(item.kind));var atlas=load("res://assets/art/BranchFloors/stations.png")
  image=Art._region(atlas,Rect2(Vector2(index,["india","nordic","greece"].find(rid))*Vector2(atlas.get_width()/4.0,atlas.get_height()/3.0),Vector2(atlas.get_width()/4.0,atlas.get_height()/3.0)))
  dimensions=Vector2(132,132*image.get_height()/image.get_width())
 _texture_at(image,p+Vector2(0,38 if item.kind=="table"else 0),dimensions)
 if item.kind in["stove","prep"]and not Visual.reduced(ui.host.model):
  for job in ui.rules().region(rid).jobs:
   if str(job.get("station",""))!=str(item.uid)or str(job.get("phase",""))!="working":continue
   for i in range(3):
    var phase=fposmod(clock()*.12+i*.33,1);draw_circle(to_view(p+Vector2((i-1)*12,-85-phase*28)),(3+phase*3)*scale_factor(),Color(.97,.94,.83,.5*(1-phase)))
func _shared_tabletop(item: Dictionary):
 var cfg=Floor.seating_config();var c=cfg.regions[rid].shared_tabletop;var crop=Rect2(c[0],c[1],c[2],c[3]);var atlas=Art._texture("res://assets/art/BranchFloors/tables.png");var cell=Vector2(atlas.get_width()/2.0,atlas.get_height()/3.0)
 var image=Art._region(atlas,Rect2(Vector2(cell.x,cell.y*["india","nordic","greece"].find(rid))+crop.position,crop.size));var ratio=Vector2(240,160)/cell
 var origin=Floor.centre(item)+Vector2(-120,-122)+crop.position*ratio
 draw_texture_rect(image,Rect2(to_view(origin),crop.size*ratio*scale_factor()),false)
func _draw():
 _render_count+=1;draw_rect(Rect2(Vector2.ZERO,size),Color("e8e3d3"))
 if ui==null:return
 if not inside:
  var exterior=Art.store(rid,false)
  if exterior!=null:
   var extent=minf(size.x,size.y)*float(camera.zoom);draw_texture_rect(exterior,Rect2((size-Vector2.ONE*extent)*.5+Vector2(camera.pan),Vector2.ONE*extent),false)
  return
 var image=Art._texture("res://assets/art/BranchFloors/"+rid+".png");draw_texture_rect(image,Rect2(offset(),Floor.WORLD*scale_factor()),false)
 var rules=ui.rules();var data=rules.region(rid);var items=Floor.default_fixtures(preview)if not preview.is_empty()else rules.floor.fixtures(rid);var minute=clock();var entities=[];var spacing=[]
 for index in range(items.size()):
  entities.append({"kind":"fixture","point":Floor.centre(items[index])-Vector2(0,180 if items[index].kind=="table"else 0),"data":items[index],"serial":index})
  if items[index].kind=="table"and items[index].get("shared",false):entities.append({"kind":"tabletop","point":Floor.centre(items[index])-Vector2(0,30),"data":items[index],"serial":50+index})
 if bool(data.open)and preview.is_empty():
  for w in rules.floor.worker_snapshot(rid,minute):
   var pinned=w.motion.is_empty()or Floor.arrived(w.motion,minute);spacing.append({"key":"w:"+str(w.id),"point":w.position,"pinned":pinned,"radius":38.0});entities.append({"kind":"worker","point":w.position,"data":w,"serial":100+entities.size()})
  for g in rules.floor.state(rid).guests:
   if g.stage=="cleaning":continue
   var foot=rules.floor.guest_pose(rid,g,minute).point
   spacing.append({"key":"g:"+str(g.id),"point":foot,"pinned":str(g.stage)in["ordering","waiting","serving","eating","paying"],"radius":38.0});entities.append({"kind":"guest","point":foot,"data":g,"serial":200+int(g.id)})
 var dt=maxf(0,minute-_last_clock)if _last_clock>=0 else 1.0;_last_clock=minute;crowd.update_in_space(spacing,dt,Floor.BOUNDS,Floor.obstacles(items))
 entities.sort_custom(func(a,b):return a.point.y<b.point.y if not is_equal_approx(a.point.y,b.point.y)else a.serial<b.serial)
 for entity in entities:
  match entity.kind:
   "fixture":_fixture(entity.data)
   "tabletop":_shared_tabletop(entity.data)
   "worker":_draw_worker(entity.data,minute)
   "guest":
    var g=entity.data;var seat=rules.floor.seat_info(rid,int(g.seat));var pose=rules.floor.guest_pose(rid,g,minute);var seated=bool(pose.seated);var foot=pose.point if seated else crowd.point("g:"+str(g.id),entity.point)
    var direction=str(seat.get("direction","down"))if seated else _direction(g.motion,minute,"up")
    draw_ellipse_shadow(to_view(foot),13*scale_factor());_human(int(g.id),str(pose.action),direction,foot,minute)
    if g.stage=="eating":
     var order=rules.order(rid,int(g.id))
     if not order.is_empty():_texture_at(Art.dish(str(order.dish_id)),Floor.centre(rules.floor.by_uid(rid,str(g.table)))+Vector2(-14 if seat.direction in["right","down"]else 14,-35),Vector2(28,24))
    if g.stage in["ordering","waiting","paying"]:_caption(foot-Vector2(0,75)if seated else foot,ui.t("点单"if g.stage=="ordering"else"候餐"if g.stage=="waiting"else"结账","Order"if g.stage=="ordering"else"Waiting"if g.stage=="waiting"else"Pay"))
 if not placement_uid.is_empty():
  var current=rules.floor.by_uid(rid,placement_uid).duplicate();current.x=placement_point.x;current.y=placement_point.y
  draw_rect(Rect2(to_view(Floor.fixture_rect(current).position),Floor.fixture_rect(current).size*scale_factor()),Color(.2,.7,.4,.35)if placement_valid else Color(.9,.2,.15,.4));_fixture(current)
func draw_ellipse_shadow(at: Vector2,radius: float):
 draw_set_transform(at,0,Vector2(1,.32));draw_circle(Vector2.ZERO,radius,Color(0,0,0,.17));draw_set_transform(Vector2.ZERO)
