extends Button
## Portraits are independent of tiny gameplay sprites and lore illustrations.
var assets
var localization
var _last_language=""
var model_ref: WeakRef
var _elapsed=0.0
var character_id=""
var tutorial=false
var rarity="N"
var status=""
var compact=false
var caption=""
var full_body=false
const Composition = preload("res://scripts/ui/portrait_composition.gd")
func _ready():
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	if assets!=null:assets.changed.connect(queue_redraw)
	add_theme_stylebox_override("normal",StyleBoxEmpty.new());add_theme_stylebox_override("hover",StyleBoxEmpty.new());add_theme_stylebox_override("pressed",StyleBoxEmpty.new());add_theme_stylebox_override("focus",StyleBoxEmpty.new())
func _process(delta):
	if localization!=null and _last_language!=localization.language:
		_last_language=localization.language;queue_redraw()
	_elapsed+=delta
	if _elapsed<.25 or model_ref==null:return
	_elapsed=0;var model=model_ref.get_ref()
	if model==null:return
	var employee=model._employee(character_id)
	if employee.is_empty():return
	var label=model.full_rules.revision.status(employee)
	var next="训" if "培训" in label else "建" if "装修" in label else "疲" if "疲" in label else "休" if "休" in label else "班"
	if status!=next:status=next;queue_redraw()
func _draw():
	var rarity_color=preload("res://scripts/ui/rarity_display.gd").color_for(rarity)
	var rect=Rect2(Vector2(2,2),size-Vector2(4,4));var style=StyleBoxFlat.new();style.bg_color=Color("e0e1dc");style.border_color=rarity_color;style.set_border_width_all(3);style.set_corner_radius_all(8);draw_style_box(style,rect)
	var image=assets.get_portrait(character_id,tutorial) if assets!=null else null
	if image!=null and not assets.is_placeholder(image):
		if tutorial or full_body:
			var extent=image.get_size();var scale=minf((size.x-12)/extent.x,(size.y-12)/extent.y);draw_texture_rect(image,Rect2((size-extent*scale)/2,extent*scale),false)
		else:
			var window = Rect2(size*Vector2(.10,.10),size*Vector2(.80,.80)) if assets.has_image("UI/frame_portrait") else rect.grow(-5)
			var source = head_crop(image,window.size.x/window.size.y)
			draw_texture_rect_region(image,Composition.destination(window,source.size),source)
	else:
		var center=size*Vector2(.5,.37);draw_circle(center,minf(size.x*.15,22),Color("b6bab4"));draw_style_box(_silhouette(),Rect2(size*Vector2(.25,.52),size*Vector2(.5,.25)))
		if size.x>=100:draw_string(get_theme_default_font(),Vector2(8,size.y-12),("Portrait pending" if localization!=null and localization.language=="en" else "立绘待补充"),HORIZONTAL_ALIGNMENT_CENTER,size.x-16,12,Color("68736c"))
	if not tutorial and not full_body and assets!=null and assets.has_image("UI/frame_portrait"):draw_texture_rect(assets.get_texture("UI/frame_portrait"),rect,false)
	if rarity=="SSR":draw_string(get_theme_default_font(),Vector2(7,19),"★",HORIZONTAL_ALIGNMENT_LEFT,-1,17,rarity_color)
	if not status.is_empty():
		var caption=str({"训":"TR","建":"BLD","疲":"LOW","休":"RST","班":"ON"}.get(status,status)) if localization!=null and localization.language=="en" else status
		var stamp=Rect2(size.x-31,3,28,20);draw_style_box(_stamp(),stamp);draw_string(get_theme_default_font(),Vector2(stamp.position.x+2,18),caption,HORIZONTAL_ALIGNMENT_CENTER,24,10,Color("fff9ed"))
func _silhouette() -> StyleBoxFlat:
	var box=StyleBoxFlat.new();box.bg_color=Color("b6bab4");box.set_corner_radius_all(12);return box
func _stamp() -> StyleBoxFlat:
	var box=StyleBoxFlat.new();box.bg_color=Color("708c7c");box.set_corner_radius_all(3);return box
static func add_to(host,parent: Node,employee: Dictionary,small: bool=false):
	var Frame=load("res://scripts/ui/portrait_frame.gd");var frame=Frame.new();frame.assets=host.assets;frame.localization=host.localization;frame.character_id=str(employee.id);frame.rarity=str(employee.get("rarity","N"));frame.compact=small;frame.model_ref=weakref(host.model)
	var status=host.revision_ui.rules().status(employee) if employee.has("level") else "当班"
	frame.status="训" if "培训" in status else "建" if "装修" in status else "疲" if "疲" in status else "休" if "休" in status else "班"
	frame.custom_minimum_size=Vector2(88,96) if small else Vector2(168,184);frame.size_flags_horizontal=Control.SIZE_SHRINK_CENTER
	frame.set_meta("qa_id","employee:portrait:"+str(employee.id));frame.tooltip_text=str(employee.name)+" · 点击查看立绘"
	frame.pressed.connect(func():show_large(host,employee));parent.add_child(frame)
	if "_qa_buttons" in host:host._qa_buttons.append(frame)
	return frame
static func show_large(host,employee: Dictionary):
	var dialog=PopupPanel.new();dialog.name="EmployeePortrait";host.add_child(dialog);dialog.popup_hide.connect(dialog.queue_free)
	var image = TextureRect.new()
	image.texture = host.assets.get_portrait(str(employee.id))
	image.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	image.custom_minimum_size = Vector2(minf(520,host.get_viewport_rect().size.x*.8),minf(600,host.get_viewport_rect().size.y*.8))
	image.set_meta("qa_id","employee:portrait-close")
	dialog.add_child(image)
	image.gui_input.connect(func(event):
		if event is InputEventMouseButton and event.pressed: dialog.hide())
	if host.assets.is_placeholder(image.texture):
		image.texture = null
		var missing = Label.new();missing.text = "立绘待补充";missing.mouse_filter=Control.MOUSE_FILTER_IGNORE;image.add_child(missing)
	dialog.add_theme_stylebox_override("panel",StyleBoxEmpty.new())
	dialog.popup_centered_clamped(Vector2i(560,660),.9)

func head_crop(texture: Texture2D, aspect: float) -> Rect2:
	# Imported portraits may already be busts or place the head elsewhere. Contain them whole.
	var custom = assets != null and not str(assets.get_resource_info("Portraits/"+character_id).get("custom_path","")).is_empty()
	return Composition.region(texture,aspect,custom)
