extends RefCounted
## Local visual lanes only. Seats and working hands stay at real interaction points.
## This observer never writes orders, motion paths, saves, equipment locks or RNG.
const Space = preload("res://scripts/services/restaurant_space.gd")
const Geometry = preload("res://scripts/services/grid_navigation.gd")
var offsets: Dictionary = {}
var positions: Dictionary = {}
var pinned_conflicts = 0

static func overlaps(a: Vector2, b: Vector2) -> bool:
	return Vector2((a.x-b.x)/38.0, (a.y-b.y)/50.0).length_squared() < .999

func is_free(point: Vector2, occupied: Array[Vector2]) -> bool:
	for other in occupied:
		if overlaps(point, other): return false
	return true

func update(model, entries: Array, delta: float) -> void:
	var walls = Space.obstacles(model)
	var bounds = Space.walk_bounds(model)
	update_in_space(entries,delta,bounds,walls)

func update_in_space(entries: Array,delta: float,bounds: Rect2,walls: Array) -> void:
	var occupied: Array[Vector2] = []
	var present: Dictionary = {}
	positions.clear(); pinned_conflicts = 0
	# Reserve actual diners and actual working positions first, regardless of draw order.
	for entry in entries:
		var key = str(entry.key); present[key] = true
		if not bool(entry.pinned): continue
		var point: Vector2 = entry.point
		if not is_free(point, occupied): pinned_conflicts += 1
		positions[key] = point; offsets[key] = Vector2.ZERO; occupied.append(point)
	entries.sort_custom(func(a,b): return str(a.key) < str(b.key))
	for entry in entries:
		if bool(entry.pinned): continue
		var key = str(entry.key); var base: Vector2 = entry.point
		var old: Vector2 = offsets.get(key, Vector2.ZERO)
		var radius = float(entry.get("radius",53.0))
		var chosen = old
		# Keep an existing lane until it is clear to merge, avoiding left/right oscillation.
		var candidates: Array[Vector2] = [Vector2.ZERO, old]
		if old.length() > 1: candidates = [old, Vector2.ZERO]
		candidates.append_array([Vector2(-40,0), Vector2(40,0), Vector2(0,52), Vector2(0,-52), Vector2(-34,36), Vector2(34,36), Vector2(-34,-36), Vector2(34,-36)])
		var found = false
		for offset in candidates:
			offset = offset.limit_length(radius)
			var point: Vector2 = base + offset
			if not bounds.has_point(point) or not Geometry.point_is_clear(point,walls): continue
			if not Geometry.segment_is_clear(base,point,walls): continue
			if is_free(point,occupied): chosen = offset; found = true; break
		# Recover toward the path when the original lane is clear; never move an actor
		# through a fixture just to make a crowded screenshot look empty.
		if found and is_free(base,occupied): chosen = Vector2.ZERO
		var next: Vector2 = old.move_toward(chosen, maxf(0,delta)*120)
		next = next.limit_length(radius)
		if not offsets.has(key): next = chosen
		if not Geometry.point_is_clear(base+next,walls) or not Geometry.segment_is_clear(base,base+next,walls): next = Vector2.ZERO
		offsets[key] = next; positions[key] = base+next; occupied.append(base+next)
	for key in offsets.keys():
		if not present.has(key): offsets.erase(key)

func point(key: String, fallback: Vector2) -> Vector2:
	return positions.get(key,fallback)
