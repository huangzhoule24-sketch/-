extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Guide=preload("res://scripts/core/tutorial_progress.gd")
const Floor=preload("res://scripts/core/international_floor.gd")
const Nav=preload("res://scripts/services/grid_navigation.gd")
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
 checks+=1
 if not value:failures.append(message);push_error(message)
func fixture(seed=77):
 var m=Model.new(seed);m.start_full();var p=Guide.ensure(m);p.completed_steps=Guide.config().steps.map(func(s):return str(s.id));p.finished=true;return m
func step(m,minutes=1):
 for i in range(minutes):m.state.total_minutes+=1;m.full_rules.international.tick()
func run():
 var locked=Model.new(2);locked.start_full();expect(not locked.full_rules.international.perform("int_visit",{"region":"india"}).ok,"Locked scenes cannot bypass opening or guidance")
 for rid in["india","nordic","greece"]:
  for layout in["balanced","service","storage","sharing"]:expect(Floor.safe_layout(Floor.default_fixtures(layout)),rid+" "+layout+" has real seat/station routes")
  var m=fixture();var r=m.full_rules.international;var d=r.region(rid);var def=r.definition("regions",rid);var main=m.state.get("revision191",{}).duplicate(true);var cash=float(m.state.cash)
  expect(not r.perform("int_visit",{"region":rid}).ok,rid+" closed scene rejects travel")
  expect(r.perform("int_open",{"region":rid}).ok,rid+" opens with real expense")
  expect(r.perform("int_visit",{"region":rid}).ok and r.s().active_scene==rid,rid+" becomes primary scene")
  expect(m.state.revision191==main and is_equal_approx(float(m.state.cash),cash-float(def.opening_cost)),rid+" switching changes neither main layout nor cash")
  var first=str(def.dishes[0]);r.perform("int_auto",{"region":rid,"id":first});d.auto_service=false;var seen={};var paid_before=0;var local_revenue=0.0;var checkpoint={};var path="/tmp/branch-lifecycle-"+rid+".json"
  for minute in range(210):
   step(m)
   var f=d.floor
   for g in f.guests:
    seen[str(g.stage)]=true
    if g.stage=="waiting":d.auto_service=true
    if str(g.stage)in["eating","paying"]and not checkpoint.has(str(g.stage)):
     checkpoint[str(g.stage)]=true
     expect(m.save_game(path),rid+" saves during "+str(g.stage));var loaded=fixture();expect(loaded.load_game(path),rid+" reloads during "+str(g.stage))
     expect(loaded.state.international.active_scene==rid and JSON.parse_string(JSON.stringify(loaded.full_rules.international.region(rid).floor))==JSON.parse_string(JSON.stringify(f)),rid+" retains active floor positions and task bindings")
    if not g.motion.is_empty():expect(Nav.point_is_clear(Floor.position(g.motion,r.now()),Floor.obstacles(f.fixtures)),rid+" guest moves outside fixture collision")
   var payments=f.history.filter(func(h):return h.stage=="paid").size()
   if int(d.served)==paid_before:expect(is_equal_approx(float(d.revenue),local_revenue),rid+" no revenue before real cashier completion")
   paid_before=int(d.served);local_revenue=float(d.revenue)
   expect(payments==int(d.served),rid+" each cashier completion books one sale")
   var jobs={}
   for w in f.workers.values():
    if int(w.job)>0:expect(not jobs.has(int(w.job)),rid+" job has one worker");jobs[int(w.job)]=true
   if minute%25==0:expect(r.validate(m.state),rid+" ongoing floor validates")
  for stage in["arriving","ordering","waiting","serving","eating","queue","paying","leaving","cleaning"]:expect(seen.has(stage),rid+" real lifecycle reaches "+stage)
  for stage in["entered","seated","ordered","served","checkout_walk","paid","departed","cleaned"]:expect(d.floor.history.any(func(h):return h.stage==stage),rid+" history records "+stage)
  expect(int(d.served)>=3,rid+" real local business completes multiple paid orders")
  r.perform("int_business",{"region":rid,"enabled":false});r.perform("int_auto",{"region":rid,"id":first});step(m,140)
  expect(r.floor.can_remodel(rid),rid+" stopping arrivals drains guests and cleaning")
  var original=JSON.stringify(d.floor.fixtures);var move=r.perform("int_move_fixture",{"region":rid,"uid":"table0","x":230,"y":215})
  expect(move.ok and JSON.stringify(d.floor.fixtures)!=original,rid+" clear free reposition applies")
  original=JSON.stringify(d.floor.fixtures);expect(not r.perform("int_move_fixture",{"region":rid,"uid":"table0","x":780,"y":180}).ok and original==JSON.stringify(d.floor.fixtures),rid+" overlapping move refuses without mutation")
  var before=float(m.state.cash);expect(r.perform("int_layout",{"region":rid,"layout":"sharing"}).ok,rid+" starts builder construction");expect(is_equal_approx(float(m.state.cash),before-45)and d.layout=="balanced",rid+" layout charges once and waits for work");step(m,18);expect(d.layout=="sharing"and Floor.safe_layout(d.floor.fixtures),rid+" builder completion replaces valid geometry")
  var cid=str(def.characters[0]);expect(cid in d.partners or r.perform("int_partner",{"region":rid,"id":cid}).ok,rid+" named partner joins real role");expect(r.perform("int_train",{"region":rid,"id":cid}).ok,rid+" training starts");expect(not r.perform("int_train",{"region":rid,"id":cid}).ok,rid+" duplicate training refused");step(m,40);expect(int(d.training.get(cid,0))==1,rid+" timed training completes once")
  expect(r.perform("int_research",{"region":rid,"id":first}).ok,rid+" refinement starts");step(m,30);expect(int(d.mastery.get(first,0))==1,rid+" chef refinement completes")
  expect(r.perform("int_marketing",{"region":rid}).ok,rid+" promotion starts");
  for i in range(20):
   step(m)
   if int(d.marketing_until)>r.now():break
  expect(int(d.marketing_until)>r.now(),rid+" completed promotion has a real timed effect")
  expect(not r.floor.can_remodel(rid),rid+" finishing staff must clear their return route before remodeling");step(m,3);expect(r.floor.can_remodel(rid),rid+" cleared return route permits remodeling")
  var pause=JSON.stringify(m.state.international);m.set_paused(true);m.advance_real(10);expect(pause==JSON.stringify(m.state.international),rid+" pause freezes every local task")
  expect(m.save_game(path),rid+" saves improved scene");var reloaded=fixture();expect(reloaded.load_game(path),rid+" loads improved scene");expect(JSON.parse_string(JSON.stringify(reloaded.full_rules.international.region(rid).floor))==JSON.parse_string(JSON.stringify(d.floor)),rid+" reload retains moved furnishings and task progress")
  var invalid=m.state.duplicate(true);invalid.international.active_scene="bogus";expect(not r.validate(invalid),rid+" unknown scene rejected")
  expect(r.perform("int_visit",{"region":"main"}).ok and r.s().active_scene=="main",rid+" safely returns to main")
  # Legacy orders are explicit migration fixtures, not a claim of natural gameplay.
  var legacy=fixture();var lr=legacy.full_rules.international;lr.perform("int_open",{"region":rid});var ld=lr.region(rid);ld.erase("floor");ld.orders=[{"id":999,"dish_id":first,"quantity":1,"request":"standard","status":"waiting","created":lr.now(),"due":lr.now()+60}];ld.jobs=[];var money=float(legacy.state.cash);lr.ensure_state()
  expect(ld.floor.guests.size()==1 and ld.floor.guests[0].stage=="waiting"and is_equal_approx(float(legacy.state.cash),money),rid+" old waiting guest migrates without new charge")
  expect(lr.validate(legacy.state),rid+" migrated old floor is valid")
 print("Branch floor: "+JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty()else 1)
