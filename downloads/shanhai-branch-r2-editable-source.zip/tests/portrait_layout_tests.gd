extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures.append(message);push_error(message)
func settle():
	for i in range(12):await process_frame
func run():
	root.size=Vector2i(390,844)
	var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	await settle()
	for dimensions in [Vector2i(390,844),Vector2i(360,640),Vector2i(430,932),Vector2i(375,667)]:
		root.size=dimensions;ui.update_ui_layout();await settle()
		expect(ui.portrait_layout and not ui.landscape_required,"Portrait has native layout without orientation lock: "+str(dimensions))
		expect(ui.map_view.size.y>=dimensions.y*.4,"Restaurant remains usable in portrait: "+str(ui.map_view.size))
		for name in ui.navigation_buttons:
			var b=ui.navigation_buttons[name]
			if b.is_visible_in_tree():expect(b.get_global_rect().position.x>=0 and b.get_global_rect().end.x<=dimensions.x+1,"Portrait navigation fits: "+name)
		for control in [ui.phone_ui.hud,ui._layout_controls.bottom]:expect(control.get_global_rect().end.x<=dimensions.x+1,"HUD/bottom fit real width")
	ui.model.set_paused(false);var state=JSON.stringify(ui.model.state);root.size=Vector2i(844,390);ui.update_ui_layout();await settle()
	expect(not ui.portrait_layout and not ui.model.paused,"Rotating does not pause the running campaign")
	root.size=Vector2i(390,844);ui.update_ui_layout();await settle()
	ui.model.set_paused(true);ui.model.state.stage=4;ui.model.state.cash=100000;ui.refresh()
	for name in ["员工","更多","财务账本","系统","图鉴","山海驿路","菜牌说明","装修"]:
		ui.open_panel(name);await settle();ui.phone_ui.adapt_content();await settle()
		var r=ui.modal_window.get_global_rect()
		expect(r.position.x>=0 and r.position.y>=0 and r.end.x<=ui.size.x+1 and r.end.y<=ui.size.y+1,"Portrait modal fits: "+name+str(r))
		expect(ui.modal_body.get_combined_minimum_size().x<=ui.size.x-20,"Portrait contents wrap: "+name+str(ui.modal_body.get_combined_minimum_size()))
		ui.close_panel(false);await settle()
	ui.open_culture("employees","bi_fang");await settle()
	expect(ui.modal_body.get_combined_minimum_size().x<=ui.size.x-20,"Culture portrait and introduction fit phone")
	ui.close_panel(false)
	ui.model.state.erase("tutorial");ui.model.state.stage=0;ui.tutorial_overlay.poll(0);ui.tutorial_overlay.update_layout();await settle()
	var guide=ui.tutorial_overlay.tutorial_card.get_global_rect()
	expect(guide.position.x>=0 and guide.end.x<=ui.size.x+1 and guide.end.y<=ui.size.y+1,"Full tutorial card stays inside portrait")
	ui.open_panel("员工");await settle()
	var panel=ui.modal_window.get_global_rect();guide=ui.tutorial_overlay.tutorial_card.get_global_rect()
	expect(not panel.intersects(guide),"Tutorial gets its own region below panel")
	print("Portrait layout: "+JSON.stringify({"checks":checks,"failures":failures}))
	ui.queue_free();await process_frame;quit(0 if failures.is_empty()else 1)
