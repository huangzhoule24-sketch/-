extends SceneTree

## Exercise the real cultural controls, including locked content and return state.
## No browser is opened by this harness; source-click destinations are recorded.
const Catalog = preload("res://scripts/services/culture_catalog.gd")
var checks: int = 0
var failures: int = 0
var letter_pattern = RegEx.new()
var covered_glyphs: Dictionary = {}
var missing_glyphs: Dictionary = {}

class Harness extends "res://scripts/ui/main.gd":
	var opened_urls: Array[String] = []
	func _ready() -> void:
		var game_theme = Theme.new()
		game_theme.default_font = FONT
		game_theme.default_font_size = 16
		theme = game_theme
		model = GameModel.new(20261017)
		model.start_full()
		# Broad panel fixtures defer stage teaching; mandatory guidance has its own real-operation suite.
		model.state.tutorial = {"version":2,"completed_steps":["welcome","staff","promotion","first_order","income","bill"],"deferred":Guide.config().stage_steps.map(func(step): return step.id),"actions":[],"stage_completed":[],"panel_opened":[],"panel_closed":[],"finished":true,"skipped":false,"seen_stage":0}
		assets = AssetCatalog.new()
		model.set_paused(true)
		build_interface()
		full_panels = FullPanels.new(self)
		tutorial_overlay = TutorialOverlay.new()
		add_child(tutorial_overlay)
		tutorial_overlay.setup(self)
		model.changed.connect(refresh)
		model.notice.connect(show_notice)
		set_process(false)
		refresh()
	func open_culture_source(url: String) -> void:
		if valid_culture_source_url(url): opened_urls.append(url)

func _init() -> void:
	call_deferred("run")

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures += 1
		push_error(message)

func find(node: Node, id: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.get_meta("qa_id", "")) == id: return node
	for child in node.get_children():
		var result = find(child, id)
		if result != null: return result
	return null

func text_of(node: Node) -> String:
	var result: String = node.text if node is Label or node is RichTextLabel else ""
	for child in node.get_children():
		if not child.is_queued_for_deletion(): result += "\n" + text_of(child)
	return result

func named(node: Node, expected: String) -> Node:
	if str(node.name) == expected: return node
	for child in node.get_children():
		var result = named(child, expected)
		if result != null: return result
	return null

func body_label(node: Node) -> Label:
	if node is Label and bool(node.get_meta("culture_body_text", false)) and str(node.name) != "CulturePinyin": return node
	for child in node.get_children():
		var result: Label = body_label(child)
		if result != null: return result
	return null

func record_glyph_coverage(node: Node) -> void:
	if node is Label or node is RichTextLabel or node is Button:
		var font: Font = node.get_theme_font("normal_font" if node is RichTextLabel else "font")
		for character in node.text:
			if letter_pattern.search(character) == null: continue
			var key: String = str(font.get_instance_id()) + ":" + character
			if covered_glyphs.has(key): continue
			covered_glyphs[key] = true
			if not font.has_char(character.unicode_at(0)):
				missing_glyphs["U+%04X %s" % [character.unicode_at(0), character]] = true
	for child in node.get_children():
		if not child.is_queued_for_deletion(): record_glyph_coverage(child)

func settle() -> void:
	await process_frame
	await process_frame
	await process_frame

func run() -> void:
	check(letter_pattern.compile("\\p{L}") == OK, "Unicode letter coverage matcher initializes")
	root.size = Vector2i(1440, 900)
	var catalog = Catalog.new()
	check(catalog.errors.is_empty(), "Cultural data validates before the UI opens")
	check(catalog.entry_ids("employees").size() == 45 and catalog.entry_ids("dishes").size() == 40, "Original and international partners and dishes all have reading entries")
	for letter in "āáǎàēéěèīíǐìōóǒòūúǔùüǖǘǚǜĀÁǍÀĒÉĚÈĪÍǏÌŌÓǑÒŪÚǓÙÜǕǗǙǛ":
		check(preload("res://scripts/ui/culture_panel.gd").PINYIN_FONT.has_char(letter.unicode_at(0)), "Bundled pinyin font contains accented character: " + letter)
	var ui = Harness.new()
	root.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	await settle()
	# This suite checks the Chinese narrative; a player's saved English preference
	# is covered by the bilingual suite and must not change this fixture's language.
	ui.culture_panel=preload("res://scripts/ui/culture_panel.gd").new(ui,"user://culture-ui-%d.cfg"%OS.get_process_id())
	ui.culture_panel.language="zh"
	ui.open_panel("员工")
	for employee in ui.model.employees:
		check(find(ui.modal_body, "culture:employees:" + str(employee.id)) != null, "Owned employee card exposes cultural reading: " + str(employee.id))
	ui.open_panel("员工培养")
	check(find(ui.modal_body, "culture:employees:xian_yang") != null, "Training cards preserve cultural access")
	ui.model.state.stage=1
	ui.open_panel("研发")
	check(find(ui.modal_body, "culture:dishes:qianyang_soup") != null, "A locked recipe exposes cultural reading before research")
	ui.open_panel("菜单")
	check(find(ui.modal_body, "culture:dishes:noodles") != null, "Menu cards expose cultural reading")
	ui.open_panel("图鉴")
	await settle()
	var before_cash: float = float(ui.model.state.cash)
	var before_minute: int = int(ui.model.state.total_minutes)
	var before_unlocks: Array = ui.model.state.unlocked_dishes.duplicate()
	var before_employees: Array = ui.model.employees.duplicate(true)
	for kind in ["employees", "dishes"]:
		var tab: String = "员工" if kind == "employees" else "菜品"
		ui.full_panels.catalog_tab = tab
		ui.open_panel("图鉴")
		await settle()
		for id in catalog.entry_ids(kind):
			var regional=catalog.get_entry(kind,id).has("international_region")
			tab=("跨国伙伴"if kind=="employees"else"当地菜品")if regional else("员工"if kind=="employees"else"菜品")
			if ui.full_panels.catalog_tab!=tab:
				ui.full_panels.catalog_tab=tab;ui.open_panel("图鉴");await settle()
			var button: Button = find(ui.modal_body, "culture:%s:%s" % [kind, id])
			check(button != null and not button.disabled, "All catalog entries can be read before unlocking: %s/%s" % [kind, id])
			if button == null: continue
			var prior_scroll: int = 180
			ui.modal_body.get_parent().scroll_vertical = prior_scroll
			prior_scroll = ui.modal_body.get_parent().scroll_vertical
			var links_before: int = ui.opened_urls.size()
			button.pressed.emit()
			await settle()
			var entry: Dictionary = catalog.get_entry(kind, id)
			var rendered: String = text_of(ui.modal_body)
			check(ui.panel_name == "文化简介" and rendered.contains(str(entry.name)), "Actual cultural button renders the requested name: " + str(id))
			var pinyin_label: Label = named(ui.modal_body, "CulturePinyin")
			check(pinyin_label != null and pinyin_label.text == str(entry.pinyin) and pinyin_label.get_theme_font("font") == preload("res://scripts/ui/culture_panel.gd").PINYIN_FONT, "Actual pinyin label uses the bundled extended Latin font: " + str(id))
			var actual_body: Label = body_label(ui.modal_body)
			check(actual_body != null and actual_body.get_theme_font("font").has_char(0x342b) and actual_body.get_theme_font("font").has_char(0x4455), "Actual cultural body font retains uncommon original-text glyphs: " + str(id))
			record_glyph_coverage(ui.modal_body)
			var complete = rendered.contains(str(entry.summary))
			for section in entry.sections: complete = complete and rendered.contains(str(section.text))
			for quote in entry.get("quotes",[]): complete = complete and rendered.contains(str(quote.text))
			check(complete and not rendered.contains("来源与延伸阅读"), "Full player narrative and optional excerpts render without a bibliography: " + str(id))
			check(ui.opened_urls.size() == links_before, "Reading alone does not open an external website: " + str(id))
			var snapshot: Dictionary = ui.culture_panel.snapshot()
			check(snapshot.id == id and snapshot.kind == kind and int(snapshot.source_count) > 0 and snapshot.resource_id == ui.assets.culture_resource_id(kind, id), "Read-only snapshot identifies entry, references and future image slot: " + str(id))
			var sources: Array = catalog.sources_for(entry)
			check(not rendered.contains("http") and find(ui.modal_body,"culture:source:"+str(sources[0].id))==null,"Player reading has no source links")
			var back: Button = find(ui.modal_window, "culture:back")
			check(back != null and back.is_visible_in_tree() and back.size.y >= 44, "Return stays fixed outside scrolling content: " + str(id))
			if back != null: back.pressed.emit()
			await settle()
			check(ui.panel_name == "图鉴" and ui.full_panels.catalog_tab == tab and ui.modal_body.get_parent().scroll_vertical == prior_scroll, "Return restores catalog, tab and reading position: " + str(id))
	check(float(ui.model.state.cash) == before_cash and int(ui.model.state.total_minutes) == before_minute and ui.model.state.unlocked_dishes == before_unlocks and ui.model.employees == before_employees, "All85 partner/dish readings leave resources, time, employees and recipe unlocks untouched")
	check(not "baize_hidden_banquet" in ui.model.state.unlocked_dishes and find(ui.modal_body, "culture:dishes:baize_hidden_banquet") != null, "Hidden recipe remains locked while its cultural card is accessible")
	ui.close_panel()
	ui.model.set_paused(false)
	ui.open_panel("菜单")
	find(ui.modal_body, "culture:dishes:noodles").pressed.emit()
	await settle()
	ui.close_panel()
	check(ui.panel_name == "菜单" and ui.model.paused, "Close on a cultural page returns to its parent without resuming early")
	ui.close_panel()
	check(not ui.model.paused, "Closing the parent restores the running state it had before reading")
	ui.model.set_paused(true)
	ui.open_panel("员工")
	find(ui.modal_body, "culture:employees:xian_yang").pressed.emit()
	await settle()
	ui.return_from_culture()
	await settle()
	ui.close_panel()
	check(ui.model.paused, "Reading preserves an already paused game")
	for unsafe_url in ["javascript:alert(1)", "file:///tmp/file", "http://example.com", "https://", "https://example.com/\ntext", "https://user@example.com"]:
		check(not ui.valid_culture_source_url(unsafe_url), "Unsafe source URL is rejected: " + unsafe_url)
	ui.open_panel("美术资源")
	var slots: OptionButton = find(ui.modal_body, "art:culture-slot")
	check(slots != null and slots.item_count == 82+preload("res://scripts/ui/art_targets.gd").slots(ui.model).size(), "Developer import offers 55 culture,12 guest,2 pickup,12 cutaway slots and manual entry")
	if slots != null:
		slots.item_selected.emit(1)
		check(ui._import_path.text == "Characters/xian_yang_lore.png", "Employee slot selects the reserved cultural image path")
		var hidden_slots: Dictionary = {"Dishes/baize_hidden_banquet_lore.png":false,"Dishes/phoenix_true_soup_lore.png":false}
		for index in range(1,slots.item_count):
			var target: String = str(slots.get_item_metadata(index))
			if hidden_slots.has(target):
				slots.item_selected.emit(index)
				hidden_slots[target] = ui._import_path.text == target
		for target in hidden_slots: check(bool(hidden_slots[target]), "Hidden dish selects its own reserved cultural image path: " + target)
	root.size = Vector2i(844, 390)
	await settle()
	ui.open_panel("图鉴")
	ui.open_culture("employees", "xian_yang")
	await settle()
	var mobile_back: Button = find(ui.modal_window, "culture:back")
	check(ui.compact_layout and mobile_back != null and mobile_back.size.y >= 44 and ui.modal_window.get_global_rect().encloses(mobile_back.get_global_rect()), "Phone landscape keeps the cultural return target visible and touch-sized")
	check(ui.modal_body.size.x <= ui.modal_window.size.x and not ui.modal_body.get_parent().horizontal_scroll_mode == ScrollContainer.SCROLL_MODE_AUTO, "Cultural text wraps inside the phone reading panel")
	ui.modal_body.get_parent().scroll_vertical = 100000
	await settle()
	check(mobile_back.is_visible_in_tree() and ui.modal_window.get_global_rect().encloses(mobile_back.get_global_rect()), "Long references can scroll without moving the phone return button")
	ui.close_panel()
	ui.close_panel()
	ui.queue_free()
	await settle()
	check(missing_glyphs.is_empty(), "Every Unicode letter in actual rendered cultural labels has a bundled font glyph: " + str(missing_glyphs.keys()))
	print("Culture font coverage: %d distinct font/letter pairs; missing: %s" % [covered_glyphs.size(), str(missing_glyphs.keys())])
	print("Culture UI checks: %d; failures: %d" % [checks, failures])
	quit(1 if failures else 0)
