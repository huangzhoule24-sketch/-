extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures.append(message);push_error(message)
func settle():
	for i in range(12):await process_frame
func control(ui,id: String):
	for node in ui._qa_buttons:
		if is_instance_valid(node)and not node.is_queued_for_deletion()and node.is_visible_in_tree()and str(node.get_meta("qa_id",""))==id:return node
	return null
func inside(ui,node: Control) -> bool:
	var r=node.get_global_rect();return r.position.x>=-.5 and r.position.y>=-.5 and r.end.x<=ui.size.x+.5 and r.end.y<=ui.size.y+.5
func run():
	root.size=Vector2i(390,844);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	for dimensions in [Vector2i(360,640),Vector2i(390,844),Vector2i(430,932)]:
		root.size=dimensions;ui.update_ui_layout();await settle()
		expect(ui.phone_ui.hud.size.y<=140,"Phone primary HUD uses at most140px: "+str(ui.phone_ui.hud.size))
		expect(ui.map_view.size.y>=dimensions.y*.55,"Restaurant receives at least55% phone height")
		for node in [ui.money_label,ui.clock_label,ui.pause_button,ui.bottom_ui.speed_entry,ui.bottom_ui.inventory_button,ui.bottom_ui.summary_button]:expect(node.is_visible_in_tree()and inside(ui,node),"Primary control fits: "+node.name)
		for node in [ui.gem_label,ui.reputation_label,ui.debt_label,ui.training_status,ui.building_status]:expect(not node.is_visible_in_tree()and ui.phone_ui.statuses.is_ancestor_of(node),"Secondary values are intentionally owned by Overview")
	ui.model.state.gems=7;ui.model.set_paused(false)
	ui.bottom_ui.summary_button.pressed.emit();await settle();expect(ui.panel_name=="经营概览","Overview opens from the main HUD")
	var values=ui.overview_ui.snapshot();expect(values.gems.text=="7"and values.debt.text=="￥1200.00","Overview shows actual gem and debt values")
	for key in ["cash","gems","reputation","ingredients","debt","training","building"]:expect(values[key].visible,"Overview displays "+key)
	for key in ["cash","gems","reputation","ingredients"]:expect(values[key].rect.w>=100 and values[key].rect.h<70,"Overview metric has readable card dimensions: "+key)
	var back=control(ui,"panel:restaurant");expect(back!=null and inside(ui,back),"Overview has a fixed Return to Restaurant")
	if back!=null:back.pressed.emit();await settle()
	expect(ui.panel_name.is_empty()and not ui.model.paused,"Global return restores the previous running state")
	ui.model.set_paused(true);ui.open_panel("更多");await settle()
	ui.full_panels.more_search.text="库存";ui.full_panels.more_search.text_changed.emit("库存");await settle()
	expect(control(ui,"full:open:库存供应")!=null and control(ui,"full:open:系统")==null,"More search filters real visible feature shortcuts")
	var stock=control(ui,"full:open:库存供应");stock.pressed.emit();await settle()
	expect(ui._breadcrumb.text.contains("更多")and ui._breadcrumb.text.contains("库存供应"),"Breadcrumb explains the nested route")
	ui.return_to_parent_panel();await settle();expect(ui.full_panels.more_search.text=="库存","Back restores the More filter")
	control(ui,"more:clear").pressed.emit();await settle();expect(ui.full_panels.more_search.text.is_empty()and control(ui,"full:open:系统")!=null,"Clear restores all available entries")
	ui.full_panels.more_search.grab_focus();var paused=ui.model.paused
	var space=InputEventKey.new();space.keycode=KEY_SPACE;space.pressed=true;ui._input(space)
	expect(ui.model.paused==paused,"Typing a space in search cannot pause or resume the game")
	var original=root.size;root.size=Vector2i(original.x,330);ui.update_ui_layout();await settle()
	expect(ui.portrait_layout and ui.full_panels.more_search.has_focus(),"Keyboard-height resize keeps portrait search and focus")
	expect(inside(ui,control(ui,"panel:restaurant")),"Return remains reachable above a short keyboard viewport")
	root.size=original;ui.update_ui_layout();await settle()
	ui.full_panels.more_search.release_focus();ui.return_to_restaurant();await settle()
	ui.open_panel("图鉴");ui.open_culture("employees","xian_yang");await settle()
	expect(control(ui,"panel:restaurant")!=null,"Culture has an explicit global return alongside its parent Back")
	ui.return_to_restaurant();await settle();expect(ui.panel_name.is_empty()and ui._more_history.is_empty(),"Global return exits the entire culture route")
	ui.localization=preload("res://scripts/services/localization.gd").new();ui.localization.set_language("en");ui.open_panel("经营概览");ui.localization.apply_tree(ui);await settle()
	expect(ui._breadcrumb.text.contains("Restaurant")and ui._breadcrumb.text.contains("Overview"),"Breadcrumb is available in English")
	expect(control(ui,"panel:restaurant").text=="Return to the Inn","Global return is available in English")
	ui.return_to_restaurant();await settle()
	root.size=Vector2i(1440,900);ui.update_ui_layout();await settle()
	expect(not ui.portrait_layout and ui.bottom_ui.narrow_row.visible,"Desktop has a separate management row")
	for node in [ui.clock_label,ui.gem_label,ui.reputation_label,ui.debt_label,ui.training_status,ui.building_status]:expect(node.is_visible_in_tree()and inside(ui,node),"Desktop restores all live values")
	ui.open_panel("系统");await settle();expect(control(ui,"panel:restaurant")!=null and inside(ui,control(ui,"panel:restaurant")),"Desktop shares the fixed global return")
	ui.return_to_restaurant();await settle()
	root.size=Vector2i(390,844);ui.update_ui_layout();await settle();expect(ui.phone_ui.hud.size.y<=140,"Returning to portrait retains the compact HUD")
	print("UI refresh: "+JSON.stringify({"checks":checks,"failures":failures}))
	ui.queue_free();await process_frame;quit(0 if failures.is_empty()else 1)
