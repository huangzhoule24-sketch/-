extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures+=1;push_error(message)
func run():
	root.size=Vector2i(844,390)
	var ui=Harness.new();root.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for i in range(6):await process_frame
	ui.close_panel(false)
	var house=ui.map_view.house();house.camera=Vector2.ZERO
	var before=JSON.stringify(ui.model.state);var rng=ui.model._rng.state
	var press=InputEventScreenTouch.new();press.index=0;press.pressed=true;press.position=Vector2(300,160);house.input(press)
	var drag=InputEventScreenDrag.new();drag.index=0;drag.position=Vector2(320,170);drag.relative=Vector2(20,10)
	house.input(drag)
	var once=house.camera
	expect(once.length()>0,"A real finger drag pans the inn")
	var mouse=InputEventMouseMotion.new();mouse.device=-1;mouse.position=drag.position;mouse.relative=drag.relative;house.input(mouse)
	expect(house.camera==once,"Emulated mouse movement does not double the finger drag")
	var other=InputEventScreenDrag.new();other.index=1;other.position=Vector2(600,150);other.relative=Vector2(100,50);house.input(other)
	expect(house.camera==once,"A second finger does not jump the camera")
	press.pressed=false;press.position=drag.position;house.input(press)
	expect(house.touch_index==-1 and not house.pointer_down,"Releasing a finger ends its gesture")
	house.input(drag);expect(house.camera==once,"An ended finger gesture cannot keep panning")
	# A real second contact pinches; an unrelated drag above was deliberately ignored.
	house.cancel_gesture();house.set_zoom(1)
	press.pressed=true;press.position=Vector2(220,140);house.input(press)
	var finger=InputEventScreenTouch.new();finger.index=1;finger.pressed=true;finger.position=Vector2(340,140);house.input(finger)
	var scale=house.scale_factor();other.position=Vector2(400,140);other.relative=Vector2(60,0);house.input(other)
	expect(house.scale_factor()>scale,"Two tracked fingers zoom in smoothly")
	finger.pressed=false;house.input(finger);press.pressed=false;house.input(press)
	expect(house.touches.is_empty() and not house.pointer_down,"Pinch release leaves no stuck pointer")
	house.set_zoom(2)
	var real_mouse=InputEventMouseButton.new();real_mouse.button_index=MOUSE_BUTTON_LEFT;real_mouse.pressed=true;real_mouse.position=Vector2(300,160);house.input(real_mouse)
	mouse.device=0;mouse.position=Vector2(310,165);mouse.relative=Vector2(10,5);house.input(mouse)
	expect(house.camera!=once,"A real mouse remains usable after touch input")
	real_mouse.pressed=false;house.input(real_mouse)
	expect(JSON.stringify(ui.model.state)==before and ui.model._rng.state==rng,"Touch and mouse panning preserve campaign state and randomness")
	ui.model.set_paused(false)
	root.size=Vector2i(390,844);ui.update_ui_layout();await process_frame
	expect(ui.portrait_layout and not ui.landscape_required and not ui.model.paused,"Portrait rotation uses a native layout and preserves running time")
	root.size=Vector2i(844,390);ui.update_ui_layout();await process_frame
	expect(not ui.landscape_required and not ui.model.paused,"Landscape rotation resumes the previously running game")
	ui.model.set_paused(true)
	root.size=Vector2i(390,844);ui.update_ui_layout();await process_frame
	root.size=Vector2i(844,390);ui.update_ui_layout();await process_frame
	expect(ui.model.paused,"Rotation respects a player-selected pause")
	root.size=Vector2i(667,375);ui.update_ui_layout()
	for i in range(6):await process_frame
	for control in [ui.pause_button,ui.money_label,ui.training_status,ui.building_status,ui.bottom_ui.summary_button,ui.bottom_ui.speed_entry]:
		expect(control.get_global_rect().end.x<=667,"Small-phone status remains inside the screen: "+str(control.name))
	for dimensions in [Vector2i(667,375),Vector2i(844,390),Vector2i(915,412),Vector2i(740,320)]:
		root.size=dimensions;ui.update_ui_layout()
		for i in range(8):await process_frame
		expect(ui.map_view.size.y>=dimensions.y*.5,"Phone scene receives at least half the landscape height: "+str(dimensions))
		house.fit_all()
		var area=house.content_rect();var bounds=house.world_bounds()
		for corner in [bounds.position,bounds.end]:
			var projected=house.to_view(corner)
			expect(projected.x>=area.position.x-.1 and projected.y>=area.position.y-.1 and projected.x<=area.end.x+.1 and projected.y<=area.end.y+.1,"Fit contains every map corner: "+str(dimensions))
		house.pan_by(Vector2(99999,99999))
		expect(house.camera.is_equal_approx(Vector2.ZERO),"Fitted map cannot be dragged away into blank space")
		house.set_zoom(2);house.pan_by(Vector2(99999,99999));var limit=house.camera_limits()
		expect(house.camera.is_equal_approx(limit),"Zoomed panning reaches the lower/right map bounds")
		house.pan_by(Vector2(-99999,-99999))
		expect(house.camera.is_equal_approx(-limit),"Zoomed panning reaches the upper/left map bounds")
		var normal_height=ui.map_view.size.y;ui.set_scene_focus(true)
		for i in range(8):await process_frame
		expect(ui.scene_focus and ui.map_view.size.y>normal_height+60 and not ui._layout_controls.bottom.visible,"Focus expands map and leaves an explicit return control")
		ui.open_panel("更多")
		for i in range(8):await process_frame
		expect(not ui.scene_focus and ui._layout_controls.bottom.visible,"Opening a panel restores the interface")
		ui.close_panel(false)
	root.size=Vector2i(667,375);ui.update_ui_layout()
	for i in range(8):await process_frame
	house.set_zoom(2)
	press.pressed=true;press.position=ui.map_view.global_position+house.content_rect().get_center()
	ui.map_view._input(press)
	drag.position=Vector2(press.position.x,ui.map_view.global_position.y-20);drag.relative=drag.position-press.position
	ui.map_view._input(drag)
	expect(house.dragging,"Finger drag stays captured outside the scene")
	press.pressed=false;press.position=drag.position;ui.map_view._input(press)
	expect(house.touches.is_empty(),"Releasing outside the scene ends captured touch")
	ui.open_panel("更多")
	for i in range(6):await process_frame
	var scroll=ui.modal_body.get_parent()
	var relay=preload("res://scripts/ui/touch_scrolling.gd").new(ui)
	press.index=0;press.pressed=true;press.position=scroll.get_global_rect().get_center();relay.input(press)
	drag.index=0;drag.position=press.position-Vector2(0,60);drag.relative=Vector2(0,-60);relay.input(drag)
	expect(scroll.scroll_vertical>0,"Touch lists scroll even without native touchscreen detection")
	press.pressed=false;relay.input(press)
	ui.queue_free();await process_frame
	print("Mobile touch: ",JSON.stringify({"checks":checks,"failures":failures}));quit(1 if failures else 0)
