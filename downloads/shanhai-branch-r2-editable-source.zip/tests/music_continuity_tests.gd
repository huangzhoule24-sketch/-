extends SceneTree
const Audio=preload("res://scripts/services/audio_system.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures+=1;push_error(message)
func run():
	var audio=Audio.new("res://assets/audio","user://continuity-no-custom","user://continuity-%d.cfg"%OS.get_process_id())
	root.add_child(audio)
	await process_frame
	audio.set_music("music.day")
	expect(audio.snapshot().music_paused,"New music follows the initial game pause")
	await create_timer(.2).timeout
	expect(audio.snapshot().music_position<.05,"Music does not advance during the initial pause")
	audio.set_world_paused(false)
	await create_timer(.3).timeout
	var before=audio.snapshot();var starts=audio.music_starts
	expect(not before.music_paused and before.music_position>.1,"Resuming starts actual cursor advancement")
	for i in range(20):audio.stop_preview()
	await create_timer(.2).timeout
	expect(audio.snapshot().music_position>before.music_position+.1 and audio.music_starts==starts,"Ordinary panel cleanup keeps the current playback cursor")
	audio.set_world_paused(true)
	var paused=audio.snapshot().music_position
	await create_timer(.25).timeout
	expect(audio.snapshot().music_paused and absf(audio.snapshot().music_position-paused)<.04,"Game pause freezes music at its current position")
	for cue in ["music.title","music.explore","music.contest","music.night","music.day"]:
		audio.set_music(cue);audio.stop_preview()
	expect(audio.music_starts==starts and audio.snapshot().music_paused and absf(audio.snapshot().music_position-paused)<.04,"Navigating shared contexts while paused preserves one suspended recording")
	audio.set_channel_enabled("music",false);audio.set_channel_enabled("music",true)
	expect(audio.snapshot().music_paused and audio.music_starts==starts,"Music toggle cannot resume a paused game or restart its recording")
	audio.set_world_paused(false)
	await create_timer(.25).timeout
	expect(audio.snapshot().music_position>paused+.1,"Continue resumes from the held position")
	before=audio.snapshot()
	for i in range(20):
		audio.set_music("music.explore" if i%2==0 else "music.day");audio.stop_preview()
	audio.set_level("music",.4);audio.set_muted(true);audio.set_muted(false)
	await create_timer(.2).timeout
	expect(audio.music_starts==starts and audio.snapshot().music_position>before.music_position+.1,"Navigation, gain and mute changes never rewind music")
	audio.set_world_paused(true)
	expect(audio.preview("music.day"),"Explicit developer preview remains available")
	audio.stop_preview()
	expect(audio.snapshot().music_paused,"Ending a preview respects the paused game")
	audio.queue_free();await process_frame;await process_frame
	print("Music continuity: ",JSON.stringify({"checks":checks,"failures":failures}));quit(1 if failures else 0)
