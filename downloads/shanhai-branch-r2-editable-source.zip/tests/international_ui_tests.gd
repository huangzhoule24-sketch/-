extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures.append(message);push_error(message)
func settle():
	for i in range(10):await process_frame
func control(ui,id):
	for node in ui._qa_buttons:
		if is_instance_valid(node)and not node.is_queued_for_deletion()and node.is_visible_in_tree()and node.get_meta("qa_id","")==id:return node
	return null
func run():
	root.size=Vector2i(390,844);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
	ui.open_panel("跨国食肆");await settle()
	expect(ui.panel_name=="跨国食肆"and ui.international_ui!=null,"Existing navigation opens the actual international panel")
	for rid in["india","nordic","greece"]:
		ui.international_ui.select_region(rid);await settle()
		expect(control(ui,"int:int_open:")!=null,rid+" has a real opening action")
		expect(is_instance_valid(ui.international_ui.map_widget),rid+" has the live regional scene")
		var before=JSON.stringify(ui.model.state.international)
		ui.international_ui.preview="sharing";ui.international_ui.refresh_page();await settle()
		expect(JSON.stringify(ui.model.state.international)==before,rid+" an unconfirmed layout preview is read-only")
		for tab in["菜单","伙伴","来信","账目","店铺"]:
			ui.international_ui.tab=tab;ui.international_ui.refresh_page(false);await settle()
			expect(control(ui,"panel:restaurant")!=null,rid+" / "+tab+" retains fixed global return")
	ui.international_ui.select_region("india");await settle()
	ui.modal_body.get_parent().scroll_vertical=1000;await settle()
	ui.international_ui.action(ui.modal_body,"Open","int_open",{}).pressed.emit();await settle()
	expect(ui.model.full_rules.international.region("india").open,"A real UI action opens a branch")
	expect(ui.modal_body.get_parent().scroll_vertical==0,"Opening resets the invitation offset after pending state refresh and layout settle")
	ui.international_ui.tab="菜单";ui.international_ui.refresh_page(false);await settle();control(ui,"int:int_prepare:in_d01:q1").pressed.emit();await settle()
	expect(ui.model.full_rules.international.region("india").jobs.size()==1,"Menu action purchases and starts preparation")
	ui.international_ui.tab="店铺";ui.international_ui.refresh_page();await settle()
	var paused=ui.model.paused;control(ui,"int:time:pause").pressed.emit();await settle();expect(ui.model.paused!=paused,"Local continue/pause controls the real campaign clock")
	ui.toggle_pause();await settle()
	for dimensions in[Vector2i(360,640),Vector2i(390,844),Vector2i(1440,900)]:
		root.size=dimensions;ui.update_ui_layout();await settle()
		ui.international_ui.refresh_page();await settle()
		var back=control(ui,"panel:restaurant");var rect=back.get_global_rect()
		expect(rect.position.x>=0 and rect.end.x<=dimensions.x+1 and rect.end.y<=dimensions.y+1,"Global return fits "+str(dimensions))
	ui.open_panel("图鉴");ui.full_panels.catalog_tab="跨国伙伴";ui.open_panel("图鉴",false);await settle()
	expect(control(ui,"culture:employees:in_01")!=null and control(ui,"culture:employees:gr_05")!=null,"Existing catalog includes every region’s partner entries")
	ui.open_culture("employees","in_01");await settle()
	expect(ui.culture_panel.image_available and ui.culture_panel.image_style=="pixel","New culture reading uses a real pixel figure")
	expect(ui.culture_panel.entry.sections.size()==3,"New character has three literary/cultural reading sections")
	ui.return_to_parent_panel();await settle();ui.return_to_restaurant();await settle()
	expect(ui.panel_name.is_empty(),"International culture route can return to the restaurant")
	ui.localization=preload("res://scripts/services/localization.gd").new();ui.localization.set_language("en");ui.open_panel("跨国食肆");await settle()
	expect(control(ui,"int:region:india").text.contains("India"),"Regional navigation has intentional English text")
	ui.return_to_restaurant();await settle();ui.queue_free();await process_frame
	print("International UI: "+JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty()else 1)
