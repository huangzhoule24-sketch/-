extends SceneTree
const Audio = preload("res://scripts/services/audio_system.gd")
const Bridge = preload("res://scripts/services/game_audio_bridge.gd")
const Model = preload("res://scripts/core/game_model.gd")
const Harness = preload("res://tests/ui_requirements_tests.gd").Harness
var checks = 0
var failures = 0
var fixture = "user://audio-tests-%d" % OS.get_process_id()
class Recorder extends RefCounted:
	var config: Dictionary
	var calls: Array = []
	var world_paused = false
	var requested_music = ""
	func set_music(cue): requested_music = cue
	func set_ambience(_cue): pass
	func set_world_paused(value): world_paused = value
	func stop_preview(): pass
	func play_cue(cue, _world = false): calls.append(cue); return true

func _init(): call_deferred("run")
func expect(value: bool, message: String):
	checks += 1
	if not value: failures += 1; push_error(message)
func settle():
	for i in range(5): await process_frame
func find(node: Node, id: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.get_meta("qa_id","")) == id: return node
	for child in node.get_children():
		var result = find(child,id)
		if result != null: return result
	return null
func run():
	DirAccess.make_dir_recursive_absolute(fixture)
	var wav = AudioStreamWAV.new(); wav.format = AudioStreamWAV.FORMAT_16_BITS; wav.mix_rate = 22050
	var data = PackedByteArray(); data.resize(22050*2*2)
	for i in range(22050*2): data.encode_s16(i*2,int(sin(i*TAU*220/22050)*1200))
	wav.data = data
	expect(wav.save_to_wav(fixture+"/test.wav") == OK,"Generate isolated two-second fixture")
	var bytes = FileAccess.get_file_as_bytes(fixture+"/test.wav")
	var audio = Audio.new(fixture+"/builtin",fixture+"/custom",fixture+"/settings.cfg")
	root.add_child(audio); await settle(); audio.set_process(false)
	expect(audio.config.cues.size() == 35,"All 35 named slots load")
	expect(not audio.play_cue("ui.click") and audio.last_errors.is_empty(),"Missing sounds are silent without log spam")
	for cue in audio.config.cues:
		var definition: Dictionary = audio.config.cues[cue]
		expect(Audio.safe_path(str(definition.files[0])),"Valid relative path: "+cue)
		expect(AudioServer.get_bus_index(str(definition.bus)) >= 0,"Existing audio bus: "+cue)
	for path in ["../music/test.wav","/tmp/test.wav","res://test.wav","music/../../test.wav","music\\test.wav","test.gd"]:
		expect(not Audio.safe_path(path),"Reject traversal/script/absolute paths")
	expect(not audio.import_bytes("invalid",bytes,"wav").ok,"Reject unknown slots")
	expect(not audio.import_bytes("music.day",bytes,"gd").ok,"Reject unsupported file extensions")
	expect(not audio.import_bytes("music.day",PackedByteArray([1,2,3]),"wav").ok,"Reject malformed file before decoder")
	for cue in ["music.day","music.title","music.night","ambience.dining","ui.click","action.cook","move.fly"]:
		expect(audio.import_bytes(cue,bytes,"wav").ok,"Import and decode actual WAV: "+cue)
	expect(audio.resource_paths("music.day")[0].ends_with("business_day.wav"),"Imported suffix works without editing manifest")
	var looped = audio.cue_stream("music.day",true)
	expect(looped is AudioStreamWAV and looped.loop_mode == AudioStreamWAV.LOOP_FORWARD and looped.loop_end == 44100,"Whole-WAV loop endpoints use samples")
	var one_shot = audio.cue_stream("music.day",false)
	expect(one_shot.loop_mode == AudioStreamWAV.LOOP_DISABLED and looped.loop_mode == AudioStreamWAV.LOOP_FORWARD,"Loop settings do not mutate shared streams")
	audio.config.crossfade_seconds = .05
	audio.set_music("music.day"); await create_timer(.08).timeout
	var starts = audio.music_starts
	for i in range(20): audio.set_music("music.day")
	expect(audio.music_starts == starts,"Same context never restarts background music")
	audio.set_music("music.title"); audio.set_music("music.night"); await create_timer(.15).timeout
	expect(audio._current.music == "music.night" and audio._music.filter(func(p):return p.playing or p.stream_paused).size() == 1,"Rapid crossfades leave exactly one current track")
	audio.set_world_paused(true)
	audio.set_ambience("ambience.dining")
	expect(audio._ambient[int(audio._active.ambience)].stream_paused,"Environment loop pauses with the world")
	expect(not audio.play_cue("action.cook",true),"Pause rejects world action sounds")
	expect(audio.play_cue("ui.click"),"UI remains audible during pause")
	expect(not audio.play_cue("ui.click"),"Repeated clicks respect per-cue cooldown")
	audio._clock += 1; audio.set_world_paused(false)
	expect(not audio._ambient[int(audio._active.ambience)].stream_paused,"Environment loop resumes with the world")
	expect(audio.play_cue("action.cook",true),"Real action cue can play while running")
	expect(not audio.play_cue("move.fly",true),"Global world budget prevents dense overlap")
	audio.set_world_paused(true)
	expect(not audio._voices.any(func(p):return p.playing and p.get_meta("world",false)),"Pausing stops in-flight world effects")
	expect(audio.preview("music.day"),"Preview decodes selected slot")
	expect(audio._music[int(audio._active.music)].stream_paused,"Preview suppresses current background music")
	audio.stop_preview()
	expect(not audio._preview.playing and audio.snapshot().music_paused,"Stopping preview preserves game pause")
	audio.set_world_paused(false)
	expect(audio._music.all(func(p):return not p.stream_paused),"Music resumes when the game resumes")
	audio.set_level("music",.23); audio.set_level("sfx",5); audio.set_muted(true)
	expect(audio.levels.sfx == 1.0 and AudioServer.is_bus_mute(AudioServer.get_bus_index("Master")),"Volumes clamp and mute applies at bus")
	expect(audio.save_settings() == OK,"Independent preferences save")
	var restored = Audio.new(fixture+"/builtin",fixture+"/custom",fixture+"/settings.cfg")
	root.add_child(restored); await settle()
	expect(is_equal_approx(restored.levels.music,.23) and restored.muted,"Volume and mute survive service recreation")
	expect(restored.resource_paths("music.day")[0].ends_with("business_day.wav"),"Imported slot choice persists")
	restored.set_muted(false); restored.queue_free(); audio.set_muted(false)
	# Imported-format precedence and variant rotation do not mix custom/builtin assets.
	DirAccess.make_dir_recursive_absolute(fixture+"/builtin/ui")
	var file = FileAccess.open(fixture+"/builtin/ui/click.wav",FileAccess.WRITE); file.store_buffer(bytes); file.close()
	audio.reload()
	for i in range(4):
		audio.cue_stream("ui.click")
		expect(not audio._cache.has(fixture+"/builtin/ui/click.wav"),"Bundled audio cannot leak into custom variants")
	var model = Model.new(20261025); model.start_full(); model.set_paused(false)
	var recorder = Recorder.new(); recorder.config = audio.config.duplicate(true)
	var bridge = Bridge.new(recorder)
	bridge.update(.3,model,{},"欢迎")
	expect(recorder.requested_music == "music.title" and recorder.calls.is_empty(),"Initial/load snapshot never replays historic rewards")
	bridge.update(.3,model,{},"山海探索")
	expect(recorder.requested_music == "music.explore","Exploration routes to its own music")
	bridge.update(.3,model,{},"厨神大赛")
	expect(recorder.requested_music == "music.contest","Contest routes to its own music")
	model.state.served += 1; bridge.update(.3,model,{},"")
	expect("event.checkout" in recorder.calls,"Actual served increment triggers checkout")
	recorder.calls.clear()
	var before = JSON.stringify(model.state); var rng = model._rng.state
	bridge.update(.3,model,{"xian_yang":{"action":"Move"},"bi_fang":{"action":"Move"},"xuan_gui":{"action":"Move"},"tao_tie":{"action":"Cook"}},"")
	for cue in ["move.walk","move.fly","move.crawl","action.cook"]: expect(cue in recorder.calls,"Different physical actions map to "+cue)
	expect(before == JSON.stringify(model.state) and rng == model._rng.state,"Audio observer cannot change campaign or RNG")
	model.customers.clear()
	model.customers.append({"id":42,"stage":"ordering","arrival_motion":{"started":int(model.state.total_minutes),"travel_minutes":.5}})
	recorder.calls.clear(); bridge.update(.3,model,{},"")
	expect(not "guest.sit" in recorder.calls,"Ordering stage while walking does not play a seat sound")
	model._fraction = .6; bridge.update(.3,model,{},"")
	expect("guest.sit" in recorder.calls,"Seat sound waits until the visible arrival motion finishes")
	recorder.calls.clear(); bridge.update(.3,model,{},"")
	expect(not "guest.sit" in recorder.calls,"Seated customers do not repeat the arrival sound")
	model._fraction = 0; model.customers.clear()
	model.set_paused(true); recorder.calls.clear(); bridge.update(.3,model,{"tao_tie":{"action":"Cook"}},"")
	expect(recorder.calls.is_empty(),"Paused observer emits no movement/work sounds")
	var ui = Harness.new(); root.add_child(ui); await settle()
	ui.setup_audio(); ui.audio.settings_path = fixture+"/ui-settings.cfg"; ui.audio.custom_root = fixture+"/ui-custom"
	ui.open_panel("更多"); ui.open_panel("系统"); ui.open_panel("声音设置"); await settle()
	expect(ui.panel_name == "声音设置" and ui._panel_back.visible,"Sound settings use existing nested back navigation")
	for channel in ["master","music","sfx","ambience"]:
		var slider = find(ui,"audio:volume:"+channel)
		expect(slider is HSlider and slider.custom_minimum_size.y >= 44,"Accessible volume slider "+channel)
	var state_before = JSON.stringify(ui.model.state)
	find(ui,"audio:volume:music").value = 37
	expect(is_equal_approx(ui.audio.levels.music,.37) and state_before == JSON.stringify(ui.model.state),"Actual slider changes audio without changing game values")
	ui.return_to_parent_panel(); await settle()
	expect(ui.panel_name == "系统","Back returns from audio to actual parent")
	ui.open_panel("声音设置"); await settle(); root.size = Vector2i(844,390); ui.queue_ui_layout(); await settle()
	expect(ui._panel_back.get_global_rect().size.y >= 44 and ui.modal_window.get_global_rect().encloses(ui._panel_back.get_global_rect()),"Mobile retains visible fixed return control")
	ui.queue_free(); audio.queue_free(); await settle()
	# Let the audio mixer release its final playback reference before tree exit.
	await create_timer(.15).timeout
	var report = {"checks":checks,"failures":failures,"slots":35,"fixture_audio_shipped":false}
	FileAccess.open("res://build/audio-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Audio foundation: ",JSON.stringify(report)); quit(1 if failures else 0)
