extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
const Art=preload("res://scripts/services/international_art.gd")
const Visual=preload("res://scripts/services/visual_refinement.gd")
const Assets=preload("res://scripts/services/asset_catalog.gd")
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
 checks+=1
 if not value:failures.append(message);push_error(message)
func settle():
 for i in range(10):await process_frame
func button(ui,id):
 for node in ui._qa_buttons:
  if is_instance_valid(node)and node.is_visible_in_tree()and node.get_meta("qa_id","")==id:return node
 return null
func run():
 root.size=Vector2i(390,844);var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle()
 for id in["bi_fang","di_jiang","xian_yang"]:
  expect(ui.assets.get_portrait(id)is AtlasTexture,id+" uses the refined full-body illustration")
  expect(Visual.pixel(id)!=null,id+" has matching pixel cultural art")
  ui.open_culture("employees",id);await settle();expect(ui.culture_panel.image_style=="pixel"and ui.culture_panel.image_available,id+" reading retains a complete pixel figure")
 var custom="/tmp/shanhai-visual-override-"+str(OS.get_process_id());DirAccess.make_dir_recursive_absolute(custom+"/Portraits")
 DirAccess.copy_absolute(ProjectSettings.globalize_path("res://assets/art/Portraits/xian_yang.png"),custom+"/Portraits/xian_yang.png")
 var replacement=Assets.new(Assets.DEFAULT_BUILTIN_ROOT,custom)
 expect(replacement.get_portrait("xian_yang").get_size()==Vector2(512,512),"An imported portrait keeps precedence over the bundled refinement")
 for character in Art.config().characters:
  for frame in range(6):
   var geometry=Visual.walking(character.region,int(character.column),frame);var image=Art.walking(character.id,frame);var b=geometry.bounds
   expect(geometry.reference_height>0 and b[0]>=0 and b[1]>=0 and b[2]<=image.get_width()and b[3]<=image.get_height(),str(character.id)+" frame"+str(frame)+" has in-cell geometry")
   var point=Vector2(100,100);var a=Visual.sprite_rect(point,42,geometry);var z=Visual.sprite_rect(point,84,geometry)
   expect(z.size.is_equal_approx(a.size*2)and(z.position-point).is_equal_approx((a.position-point)*2),"Zoom scales both the body and its ground anchor")
 ui.open_panel("跨国食肆");await settle();var scene=ui.international_ui.map_widget
 for region_id in["india","nordic","greece"]:
  scene.rid=region_id
  var workers=ui.model.full_rules.international.floor.worker_snapshot(region_id,scene.clock())
  for i in range(workers.size()):
   for j in range(i):expect(workers[i].position.distance_to(workers[j].position)>=38,"Actual idle roles have separate anchors in "+region_id)
 scene.rid="india"
 var centre=scene.size*.5;scene.camera.pan=Vector2(21,-15);var before=(centre-scene.size*.5-Vector2(scene.camera.pan))/(scene.base_scale()*float(scene.camera.zoom))
 scene.zoom_at(1.6,centre);var after=(centre-scene.size*.5-Vector2(scene.camera.pan))/(scene.base_scale()*float(scene.camera.zoom))
 expect(before.is_equal_approx(after),"Pinch/wheel zoom preserves the world point under the fingers")
 ui.model._fraction=.375;ui.model.set_paused(false);var active_clock=scene.clock();var active_pose=scene.actor_pose(0,active_clock,"balanced");ui.model.set_paused(true)
 expect(scene.clock()==active_clock and scene.actor_pose(0,scene.clock(),"balanced")==active_pose,"Pause freezes the exact fractional pose without a position or frame snap")
 var touch=InputEventScreenTouch.new();touch.index=4;touch.position=centre;touch.pressed=true;scene._gui_input(touch)
 var release=InputEventScreenTouch.new();release.index=4;release.position=Vector2(-300,-300);release.pressed=false;scene._input(release)
 expect(scene.touches.is_empty(),"A finger released outside the map cannot leave the map captured")
 scene._gui_input(touch);scene._notification(NOTIFICATION_APPLICATION_FOCUS_OUT);expect(scene.touches.is_empty()and not scene.dragging,"App focus loss cancels every pending gesture")
 scene._gui_input(touch);var mouse=InputEventMouseButton.new();mouse.button_index=MOUSE_BUTTON_LEFT;mouse.pressed=true;mouse.device=-1;scene._gui_input(mouse)
 expect(not scene.dragging,"A synthetic mouse stream does not duplicate a finger drag")
 scene.fit();expect(scene.touches.is_empty()and scene.camera.zoom==1.0 and scene.camera.pan==Vector2.ZERO,"Fit restores a recoverable camera and releases gestures")
 ui._touch_scrolling=preload("res://scripts/ui/touch_scrolling.gd").new(ui);ui._touch_scrolling.index=7;ui._touch_scrolling.dragging=true;ui._touch_scrolling.scroll=ui.modal_body.get_parent()
 ui._notification(NOTIFICATION_APPLICATION_FOCUS_OUT);expect(ui._touch_scrolling.index==-1 and not ui._touch_scrolling.dragging,"Focus loss also releases a captured management-list scroll")
 ui._touch_scrolling.index=8;ui._touch_scrolling.scroll=ui.modal_body.get_parent();ui.open_panel("系统");await settle();expect(ui._touch_scrolling.index==-1,"Changing management pages clears the old list gesture")
 var frozen=JSON.stringify(ui.model.state.international);var cash=ui.model.state.cash
 ui.open_panel("系统");await settle();expect(button(ui,"system:visual:reduced")!=null,"Reduced effects are available in normal system settings")
 button(ui,"system:visual:reduced").pressed.emit();await settle()
 expect(Visual.reduced(ui.model)and ui.model.state.cash==cash and JSON.stringify(ui.model.state.international)==frozen,"Reduced effects change only the saved visual preference")
 var path="/tmp/shanhai-visual-save.json";ui.model.save_game(path);var loaded=preload("res://scripts/core/game_model.gd").new(50);loaded.start_full();expect(loaded.load_game(path)and Visual.reduced(loaded),"The visual preference survives the real save serializer")
 ui.return_to_restaurant();ui.queue_free();await process_frame
 print("Visual refinement: "+JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty()else 1)
