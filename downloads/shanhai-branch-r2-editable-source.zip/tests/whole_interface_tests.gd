extends SceneTree
const Harness=preload("res://tests/ui_requirements_tests.gd").Harness
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
 checks+=1
 if not ok:failures+=1;push_error(message)
func settle():
 for i in range(10):await process_frame
func run():
 root.size=Vector2i(1440,900)
 var ui=Harness.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle();ui.close_panel(false)
 ui.tutorial_overlay.restart_tutorial();await settle()
 var guide=ui.tutorial_overlay;var rect=guide.tutorial_card.get_global_rect()
 expect(rect.position.x>=0 and rect.position.y>=0 and rect.end.x<=1440 and rect.end.y<=900,"Full-size opening tutorial fits the shared interface")
 # Layout stress fixture: a long translation must remain scrollable above the map.
 guide.message_label.text=guide.message_label.text.repeat(14);guide.update_layout();await settle()
 expect(guide.card_scroll.get_v_scroll_bar().max_value>guide.card_scroll.get_v_scroll_bar().page,"Long guide body has a real scroll range")
 var house=ui.map_view.house();var old=house.camera
 var press=InputEventScreenTouch.new();press.index=0;press.pressed=true;press.position=guide.card_scroll.get_global_rect().get_center()
 ui.map_view._input(press)
 expect(house.touches.is_empty(),"Map capture does not steal a touch over the tutorial")
 ui._input(press)
 var drag=InputEventScreenDrag.new();drag.index=0;drag.position=press.position-Vector2(0,90);drag.relative=Vector2(0,-90)
 ui.map_view._input(drag);ui._input(drag)
 expect(guide.card_scroll.scroll_vertical>0,"Native content drag scrolls the tutorial body")
 expect(house.camera==old,"Reading the guide does not move the camera underneath")
 press.pressed=false;press.position=drag.position;ui._input(press)
 expect(ui._touch_scrolling.index==-1,"Guide scrolling releases the touch cleanly")
 var tap_card=preload("res://scripts/ui/tap_card.gd").new();ui.add_child(tap_card);tap_card.size=Vector2(200,100)
 var tapped=[0];tap_card.activated.connect(func():tapped[0]+=1)
 var down=InputEventMouseButton.new();down.button_index=MOUSE_BUTTON_LEFT;down.pressed=true;down.position=Vector2(30,30);down.global_position=Vector2(30,30);tap_card._gui_input(down)
 expect(tapped[0]==0,"Employee card waits for release instead of opening at scroll start")
 tap_card.notification(Control.NOTIFICATION_SCROLL_BEGIN);down.pressed=false;tap_card._gui_input(down)
 expect(tapped[0]==0,"Scrolling cancels an armed employee card")
 down.pressed=true;tap_card._gui_input(down);down.pressed=false;tap_card._gui_input(down)
 expect(tapped[0]==1,"A genuine employee-card tap still activates once")
 guide.acknowledge();ui.open_panel("员工");await settle()
 var actual=null
 for node in ui.modal_body.find_children("*","PanelContainer",true,false):
  if node.get_script()!=null and node.get_script().resource_path.ends_with("tap_card.gd"):actual=node;break
 expect(actual!=null,"Real staff list uses scroll-safe cards")
 if actual!=null:
  down.position=Vector2(8,8);down.global_position=actual.global_position+down.position;down.pressed=true;actual._gui_input(down);down.pressed=false;actual._gui_input(down)
  expect(ui.panel_name=="员工详情","A real employee card can open its replacement panel safely")
 ui.queue_free();await settle();print("Whole interface: ",JSON.stringify({"checks":checks,"failures":failures}));quit(1 if failures else 0)
