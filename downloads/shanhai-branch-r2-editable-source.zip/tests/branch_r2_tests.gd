extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Guide=preload("res://scripts/core/tutorial_progress.gd")
const Floor=preload("res://scripts/core/international_floor.gd")
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,detail: String):
 checks+=1
 if not value:failures.append(detail);push_error(detail)
func fixture():
 var m=Model.new(123);m.start_full();var p=Guide.ensure(m);p.completed_steps=Guide.config().steps.map(func(s):return str(s.id));p.finished=true;return m
func step(m,count):
 for n in range(count):m.state.total_minutes+=1;m.full_rules.international.tick()
func run():
 for rid in["india","nordic","greece"]:
  var m=fixture();var r=m.full_rules.international;var d=r.region(rid);var def=r.definition("regions",rid);var cash=float(m.state.cash)
  expect(r.perform("int_open",{"region":rid}).ok,rid+" opens normally")
  expect(d.served==0 and d.partners.any(func(id):return r.floor.worker_role(str(id))=="chef"),rid+" has an active named chef before the first sale")
  expect(is_equal_approx(float(m.state.cash),cash-float(def.opening_cost)),rid+" opening chef is included without a second charge")
  expect(r.staff_limit()==m.full_rules.active_limit(),rid+" active slots follow the main restaurant at the starting stage")
  var candidates=def.characters.filter(func(id):return not id in d.hired);var id=str(candidates[-1]);var before=float(m.state.cash);var expense=float(m.state.ledger.expenses)
  expect(r.unlocked(rid,r.definition("characters",id)),rid+" candidates have no sales-count bond gate")
  expect(not r.can("int_partner",{"region":rid,"id":id}).ok,rid+" staff must be recruited before assignment")
  expect(r.perform("int_recruit",{"region":rid,"id":id,"payment":"cash"}).ok,rid+" zero-sale cash recruitment succeeds")
  expect(d.hired.has(id)and is_equal_approx(float(m.state.cash),before-m._b("hire.ticket_cost_normal"))and is_equal_approx(float(m.state.ledger.expenses),expense+m._b("hire.ticket_cost_normal")),rid+" main recruitment price books cash and expense once")
  before=float(m.state.cash);expect(not r.perform("int_recruit",{"region":rid,"id":id,"payment":"cash"}).ok and is_equal_approx(float(m.state.cash),before),rid+" duplicate recruitment cannot charge again")
  var another=str(def.characters.filter(func(cid):return not cid in d.hired)[0]);m.state.gems=0
  expect(not r.perform("int_recruit",{"region":rid,"id":another,"payment":"gems"}).ok,rid+" resource requirements are enforced")
  # Explicit resource fixture to check gem payment, separate from natural browser play.
  m.state.gems=int(m._b("hire.ticket_cost_advanced"));expense=float(m.state.ledger.expenses)
  expect(r.perform("int_recruit",{"region":rid,"id":another,"payment":"gems"}).ok,rid+" gem recruitment succeeds at the main price")
  expect(m.state.gems==0 and float(m.state.cash)==before and float(m.state.ledger.expenses)==expense,rid+" gem hiring does not also spend cash")
  expect(d.hired.has(another)and not d.partners.has(another),rid+" full active shifts send a new hire to standby")
  var path="/tmp/shanhai-branch-r2-"+rid+".json";expect(m.save_game(path),rid+" hired roster saves")
  var loaded=fixture();expect(loaded.load_game(path),rid+" hired roster reloads")
  expect(loaded.state.international.regions[rid].hired==d.hired and loaded.state.international.regions[rid].recruit_log.size()==2,rid+" ownership and paid hires survive reload")
  for layout in["balanced","service","storage","sharing"]:
   d.layout=layout;r.floor.apply_layout(rid)
   var points=[]
   for index in range(Floor.seats(d.floor.fixtures).size()):
    var anchor=r.floor.seated_anchor(rid,index);points.append(anchor)
    expect(anchor.distance_to(Floor.point(r.floor.seat_info(rid,index).point))<65,rid+" chair and approach remain a short sit-down step apart")
    for stage in["ordering","waiting","serving","eating"]:
     var g={"id":1,"seat":index,"stage":stage,"motion":{},"position":{"x":560,"y":610}}
     var a=r.floor.guest_pose(rid,g,r.now());var b=r.floor.guest_pose(rid,g,r.now()+80)
     expect(a.seated and a.point==b.point and a.point==anchor and a.action==("eat"if stage=="eating"else"sit"),rid+" "+layout+" holds the same chair throughout "+stage)
   for i in range(points.size()):
    for j in range(i):expect(points[i].distance_to(points[j])>=55,rid+" chair anchors remain distinct")
  # Even with all named staff on standby, the opening crew must fulfil actual orders.
  d.layout="balanced";r.floor.apply_layout(rid);d.partners.clear();d.accepting=true;d.auto_service=true
  var first=str(def.dishes[0]);expect(not r.floor.available_workers(rid,"chef").is_empty(),rid+" base kitchen covers missing named chefs")
  expect(r.perform("int_prepare",{"region":rid,"id":first,"quantity":3}).ok,rid+" base kitchen can buy a real batch")
  step(m,120);expect(d.served>=1,rid+" base kitchen completes an actual paid order without a recruitment deadlock")
  # Old R1 roster migration: keep previously seen staff and add the opening chef without money changes.
  var old=fixture();var oldr=old.full_rules.international;oldr.perform("int_open",{"region":rid});var od=oldr.region(rid);var remembered=str(def.characters[-1]);od.floor.workers[remembered]=oldr.floor._worker(remembered)
  od.erase("hired");od.erase("starter_staffed");od.erase("recruit_log");od.partners=def.characters.filter(func(cid):return oldr.floor.worker_role(cid)=="host").slice(0,1);before=float(old.state.cash)
  expect(old.save_game(path),rid+" legacy R1-shaped save writes");var migrated=fixture();expect(migrated.load_game(path),rid+" legacy save loads")
  var md=migrated.state.international.regions[rid]
  expect(md.hired.has(remembered)and md.partners.any(func(cid):return migrated.full_rules.international.floor.worker_role(cid)=="chef")and float(migrated.state.cash)==before,rid+" legacy ownership and opening chef migrate without recharging")
 print("Branch R2: "+JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty()else 1)
