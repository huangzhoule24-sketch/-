extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Sandbox=preload("res://scripts/core/offline_sandbox.gd")
const Guide=preload("res://scripts/core/tutorial_progress.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
 checks+=1
 if not ok:failures+=1;push_error(message)
func run():
 var normal=Model.new(20);normal.start_full();var original=JSON.stringify(normal.state)
 var model=Model.new(20);model.sandbox=Sandbox.new(model);model.sandbox.start();var free=model.sandbox
 expect(model.state.stage==4 and model.employees.size()==30,"All stages and thirty employees are unlocked")
 expect(model.state.unlocked_dishes.size()==model.dishes.size() and model.dishes.size()>=25,"All dishes including hidden recipes are unlocked")
 expect(model.state.expansion.membership.enabled and model.state.expansion.central.enabled and model.state.expansion.branches.values().all(func(b):return b.open),"Membership, central kitchen and every branch are ready")
 expect(model.state.special_visitors.records.size()==6 and model.full_rules.dollhouse.fixtures("stove").size()>=3,"Six guest readings and three actual stoves exist")
 expect(model.state.culture_experience.route_completed.size()==4,"All four branch themes are unlocked")
 expect(Guide.current(model).is_empty(),"Mandatory teaching does not block free play")
 model.set_speed(128);expect(model.speed==128,"Free play supports 128x speed");normal.set_speed(128);expect(normal.speed==4,"Normal speed cap is unchanged")
 model.employees[0].training_until=int(model.state.total_minutes)+200
 var old=int(model.state.total_minutes);var wait=int(model.employees[0].training_until)-old
 expect(free.clock_jump(4*1440+480),"Calendar can move forward")
 expect(int(model.employees[0].training_until)-int(model.state.total_minutes)==wait,"Calendar jump preserves remaining training duration")
 expect(free.clock_jump(60),"Calendar can move backward")
 expect(int(model.employees[0].training_until)-int(model.state.total_minutes)==wait,"Backward jump preserves remaining duration")
 var cash=float(model.state.cash);expect(free.clock_jump(480) and model.state.cash==cash,"Clock-only jump does not invent revenue or fees")
 free.queue_minutes(60)
 while free.remaining>0:free.step()
 expect(int(model.state.total_minutes)==540,"Simulation advances exactly the requested sixty minutes")
 free.queue_minutes(1440)
 while free.remaining>0:free.step()
 expect(int(model.state.total_minutes)==1980,"Simulation crosses daily settlement without freezing on the bill")
 var path="user://sandbox-test.json";expect(free.save(path),"Sandbox save succeeds")
 var known=int(model.state.total_minutes);free.clock_jump(10000)
 expect(free.load_save(path) and int(model.state.total_minutes)==known,"Sandbox restore restores time and gameplay")
 expect(not normal.load_game(path) and JSON.stringify(normal.state)==original,"Normal campaign rejects sandbox saves without changing state")
 free.prepare_case("harvest");expect(int(model.state.total_minutes)==6240 and model.full_rules.culture_experience.event("harvest").status=="offered","Harvest preset sets a fifth-day opportunity")
 expect(not free.clock_jump(-1),"Invalid negative date is rejected")
 model.sandbox=null;free=null
 print("Offline sandbox: ",JSON.stringify({"checks":checks,"failures":failures}));quit(1 if failures else 0)
