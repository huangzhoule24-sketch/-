extends SceneTree
const Main=preload("res://scripts/ui/main.gd")
var checks=0
var failures=0
func _init():call_deferred("run")
func expect(ok: bool,message: String):
 checks+=1
 if not ok:failures+=1;push_error(message)
func find(node: Node,id: String):
 if str(node.get_meta("qa_id",""))==id:return node
 for child in node.get_children():
  var found=find(child,id)
  if found!=null:return found
 return null
func settle():
 for i in range(10):await process_frame
func run():
 root.size=Vector2i(1280,800)
 var ui=Main.new();root.add_child(ui);ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);await settle();ui.set_process(false)
 expect(ui.model.sandbox!=null and ui.model.state.stage==4,"Offline flag starts a fully unlocked game")
 expect(ui.SAVE_PATH=="user://classroom_sandbox.json","UI saves to isolated sandbox path")
 ui.model.sandbox.refill();ui.refresh()
 expect(ui.money_label.text.ends_with("M") and ui.money_label.text.length()<=7 and ("%.2f" % float(ui.model.state.cash)) in ui.money_label.tooltip_text,"Large sandbox cash has a short HUD value and exact tooltip")
 ui.close_panel(false);ui.open_panel("自由控制台");await settle()
 expect(find(ui,"sandbox:clock_apply")!=null and find(ui,"sandbox:checkpoint")!=null,"Console contains actual calendar and checkpoint controls")
 find(ui,"sandbox:day").value=5;find(ui,"sandbox:hour").value=8;find(ui,"sandbox:minute").value=0;find(ui,"sandbox:clock_apply").pressed.emit();await settle()
 expect(int(ui.model.state.total_minutes)==6240,"Actual calendar controls jump to fifth day 08:00")
 find(ui,"sandbox:speed").value=64;find(ui,"sandbox:speed_apply").pressed.emit();await settle()
 expect(ui.model.speed==64,"Actual custom speed control applies 64x")
 find(ui,"sandbox:checkpoint").pressed.emit();ui.model.sandbox.clock_jump(9000);find(ui,"sandbox:restore").pressed.emit();await settle()
 expect(int(ui.model.state.total_minutes)==6240,"Actual checkpoint controls recover previous game time")
 for panel in ["会员外卖","连锁经营","山海探索","三界集团","员工培养","菜单定价","装修","文化简介"]:
  if panel=="文化简介":ui.open_culture("employees","xian_yang")
  else:ui.open_panel(panel)
  await settle();expect(ui.panel_name==panel,"Unlocked page opens: "+panel)
  if ui.decoration_active():ui.finish_decoration(false)
 ui.open_panel("自由控制台");await settle();find(ui,"sandbox:advance:60").pressed.emit()
 while ui.model.sandbox.remaining>0:ui.model.sandbox.step()
 expect(int(ui.model.state.total_minutes)==6300,"UI fast-forward performs sixty real game minutes")
 ui.model.sandbox.save();ui.queue_free();await settle()
 print("Offline sandbox UI: ",JSON.stringify({"checks":checks,"failures":failures}));quit(1 if failures else 0)
