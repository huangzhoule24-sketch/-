extends SceneTree

const Catalog = preload("res://scripts/services/culture_catalog.gd")
var checks := 0
var failures: Array[String] = []

func check(value: bool, message: String) -> void:
	checks += 1
	if not value: failures.append(message)

func plain(entry: Dictionary) -> String:
	var result := str(entry.get("summary", ""))
	for section in entry.get("sections", []): result += "\n" + str(section.get("text", ""))
	return result

func _init() -> void:
	var catalog = Catalog.new()
	var employees = JSON.parse_string(FileAccess.get_file_as_string("res://config/employees.json"))
	var dishes = JSON.parse_string(FileAccess.get_file_as_string("res://config/dishes.json"))
	var management = JSON.parse_string(FileAccess.get_file_as_string("res://config/management.json"))
	var employee_ids: Array = []
	var dish_ids: Array = []
	for employee in employees: employee_ids.append(str(employee.id))
	for dish in dishes: dish_ids.append(str(dish.id))
	dish_ids.append(str(management.hidden_recipe.id))
	var sidequests = JSON.parse_string(FileAccess.get_file_as_string("res://config/sidequests.json"))
	for hidden_recipe in sidequests.hidden_recipes: dish_ids.append(str(hidden_recipe.id))
	check(catalog.errors.is_empty(), "Published culture file passes schema and citation checks: " + str(catalog.errors))
	check(Catalog.validate(catalog.data, employee_ids, dish_ids).is_empty(), "Every actual employee and dish, including the hidden recipe, has a complete referenced entry")
	check(catalog.entry_ids("employees").size() == 45 and catalog.entry_ids("dishes").size() == 40, "The catalogue preserves30 original partners and25 dishes and adds15 international entries to each")
	var matching_names := true
	for employee in employees: matching_names = matching_names and catalog.get_entry("employees", str(employee.id)).get("name", "") == employee.name
	for dish in dishes: matching_names = matching_names and catalog.get_entry("dishes", str(dish.id)).get("name", "") == dish.name
	matching_names = matching_names and catalog.get_entry("dishes", str(management.hidden_recipe.id)).get("name", "") == management.hidden_recipe.name
	for hidden_recipe in sidequests.hidden_recipes:
		matching_names = matching_names and catalog.get_entry("dishes", str(hidden_recipe.id)).get("name", "") == hidden_recipe.name
	check(catalog.get_entry("dishes", "phoenix_true_soup").origin_label.contains("原创") and plain(catalog.get_entry("dishes", "phoenix_true_soup")).contains("重逢"), "Phoenix branch reading tells its reunion story while its editorial origin remains traceable")
	check(catalog.get_entry("dishes", "phoenix_true_soup").source_ids.has("d_shanhai_01"), "New phoenix dish reuses verified primary Phoenix context")
	check(matching_names, "Reading cards match the real game IDs and displayed names")
	check(catalog.get_entry("employees", "missing").is_empty() and catalog.get_entry("unknown", "xian_yang").is_empty(), "Unknown reading IDs fail without crossing categories")
	var original: Dictionary = catalog.get_entry("employees", "xian_yang")
	var edited: Dictionary = catalog.get_entry("employees", "xian_yang")
	edited["summary"] = "test edit"
	if edited.has("sections"): edited.sections.clear()
	check(catalog.get_entry("employees", "xian_yang") == original, "A view cannot mutate the shared reading data")
	var copied_sources: Array = catalog.sources_for(original)
	if not copied_sources.is_empty(): copied_sources[0]["title"] = "test edit"
	check(catalog.sources_for(original) != copied_sources, "Views cannot mutate bibliographic records")
	var invalid: Dictionary = catalog.data.duplicate(true)
	invalid.sources.append(invalid.sources[0].duplicate(true))
	check(not Catalog.validate(invalid).is_empty(), "Duplicate source IDs are rejected")
	invalid = catalog.data.duplicate(true)
	invalid.employees.xian_yang.source_ids.append("unregistered-source")
	check(not Catalog.validate(invalid).is_empty(), "Unregistered citations are rejected")
	invalid = catalog.data.duplicate(true)
	invalid.employees.xian_yang.sections[0]["source_ids"] = ["unregistered-source"]
	check(not Catalog.validate(invalid).is_empty(), "A paragraph cannot cite a source absent from its reading card")
	invalid = catalog.data.duplicate(true)
	invalid.employees.xian_yang["quotes"] = [{"text":"quote", "source_id":"unregistered-source"}]
	check(not Catalog.validate(invalid).is_empty(), "An untraceable quotation is rejected")
	invalid = catalog.data.duplicate(true)
	invalid.dishes.erase(str(management.hidden_recipe.id))
	check(not Catalog.validate(invalid, employee_ids, dish_ids).is_empty(), "Missing hidden-dish reading is caught by integration validation")
	check(Catalog.safe_source_url("https://github.com/kanripo/KR3l0090"), "Explicit HTTPS source links are supported")
	check(not Catalog.safe_source_url("javascript:alert(1)") and not Catalog.safe_source_url("file:///tmp/book") and not Catalog.safe_source_url("https://user@example.com/book") and not Catalog.safe_source_url("https://example.com/\nbook"), "Reading links reject executable, local, credential and control-character URLs")
	check("神异经" in plain(catalog.get_entry("employees", "e_shou")) or "神異經" in plain(catalog.get_entry("employees", "e_shou")), "Eshou has its actual later textual context")
	check("淮南子" in plain(catalog.get_entry("employees", "jiu_ying")), "Jiuying is traced to Huainanzi rather than blindly assigned to Shanhaijing")
	check("丹砂" in str(catalog.get_entry("dishes", "jingwei_bibimbap").get("research_notes","")) and catalog.get_entry("dishes", "jingwei_bibimbap").origin_label.contains("跨文化创意") and "韩国" in plain(catalog.get_entry("dishes", "jingwei_bibimbap")), "Creative dish identity, Korean food context and the mineral distinction remain traceable")
	check("日本" in plain(catalog.get_entry("dishes", "tiangou_tempura")), "The cross-cultural tempura naming is explained")
	for failure in failures: printerr("FAIL: " + failure)
	print("CULTURE CHECKS: %d passed, %d failed" % [checks - failures.size(), failures.size()])
	quit(1 if not failures.is_empty() else 0)
