extends SceneTree
const Model=preload("res://scripts/core/game_model.gd")
const Guide=preload("res://scripts/core/tutorial_progress.gd")
const Catalog=preload("res://scripts/services/culture_catalog.gd")
const Art=preload("res://scripts/services/international_art.gd")
var checks=0
var failures=[]
func _init():call_deferred("run")
func expect(value: bool,message: String):
	checks+=1
	if not value:failures.append(message);push_error(message)
func guided(model):
	var p=Guide.ensure(model);p.completed_steps=Guide.config().steps.map(func(step):return str(step.id));p.finished=true
func minutes(model,amount: int):
	for i in range(amount):model.state.total_minutes=int(model.state.total_minutes)+1;model.full_rules.international.tick()
func run():
	var book=Catalog.new();expect(book.errors.is_empty(),"Merged cultural book validates: "+str(book.errors))
	var master=Model.new(42);master.start_full();var rules=master.full_rules.international
	expect(rules.config.characters.size()==15 and rules.config.dishes.size()==15,"All15 partners and15 recipes are present")
	expect(not rules.perform("int_open",{"region":"india"}).ok,"Opening cannot bypass the six-step tutorial")
	for def in rules.config.regions:
		var model=Model.new(43);model.start_full();guided(model);var r=model.full_rules.international;var rid=str(def.id);var data=r.region(rid)
		var before=float(model.state.cash);var result=r.perform("int_open",{"region":rid})
		expect(result.ok and data.open and float(model.state.cash)==before-float(def.opening_cost),rid+" real opening expense")
		data.auto_service=false
		expect(not r.perform("int_open",{"region":rid}).ok,rid+" opening is not charged twice")
		var first=str(def.dishes[0]);var quote=r.prep_quote(rid,r.definition("dishes",first),3);var revenue=float(model.state.total_revenue)
		expect(r.perform("int_prepare",{"region":rid,"id":first,"quantity":3}).ok,rid+" purchases and starts a real batch")
		expect(float(model.state.total_revenue)==revenue and r.inventory_value()==float(quote.cost),rid+" preparation is inventory, not revenue or immediate consumption")
		expect(not r.perform("int_prepare",{"region":rid,"id":first,"quantity":3}).ok,rid+" occupied equipment prevents duplicate parallel use")
		minutes(model,int(quote.minutes)+5);expect(r.ready(rid,first)==3,rid+" preparation completes against campaign time")
		expect(not data.orders.is_empty(),rid+" actual local demand arrives")
		var requested=data.orders[0];var id=int(requested.id)
		expect(r.perform("int_serve",{"region":rid,"order":id}).ok,rid+" handover consumes prepared stock")
		expect(float(model.state.total_revenue)==revenue,rid+" starting handover does not yet charge the customer")
		minutes(model,35)
		expect(int(data.served)==1 and float(model.state.total_revenue)>revenue,rid+" actual cashier payment records revenue")
		expect(float(model.state.ledger.cost_of_sales)>0,rid+" consumed ingredients reach the existing accrual ledger")
		expect(r.inventory_value()<float(quote.cost),rid+" remaining inventory excludes the sold portion")
		var value=r.inventory_value();var state=model.state.duplicate(true);state.erase("international");expect(r.validate(state),rid+" old saves without the new block remain compatible")
		expect(r.validate(model.state),rid+" new local state validates")
		var path="/tmp/shanhai-international-"+rid+".json";expect(model.save_game(path),rid+" campaign saves through the existing serializer")
		var loaded=Model.new(50);loaded.start_full();expect(loaded.load_game(path),rid+" real campaign reload succeeds")
		expect(loaded.full_rules.international.region(rid).served==data.served and is_equal_approx(loaded.full_rules.international.inventory_value(),value),rid+" reload retains sales and inventory")
		var malformed=model.state.duplicate(true);malformed.international.regions[rid].stock[0].value=-10;expect(not r.validate(malformed),rid+" invalid inventory cost is rejected")
		data.served=8
		for cid in def.characters:
			expect(not book.get_entry("employees",cid).is_empty(),cid+" has bilingual cultural reading")
			expect(Art.character(cid)!=null and Art.character(cid,true)!=null,cid+" has both ink portrait and pixel figure")
		for did in def.dishes:
			expect(not book.get_entry("dishes",did).is_empty(),did+" has bilingual culinary reading")
			expect(Art.dish(did)!=null,did+" has a real dish icon")
		expect(Art.store(rid)!=null and Art.store(rid,true)!=null,rid+" has storefront and room art")
		data.orders.clear();data.jobs.clear();data.stock.clear();data.stock.append({"dish_id":first,"quantity":3,"value":9.0,"expires":r.now()+100})
		data.orders.append({"id":999,"dish_id":first,"quantity":1,"request":"no_milk","status":"waiting","created":r.now(),"due":r.now()+60})
		if "milk"in r.definition("dishes",first).contains:expect(not r.perform("int_serve",{"region":rid,"order":999,"id":str(def.dishes[2])}).ok,rid+" an alternate argument cannot conceal dairy in the actual order")
		var remodel=Model.new(44);remodel.start_full();guided(remodel);var rr=remodel.full_rules.international;rr.perform("int_open",{"region":rid});rr.perform("int_business",{"region":rid,"enabled":false});var rd=rr.region(rid)
		var cash=float(remodel.state.cash);var layout=str(rd.layout);expect(rr.perform("int_layout",{"region":rid,"layout":"sharing"}).ok,rid+" layout improvement has a real time and cash cost")
		expect(rd.layout==layout and float(remodel.state.cash)==cash-45,rid+" layout preview is not instant construction")
		minutes(remodel,16);expect(rd.layout=="sharing",rid+" the completed improvement changes the scene layout")
		var automatic=Model.new(60);automatic.start_full();guided(automatic);var auto=automatic.full_rules.international
		expect(auto.perform("int_open",{"region":rid}).ok,rid+" automatic-service fixture opens through the real action")
		var choice={"india":"limited","nordic":"reserve","greece":"separate"}[rid]
		expect(auto.perform("int_story",{"region":rid,"choice":choice}).ok,rid+" reception story starts without granting service progress")
		expect(auto.region(rid).served==0 and auto.region(rid).story.status=="waiting",rid+" a dialogue choice cannot finish the story")
		expect(auto.perform("int_auto",{"region":rid,"id":first}).ok,rid+" standing procurement requires an explicit action")
		minutes(automatic,180)
		expect(auto.region(rid).served>=3,rid+" the local team completes actual automatic handovers")
		expect(auto.region(rid).story.status=="resolved"and auto.s().letters.size()==1,rid+" fulfilment produces one branch-specific reply")
		expect(automatic.full_rules.culture_experience.s().letters.any(func(l):return str(l.id).begins_with("international:")),rid+" the reply also reaches the existing Shanhai letter box")
		expect(float(automatic.state.cash)>=200 and float(automatic.state.ledger.procurement)>0,rid+" recurring batches respect the cash reserve and are not free")
		expect(auto.validate(automatic.state),rid+" automatically scheduled work and replies remain valid save data")
		var paused=JSON.stringify(automatic.state.international);automatic.set_paused(true);automatic.advance_real(10)
		expect(JSON.stringify(automatic.state.international)==paused,rid+" manual pause freezes local jobs and demand")
		for cid in def.characters:
			for frame in range(6):expect(Art.walking(cid,frame)!=null,cid+" has walking frame"+str(frame))
	print("International: "+JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty()else 1)
