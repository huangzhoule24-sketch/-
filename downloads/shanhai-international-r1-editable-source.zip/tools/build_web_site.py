#!/usr/bin/env python3
"""Build a portable complete static website around a verified Godot export."""
from pathlib import Path
import argparse,gzip,json,shutil,subprocess
from package_release import ROOT,sha256,game_source_fingerprint,write_json,write_zip,utc_now
BUILD=ROOT/'build';SITE=BUILD/'portrait-site';SOURCE=BUILD/'full-web'
REVISION='web-r9-portrait'
VERSION='SH-WEB-R9-PORTRAIT'
PART_BYTES=8*1024*1024
def split_resource(path,encoding):
    parts=[];directory=path.parent/'parts';directory.mkdir(exist_ok=True)
    with path.open('rb')as handle:
        index=0
        while True:
            block=handle.read(PART_BYTES)
            if not block:break
            target=directory/(path.name.replace('.gz','')+'.'+encoding+'.'+str(index).zfill(3)+'.bin');target.write_bytes(block)
            parts.append({'path':'parts/'+target.name,'bytes':len(block),'sha256':sha256(target)});index+=1
    return parts
def main():
    global SITE,REVISION,VERSION
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision',default=REVISION);parser.add_argument('--version',default=VERSION);parser.add_argument('--site-dir',default=str(SITE));parser.add_argument('--public-url',default='https://huangzhoule24-sketch.github.io/-/portrait/')
    parser.add_argument('--skip-archive',action='store_true',help='Build the verified site without an oversized duplicate raw/gzip ZIP; package separately.')
    args=parser.parse_args();REVISION=args.revision;VERSION=args.version;SITE=Path(args.site_dir)
    source=game_source_fingerprint()
    receipt=json.loads((SOURCE/'export-receipt.json').read_text())
    assert receipt['game_source']==source,'Export the current Web game first.'
    for name,entry in receipt['files'].items():
        p=SOURCE/name
        assert p.stat().st_size==entry['bytes'] and sha256(p)==entry['sha256'],name
    if SITE.exists():shutil.rmtree(SITE)
    SITE.mkdir(parents=True)
    shutil.copytree(ROOT/'web/site',SITE,dirs_exist_ok=True)
    for page in SITE.glob('*.html'):page.write_text(page.read_text().replace('SH-WEB-R8',VERSION).replace('web-r8',REVISION))
    for name in ['preview-access.js','share.js']:
        page=SITE/name;page.write_text(page.read_text().replace('web-r9-portrait',REVISION))
    for name in receipt['files']:
        target=SITE/'game'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/name,target)
    (SITE/'assets').mkdir()
    for name in ['logo.png','title.png']:shutil.copyfile(ROOT/'assets/art/UI'/name,SITE/'assets'/name)
    shutil.copyfile(ROOT/'web/fast-loader.js',SITE/'game/fast-loader.js')
    shutil.copyfile(ROOT/'web/mobile-surface.js',SITE/'game/mobile-surface.js')
    sizes={};resource_map={'version':1,'resources':{}}
    for name in ['index.wasm','index.pck']:
        p=SITE/'game'/name
        with p.open('rb')as src,(p.with_name(name+'.gz')).open('wb')as target:
            with gzip.GzipFile(filename='',fileobj=target,mode='wb',compresslevel=9,mtime=0)as z:shutil.copyfileobj(src,z)
        assert gzip.decompress((SITE/'game'/(name+'.gz')).read_bytes())==p.read_bytes()
        sizes[name]={'original_bytes':p.stat().st_size,'gzip_bytes':(SITE/'game'/(name+'.gz')).stat().st_size,'sha256':sha256(p),'gzip_sha256':sha256(SITE/'game'/(name+'.gz'))}
        raw_parts=split_resource(p,'raw');gzip_parts=split_resource(SITE/'game'/(name+'.gz'),'gzip')
        raw=b''.join((SITE/'game'/v['path']).read_bytes()for v in raw_parts)
        compressed=b''.join((SITE/'game'/v['path']).read_bytes()for v in gzip_parts)
        assert raw==p.read_bytes()and gzip.decompress(compressed)==raw
        resource_map['resources'][name]={'mime':'application/wasm'if name.endswith('wasm')else'application/octet-stream','bytes':p.stat().st_size,'sha256':sha256(p),'raw':raw_parts,'gzip':gzip_parts}
        p.unlink();(SITE/'game'/(name+'.gz')).unlink()
        receipt.setdefault('logical_resources',{})[name]=receipt['files'].pop(name)
    write_json(SITE/'game/resource-map.json',resource_map)
    page=SITE/'game/index.html';html=page.read_text()
    html=html.replace('<html lang="en">','<html lang="zh-CN">')
    html=html.replace('<canvas id="canvas">','<div id="game-surface"><canvas id="canvas">').replace('</canvas>','</canvas></div>',1)
    html=html.replace('<script src="index.js"></script>','<script id="shanhai-resource-map" type="application/json">'+json.dumps(resource_map,separators=(',',':'))+'</script>\n<script src="fast-loader.js?v='+source['sha256']+'" data-version="'+source['sha256']+'"></script>\n\t\t<script src="index.js"></script>')
    html=html.replace('user-scalable=no, initial-scale=1.0','user-scalable=yes, initial-scale=1.0, viewport-fit=cover')
    html=html.replace('const engine = new Engine(GODOT_CONFIG);',"if (window.shanhaiWholeView && window.shanhaiWholeView.active) GODOT_CONFIG.canvasResizePolicy = 0;\nconst engine = new Engine(GODOT_CONFIG);")
    html=html.replace('<script src="index.js"></script>','<script src="mobile-surface.js?v='+REVISION+'"></script>\n<script src="index.js"></script>')
    style='''<style>#status{background:#f5efdc;color:#334e45;font-family:"Microsoft YaHei",system-ui,sans-serif;padding:24px;box-sizing:border-box;gap:20px}#status-splash{display:none!important}.status-heading{font-size:clamp(22px,4vw,34px);text-align:center;line-height:1.6}.status-detail{font-size:14px;line-height:1.8;text-align:center;max-width:600px}#status-progress{position:static;width:min(520px,85%);height:18px;accent-color:#427b6c;margin:0}#status-notice{max-width:700px;white-space:pre-wrap}#status .status-links{display:none;gap:16px;align-items:center}#status[data-mode=notice] .status-links{display:flex}.status-links a,.status-links button{font:inherit;color:#334e45;background:#f5efdc;border:2px solid #334e45;padding:8px 16px;min-height:44px;cursor:pointer;text-decoration:none}</style>'''
    html=html.replace('</head>',style+'\n</head>')
    html=html.replace('</head>','<style>html{height:100%;height:100dvh}body{width:100%;height:100%;box-sizing:border-box;overscroll-behavior:none}#game-surface{position:fixed;left:env(safe-area-inset-left);right:env(safe-area-inset-right);top:env(safe-area-inset-top);height:calc(100% - env(safe-area-inset-top) - env(safe-area-inset-bottom));height:calc(var(--game-height,100dvh) - env(safe-area-inset-top) - env(safe-area-inset-bottom))}#canvas{width:100%!important;height:100%!important;touch-action:none}#status{padding:max(16px,env(safe-area-inset-top)) max(16px,env(safe-area-inset-right)) max(16px,env(safe-area-inset-bottom)) max(16px,env(safe-area-inset-left))}</style>\n</head>')
    transfer=sum(e['gzip_bytes']for e in sizes.values())/1048576
    raw=sum(e['original_bytes']for e in sizes.values())/1048576
    header=f'''<div class="status-heading">山海食肆物语<br>Shanhai Inn</div><div class="status-detail">正在准备有间小馆 / Loading your inn<br>首次约{transfer:.1f} MiB加速资源；兼容方式约{raw:.1f} MiB。<br>First visit: about {transfer:.1f} MiB compressed, or {raw:.1f} MiB in compatibility mode.</div><div class="status-links"><button type="button" id="status-retry">重新尝试 / Retry</button><a href="../">返回首页 / Home</a></div>'''
    html=html.replace('<div id="status">','<div id="status">'+header)
    html=html.replace("const statusNotice = document.getElementById('status-notice');","const statusNotice = document.getElementById('status-notice');\n\tdocument.getElementById('status-retry').addEventListener('click', () => location.reload());")
    html=html.replace("statusMode = mode;","statusMode = mode;\n\t\tstatusOverlay.dataset.mode = mode;",1)
    html=html.replace("const missing = Engine.getMissingFeatures({","if (location.protocol === 'file:') { displayFailureNotice('请通过网站地址打开游戏，不要直接双击HTML。\\nOpen the game through HTTP or HTTPS, not a local HTML file.'); return; }\n\tconst missing = Engine.getMissingFeatures({")
    # Use a literal JavaScript escape inside its quoted string.
    html=html.replace("直接双击HTML。\nOpen the game","直接双击HTML。\\nOpen the game")
    page.write_text(html)
    receipt['original_export_receipt_sha256']=sha256(SOURCE/'export-receipt.json')
    receipt['web_shell']=VERSION;receipt['site_shell_updated_utc']=utc_now()
    for p in (SITE/'game').rglob('*'):
        if not p.is_file()or p.name=='export-receipt.json':continue
        name=p.relative_to(SITE/'game').as_posix();receipt['files'][name]={'bytes':p.stat().st_size,'sha256':sha256(p)}
    write_json(SITE/'game/export-receipt.json',receipt)
    shutil.copyfile(ROOT/'tools/serve_site.py',SITE/'serve.py')
    readme='docs/international-release-r1.md'if REVISION=='web-international-r1'else('docs/mobile-portrait-r9.md'if REVISION=='web-r9-portrait'else'docs/web-site-guide.md')
    shutil.copyfile(ROOT/readme,SITE/'README.md')
    shutil.copytree(ROOT/'web/deploy',SITE/'deploy',dirs_exist_ok=True)
    shutil.copyfile(ROOT/'docs/mainland-hosting-guide.md',SITE/'deploy/README.md')
    shutil.copyfile(ROOT/'docs/classroom-free-hosting.md',SITE/'deploy/FREE-HOSTING.md')
    shutil.copyfile(ROOT/'tools/verify_hosted_site.py',SITE/'deploy/verify-hosted-site.py')
    (SITE/'.nojekyll').write_text('')
    qr_url=args.public_url+'?classroom=1&v='+REVISION
    generator="const fs=require('fs'),qr=require(process.argv[1])(0,'M');qr.addData(process.argv[2]);qr.make();fs.writeFileSync(process.argv[3],qr.createSvgTag({cellSize:8,margin:32,scalable:true}));"
    subprocess.run(['node','-e',generator,str(ROOT/'web/site/vendor/qrcode.js'),qr_url,str(SITE/'classroom-qr-github.svg')],check=True)
    cmd='''@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 serve.py --open-browser
  goto done
)
python --version >nul 2>&1
if not errorlevel 1 (
  python serve.py --open-browser
  goto done
)
echo Python 3 is needed only for this local server.
echo Deploy the site online to let players use it without installing Python.
:done
pause
'''
    (SITE/'Start-Web.cmd').write_bytes(cmd.replace('\n','\r\n').encode('ascii'))
    # Safe defaults for hosts that accept this format; GitHub Pages needs no special headers.
    (SITE/'_headers').write_text('/game/*.wasm\n  Content-Type: application/wasm\n/game/*.pck\n  Content-Type: application/octet-stream\n')
    paths=sorted(p for p in SITE.rglob('*')if p.is_file())
    assert all(p.stat().st_size<=PART_BYTES for p in paths),'A file exceeds the free-host upload profile'
    manifest={'version':VERSION,'created_utc':utc_now(),'game_source':source,'compression':sizes,'resource_map':resource_map,'max_file_bytes':max(p.stat().st_size for p in paths),'classroom_url':qr_url,'files':{p.relative_to(SITE).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p)}for p in paths}}
    write_json(SITE/'site-receipt.json',manifest)
    paths=sorted(p for p in SITE.rglob('*')if p.is_file())
    artifact=None
    if not args.skip_archive:
        artifact=write_zip(BUILD/('shanhai-v1.9.5-'+REVISION+'-site.zip'),[(p,p.relative_to(SITE).as_posix())for p in paths])
        assert artifact['bytes']<100*1024*1024
    write_json(BUILD/REVISION/'site-build.json',{'game_source':source,'artifact':artifact,'compression':sizes})
    print(json.dumps({'artifact':artifact,'compression':sizes},indent=2))
if __name__=='__main__':main()
