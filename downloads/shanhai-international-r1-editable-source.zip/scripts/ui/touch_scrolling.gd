extends RefCounted
## Touch list scrolling also works when a Web browser does not report native touch support.
var host
var scroll: ScrollContainer
var index=-1
var origin=Vector2.ZERO
var initial=Vector2.ZERO
var dragging=false
func _init(owner_ui):host=owner_ui
func _find(node: Node,point: Vector2) -> ScrollContainer:
	if node is Window:return null
	if node is Control:
		if not node.is_visible_in_tree():return null
		if node.clip_contents and not node.get_global_rect().has_point(point):return null
	var children=node.get_children();children.reverse()
	for child in children:
		var found=_find(child,point)
		if found!=null:return found
	if node is ScrollContainer and node.get_global_rect().has_point(point):
		var bar=node.get_v_scroll_bar()
		if bar.max_value>bar.page:return node
	return null
func input(event: InputEvent) -> bool:
	if event is InputEventScreenTouch:
		if event.pressed and index<0 and not host.landscape_required:
			# A local eatery map owns drag/pinch gestures; lists scroll outside it.
			if host.international_ui!=null and is_instance_valid(host.international_ui.map_widget):
				var map=host.international_ui.map_widget
				if map.is_visible_in_tree()and map.get_global_rect().has_point(event.position):return false
			for child in host.get_children():
				if child is Window and child.visible:return false
			scroll=_find(host,event.position)
			if scroll!=null:
				index=event.index;origin=event.position;initial=Vector2(scroll.scroll_horizontal,scroll.scroll_vertical);dragging=false
		elif not event.pressed and event.index==index:
			if dragging and is_instance_valid(scroll):
				scroll.propagate_notification(Control.NOTIFICATION_SCROLL_END);scroll.scroll_ended.emit()
			index=-1;scroll=null;dragging=false
		return false
	if event is InputEventScreenDrag and event.index==index and is_instance_valid(scroll):
		if not dragging and event.position.distance_to(origin)>=8:
			dragging=true;scroll.propagate_notification(Control.NOTIFICATION_SCROLL_BEGIN);scroll.scroll_started.emit()
		if dragging:
			scroll.scroll_vertical=int(initial.y+origin.y-event.position.y)
			return true
	if event is InputEventMouseMotion and event.device==-1 and dragging:return true
	return false
