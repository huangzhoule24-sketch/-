extends Control
## Live local branch view. Campaign state owns progress; this control only draws.
const Art=preload("res://scripts/services/international_art.gd")
var ui
var rid="india"
var inside=true
var preview=""
var camera: Dictionary={"zoom":1.0,"pan":Vector2.ZERO}
var touches={}
var dragging=false
var _elapsed=0.0
func setup(owner_ui,region_id: String,interior=true):
	ui=owner_ui;rid=region_id;inside=interior;camera=ui.cameras.get(rid,{"zoom":1.0,"pan":Vector2.ZERO});ui.cameras[rid]=camera
	custom_minimum_size=Vector2(0,310);size_flags_horizontal=Control.SIZE_EXPAND_FILL;clip_contents=true;mouse_filter=Control.MOUSE_FILTER_STOP;texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
func fit():camera.zoom=1.0;camera.pan=Vector2.ZERO;queue_redraw()
func _process(delta):
	_elapsed+=delta
	queue_redraw()
func _gui_input(event):
	if event is InputEventMouseButton:
		if event.button_index in[MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]and event.pressed:camera.zoom=clampf(float(camera.zoom)*(1.12 if event.button_index==MOUSE_BUTTON_WHEEL_UP else .89),.65,2.8);accept_event()
		elif event.button_index==MOUSE_BUTTON_LEFT:dragging=event.pressed;accept_event()
	elif event is InputEventMouseMotion and dragging:camera.pan+=event.relative;accept_event()
	elif event is InputEventScreenTouch:
		if event.pressed:touches[event.index]=event.position
		else:touches.erase(event.index)
		accept_event()
	elif event is InputEventScreenDrag:
		if touches.size()>=2:
			var ids=touches.keys();var old=Vector2(touches[ids[0]]).distance_to(touches[ids[1]]);touches[event.index]=event.position;var next=Vector2(touches[ids[0]]).distance_to(touches[ids[1]])
			if old>1:camera.zoom=clampf(float(camera.zoom)*next/old,.65,2.8)
		else:camera.pan+=event.relative;touches[event.index]=event.position
		accept_event()
func _point(unit: Vector2,rect: Rect2) -> Vector2:return rect.position+unit*rect.size
func _sprite(texture: Texture2D,foot: Vector2,height: float):
	if texture==null:return
	var ratio=float(texture.get_width())/maxf(1,texture.get_height());draw_texture_rect(texture,Rect2(foot-Vector2(height*ratio/2,height),Vector2(height*ratio,height)),false)
func _draw():
	draw_rect(Rect2(Vector2.ZERO,size),Color("ebe6d6"))
	if ui==null:return
	var texture=Art.store(rid,inside)
	if texture==null:return
	var extent=minf(size.x,size.y)*float(camera.zoom);var rect=Rect2((size-Vector2.ONE*extent)/2+Vector2(camera.pan),Vector2.ONE*extent)
	draw_texture_rect(texture,rect,false)
	if not inside:return
	var rules=ui.rules();var data=rules.region(rid);var layout=preview if not preview.is_empty()else str(data.layout)
	var tables=[Vector2(.30,.51),Vector2(.68,.52),Vector2(.31,.73),Vector2(.67,.73)]
	if rid=="nordic":tables=[Vector2(.32,.43),Vector2(.70,.45),Vector2(.32,.66),Vector2(.70,.68)]
	if rid=="greece":tables=[Vector2(.30,.52),Vector2(.62,.53),Vector2(.28,.73),Vector2(.65,.74)]
	var ink=Color("654d36");var wood=Color("c99a62")if rid!="greece"else Color("baa47b")
	if layout=="sharing":tables=[Vector2(.40,.58),Vector2(.68,.58)]
	if layout=="storage":tables=tables.slice(0,3)
	for index in range(tables.size()):
		var at=_point(tables[index],rect);var dimensions=Vector2(.15,.065)*extent
		if layout=="sharing":dimensions.x*=1.65
		var furniture=Art.furniture(rid,1 if layout=="sharing"else 0)
		if furniture!=null:
			var scale=Vector2(.27 if layout=="sharing"else .22,.18)*extent
			draw_texture_rect(furniture,Rect2(at-scale/2,scale),false)
		else:
			draw_rect(Rect2(at-dimensions/2,dimensions),ink);draw_rect(Rect2(at-dimensions/2+Vector2.ONE*2,dimensions-Vector2.ONE*4),wood)
	if layout=="storage":
		var cabinet=Art.furniture(rid,3 if rid=="nordic"else 4)
		if cabinet!=null:draw_texture_rect(cabinet,Rect2(_point(Vector2(.58,.65),rect),Vector2(.22,.18)*extent),false)
	if not bool(data.open):return
	var characters=rules.definition("regions",rid).characters
	var active=data.partners
	var minute=float(rules.now())+(float(ui.host.model._fraction)if not ui.host.model.paused else 0.0)
	for index in range(active.size()):
		var phase=fposmod(minute*.08+index*.42,1.0);var a=Vector2(.55,.35);var b=Vector2(.52,.70)
		if rid=="nordic":a=Vector2(.60,.29);b=Vector2(.53,.67)
		if rid=="greece":a=Vector2(.80,.30);b=Vector2(.53,.61)
		var foot=_point(a.lerp(b,phase*2 if phase<.5 else(1-phase)*2),rect)
		var frame=1 if ui.host.model.paused else[0,1,2,1][int(minute*2)%4]
		if phase>=.5:frame+=3
		_sprite(Art.walking(str(active[index]),frame),foot,minf(56,extent*.14))
	var count=mini(3,data.orders.size())
	for index in range(count):
		var source=ui.host.assets.get_customer_frames("human","human_%02d"%(index%3+1),"sit","down")
		if not source.is_empty():_sprite(source[index%source.size()],_point(tables[index%tables.size()]+Vector2(.01,.055),rect),minf(44,extent*.105))
	for job in data.jobs:
		if job.kind!="service":continue
		var progress=clampf((minute-float(job.started))/maxf(1,float(job.due)-float(job.started)),0,1)
		var texture_dish=Art.dish(str(job.dish_id));var at=_point(Vector2(.69,.30).lerp(Vector2(.56,.63),progress),rect)
		if texture_dish!=null:draw_texture_rect(texture_dish,Rect2(at-Vector2.ONE*12,Vector2.ONE*24),false)
