extends RefCounted
## Fixed top-down indoor/outdoor map. Projection, pointer coordinates and overlays share one affine map.
const Space=preload("res://scripts/services/restaurant_space.gd")
var view
var zoom=1.0
var camera=Vector2.ZERO
var controls: HBoxContainer
var dragging=false
var pointer_down=false
var press_position=Vector2.ZERO
var touch_index=-1
var touch_used=false
var touches: Dictionary = {}
var pinch_distance=0.0
var gesture_was_pinch=false
var overview=false
var capacity_label: Label
var gesture_hint: Label
var focus_button: Button
var fit_button: Button
var _last_view_size=Vector2.ZERO
var phone_zones: HBoxContainer
func portrait() -> bool:
	var ui=host();return ui!=null and "portrait_layout"in ui and ui.portrait_layout
func _init(owner_view):view=owner_view
func m():return view.model
func host():
	var reference=view.get_meta("presentation_host",null)
	return reference.get_ref() if reference!=null else null
func width() -> float:return Space.world_size(m()).x+24
func world_bounds() -> Rect2:return Rect2(Vector2(-12,-12),Space.world_size(m())+Vector2(24,24))
func content_rect() -> Rect2:
	var top=104 if portrait()else 52
	return Rect2(0,top,view.size.x,maxf(1,view.size.y-top))
func base_scale() -> float:
	var area=content_rect();var vertical=area.size.y/world_bounds().size.y
	if portrait()and not overview:return minf(1.0,maxf(.58,vertical))
	if not overview and view.size.x<1000:vertical=maxf(.55,vertical)
	return maxf(.01,minf(area.size.x/width(),vertical))
func scale_factor() -> float:return base_scale()*zoom
func offset() -> Vector2:
	var scale=scale_factor()
	return content_rect().get_center()-(world_bounds().get_center()+camera)*scale
func project(point: Vector2) -> Vector2:return point
func unproject(point: Vector2) -> Vector2:return point
func to_view(point: Vector2) -> Vector2:return offset()+point*scale_factor()
func to_world(point: Vector2) -> Vector2:return (point-offset())/scale_factor()
func linear_scale() -> Vector2:return Vector2.ONE*scale_factor()
func camera_limits() -> Vector2:
	return ((world_bounds().size-content_rect().size/scale_factor())*.5).max(Vector2.ZERO)
func clamp_camera():
	var limit=camera_limits();camera=camera.clamp(-limit,limit)
func fit_all():
	overview=true;zoom=1.0;camera=Vector2.ZERO;cancel_gesture();view.queue_redraw()
func focus_room(kind: String):
	overview=false;zoom=1.0
	var world=Space.world_size(m());var point=Vector2(world.x*.32,270)
	var items=m().full_rules.dollhouse.fixtures("stove"if kind=="kitchen"else"table")
	if not items.is_empty():
		point=Vector2.ZERO
		for item in items:point+=Space.cell_rect(m(),item.x,item.y,item.w,item.h).get_center()
		point/=items.size()
	if kind=="yard":point=Vector2(world.x*.5,495)
	camera=point-world_bounds().get_center();clamp_camera();cancel_gesture();view.queue_redraw()
func set_zoom(value: float):
	overview=false;zoom=clampf(value,1,3);camera=Vector2.ZERO;view.queue_redraw()
func zoom_at(factor: float,anchor: Vector2):
	var point=to_world(anchor)
	# Keep a common fit baseline, so switching out of the readable phone view
	# cannot introduce an extra jump during a pinch.
	var old_scale=scale_factor();overview=true
	zoom=clampf(old_scale*factor/base_scale(),1,maxf(4,1.65/base_scale()))
	camera=point-world_bounds().get_center()-(anchor-content_rect().get_center())/scale_factor()
	clamp_camera();view.queue_redraw()
func pan(amount: float):pan_by(Vector2(amount,0))
func pan_by(amount: Vector2):
	camera+=amount;clamp_camera();view.queue_redraw()
func cancel_gesture():
	touches.clear();touch_index=-1;pointer_down=false;dragging=false;pinch_distance=0;gesture_was_pinch=false
func text(zh: String,en: String) -> String:
	return en if view.localization!=null and view.localization.language=="en" else zh
func setup_controls():
	if controls!=null:return
	controls=HBoxContainer.new();controls.position=Vector2(4,3);controls.add_theme_constant_override("separation",4);controls.mouse_filter=Control.MOUSE_FILTER_IGNORE;view.add_child(controls)
	var ui=host()
	if ui!=null:
		fit_button=ui.button("",fit_all,false,"scene:fit");fit_button.custom_minimum_size.x=52;controls.add_child(fit_button)
		for entry in [["−",1.0/1.25,"scene:smaller"],["+",1.25,"scene:larger"]]:
			var factor=float(entry[1]);var button=ui.button(str(entry[0]),func():zoom_at(factor,content_rect().get_center()),false,str(entry[2]))
			button.add_theme_font_override("font",preload("res://assets/fonts/DejaVuSans.ttf"));button.custom_minimum_size.x=44;controls.add_child(button)
		focus_button=ui.button("",func():ui.set_scene_focus(not ui.scene_focus),false,"scene:focus");focus_button.custom_minimum_size.x=76;controls.add_child(focus_button)
		for button in controls.get_children():
			button.add_theme_font_size_override("font_size",12)
			for state in ["normal","hover","pressed","disabled"]:
				var skin=button.get_theme_stylebox(state).duplicate();skin.set_content_margin_all(6);button.add_theme_stylebox_override(state,skin)
	gesture_hint=Label.new();gesture_hint.add_theme_font_size_override("font_size",12);gesture_hint.add_theme_color_override("font_color",view.ink);gesture_hint.mouse_filter=Control.MOUSE_FILTER_IGNORE;controls.add_child(gesture_hint)
	capacity_label=Label.new();capacity_label.add_theme_font_size_override("font_size",12);capacity_label.add_theme_color_override("font_color",view.ink);capacity_label.mouse_filter=Control.MOUSE_FILTER_IGNORE;capacity_label.clip_text=true;capacity_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL;controls.add_child(capacity_label)
	phone_zones=HBoxContainer.new();phone_zones.position=Vector2(4,53);phone_zones.add_theme_constant_override("separation",6);view.add_child(phone_zones)
	for zone in [["dining","大厅","Hall"],["kitchen","后厨","Kitchen"],["yard","庭院","Yard"]]:
		if ui==null:continue
		var key=str(zone[0]);var b=ui.button(str(zone[1]),func():focus_room(key),false,"scene:zone:"+key)
		b.custom_minimum_size=Vector2(72,44);b.add_theme_font_size_override("font_size",14);b.set_meta("zone_zh",zone[1]);b.set_meta("zone_en",zone[2]);phone_zones.add_child(b)
	refresh_controls()
func refresh_controls():
	if controls==null:return
	controls.size.x=maxf(1,view.size.x-8)
	var ui=host();var compact=ui!=null and ui.compact_layout
	capacity_label.visible=not portrait()
	if phone_zones!=null:
		phone_zones.visible=portrait()
		for b in phone_zones.get_children():b.text=text(str(b.get_meta("zone_zh")),str(b.get_meta("zone_en")))
	if fit_button!=null:fit_button.text=text("全景","Fit")
	if focus_button!=null:
		focus_button.visible=compact and not ui.decoration_active()
		focus_button.text=text("恢复界面","Show UI") if ui.scene_focus else text("专注视图","Focus")
	gesture_hint.visible=not compact and view.size.x>1000
	gesture_hint.text=text("拖动查看 · 滚轮缩放","Drag to pan · scroll to zoom")
func input(event: InputEvent) -> bool:
	if event is InputEventScreenTouch:
		touch_used=true
		if event.pressed:
			if touches.size()>=2 or touches.has(event.index):return true
			touches[event.index]=event.position
			if touches.size()==1:
				touch_index=event.index;pointer_down=true;dragging=false;press_position=event.position;gesture_was_pinch=false
			else:
				gesture_was_pinch=true;dragging=true;pinch_distance=touches.values()[0].distance_to(touches.values()[1])
		elif touches.has(event.index):
			if touches.size()==1 and pointer_down and not dragging and not gesture_was_pinch and not event.canceled:view.select_employee_at(event.position)
			touches.erase(event.index)
			if touches.is_empty():cancel_gesture()
			else:
				touch_index=int(touches.keys()[0]);press_position=touches[touch_index];pinch_distance=0;dragging=true
		return true
	if event is InputEventScreenDrag:
		if not touches.has(event.index):return true
		var previous: Vector2=touches[event.index];touches[event.index]=event.position
		if touches.size()==2:
			var positions=touches.values();var distance=positions[0].distance_to(positions[1]);var center=(positions[0]+positions[1])*.5
			pan_by(-(event.position-previous)*.5/scale_factor())
			if pinch_distance>1:zoom_at(distance/pinch_distance,center)
			pinch_distance=distance
		else:
			if event.position.distance_to(press_position)>=6:dragging=true
			if dragging:pan_by(-(event.position-previous)/scale_factor())
		return true
	# Godot emits a mouse stream for a finger too; consume that stream once.
	if event is InputEventMouse and (not touches.is_empty() or (touch_used and event.device==-1)):return true
	if event is InputEventMouseButton:
		if event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:
			zoom_at(1.15 if event.button_index==MOUSE_BUTTON_WHEEL_UP else 1.0/1.15,event.position);return true
		if event.button_index in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_MIDDLE]:
			if event.pressed:pointer_down=true;dragging=false;press_position=event.position
			else:
				if pointer_down and not dragging and event.button_index==MOUSE_BUTTON_LEFT:view.select_employee_at(event.position)
				pointer_down=false;dragging=false
			return true
	if event is InputEventMouseMotion and pointer_down:
		if event.position.distance_to(press_position)>=6:dragging=true
		if dragging:pan_by(-event.relative/scale_factor())
		return true
	return false
func draw():
	view.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	view.scene_labels.clear(); view.collect_scene_labels=true; view.scene_text_priority=0
	setup_controls()
	if _last_view_size!=view.size:
		_last_view_size=view.size;cancel_gesture();clamp_camera()
	refresh_controls()
	var rules=m().full_rules.dollhouse;var stoves=rules.fixtures("stove");var tills=rules.fixtures("cashier")
	capacity_label.text="灶台 %d/%d · 收银 %d/%d" % [stoves.filter(func(f):return rules.locked(rules.identity(f))).size(),stoves.size(),tills.filter(func(f):return rules.locked(rules.identity(f))).size(),tills.size()]
	if view.localization!=null:capacity_label.text=view.localization.translate(capacity_label.text)
	var scale=scale_factor();var shift=offset();view.draw_set_transform(shift,0,Vector2.ONE*scale)
	var w=Space.world_size(m()).x;var ground=Space.grid_rect(m());var indoors=Rect2(ground.position,Vector2(ground.size.x,ground.size.y*.8))
	view.box(Rect2(0,60,w,500),Color("c9d6b5"),5)
	var yard=view._asset_texture("Map","floor_yard")
	if yard!=null:view.draw_texture_rect(yard,Rect2(0,60,w,500),true)
	var background=view._asset_texture("Map","restaurant_stage_%d" % int(m().state.stage))
	if background==null:background=view._asset_texture("Map","restaurant")
	if background!=null:view.draw_texture_rect(background,Rect2(0,60,w,500),false)
	view.box(Rect2(0,518,w,42),Color("b7b6ad"),2)
	var street=view._asset_texture("Map","floor_street")
	if street!=null:view.draw_texture_rect(street,Rect2(0,518,w,42),true)
	for x in range(8,int(w),60):view.box(Rect2(x,536,30,3),Color("dedbd0"),0)
	view.box(Rect2(8,430,65,105),Color("b7b6ad"),2)
	view.box(Rect2(28,398,60,32),Color("dbceb0"),2)
	view.box(indoors,Color("ecdfc6"),3)
	var tile=view._asset_texture("Map","floor_wood")
	if tile!=null:view.draw_texture_rect(tile,indoors,true)
	else:
		for x in range(int(indoors.position.x),int(indoors.end.x),32):view.draw_line(Vector2(x,indoors.position.y),Vector2(x,indoors.end.y),Color(.6,.5,.35,.12),1)
		for y in range(int(indoors.position.y),int(indoors.end.y),32):view.draw_line(Vector2(indoors.position.x,y),Vector2(indoors.end.x,y),Color(.6,.5,.35,.12),1)
	view.box(Rect2(indoors.end.x*.65,indoors.position.y,indoors.size.x*.33,indoors.size.y),Color(.56,.69,.61,.15),0)
	var experience=m().state.get("culture_experience",{})
	if bool(experience.get("night",{}).get("active",false)) and not bool(experience.get("reduce_fx",false)):
		view.box(indoors,Color(.12,.18,.32,.12),0)
		for table in rules.fixtures("table"):
			var at=Space.cell_rect(m(),table.x,table.y,table.w,table.h).get_center()
			view.box(Rect2(at+Vector2(-6,-15),Vector2(12,5)),Color("ecd696"),0)
	view.box(Rect2(indoors.position.x,indoors.position.y-10,indoors.size.x,12),Color("759081"),2)
	var wall=view._asset_texture("Map","wall_shop")
	if wall!=null:view.draw_texture_rect(wall,Rect2(indoors.position.x,indoors.position.y-22,indoors.size.x,24),true)
	view.centered_text("用餐区",Vector2(w*.31,78),16,view.ink);view.centered_text("后厨",Vector2(w*.76,78),16,view.ink)
	var sign=view._asset_texture("Map","decor_sign")
	if sign!=null:view.draw_texture_rect(sign,Rect2(0,380,90,105),false)
	else:view.box(Rect2(120,445,135,34),Color("8a795d"),3)
	view.centered_text("有间小馆",Vector2(187,468),16,view.ink)
	view.centered_text("庭院 · 店门",Vector2(w*.52,473),14,view.green)
	for x in [int(w)-50,int(w)-110]:
		var plant=view._asset_texture("Map","decor_plant")
		if plant!=null:view.draw_texture_rect(plant,Rect2(x-8,421,40,62),false)
		else:
			view.box(Rect2(x,455,22,24),Color("b39771"),2);view.draw_circle(Vector2(x+11,451),18,Color("79a27c"))
	var entities = draw_entities()
	for entity in entities:
		view.scene_text_priority = 2 if str(entity.type)=="staff" else 1 if str(entity.type) in ["guest","leaving"] else 0
		match str(entity.type):
			"chair":chair(entity.point,str(entity.get("direction","down")))
			"fixture":fixture(entity.data,project(entity.point),int(entity.number))
			"staff":staff(entity.data,entity.point)
			_:guest(entity.data,project(entity.point),str(entity.type)=="leaving")
	if not view.placement_id.is_empty():placement()
	view.draw_scene_labels(entities)
	view.draw_set_transform(Vector2.ZERO)
	view.box(Rect2(0,0,view.size.x,content_rect().position.y),Color("faf9f3"),0)

func draw_entities() -> Array:
	# A chair is the support behind a seated body, not a foreground occluder.
	# Keeping all chairs in their own back pass also avoids a pop when arrival
	# motion ends a fraction of a pixel behind the seat's Y coordinate.
	var entities: Array=[];var table_number=0
	for item in m().state.layout:
		var center=Space.cell_rect(m(),item.x,item.y,item.w,item.h).get_center()
		if str(item.id) in ["table_two","table_four"]:table_number+=1
		entities.append({"type":"fixture","point":center,"data":item,"number":table_number})
		if str(item.id) in ["table_two","table_four"] and not bool(item.get("building",false)):
			var rectangle=Space.cell_rect(m(),item.x,item.y,item.w,item.h)
			var capacity=4 if str(item.id)=="table_four" else 2
			for seat in range(capacity):entities.append({"type":"chair","point":Space.chair_position(rectangle,seat,capacity),"direction": ["right","left","down","up"][seat]})
	for employee in m().employees:
		if view._actors.has(str(employee.id)):
			var actor=view._actors[str(employee.id)];entities.append({"type":"staff","point":actor.get("display_position",actor.position),"data":employee})
	for guest in m().customers:
		if str(guest.stage)=="cleaning":continue
		entities.append({"type":"guest","point":view.guest_display_position(guest) if view.has_method("guest_display_position") else m().full_rules.dollhouse.guest_position(guest,float(m().state.total_minutes)+m()._fraction),"data":guest})
	for departed in m().state.revision191.departures:
		entities.append({"type":"leaving","point":view.guest_display_position(departed,true) if view.has_method("guest_display_position") else m().motion_position(departed,float(m().state.total_minutes)+m()._fraction),"data":departed})
	for index in range(entities.size()):entities[index]["serial"]=index
	entities.sort_custom(_draws_before)
	return entities

static func _draws_before(a: Dictionary,b: Dictionary) -> bool:
	var a_back=str(a.type)=="chair";var b_back=str(b.type)=="chair"
	if a_back!=b_back:return a_back
	# Subpixel arrival interpolation must not toggle a body behind a tabletop.
	# Sort on the same whole-pixel floor bands as the pixel artwork.
	var a_depth=roundi(float(a.point.y));var b_depth=roundi(float(b.point.y))
	if a_depth!=b_depth:return a_depth<b_depth
	# At equal depth, furniture is drawn before bodies. Explicit serial order
	# makes equal-position crowds deterministic instead of relying on sort stability.
	var priority={"chair":0,"fixture":1,"staff":2,"guest":3,"leaving":4}
	var a_priority=int(priority.get(str(a.type),5));var b_priority=int(priority.get(str(b.type),5))
	if a_priority!=b_priority:return a_priority<b_priority
	return int(a.serial)<int(b.serial)
func fixture(item: Dictionary,p: Vector2,number: int):
	var id=str(item.id);var d=m().full_rules.dollhouse;var kind=d.kind(item)
	var rect=Rect2(p-Vector2(23,30),Vector2(46,40))
	if bool(item.get("building",false)):
		view.box(rect,Color("e6d3a8"),3,Color("bda275"));view.draw_line(rect.position,rect.end,Color("b9955a"),2)
		view.centered_text("施工中",p-Vector2(0,12),12,view.ink);return
	var texture=view._asset_texture("Map",("equip_" if kind in ["stove","pass","cashier","table","upgrade"] else "decor_")+id)
	if texture!=null:
		var table_size=Space.table_extent(Space.cell_rect(m(),item.x,item.y,item.w,item.h))
		var extent=table_size+Vector2(6,12) if kind=="table" else Vector2(72,82)
		var origin=p-Vector2(extent.x*.5,extent.y*.5+12 if kind=="table" else 58)
		view.draw_texture_rect(texture,Rect2(origin,extent),false)
	else:
		match kind:
			"table":
				for x in [-24,24]:view.draw_line(p+Vector2(x,-17),p+Vector2(x,5),Color("9c8063"),5)
				view.box(Rect2(p-Vector2(24,23),Vector2(48,38)),Color("d8ac79"),3,Color("bd925d"))
				view.centered_text("%02d" % number,p-Vector2(0,0),11,Color("7d603e"))
			"stove","pass","cashier","upgrade":
				view.box(rect,Color("899b93") if kind in ["stove","upgrade"] else Color("a5b4a3"),3,Color("677e72"))
				view.box(Rect2(p-Vector2(28,40),Vector2(56,8)),Color("c9d4c4"),2)
				if kind=="stove":
					view.box(Rect2(p-Vector2(17,47),Vector2(34,13)),Color("424e49"),6)
					if d.locked(d.identity(item)):
						view.draw_arc(p-Vector2(0,48),12,0,PI,14,view.orange,4)
						for i in range(2):view.draw_line(p+Vector2(i*9-5,-56),p+Vector2(i*9-5+sin(view.elapsed+i)*3,-68),Color("b6b2a1"),2)
				elif kind=="cashier":
					view.box(Rect2(p-Vector2(17,60),Vector2(34,20)),Color("607b70"),2);view.centered_text("￥",p-Vector2(0,46),14,Color.WHITE)
				elif kind=="pass":view.bowl(p-Vector2(0,43),view.green)
			"promotion":
				view.draw_line(p-Vector2(20,0),p-Vector2(15,60),Color("a48b68"),4);view.draw_line(p+Vector2(20,0),p+Vector2(15,-60),Color("a48b68"),4)
				view.box(Rect2(p-Vector2(24,60),Vector2(48,42)),Color("91ac91"),2);view.centered_text("今日招牌",p-Vector2(0,35),11,Color("fff9de"))
			"rest":view.box(Rect2(p-Vector2(30,25),Vector2(60,25)),Color("a3b695"),6);view.box(Rect2(p-Vector2(31,43),Vector2(62,21)),Color("b9caa8"),5)
			_:
				if id=="lantern":view.box(Rect2(p-Vector2(15,60),Vector2(30,32)),Color("d99e72"),10);view.draw_line(p-Vector2(0,62),p-Vector2(0,81),view.ink,2)
				else:view.box(Rect2(p-Vector2(28,65),Vector2(56,40)),Color("bed0b7"),3);view.centered_text("山海",p-Vector2(0,41),14,view.green)
	if kind!="table":view.centered_text(str(m().full_rules.decoration(id).name).replace("基础",""),p+Vector2(0,17),11,view.ink)
func staff(employee: Dictionary,world: Vector2):
	var actor: Dictionary=view._actors[str(employee.id)];var p=project(world);var action=str(actor.action);var phase=float(actor.phase)*TAU
	var bob=0.0 # Baked rig enforces at most one source pixel of body motion.
	var body=p-Vector2(0,22-bob)
	shadow(p)
	var illustrated=view._draw_employee_frame(employee,actor,action,body,1)
	var handover: Dictionary=m().full_rules.culture_experience.handover(str(employee.id))
	if not handover.is_empty():
		# Two short, steady tray-side marks acknowledge the handover without a face,
		# flashing, another speech balloon or any movement of the seated guest.
		var hand=p+Vector2(16,-35)
		var color=Color("e6c78e") if float(handover.progress)<.5 else Color("8fbba2")
		view.box(Rect2(hand+Vector2(-7,0),Vector2(5,2)),color,0)
		view.box(Rect2(hand+Vector2(2,0),Vector2(5,2)),color,0)
	if not illustrated:
		view.draw_set_transform(offset()+body*scale_factor(),0,Vector2(float(actor.facing),1)*scale_factor())
		view.animal(Vector2.ZERO,m().full_rules.dollhouse.capable(employee,"chef"),bool(actor.get("resting",false)),str(employee.id),str(employee.get("icon","")))
		view.draw_set_transform(offset(),0,Vector2.ONE*scale_factor())
	var facing={"up":Vector2(0,-1),"down":Vector2(0,1),"left":Vector2(-1,0),"right":Vector2(1,0)}.get(str(actor.get("direction","down")),Vector2(0,1))
	var at=p+Vector2(0,16);var side=Vector2(-facing.y,facing.x)*4
	view.draw_colored_polygon(PackedVector2Array([at+facing*7,at-facing*3+side,at-facing*3-side]),Color("647b69"))
	if not illustrated and action in ["Move","Cook","Serve","Clean","Cashier","Promote","Order"]:view._draw_action_prop(actor,body)
	if not illustrated and action=="Order":
		view.box(Rect2(body+Vector2(20,-12),Vector2(16,24)),Color("fcf4d9"),2);view.draw_line(body+Vector2(22,-3),body+Vector2(32,-3),view.green,2)
	if not illustrated and action=="Build":view.draw_line(body+Vector2(10,0),body+Vector2(25+sin(phase)*8,-12),view.ink,3)
	var labels={"Idle":"待命","Move":"行走","Cook":"炒菜","Serve":"上菜","Clean":"清台","Cashier":"收银","Promote":"宣传","Order":"点单","Rest":"休息","Build":"施工"}
	var label=str(labels.get(action,action))
	if not handover.is_empty():label="交接"
	if int(actor.get("task_count",0))>1:label+="×%d" % int(actor.task_count)
	view.centered_text(str(employee.name)+"·"+label,p-Vector2(0,82),12,view.ink)
	view.box(Rect2(p-Vector2(18,-9),Vector2(36,3)),Color("d6c9b1"),1)
	view.box(Rect2(p-Vector2(18,-9),Vector2(36*float(employee.get("stamina",100))/100,3)),view.green,1)
func guest(data: Dictionary,p: Vector2,leaving: bool):
	var motion: Dictionary=data.get("checkout_motion",data.get("arrival_motion",data.get("motion",{})))
	var walking=not motion.is_empty() and float(m().state.total_minutes)+m()._fraction<float(motion.get("started",0))+float(motion.get("travel_minutes",0))
	var action="walk" if walking else "eat" if data.get("stage")=="eating" else "sit" if data.get("stage") in ["ordering","queued","cooking","serving"] else "idle"
	var direction="down"
	if walking:
		var at=float(m().state.total_minutes)+m()._fraction;var previous=m().motion_position({"motion":motion},at-.01);var current=m().motion_position({"motion":motion},at);var delta=current-previous
		direction=("right" if delta.x>0 else "left") if absf(delta.x)>=absf(delta.y) else ("down" if delta.y>0 else "up")
	var kind={"human":"human","monster":"demon","descendant":"beastkin"}.get(str(data.get("type","human")),"human")
	var appearance="%s_%02d" % [kind,int(data.id)%3+1]
	if data.has("visitor_id"):kind="special";appearance=str(preload("res://scripts/ui/art_targets.gd").GUEST_IDS.get(str(data.visitor_id),str(data.visitor_id)))
	var image=null
	if view.assets!=null:
		var frames=view.assets.get_customer_frames(kind,appearance,action,direction)
		if not frames.is_empty() and not view.assets.is_placeholder(frames[0]):image=frames[int(view.elapsed*6)%frames.size()]
	if image==null and data.has("visitor_id"):image=view._asset_texture("Characters","guest_"+str(data.visitor_id)+"_idle")
	if not walking and action in ["sit","eat"]:
		direction="down"
		var table=m().full_rules.dollhouse.table_for(data)
		if not table.is_empty():
			var center=Space.cell_rect(m(),table.x,table.y,table.w,table.h).get_center()
			var to_table=center-p
			direction=("right" if to_table.x>0 else "left") if absf(to_table.x)>=absf(to_table.y) else ("down" if to_table.y>0 else "up")
			if view.assets!=null:
				var frames=view.assets.get_customer_frames(kind,appearance,action,direction)
				if not frames.is_empty() and not view.assets.is_placeholder(frames[0]):image=frames[int(view.elapsed*6)%frames.size()]
	if image!=null:
		var anchor=Vector2(32,61) if not walking and action in ["sit","eat"] else Vector2(32,77)
		shadow(p)
		var lift=preload("res://scripts/services/art_motion.gd").lift(appearance,action) if walking or action=="idle" else 0.0
		view.draw_texture_rect(image,Rect2(p-anchor-Vector2(0,lift),Vector2(64,80)),false)
	else:
		view.draw_circle(p-Vector2(0,27),14,Color("a4b9ad"))
		view.box(Rect2(p-Vector2(12,16),Vector2(24,20)),Color("b5c5b3"),4)
	var title="离店" if leaving else {"ordering":"点单","queued":"等餐","cooking":"等餐","serving":"上菜","eating":"用餐","paying":"结账"}.get(str(data.get("stage","")),"食客")
	if data.get("culture_booking_id","")=="lin": title="Lin · "+str(title)
	# Ordinary guest status remains in the hover tooltip; avoid a full screen of repeated labels.
	if data.has("visitor_id") or data.get("culture_booking_id","")=="lin" or (view.get_local_mouse_position()-to_view(p)).length()<24:
		view.centered_text(str(title),p-Vector2(0,82),11,view.green)
	if data.has("visitor_id"):
		var marker=view._asset_texture("FX","icon_special_guest")
		if marker!=null:view.draw_texture_rect(marker,Rect2(p+Vector2(12,-50),Vector2(20,20)),false)
		else:view.centered_text("★",p+Vector2(20,-34),14,view.orange)
	if data.get("stage")=="eating":
		var dish=view._asset_texture("Dishes",str(data.dish_id))
		if dish!=null:
			var table=m().full_rules.dollhouse.table_for(data)
			var at=p+Vector2(0,-18)
			if not table.is_empty():at=p.lerp(Space.cell_rect(m(),table.x,table.y,table.w,table.h).get_center(),.55)+Vector2(0,-18)
			view.draw_texture_rect(dish,Rect2(at-Vector2(12,12),Vector2(24,24)),false)
		else:view.bowl(p+Vector2(22,-6),view.orange)
func placement():
	var dimensions=view.grid_dimensions()
	for x in range(dimensions.x):
		for y in range(dimensions.y):
			var rect=view.cell_rect(x,y);var p=project(rect.position);var extent=rect.size
			view.box(Rect2(p,extent).grow(-1),Color(.4,.64,.5,.08),1,Color(.4,.64,.5,.3))
	if view.preview_cell.x<0:return
	var definition=view._decoration_entry(view.placement_id);var rect=view.cell_rect(view.preview_cell.x,view.preview_cell.y,int(definition.get("width",1)),int(definition.get("height",1)))
	var p=project(rect.position);var extent=rect.size
	var color=Color("528575") if view._placement_allowed() else Color("c1765d")
	view.box(Rect2(p,extent).grow(-1),Color(color,.32),2,color);view.centered_text("可放" if view._placement_allowed() else "不可放",p+extent*.5+Vector2(0,5),12,view.ink)

func chair(point: Vector2,direction: String="down"):
	var texture=view._asset_texture("Map","chair_"+direction)
	if texture!=null:
		view.draw_texture_rect(texture,Rect2(point-Vector2(23,44),Vector2(46,62)),false);return
	# Pixel geometry keeps all four chairs upright; a rotated front sprite would be upside down.
	var dark=Color("493b31");var wood=Color("926643");var light=Color("c2945d")
	for x in [-17,13]:view.box(Rect2(point+Vector2(x,0),Vector2(5,18)),dark,0)
	view.box(Rect2(point+Vector2(-22,-17),Vector2(44,24)),dark,0)
	view.box(Rect2(point+Vector2(-19,-14),Vector2(38,17)),wood,0)
	view.box(Rect2(point+Vector2(-16,-12),Vector2(32,4)),light,0)
	var back=Rect2(point+Vector2(-23 if direction=="right" else 14,-42),Vector2(9,43)) if direction in ["left","right"] else Rect2(point+Vector2(-22,-43 if direction=="down" else -5),Vector2(44,16))
	view.box(back,dark,0);view.box(back.grow(-3),wood,0)
	if direction in ["up","down"]:view.box(Rect2(back.position+Vector2(4,3),Vector2(36,3)),light,0)

func shadow(point: Vector2):
	var texture=view._asset_texture("FX","shadow")
	if texture!=null:view.draw_texture_rect(texture,Rect2(point-Vector2(16,3),Vector2(32,12)),false)
