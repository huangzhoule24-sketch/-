extends RefCounted

## Read-only cultural context. Opening an entry never changes campaign unlocks.
const Catalog = preload("res://scripts/services/culture_catalog.gd")
const PINYIN_FONT = preload("res://assets/fonts/DejaVuSans.ttf")
const SUPPLEMENT = preload("res://assets/fonts/ShanhaiCJKSupplement.otf")
const Composition = preload("res://scripts/ui/portrait_composition.gd")
const GREEN = Color("427b6c")
const MUTED = Color("718078")
var host
var catalog = Catalog.new()
var kind: String = ""
var entry_id: String = ""
var entry: Dictionary = {}
var image_available: bool = false
var text_font: Font
var language: String = "zh"
var preferences_path: String
var image_resource_id: String = ""
var image_crop: Dictionary = {}
var image_style: String = "dedicated"
var regional_sources_open=false
const RegionalArt=preload("res://scripts/services/international_art.gd")

func _init(ui, preferences: String = "user://culture_preferences.cfg") -> void:
	host = ui
	preferences_path = preferences
	var settings = ConfigFile.new()
	if settings.load(preferences_path) == OK:
		language = str(settings.get_value("reading","language","zh"))
	if not language in ["zh","en"]: language = "zh"
	# Local fallback keeps uncommon quoted characters without changing the theme.
	text_font = host.FONT.duplicate()
	text_font.fallbacks = [preload("res://assets/fonts/NotoSansSC.otf"), SUPPLEMENT, PINYIN_FONT]

func select_entry(next_kind: String, id: String) -> bool:
	var candidate: Dictionary = catalog.get_entry(next_kind, id)
	if candidate.is_empty(): return false
	if entry_id!=id:regional_sources_open=false
	kind = next_kind
	entry_id = id
	entry = candidate
	return true

func render() -> void:
	if entry.is_empty(): return
	host._culture_back.text = "返回 / Back"
	var language_bar = host.row(8)
	host.modal_body.add_child(language_bar)
	for code in ["zh","en"]:
		var target = str(code)
		var control = host.button("中文" if target == "zh" else "English",func():set_language(target),target==language,"culture:language:"+target)
		control.name = "CultureLanguage_"+target
		language_bar.add_child(control)
	var reading: Dictionary = entry.get("en",entry) if language == "en" else entry
	var overview = host.row(16)
	host.modal_body.add_child(overview)
	var image_box: PanelContainer = host.card()
	image_box.name = "CultureImage"
	image_box.custom_minimum_size = Vector2(108, 140) if host.compact_layout else Vector2(164, 184)
	overview.add_child(image_box)
	var texture: Texture2D = host.assets.culture_texture(kind, entry_id)
	image_resource_id = host.assets.culture_resource_id(kind, entry_id)
	image_crop = {}
	image_style = "dedicated"
	# Reuse a complete pixel idle frame, not the old pre-cropped lore icon.
	# Imported lore art and new full-size built-in lore art keep their independent channel.
	var regional=RegionalArt.lore(kind,entry_id)
	if regional!=null:
		texture=regional;image_style="pixel"if kind=="employees"else"dedicated";image_resource_id="International/"+entry_id
	var legacy_icon = texture != null and texture.get_width() <= 48 and texture.get_height() <= 42
	if regional==null and (legacy_icon or not host.assets.has_image(image_resource_id)) and str(host.assets.get_resource_info(image_resource_id).get("custom_path","")).is_empty():
		var pixel: Texture2D
		var pixel_id = ""
		if kind in ["employee","employees"]:
			pixel = host.assets.get_frame(entry_id,"idle","down",0)
			pixel_id = "Sprites/"+entry_id+"/idle_down_0"
		elif kind in ["guest","guests"]:
			var guest_id = str(preload("res://scripts/ui/art_targets.gd").GUEST_IDS.get(entry_id,entry_id))
			pixel = host.assets.get_customer_frames("special",guest_id,"idle","down")[0]
			pixel_id = "Sprites/customer/"+guest_id+"/"+guest_id+"_idle_down_0"
		if pixel != null and not host.assets.is_placeholder(pixel):
			texture = pixel
			image_resource_id = pixel_id
			image_style = "pixel"
	image_available = texture != null and not host.assets.is_placeholder(texture)
	if image_available:
		var picture = TextureRect.new()
		picture.name = "CultureArtwork"
		if image_style == "pixel":
			var crop = Composition.pixel_region(texture)
			picture.texture = Composition.cropped_texture(texture,crop)
			picture.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			image_crop = {"x":crop.position.x,"y":crop.position.y,"w":crop.size.x,"h":crop.size.y}
		else:
			picture.texture = texture
		picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		picture.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		image_box.add_child(picture)
	else:
		var placeholder_text=str(entry.get("name","山海")).left(1)+"\n图像待补充" if language=="zh" else str(reading.get("name",entry_id)).left(1)+"\nArtwork pending"
		var placeholder: Label = _text(image_box,placeholder_text,20,GREEN)
		placeholder.name = "CultureImagePlaceholder"
		placeholder.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		placeholder.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var introduction: VBoxContainer = host.column(8)
	introduction.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	overview.add_child(introduction)
	_text(introduction, str(entry.get("name", entry_id)), 25, GREEN)
	if language == "en": _text(introduction,str(reading.get("name","")),18,GREEN)
	if not str(entry.get("pinyin", "")).is_empty():
		var pinyin_label: Label = _text(introduction, str(entry.pinyin), 15, MUTED)
		pinyin_label.name = "CulturePinyin"
		pinyin_label.add_theme_font_override("font", PINYIN_FONT)
	_text(introduction,str(reading.get("summary","")),16)
	for section in reading.get("sections",[]):
		var body = _section(str(section.title))
		_text(body,str(section.text),16)
	if not entry.get("quotes",[]).is_empty():
		var body = _section("典籍里的原貌" if language == "zh" else "A closer reading of the old texts")
		for quote in entry.quotes:
			var attribution = str(quote.get("source_label_en","")) if language == "en" else str(quote.get("source_label",""))
			if not attribution.is_empty(): _text(body,attribution,16,GREEN)
			if language == "zh" and not str(quote.get("context","")).is_empty():
				_text(body,str(quote.context),15)
			_text(body,"“"+str(quote.text)+"”",17,GREEN)
			if language == "zh" and not str(quote.get("paraphrase","")).is_empty():
				_text(body,str(quote.paraphrase),15)
			if language == "en":
				_text(body,str(quote.get("translation","")),15)
				var info: Dictionary=quote.get("translation_info",{})
				if not info.is_empty():
					_text(body,"— "+str(info.get("credit","")),13,MUTED)
					var edition: Dictionary=catalog.data.get("translation_editions",{}).get(str(info.get("edition_id","")),{})
					if not edition.is_empty():
						var source_url=str(edition.get("url",""))
						if catalog.safe_source_url(source_url):
							var index=entry.quotes.find(quote)
							body.add_child(host.button("Translation source · "+str(info.get("locator","")),func():host.open_culture_source(source_url),false,"culture:translation-source:"+str(index)))
			if attribution.is_empty(): _text(body,"— "+_source_short(str(quote.source_id)),13,MUTED)

	if entry.has("international_region"):
		var toggle=host.button(("收起出处与创作说明"if regional_sources_open else"查看出处与创作说明")if language=="zh"else("Hide references"if regional_sources_open else"References and adaptation"),func():regional_sources_open=not regional_sources_open;host.open_panel("文化简介",false),false,"source:international:toggle")
		host.modal_body.add_child(toggle)
		if regional_sources_open:
			var sources=_section("资料与创作说明"if language=="zh"else"Sources and original adaptation")
			_text(sources,"岗位、合作事件与餐馆经历为游戏原创；下列为参考书目/资料入口，非逐段校勘的原文引文。"if language=="zh"else"The occupations, cooperation and restaurant lives are game fiction. These are research references, not verified verbatim quotations.",14,MUTED)
			for source in catalog.sources_for(entry):
				var url=str(source.url);var title=str(source.get("work_en",source.title))if language=="en"else str(source.title)+" · "+str(source.chapter)
				sources.add_child(host.button(title,func():host.open_culture_source(url),false,"source:international:"+str(source.id)))

func set_language(value: String) -> void:
	if not value in ["zh","en"] or value == language: return
	language = value
	var settings = ConfigFile.new()
	settings.set_value("reading","language",language)
	if settings.save(preferences_path) == OK and OS.has_feature("web"): JavaScriptBridge.force_fs_sync()
	if host.panel_name == "文化简介":
		host.open_panel("文化简介",false)
		host.modal_body.get_parent().set_deferred("scroll_vertical",0)

func brief(value: String,maximum: int=5) -> String:
	var pieces=value.replace("！","。").replace("？","。").split("。",false)
	return "。".join(pieces.slice(0,maximum))+("。" if not pieces.is_empty() else "")

func snapshot() -> Dictionary:
	var reading: Dictionary = entry.get("en",entry) if language == "en" else entry
	var titles: Array[String] = []
	for section in reading.get("sections", []): titles.append(str(section.get("title", "")))
	var urls: Array[String] = []
	for source in catalog.sources_for(entry): urls.append(str(source.get("url", "")))
	return {"kind":kind, "id":entry_id, "name":str(entry.get("name", "")), "summary":str(reading.get("summary", "")), "language":language,"reading_version":int(entry.get("reading_version",1)),"quote_count":entry.get("quotes",[]).size(),"paraphrase_count":entry.get("quotes",[]).filter(func(q):return not str(q.get("paraphrase","")).is_empty()).size(),"origin_label":str(entry.get("origin_label", "")), "section_titles":titles, "source_urls":urls, "source_count":urls.size(), "image_available":image_available, "resource_id":host.assets.culture_resource_id(kind, entry_id),"image_resource_id":image_resource_id,"image_crop":image_crop,"image_style":image_style}

func _source_short(id: String) -> String:
	for source in catalog.sources_for(entry):
		if str(source.get("id", "")) == id:
			if language == "en": return str(source.get("work_en",source.get("work","")))
			var work: String = str(source.get("work", source.get("title", "")))
			var chapter: String = str(source.get("chapter", ""))
			return work + ("·" + chapter if not chapter.is_empty() else "")
	return id

func _section(title: String) -> VBoxContainer:
	var panel: PanelContainer = host.card()
	host.modal_body.add_child(panel)
	var body: VBoxContainer = host.column(8)
	panel.add_child(body)
	_text(body, title, 18, GREEN)
	return body

func _text(parent: Node, text: String, font_size: int = 16, color: Color = Color("30493f")) -> Label:
	# Construct deliberate reading text directly: the interface factory would
	# otherwise attempt to translate the preserved Chinese before we restore it.
	var result=Label.new()
	result.add_theme_font_size_override("font_size",font_size)
	result.add_theme_color_override("font_color",color)
	# Reading language is independent: quoted originals and a deliberate Chinese
	# reading must not be translated by the global interface factory.
	result.text = text
	result.set_meta("l10n_source",text)
	result.set_meta("l10n_last",text)
	result.add_theme_font_override("font", text_font)
	result.set_meta("culture_body_text", true)
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(result)
	return result
