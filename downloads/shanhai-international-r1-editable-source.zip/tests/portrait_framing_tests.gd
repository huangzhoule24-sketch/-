extends SceneTree
const Composition = preload("res://scripts/ui/portrait_composition.gd")
const Frame = preload("res://scripts/ui/portrait_frame.gd")
const Harness = preload("res://tests/culture_ui_tests.gd").Harness
var checks = 0
var failures = 0
func _init(): call_deferred("run")
func expect(ok: bool, message: String):
	checks += 1
	if not ok: failures += 1;push_error(message)
func named(node: Node, target: String) -> Node:
	if node.is_queued_for_deletion(): return null
	if str(node.name) == target: return node
	for child in node.get_children():
		var result = named(child,target)
		if result != null: return result
	return null
func settle():
	await process_frame
	await process_frame
	await process_frame
func run():
	root.size = Vector2i(1440,900)
	var ui = Harness.new();root.add_child(ui);await settle()
	var baseline = [ui.model.state.cash,ui.model.state.total_minutes,ui.model.state.unlocked_dishes.duplicate(),ui.model.employees.duplicate(true)]
	var random_state = ui.model._rng.state
	var frame = Frame.new();frame.assets = ui.assets
	for employee in ui.model.catalog:
		var id = str(employee.id);frame.character_id = id
		var texture = ui.assets.get_portrait(id)
		var extent = texture.get_size()
		var protected = Rect2(Composition.UPPER_BODY.position*extent,Composition.UPPER_BODY.size*extent)
		for aspect in [168.0/184,88.0/96,108.0/140,.15,4.0]:
			var source = frame.head_crop(texture,aspect)
			expect(source.position.y == 0 and source.grow(.01).encloses(protected),"Keep head and torso: "+id+" / "+str(aspect))
			expect(Rect2(Vector2.ZERO,extent).grow(.01).encloses(source),"Source stays inside image: "+id)
			var window = Rect2(10,10,168,184)
			var destination = Composition.destination(window,source.size)
			expect(window.grow(.01).encloses(destination) and is_equal_approx(destination.size.x/destination.size.y,source.size.x/source.size.y),"No stretching or drawing outside frame: "+id)
		ui.open_culture("employees",id);await settle()
		var picture = named(ui.modal_body,"CultureArtwork")
		expect(picture != null and picture.texture is AtlasTexture and picture.texture.atlas == ui.assets.get_frame(id,"idle","down",0).atlas and picture.texture_filter == CanvasItem.TEXTURE_FILTER_NEAREST,"Real culture panel uses matching pixel character: "+id)
		var pixel = ui.assets.get_frame(id,"idle","down",0)
		var used = Rect2(pixel.get_image().get_used_rect())
		expect(Composition.pixel_region(pixel).encloses(used),"Pixel crop includes every head/body pixel: "+id)
		var shot = ui.culture_panel.snapshot()
		expect(shot.image_resource_id == "Sprites/"+id+"/idle_down_0" and shot.image_style == "pixel","Real culture page uses the complete idle-frame channel: "+id)
		ui.return_from_culture();await settle()
	for guest in ui.model.full_rules.visitors.definitions():
		var id = str(guest.id)
		ui.model.state.special_visitors.records[id] = {"met":1,"best":"portrait test fixture"}
		ui.open_culture("guests",id);await settle()
		var guest_shot = ui.culture_panel.snapshot()
		expect(guest_shot.image_style == "pixel" and guest_shot.image_resource_id.begins_with("Sprites/customer/"),"Guest cultural page also uses a complete pixel figure: "+id)
		var guest_picture = named(ui.modal_body,"CultureArtwork")
		expect(guest_picture != null and guest_picture.texture_filter == CanvasItem.TEXTURE_FILTER_NEAREST,"Guest pixels stay sharp: "+id)
	# Import channels must still show deliberately supplied full illustrations without recropping.
	var original_assets = ui.assets
	var custom_assets = preload("res://scripts/services/asset_catalog.gd").new("res://assets/art","/tmp/portrait-framing-"+str(Time.get_ticks_usec()))
	var solid = Image.create(96,160,false,Image.FORMAT_RGBA8);solid.fill(Color.GREEN)
	expect(custom_assets.import_image(solid.save_png_to_buffer(),"Characters/feng_huang_lore.png").ok,"Dedicated lore channel imports")
	ui.assets = custom_assets;ui.open_culture("employees","feng_huang");await settle()
	var custom_picture = named(ui.modal_body,"CultureArtwork")
	expect(custom_picture.texture.get_size() == Vector2(96,160) and ui.culture_panel.snapshot().image_crop.is_empty(),"Dedicated custom lore is contained whole")
	expect(custom_assets.import_image(solid.save_png_to_buffer(),"Portraits/bi_fang.png").ok,"Custom portrait channel imports")
	frame.assets = custom_assets;frame.character_id = "bi_fang"
	expect(frame.head_crop(custom_assets.get_portrait("bi_fang"),.9) == Rect2(0,0,96,160),"Imported portrait keeps its entire face regardless of placement")
	var builtin_root = "/tmp/portrait-builtin-"+str(Time.get_ticks_usec())
	DirAccess.make_dir_recursive_absolute(builtin_root+"/Characters")
	DirAccess.make_dir_recursive_absolute(builtin_root+"/Portraits")
	solid.save_png(builtin_root+"/Characters/feng_huang_lore.png")
	DirAccess.copy_absolute("res://assets/art/Portraits/feng_huang.png",builtin_root+"/Portraits/feng_huang.png")
	ui.assets = preload("res://scripts/services/asset_catalog.gd").new(builtin_root,builtin_root+"/custom")
	ui.open_culture("employees","feng_huang");await settle()
	expect(named(ui.modal_body,"CultureArtwork").texture.get_size() == Vector2(96,160) and ui.culture_panel.snapshot().image_resource_id == "Characters/feng_huang_lore","New full-size built-in cultural art also keeps its own channel")
	ui.assets = original_assets
	expect([ui.model.state.cash,ui.model.state.total_minutes,ui.model.state.unlocked_dishes,ui.model.employees] == baseline and ui.model._rng.state == random_state,"Reading and framing leave the economy, employees, recipe unlocks and RNG untouched")
	frame.free();ui.queue_free();await settle()
	var report = {"checks":checks,"failures":failures,"employees":30,"sizes_per_employee":5}
	FileAccess.open("res://build/portrait-framing-tests.json",FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("Portrait framing: ",JSON.stringify(report));quit(1 if failures else 0)
