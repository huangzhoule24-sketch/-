# 山海食肆物语 · 跨国食肆可编辑源码

SH-SOURCE-INTERNATIONAL-R1 · Godot 4.6.3

解压后用Godot 4.6.3导入project.godot，等待资源导入并运行主场景。包含当前完整运行美术、字体、音频、原主店和印度/北欧/希腊内容；不需要额外母图包即可运行。本轮11张新美术母图直接在assets/art/International中，图集取景由international_art.gd配置。

新内容入口：完成白泽六步引导→更多→跨国食肆。正式经营解锁，文化图鉴可提前读。默认自动交付，循环备料需主动开启并照常付款。存档与同一浏览器已部署网站的存档分别保存。

scripts/core/international_rules.gd是当地经营；scripts/ui/international_panel.gd与international_scene.gd是界面与镜头；config/international*.json由tools/build_international_content.py整理。文化资料、游戏改编与AI美术制作见docs/international-art-process.md。

命令行检查：godot --headless --path . --script tests/international_tests.gd；界面检查使用tests/international_ui_tests.gd。浏览器检查另外需要Node/Playwright/Chromium。

导出网站或Windows时安装Godot 4.6.3对应的标准导出模板，并用export_presets.cfg预设导出。旧发布工具可能引用本工程以外的历史构建缓存；在新电脑不要直接依赖这些旧缓存。源码是编辑工程，不能把它直接作为WorkBuddy的静态网站部署；使用另提供的完整网页运行包。

包内不含私人PPT、聊天记录、项目日记、登录凭据、玩家存档、Git历史或Godot导入缓存。原素材许可见assets/audio/CREDITS.md、assets/fonts及tools/licenses。新美术使用图像生成，文化资料仍可继续校勘和邀请当地读者审阅。
