extends Control
## A small first frame before loading the complete game. No campaign changes.
const GAME_SCENE="res://scenes/main.tscn"
const Metrics=preload("res://scripts/services/startup_metrics.gd")
const FONT=preload("res://assets/fonts/DejaVuSans.ttf")
var progress_bar: ProgressBar
var status: Label
var retry: Button
var _loading=false
var _started=Time.get_ticks_msec()
var _warning_shown=false
func _ready():
	Metrics.mark("loading_screen_ready")
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var background=ColorRect.new()
	background.color=Color("ede9d6")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var center=CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var column=VBoxContainer.new()
	column.custom_minimum_size=Vector2(520,0)
	column.add_theme_constant_override("separation",24)
	center.add_child(column)
	var title=Label.new()
	title.text="SHANHAI INN"
	title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size",30)
	column.add_child(title)
	progress_bar=ProgressBar.new()
	progress_bar.custom_minimum_size=Vector2(520,20)
	progress_bar.show_percentage=false
	column.add_child(progress_bar)
	status=Label.new()
	status.text="Preparing your inn..."
	status.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(status)
	retry=Button.new()
	retry.text="Retry loading"
	retry.visible=false
	retry.pressed.connect(_begin_loading)
	column.add_child(retry)
	var loading_theme=Theme.new()
	loading_theme.default_font=FONT
	loading_theme.default_font_size=18
	loading_theme.set_color("font_color","Label",Color("3a5a63"))
	theme=loading_theme
	get_window().title="Shanhai Inn"
	if OS.has_feature("windows") and DisplayServer.get_name()!="headless":
		var usable=DisplayServer.screen_get_usable_rect()
		if usable.size.x>=640 and usable.size.y>=480:
			get_window().size=get_window().size.min(usable.size-Vector2i(32,48))
			get_window().position=usable.position+(usable.size-get_window().size)/2
	# Let the operating system present a real window before parsing game scripts.
	await get_tree().process_frame
	await get_tree().process_frame
	Metrics.mark("loading_screen_presented")
	_begin_loading()
func _begin_loading():
	retry.hide()
	_warning_shown=false
	_started=Time.get_ticks_msec()
	status.text="Loading the complete game..."
	var error=ResourceLoader.load_threaded_request(GAME_SCENE,"PackedScene")
	_loading=error==OK
	if not _loading:_failed("Unable to start loading ("+str(error)+").")
func _process(_delta):
	if not _loading:return
	var progress=[]
	var state=ResourceLoader.load_threaded_get_status(GAME_SCENE,progress)
	if not progress.is_empty():progress_bar.value=clampf(float(progress[0])*95,0,95)
	match state:
		ResourceLoader.THREAD_LOAD_LOADED:
			Metrics.mark("game_resources_loaded")
			_loading=false
			status.text="Opening your inn..."
			progress_bar.value=100
			var scene=ResourceLoader.load_threaded_get(GAME_SCENE) as PackedScene
			if scene==null:_failed("The game scene could not be read.");return
			await get_tree().process_frame
			var error=get_tree().change_scene_to_packed(scene)
			if error!=OK:_failed("Unable to open the game ("+str(error)+").")
		ResourceLoader.THREAD_LOAD_FAILED,ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			_failed("Loading failed. Extract the entire ZIP and retry.")
	if not _warning_shown and Time.get_ticks_msec()-_started>15000:
		_warning_shown=true
		status.text="Still loading. Please wait; your save is unchanged."
func _failed(message:String):
	_loading=false
	status.text=message
	retry.show()
	push_error(message)
