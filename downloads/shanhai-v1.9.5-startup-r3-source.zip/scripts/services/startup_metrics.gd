extends RefCounted
## Diagnostic timings only: never inspect or modify a campaign save.
static var stages: Dictionary={}
static func mark(stage:String):
	stages[stage]=Time.get_ticks_msec()
static func finish():
	mark("welcome_presented")
	var report={"version":"SH-STARTUP-R3","godot":Engine.get_version_info().string,"os":OS.get_name(),"rendering_driver":RenderingServer.get_current_rendering_driver_name(),"stages_ms_since_engine_start":stages.duplicate(),"complete":true}
	var file=FileAccess.open("user://startup-report.json",FileAccess.WRITE)
	if file!=null:file.store_string(JSON.stringify(report,"  "));file.close()
	print("SHANHAI_STARTUP ",JSON.stringify(report))
