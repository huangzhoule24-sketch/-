extends RefCounted
## Global presentation preference, independent from campaign state and simulation RNG.
var language: String="zh"
var path: String
var data: Dictionary={}
var cache: Dictionary={}
var patterns: Array=[]
var untranslated: Dictionary={}
var chinese=RegEx.new()
func _init(preferences: String="user://interface_language.cfg") -> void:
	path=preferences
	var parsed=JSON.parse_string(FileAccess.get_file_as_string("res://config/localization.json"))
	if parsed is Dictionary: data=parsed
	chinese.compile("[\\x{3400}-\\x{9fff}]")
	var file=ConfigFile.new()
	if file.load(path)==OK: language=str(file.get_value("interface","language","zh"))
	else:
		var old=ConfigFile.new()
		if old.load("user://culture_preferences.cfg")==OK: language=str(old.get_value("reading","language","zh"))
	if not language in ["zh","en"]: language="zh"
	TranslationServer.set_locale(language)

func _ensure_patterns() -> void:
	if not patterns.is_empty():return
	for item in data.get("patterns",[]):
		var regex=RegEx.new()
		if regex.compile(str(item.regex))==OK: patterns.append({"regex":regex,"en":str(item.en)})
func set_language(code: String) -> bool:
	if not code in ["zh","en"]: return false
	language=code
	TranslationServer.set_locale(code)
	var file=ConfigFile.new();file.set_value("interface","language",code)
	return file.save(path)==OK
func field(value: Variant) -> String:
	if value is Dictionary: return str(value.get(language,value.get("zh","")))
	return translate(str(value))

func _known_prefix(source: String, exact: Dictionary) -> String:
	# Composite event feedback appends deltas to complete option sentences.
	# Choose the longest registered sentence at a structural boundary so an
	# option's internal colon/semicolon is never mistaken for an outer split.
	var boundaries: Array=[]
	for separator in ["；","：","，"," · "," / ","·"]:
		var position=source.find(separator)
		while position>0:
			boundaries.append({"position":position,"separator":separator})
			position=source.find(separator,position+separator.length())
	boundaries.sort_custom(func(a,b):return int(a.position)>int(b.position))
	for boundary in boundaries:
		var prefix=source.left(int(boundary.position))
		if exact.has(prefix):
			var separator=str(boundary.separator)
			var joiner=": " if separator=="：" else "; " if separator=="；" else ", " if separator=="，" else " · " if separator=="·" else separator
			return str(exact[prefix])+joiner+translate(source.substr(int(boundary.position)+separator.length()))
	return ""

func translate(source: String) -> String:
	if language!="en" or source.strip_edges().is_empty() or source=="中文": return source
	if cache.has(source): return str(cache[source])
	if cache.size()>20000:cache.clear()
	var exact: Dictionary=data.get("strings",{})
	if chinese.search(source)==null and not exact.has(source):return source
	var translated=source
	if exact.has(source): translated=str(exact[source])
	elif source!=source.strip_edges():
		var trimmed=source.strip_edges()
		translated=source.replace(trimmed,translate(trimmed))
	elif source.begins_with("• ") or source.begins_with("● ") or source.begins_with("✓ ") or source.begins_with("◇ ") or source.begins_with("· "):
		translated=source.left(2)+translate(source.substr(2))
	elif source.ends_with(" ·") or source.ends_with(" /") or source.ends_with(" |"):
		translated=translate(source.left(-2))+source.right(2)
	else:
		_ensure_patterns()
		for item in patterns:
			var found=item.regex.search(source)
			if found!=null:
				translated=item.en
				for i in range(found.get_group_count(),0,-1): translated=translated.replace("{"+str(i)+"}",translate(found.get_string(i)))
				break
		if chinese.search(translated)!=null:
			var prefix_result=_known_prefix(source,exact)
			if not prefix_result.is_empty():translated=prefix_result
			if chinese.search(translated)!=null and source.contains("\n"):
				var paragraphs: Array[String]=[]
				for paragraph in source.split("\n"):paragraphs.append(translate(paragraph))
				translated="\n".join(paragraphs)
			elif chinese.search(translated)!=null and source.contains("；"):
				var clauses=source.split("；",true,1)
				translated=translate(clauses[0])+"; "+translate(clauses[1])
		if translated==source and source.contains("\n"):
			var lines: Array[String]=[]
			for line in source.split("\n"): lines.append(translate(line))
			translated="\n".join(lines)
		if translated==source:
			for prefix in ["• ","● ","✓ ","◇ ","· "]:
				if source.begins_with(prefix):translated=prefix+translate(source.trim_prefix(prefix));break
		if translated==source:
			for suffix in [" ·"," /","："]:
				if source.ends_with(suffix):translated=translate(source.trim_suffix(suffix))+suffix;break
		if translated==source:
			for separator in [" · "," / ","：","；","、","·"]:
				if source.contains(separator):
					var pieces: Array[String]=[]
					# Preserve complete sentences after a speaker/label prefix. Splitting
					# every colon at once would break a later speaker inside that sentence.
					for piece in source.split(separator,true,1):pieces.append(translate(piece))
					translated=(": " if separator=="：" else "; " if separator=="；" else ", " if separator=="、" else " · " if separator=="·" else separator).join(pieces)
					if translated!=source:break
		# Unknown sentences stay visible to the coverage audit. Replacing arbitrary
		# words used to create misleading, partly translated English sentences.
		if translated==source and source!=source.strip_edges():
			var trimmed=source.strip_edges()
			translated=source.replace(trimmed,translate(trimmed))
	if chinese.search(translated)!=null: untranslated[source]=translated
	cache[source]=translated
	return translated
func _property(node: Object, property: String, key: String) -> void:
	var current=str(node.get(property))
	if current!=str(node.get_meta(key+"_last",current)) or not node.has_meta(key+"_source"):
		node.set_meta(key+"_source",current)
	var translated=translate(str(node.get_meta(key+"_source",current)))
	if current!=translated:node.set(property,translated)
	node.set_meta(key+"_last",translated)

func _item(node: Object, index: int, key: String) -> void:
	var current=str(node.get_item_text(index))
	# A menu may be cleared and rebuilt in the same node between frames.
	if not node.has_meta(key) or current!=str(node.get_meta(key+"_last",current)):
		node.set_meta(key,current)
	var translated=translate(str(node.get_meta(key,current)))
	if current!=translated:node.set_item_text(index,translated)
	node.set_meta(key+"_last",translated)

func apply_tree(node: Node) -> void:
	if node.is_queued_for_deletion() or bool(node.get_meta("culture_body_text",false)): return
	if (node is Label or node is RichTextLabel or (node is Button and not node is OptionButton)) and not bool(node.get_meta("l10n_managed_text",false)):
		# Preserve the source metadata written by the UI factories.
		_property(node,"text","l10n")
	if node is Control and not node.tooltip_text.is_empty():
		_property(node,"tooltip_text","l10n_tooltip")
	if node is LineEdit or node is TextEdit:_property(node,"placeholder_text","l10n_placeholder")
	if node is OptionButton:
		for i in range(node.item_count):
			_item(node,i,"l10n_option_"+str(i))
	elif node is PopupMenu and not node.get_parent() is OptionButton:
		for i in range(node.item_count):_item(node,i,"l10n_menu_"+str(i))
	elif node is ItemList:
		for i in range(node.item_count):_item(node,i,"l10n_list_"+str(i))
	if node is Window:_property(node,"title","l10n_title")
	if node is AcceptDialog:
		_property(node,"dialog_text","l10n_dialog")
	for child in node.get_children(): apply_tree(child)
