extends SceneTree
## Run with --script res://tools/profile_startup.gd. Isolate XDG_DATA_HOME.
var started=Time.get_ticks_usec()
func _initialize():call_deferred("run")
func run():
	var report={"headless":DisplayServer.get_name()=="headless"}
	var before=Time.get_ticks_usec()
	var scene=load("res://scenes/main.tscn")
	report.scene_load_ms=(Time.get_ticks_usec()-before)/1000.0
	var main=scene.instantiate()
	before=Time.get_ticks_usec()
	root.add_child(main)
	report.initialization_ms=(Time.get_ticks_usec()-before)/1000.0
	for i in range(5):await process_frame
	report.welcome_ms=(Time.get_ticks_usec()-started)/1000.0
	report.content={"employees":main.model.catalog.size(),"dishes":main.model.dishes.size(),"events":main.model.events.size()}
	report.normal_play_hash_snapshot_entries=main.assets._snapshot.size()
	print("STARTUP_BENCHMARK ",JSON.stringify(report))
	main.free()
	quit()
