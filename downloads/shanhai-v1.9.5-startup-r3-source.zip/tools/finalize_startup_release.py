#!/usr/bin/env python3
"""Validate actual startup release evidence and preserve it beside the source."""
import json,re,shutil
from pathlib import Path
from package_release import ROOT,game_source_fingerprint
B=ROOT/'build/startup-r3';D=ROOT/'docs/validation-artifacts/startup-r3'
def read(p):return json.loads(p.read_text())
def main():
    source=game_source_fingerprint();assert read(B/'tested-source.json')==source
    log=(B/'full-checks.log').read_text();groups=re.findall(r'^PASS (\w+):',log,re.M)
    assert len(groups)==54 and 'FAIL 'not in log
    english=read(ROOT/'build/english-r2/localization-tests.json')
    assert english['checks']==4701 and english['failures']==0 and not english['missing']
    assert '4701 checks, 0 failures'in (B/'english-tests-final.log').read_text()
    assert 'Startup checks: 14; failures: []'in (B/'startup-tests-final.log').read_text()
    browser=read(B/'browser-final2/report.json');assert browser['game_source']==source and not browser['errors']
    assert len(browser['checks'])==8 and all(c['ok']for c in browser['checks'])
    windows=read(B/'windows-verification.json');assert windows['game_source']==source and not windows['errors']and windows['startup']['complete']
    bench=read(B/'benchmarks.json');assert bench['game_source']==source and bench['content_equal']
    for platform in ['web','windows']:assert read(ROOT/f'build/full-{platform}/export-receipt.json')['game_source']==source
    pe=read(B/'windows-pe.json');assert not pe['visual_cpp_runtime_imports']and pe['machine']=='AMD64 / x86_64'
    content=read(B/'content-preservation.json');assert content['art_audio_balance_culture_unchanged']
    summary={'version':'SH-STARTUP-R3','validated_on':'2026-11-01','game_source':source,'native_groups':groups,'native_group_count':len(groups),'english_checks':english['checks'],'startup_checks':14,'browser_actions':len(browser['actions']),'browser_checks':len(browser['checks']),'browser_errors':browser['errors'],'windows_target':'Windows 10/11 x64; D3D11 ANGLE preferred, OpenGL fallback','windows_test_environment':windows['environment'],'windows_tested_path':'OpenGL fallback at 1024x768; default ANGLE hardware not certified','classroom_machine_known':False,'complete_content_preserved':True,'performance_scope':bench['environment'],'regression_scope':'54-group run, followed by targeted English event-result correction and successful 4701-check rerun, final boot check, exported Windows and final Web flow. No claim that source stayed frozen across the earlier full run.'}
    D.mkdir(parents=True,exist_ok=True)
    for name in ['benchmarks.json','content-preservation.json','windows-pe.json','windows-verification.json','windows-final.log','wine-angle-limitation.json','windows-angle-graphics.log','full-checks.log','english-tests-final.log','startup-tests-final.log','windows-final-1024x768.png']:
        shutil.copyfile(B/name,D/(name[:-4]+".txt" if name.endswith(".log") else name))
    shutil.copyfile(ROOT/'build/english-r2/localization-tests.json',D/'localization-tests.json')
    shutil.copyfile(B/'browser-final2/report.json',D/'browser-report.json')
    for name in ['01-english-welcome','01b-mobile-guide','03-first-accounts','12-letters-english','13-mobile-letters','16-chinese-return']:
        shutil.copyfile(B/f'browser-final2/{name}.png',D/f'{name}.png')
    (D/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    p=ROOT/'docs/startup-performance-validation.md';s=p.read_text();marker='\n## 最终检查与证据\n'
    if marker in s:s=s.split(marker)[0]
    s+=marker+f'\n运行源码指纹`{source["sha256"]}`，{source["files"]}项，Web/Windows回执一致。54组回归通过，随后对实际浏览器新发现的带符号事件结果行补译并专项复验：英文4701项、启动14项通过。最终浏览器{len(browser["actions"])}次真实操作、8结果检查、0错误，涵盖首单、原文读本、随机事件、实际日结与来信、小屏返回、存档刷新及中英切换。专项修复后没有重复宣称整轮源码全程未变化；实际记录保留。\n\n最终Windows EXE在Wine/OpenGL/1024×768环境启动到完整欢迎页，无脚本错误；此处不声明真实Windows课堂硬件或ANGLE实体显卡已验收。证据见[summary.json](validation-artifacts/startup-r3/summary.json)及同目录原始记录。后验下载核验在公开发布后追加，不重打包覆盖已发布文件。\n'
    p.write_text(s)
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
