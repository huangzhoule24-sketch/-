#!/usr/bin/env bash
set -euo pipefail
shanhai_root="$(realpath "$(dirname "${BASH_SOURCE[0]}")/..")"
cd "$shanhai_root"
export XDG_DATA_HOME="${XDG_DATA_HOME:-/workspace/.tools/godot/data}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-/workspace/.tools/godot/config}"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/workspace/.tools/godot/cache}"
mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" build/full-windows
godot --headless --path "$shanhai_root" --editor --import --quit
python3 tools/package_release.py begin windows
godot --headless --path "$shanhai_root" --export-release "Windows Desktop" "$shanhai_root/build/full-windows/shanhai-v1.9.5-startup-r3.exe"
python3 tools/package_release.py stamp windows
